suppressPackageStartupMessages({
  library(BisqueRNA)
  library(Biobase)
  library(Matrix)
})

der <- "C:/wb_links/dlc_derived/D11_deconvolution"
sc_mtx_file <- file.path(der, "D11_Bisque_gingiva_sc_counts.mtx")
sc_meta_file <- file.path(der, "D11_Bisque_gingiva_sc_metadata.csv")
sc_genes_file <- file.path(der, "D11_Bisque_gingiva_sc_genes.txt")

sc_sparse <- readMM(sc_mtx_file)
sc_counts_all <- as.matrix(sc_sparse)
rm(sc_sparse)
sc_meta <- read.csv(sc_meta_file, check.names = FALSE, stringsAsFactors = FALSE)
sc_genes <- readLines(sc_genes_file, encoding = "UTF-8")
rownames(sc_counts_all) <- sc_genes
colnames(sc_counts_all) <- sc_meta$cell_id
sc_meta$SubjectName <- factor(sc_meta$SubjectName)
sc_meta$cellType <- factor(sc_meta$cellType)
rownames(sc_meta) <- sc_meta$cell_id

collapse_rows <- function(x) {
  x <- as.matrix(x)
  storage.mode(x) <- "numeric"
  if (anyDuplicated(rownames(x))) x <- rowsum(x, group = rownames(x), reorder = FALSE)
  x
}

make_esets <- function(bulk) {
  bulk <- collapse_rows(bulk)
  markers <- intersect(setdiff(rownames(sc_counts_all), "__OTHER__"), rownames(bulk))
  if (length(markers) < 80) stop("Insufficient gingiva marker overlap: ", length(markers))

  sc_common <- sc_counts_all[markers, , drop = FALSE]
  sc_other <- colSums(sc_counts_all) - colSums(sc_common)
  sc_use <- rbind(sc_common, `__OTHER__` = pmax(sc_other, 0))
  bulk_common <- bulk[markers, , drop = FALSE]
  bulk_other <- colSums(bulk) - colSums(bulk_common)
  bulk_use <- rbind(bulk_common, `__OTHER__` = pmax(bulk_other, 0))

  sc_eset <- ExpressionSet(
    assayData = sc_use,
    phenoData = AnnotatedDataFrame(sc_meta[colnames(sc_use), , drop = FALSE])
  )
  bulk_eset <- ExpressionSet(assayData = bulk_use)
  list(sc = sc_eset, bulk = bulk_eset, markers = markers)
}

run_bisque <- function(bulk, dataset, group, batch = NULL) {
  es <- make_esets(bulk)
  cat(dataset, ":", length(es$markers), "markers,", ncol(exprs(es$bulk)), "bulk samples\n")
  fit <- ReferenceBasedDecomposition(
    bulk.eset = es$bulk,
    sc.eset = es$sc,
    markers = es$markers,
    cell.types = "cellType",
    subject.names = "SubjectName",
    use.overlap = FALSE,
    verbose = TRUE,
    old.cpm = FALSE
  )
  props <- t(fit$bulk.props)
  props <- props[, setdiff(colnames(props), "__OTHER__"), drop = FALSE]
  out <- data.frame(sample = rownames(props), group = unname(group[rownames(props)]),
                    props, check.names = FALSE)
  if (!is.null(batch)) out$batch <- unname(batch[out$sample])
  write.csv(out, file.path(der, paste0("D11_", dataset, "_Bisque_cell_fractions.csv")), row.names = FALSE)

  tests <- lapply(colnames(props), function(ct) {
    h <- props[group[rownames(props)] == "Healthy", ct]
    p <- props[group[rownames(props)] == "Periodontitis", ct]
    wt <- wilcox.test(p, h, exact = FALSE)
    data.frame(dataset = dataset, cell_type = ct, n_H = length(h), n_PD = length(p),
               median_H = median(h), median_PD = median(p),
               difference_PD_minus_H = median(p) - median(h),
               wilcox_p = wt$p.value)
  })
  tests <- do.call(rbind, tests)
  tests$wilcox_FDR <- p.adjust(tests$wilcox_p, method = "BH")
  write.csv(tests, file.path(der, paste0("D11_", dataset, "_Bisque_group_tests.csv")), row.names = FALSE)

  full_bulk <- collapse_rows(bulk)
  lib <- colSums(full_bulk)
  gdf <- log2(full_bulk["GDF15", rownames(props)] / lib[rownames(props)] * 1e6 + 0.5)
  d <- data.frame(GDF15 = as.numeric(gdf),
                  PD = as.integer(group[rownames(props)] == "Periodontitis"),
                  fibroblast = props[, "Fibroblast"],
                  epithelial = props[, "Epithelial"],
                  immune = rowSums(props[, intersect(colnames(props),
                    c("T/NK", "B/Plasma", "Myeloid/DC", "Neutrophil", "Mast")), drop = FALSE]))
  if (!is.null(batch)) d$batch <- factor(batch[rownames(props)])
  f_raw <- if (is.null(batch)) GDF15 ~ PD else GDF15 ~ PD + batch
  f_adj <- if (is.null(batch)) GDF15 ~ PD + fibroblast + epithelial + immune else
    GDF15 ~ PD + batch + fibroblast + epithelial + immune
  m_raw <- lm(f_raw, data = d)
  m_adj <- lm(f_adj, data = d)
  take <- function(m, label) {
    ci <- confint(m, "PD")
    data.frame(dataset = dataset, model = label, PD_beta = coef(m)["PD"],
               PD_CI_low = ci[1], PD_CI_high = ci[2], PD_p = summary(m)$coefficients["PD", "Pr(>|t|)"])
  }
  gdf_out <- rbind(take(m_raw, "unadjusted"), take(m_adj, "composition_adjusted"))
  write.csv(gdf_out, file.path(der, paste0("D11_", dataset, "_Bisque_GDF15_models.csv")), row.names = FALSE)
  list(props = out, tests = tests, gdf = gdf_out, genes = fit$genes.used, rnorm = fit$rnorm)
}

b1 <- read.csv(gzfile("C:/wb_links/dlc_data/external_GSE223924/GSE223924_raw_count.csv.gz"),
               row.names = 1, check.names = FALSE)
s1 <- c(paste0("H", 1:10), paste0("PT", c(1:8, 10, 11)))
b1 <- b1[, s1, drop = FALSE]
g1 <- setNames(ifelse(grepl("^PT", s1), "Periodontitis", "Healthy"), s1)
r1 <- run_bisque(b1, "GSE223924", g1)

b2 <- read.delim(gzfile("C:/wb_links/dlc_data/external_GSE173078/GSE173078_rnaseq_raw_counts.txt.gz"),
                 row.names = 1, check.names = FALSE)
pd_a <- c("AC001", "AC003", "AC005", "AC007", "AC009", "AC011")
h_a <- c("AC013", "AC016", "AC018", "AC019", "AC022", "AC024")
pd_b <- c("AC037", "AC039", "AC042", "AC044", "AC046", "AC048")
h_b <- c("AC050", "AC052", "AC054", "AC056", "AC058", "AC060")
s2 <- c(h_a, h_b, pd_a, pd_b)
b2 <- b2[, s2, drop = FALSE]
g2 <- setNames(ifelse(s2 %in% c(pd_a, pd_b), "Periodontitis", "Healthy"), s2)
batch2 <- setNames(ifelse(s2 %in% c(h_a, pd_a), "A", "B"), s2)
r2 <- run_bisque(b2, "GSE173078", g2, batch2)

all_tests <- rbind(r1$tests, r2$tests)
all_gdf <- rbind(r1$gdf, r2$gdf)
write.csv(all_tests, file.path(der, "D11_Bisque_cross_cohort_group_tests.csv"), row.names = FALSE)
write.csv(all_gdf, file.path(der, "D11_Bisque_cross_cohort_GDF15_models.csv"), row.names = FALSE)
writeLines(capture.output(sessionInfo()), file.path(der, "D11_Bisque_sessionInfo.txt"))
cat("Formal BisqueRNA analysis completed.\n")
