from __future__ import annotations
import gzip
import os
import sys
import zipfile
import numpy as np
import pandas as pd
from scipy import sparse, stats
from scipy.optimize import nnls
import statsmodels.api as sm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gingiva_reference import BROAD_ORDER, load_reference, derive_markers, bh_fdr
from style_npj import set_npj_style, save_npj, NPJ_CASE, NPJ_CTRL, NPJ_DISCRETE, MM
set_npj_style()
ZIP = 'C:\\Users\\Lin\\Downloads\\dataverse_files.zip'
BULK = 'E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\01_\u6570\u636e\u51c6\u5907\\external_GSE223924\\GSE223924_raw_count.csv.gz'
DER = 'E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\data_derived\\D11_deconvolution'
OUT = 'E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\\u7b2c11\u9879_bulk\u7ec6\u80de\u7ec4\u6210\u53bb\u5377\u79ef'
os.makedirs(DER, exist_ok=True)
os.makedirs(OUT, exist_ok=True)

def ungzip(b):
    return gzip.decompress(b) if b[:2] == b'\x1f\x8b' else b

def linearize_log1p(X):
    Y = X.copy().tocsr().astype(np.float64)
    Y.data = np.expm1(Y.data)
    return Y

def mean_profile(Y, labels, classes=BROAD_ORDER):
    arr = []
    lab = np.asarray(labels)
    for c in classes:
        ii = np.flatnonzero(lab == c)
        arr.append(np.asarray(Y[ii].mean(axis=0)).ravel() if len(ii) else np.full(Y.shape[1], np.nan))
    return np.vstack(arr).T

def fit_nnls(A, b, normalize_columns=True):
    AA = A / np.maximum(A.sum(axis=0, keepdims=True), 1e-12) if normalize_columns else A
    bb = b / max(float(np.sum(b)), 1e-12)
    coef, _ = nnls(AA, bb)
    return coef / coef.sum() if coef.sum() else np.full(A.shape[1], np.nan)
with zipfile.ZipFile(ZIP) as z:
    fn = next((n for n in z.namelist() if n.endswith('_features.tsv.gz')))
    panel = [x.split('\t')[1] for x in ungzip(z.read(fn)).decode().splitlines() if x]
Xref, obs, genes = load_reference(panel)
markers, marker_audit, _ = derive_markers(Xref, obs, genes, top_n=12)
bulk = pd.read_csv(BULK, index_col=0)
bulk = bulk.loc[~bulk.index.duplicated(keep='first')]
samples = [c for c in bulk.columns if c.startswith('H') or c.startswith('PT')]
groups = pd.Series({c: 'Periodontitis' if c.startswith('PT') else 'Healthy' for c in samples}, name='group')
selected = sorted({g for v in markers.values() for g in v if g in bulk.index and g in genes})
if len(selected) < 50:
    raise ValueError(f'Only {len(selected)} marker genes overlap bulk; insufficient for deconvolution')
marker_audit[marker_audit.gene.isin(selected)].to_csv(os.path.join(DER, 'D11_marker_gene_audit.csv'), index=False)
gidx = [genes.index(g) for g in selected]
Y = linearize_log1p(Xref[:, gidx])
profiles_by_donor = {}
for donor, ii in obs.groupby('donor_id', observed=True).indices.items():
    profiles_by_donor[donor] = mean_profile(Y[ii], obs.iloc[ii].broad_type)
profile_stack = np.stack(list(profiles_by_donor.values()), axis=2)
profile = np.nanmean(profile_stack, axis=2)
pd.DataFrame(profile, index=selected, columns=BROAD_ORDER).to_csv(os.path.join(DER, 'D11_gingiva_reference_profiles.csv'))
lib = bulk[samples].sum(axis=0)
cpm = bulk[samples].div(lib, axis=1) * 1000000.0
ref_prop = obs.broad_type.value_counts(normalize=True).reindex(BROAD_ORDER, fill_value=0).to_numpy()
expected = profile.dot(ref_prop)
bulk_mean = cpm.loc[selected, samples].mean(axis=1).to_numpy(float)
bias = bulk_mean / np.maximum(expected, 1e-08)
lo, hi = np.nanpercentile(bias[np.isfinite(bias)], [5, 95])
bias = np.clip(np.nan_to_num(bias, nan=np.nanmedian(bias), posinf=hi), lo, hi)
profile_bulk = profile * bias[:, None]
pd.DataFrame({'gene': selected, 'cross_platform_bias': bias, 'reference_expected': expected, 'bulk_mean_CPM': bulk_mean}).to_csv(os.path.join(DER, 'D11_cross_platform_gene_calibration.csv'), index=False)
est = {}
for s in samples:
    est[s] = fit_nnls(profile_bulk, cpm.loc[selected, s].to_numpy(float), normalize_columns=False)
E = pd.DataFrame(est, index=BROAD_ORDER).T
E.insert(0, 'group', groups[E.index].to_numpy())
E.to_csv(os.path.join(DER, 'D11_GSE223924_estimated_cell_fractions.csv'))
cv_rows = []
for donor, ii in obs.groupby('donor_id', observed=True).indices.items():
    train_profiles = np.stack([v for k, v in profiles_by_donor.items() if k != donor], axis=2)
    A = np.nanmean(train_profiles, axis=2)
    pseudo = np.asarray(Y[ii].mean(axis=0)).ravel()
    pred = fit_nnls(A, pseudo)
    counts = obs.iloc[ii].broad_type.value_counts().reindex(BROAD_ORDER, fill_value=0)
    true = counts.to_numpy(float) / counts.sum()
    for c, t, p in zip(BROAD_ORDER, true, pred):
        cv_rows.append({'donor': donor, 'cell_type': c, 'true_fraction': t, 'estimated_fraction': p})
cv = pd.DataFrame(cv_rows)
cv.to_csv(os.path.join(DER, 'D11_leave_one_donor_out_validation.csv'), index=False)
cv_stats = []
for c, q in cv.groupby('cell_type', observed=True):
    r, p = stats.spearmanr(q.true_fraction, q.estimated_fraction)
    cv_stats.append({'cell_type': c, 'n_donors': len(q), 'spearman_rho': r, 'spearman_p': p, 'MAE': np.mean(np.abs(q.true_fraction - q.estimated_fraction))})
cv_stats = pd.DataFrame(cv_stats)
cv_stats.to_csv(os.path.join(DER, 'D11_validation_metrics.csv'), index=False)
rng = np.random.default_rng(20260914)
boot_rows = []
for s in samples:
    b = cpm.loc[selected, s].to_numpy(float)
    vals = []
    for _ in range(300):
        jj = rng.integers(0, len(selected), len(selected))
        vals.append(fit_nnls(profile_bulk[jj], b[jj], normalize_columns=False))
    vals = np.vstack(vals)
    for k, c in enumerate(BROAD_ORDER):
        boot_rows.append({'sample': s, 'group': groups[s], 'cell_type': c, 'estimate': E.loc[s, c], 'bootstrap_CI95_low': np.percentile(vals[:, k], 2.5), 'bootstrap_CI95_high': np.percentile(vals[:, k], 97.5)})
boot = pd.DataFrame(boot_rows)
boot.to_csv(os.path.join(DER, 'D11_GSE223924_fraction_bootstrap_CI.csv'), index=False)
test_rows = []
for c in BROAD_ORDER:
    h = E.loc[E.group == 'Healthy', c]
    p = E.loc[E.group == 'Periodontitis', c]
    u = stats.mannwhitneyu(p, h, alternative='two-sided')
    test_rows.append({'cell_type': c, 'n_H': len(h), 'n_PD': len(p), 'median_H': h.median(), 'median_PD': p.median(), 'difference_PD_minus_H': p.median() - h.median(), 'MWU_p': u.pvalue})
tests = pd.DataFrame(test_rows)
tests['MWU_FDR'] = bh_fdr(tests.MWU_p)
tests.to_csv(os.path.join(DER, 'D11_GSE223924_group_tests.csv'), index=False)
logcpm = np.log2(cpm.loc[selected, samples] + 0.5)
gene_z = logcpm.sub(logcpm.mean(axis=1), axis=0).div(logcpm.std(axis=1).replace(0, np.nan), axis=0)
score_rows = []
for c in BROAD_ORDER:
    mg = [g for g in markers[c] if g in gene_z.index]
    score = gene_z.loc[mg].mean(axis=0)
    hh = score[[s for s in samples if s.startswith('H')]]
    pp = score[[s for s in samples if s.startswith('PT')]]
    u2 = stats.mannwhitneyu(pp, hh, alternative='two-sided')
    score_rows.append({'cell_type': c, 'n_markers': len(mg), 'mean_score_H': hh.mean(), 'mean_score_PD': pp.mean(), 'difference_PD_minus_H': pp.mean() - hh.mean(), 'MWU_p': u2.pvalue})
score_test = pd.DataFrame(score_rows)
score_test['MWU_FDR'] = bh_fdr(score_test.MWU_p)
score_test = score_test.merge(tests[['cell_type', 'difference_PD_minus_H']].rename(columns={'difference_PD_minus_H': 'NNLS_difference_PD_minus_H'}), on='cell_type')
score_test['direction_concordant_with_NNLS'] = np.sign(score_test.difference_PD_minus_H) == np.sign(score_test.NNLS_difference_PD_minus_H)
score_test.to_csv(os.path.join(DER, 'D11_marker_score_sensitivity.csv'), index=False)
gdf = np.log2(cpm.loc['GDF15', samples] + 0.5)
design = pd.DataFrame(index=samples)
design['periodontitis'] = (groups[samples] == 'Periodontitis').astype(int).to_numpy()
design['fibroblast'] = E.loc[samples, 'Fibroblast']
design['epithelial'] = E.loc[samples, 'Epithelial']
design['immune'] = E.loc[samples, ['T/NK', 'B/Plasma', 'Myeloid/DC', 'Neutrophil', 'Mast']].sum(axis=1)
fit_adj = sm.OLS(gdf.to_numpy(), sm.add_constant(design)).fit(cov_type='HC3')
fit_raw = sm.OLS(gdf.to_numpy(), sm.add_constant(design[['periodontitis']])).fit(cov_type='HC3')
gdf_res = pd.DataFrame([{'model': 'unadjusted', 'PD_beta': fit_raw.params['periodontitis'], 'PD_CI_low': fit_raw.conf_int().loc['periodontitis', 0], 'PD_CI_high': fit_raw.conf_int().loc['periodontitis', 1], 'PD_p': fit_raw.pvalues['periodontitis']}, {'model': 'composition_adjusted', 'PD_beta': fit_adj.params['periodontitis'], 'PD_CI_low': fit_adj.conf_int().loc['periodontitis', 0], 'PD_CI_high': fit_adj.conf_int().loc['periodontitis', 1], 'PD_p': fit_adj.pvalues['periodontitis']}])
gdf_res.to_csv(os.path.join(DER, 'D11_GDF15_composition_adjusted_model.csv'), index=False)
fig = plt.figure(figsize=(180 * MM, 150 * MM))
gs = fig.add_gridspec(2, 2, height_ratios=[0.78, 1.15], width_ratios=[0.72, 1.28], left=0.08, right=0.98, bottom=0.09, top=0.9, wspace=0.34, hspace=0.45)
ax = fig.add_subplot(gs[0, 0])
q = cv_stats.set_index('cell_type').reindex(BROAD_ORDER).sort_values('spearman_rho')
y = np.arange(len(q))
ax.barh(y, q.spearman_rho, color='#8F8F8F', height=0.65)
ax.axvline(0, c='black', lw=0.5)
ax.set_xlim(-1, 1)
ax.set_yticks(y)
ax.set_yticklabels(q.index)
ax.set_xlabel('LODO Spearman \u03c1')
ax.set_title('Gingiva-reference validation', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=.35'))
fig.text(0.045, 0.94, 'A', fontsize=12, fontweight='bold')
ax = fig.add_subplot(gs[0, 1])
order = [s for s in samples if s.startswith('H')] + [s for s in samples if s.startswith('PT')]
bottom = np.zeros(len(order))
for k, c in enumerate(BROAD_ORDER):
    v = E.loc[order, c].to_numpy()
    ax.bar(range(len(order)), v, bottom=bottom, width=0.85, color=NPJ_DISCRETE[k], label=c, lw=0)
    bottom += v
ax.set_xticks(range(len(order)))
ax.set_xticklabels(order, rotation=90)
ax.set_ylabel('Estimated fraction')
ax.set_ylim(0, 1)
ax.legend(frameon=False, ncol=5, bbox_to_anchor=(1.0, -0.18), loc='upper right', fontsize=5.2, handlelength=0.9, columnspacing=0.8, handletextpad=0.25)
ax.set_title('GSE223924 cell composition', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=.35'))
fig.text(0.39, 0.94, 'B', fontsize=12, fontweight='bold')
ax = fig.add_subplot(gs[1, :])
show = tests.reindex(tests.difference_PD_minus_H.abs().sort_values(ascending=False).index).head(6).cell_type.tolist()
positions = []
labels = []
for i, c in enumerate(show):
    for j, (grp, col) in enumerate([('Healthy', NPJ_CTRL), ('Periodontitis', NPJ_CASE)]):
        x = i * 2.2 + j * 0.65
        v = E.loc[E.group == grp, c].to_numpy()
        positions.append(x)
        bp = ax.boxplot([v], positions=[x], widths=0.48, patch_artist=True, showfliers=False, medianprops=dict(color='black', lw=0.8), boxprops=dict(lw=0.6), whiskerprops=dict(lw=0.6), capprops=dict(lw=0.6))
        bp['boxes'][0].set_facecolor(col)
        bp['boxes'][0].set_alpha(0.78)
        ax.scatter(x + rng.uniform(-0.08, 0.08, len(v)), v, s=7, c=col, ec='black', lw=0.25, zorder=3)
    row = tests.set_index('cell_type').loc[c]
    ax.text(i * 2.2 + 0.325, 1.02, f'FDR={row.MWU_FDR:.2g}', ha='center', va='bottom', fontsize=5.8)
    labels.append(c)
ax.set_xticks([i * 2.2 + 0.325 for i in range(len(show))])
ax.set_xticklabels(labels, rotation=25, ha='right')
ax.set_ylabel('Estimated cell fraction')
ax.set_ylim(0, 1.1)
ax.set_title('Largest differences (teal: healthy; red: periodontitis)', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=.35'))
fig.text(0.045, 0.47, 'C', fontsize=12, fontweight='bold')
save_npj(fig, os.path.join(OUT, '\u7b2c11\u9879_GSE223924_\u7259\u9f88\u53c2\u8003\u53bb\u5377\u79ef_20260914'), 180, 150, 600)
print('MARKERS', len(selected))
print('VALIDATION\n', cv_stats.sort_values('spearman_rho', ascending=False).to_string(index=False))
print('GROUP TESTS\n', tests.sort_values('MWU_FDR').to_string(index=False))
print('MARKER-SCORE SENSITIVITY\n', score_test.sort_values('MWU_FDR').to_string(index=False))
print('GDF15 MODELS\n', gdf_res.to_string(index=False))
