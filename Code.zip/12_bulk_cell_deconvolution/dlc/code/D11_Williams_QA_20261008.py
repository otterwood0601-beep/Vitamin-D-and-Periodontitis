from pathlib import Path
from itertools import combinations
import json
import numpy as np
import pandas as pd
from scipy import stats
from PIL import Image
OUT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\Williams_\u7ec6\u80de\u7ec4\u6210_GDF15\u6821\u6b63_AC_20261008')
SD = OUT / 'source_data'
m = pd.read_csv(SD / '01_Williams_cell_counts_and_metadata.csv.gz')
d = pd.read_csv(SD / '02_participant_group_manifest.csv').set_index('participant_group')
fr = pd.read_csv(SD / '04_observed_cell_fractions.csv').set_index('participant_group').reindex(d.index)
models = pd.read_csv(SD / '07_Williams_GDF15_composition_models.csv')
ct = pd.crosstab(m.participant_group, m.broad_type).reindex(index=d.index, columns=fr.columns, fill_value=0)
assert np.allclose(ct.sum(axis=1), d.n_cells)
assert np.allclose(ct.div(ct.sum(axis=1), axis=0), fr)
raw = m.groupby('participant_group')[['total_UMI', 'GDF15_UMI']].sum().reindex(d.index)
assert np.allclose(raw, d[['total_UMI', 'GDF15_UMI']])
y = np.log2(raw.GDF15_UMI / raw.total_UMI * 1000000.0 + 0.5).to_numpy()
assert np.allclose(y, d.GDF15_log2CPM)
errs = []
for model in ['unadjusted', 'composition_adjusted']:
    x = np.column_stack([np.ones(len(d)), d.PD])
    if model == 'composition_adjusted':
        x = np.column_stack([x, fr.Fibroblast, fr.Epithelial, fr[['T/NK', 'B/Plasma', 'Myeloid/DC', 'Neutrophil', 'Mast']].sum(axis=1)])
    b = np.linalg.lstsq(x, y, rcond=None)[0]
    df = len(d) - x.shape[1]
    res = y - x @ b
    cov = np.linalg.inv(x.T @ x) * (res @ res) / df
    se = np.sqrt(cov[1, 1])
    q = stats.t.ppf(0.975, df)
    pv = 2 * stats.t.sf(abs(b[1] / se), df)
    r = models[models.model == model].iloc[0]
    err = np.max(abs(np.array([b[1], b[1] - q * se, b[1] + q * se, pv]) - np.array([r.PD_beta, r.PD_CI_low, r.PD_CI_high, r.PD_p])))
    assert err < 1e-10
    errs.append(float(err))
perm = np.array(list(combinations(range(len(d)), int(d.PD.sum()))))
pr = []
for ctname in fr.columns:
    ranks = stats.rankdata(fr[ctname].to_numpy())
    observed = ranks[d.PD.eq(1)].sum()
    null = ranks[perm].sum(axis=1)
    center = int(d.PD.sum()) * (len(d) + 1) / 2
    pv = float(np.mean(abs(null - center) >= abs(observed - center) - 1e-12))
    pr.append(dict(cell_type=ctname, exact_permutation_p=pv))
pr = pd.DataFrame(pr)
o = np.argsort(pr.exact_permutation_p)
q = pr.exact_permutation_p.to_numpy()[o] * len(pr) / np.arange(1, len(pr) + 1)
q = np.minimum(np.minimum.accumulate(q[::-1])[::-1], 1)
fdr = np.empty(len(pr))
fdr[o] = q
pr['exact_permutation_FDR'] = fdr
pr.to_csv(SD / '15_cell_fraction_exact_permutation_sensitivity.csv', index=False)
pngs = {}
for p in (OUT / 'figures').glob('*.png'):
    im = Image.open(p)
    assert im.size[0] > 1800 and abs(im.info['dpi'][0] - 600) < 1
    pngs[p.name] = dict(size=im.size, dpi=im.info['dpi'])
qa = dict(cell_table_reconciliation='passed', manual_model_max_error=max(errs), rank_permutations=len(perm), exact_rank_significant_types=pr.loc[pr.exact_permutation_FDR < 0.05, 'cell_type'].tolist(), original_significant_types=pd.read_csv(SD / '06_Williams_cell_fraction_group_tests.csv').query('wilcox_FDR < 0.05').cell_type.tolist(), pngs=pngs)
(SD / '16_independent_numeric_QA.json').write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding='utf-8')
print(pr.to_string(index=False))
print(json.dumps(qa, ensure_ascii=False, indent=2))
print('[DONE] Numeric and export verification')
