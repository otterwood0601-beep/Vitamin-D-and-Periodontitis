from pathlib import Path
import json
import re
import sys
from itertools import combinations
import numpy as np
import pandas as pd
import anndata as ad
from scipy import stats, sparse
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
sys.path.insert(0, str(ROOT / 'code'))
from gingiva_reference import H5AD, BROAD_ORDER, broad_cell_type, bh_fdr
OUT = ROOT / 'output' / 'Williams_\u7ec6\u80de\u7ec4\u6210_GDF15\u6821\u6b63_AC_20261008'
SD = OUT / 'source_data'
SD.mkdir(parents=True, exist_ok=True)
CACHE = SD / '01_Williams_cell_counts_and_metadata.csv.gz'
if not CACHE.exists():
    a = ad.read_h5ad(H5AD, backed='r')
    mask = (a.obs['Study'].astype(str) == 'Williams') & (a.obs['tissue'].astype(str) == 'gingiva') & a.obs['disease'].astype(str).isin(['normal', 'periodontitis'])
    idx = np.flatnonzero(mask.to_numpy())
    m = a.obs.iloc[idx][['Study', 'GSE', 'Sample ID', 'donor_id', 'disease', 'tissue', 'sex', 'cell_type']].copy()
    m = m.rename(columns={'Sample ID': 'sample_id', 'donor_id': 'atlas_sample_accession'})
    m.insert(0, 'cell_id', m.index.astype(str))
    m['participant_group'] = m.sample_id.astype(str).map(lambda x: re.sub('[a-z]+$', '', x))
    m['broad_type'] = m.cell_type.map(broad_cell_type)
    if not m.broad_type.isin(BROAD_ORDER).all():
        raise ValueError('Unmapped cell type; do not silently remove denominator cells')
    gidx = np.flatnonzero(a.raw.var.feature_name.astype(str).to_numpy() == 'GDF15')
    if len(gidx) != 1:
        raise ValueError('GDF15 must map to exactly one raw feature')
    lib, gdf = (np.zeros(len(idx)), np.zeros(len(idx)))
    for start in range(0, len(idx), 4096):
        end = min(start + 4096, len(idx))
        x = a.raw.X[idx[start:end], :].tocsr()
        if (x.data < 0).any() or not np.allclose(x.data, np.round(x.data)):
            raise ValueError('Raw matrix is not nonnegative integer counts')
        lib[start:end] = np.asarray(x.sum(axis=1)).ravel()
        gdf[start:end] = x[:, gidx[0]].toarray().ravel()
        print(f'Extracted {end}/{len(idx)} Williams cells', flush=True)
    m['total_UMI'] = lib
    m['GDF15_UMI'] = gdf
    m.to_csv(CACHE, index=False, compression='gzip')
    a.file.close()
m = pd.read_csv(CACHE)
assert m.cell_id.is_unique and (m.total_UMI > 0).all()
assert m.GDF15_UMI.le(m.total_UMI).all()
units = m.groupby('participant_group', observed=True)
if (units.disease.nunique() != 1).any() or (units.sex.nunique() != 1).any():
    raise ValueError('Inconsistent disease or sex in a conservatively pooled unit')
manifest = units.agg(n_cells=('cell_id', 'size'), disease=('disease', 'first'), sex=('sex', 'first'), total_UMI=('total_UMI', 'sum'), GDF15_UMI=('GDF15_UMI', 'sum'), GDF15_positive_cells=('GDF15_UMI', lambda x: int((x > 0).sum())), sample_ids=('sample_id', lambda x: ';'.join(sorted(set(x)))), GEO_accessions=('atlas_sample_accession', lambda x: ';'.join(sorted(set(x)))))
manifest['grouping_note'] = np.where(manifest.sample_ids.str.contains(';'), 'Same numeric ID pooled conservatively; participant linkage not independently verified', 'Single available sample label')
manifest['PD'] = manifest.disease.eq('periodontitis').astype(int)
manifest['GDF15_CPM'] = manifest.GDF15_UMI / manifest.total_UMI * 1000000.0
manifest['GDF15_log2CPM'] = np.log2(manifest.GDF15_CPM + 0.5)
manifest['GDF15_detection_fraction'] = manifest.GDF15_positive_cells / manifest.n_cells
manifest.to_csv(SD / '02_participant_group_manifest.csv')
counts = pd.crosstab(m.participant_group, m.broad_type).reindex(index=manifest.index, columns=BROAD_ORDER, fill_value=0)
fractions = counts.div(counts.sum(axis=1), axis=0)
assert np.allclose(fractions.sum(axis=1), 1)
counts.to_csv(SD / '03_cell_type_counts.csv')
fractions.to_csv(SD / '04_observed_cell_fractions.csv')
rna = m.pivot_table(index='participant_group', columns='broad_type', values='total_UMI', aggfunc='sum', fill_value=0, observed=True).reindex(index=manifest.index, columns=BROAD_ORDER, fill_value=0)
rna = rna.div(rna.sum(axis=1), axis=0)
rna.to_csv(SD / '05_observed_RNA_fractions_sensitivity.csv')
rows = []
permutations = np.array(list(combinations(range(len(manifest)), int(manifest.PD.sum()))))
for ct in BROAD_ORDER:
    h, p = (fractions.loc[manifest.PD.eq(0), ct], fractions.loc[manifest.PD.eq(1), ct])
    test = stats.mannwhitneyu(p, h, alternative='two-sided', method='asymptotic', use_continuity=True)
    ranks = stats.rankdata(fractions[ct].to_numpy())
    observed = ranks[manifest.PD.eq(1)].sum()
    null = ranks[permutations].sum(axis=1)
    center = int(manifest.PD.sum()) * (len(manifest) + 1) / 2
    exact_p = np.mean(abs(null - center) >= abs(observed - center) - 1e-12)
    rows.append(dict(cell_type=ct, n_H=len(h), n_PD=len(p), median_H=h.median(), median_PD=p.median(), difference_PD_minus_H=p.median() - h.median(), wilcox_p=float(exact_p), wilcox_asymptotic_p=float(test.pvalue), total_reference_cells=int(counts[ct].sum())))
tests = pd.DataFrame(rows)
tests['wilcox_FDR'] = bh_fdr(tests.wilcox_p)
tests['wilcox_asymptotic_FDR'] = bh_fdr(tests.wilcox_asymptotic_p)
tests['primary_test'] = 'Exact two-sided rank permutation; all 8568 allocations'
tests.to_csv(SD / '06_Williams_cell_fraction_group_tests.csv', index=False)
immune_types = ['T/NK', 'B/Plasma', 'Myeloid/DC', 'Neutrophil', 'Mast']

def fit_models(man, frac, tag, cov_type='OLS', add_sex=False):
    d = pd.DataFrame({'PD': man.PD, 'fibroblast': frac.Fibroblast, 'epithelial': frac.Epithelial, 'immune': frac[immune_types].sum(axis=1)}, index=man.index)
    if add_sex:
        d['male'] = man.sex.eq('male').astype(int)
    fits, result = ({}, [])
    for model in ['unadjusted', 'composition_adjusted']:
        cols = ['PD'] if model == 'unadjusted' else ['PD', 'fibroblast', 'epithelial', 'immune']
        if add_sex:
            cols += ['male']
        x = sm.add_constant(d[cols], has_constant='add')
        if np.linalg.matrix_rank(x) != x.shape[1]:
            raise ValueError(f'Rank deficient {tag} {model}')
        f = sm.OLS(man.GDF15_log2CPM, x).fit()
        if cov_type == 'HC3':
            f = f.get_robustcov_results(cov_type='HC3', use_t=True)
            k = x.columns.get_loc('PD')
            coef, ci, pv = (f.params[k], f.conf_int()[k], f.pvalues[k])
        else:
            coef, ci, pv = (f.params['PD'], f.conf_int().loc['PD'], f.pvalues['PD'])
        result.append(dict(analysis=tag, model=model, covariance=cov_type, n=len(man), n_H=int(man.PD.eq(0).sum()), n_PD=int(man.PD.sum()), PD_beta=float(coef), PD_CI_low=float(ci.iloc[0] if hasattr(ci, 'iloc') else ci[0]), PD_CI_high=float(ci.iloc[1] if hasattr(ci, 'iloc') else ci[1]), PD_p=float(pv), residual_df=float(f.df_resid), R_squared=float(f.rsquared)))
        fits[model] = f
    return (result, fits)
main, fits = fit_models(manifest, fractions, 'cell_fraction_primary')
models = pd.DataFrame(main)
models.to_csv(SD / '07_Williams_GDF15_composition_models.csv', index=False)
with open(SD / '08_primary_model_details.txt', 'w', encoding='utf-8') as f:
    for name, model in fits.items():
        f.write(name + '\n' + model.summary().as_text() + '\n\n')
sens = []
for man, fr, tag, cov, sex in [(manifest, fractions, 'cell_fraction_HC3', 'HC3', False), (manifest, rna, 'RNA_fraction_sensitivity', 'OLS', False), (manifest, fractions, 'cell_fraction_plus_sex', 'OLS', True)]:
    res, _ = fit_models(man, fr, tag, cov, sex)
    sens.extend(res)
pd.DataFrame(sens).to_csv(SD / '09_sensitivity_models.csv', index=False)
loo = []
for key in manifest.index:
    keep = manifest.index != key
    res, _ = fit_models(manifest.loc[keep], fractions.loc[keep], 'leave_one_group_out')
    for row in res:
        row['excluded_group'] = key
    loo.extend(res)
pd.DataFrame(loo).to_csv(SD / '10_leave_one_group_out_models.csv', index=False)
contribution = m.groupby('broad_type', observed=True).agg(n_cells=('cell_id', 'size'), GDF15_UMI=('GDF15_UMI', 'sum'), positive_cells=('GDF15_UMI', lambda x: int((x > 0).sum())), total_UMI=('total_UMI', 'sum'))
contribution['share_of_all_GDF15_UMI'] = contribution.GDF15_UMI / contribution.GDF15_UMI.sum()
contribution.to_csv(SD / '11_GDF15_cell_type_contributions.csv')
x = fits['composition_adjusted'].model.exog
vifs = {name: float(variance_inflation_factor(x, i)) for i, name in enumerate(fits['composition_adjusted'].model.exog_names) if name != 'const'}
influence = fits['composition_adjusted'].get_influence()
pd.DataFrame({'participant_group': manifest.index, 'cooks_distance': influence.cooks_distance[0], 'leverage': influence.hat_matrix_diag}).to_csv(SD / '12_model_influence.csv', index=False)
qa = dict(source_h5ad=H5AD, source_dataset='Williams GSE164241 subset of integrated gingiva atlas', n_cells=len(m), n_sample_labels=int(m.sample_id.nunique()), n_participant_groups=len(manifest), n_healthy=int(manifest.PD.eq(0).sum()), n_periodontitis=int(manifest.PD.sum()), pooled_groups=manifest.loc[manifest.sample_ids.str.contains(';'), 'sample_ids'].to_dict(), grouping_uncertainty='Same numeric sample IDs pooled conservatively; participant linkage not independently verified', absent_GEO_sample='GSM7780241 / ID080UST is absent in the local integrated atlas; not substituted', n_GDF15_positive_cells=int((m.GDF15_UMI > 0).sum()), total_GDF15_UMI=int(m.GDF15_UMI.sum()), min_cells_per_group=int(manifest.n_cells.min()), max_cells_per_group=int(manifest.n_cells.max()), max_fraction_sum_error=float(np.max(abs(fractions.sum(axis=1) - 1))), VIF=vifs, design_rank=int(np.linalg.matrix_rank(x)), design_columns=x.shape[1], composition_covariates=['fibroblast', 'epithelial', 'pooled immune'], cell_fraction_test='Exact two-sided rank permutation across all 8568 allocations; BH FDR over 10 types', outcome='log2(sum raw GDF15 UMI / sum all-gene UMI * 1e6 + 0.5)', independent_validation=False, limitations=['Single-cell captured fractions are not histological tissue fractions', 'Synthetic tissue pseudobulk is not an independently measured bulk sample', 'Williams cells also contributed to the prior BisqueRNA reference', 'Only 5 conservatively grouped periodontitis units; sensitivity results required'])
(SD / '13_analysis_QA_manifest.json').write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(qa, ensure_ascii=False, indent=2), flush=True)
print(tests.to_string(index=False), flush=True)
print(models.to_string(index=False), flush=True)
print(pd.DataFrame(sens).to_string(index=False), flush=True)
print('[DONE] Analysis tables', flush=True)
