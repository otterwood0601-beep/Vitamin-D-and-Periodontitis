from pathlib import Path
import sys
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
sys.path.insert(0, str(ROOT / 'code'))
from style_npj import set_npj_style, save_npj, MM
set_npj_style()
OUT = ROOT / 'output' / 'Williams_\u7ec6\u80de\u7ec4\u6210_GDF15\u6821\u6b63_AC_20261008'
SD, FIG = (OUT / 'source_data', OUT / 'figures')
FIG.mkdir(exist_ok=True)
tests = pd.read_csv(SD / '06_Williams_cell_fraction_group_tests.csv').set_index('cell_type')
models = pd.read_csv(SD / '07_Williams_GDF15_composition_models.csv')
manifest = pd.read_csv(SD / '02_participant_group_manifest.csv')
order = ['Epithelial', 'Fibroblast', 'B/Plasma', 'Neutrophil', 'Mast', 'T/NK', 'Myeloid/DC', 'Endothelial', 'Mural', 'Neural/Melanocyte']
tests = tests.loc[order]
header = dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=.35')

def heatmap(ax, cax):
    values = tests.difference_PD_minus_H.to_numpy()[:, None] * 100
    vmax = np.max(abs(values)) * 1.05
    im = ax.imshow(values, cmap='RdBu_r', vmin=-vmax, vmax=vmax, aspect='auto')
    ax.set_yticks(range(len(order)))
    ax.set_yticklabels(order)
    ax.set_xticks([0])
    ax.set_xticklabels(['Williams'])
    for i in range(len(order)):
        v = values[i, 0]
        star = '*' if tests.wilcox_FDR.iloc[i] < 0.05 else ''
        ax.text(0, i, f'{v:+.1f}{star}', ha='center', va='center', fontsize=7, color='white' if abs(v) > vmax * 0.55 else 'black')
    cb = ax.figure.colorbar(im, cax=cax)
    cb.set_label('Median cell-fraction difference\n(PD \u2212 healthy; percentage points)', fontsize=7)
    cb.ax.tick_params(labelsize=6)
    ax.set_title('Observed cell composition', bbox=header, pad=8)

def forest(ax):
    for y, (_, r) in zip([1, 0], models.iterrows()):
        color = '#8F8F8F' if r.model == 'unadjusted' else '#7E5AA7'
        ax.errorbar(r.PD_beta, y, xerr=[[r.PD_beta - r.PD_CI_low], [r.PD_CI_high - r.PD_beta]], fmt='o', ms=4.5, color=color, elinewidth=1, capsize=2)
        ax.text(r.PD_beta, y + 0.18, f'p = {r.PD_p:.3f}', ha='center', va='bottom', fontsize=7)
    ax.axvline(0, color='black', lw=0.6, ls='--')
    ax.set_yticks([1, 0])
    ax.set_yticklabels(['Unadjusted', 'Cell-composition\nadjusted'], fontsize=7)
    ax.set_ylim(-0.6, 1.6)
    ax.set_xlim(-0.9, 2.0)
    ax.set_xticks([-0.5, 0, 0.5, 1, 1.5])
    ax.set_xlabel('GDF15 difference (PD \u2212 healthy)\nlog2(CPM + 0.5)')
    ax.set_title('GDF15 before/after adjustment', bbox=header, pad=8)
fig = plt.figure(figsize=(180 * MM, 112 * MM))
heatmap(fig.add_axes([0.155, 0.2, 0.26, 0.63]), fig.add_axes([0.431, 0.2, 0.014, 0.63]))
forest(fig.add_axes([0.715, 0.2, 0.26, 0.63]))
fig.text(0.045, 0.91, 'A', fontsize=12, fontweight='bold')
fig.text(0.58, 0.91, 'C', fontsize=12, fontweight='bold')
fig.text(0.155, 0.115, 'Williams gingiva: 13 healthy and 5 PD sample groups (86,138 cells).', fontsize=6)
fig.text(0.155, 0.07, 'A: exact rank tests; * FDR < 0.05. C: pooled raw-count expression; bars: 95% CI.', fontsize=6)
fig.text(0.155, 0.035, 'Repeated numeric sample IDs pooled conservatively; participant linkage is unverified.', fontsize=6)
stem = FIG / 'Williams_\u7ec6\u80de\u6bd4\u4f8b\u53caGDF15\u7ec4\u6210\u6821\u6b63_AC_20261008'
save_npj(fig, str(stem), 180, 112, 600)
plt.close(fig)
fig = plt.figure(figsize=(82 * MM, 112 * MM))
heatmap(fig.add_axes([0.34, 0.17, 0.43, 0.66]), fig.add_axes([0.795, 0.17, 0.025, 0.66]))
fig.text(0.06, 0.92, 'A', fontsize=12, fontweight='bold')
fig.text(0.34, 0.095, '13 healthy / 5 PD sample groups', fontsize=6)
fig.text(0.34, 0.055, 'Exact rank tests; * FDR < 0.05', fontsize=6)
fig.text(0.1, 0.022, 'Numeric repeats pooled; participant linkage unverified', fontsize=5.5)
save_npj(fig, str(FIG / 'Williams_A_\u7ec6\u80de\u6bd4\u4f8b\u53d8\u5316_20261008'), 82, 112, 600)
plt.close(fig)
fig = plt.figure(figsize=(100 * MM, 78 * MM))
forest(fig.add_axes([0.31, 0.31, 0.64, 0.5]))
fig.text(0.06, 0.92, 'C', fontsize=12, fontweight='bold')
fig.text(0.31, 0.06, '13 healthy / 5 PD sample groups; 95% CI', fontsize=6)
fig.text(0.12, 0.024, 'Numeric repeats pooled; participant linkage unverified', fontsize=5.5)
save_npj(fig, str(FIG / 'Williams_C_GDF15\u6821\u6b63\u524d\u540e_20261008'), 100, 78, 600)
plt.close(fig)
meta = dict(panels=['A', 'C'], removed_panel='B', width_mm=180, height_mm=112, dpi=600, figure_source_tables=['06_Williams_cell_fraction_group_tests.csv', '07_Williams_GDF15_composition_models.csv'], analysis='Observed single-cell composition and synthetic tissue pseudobulk; not BisqueRNA')
(SD / '14_figure_manifest.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')
print('[DONE] A/C combined and individual panels: PDF + 600 dpi PNG')
