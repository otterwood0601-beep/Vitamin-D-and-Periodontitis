from __future__ import annotations
import os
import sys
import numpy as np
import pandas as pd
from scipy import sparse
from scipy.io import mmwrite
import anndata as ad
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gingiva_reference import H5AD, BROAD_ORDER, broad_cell_type
DER = 'E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\data_derived\\D11_deconvolution'
AUDIT = os.path.join(DER, 'D11_marker_gene_audit.csv')
OUT_MTX = 'C:\\wb_links\\dlc_derived\\D11_deconvolution\\D11_Bisque_gingiva_sc_counts.mtx'
OUT_META = os.path.join(DER, 'D11_Bisque_gingiva_sc_metadata.csv')
OUT_GENES = os.path.join(DER, 'D11_Bisque_gingiva_sc_genes.txt')
OUT_QC = os.path.join(DER, 'D11_Bisque_reference_QC.csv')
os.makedirs(DER, exist_ok=True)
markers = pd.read_csv(AUDIT)['gene'].dropna().astype(str).drop_duplicates().tolist()
a = ad.read_h5ad(H5AD, backed='r')
obs = a.obs[['donor_id', 'cell_type', 'tissue', 'Study']].copy()
if set(obs['tissue'].astype(str)) != {'gingiva'}:
    raise ValueError('Reference contains non-gingiva tissue')
obs['cellType'] = obs['cell_type'].map(broad_cell_type)
keep = obs['cellType'].isin(BROAD_ORDER)
obs = obs.loc[keep].copy()
rng = np.random.default_rng(20260914)
chosen = []
for _, idx in obs.groupby('donor_id', observed=True).indices.items():
    idx = np.asarray(idx)
    chosen.extend(rng.choice(idx, size=min(len(idx), 1000), replace=False))
chosen = np.sort(np.asarray(chosen, dtype=int))
obs = obs.iloc[chosen].copy()
v = a.raw.var.reset_index().rename(columns={a.raw.var.index.name or 'index': 'ensembl'})
v['symbol'] = v['feature_name'].astype(str)
v = v.drop_duplicates('symbol')
hit = v[v['symbol'].isin(markers)].copy().sort_values('symbol')
genes = hit['symbol'].tolist()
gidx = hit.index.to_numpy()
if len(genes) < 80:
    raise ValueError(f'Only {len(genes)} marker genes found in the gingiva reference')
raw_sub = a.raw.X[chosen, :]
if not sparse.issparse(raw_sub):
    raw_sub = sparse.csr_matrix(raw_sub)
raw_sub = raw_sub.tocsr()
selected = raw_sub[:, gidx].tocsr()
lib = np.asarray(raw_sub.sum(axis=1)).ravel()
selected_sum = np.asarray(selected.sum(axis=1)).ravel()
remainder = np.maximum(lib - selected_sum, 0)
mat = sparse.vstack([selected.T, sparse.csr_matrix(remainder.reshape(1, -1))], format='csr')
mmwrite(OUT_MTX, mat, field='integer')
pd.DataFrame({'cell_id': obs.index.astype(str), 'SubjectName': obs['donor_id'].astype(str).to_numpy(), 'cellType': obs['cellType'].astype(str).to_numpy(), 'Study': obs['Study'].astype(str).to_numpy()}).to_csv(OUT_META, index=False)
with open(OUT_GENES, 'w', encoding='utf-8') as f:
    f.write('\n'.join(genes + ['__OTHER__']) + '\n')
qc = obs.groupby(['donor_id', 'cellType'], observed=True).size().rename('n_cells').reset_index()
qc.to_csv(OUT_QC, index=False)
print(f'Prepared {mat.shape[1]} gingival cells, {len(qc.donor_id.unique())} donors, {len(genes)} marker genes + library-size remainder')
print(obs['cellType'].value_counts().reindex(BROAD_ORDER, fill_value=0).to_string())
a.file.close()
