from __future__ import annotations
import os
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from adjustText import adjust_text
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from style_npj import set_npj_style, save_npj, NPJ_CASE, NPJ_CTRL, MM
set_npj_style()
DER = 'E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\data_derived\\D11_deconvolution'
OUT = 'E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\\u7b2c11\u9879_bulk\u7ec6\u80de\u7ec4\u6210\u53bb\u5377\u79ef'
os.makedirs(OUT, exist_ok=True)
tests = pd.read_csv(os.path.join(DER, 'D11_Bisque_cross_cohort_group_tests.csv'))
gdf = pd.read_csv(os.path.join(DER, 'D11_Bisque_cross_cohort_GDF15_models.csv'))
order = ['Epithelial', 'Fibroblast', 'B/Plasma', 'Neutrophil', 'Mast', 'T/NK', 'Myeloid/DC', 'Endothelial', 'Mural', 'Neural/Melanocyte']
datasets = ['GSE223924', 'GSE173078']
piv = tests.pivot(index='cell_type', columns='dataset', values='difference_PD_minus_H').reindex(order)[datasets]
fdr = tests.pivot(index='cell_type', columns='dataset', values='wilcox_FDR').reindex(order)[datasets]
concordance = pd.DataFrame({'cell_type': order, 'GSE223924_PD_minus_H': piv['GSE223924'].to_numpy(), 'GSE173078_PD_minus_H': piv['GSE173078'].to_numpy()})
concordance['direction_concordant'] = np.sign(concordance.iloc[:, 1]) == np.sign(concordance.iloc[:, 2])
concordance.to_csv(os.path.join(DER, 'D11_Bisque_cross_cohort_direction_concordance.csv'), index=False)
fig = plt.figure(figsize=(180 * MM, 142 * MM))
gs = fig.add_gridspec(2, 2, height_ratios=[1.15, 0.85], width_ratios=[1.05, 0.95], left=0.13, right=0.96, bottom=0.11, top=0.89, wspace=0.42, hspace=0.52)
ax = fig.add_subplot(gs[:, 0])
mat = piv.to_numpy()
vmax = np.nanmax(np.abs(mat)) * 1.05
im = ax.imshow(mat, cmap='RdBu_r', vmin=-vmax, vmax=vmax, aspect='auto')
ax.set_xticks([0, 1])
ax.set_xticklabels(datasets, rotation=25, ha='right')
ax.set_yticks(range(len(order)))
ax.set_yticklabels(order)
for i in range(len(order)):
    for j in range(2):
        star = '*' if fdr.iloc[i, j] < 0.05 else ''
        ax.text(j, i, f'{mat[i, j]:+.3f}{star}', ha='center', va='center', fontsize=6, color='white' if abs(mat[i, j]) > vmax * 0.55 else 'black')
cb = fig.colorbar(im, ax=ax, fraction=0.045, pad=0.025)
cb.set_label('Median fraction difference\n(PD \u2212 healthy)', fontsize=7)
cb.ax.tick_params(labelsize=6)
ax.set_title('BisqueRNA cell-composition effects', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=.35'))
fig.text(0.045, 0.94, 'A', fontsize=12, fontweight='bold')
ax = fig.add_subplot(gs[0, 1])
texts = []
for _, r in concordance.iterrows():
    color = '#7E5AA7' if r.direction_concordant else '#8F8F8F'
    ax.scatter(r.GSE223924_PD_minus_H, r.GSE173078_PD_minus_H, s=23, color=color, edgecolor='black', linewidth=0.35, zorder=3)
    texts.append(ax.text(r.GSE223924_PD_minus_H, r.GSE173078_PD_minus_H, r.cell_type, fontsize=5.2))
ax.axhline(0, color='black', lw=0.5)
ax.axvline(0, color='black', lw=0.5)
limx = max(abs(concordance.GSE223924_PD_minus_H.min()), abs(concordance.GSE223924_PD_minus_H.max())) * 1.2
limy = max(abs(concordance.GSE173078_PD_minus_H.min()), abs(concordance.GSE173078_PD_minus_H.max())) * 1.2
ax.set_xlim(-limx, limx)
ax.set_ylim(-limy, limy)
adjust_text(texts, ax=ax, expand=(1.08, 1.18), force_text=(0.25, 0.45), force_points=(0.2, 0.35), arrowprops=dict(arrowstyle='-', color='#777777', lw=0.35))
ax.set_xlabel('GSE223924 PD \u2212 healthy')
ax.set_ylabel('GSE173078 PD \u2212 healthy')
ax.text(0.04, 0.94, f'8/10 directions concordant', transform=ax.transAxes, va='top', fontsize=6.5)
ax.set_title('Independent gingiva cohorts', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=.35'))
ax.text(-0.26, 1.14, 'B', transform=ax.transAxes, fontsize=12, fontweight='bold')
ax = fig.add_subplot(gs[1, 1])
rows = []
for ds in datasets:
    for model in ['unadjusted', 'composition_adjusted']:
        rows.append(gdf[(gdf.dataset == ds) & (gdf.model == model)].iloc[0])
y = np.arange(len(rows))[::-1]
for yy, r in zip(y, rows):
    color = '#8F8F8F' if r.model == 'unadjusted' else '#7E5AA7'
    ax.errorbar(r.PD_beta, yy, xerr=[[r.PD_beta - r.PD_CI_low], [r.PD_CI_high - r.PD_beta]], fmt='o', ms=4, color=color, ecolor=color, elinewidth=1, capsize=2)
ax.axvline(0, color='black', lw=0.6, ls='--')
ax.set_yticks(y)
ax.set_yticklabels([f"{r.dataset} | {('raw' if r.model == 'unadjusted' else 'composition-adjusted')}" for r in rows], fontsize=6)
ax.set_xlabel('PD coefficient for log2(CPM+0.5) GDF15')
ax.set_title('GDF15 after composition adjustment', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=.35'))
ax.text(-0.05, 1.12, 'C', transform=ax.transAxes, fontsize=12, fontweight='bold')
save_npj(fig, os.path.join(OUT, '\u7b2c11\u9879_BisqueRNA_\u7259\u9f88\u53cc\u961f\u5217\u6c47\u603b_20260914'), 180, 142, 600)
print(concordance.to_string(index=False))
print(gdf.to_string(index=False))
