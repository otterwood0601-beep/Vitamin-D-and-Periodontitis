from pathlib import Path
import hashlib, json
import fitz
import pandas as pd
import numpy as np
from scipy.stats import fisher_exact
root = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\P3_WGCNA_Williams_20261008_RAWP')
old = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\P3_WGCNA_Williams_20261008')
fig = root / '\u56fe'
sd = root / '\u5176\u4ed6/source_data'
qa = root / '\u5176\u4ed6/QA'
render = qa / 'rendered'
render.mkdir(exist_ok=True)
files = [fig / f'P3_{a}_WGCNA_RAWP.pdf' for a in ['A', 'B', 'B2', 'C', 'D']]
out = fitz.open()
for f in files + [old / '\u56fe/WGCNA_diagnostics.pdf']:
    with fitz.open(f) as d:
        out.insert_pdf(d)
out.save(fig / 'P3_A-D_WGCNA_RAWP_complete.pdf', garbage=4, deflate=True)
out.close()
report = {'pages': [], 'checks': {}}
with fitz.open(fig / 'P3_A-D_WGCNA_RAWP_complete.pdf') as d:
    for i, p in enumerate(d):
        p.get_pixmap(matrix=fitz.Matrix(2.5, 2.5), alpha=False).save(render / f'page_{i + 1}.png')
        fonts = [{'name': f[3], 'embedded': bool(d.extract_font(f[0])[3])} for f in p.get_fonts()]
        outside = []
        for b in p.get_text('dict')['blocks']:
            for l in b.get('lines', []):
                for s in l['spans']:
                    if not p.rect.contains(fitz.Rect(s['bbox'])):
                        outside.append(s['text'])
        text = p.get_text()
        report['pages'].append({'page': i + 1, 'fonts': fonts, 'text_outside_page': outside, 'no_adjusted_P_labels': not any((x in text.lower() for x in ['fdr', 'padj', 'p.adjust', 'p.adj']))})
checks = report['checks']
checks['all_fonts_embedded'] = all((f['embedded'] for p in report['pages'] for f in p['fonts']))
checks['no_off_page_text'] = all((not p['text_outside_page'] for p in report['pages']))
checks['no_adjusted_P_labels'] = all((p['no_adjusted_P_labels'] for p in report['pages']))
mem = pd.read_csv(sd / '05_WGCNA_gene_membership.csv')
om = pd.read_csv(old / '\u5176\u4ed6/source_data/05_WGCNA_gene_membership.csv')
checks['WGCNA_membership_unchanged'] = mem.equals(om)
shared = pd.read_csv(sd / '08_A_shared_gene_effects_RAWP.csv')
sets = pd.read_csv(sd / '09_B_input_VD_signatures_RAWP.csv')
checks['VD_signature_rawP_selection'] = all((set(sets.loc[sets.signature.eq(s), 'gene']) == set(shared.loc[shared.p_vd.lt(0.05) & (shared.lfc_vd.gt(0) if s == 'VD_UP' else shared.lfc_vd.lt(0)), 'gene']) for s in ['VD_UP', 'VD_DOWN']))
ora = pd.read_csv(sd / '12_D_Williams_KO_module_Fisher_RAWP.csv')
tested = pd.read_csv(sd / '12_D_KO_tested_genes_and_rawP_selection.csv')
checks['KO_gene_rawP_selection'] = (tested.selected == tested.raw_P.lt(0.05)).all().item()
results = []
for r in ora.itertuples():
    k, K, M, N = (r.overlap, r.KO_significant, r.module_tested, r.background)
    p = fisher_exact([[k, K - k], [M - k, N - M - K + k]], alternative='greater').pvalue
    results.append(np.isclose(p, r.p, rtol=1e-09, atol=1e-12))
checks['Fisher_rawP_independently_recomputed'] = all(results)
checks['KO_counts_match_selection'] = all((r.KO_significant == int(tested.loc[tested.state.eq(r.state), 'selected'].sum()) for r in ora.itertuples()))
mc = pd.read_csv(sd / '10_C_module_GSEA_RAWP.csv')
direction = pd.read_csv(sd / '11_C_direction_summary_RAWP.csv')
checks['C_rawP_significance'] = np.array_equal(direction.nominal_reverse, (direction.NES_disease * direction.NES_VD < 0) & direction.P_disease.lt(0.05) & direction.P_VD.lt(0.05))
before = json.loads((qa / 'previous_version_pdf_SHA256.json').read_text(encoding='utf-8-sig'))
checks['previous_version_unchanged'] = all((hashlib.sha256(Path(p).read_bytes()).hexdigest().upper() == h for p, h in before.items()))
checks['no_adjusted_P_columns_new_tables'] = not any((any((x in c.lower() for x in ['fdr', 'padj', 'p.adj'])) for f in sd.glob('*.csv') for c in pd.read_csv(f, nrows=0).columns))
with open(qa / 'independent_QA_RAWP.json', 'w', encoding='utf-8') as f:
    json.dump(report, f, indent=2, ensure_ascii=False)
print(json.dumps(checks, ensure_ascii=False, indent=2))
print(direction.loc[direction.nominal_reverse, ['module', 'NES_disease', 'P_disease', 'NES_VD', 'P_VD']].to_string(index=False))
print(ora.loc[ora.p.lt(0.05), ['state', 'module', 'overlap', 'KO_significant', 'p']].to_string(index=False))
