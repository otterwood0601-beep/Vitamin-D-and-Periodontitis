cat('[6] Draw A-D plus B2, keeping previous geometry and palette\n'); flush.console()
TH <- theme_classic(base_size=8,base_family='Arial')+
 theme(axis.text=element_text(size=7,colour='black'),axis.title=element_text(size=8),
 axis.line=element_line(linewidth=0.4),legend.text=element_text(size=6.5),
 legend.title=element_text(size=7),plot.title=element_text(size=8,face='bold'),
 plot.subtitle=element_text(size=6.5),plot.tag=element_text(face='bold',size=12),
 plot.tag.position='topleft',plot.margin=margin(7,8,6,6))
ct <- cor.test(shared$lfc_disease,shared$lfc_vd,method='spearman',exact=FALSE)
shared[,vd_class := fifelse(p_vd<0.05&lfc_vd>0.5,'VD up',
 fifelse(p_vd<0.05&lfc_vd< -0.5,'VD down','Other'))]
shared[is.na(vd_class),vd_class:='Other']
labelgenes <- c('GDF15','MAPK1','MAPK3','MMP1','MMP3','MMP9','MMP13')
labsA <- shared[gene%in%labelgenes]
labsA[,label := paste0(gene,' [',module,']')]
pA <- ggplot(shared,aes(lfc_disease,lfc_vd))+
 geom_hline(yintercept=0,linetype='dashed',linewidth=.3,colour='grey50')+
 geom_vline(xintercept=0,linetype='dashed',linewidth=.3,colour='grey50')+
 geom_point(aes(colour=vd_class),size=.5,alpha=.35)+
 geom_point(data=shared[gene=='GDF15'],shape=17,size=2,colour='#B2182B')+
 geom_text_repel(data=labsA,aes(label=label),size=2.1,family='Arial',seed=20261008,
 max.overlaps=Inf,box.padding=.35,min.segment.length=0,segment.size=.2)+
 scale_colour_manual(values=c('VD up'='#B2182B','VD down'='#2166AC','Other'='grey70'),name=NULL)+
 labs(x='Periodontitis vs healthy (log2 FC)',y='Vitamin D3 vs control (log2 FC)',
 title=sprintf('Disease vs vitamin-D signature (Spearman r = %.3f)',ct$estimate),
 subtitle='Williams fibroblasts; VD colors: raw P < 0.05, |log2 FC| > 0.5\nGDF15 fails expression filter: no disease estimate',tag='A')+TH
gb[,label:=sprintf('P=%.2g; n=%d',pval,size)]
pB <- ggplot(gb,aes(pathway,NES,fill=pathway))+geom_col(width=.6,colour='black',linewidth=.3)+
 geom_hline(yintercept=0,linewidth=.3)+
 geom_text(aes(label=label),hjust=ifelse(gb$NES>=0,-.05,1.05),size=2.1,family='Arial')+
 scale_fill_manual(values=c(VD_UP='#B2182B',VD_DOWN='#2166AC'),guide='none')+
 scale_y_continuous(expand=expansion(mult=c(.15,.55)))+coord_flip(clip='off')+
 labs(x=NULL,y='Normalized enrichment score (NES)',title='Vitamin-D signatures in periodontitis',
 subtitle='Signatures: VD gene raw P < 0.05 (uncorrected)',tag='B')+TH
running <- function(s,rk,name){
 N<-length(rk); hit<-names(rk)%in%s; w<-abs(rk)
 es<-cumsum(ifelse(hit,w/sum(w[hit]),-1/sum(!hit)))
 data.table(rank=seq_len(N),ES=es,signature=name,hit=hit)
}
run <- rbindlist(lapply(names(vs),function(n)running(vs[[n]],rkD,n)))
pB2 <- ggplot(run,aes(rank,ES,colour=signature))+
 geom_hline(yintercept=0,colour='grey50',linetype='dashed',linewidth=.3)+
 geom_line(linewidth=.5)+facet_wrap(~signature,nrow=1)+
 scale_x_continuous(breaks=c(0,5000,10000),labels=c('0','5k','10k'),expand=expansion(mult=c(.02,.04)))+
 scale_colour_manual(values=c(VD_UP='#B2182B',VD_DOWN='#2166AC'),guide='none')+
 labs(x='Disease ranked genes (up to down)',y='Running enrichment score',
 title='Vitamin-D signature GSEA curves',tag='B2')+TH
mc[,star:=fifelse(pval<.001,'***',fifelse(pval<.01,'**',fifelse(pval<.05,'*','')))]
mc[,label:=sprintf('%.2f%s',NES,star)]
mc[,dataset:=factor(dataset,levels=c('Periodontitis','Vitamin D3'))]
module_order <- mdirection[order(NES_disease)]$module
mc[,pathway:=factor(pathway,levels=module_order)]
pC <- ggplot(mc,aes(dataset,pathway,fill=NES))+geom_tile(colour='white',linewidth=.6)+
 geom_text(aes(label=label),size=2.3,family='Arial')+
 scale_fill_gradient2(low='#2166AC',mid='#F7F7F7',high='#B2182B',midpoint=0,name='GSEA NES')+
 labs(x=NULL,y='WGCNA module',title='WGCNA modules: disease vs vitamin-D direction',
 subtitle='Stars = GSEA raw P; grey excluded (uncorrected)',tag='C')+TH+
 theme(axis.text.x=element_text(angle=20,hjust=1))
ora[,module:=factor(module,levels=rev(module_order))]
ora[,plot_or:=pmin(OR,10)]
ora[!is.finite(plot_or),plot_or:=0]
pD <- ggplot(ora,aes(module,-log10(pmax(p,1e-300)),fill=plot_or))+
 geom_col(width=.62,colour='black',linewidth=.3)+
 geom_hline(yintercept=-log10(.05),linetype='dashed',colour='grey40',linewidth=.35)+
 facet_wrap(~state,nrow=1)+scale_fill_viridis_c(name='Odds ratio\n(capped at 10)',option='viridis')+
 coord_flip()+labs(x=NULL,y='-log10 Fisher raw P',
 title='GDF15 virtual-KO affected genes vs WGCNA modules',
 subtitle='Williams only; gene raw P < 0.05; target excluded',tag='D')+TH
if(all(ora$p==1)) {
 ann <- unique(ora[,.(state,KO_significant,background)])
 ann[,module:=factor(module_order[ceiling(length(module_order)/2)],levels=rev(module_order))]
 ann[,label:=sprintf('No enriched modules\n(all raw P = 1)\nKO genes: %d / %d tested',KO_significant,background)]
 pD <- pD+geom_text(data=ann,aes(x=module,y=.7,label=label),inherit.aes=FALSE,size=2.1,family='Arial')
}
plots <- list(A=pA,B=pB,B2=pB2,C=pC,D=pD)
dims <- list(A=c(4,3.6),B=c(3.4,2.2),B2=c(4.2,2.4),C=c(4.6,max(2.8,.20*length(sets)+1.5)),D=c(4.4,max(2.6,.18*length(sets)+1.35)))
for(n in names(plots)) {
 ggsave(file.path(FIG,paste0('P3_',n,'_WGCNA_RAWP.pdf')),plots[[n]],width=dims[[n]][1],height=dims[[n]][2],device=cairo_pdf)
 ggsave(file.path(FIG,paste0('P3_',n,'_WGCNA_RAWP.png')),plots[[n]],width=dims[[n]][1],height=dims[[n]][2],dpi=600,device=grDevices::png,type='cairo')
}
