options(stringsAsFactors=FALSE)
.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fgsea);library(ggplot2);library(ggrepel);library(jsonlite)})
set.seed(20261008)
OLD <- 'C:/wb_links/p3_wgcna_20261008'
SD <- 'C:/wb_links/p3_rawp_data_20261008'
FIG <- 'C:/wb_links/p3_rawp_fig_20261008'
QA <- 'C:/wb_links/p3_rawp_qa_20261008'
for(d in c(SD,FIG,QA)) dir.create(d,recursive=TRUE,showWarnings=FALSE)
write_table <- function(x,name) fwrite(x,file.path(SD,paste0(name,'.csv')))
drop_adjusted <- function(x) { 
 bad <- grep('fdr|padj|p[.]adj|adj[.]P',names(x),ignore.case=TRUE,value=TRUE)
 if(length(bad)) x[,(bad):=NULL]
 x
}
cat('[1] Reuse saved Williams WGCNA modules and disease estimates\n');flush.console()
member <- fread(file.path(OLD,'data','05_WGCNA_gene_membership.csv'))
modules <- setdiff(sort(unique(member$module)),'grey')
shared <- drop_adjusted(fread(file.path(OLD,'data','08_A_shared_gene_effects.csv')))
write_table(shared,'08_A_shared_gene_effects_RAWP')
write_table(member,'05_WGCNA_gene_membership')
manifest <- fread(file.path(OLD,'data','01_sample_group_manifest.csv'))
write_table(manifest,'01_sample_group_manifest')
write_table(drop_adjusted(fread(file.path(OLD,'data','02_Williams_group_pseudobulk_DE.csv'))),'02_Williams_group_pseudobulk_DE_RAWP')
write_table(drop_adjusted(fread(file.path(OLD,'data','07_module_disease_association.csv'))),'07_module_disease_association_RAWP')
write_table(drop_adjusted(fread(file.path(OLD,'data','13_GDF15_ERK_MMP_VDR_results.csv'))),'13_GDF15_ERK_MMP_VDR_results_RAWP')
write_table(fread(file.path(OLD,'data','14_target_QC_and_exclusion_reasons.csv')),'14_target_QC_and_exclusion_reasons')
rkD <- sort(setNames(shared$t,shared$gene),decreasing=TRUE)
vs <- list(VD_UP=shared[is.finite(p_vd)&p_vd<.05&lfc_vd>0]$gene,
 VD_DOWN=shared[is.finite(p_vd)&p_vd<.05&lfc_vd<0]$gene)
stopifnot(all(lengths(vs)>=15),!anyDuplicated(names(rkD)))
write_table(rbindlist(lapply(names(vs),function(s)data.table(signature=s,gene=vs[[s]]))),
 '09_B_input_VD_signatures_RAWP')
cat('[2] Recompute B/B2 using VD gene raw P < 0.05, not previous selected genes\n');flush.console()
if('--render-only'%in%commandArgs(TRUE)) {
 gb <- fread(file.path(SD,'09_B_VD_signature_GSEA_on_disease_RAWP.csv'))
} else {
 gb <- fgseaMultilevel(pathways=vs,stats=rkD,minSize=15,maxSize=5000,eps=0,nPermSimple=10000,nproc=1)
 gb <- drop_adjusted(gb)
 gb[,leadingEdge:=vapply(leadingEdge,paste,collapse=';',FUN.VALUE=character(1))]
 write_table(gb,'09_B_VD_signature_GSEA_on_disease_RAWP')
}
cat('[3] Use the actual raw P from unchanged module GSEA for C\n');flush.console()
mc <- drop_adjusted(fread(file.path(OLD,'data','10_C_module_GSEA.csv')))
write_table(mc,'10_C_module_GSEA_RAWP')
mdirection <- merge(mc[dataset=='Periodontitis',.(module=pathway,NES_disease=NES,P_disease=pval,size)],
 mc[dataset=='Vitamin D3',.(module=pathway,NES_VD=NES,P_VD=pval)],by='module')
mdirection[,opposite_direction:=NES_disease*NES_VD<0]
mdirection[,nominal_reverse:=opposite_direction & P_disease<.05 & P_VD<.05]
write_table(mdirection,'11_C_direction_summary_RAWP')
sets <- split(shared[module%in%mdirection$module]$gene,shared[module%in%mdirection$module]$module)
cat('[4] Recompute D from KO gene p.value < 0.05; Fisher raw P, no correction\n');flush.console()
KOROOT <- 'C:/wb_links/williams_ko_20260924'
ko_selected <- list()
ora <- rbindlist(lapply(c('Vascular','Immune'),function(state){
 ko <- fread(file.path(KOROOT,paste0('27_scTenifoldKnk_GDF15_',state,'_differential_regulation.csv')))
 stopifnot('p.value'%in%names(ko))
 universe <- intersect(setdiff(ko$gene,'GDF15'),member$gene)
 sig <- intersect(ko[is.finite(p.value)&p.value<.05]$gene,universe)
 ko_selected[[state]] <<- ko[gene%in%universe,.(state, gene,raw_P=p.value,selected=p.value<.05)]
 rbindlist(lapply(modules,function(m){
 g <- intersect(member[module==m]$gene,universe)
 N<-length(universe); M<-length(g); K<-length(sig); k<-length(intersect(g,sig))
 ft <- fisher.test(matrix(c(k,K-k,M-k,N-M-K+k),nrow=2),alternative='greater')
 data.table(state,module=m,background=N,module_tested=M,KO_significant=K,
 overlap=k,overlap_genes=paste(intersect(g,sig),collapse=';'),OR=unname(ft$estimate),p=ft$p.value)
 }))
}))
ora[,nominal_significant:=p<.05]
write_table(ora,'12_D_Williams_KO_module_Fisher_RAWP')
write_table(rbindlist(ko_selected),'12_D_KO_tested_genes_and_rawP_selection')
cat('[5] Reuse prior A-D drawing code with auditable raw-P bindings\n');flush.console()
source_path <- 'C:/wb_links/p3_wgcna_scripts_20261008/redo_P3_WGCNA.R'
lines <- readLines(source_path,warn=FALSE)
start <- grep("^cat\\('\\[6\\]",lines)
end <- grep('^# Diagnostics:',lines)
stopifnot(length(start)==1,length(end)==1)
body <- paste(lines[start:(end-1)],collapse='\n')
replace_exact <- function(old,new) {
 if(!grepl(old,body,fixed=TRUE)) stop(paste('Expected plot binding missing:',old))
 body <<- gsub(old,new,body,fixed=TRUE)
}
replace_exact('fdr_vd<0.05','p_vd<0.05')
replace_exact('padj','pval')
replace_exact('FDR = %.2g; n = %d','P=%.2g; n=%d')
replace_exact('Stars = gene-set GSEA BH FDR; grey excluded','Stars = GSEA raw P; grey excluded (uncorrected)')
replace_exact('-log10(pmax(fdr,1e-300))','-log10(pmax(p,1e-300))')
replace_exact('-log10 Fisher BH FDR','-log10 Fisher raw P')
replace_exact('Williams only; FDR < 0.05; target excluded; tested-gene universe',
 'Williams only; gene raw P < 0.05; target excluded')
replace_exact('ora$fdr==1','ora$p==1')
replace_exact('(all BH FDR = 1)','(all raw P = 1)')
replace_exact('_WGCNA.pdf','_WGCNA_RAWP.pdf')
replace_exact('_WGCNA.png','_WGCNA_RAWP.png')
replace_exact("subtitle='Positive NES = enriched among disease-up genes'",
 "subtitle='Signatures: VD gene raw P < 0.05 (uncorrected)'")
replace_exact('Williams gingival fibroblasts; WGCNA membership shown\\nGDF15 fails expression filter: no disease estimate',
 'Williams fibroblasts; VD colors: raw P < 0.05, |log2 FC| > 0.5\\nGDF15 fails expression filter: no disease estimate')
if(grepl('fdr|padj|p[.]adj',body,ignore.case=TRUE)) stop('Adjusted-P reference remains in drawing code')
writeLines(body,file.path(QA,'reused_plot_code_RAWP.R'))
eval(parse(text=body))
summary <- list(created_at=format(Sys.time()),criterion='All displayed P and significance thresholds use raw unadjusted P; threshold 0.05',
 WGCNA_reused=TRUE,module_count=length(modules),input='Williams gingival fibroblasts + Zhang/GSE212728 gingival fibroblast D3 cultures',
 n_shared_genes=nrow(shared),sample_groups=nrow(manifest),
 participant_caveat='PD161/b and PD164/b/c conservatively pooled by numeric ID; patient linkage not confirmed. Exploratory only.',
 signature_GSEA=gb[,.(pathway,NES,pval,size)],
 nominal_reverse_modules=mdirection[nominal_reverse==TRUE],
 KO_selected=unique(ora[,.(state,KO_significant,background)]),
 KO_nominal_enrichment=ora[nominal_significant==TRUE],
 target_results=drop_adjusted(fread(file.path(SD,'13_GDF15_ERK_MMP_VDR_results_RAWP.csv')))[,.(gene,module,lfc_disease,p_disease,lfc_vd,p_vd)],
 limitations='No multiple-testing correction. Nominal P<0.05 is not corrected significance, independent validation or causal proof. Zhang has one fibroblast donor. KO GDF15 detection sparse; Immune target previously forced into input.',
 previous_version_untouched=TRUE,
 sessionInfo=paste(capture.output(sessionInfo()),collapse='\n'))
writeLines(toJSON(summary,pretty=TRUE,auto_unbox=TRUE,digits=10,na='null'),file.path(QA,'analysis_summary_RAWP.json'))
cat('[DONE] Raw-P A-D/B2 completed\n');flush.console()
