options(stringsAsFactors=FALSE)
.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5', .libPaths()))
suppressPackageStartupMessages({
 library(SeuratObject); library(Matrix); library(data.table); library(edgeR)
 library(WGCNA); library(fgsea); library(ggplot2); library(ggrepel); library(jsonlite)
})
set.seed(20261008)
ROOT <- 'C:/wb_links/p3_wgcna_20261008'
SD <- file.path(ROOT,'data'); FIG <- file.path(ROOT,'figures'); QA <- file.path(ROOT,'qa')
for(d in c(SD,FIG,QA)) dir.create(d,recursive=TRUE,showWarnings=FALSE)
save_table <- function(x,n) fwrite(as.data.table(x),file.path(SD,paste0(n,'.csv')))
RENDER_ONLY <- '--render-only' %in% commandArgs(trailingOnly=TRUE)

if(!RENDER_ONLY) {
cat('[1] Williams fibroblast raw counts\n'); flush.console()
fb <- readRDS('C:/wb_links/dlc_data/outputs/fb_seurat_annotated.rds')
md <- as.data.table(fb[[]],keep.rownames='barcode')
md <- md[Study=='Williams' & disease %in% c('normal','periodontitis')]

md[, participant_group := sub('[a-z]+$','',sample_id)]
manifest <- md[,.(n_cells=.N,sample_ids=paste(sort(unique(sample_id)),collapse=';'),
 disease=unique(disease),GEO_ids=paste(sort(unique(donor_id)),collapse=';')),by=participant_group]
setorder(manifest,disease,participant_group)
manifest[,grouping_note := fifelse(grepl(';',sample_ids),
 'Conservative pooling of same numeric ID; patient linkage not independently verified',
 'Single available sample ID')]
save_table(manifest,'01_sample_group_manifest')
if(any(manifest$n_cells<20)) stop('A participant group has fewer than 20 fibroblasts; manual QC review required')
cnt <- GetAssayData(fb,layer='counts')[,md$barcode,drop=FALSE]
pb <- sapply(manifest$participant_group,function(g) Matrix::rowSums(cnt[,md[participant_group==g]$barcode,drop=FALSE]))
rm(fb,cnt); gc()
stopifnot(ncol(pb)>=15,identical(colnames(pb),manifest$participant_group))
group <- factor(manifest$disease,levels=c('normal','periodontitis'))
design <- model.matrix(~group)
dge <- DGEList(pb)
keep <- filterByExpr(dge,design=design)
dge <- calcNormFactors(dge[keep,,keep.lib.sizes=FALSE],method='TMM')
lcpm <- cpm(dge,log=TRUE,prior.count=2)
vv <- voom(dge,design,plot=FALSE)
fit <- eBayes(lmFit(vv,design),robust=TRUE)
de <- as.data.table(topTable(fit,coef=2,number=Inf,sort.by='none'),keep.rownames='gene')
setnames(de,c('logFC','P.Value','adj.P.Val'),c('lfc_disease','p_disease','fdr_disease'))
save_table(de,'02_Williams_group_pseudobulk_DE')
save_table(cbind(data.table(gene=rownames(lcpm)),as.data.table(lcpm)),'03_TMM_logCPM')
cat('[2] WGCNA: expression filter, top 5000 variance genes; no DEG selection\n'); flush.console()
variance <- apply(lcpm,1,var)
genes <- names(sort(variance[is.finite(variance)&variance>0],decreasing=TRUE))[seq_len(min(5000,sum(variance>0)))]
dat <- t(lcpm[genes,,drop=FALSE])
qc <- goodSamplesGenes(dat,verbose=0)
stopifnot(all(qc$goodSamples))
dat <- dat[,qc$goodGenes,drop=FALSE]
enableWGCNAThreads(nThreads=4)
powers <- c(1:10,seq(12,30,2))
sft <- pickSoftThreshold(dat,powerVector=powers,networkType='signed',
 corFnc='bicor',corOptions=list(use='p',maxPOutliers=0.05),verbose=2)
st <- as.data.table(sft$fitIndices)
st[,signed_R2 := -sign(slope)*SFT.R.sq]
goodp <- st[signed_R2>=0.8 & mean.k.>=1]$Power
power <- if(length(goodp)) min(goodp) else if(nrow(dat)<20) 18 else 16
save_table(st,'04_soft_threshold_scan')
cat('Samples/groups:',nrow(dat),'power:',power,'genes:',ncol(dat),'\n'); flush.console()
net <- blockwiseModules(dat,power=power,networkType='signed',TOMType='signed',
 corType='bicor',maxPOutliers=0.05,maxBlockSize=6000,minModuleSize=30,
 deepSplit=2,mergeCutHeight=0.25,pamRespectsDendro=TRUE,reassignThreshold=0,
 numericLabels=FALSE,saveTOMs=FALSE,nThreads=4,randomSeed=20261008,verbose=3)
member <- data.table(gene=colnames(dat),module=net$colors)
modules <- setdiff(sort(unique(member$module)),'grey')
if(!length(modules)) stop('WGCNA found no non-grey module; do not fabricate modules')
km <- as.data.table(signedKME(dat,net$MEs,corFnc='bicor',corOptions='use = "p", maxPOutliers = 0.05'))
member <- cbind(member,km)
save_table(member,'05_WGCNA_gene_membership')
save_table(cbind(manifest,as.data.table(net$MEs)),'06_module_eigengenes_by_group')
mt <- rbindlist(lapply(modules,function(m){
 y <- net$MEs[[paste0('ME',m)]]
 f <- lm(y~group)
 cfs <- summary(f)$coefficients
 data.table(module=m,n_genes=sum(member$module==m),effect_PD_minus_H=cfs[2,1],
 p=cfs[2,4],cor_disease=cor(y,as.numeric(group)-1))
}))
mt[,fdr := p.adjust(p,'BH')]
save_table(mt,'07_module_disease_association')
saveRDS(list(datExpr=dat,network=net,metadata=manifest,DE=de,soft_threshold=sft),file.path(SD,'WGCNA_checkpoint.rds'))
cat('[3] Zhang full original DESeq2 table and common-gene rankings\n'); flush.console()
vd <- fread('C:/wb_links/fig3_bulk/02_DESeq2_genome/11_DESeq2_D3_vs_ethanol_all_genes.csv')
vd <- vd[!is.na(gene_symbol)&nzchar(gene_symbol)]

setorder(vd,gene_symbol,-baseMean,gene_id)
vd <- unique(vd,by='gene_symbol')
vd <- vd[,.(gene=gene_symbol,lfc_vd=log2FoldChange,stat_vd=stat,p_vd=pvalue,fdr_vd=padj,baseMean)]
shared <- merge(de,vd,by='gene')
shared <- shared[is.finite(lfc_disease)&is.finite(lfc_vd)&is.finite(t)&is.finite(stat_vd)]
shared <- merge(shared,member[,.(gene,module)],by='gene',all.x=TRUE)
shared[is.na(module),module:='not_in_network']
shared[,quadrant := fifelse(lfc_disease>=0 & lfc_vd>=0,'PD up / VD up',
 fifelse(lfc_disease>=0 & lfc_vd<0,'PD up / VD down',
 fifelse(lfc_disease<0 & lfc_vd>=0,'PD down / VD up','PD down / VD down')))]
save_table(shared,'08_A_shared_gene_effects')
rkD <- sort(setNames(shared$t,shared$gene),decreasing=TRUE)
rkV <- sort(setNames(shared$stat_vd,shared$gene),decreasing=TRUE)
sets <- lapply(modules,function(m) member[module==m]$gene); names(sets)<-modules
sets <- lapply(sets,function(s) intersect(s,names(rkD)))
sets <- sets[lengths(sets)>=15]
cat('[4] GSEA; module heatmap uses NES, not gene-wise t-test\n'); flush.console()
gsea <- function(sets,rk) {
 if(anyDuplicated(names(rk))) stop('Duplicated ranking symbols')
 fgseaMultilevel(pathways=sets,stats=rk,minSize=15,maxSize=5000,eps=0,nPermSimple=10000,nproc=1)
}
vs <- list(VD_UP=vd[fdr_vd<0.05&lfc_vd>0]$gene,VD_DOWN=vd[fdr_vd<0.05&lfc_vd<0]$gene)
vs <- lapply(vs,function(s) intersect(s,names(rkD)))
gb <- gsea(vs,rkD)
gd <- gsea(sets,rkD); gv <- gsea(sets,rkV)
flat <- function(g) { z<-copy(g); if('leadingEdge'%in%names(z)) z[,leadingEdge:=vapply(leadingEdge,paste,collapse=';',FUN.VALUE=character(1))]; z }
save_table(flat(gb),'09_B_VD_signature_GSEA_on_disease')
gd[,dataset:='Periodontitis']; gv[,dataset:='Vitamin D3']
mc <- rbind(gd,gv)
save_table(flat(mc),'10_C_module_GSEA')
mdirection <- merge(gd[,.(module=pathway,NES_disease=NES,FDR_disease=padj,size)],
 gv[,.(module=pathway,NES_VD=NES,FDR_VD=padj)],by='module')
mdirection[,opposite_direction := NES_disease*NES_VD<0]
mdirection[,significant_reverse := opposite_direction & FDR_disease<0.05 & FDR_VD<0.05]
save_table(mdirection,'11_C_direction_summary')
cat('[5] Williams-only virtual-KO module enrichment, proper tested background\n'); flush.console()
KO_ROOT <- 'C:/wb_links/williams_ko_20260924'
ora <- rbindlist(lapply(c('Vascular','Immune'),function(state){
 ko <- fread(file.path(KO_ROOT,paste0('27_scTenifoldKnk_GDF15_',state,'_differential_regulation.csv')))
 universe <- intersect(setdiff(ko$gene,'GDF15'),member$gene)
 sig <- intersect(ko[is.finite(p.adj)&p.adj<0.05]$gene,universe)
 rbindlist(lapply(modules,function(m){
 g <- intersect(member[module==m]$gene,universe)
 N<-length(universe); M<-length(g); K<-length(sig); k<-length(intersect(g,sig))
 ft <- fisher.test(matrix(c(k,K-k,M-k,N-M-K+k),nrow=2),alternative='greater')
 data.table(state,module=m,background=N,module_tested=M,KO_significant=K,
 overlap=k,overlap_genes=paste(intersect(g,sig),collapse=';'),OR=unname(ft$estimate),p=ft$p.value)
 }))
}))
ora[,fdr:=p.adjust(p,'BH'),by=state]
save_table(ora,'12_D_Williams_KO_module_Fisher')
targets <- c('GDF15','MAPK3','MAPK1','MMP1','MMP3','MMP9','MMP13','VDR','CYP24A1')
target_table <- merge(data.table(gene=targets),merge(de,vd,by='gene',all=TRUE),by='gene',all.x=TRUE)
target_table <- merge(target_table,member,by='gene',all.x=TRUE)
target_table[is.na(module),module:='not_in_network']
save_table(target_table,'13_GDF15_ERK_MMP_VDR_results')
} else {
 shared <- fread(file.path(SD,'08_A_shared_gene_effects.csv'))
 gb <- fread(file.path(SD,'09_B_VD_signature_GSEA_on_disease.csv'))
 mc <- fread(file.path(SD,'10_C_module_GSEA.csv'))
 mdirection <- fread(file.path(SD,'11_C_direction_summary.csv'))
 ora <- fread(file.path(SD,'12_D_Williams_KO_module_Fisher.csv'))
 rkD <- sort(setNames(shared$t,shared$gene),decreasing=TRUE)
 vs <- list(VD_UP=shared[fdr_vd<.05&lfc_vd>0]$gene,VD_DOWN=shared[fdr_vd<.05&lfc_vd<0]$gene)
 sets <- split(shared[module%in%mdirection$module]$gene,shared[module%in%mdirection$module]$module)
}
cat('[6] Draw A-D plus B2, keeping previous geometry and palette\n'); flush.console()
TH <- theme_classic(base_size=8,base_family='Arial')+
 theme(axis.text=element_text(size=7,colour='black'),axis.title=element_text(size=8),
 axis.line=element_line(linewidth=0.4),legend.text=element_text(size=6.5),
 legend.title=element_text(size=7),plot.title=element_text(size=8,face='bold'),
 plot.subtitle=element_text(size=6.5),plot.tag=element_text(face='bold',size=12),
 plot.tag.position='topleft',plot.margin=margin(7,8,6,6))
ct <- cor.test(shared$lfc_disease,shared$lfc_vd,method='spearman',exact=FALSE)
shared[,vd_class := fifelse(fdr_vd<0.05&lfc_vd>0.5,'VD up',
 fifelse(fdr_vd<0.05&lfc_vd< -0.5,'VD down','Other'))]
shared[is.na(vd_class),vd_class:='Other']
labelgenes <- c('GDF15','MAPK1','MAPK3','MMP1','MMP3','MMP9','MMP13')
labsA <- shared[gene%in%labelgenes]
labsA[,label := paste0(gene,' [',module,']')]
pA <- ggplot(shared,aes(lfc_disease,lfc_vd))+
 geom_hline(yintercept=0,linetype='dashed',linewidth=.3,colour='grey50')+
 geom_vline(xintercept=0,linetype='dashed',linewidth=.3,colour='grey50')+
 geom_point(aes(colour=vd_class),size=.5,alpha=.35)+
 geom_point(data=shared[gene=='GDF15'],shape=17,size=2,colour='#B2182B')+
 geom_text_repel(data=labsA,aes(label=label),size=2.1,family='Arial',seed=20261008,
 max.overlaps=Inf,box.padding=.35,min.segment.length=0,segment.size=.2)+
 scale_colour_manual(values=c('VD up'='#B2182B','VD down'='#2166AC','Other'='grey70'),name=NULL)+
 labs(x='Periodontitis vs healthy (log2 FC)',y='Vitamin D3 vs control (log2 FC)',
 title=sprintf('Disease vs vitamin-D signature (Spearman r = %.3f)',ct$estimate),
 subtitle='Williams gingival fibroblasts; WGCNA membership shown\nGDF15 fails expression filter: no disease estimate',tag='A')+TH
gb[,label:=sprintf('FDR = %.2g; n = %d',padj,size)]
pB <- ggplot(gb,aes(pathway,NES,fill=pathway))+geom_col(width=.6,colour='black',linewidth=.3)+
 geom_hline(yintercept=0,linewidth=.3)+
 geom_text(aes(label=label),hjust=ifelse(gb$NES>=0,-.05,1.05),size=2.1,family='Arial')+
 scale_fill_manual(values=c(VD_UP='#B2182B',VD_DOWN='#2166AC'),guide='none')+
 scale_y_continuous(expand=expansion(mult=c(.15,.55)))+coord_flip(clip='off')+
 labs(x=NULL,y='Normalized enrichment score (NES)',title='Vitamin-D signatures in periodontitis',
 subtitle='Positive NES = enriched among disease-up genes',tag='B')+TH
running <- function(s,rk,name){
 N<-length(rk); hit<-names(rk)%in%s; w<-abs(rk)
 es<-cumsum(ifelse(hit,w/sum(w[hit]),-1/sum(!hit)))
 data.table(rank=seq_len(N),ES=es,signature=name,hit=hit)
}
run <- rbindlist(lapply(names(vs),function(n)running(vs[[n]],rkD,n)))
pB2 <- ggplot(run,aes(rank,ES,colour=signature))+
 geom_hline(yintercept=0,colour='grey50',linetype='dashed',linewidth=.3)+
 geom_line(linewidth=.5)+facet_wrap(~signature,nrow=1)+
 scale_x_continuous(breaks=c(0,5000,10000),labels=c('0','5k','10k'),expand=expansion(mult=c(.02,.04)))+
 scale_colour_manual(values=c(VD_UP='#B2182B',VD_DOWN='#2166AC'),guide='none')+
 labs(x='Disease ranked genes (up to down)',y='Running enrichment score',
 title='Vitamin-D signature GSEA curves',tag='B2')+TH
mc[,star:=fifelse(padj<.001,'***',fifelse(padj<.01,'**',fifelse(padj<.05,'*','')))]
mc[,label:=sprintf('%.2f%s',NES,star)]
mc[,dataset:=factor(dataset,levels=c('Periodontitis','Vitamin D3'))]
module_order <- mdirection[order(NES_disease)]$module
mc[,pathway:=factor(pathway,levels=module_order)]
pC <- ggplot(mc,aes(dataset,pathway,fill=NES))+geom_tile(colour='white',linewidth=.6)+
 geom_text(aes(label=label),size=2.3,family='Arial')+
 scale_fill_gradient2(low='#2166AC',mid='#F7F7F7',high='#B2182B',midpoint=0,name='GSEA NES')+
 labs(x=NULL,y='WGCNA module',title='WGCNA modules: disease vs vitamin-D direction',
 subtitle='Stars = gene-set GSEA BH FDR; grey excluded',tag='C')+TH+
 theme(axis.text.x=element_text(angle=20,hjust=1))
ora[,module:=factor(module,levels=rev(module_order))]
ora[,plot_or:=pmin(OR,10)]
ora[!is.finite(plot_or),plot_or:=0]
pD <- ggplot(ora,aes(module,-log10(pmax(fdr,1e-300)),fill=plot_or))+
 geom_col(width=.62,colour='black',linewidth=.3)+
 geom_hline(yintercept=-log10(.05),linetype='dashed',colour='grey40',linewidth=.35)+
 facet_wrap(~state,nrow=1)+scale_fill_viridis_c(name='Odds ratio\n(capped at 10)',option='viridis')+
 coord_flip()+labs(x=NULL,y='-log10 Fisher BH FDR',
 title='GDF15 virtual-KO affected genes vs WGCNA modules',
 subtitle='Williams only; FDR < 0.05; target excluded; tested-gene universe',tag='D')+TH
if(all(ora$fdr==1)) {
 ann <- unique(ora[,.(state,KO_significant,background)])
 ann[,module:=factor(module_order[ceiling(length(module_order)/2)],levels=rev(module_order))]
 ann[,label:=sprintf('No enriched modules\n(all BH FDR = 1)\nKO genes: %d / %d tested',KO_significant,background)]
 pD <- pD+geom_text(data=ann,aes(x=module,y=.7,label=label),inherit.aes=FALSE,size=2.1,family='Arial')
}
plots <- list(A=pA,B=pB,B2=pB2,C=pC,D=pD)
dims <- list(A=c(4,3.6),B=c(3.4,2.2),B2=c(4.2,2.4),C=c(4.6,max(2.8,.20*length(sets)+1.5)),D=c(4.4,max(2.6,.18*length(sets)+1.35)))
for(n in names(plots)) {
 ggsave(file.path(FIG,paste0('P3_',n,'_WGCNA.pdf')),plots[[n]],width=dims[[n]][1],height=dims[[n]][2],device=cairo_pdf)
 ggsave(file.path(FIG,paste0('P3_',n,'_WGCNA.png')),plots[[n]],width=dims[[n]][1],height=dims[[n]][2],dpi=600,device=grDevices::png,type='cairo')
}

if(!RENDER_ONLY) {
cairo_pdf(file.path(FIG,'WGCNA_diagnostics.pdf'),width=7.2,height=4.2,family='Arial')
par(mfrow=c(1,2),mar=c(4,4,2,1),cex=.8)
plot(st$Power,st$signed_R2,type='b',xlab='Soft-threshold power',ylab='Signed scale-free fit R2',main=paste('Selected power:',power))
abline(h=.8,col='#B2182B',lty=2);abline(v=power,col='#2166AC',lty=3)
plot(st$Power,st$mean.k.,type='b',xlab='Soft-threshold power',ylab='Mean connectivity',main=paste(nrow(dat),'sample-ID groups'))
par(mfrow=c(1,1))
plotDendroAndColors(net$dendrograms[[1]],net$colors[net$blockGenes[[1]]],groupLabels='WGCNA modules',
 dendroLabels=FALSE,hang=.03,main='Williams fibroblast pseudobulk module clustering')
dev.off()
summary <- list(created_at=format(Sys.time()),seed=20261008,
 tissue='Williams human gingival fibroblasts only; no Caetano/buccal/other tissue',
 input_sample_IDs=uniqueN(md$sample_id),conservative_sample_ID_groups=nrow(dat),
 healthy_groups=sum(group=='normal'),PD_groups=sum(group=='periodontitis'),
 participant_identity_caveat='PD161/b and PD164/b/c pooled conservatively by numeric ID. Public sample labels available; actual linkage not independently confirmed. These are sample-ID groups, not confirmed independent donors.',
 n_filtered_genes=nrow(lcpm),n_WGCNA_genes=ncol(dat),power=power,
 power_rule='First signed R2 >= 0.8 and mean connectivity >= 1; otherwise WGCNA FAQ sample-size fallback, 18 for <20',
 WGCNA=list(network='signed',correlation='bicor',maxPOutliers=.05,minModuleSize=30,deepSplit=2,mergeCutHeight=.25),
 n_modules=length(modules),module_sizes=member[,.N,by=module],
 signature_spearman=unname(ct$estimate),signature_spearman_p=ct$p.value,
 n_shared_genes=nrow(shared),VD_signature_GSEA=gb[,.(pathway,NES,padj,size)],
 reversal_modules=mdirection[significant_reverse==TRUE],
 no_reversal_claim='Opposite module direction is cross-dataset association only. Williams defines modules and disease test, so disease module inference is exploratory, not independent validation.',
 VD_caveat='Zhang/GSE212728: 3 D3 and 2 ethanol culture samples; one gingival-fibroblast donor. Culture replicates do not establish patient-level vitamin-D benefit.',
 KO_caveat='Reused Williams-only scTenifoldKnk outputs; sparse GDF15 detection; Immune input forced GDF15 into 500 genes. No top50 fallback. KO regulation FC is not measured expression FC.',
 KO_summary=ora[,.(state,module,background,KO_significant,overlap,fdr)],
 target_results=target_table[,.(gene,module,lfc_disease,fdr_disease,lfc_vd,fdr_vd)],
 sessionInfo=paste(capture.output(sessionInfo()),collapse='\n'))
writeLines(toJSON(summary,pretty=TRUE,auto_unbox=TRUE,digits=10,na='null'),file.path(QA,'analysis_summary.json'))
cat('[DONE] Fresh WGCNA and A-D/B2 completed\n'); flush.console()
} else { cat('[DONE] Figures re-exported from saved source tables; no WGCNA recomputation\n') }
