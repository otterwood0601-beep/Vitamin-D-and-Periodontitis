.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(SeuratObject);library(Matrix);library(data.table);library(edgeR)})
root <- 'C:/wb_links/p3_wgcna_20261008'
x <- readRDS('C:/wb_links/dlc_data/outputs/fb_seurat_annotated.rds')
d <- as.data.table(x[[]],keep.rownames='barcode')
d <- d[Study=='Williams' & disease%in%c('normal','periodontitis')]
d[,sample_group:=sub('[a-z]+$','',sample_id)]
c <- GetAssayData(x,layer='counts')[,d$barcode,drop=FALSE]
targets <- c('GDF15','MAPK1','MAPK3','MMP1','MMP3','MMP9','MMP13','VDR','CYP24A1')
mf <- fread(file.path(root,'data','01_sample_group_manifest.csv'))
pb <- sapply(mf$participant_group,function(g)Matrix::rowSums(c[,d[sample_group==g]$barcode,drop=FALSE]))
grp <- factor(mf$disease,levels=c('normal','periodontitis'))
design <- model.matrix(~grp)
y <- DGEList(pb); keep <- filterByExpr(y,design=design)
cp <- cpm(y)
DE <- fread(file.path(root,'data','02_Williams_group_pseudobulk_DE.csv'))
modules <- fread(file.path(root,'data','05_WGCNA_gene_membership.csv'))
passed <- calcNormFactors(y[keep,,keep.lib.sizes=FALSE]); lc <- cpm(passed,log=TRUE,prior.count=2)
var_rank <- rank(-apply(lc,1,var),ties.method='first')
report <- rbindlist(lapply(targets,function(g) {
 present <- g%in%rownames(c)
 nr <- if(present) match(g,rownames(c)) else NA_integer_
 data.table(gene=g,present_in_raw=present,expression_filter_pass=if(present)keep[nr] else FALSE,
 n_Williams_cells=ncol(c),n_detected_cells=if(present)sum(c[g,]>0) else NA_integer_,
 detection_fraction=if(present)mean(c[g,]>0) else NA_real_,
 total_UMI=if(present)sum(c[g,]) else NA_real_,
 groups_with_nonzero_counts=if(present)sum(pb[g,]>0) else NA_integer_,
 groups_with_CPM_at_least_1=if(present)sum(cp[g,]>=1) else NA_integer_,
 variance_rank=if(g%in%names(var_rank))var_rank[g] else NA_real_,
 network_status=if(g%in%modules$gene) modules[gene==g]$module else 'not_in_network',
 exclusion_reason=if(!present)'not_in_raw_matrix' else if(!keep[nr]) 'expression_filter' else if(!g%in%modules$gene)'outside_top_5000_variance' else 'included')
}))
fwrite(report,file.path(root,'data','14_target_QC_and_exclusion_reasons.csv'))
gc()
cat('Target QC completed\n'); print(report[,.(gene,expression_filter_pass,detection_fraction,variance_rank,exclusion_reason)])
