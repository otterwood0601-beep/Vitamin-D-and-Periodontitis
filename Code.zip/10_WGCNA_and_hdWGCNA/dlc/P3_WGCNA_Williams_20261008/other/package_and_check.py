from pathlib import Path
import json, hashlib
import numpy as np
import pandas as pd
import fitz
from scipy.stats import fisher_exact
root = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\P3_WGCNA_Williams_20261008')
fig = root / '\u56fe'
sd = root / '\u5176\u4ed6' / 'source_data'
qa = root / '\u5176\u4ed6' / 'QA'
render = qa / 'rendered'
render.mkdir(exist_ok=True)
files = [fig / f'P3_{a}_WGCNA.pdf' for a in ['A', 'B', 'B2', 'C', 'D']] + [fig / 'WGCNA_diagnostics.pdf']
out = fitz.open()
for f in files:
    with fitz.open(f) as d:
        out.insert_pdf(d)
out.save(fig / 'P3_A-D_WGCNA_complete.pdf', garbage=4, deflate=True)
out.close()
report = {'pages': [], 'checks': {}, 'source_pdf_sha256': {}}
for f in files:
    report['source_pdf_sha256'][f.name] = hashlib.sha256(f.read_bytes()).hexdigest()
with fitz.open(fig / 'P3_A-D_WGCNA_complete.pdf') as d:
    for i, p in enumerate(d):
        p.get_pixmap(matrix=fitz.Matrix(2.5, 2.5), alpha=False).save(render / f'page_{i + 1}.png')
        fonts = [{'name': f[3], 'embedded': bool(d.extract_font(f[0])[3])} for f in p.get_fonts()]
        outside = []
        for b in p.get_text('dict')['blocks']:
            for l in b.get('lines', []):
                for s in l['spans']:
                    if not p.rect.contains(fitz.Rect(s['bbox'])):
                        outside.append(s['text'])
        report['pages'].append({'page': i + 1, 'size_points': list(p.rect)[2:], 'fonts': fonts, 'text_outside_page': outside})
mem = pd.read_csv(sd / '05_WGCNA_gene_membership.csv')
shared = pd.read_csv(sd / '08_A_shared_gene_effects.csv')
manifest = pd.read_csv(sd / '01_sample_group_manifest.csv')
ora = pd.read_csv(sd / '12_D_Williams_KO_module_Fisher.csv')
report['checks']['unique_membership_genes'] = not mem.gene.duplicated().any()
report['checks']['membership_n_5000'] = len(mem) == 5000
report['checks']['unique_shared_genes'] = not shared.gene.duplicated().any()
report['checks']['no_grey_enrichment_module'] = not ora.module.eq('grey').any()
report['checks']['sample_groups_18'] = len(manifest) == 18
report['checks']['all_fonts_embedded'] = all((f['embedded'] for p in report['pages'] for f in p['fonts']))
report['checks']['no_off_page_text'] = all((not p['text_outside_page'] for p in report['pages']))
results = []
for r in ora.itertuples():
    k, K, M, N = (r.overlap, r.KO_significant, r.module_tested, r.background)
    table = [[k, K - k], [M - k, N - M - K + k]]
    p = fisher_exact(table, alternative='greater').pvalue
    results.append(min((min(x) for x in table)) >= 0 and np.isclose(p, r.p, rtol=1e-09, atol=1e-12))
report['checks']['Fisher_independently_recomputed'] = all(results)
old = pd.read_csv(qa / 'old_P3_pdf_SHA256_before.csv')
report['checks']['old_figures_unchanged'] = all((hashlib.sha256(Path(r.Path).read_bytes()).hexdigest().upper() == r.Hash for r in old.itertuples()))
report['checks']['old_figure_count'] = len(old)
with open(qa / 'independent_QA.json', 'w', encoding='utf-8') as f:
    json.dump(report, f, indent=2, ensure_ascii=False)
print(json.dumps(report['checks'], ensure_ascii=False, indent=2))
print('Render files:', render)
