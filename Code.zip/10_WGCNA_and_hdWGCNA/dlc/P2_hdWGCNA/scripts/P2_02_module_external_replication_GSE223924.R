options(stringsAsFactors = FALSE)
source("C:/wb_links/dlc_config/project_paths.R", encoding = "UTF-8")
PROJ <- Sys.getenv("DLC_HDWGCNA_PROJ", "P2_hdWGCNA"); ensure_dirs(PROJ)
FIG <- SEG_FIGDIR(PROJ); SD <- SEG_SRC(PROJ); QA <- SEG_QA(PROJ)

suppressPackageStartupMessages({ library(data.table); library(ggplot2) })
set.seed(20260910L)

mods <- fread(file.path(SD, "03_module_gene_membership.csv"))
mods <- mods[module != "grey"]
expr <- fread(file.path(WORK, "P1_\u75be\u75c5\u72b6\u6001\u9a8c\u8bc1/outputs/02_source_data/14_GSE223924_log2CPM.csv.gz"))
sc_stats <- fread(file.path(SD, "07_module_disease_donor_stats.csv"))  

g <- expr[[1]]
mat <- as.matrix(expr[, -1]); rownames(mat) <- g
h_cols <- grep("^H[0-9]+$", colnames(mat), value = TRUE)
pt_cols <- grep("^PT[0-9]+$", colnames(mat), value = TRUE)
stopifnot(length(h_cols) == 10, length(pt_cols) == 10)

z <- t(scale(t(mat)))
mod_ids <- unique(mods$module)
res <- rbindlist(lapply(mod_ids, function(mn) {
  genes <- intersect(mods[module == mn]$gene_name, rownames(z))
  if (length(genes) < 5) {
    return(data.table(module = mn, n_module_genes = mods[module == mn, .N],
                      n_genes_used = length(genes), coverage = NA_real_,
                      diff = NA_real_, CI_L = NA_real_, CI_R = NA_real_,
                      t = NA_real_, p_t = NA_real_))
  }
  sc <- colMeans(z[genes, , drop = FALSE])
  tt <- t.test(sc[pt_cols], sc[h_cols])
  data.table(module = mn, n_module_genes = mods[module == mn, .N],
             n_genes_used = length(genes),
             coverage = round(length(genes) / mods[module == mn, .N], 3),
             median_h = median(sc[h_cols]), median_p = median(sc[pt_cols]),
             diff = unname(tt$estimate[1] - tt$estimate[2]),
             CI_L = tt$conf.int[1], CI_R = tt$conf.int[2],
             t = unname(tt$statistic), p_t = tt$p.value)
}))
res[, p_BH := p.adjust(p_t, "BH")]

res <- merge(res, sc_stats[, .(module, sc_diff = diff, sc_p_BH = p_BH)],
             by = "module", all.x = TRUE, sort = FALSE)
res[, direction_concordant := sign(diff) == sign(sc_diff)]
fwrite(res, file.path(SD, "11_GSE223924_module_replication.csv"))

mod_col_vec <- setNames(unique(mods$color), unique(mods$module))
res[, module := factor(module, levels = mod_ids)]
res[, sig := ifelse(!is.na(p_BH) & p_BH < 0.05, "FDR<0.05", "ns")]
gp <- ggplot(res, aes(diff, module)) +
  geom_vline(xintercept = 0, linetype = "dashed", linewidth = 0.4, colour = "grey40") +
  geom_errorbarh(aes(xmin = CI_L, xmax = CI_R), height = 0.25, linewidth = 0.5) +
  geom_point(aes(colour = module, size = sig)) +
  scale_colour_manual(values = mod_col_vec, guide = "none") +
  scale_size_manual(values = c("FDR<0.05" = 2.6, "ns" = 1.6), guide = "none") +
  labs(x = "Module score difference (periodontitis - healthy), z units",
       y = NULL,
       title = "Independent replication of hdWGCNA modules in gingival tissue (GSE223924, 10 vs 10)") +
  THEME_NPJ +
  theme(axis.text.y = element_text(colour = mod_col_vec[levels(res$module)], face = "bold"),
        plot.tag = element_text(face = "bold", size = 12), plot.tag.position = "topleft") +
  labs(tag = "I")
ggsave(file.path(FIG, "\u56feP2I_\u6a21\u5757\u5916\u90e8\u590d\u73b0\u68ee\u6797\u56fe.pdf"), gp, width = 4.4, height = 2.8)
ggsave(file.path(FIG, "\u56feP2I_\u6a21\u5757\u5916\u90e8\u590d\u73b0\u68ee\u6797\u56fe.png"), gp, width = 4.4, height = 2.8, dpi = 300)

val <- list(created_at = format(Sys.time()),
            cohort = "GSE223924 tissue bulk (10 periodontitis vs 10 healthy, peri-implantitis excluded)",
            n_modules_tested = nrow(res),
            module_coverage = res[, .(module, n_module_genes, n_genes_used, coverage)],
            replication = res[, .(module, diff, CI_L, CI_R, p_t, p_BH, sc_diff, direction_concordant)],
            caveat = "Tissue-bulk scores cannot assign signals to fibroblast subtypes; replication is at module level only.",
            sessionInfo = paste(capture.output(sessionInfo()), collapse = "\n"))
writeLines(jsonlite::toJSON(val, pretty = TRUE, auto_unbox = TRUE, na = "null", digits = 6),
           file.path(QA, "P2_external_QA.json"))
cat("[done] P2 external replication\n")
