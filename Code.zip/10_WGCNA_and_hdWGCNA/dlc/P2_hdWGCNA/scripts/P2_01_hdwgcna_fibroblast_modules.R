options(stringsAsFactors = FALSE)
source("C:/wb_links/dlc_config/project_paths.R", encoding = "UTF-8")
PROJ <- Sys.getenv("DLC_HDWGCNA_PROJ", "P2_hdWGCNA"); ensure_dirs(PROJ)
STUDY_FILTER <- trimws(Sys.getenv("DLC_STUDY_FILTER", ""))
TOM_NAME <- if (nzchar(STUDY_FILTER)) paste0("gingival_fb_", STUDY_FILTER) else "gingival_fb"
FIG <- SEG_FIGDIR(PROJ); SD <- SEG_SRC(PROJ); QA <- SEG_QA(PROJ)

suppressPackageStartupMessages({
  library(Seurat); library(Matrix); library(data.table); library(ggplot2)
  library(hdWGCNA); library(WGCNA); library(patchwork)
})
set.seed(20260910L)
t0 <- Sys.time()

assign("cor", WGCNA::cor, envir = .GlobalEnv)

combine_plots <- function(obj, ncol = NULL) {
  if (inherits(obj, c("gg", "patchwork"))) return(obj)
  if (is.list(obj)) {
    flat <- list()
    for (x in obj) {
      if (is.list(x) && !inherits(x, c("gg", "patchwork"))) flat <- c(flat, x)
      else flat[[length(flat) + 1]] <- x
    }
    return(patchwork::wrap_plots(flat, ncol = ncol))
  }
  NULL
}

cat("[0] load annotated object\n"); flush.console()
fb <- readRDS(file.path(WORK, "01_\u6570\u636e\u51c6\u5907/outputs/fb_seurat_annotated.rds"))
if (nzchar(STUDY_FILTER)) {
  keep_cells <- rownames(fb[[]])[as.character(fb$Study) == STUDY_FILTER]
  if (!length(keep_cells)) stop("No cells matched Study == ", STUDY_FILTER)
  fb <- subset(fb, cells = keep_cells)
  cat("    study filter:", STUDY_FILTER, "cells:", ncol(fb), "\n")
}
gmt <- list()
for (ln in readLines(file.path(WORK, "01_\u6570\u636e\u51c6\u5907/outputs/curated_gene_sets_v1.gmt"))) {
  p <- strsplit(ln, "\t", fixed = TRUE)[[1]]
  gmt[[p[1]]] <- p[-c(1, 2)]
}

fb[["umap"]] <- fb[["frozen_umap"]]
DefaultAssay(fb) <- "RNA"

cat("[1] SetupForWGCNA + MetacellsByGroups\n"); flush.console()
fb <- SetupForWGCNA(fb, gene_select = "fraction", fraction = 0.05, wgcna_name = TOM_NAME)
cat("    selected genes:", length(GetWGCNAGenes(fb)), "\n")

fb <- MetacellsByGroups(
  seurat_obj = fb,
  group.by = c("donor_id", "fibroblast_type", "Study", "disease"),
  ident.group = "donor_id",
  k = 20, max_shared = 10, min_cells = 25, target_metacells = 100,
  reduction = "pca")
fb <- NormalizeMetacells(fb)

mc <- GetMetacellObject(fb)
mc_meta <- as.data.table(mc[[]])
mc_meta[, metacell := colnames(mc)]
fwrite(mc_meta, file.path(SD, "01_metacell_metadata.csv"))
cat("    metacells:", ncol(mc), " donors:", uniqueN(mc_meta$donor_id),
    "types:", uniqueN(mc_meta$fibroblast_type), "\n")

cat("[2] soft-power selection\n"); flush.console()
fb <- SetDatExpr(fb, group_name = "all", group.by = NULL, use_metacells = TRUE)
fb <- TestSoftPowers(fb, networkType = "signed")
sft <- as.data.table(GetPowerTable(fb))
fwrite(sft, file.path(SD, "02_soft_power_table.csv"))

cand <- sft[Power <= 12]
hit <- which(cand$SFT.R.sq >= 0.80)
pow <- if (length(hit)) cand$Power[hit[1]] else sft$Power[which.max(sft$SFT.R.sq)]
cat("    chosen soft power:", pow, "\n")
p1 <- tryCatch(combine_plots(PlotSoftPowers(fb, selected_power = pow), ncol = 2),
               error = function(e) { cat("    PlotSoftPowers failed:", conditionMessage(e), "\n")
    ggplot(sft, aes(Power, SFT.R.sq)) + geom_point() + geom_vline(xintercept = pow, lty = 2) +
      THEME_NPJ + labs(title = "Soft power (fallback)") })
ggsave(file.path(FIG, "\u56feP2A_\u8f6f\u9608\u503c\u9009\u62e9.pdf"), p1, width = 6.5, height = 5.5)
ggsave(file.path(FIG, "\u56feP2A_\u8f6f\u9608\u503c\u9009\u62e9.png"), p1, width = 6.5, height = 5.5, dpi = 300)

cat("[3] ConstructNetwork\n"); flush.console()
fb <- ConstructNetwork(fb, soft_power = pow, tom_name = TOM_NAME,
                       overwrite_tom = TRUE)
fb <- ModuleEigengenes(fb)   
fb <- ModuleConnectivity(fb, harmonized = FALSE)  
mods_dt <- as.data.table(GetModules(fb))
fwrite(mods_dt, file.path(SD, "03_module_gene_membership.csv"))
mod_cols <- mods_dt[!duplicated(module) & module != "grey", .(module, color)]
cat("    modules found:", nrow(mod_cols), "\n")

genes_use <- GetWGCNAGenes(fb)
expr_mc <- as.matrix(GetAssayData(mc, layer = "data")[genes_use, , drop = FALSE])
mod_vec <- setNames(as.character(mods_dt$module), mods_dt$gene_name)[rownames(expr_mc)]
stopifnot(!any(is.na(mod_vec)))
MEs <- WGCNA::moduleEigengenes(t(expr_mc), colors = mod_vec, excludeGrey = TRUE)$eigengenes
colnames(MEs) <- sub("^ME", "", colnames(MEs))
MEs_dt <- data.table(metacell = colnames(mc), as.data.table(MEs))
MEs_dt <- merge(MEs_dt, mc_meta[, .(metacell, donor_id, fibroblast_type, Study, disease)],
                by = "metacell", sort = FALSE)
stopifnot(nrow(MEs_dt) == ncol(mc))
fwrite(MEs_dt, file.path(SD, "04_metacell_module_eigengenes.csv"))

cat("[4] module feature plots\n"); flush.console()
fp <- tryCatch(combine_plots(ModuleFeaturePlot(fb, features = "MEs", restrict_range = FALSE), ncol = 3),
               error = function(e) { cat("    ModuleFeaturePlot failed:", conditionMessage(e), "\n"); NULL })
if (!is.null(fp)) {
  ggsave(file.path(FIG, "\u56feP2B_\u6a21\u5757\u7279\u5f81UMAP.pdf"), fp, width = 8, height = 5.5, limitsize = FALSE)
  ggsave(file.path(FIG, "\u56feP2B_\u6a21\u5757\u7279\u5f81UMAP.png"), fp, width = 8, height = 5.5, limitsize = FALSE, dpi = 300)
}

cat("[4b] module dendrogram\n"); flush.console()
tryCatch({
  pdf(file.path(FIG, "\u56feP2C_\u6a21\u5757\u6811.pdf"), width = 6.5, height = 3.0)
  PlotDendrogram(fb, main = "")
  dev.off()
  png(file.path(FIG, "\u56feP2C_\u6a21\u5757\u6811.png"), width = 6.5, height = 3.0, units = "in", res = 300)
  PlotDendrogram(fb, main = "")
  dev.off()
}, error = function(e) { try(dev.off(), silent = TRUE)
  cat("    PlotDendrogram failed:", conditionMessage(e), "\n") })

saveRDS(list(soft_power = pow, modules = mods_dt, metacell_MEs = MEs_dt,
             metacell_meta = mc_meta),
        file.path(WORK, PROJ, "outputs", "checkpoint_P2_objects.rds"))

cat("[5] hub genes\n"); flush.console()
hub <- as.data.table(GetHubGenes(fb, n_hubs = 10))
fwrite(hub, file.path(SD, "05_hub_genes.csv"))

tryCatch({
  pdf(file.path(FIG, "\u56feP2E_\u6a21\u5757hub\u7f51\u7edc.pdf"), width = 7, height = 7)
  HubGeneNetworkPlot(fb, n_hubs = 3, n_other = 3)
  dev.off()
  png(file.path(FIG, "\u56feP2E_\u6a21\u5757hub\u7f51\u7edc.png"), width = 7, height = 7, units = "in", res = 300)
  HubGeneNetworkPlot(fb, n_hubs = 3, n_other = 3)
  dev.off()
}, error = function(e) { try(dev.off(), silent = TRUE)
  cat("    HubGeneNetworkPlot failed:", conditionMessage(e), "\n") })
tryCatch({
  dir.create(file.path(FIG, "\u6a21\u5757\u7f51\u7edc\u56fe"), showWarnings = FALSE)
  ModuleNetworkPlot(fb, outdir = file.path(FIG, "\u6a21\u5757\u7f51\u7edc\u56fe"))
}, error = function(e) cat("    ModuleNetworkPlot failed:", conditionMessage(e), "\n"))

cat("[6] hub gene dotplot\n"); flush.console()
hub[, kME := as.numeric(kME)]
top_hubs <- hub[module != "grey"][order(module, -kME)][, head(.SD, 6), by = module]
genes_dot <- intersect(top_hubs$gene_name, rownames(fb))
expr <- GetAssayData(fb, layer = "data")[genes_dot, ]
df_dot <- lapply(seq_along(genes_dot), function(i) {
  g <- genes_dot[i]
  data.table(gene = g, fibroblast_type = fb$fibroblast_type, expr = as.numeric(expr[i, ]))
})
df_dot <- rbindlist(df_dot)
df_dot[, mean_expr := mean(expr), by = .(gene, fibroblast_type)]
df_dot[, pct_expr := 100 * mean(expr > 0), by = .(gene, fibroblast_type)]
df_dot <- df_dot[!duplicated(paste(gene, fibroblast_type))]
df_dot[, module := top_hubs$module[match(gene, top_hubs$gene_name)]]
df_dot[, module := factor(module, levels = mod_cols$module)]
df_dot[, fibroblast_type := factor(unname(FIVE_SHORT[as.character(fibroblast_type)]),
                                   levels = unname(FIVE_SHORT[FIVE_ORDER]))]
gpD <- ggplot(df_dot[!is.na(module)], aes(fibroblast_type, gene, colour = mean_expr, size = pct_expr)) +
  geom_point() + facet_grid(module ~ ., scales = "free_y", space = "free_y") +
  scale_colour_viridis_c(name = "Avg expression", option = "magma") +
  scale_size_continuous(name = "% expressed", range = c(0.5, 3.5)) +
  labs(x = NULL, y = NULL, title = "Hub genes of hdWGCNA modules across fibroblast subtypes") +
  THEME_NPJ + theme(axis.text.y = element_text(size = 5),
                    plot.tag = element_text(face = "bold", size = 12), plot.tag.position = "topleft") +
  labs(tag = "D")
ggsave(file.path(FIG, "\u56feP2D_\u6a21\u5757hub\u57fa\u56e0\u70b9\u56fe.pdf"), gpD, width = 4.2, height = 7.5, limitsize = FALSE)
ggsave(file.path(FIG, "\u56feP2D_\u6a21\u5757hub\u57fa\u56e0\u70b9\u56fe.png"), gpD, width = 4.2, height = 7.5, limitsize = FALSE, dpi = 300)

cat("[7] module GO enrichment (manual hypergeometric ORA)\n"); flush.console()
uni <- GetWGCNAGenes(fb)
go <- list()
for (ln in readLines(GMT_GO_BP)) {
  p <- strsplit(ln, "\t", fixed = TRUE)[[1]]
  go[[p[1]]] <- p[-c(1, 2)]
}
go_df <- data.table(term = rep(names(go), sapply(go, length)), gene = unlist(go))
go_df <- go_df[gene %in% uni]
go_size <- go_df[, .(term_size = .N), by = term]
uni_go <- unique(go_df$gene)
U <- length(uni_go)

ora_module <- function(mn) {
  qg <- intersect(mods_dt[module == mn]$gene_name, uni_go)
  Q <- length(qg)
  if (Q < 5) return(NULL)
  tab <- go_df[gene %in% qg, .(hit = .N), by = term]
  tab <- merge(tab, go_size, by = "term")
  tab[, qsz := Q][, bsz := term_size]
  tab[, p := phyper(hit - 1L, bsz, U - bsz, qsz, lower.tail = FALSE)]
  tab[, padj := p.adjust(p, "BH")]  
  tab[, term_ratio := hit / qsz][, bg_ratio := bsz / U][, fold := term_ratio / bg_ratio]
  tab <- tab[order(p)][padj < 0.1]
  tab <- head(tab, 10)
  if (nrow(tab) == 0) return(NULL)
  tab[, module := mn]
  tab
}
enr_tab <- rbindlist(lapply(mod_cols$module, ora_module), fill = TRUE)
if (nrow(enr_tab) > 0) fwrite(enr_tab, file.path(SD, "06_module_GO_BP_enrichment.csv"))
if (nrow(enr_tab) > 0) {
  enr_top <- enr_tab[, head(.SD[order(padj)], 5), by = module]
  setnames(enr_top, "term", "Description")
  gpF <- ggplot(enr_top, aes(fold, reorder(Description, -padj))) +
    geom_point(aes(colour = padj, size = hit)) +
    facet_grid(module ~ ., scales = "free_y", space = "free_y") +
    scale_colour_viridis_c(name = "p.adj", option = "magma", direction = -1, trans = "log10") +
    scale_size_continuous(name = "Count", range = c(1, 3.5)) +
    labs(x = "Fold enrichment (module genes in GO BP term)", y = NULL,
         title = "GO Biological Process enrichment of hdWGCNA modules (hypergeometric ORA)") +
    THEME_NPJ + theme(axis.text.y = element_text(size = 5),
                      strip.text.y = element_text(angle = 0, size = 6),
                      plot.tag = element_text(face = "bold", size = 12), plot.tag.position = "topleft") +
    labs(tag = "F")
  ggsave(file.path(FIG, "\u56feP2F_\u6a21\u5757GO\u5bcc\u96c6.pdf"), gpF, width = 6, height = 8, limitsize = FALSE)
  ggsave(file.path(FIG, "\u56feP2F_\u6a21\u5757GO\u5bcc\u96c6.png"), gpF, width = 6, height = 8, limitsize = FALSE, dpi = 300)
}

cat("[8] module-disease association + GDF15\n"); flush.console()

me_cols <- as.character(mod_cols$module)
stopifnot(all(me_cols %in% names(MEs_dt)))
me_long <- melt(MEs_dt, id.vars = c("metacell", "donor_id", "fibroblast_type", "Study", "disease"),
                measure.vars = me_cols, variable.name = "module", value.name = "ME")
me_donor <- me_long[, .(ME = mean(ME)), by = .(donor_id, fibroblast_type, Study, disease, module)]
mod_dis <- me_donor[, {
  h <- ME[disease == "normal"]; p <- ME[disease == "periodontitis"]
  wt <- if (length(h) >= 3 & length(p) >= 3) suppressWarnings(wilcox.test(h, p, exact = FALSE)) else NULL
  data.table(n_h = length(h), n_p = length(p), median_h = median(h), median_p = median(p),
             diff = median(p) - median(h), p_wilcox = if (is.null(wt)) NA_real_ else wt$p.value)
}, by = .(module)]
mod_dis[, p_BH := p.adjust(p_wilcox, "BH")]
fwrite(mod_dis, file.path(SD, "07_module_disease_donor_stats.csv"))

counts_mc <- GetAssayData(mc, layer = "counts")
stopifnot("GDF15" %in% rownames(counts_mc))
gdf_mc <- as.numeric(counts_mc["GDF15", ])
lib_mc <- colSums(counts_mc)
gdf_cpm_mc <- log2(gdf_mc / lib_mc * 1e6 + 0.5)
names(gdf_cpm_mc) <- colnames(mc)
mes <- as.matrix(MEs_dt[, me_cols, with = FALSE])
rownames(mes) <- MEs_dt$metacell
mes <- mes[match(names(gdf_cpm_mc), rownames(mes)), , drop = FALSE]
cor_gdf <- rbindlist(lapply(me_cols, function(cn) {
  v <- mes[, cn]; mn <- cn
  g <- mods_dt[module == mn]$gene_name
  ct <- suppressWarnings(cor.test(v, gdf_cpm_mc, method = "spearman"))
  data.table(module = mn, n_genes = length(g), contains_GDF15 = "GDF15" %in% g,
             rho_GDF15 = unname(ct$estimate), p_GDF15 = ct$p.value)
}))
cor_gdf[, p_BH := p.adjust(p_GDF15, "BH")]

cat("[8s] GDF15-excluded module score sensitivity\n"); flush.console()
genes_mod <- unique(mods_dt$gene_name)
expr_mc_z <- t(scale(t(as.matrix(GetAssayData(mc, layer = "data")[genes_mod, , drop = FALSE]))))
sens <- rbindlist(lapply(me_cols, function(cn) {
  mn <- cn
  g <- setdiff(mods_dt[module == mn]$gene_name, "GDF15")
  g <- intersect(g, rownames(expr_mc_z))
  if (length(g) < 5) return(NULL)
  sc <- colMeans(expr_mc_z[g, , drop = FALSE])
  sc <- sc[match(names(gdf_cpm_mc), names(sc))]
  ct <- suppressWarnings(cor.test(sc, gdf_cpm_mc, method = "spearman"))
  data.table(module = mn, rho_noGDF15 = unname(ct$estimate), p_noGDF15 = ct$p.value)
}))
sens[, p_noGDF15_BH := p.adjust(p_noGDF15, "BH")]
cor_gdf <- merge(cor_gdf, sens, by = "module", all.x = TRUE, sort = FALSE)
fwrite(cor_gdf, file.path(SD, "08_module_GDF15_metacell_spearman.csv"))

cat("[8b] module-trait bubble (subtype + disease + GDF15)\n"); flush.console()
trait_ids <- c(unname(FIVE_SHORT[FIVE_ORDER]), "Periodontitis", "GDF15_logCPM")
fb_short <- unname(FIVE_SHORT[as.character(MEs_dt$fibroblast_type)])
mt <- rbindlist(lapply(me_cols, function(cn) {
  v <- as.numeric(MEs_dt[[cn]]); mn <- cn
  rbindlist(lapply(trait_ids, function(tr) {
    x <- switch(tr,
      Periodontitis = as.numeric(MEs_dt$disease == "periodontitis"),
      GDF15_logCPM  = as.numeric(gdf_cpm_mc[MEs_dt$metacell]),
      as.numeric(fb_short == tr))
    ct <- suppressWarnings(cor.test(v, x, method = "pearson"))
    data.table(module = mn, trait = tr, rho = unname(ct$estimate), p = ct$p.value)
  }))
}))
mt[, p_BH := p.adjust(p, "BH")]
mt[, module := factor(module, levels = mod_cols$module)]
mt[, trait := factor(trait, levels = trait_ids)]
fwrite(mt, file.path(SD, "10_module_trait_bubble.csv"))

mod_col_vec <- setNames(mod_cols$color, mod_cols$module)
gpG <- ggplot(mt, aes(trait, module)) +
  geom_point(aes(colour = rho, size = -log10(p))) +
  scale_colour_gradient2(low = "#2166AC", mid = "white", high = "#C9403B",
                         midpoint = 0, limits = c(-1, 1), name = "Pearson r") +
  scale_size_continuous(name = expression(-log[10](p)), range = c(0.4, 3.8)) +
  labs(x = NULL, y = NULL,
       title = "Module eigengene associations with fibroblast subtype, disease and GDF15") +
  THEME_NPJ +
  theme(axis.text.y = element_text(colour = mod_col_vec[levels(mt$module)], face = "bold"),
        axis.text.x = element_text(angle = 30, hjust = 1),
        plot.tag = element_text(face = "bold", size = 12), plot.tag.position = "topleft") +
  labs(tag = "G")
ggsave(file.path(FIG, "\u56feP2G_\u6a21\u5757\u4e9a\u7fa4\u75be\u75c5\u5173\u8054\u6c14\u6ce1\u56fe.pdf"), gpG, width = 4.6, height = 3.0)
ggsave(file.path(FIG, "\u56feP2G_\u6a21\u5757\u4e9a\u7fa4\u75be\u75c5\u5173\u8054\u6c14\u6ce1\u56fe.png"), gpG, width = 4.6, height = 3.0, dpi = 300)

cat("[9] donor split-half stability (direct WGCNA)\n"); flush.console()
genes_use <- GetWGCNAGenes(fb)
expr_mc <- as.matrix(GetAssayData(mc, layer = "data")[genes_use, ])  
ref_sets <- split(mods_dt$gene_name, mods_dt$module)
ref_sets <- ref_sets[names(ref_sets) != "grey"]
donors_all <- unique(mc_meta$donor_id)
stab <- rbindlist(lapply(1:5, function(r) {
  set.seed(20260910L + r)
  d_keep <- sample(donors_all, floor(0.5 * length(donors_all)))
  keep <- which(mc_meta$donor_id %in% d_keep)
  sub <- t(expr_mc[, keep, drop = FALSE])  
  net <- tryCatch(WGCNA::blockwiseModules(
    sub, power = pow, networkType = "signed", TOMType = "signed",
    minModuleSize = 30, reassignThreshold = 0, mergeCutHeight = 0.25,
    numericLabels = TRUE, saveTOMs = FALSE, verbose = 0, maxBlockSize = 30000),
    error = function(e) { cat("    split", r, "failed:", conditionMessage(e), "\n"); NULL })
  if (is.null(net)) return(NULL)
  lab <- data.table(gene_name = names(net$colors), module2 = as.character(net$colors))
  lab <- lab[module2 != "0"]
  split_sets <- split(lab$gene_name, lab$module2)
  if (length(split_sets) == 0) return(NULL)
  data.table(ref_module = names(ref_sets),
             jaccard = vapply(ref_sets, function(g) {
               max(vapply(split_sets, function(g2)
                 length(intersect(g, g2)) / length(union(g, g2)), numeric(1)))
             }, numeric(1)),
             repeat_id = r, n_donors = length(d_keep), n_metacells = length(keep))
}))
fwrite(stab, file.path(SD, "09_donorhalf_module_stability_jaccard.csv"))

if (nrow(stab) > 0) {
  stab_sum <- stab[, .(mean_j = mean(jaccard), sd_j = sd(jaccard)), by = ref_module]
  stab_sum[, ref_module := factor(ref_module, levels = mod_cols$module)]
  stab[, ref_module := factor(ref_module, levels = mod_cols$module)]
  gpH <- ggplot(stab_sum, aes(ref_module, mean_j)) +
    geom_col(aes(fill = ref_module), width = 0.65, colour = "black", linewidth = 0.3, show.legend = FALSE) +
    geom_jitter(data = stab, aes(y = jaccard), width = 0.15, size = 1, colour = "grey20") +
    geom_hline(yintercept = 0.6, linetype = "dashed", linewidth = 0.4, colour = "grey40") +
    scale_fill_manual(values = mod_col_vec) +
    scale_y_continuous(limits = c(0, 1), expand = expansion(mult = c(0, 0.05))) +
    labs(x = NULL, y = "Best-match Jaccard index",
         title = "Module stability across donor split-half network reconstructions") +
    THEME_NPJ + theme(plot.tag = element_text(face = "bold", size = 12),
                      plot.tag.position = "topleft") +
    labs(tag = "H")
  ggsave(file.path(FIG, "\u56feP2H_\u6a21\u5757\u8de8\u4f9b\u8005\u7a33\u5b9a\u6027.pdf"), gpH, width = 3.6, height = 2.6)
  ggsave(file.path(FIG, "\u56feP2H_\u6a21\u5757\u8de8\u4f9b\u8005\u7a33\u5b9a\u6027.png"), gpH, width = 3.6, height = 2.6, dpi = 300)
}

val <- list(created_at = format(Sys.time()),
            study_filter = if (nzchar(STUDY_FILTER)) STUDY_FILTER else "All studies",
            n_metacells = ncol(mc), soft_power = pow, n_modules = nrow(mod_cols),
            module_ids = as.character(mod_cols$module),
            module_disease = mod_dis, gdf15_module_cor = cor_gdf,
            module_trait = mt,
            stability_jaccard = stab,
            caveat = "Co-expression modules are association structure, not regulatory proof; GDF15 need not be a hub. Metacells preserve donor x subtype origin but are not independent donors.",
            elapsed_min = round(as.numeric(difftime(Sys.time(), t0, units = "mins")), 2),
            sessionInfo = paste(capture.output(sessionInfo()), collapse = "\n"))
writeLines(jsonlite::toJSON(val, pretty = TRUE, auto_unbox = TRUE, na = "null", digits = 6),
           file.path(QA, "P2_QA_report.json"))
cat("[done] P2 in", val$elapsed_min, "min\n")
