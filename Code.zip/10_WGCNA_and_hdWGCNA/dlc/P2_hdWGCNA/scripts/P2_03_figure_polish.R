options(stringsAsFactors = FALSE)
source("E:/\u8840\u6e05\u7ef4\u751f\u7d20D DLC/00_\u5171\u7528\u914d\u7f6e/project_paths.R")
PROJ <- "P2_hdWGCNA"; ensure_dirs(PROJ)
FIG <- SEG_FIGDIR(PROJ); SD <- SEG_SRC(PROJ)

suppressPackageStartupMessages({
  library(Seurat); library(Matrix); library(data.table); library(ggplot2)
})
set.seed(20260910L)

mods_dt <- as.data.table(fread(file.path(SD, "03_module_gene_membership.csv")))
mod_cols <- mods_dt[!duplicated(module) & module != "grey", .(module, color)]
mod_col_vec <- setNames(mod_cols$color, mod_cols$module)
mod_order <- mod_cols$module

cat("[D] hub dotplot\n"); flush.console()
hub <- as.data.table(fread(file.path(SD, "05_hub_genes.csv")))
hub[, kME := as.numeric(kME)]
top_hubs <- hub[module != "grey"][order(module, -kME)][, head(.SD, 6), by = module]
fb <- readRDS(file.path(WORK, "01_\u6570\u636e\u51c6\u5907/outputs/fb_seurat_annotated.rds"))
genes_dot <- intersect(top_hubs$gene_name, rownames(fb))
expr <- GetAssayData(fb, layer = "data")[genes_dot, ]
df_dot <- rbindlist(lapply(seq_along(genes_dot), function(i) {
  data.table(gene = genes_dot[i], fibroblast_type = fb$fibroblast_type,
             expr = as.numeric(expr[i, ]))
}))
df_dot[, mean_expr := mean(expr), by = .(gene, fibroblast_type)]
df_dot[, pct_expr := 100 * mean(expr > 0), by = .(gene, fibroblast_type)]
df_dot <- df_dot[!duplicated(paste(gene, fibroblast_type))]
df_dot[, module := top_hubs$module[match(gene, top_hubs$gene_name)]]
df_dot[, module := factor(module, levels = mod_order)]
df_dot[, fibroblast_type := factor(unname(FIVE_SHORT[as.character(fibroblast_type)]),
                                 levels = unname(FIVE_SHORT[FIVE_ORDER]))]
rm(fb, expr); gc()
gpD <- ggplot(df_dot[!is.na(module)], aes(fibroblast_type, gene, colour = mean_expr, size = pct_expr)) +
  geom_point() + facet_grid(module ~ ., scales = "free_y", space = "free_y") +
  scale_colour_viridis_c(name = "Avg expression", option = "magma") +
  scale_size_continuous(name = "% expressed", range = c(0.5, 3.5)) +
  labs(x = NULL, y = NULL, title = "Hub genes of hdWGCNA modules", tag = "D") +
  THEME_NPJ + theme(axis.text.y = element_text(size = 5),
                    axis.text.x = element_text(angle = 30, hjust = 1),
                    plot.tag = element_text(face = "bold", size = 12), plot.tag.position = "topleft")
ggsave(file.path(FIG, "\u56feP2D_\u6a21\u5757hub\u57fa\u56e0\u70b9\u56fe.pdf"), gpD, width = 4.2, height = 7.5, limitsize = FALSE)
ggsave(file.path(FIG, "\u56feP2D_\u6a21\u5757hub\u57fa\u56e0\u70b9\u56fe.png"), gpD, width = 4.2, height = 7.5, limitsize = FALSE, dpi = 300)

cat("[F] GO enrichment\n"); flush.console()
enr_tab <- as.data.table(fread(file.path(SD, "06_module_GO_BP_enrichment.csv")))
enr_top <- enr_tab[, head(.SD[order(padj)], 5), by = module]
enr_top[, module := factor(module, levels = mod_order)]
gpF <- ggplot(enr_top, aes(fold, reorder(term, -padj))) +
  geom_point(aes(colour = padj, size = hit)) +
  facet_grid(module ~ ., scales = "free_y", space = "free_y") +
  scale_colour_viridis_c(name = "p.adj", option = "magma", direction = -1, trans = "log10") +
  scale_size_continuous(name = "Count", range = c(1, 3.5)) +
  labs(x = "Fold enrichment (module genes in GO BP term)", y = NULL,
       title = "GO BP enrichment (hypergeometric ORA)", tag = "F") +
  THEME_NPJ + theme(axis.text.y = element_text(size = 5),
                    strip.text.y = element_text(angle = 0, size = 6),
                    plot.tag = element_text(face = "bold", size = 12), plot.tag.position = "topleft")
ggsave(file.path(FIG, "\u56feP2F_\u6a21\u5757GO\u5bcc\u96c6.pdf"), gpF, width = 6, height = 8, limitsize = FALSE)
ggsave(file.path(FIG, "\u56feP2F_\u6a21\u5757GO\u5bcc\u96c6.png"), gpF, width = 6, height = 8, limitsize = FALSE, dpi = 300)

cat("[G] module-trait bubble\n"); flush.console()
trait_ids <- c(unname(FIVE_SHORT[FIVE_ORDER]), "Periodontitis", "GDF15_logCPM")
mt <- as.data.table(fread(file.path(SD, "10_module_trait_bubble.csv")))
mt[, module := factor(module, levels = mod_order)]
mt[, trait := factor(trait, levels = trait_ids)]
gpG <- ggplot(mt, aes(trait, module)) +
  geom_point(aes(colour = rho, size = -log10(p))) +
  scale_colour_gradient2(low = "#2166AC", mid = "white", high = "#C9403B",
                         midpoint = 0, limits = c(-0.8, 0.8), oob = scales::squish,
                         name = "Pearson r") +
  scale_size_continuous(name = expression(-log[10](p)), range = c(0.4, 3.8)) +
  scale_y_discrete(limits = rev(mod_order)) +
  labs(x = NULL, y = NULL, title = "Module-trait associations", tag = "G") +
  THEME_NPJ +
  theme(axis.text.y = element_text(colour = mod_col_vec[rev(mod_order)], face = "bold"),
        axis.text.x = element_text(angle = 30, hjust = 1),
        plot.tag = element_text(face = "bold", size = 12), plot.tag.position = "topleft")
ggsave(file.path(FIG, "\u56feP2G_\u6a21\u5757\u4e9a\u7fa4\u75be\u75c5\u5173\u8054\u6c14\u6ce1\u56fe.pdf"), gpG, width = 4.6, height = 3.0)
ggsave(file.path(FIG, "\u56feP2G_\u6a21\u5757\u4e9a\u7fa4\u75be\u75c5\u5173\u8054\u6c14\u6ce1\u56fe.png"), gpG, width = 4.6, height = 3.0, dpi = 300)

cat("[H] stability\n"); flush.console()
stab <- as.data.table(fread(file.path(SD, "09_donorhalf_module_stability_jaccard.csv")))
stab_sum <- stab[, .(mean_j = mean(jaccard), sd_j = sd(jaccard)), by = ref_module]
stab_sum[, ref_module := factor(ref_module, levels = mod_order)]
stab[, ref_module := factor(ref_module, levels = mod_order)]
gpH <- ggplot(stab_sum, aes(ref_module, mean_j)) +
  geom_col(aes(fill = ref_module), width = 0.65, colour = "black", linewidth = 0.3, show.legend = FALSE) +
  geom_jitter(data = stab, aes(y = jaccard), width = 0.15, size = 1, colour = "grey20") +
  geom_hline(yintercept = 0.6, linetype = "dashed", linewidth = 0.4, colour = "grey40") +
  scale_fill_manual(values = mod_col_vec) +
  scale_y_continuous(limits = c(0, 1), expand = expansion(mult = c(0, 0.05))) +
  labs(x = NULL, y = "Best-match Jaccard index",
       title = "Donor split-half module stability", tag = "H") +
  THEME_NPJ + theme(plot.tag = element_text(face = "bold", size = 12),
                    plot.tag.position = "topleft")
ggsave(file.path(FIG, "\u56feP2H_\u6a21\u5757\u8de8\u4f9b\u8005\u7a33\u5b9a\u6027.pdf"), gpH, width = 3.6, height = 2.6)
ggsave(file.path(FIG, "\u56feP2H_\u6a21\u5757\u8de8\u4f9b\u8005\u7a33\u5b9a\u6027.png"), gpH, width = 3.6, height = 2.6, dpi = 300)

cat("[done] figure polish\n")
