.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(ggplot2)})
OLD <- 'C:/wb_links/dlc/output/P3_hdWGCNA6_BE_20261009_GRsmall/other'
OUT <- 'C:/Users/Lin/AppData/Local/Temp/p3_hd6_BE_20261009_clean'
sd<-file.path(OUT,'source_data');fig<-file.path(OUT,'panels')
dir.create(sd,recursive=TRUE,showWarnings=FALSE);dir.create(fig,recursive=TRUE,showWarnings=FALSE)
stopifnot(all(file.copy(list.files(file.path(OLD,'source_data'),full.names=TRUE),sd,overwrite=TRUE)))
mods<-c('green','blue','turquoise','red','yellow','brown')
shared<-fread(file.path(sd,'02_shared_gene_statistics_hd_membership.csv'))
rkD<-sort(setNames(shared$t,shared$gene),decreasing=TRUE)
sg<-fread(file.path(sd,'04_BC_VD_signatures_by_module.csv'))
gb<-fread(file.path(sd,'05_BC_signature_GSEA_rawP.csv'))
vs<-setNames(lapply(gb$pathway,function(n)sg[pathway==n]$gene),gb$pathway)
mc<-fread(file.path(sd,'06_D_module_GSEA_rawP.csv'))
ora<-fread(file.path(sd,'08_E_KO_module_Fisher_rawP.csv'))
code<-readLines('C:/wb_links/dlc/output/P3_hdWGCNA6_BE_20261009/other/run_hd6.R',warn=FALSE)
first<-which(startsWith(code,'TH <-'));last<-which(startsWith(code,'plots<-'))-1L
stopifnot(length(first)==1,length(last)==1)
eval(parse(text=code[first:last]))
plots<-list(B=pB,C=pC,D=pD,E=pE)
dims<-list(B=c(10,4.05),C=c(10,4.45),D=c(5.7,3.95),E=c(7,3.95))
for(n in names(plots)) {
 p<-plots[[n]]+labs(title=NULL,subtitle=NULL,caption=NULL)
 ggsave(file.path(fig,paste0('Fig5',n,'_hdWGCNA6_clean.pdf')),p,width=dims[[n]][1],height=dims[[n]][2],device=cairo_pdf)
 ggsave(file.path(fig,paste0('Fig5',n,'_hdWGCNA6_clean.png')),p,width=dims[[n]][1],height=dims[[n]][2],dpi=180,device=grDevices::png,type='cairo')
}
cat('[DONE] B-E headers/subtitles/captions removed; analysis unchanged\n')
