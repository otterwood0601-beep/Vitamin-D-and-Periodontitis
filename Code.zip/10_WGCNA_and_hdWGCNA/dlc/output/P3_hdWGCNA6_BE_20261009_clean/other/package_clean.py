from pathlib import Path
import json, shutil, hashlib
import pandas as pd
import fitz
old = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\P3_hdWGCNA6_BE_20261009_GRsmall\\other')
temp = Path('C:\\Users\\Lin\\AppData\\Local\\Temp\\p3_hd6_BE_20261009_clean')
out = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\P3_hdWGCNA6_BE_20261009_clean')
(out / '\u56fe').mkdir(parents=True, exist_ok=True)
for f in (old / 'source_data').glob('*.csv'):
    revised = temp / 'source_data' / f.name
    if f.name == '10_C_running_enrichment.csv':
        pd.testing.assert_frame_equal(pd.read_csv(f), pd.read_csv(revised))
    else:
        assert f.read_bytes() == revised.read_bytes(), f.name
shutil.copytree(temp / 'source_data', out / 'other/source_data', dirs_exist_ok=True)
shutil.copytree(temp / 'panels', out / 'other/panels', dirs_exist_ok=True)
shutil.copy2(old / 'summary.json', out / 'other/analysis_summary_unchanged.json')
doc = fitz.open()
page = doc.new_page(width=1000, height=1170)
rects = {'B': (12, 8, 988, 403.28), 'C': (12, 415, 988, 849.32), 'D': (12, 861, 449, 1163.83), 'E': (460, 863, 988, 1160.94)}
removed = ['Vitamin-D signatures in periodontitis', 'Six fixed hdWGCNA modules', 'Positive NES:', 'Vitamin-D signature GSEA curves', 'Curves shown only', 'Module directions: disease vs vitamin D', 'P-value computation floor:', 'GDF15 virtual-KO affected genes vs modules', 'Labels: affected / tested']
for n, rect in rects.items():
    with fitz.open(temp / 'panels' / f'Fig5{n}_hdWGCNA6_clean.pdf') as part:
        txt = part[0].get_text()
        assert all((x not in txt for x in removed))
        for m in ['green', 'blue', 'turquoise', 'red', 'yellow', 'brown']:
            assert m in txt
        page.show_pdf_page(fitz.Rect(rect), part, 0)
pdf = out / '\u56fe/Fig5_B-E_hdWGCNA6_latest.pdf'
doc.set_metadata({'title': 'Figure 5 B-E: six Williams hdWGCNA modules', 'subject': 'Green/red B-C minSize=1; other modules minSize=15; unadjusted P; source methods saved separately'})
doc.save(pdf)
doc.close()
qa = {'analysis_source': 'P3_hdWGCNA6_BE_20261009_GRsmall', 'all_source_statistics_unchanged': True, 'removed': 'B-E panel titles, subtitles, captions and combined-page footer', 'preserved': 'B-E tags, six module labels, axes, P values, gene counts, curves, legends', 'pdf': str(pdf), 'pages': 1, 'pdf_sha256': hashlib.sha256(pdf.read_bytes()).hexdigest()}
(out / 'other/QA.json').write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(qa, ensure_ascii=False, indent=2))
