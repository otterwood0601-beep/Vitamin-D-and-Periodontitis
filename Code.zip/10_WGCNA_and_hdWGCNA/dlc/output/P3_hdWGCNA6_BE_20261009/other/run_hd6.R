options(stringsAsFactors=FALSE)
.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fgsea);library(ggplot2);library(jsonlite)})
set.seed(20261009)
OUT <- 'C:/Users/Lin/AppData/Local/Temp/p3_hd6_BE_20261009'
dir.create(OUT,recursive=TRUE,showWarnings=FALSE)
sd <- file.path(OUT,'source_data'); fig <- file.path(OUT,'panels')
dir.create(sd,showWarnings=FALSE);dir.create(fig,showWarnings=FALSE)
mods <- c('green','blue','turquoise','red','yellow','brown')
member_path <- 'C:/wb_links/dlc/P2_hdWGCNA_Williams_20260920/outputs/02_source_data/03_module_gene_membership.csv'
member <- fread(member_path)[,.(gene=gene_name,module)]
stopifnot(!anyDuplicated(member$gene),setequal(setdiff(unique(member$module),'grey'),mods))
shared <- fread('C:/wb_links/p3_wgcna_20261008/data/08_A_shared_gene_effects.csv')
shared[,module:=NULL]
shared <- merge(shared,member,by='gene',all.x=TRUE)
shared[is.na(module),module:='not_in_hd_network']
stopifnot(nrow(shared)==11444,!anyDuplicated(shared$gene),all(is.finite(shared$t)),all(is.finite(shared$stat_vd)))
fwrite(member,file.path(sd,'01_fixed_hdWGCNA_membership.csv'))
fwrite(shared,file.path(sd,'02_shared_gene_statistics_hd_membership.csv'))
rkD <- sort(setNames(shared$t,shared$gene),decreasing=TRUE)
rkV <- sort(setNames(shared$stat_vd,shared$gene),decreasing=TRUE)
sets <- setNames(lapply(mods,function(m)shared[module==m]$gene),mods)
coverage <- rbindlist(lapply(mods,function(m)data.table(module=m,full_module=sum(member$module==m),shared_ranked=length(sets[[m]]))))
fwrite(coverage,file.path(sd,'03_module_coverage.csv'))
siggenes <- shared[module%in%mods & is.finite(p_vd) & p_vd<.05 & lfc_vd!=0,
 .(gene,module,direction=ifelse(lfc_vd>0,'VD_UP','VD_DOWN'),p_vd,lfc_vd)]
siggenes[,pathway:=paste(module,direction,sep='__')]
fwrite(siggenes,file.path(sd,'04_BC_VD_signatures_by_module.csv'))
siginfo <- CJ(module=mods,direction=c('VD_UP','VD_DOWN'),sorted=FALSE)
siginfo[,pathway:=paste(module,direction,sep='__')]
vs <- setNames(lapply(siginfo$pathway,function(s)siggenes[pathway==s]$gene),siginfo$pathway)
siginfo[,size:=lengths(vs)]
siginfo[,status:=ifelse(size>=15,'tested','not_tested_fewer_than_15')]
gsea <- function(s,rk,eps=0){
 z <- as.data.table(fgseaMultilevel(pathways=s,stats=rk,minSize=15,maxSize=5000,eps=eps,nPermSimple=10000,nproc=1))
 z[,leadingEdge:=vapply(leadingEdge,paste,collapse=';',FUN.VALUE=character(1))]
 z[,padj:=NULL]
 z
}
cat('Computing B/C module-specific vitamin-D signatures\n');flush.console()
if(file.exists(file.path(sd,'05_BC_signature_GSEA_rawP.csv'))) {
 gb <- fread(file.path(sd,'05_BC_signature_GSEA_rawP.csv'))
 stopifnot(setequal(gb$pathway,siginfo$pathway))
} else {
 gb <- gsea(vs[lengths(vs)>=15],rkD)
 gb <- merge(siginfo,gb[,!c('size'),with=FALSE],by='pathway',all.x=TRUE)
}
fwrite(gb,file.path(sd,'05_BC_signature_GSEA_rawP.csv'))
cat('Computing D module directions\n');flush.console()
if('--reuse-gsea'%in%commandArgs(TRUE)) {
 mc <- fread(file.path(sd,'06_D_module_GSEA_rawP.csv'))
 stopifnot('P_at_computation_floor'%in%names(mc))
} else {
 mc <- rbindlist(list(cbind(gsea(sets,rkD,eps=1e-50),dataset='Periodontitis'),cbind(gsea(sets,rkV,eps=1e-50),dataset='Vitamin D3')))
}
mc[,P_at_computation_floor:=pval<=1e-50]
fwrite(mc,file.path(sd,'06_D_module_GSEA_rawP.csv'))
dr <- merge(mc[dataset=='Periodontitis',.(module=pathway,NES_disease=NES,P_disease=pval)],mc[dataset=='Vitamin D3',.(module=pathway,NES_VD=NES,P_VD=pval)],by='module')
dr[,opposite_direction:=NES_disease*NES_VD<0]
dr[,nominal_reverse:=opposite_direction & P_disease<.05 & P_VD<.05]
fwrite(dr,file.path(sd,'07_D_direction_summary_rawP.csv'))
cat('Computing E Fisher enrichment with tested-gene background\n');flush.console()
ko_records <- list()
ora <- rbindlist(lapply(c('Vascular','Immune'),function(s){
 ko <- fread(paste0('C:/wb_links/williams_ko_20260924/27_scTenifoldKnk_GDF15_',s,'_differential_regulation.csv'))
 universe <- intersect(setdiff(ko$gene,'GDF15'),member$gene)
 sig <- intersect(ko[is.finite(p.value)&p.value<.05]$gene,universe)
 ko_records[[s]] <<- ko[gene%in%universe,.(state=s,gene,p=p.value,selected=is.finite(p.value)&p.value<.05)]
 rbindlist(lapply(mods,function(m){
  g <- intersect(member[module==m]$gene,universe)
  N<-length(universe);M<-length(g);K<-length(sig);k<-length(intersect(g,sig))
  ft<-if(M>0) fisher.test(matrix(c(k,K-k,M-k,N-M-K+k),nrow=2),alternative='greater') else list(estimate=NA_real_,p.value=NA_real_)
  data.table(state=s,module=m,background=N,module_tested=M,KO_significant=K,overlap=k,
   overlap_genes=paste(intersect(g,sig),collapse=';'),OR=unname(ft$estimate),p=ft$p.value)
 }))
}))
fwrite(ora,file.path(sd,'08_E_KO_module_Fisher_rawP.csv'))
fwrite(rbindlist(ko_records),file.path(sd,'09_E_tested_genes.csv'))

TH <- theme_classic(base_size=8,base_family='Arial')+
 theme(axis.text=element_text(size=7,colour='black'),axis.title=element_text(size=8),
 axis.line=element_line(linewidth=.4),legend.text=element_text(size=7),legend.title=element_text(size=7),
 plot.title=element_text(size=10,face='bold'),plot.subtitle=element_text(size=8),
 plot.tag=element_text(face='bold',size=14),plot.tag.position='topleft',
 strip.background=element_blank(),strip.text=element_text(face='bold',size=9),
 plot.caption=element_text(size=7,hjust=0),plot.margin=margin(9,10,8,9))
pal <- c(VD_UP='#B2182B',VD_DOWN='#2166AC')
gb[,module:=factor(module,levels=mods)]
gb[,direction:=factor(direction,levels=c('VD_DOWN','VD_UP'))]
gb[,label:=ifelse(status=='tested',sprintf('P=%.2g; n=%d',pval,size),sprintf('n=%d (<15): not tested',size))]
lim <- max(abs(gb$NES),na.rm=TRUE)+2
pB <- ggplot(gb,aes(direction,NES,fill=direction))+
 geom_col(data=gb[status=='tested'],width=.6,colour='black',linewidth=.3)+
 geom_hline(yintercept=0,linewidth=.3)+
 geom_text(data=gb[status=='tested'],aes(y=0,label=label,hjust=ifelse(NES>=0,1.08,-.08)),size=2.5,family='Arial')+
 geom_text(data=gb[status!='tested'],aes(y=.3,label=sprintf('n=%d (<15)\nnot tested',size)),hjust=0,size=2.5,family='Arial',colour='grey35')+
 facet_wrap(~module,ncol=3)+scale_fill_manual(values=pal,guide='none')+
 scale_y_continuous(limits=c(-lim,lim))+coord_flip()+
 labs(x=NULL,y='Normalized enrichment score (NES)',title='Vitamin-D signatures in periodontitis',
 subtitle='Six fixed hdWGCNA modules; VD gene raw P < 0.05',tag='B',
 caption='Positive NES: enriched toward disease-up genes. Signatures with fewer than 15 genes are not tested.')+TH
running <- function(s,rk,name){
 N<-length(rk);hit<-names(rk)%in%s;w<-abs(rk)
 es<-cumsum(ifelse(hit,w/sum(w[hit]),-1/sum(!hit)))
 data.table(rank=seq_len(N),ES=es,pathway=name,hit=hit)
}
run <- rbindlist(lapply(gb[status=='tested']$pathway,function(n)running(vs[[n]],rkD,n)))
run<-merge(run,gb[,.(pathway,module,direction)],by='pathway')
fwrite(run,file.path(sd,'10_C_running_enrichment.csv'))
cnote <- gb[status!='tested',.(note=paste(paste0(direction,': n=',size,' (<15)'),collapse='\n')),by=module]
cnote[,`:=`(rank=length(rkD)*.5,ES=0.72)]
fblank <- data.table(module=factor(mods,levels=mods),rank=1,ES=0)
pC <- ggplot(run,aes(rank,ES,colour=direction))+
 geom_blank(data=fblank,aes(rank,ES),inherit.aes=FALSE)+
 geom_hline(yintercept=0,colour='grey50',linetype='dashed',linewidth=.3)+
 geom_line(linewidth=.5)+facet_wrap(~module,ncol=3,drop=FALSE)+
 geom_text(data=cnote,aes(rank,ES,label=note),inherit.aes=FALSE,size=2.4,family='Arial',colour='grey35')+
 scale_x_continuous(breaks=c(0,5000,10000),labels=c('0','5k','10k'),expand=expansion(mult=c(.02,.04)))+
 scale_y_continuous(limits=c(-.8,.8))+scale_colour_manual(values=pal,name=NULL)+
 labs(x='Disease ranked genes (up to down)',y='Running enrichment score',title='Vitamin-D signature GSEA curves',
 subtitle='Six fixed hdWGCNA modules; same signatures as B',tag='C',
 caption='Curves shown only for tested signatures (at least 15 genes); no curve is imputed for smaller sets.')+TH+
 theme(legend.position='bottom')
mc[,star:=ifelse(pval<.001,'***',ifelse(pval<.01,'**',ifelse(pval<.05,'*','')))]
mc[,label:=sprintf('%.2f%s',NES,star)]
mc[,dataset:=factor(dataset,levels=c('Periodontitis','Vitamin D3'))]
mc[,pathway:=factor(pathway,levels=rev(mods))]
pD <- ggplot(mc,aes(dataset,pathway,fill=NES))+geom_tile(colour='white',linewidth=.6)+
 geom_text(aes(label=label),size=3,family='Arial')+
 scale_fill_gradient2(low='#2166AC',mid='#F7F7F7',high='#B2182B',midpoint=0,name='GSEA NES')+
 labs(x=NULL,y=NULL,title='Module directions: disease vs vitamin D',
 subtitle='Six fixed hdWGCNA modules; stars = raw P',tag='D',
 caption='P-value computation floor: 1e-50; values at the floor are reported as P <= 1e-50.')+TH+
 theme(axis.text.x=element_text(angle=20,hjust=1),axis.text.y=element_text(size=9))
ora[,module:=factor(module,levels=rev(mods))]
ora[,plot_or:=pmin(OR,10)]
ora[is.na(plot_or),plot_or:=0]
ora[,label:=ifelse(module_tested>0,sprintf('%d/%d',overlap,module_tested),'0 tested; NA')]
ora[,plot_score:=ifelse(is.finite(p),-log10(pmax(p,1e-300)),0)]
pE <- ggplot(ora,aes(module,plot_score,fill=plot_or))+
 geom_col(data=ora[is.finite(p)],width=.62,colour='black',linewidth=.3)+
 geom_text(aes(label=label),hjust=-.15,size=2.5,family='Arial')+
 geom_hline(yintercept=-log10(.05),linetype='dashed',colour='grey40',linewidth=.35)+
 facet_wrap(~state,nrow=1)+scale_fill_viridis_c(name='Odds ratio\n(capped at 10)',option='viridis')+
 scale_y_continuous(limits=c(0,max(1.7,max(ora$plot_score)+.7)),expand=expansion(mult=c(0,.03)))+
 coord_flip()+labs(x=NULL,y='-log10 Fisher raw P',title='GDF15 virtual-KO affected genes vs modules',
 subtitle='Six fixed hdWGCNA modules; KO gene raw P < 0.05',tag='E',
 caption='Labels: affected / tested module genes; NA: no tested genes. Dashed line: raw P = 0.05.')+TH
plots<-list(B=pB,C=pC,D=pD,E=pE)
dims<-list(B=c(10,4.6),C=c(10,5),D=c(5.7,4.5),E=c(7,4.5))
for(n in names(plots)){
 ggsave(file.path(fig,paste0('Fig5',n,'_hdWGCNA6_rawP.pdf')),plots[[n]],width=dims[[n]][1],height=dims[[n]][2],device=cairo_pdf)
 ggsave(file.path(fig,paste0('Fig5',n,'_hdWGCNA6_rawP.png')),plots[[n]],width=dims[[n]][1],height=dims[[n]][2],dpi=180,device=grDevices::png,type='cairo')
}
summary<-list(module_source=member_path,modules=mods,shared_ranked_genes=nrow(shared),coverage=coverage,
 signature_results=gb[,.(module,direction,size,NES,pval,status)],module_directions=dr,
 KO_results=ora[,.(state,module,background,module_tested,KO_significant,overlap,OR,p)],
 rules=list(VD_gene_selection='raw P < 0.05 and sign of log2FC; within each fixed module',
 ranked_universe='All 11444 common genes, unchanged; not restricted to 6-module genes',
 module_min_size=15,D_GSEA_eps=1e-50,D_floor_interpretation='Values at 1e-50 are reported as P <= 1e-50, not an exact P estimate',KO_universe='All originally tested KO genes intersect full hdWGCNA network incl grey, excluding GDF15',
 module_membership='Fixed original membership; no network re-estimation',
 interpretation='Exploratory; sample-ID groups not confirmed donors; Zhang one donor; raw P uncorrected; no causal inference'))
writeLines(toJSON(summary,pretty=TRUE,auto_unbox=TRUE,na='null',digits=12),file.path(OUT,'summary.json'))
print(coverage);print(gb[,.(module,direction,size,NES,pval,status)]);print(dr);print(ora[,.(state,module,overlap,module_tested,p)])
cat('[DONE] six-module B-E\n')
