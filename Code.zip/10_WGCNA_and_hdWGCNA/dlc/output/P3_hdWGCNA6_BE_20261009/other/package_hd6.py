from pathlib import Path
import json, hashlib, shutil
import numpy as np
import pandas as pd
import fitz
from scipy.stats import fisher_exact
temp = Path('C:\\Users\\Lin\\AppData\\Local\\Temp\\p3_hd6_BE_20261009')
out = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\P3_hdWGCNA6_BE_20261009')
src = temp / 'source_data'
summary = json.loads((temp / 'summary.json').read_text(encoding='utf-8'))
mods = ['green', 'blue', 'turquoise', 'red', 'yellow', 'brown']
orig = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\P2_hdWGCNA_Williams_20260920\\outputs\\02_source_data\\03_module_gene_membership.csv')
membership = pd.read_csv(orig).rename(columns={'gene_name': 'gene'})
saved = pd.read_csv(src / '01_fixed_hdWGCNA_membership.csv')
pd.testing.assert_frame_equal(membership[['gene', 'module']], saved)
assert set(saved.module) - {'grey'} == set(mods)
shared = pd.read_csv(src / '02_shared_gene_statistics_hd_membership.csv')
original_shared = pd.read_csv(Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\P3_WGCNA_Williams_20261008\\\u5176\u4ed6\\source_data\\08_A_shared_gene_effects.csv'))
pd.testing.assert_frame_equal(shared[['gene', 't', 'stat_vd', 'p_vd', 'lfc_vd']].sort_values('gene').reset_index(drop=True), original_shared[['gene', 't', 'stat_vd', 'p_vd', 'lfc_vd']].sort_values('gene').reset_index(drop=True))
bc = pd.read_csv(src / '05_BC_signature_GSEA_rawP.csv')
sig = pd.read_csv(src / '04_BC_VD_signatures_by_module.csv')
for row in bc.itertuples():
    expected = shared.loc[(shared.module == row.module) & (shared.p_vd < 0.05) & (shared.lfc_vd > 0 if row.direction == 'VD_UP' else shared.lfc_vd < 0), 'gene']
    assert set(expected) == set(sig.loc[sig.pathway == row.pathway, 'gene'])
    assert row.size == len(expected)
    assert (row.status == 'tested') == (len(expected) >= 15)
    if len(expected) < 15:
        assert pd.isna(row.NES) and pd.isna(row.pval)
assert len(bc) == 12
mc = pd.read_csv(src / '06_D_module_GSEA_rawP.csv')
assert len(mc) == 12 and set(mc.pathway) == set(mods)
assert np.isfinite(mc.NES).all() and mc.pval.between(0, 1).all()
curves = pd.read_csv(src / '10_C_running_enrichment.csv')
ranked = shared.sort_values('t', ascending=False)
max_es_error = 0.0
for row in bc.loc[bc.status == 'tested'].itertuples():
    hit = ranked.gene.isin(sig.loc[sig.pathway == row.pathway, 'gene']).to_numpy()
    weight = ranked.t.abs().to_numpy()
    es = np.cumsum(np.where(hit, weight / weight[hit].sum(), -1 / (~hit).sum()))
    calc = curves.loc[curves.pathway == row.pathway].sort_values('rank').ES.to_numpy()
    assert len(calc) == 11444
    max_es_error = max(max_es_error, float(np.max(np.abs(es - calc))))
assert max_es_error < 1e-09
assert curves.ES.between(-0.8, 0.8).all(), 'Curve exceeds plotted y range'
ora = pd.read_csv(src / '08_E_KO_module_Fisher_rawP.csv')
max_fisher_error = 0.0
ko_root = Path('C:\\wb_links\\williams_ko_20260924')
for row in ora.itertuples():
    ko = pd.read_csv(ko_root / f'27_scTenifoldKnk_GDF15_{row.state}_differential_regulation.csv')
    universe = set(ko.gene) - {'GDF15'} & set(saved.gene)
    selected = set(ko.loc[ko['p.value'] < 0.05, 'gene']) & universe
    modset = set(saved.loc[saved.module == row.module, 'gene']) & universe
    N, M, K, k = (len(universe), len(modset), len(selected), len(selected & modset))
    assert (N, M, K, k) == (row.background, row.module_tested, row.KO_significant, row.overlap)
    if M == 0:
        assert pd.isna(row.p)
    else:
        p = fisher_exact([[k, M - k], [K - k, N - M - K + k]], alternative='greater').pvalue
        max_fisher_error = max(max_fisher_error, abs(float(p - row.p)))
assert max_fisher_error < 1e-10
qa = {'module_membership_identical': True, 'disease_and_VD_statistics_unchanged': True, 'BC_signatures_recomputed_within_each_module': True, 'BC_sets_tested': int((bc.status == 'tested').sum()), 'BC_sets_below_15': int((bc.status != 'tested').sum()), 'D_modules': 6, 'E_module_state_slots': 12, 'E_tests_with_measured_module_genes': int(ora.p.notna().sum()), 'E_no_tested_module_genes': int(ora.p.isna().sum()), 'max_running_ES_error': max_es_error, 'max_Fisher_P_error': max_fisher_error, 'membership_source_sha256': hashlib.sha256(orig.read_bytes()).hexdigest(), 'raw_P_only': True, 'old_figures_preserved': True}
(out / 'other').mkdir(parents=True, exist_ok=True)
(out / '\u56fe').mkdir(exist_ok=True)
shutil.copytree(src, out / 'other' / 'source_data', dirs_exist_ok=True)
shutil.copytree(temp / 'panels', out / 'other' / 'panels', dirs_exist_ok=True)
shutil.copy2(temp / 'summary.json', out / 'other' / 'summary.json')
doc = fitz.open()
page = doc.new_page(width=1000, height=1390)
rects = {'B': (12, 8, 988, 456), 'C': (12, 467, 988, 955), 'D': (12, 969, 449, 1314), 'E': (460, 969, 988, 1309)}
for key, rect in rects.items():
    with fitz.open(temp / 'panels' / f'Fig5{key}_hdWGCNA6_rawP.pdf') as part:
        assert len(part) == 1
        page.show_pdf_page(fitz.Rect(rect), part, 0)
page.insert_text((18, 1341), 'Fixed module source: Williams hdWGCNA (6 non-grey modules). Disease: Williams sample-level pseudobulk; vitamin D: Zhang/GSE212728.', fontsize=9)
page.insert_text((18, 1358), 'Exploratory: 18 conservatively grouped sample IDs; donor linkage not fully confirmed. Zhang: 3 D3 / 2 ethanol cultures from one donor.', fontsize=9)
page.insert_text((18, 1375), 'All displayed P values are unadjusted. B/C signatures use raw P < 0.05 and at least 15 genes. The earlier 13-module figures are preserved.', fontsize=9)
pdf = out / '\u56fe' / 'Fig5_B-E_hdWGCNA6_RAWP_20261009.pdf'
doc.set_metadata({'title': 'Figure 5 B-E: fixed Williams hdWGCNA six modules', 'subject': 'Exploratory disease-vitamin D direction analysis; unadjusted P'})
doc.save(pdf)
doc.close()
with fitz.open(pdf) as check:
    txt = check[0].get_text()
    for m in mods:
        assert m in txt
    assert 'Vitamin-D signatures' in txt and 'GDF15 virtual-KO' in txt
    assert len(check) == 1
    qa['pdf_pages'] = len(check)
    qa['all_six_module_labels_in_pdf'] = True
(out / 'other' / 'QA.json').write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(qa, ensure_ascii=False, indent=2))
print(pdf)
