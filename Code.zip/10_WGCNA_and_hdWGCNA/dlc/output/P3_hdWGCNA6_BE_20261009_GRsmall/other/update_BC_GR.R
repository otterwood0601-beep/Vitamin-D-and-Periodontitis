options(stringsAsFactors=FALSE)
.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fgsea);library(ggplot2);library(jsonlite)})
set.seed(20261009)
OLD <- 'C:/wb_links/dlc/output/P3_hdWGCNA6_BE_20261009/other'
OUT <- 'C:/Users/Lin/AppData/Local/Temp/p3_hd6_BE_20261009_GRsmall'
sd<-file.path(OUT,'source_data'); fig<-file.path(OUT,'panels')
dir.create(sd,recursive=TRUE,showWarnings=FALSE);dir.create(fig,recursive=TRUE,showWarnings=FALSE)
stopifnot(all(file.copy(list.files(file.path(OLD,'source_data'),full.names=TRUE),sd,overwrite=TRUE)))
mods<-c('green','blue','turquoise','red','yellow','brown')
shared<-fread(file.path(sd,'02_shared_gene_statistics_hd_membership.csv'))
rkD<-sort(setNames(shared$t,shared$gene),decreasing=TRUE)
sg<-fread(file.path(sd,'04_BC_VD_signatures_by_module.csv'))
gb<-fread(file.path(sd,'05_BC_signature_GSEA_rawP.csv'))
vs<-setNames(lapply(gb$pathway,function(n)sg[pathway==n]$gene),gb$pathway)
smallnames<-gb[module%in%c('green','red')]$pathway
stopifnot(length(smallnames)==4,identical(unname(sort(lengths(vs[smallnames]))),c(4L,4L,5L,7L)))

ans<-as.data.table(fgseaMultilevel(pathways=vs[smallnames],stats=rkD,minSize=1,maxSize=5000,eps=0,nPermSimple=10000,nproc=1))
ans[,leadingEdge:=vapply(leadingEdge,paste,collapse=';',FUN.VALUE=character(1))]
ans[,padj:=NULL]
stopifnot(nrow(ans)==4,all(is.finite(ans$NES)),all(is.finite(ans$pval)))
for(n in smallnames){
 for(col in c('pval','log2err','ES','NES','leadingEdge')) set(gb,i=which(gb$pathway==n),j=col,value=ans[pathway==n][[col]])
 gb[pathway==n,status:='tested']
}
gb[,minimum_size_applied:=ifelse(module%in%c('green','red'),1L,15L)]
gb[,small_set_exception:=module%in%c('green','red')]
fwrite(gb,file.path(sd,'05_BC_signature_GSEA_rawP.csv'))
fwrite(ans,file.path(sd,'11_GR_small_sets_new_GSEA_rawP.csv'))

code<-readLines(file.path(OLD,'run_hd6.R'),warn=FALSE)
first<-which(startsWith(code,'TH <-'))
last<-which(startsWith(code,'mc[,star:='))-1L
stopifnot(length(first)==1,length(last)==1)
body<-paste(code[first:last],collapse='\n')
oldB<-'Positive NES: enriched toward disease-up genes. Signatures with fewer than 15 genes are not tested.'
newB<-'Positive NES: disease-up enrichment. Green/red: small gene sets (n=4-7); other modules retain the 15-gene minimum.'
oldC<-'Curves shown only for tested signatures (at least 15 genes); no curve is imputed for smaller sets.'
newC<-'Green/red: no 15-gene cutoff (n=4-7). Other modules retain the original 15-gene minimum.'
stopifnot(grepl(oldB,body,fixed=TRUE),grepl(oldC,body,fixed=TRUE))
body<-gsub(oldB,newB,body,fixed=TRUE);body<-gsub(oldC,newC,body,fixed=TRUE)
eval(parse(text=body))
if(max(abs(run$ES))>.8){
 newlim<-ceiling(max(abs(run$ES))*10)/10
 pC<-pC+scale_y_continuous(limits=c(-newlim,newlim))
} else newlim<-.8
for(n in c('B','C')){
 p<-if(n=='B')pB else pC
 h<-if(n=='B')4.6 else 5
 ggsave(file.path(fig,paste0('Fig5',n,'_hdWGCNA6_rawP.pdf')),p,width=10,height=h,device=cairo_pdf)
 ggsave(file.path(fig,paste0('Fig5',n,'_hdWGCNA6_rawP.png')),p,width=10,height=h,dpi=180,device=grDevices::png,type='cairo')
}
for(n in c('D','E'))for(ext in c('pdf','png')) {
 f<-paste0('Fig5',n,'_hdWGCNA6_rawP.',ext)
 stopifnot(file.copy(file.path(OLD,'panels',f),file.path(fig,f),overwrite=TRUE))
}
summary<-fromJSON(file.path(OLD,'summary.json'),simplifyVector=FALSE)
summary$signature_results<-as.data.frame(gb[,.(module,direction,size,NES,pval,status,minimum_size_applied,small_set_exception)])
summary$rules$BC_minimum_size<-list(green=1,red=1,blue=15,turquoise=15,yellow=15,brown=15)
summary$rules$BC_revision<-'User requested no 15-gene minimum for green and red only. Four sets newly tested; all other results reused exactly.'
summary$rules$C_axis_absolute_limit<-newlim
writeLines(toJSON(summary,pretty=TRUE,auto_unbox=TRUE,na='null',digits=12),file.path(OUT,'summary.json'))
print(gb[module%in%c('green','red'),.(module,direction,size,NES,pval)])
cat('[DONE] only green/red B/C updated; D/E copied unchanged\n')
