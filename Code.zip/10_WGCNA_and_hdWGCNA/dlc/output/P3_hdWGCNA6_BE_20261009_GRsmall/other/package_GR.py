from pathlib import Path
import hashlib
import pandas as pd
old = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\P3_hdWGCNA6_BE_20261009\\other')
new = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\P3_hdWGCNA6_BE_20261009_GRsmall\\other')
temp = Path('C:\\Users\\Lin\\AppData\\Local\\Temp\\p3_hd6_BE_20261009_GRsmall')
before = pd.read_csv(old / 'source_data/05_BC_signature_GSEA_rawP.csv')
after = pd.read_csv(temp / 'source_data/05_BC_signature_GSEA_rawP.csv')
keep = ~before.module.isin(['green', 'red'])
pd.testing.assert_frame_equal(before.loc[keep].reset_index(drop=True), after.loc[~after.module.isin(['green', 'red']), before.columns].reset_index(drop=True))
for name in ['01_fixed_hdWGCNA_membership.csv', '02_shared_gene_statistics_hd_membership.csv', '04_BC_VD_signatures_by_module.csv', '06_D_module_GSEA_rawP.csv', '07_D_direction_summary_rawP.csv', '08_E_KO_module_Fisher_rawP.csv']:
    assert (old / 'source_data' / name).read_bytes() == (temp / 'source_data' / name).read_bytes(), name
for n in ['D', 'E']:
    f = f'Fig5{n}_hdWGCNA6_rawP.pdf'
    assert (old / 'panels' / f).read_bytes() == (temp / 'panels' / f).read_bytes(), f
code = (old / 'package_hd6.py').read_text(encoding='utf-8')
replacements = {"p3_hd6_BE_20261009'": "p3_hd6_BE_20261009_GRsmall'", "P3_hdWGCNA6_BE_20261009')": "P3_hdWGCNA6_BE_20261009_GRsmall')", "assert (row.status=='tested') == (len(expected)>=15)": "assert (row.status=='tested') == (len(expected)>=(1 if row.module in ['green','red'] else 15))", 'if len(expected)<15:': "if row.module not in ['green','red'] and len(expected)<15:", "assert curves.ES.between(-.8,.8).all(), 'Curve exceeds plotted y range'": "assert curves.ES.between(-summary['rules']['C_axis_absolute_limit'],summary['rules']['C_axis_absolute_limit']).all()", 'B/C signatures use raw P < 0.05 and at least 15 genes. The earlier 13-module figures are preserved.': 'B/C: raw P < 0.05; green/red small sets included (n=4-7); other modules retain the 15-gene minimum.', 'Fig5_B-E_hdWGCNA6_RAWP_20261009.pdf': 'Fig5_B-E_hdWGCNA6_RAWP_20261009_GRsmall.pdf', "'old_figures_preserved':True": "'old_figures_preserved':True,'DE_PDFs_byte_identical':True,'BC_other_modules_exactly_unchanged':True"}
for a, b in replacements.items():
    assert a in code, a
    code = code.replace(a, b)
(new / 'resolved_package_GR.py').write_text(code, encoding='utf-8')
exec(compile(code, str(new / 'resolved_package_GR.py'), 'exec'))
