suppressMessages({
  library(Seurat)
  pkgload::load_all("C:/wb_links/hdWGCNA", quiet = TRUE)
  library(WGCNA)
})
options(stringsAsFactors = FALSE)

DER <- "C:/wb_links/dlc_derived"
OUT <- file.path(DER, "P2hd")
dir.create(OUT, showWarnings = FALSE, recursive = TRUE)

obj <- readRDS("C:/wb_links/fb_rds/all_conditions_allStudies_CELLxGENE_direct_fibroblast_counts_only.rds")
cellmeta <- as.data.frame(data.table::fread("C:/wb_links/fig4_src/01_cell_metadata_UMAP_GDF15.csv.gz"))
inv <- as.data.frame(data.table::fread(file.path(DER, "sample_inventory_GSE164241.csv")))
gsm2donor <- setNames(inv$donor_merged, inv$gsm)
merge_donor <- function(d) {
  g <- sub(".*(GSM[0-9]+)$", "\\1", d)
  ifelse(g %in% names(gsm2donor), paste0("Williams_", gsm2donor[g]), d)
}
cellmeta$donor_merged <- merge_donor(cellmeta$donor_id)

obj <- subset(obj, cells = cellmeta$cell_barcode)
obj$fibroblast_type <- cellmeta$fibroblast_type[match(colnames(obj), cellmeta$cell_barcode)]
obj$donor_merged <- cellmeta$donor_merged[match(colnames(obj), cellmeta$cell_barcode)]
obj$all_fib <- "fibroblast"  
cat("cells:", ncol(obj), "\n")

obj <- NormalizeData(obj, verbose = FALSE)
obj <- FindVariableFeatures(obj, nfeatures = 3000, verbose = FALSE)
obj <- ScaleData(obj, verbose = FALSE)
obj <- RunPCA(obj, npcs = 30, verbose = FALSE)

seurat_w <- SetupForWGCNA(
  obj,
  gene_select = "fraction", fraction = 0.05,
  wgcna_name = "fib"
)
seurat_w <- MetacellsByGroups(
  seurat_w,
  group.by = c("fibroblast_type", "donor_merged"),
  reduction = "pca",
  k = 10,
  max_shared = 3,
  ident.group = "fibroblast_type"
)
seurat_w <- NormalizeMetacells(seurat_w)
mc <- GetMetacellObject(seurat_w)
cat("metacells:", ncol(mc), "\n")

donor_info <- unique(cellmeta[, c("donor_merged", "Study", "disease")])
mc_meta <- mc@meta.data
mc_meta$Study <- donor_info$Study[match(mc_meta$donor_merged, donor_info$donor_merged)]
mc_meta$disease <- donor_info$disease[match(mc_meta$donor_merged, donor_info$donor_merged)]
mc@meta.data <- mc_meta
mc$all_fib <- "fibroblast"  
seurat_w <- SetMetacellObject(seurat_w, mc)
print(table(mc_meta$disease, mc_meta$fibroblast_type))

seurat_w <- SetDatExpr(
  seurat_w,
  group_name = "fibroblast",
  group.by = "all_fib",
  use_metacells = TRUE
)

expr_for_power <- GetDatExpr(seurat_w)
cat("datExpr for power test:", dim(expr_for_power), "\n")
powers <- c(1:10, seq(12, 20, 2))
sft <- WGCNA::pickSoftThreshold(expr_for_power, powerVector = powers,
                                networkType = "signed", verbose = 0)
print(sft$fitIndices)
pdf(file.path(OUT, "P2hd_softthreshold.pdf"), width = 8, height = 4)
par(mfrow = c(1, 2))
plot(sft$fitIndices[, 1], -sign(sft$fitIndices[, 3]) * sft$fitIndices[, 2],
     xlab = "Soft threshold power", ylab = "Scale-free fit R^2", type = "n",
     main = "Scale independence")
text(sft$fitIndices[, 1], -sign(sft$fitIndices[, 3]) * sft$fitIndices[, 2],
     labels = powers, cex = 0.8, col = "red")
abline(h = 0.8, col = "grey", lty = 2)
plot(sft$fitIndices[, 1], sft$fitIndices[, 5], xlab = "Soft threshold power",
     ylab = "Mean connectivity", type = "n", main = "Mean connectivity")
text(sft$fitIndices[, 1], sft$fitIndices[, 5], labels = powers, cex = 0.8, col = "red")
dev.off()

r2 <- -sign(sft$fitIndices[, 3]) * sft$fitIndices[, 2]
cand <- which(r2 >= 0.8)
soft_power <- if (length(cand)) powers[min(cand)] else powers[which.max(r2)]
cat("chosen softPower:", soft_power, "\n")

seurat_w <- ConstructNetwork(
  seurat_w,
  soft_power = soft_power,
  networkType = "signed",
  TOMType = "signed",
  minModuleSize = 30,
  mergeCutHeight = 0.25,
  deepSplit = 2,
  overwriteDatExpr = TRUE,
  overwrite_tom = TRUE,
  verbose = 1
)

seurat_w <- ModuleEigengenes(seurat_w)
seurat_w <- ModuleConnectivity(seurat_w)

mods_tbl <- GetModules(seurat_w)
cat("modules:", length(unique(mods_tbl$module)) - 1, "\n")
print(table(mods_tbl$module))
write.csv(mods_tbl, file.path(OUT, "P2hd_modules.csv"), row.names = FALSE)

MEs <- tryCatch(GetMEs(seurat_w, harmonized = TRUE), error = function(e) NULL)
if (is.null(MEs) || nrow(MEs) == 0) MEs <- tryCatch(GetMEs(seurat_w, harmonized = FALSE), error = function(e) NULL)
if (is.null(MEs) || nrow(MEs) == 0) MEs <- seurat_w@misc$fib$MEs
if (is.null(MEs) || nrow(MEs) == 0) stop("MEs extraction failed")
cat("MEs dim:", dim(MEs), "
")
write.csv(data.frame(mc = rownames(MEs), MEs, check.names = FALSE),
          file.path(OUT, "P2hd_module_eigengenes.csv"), row.names = FALSE)

trait <- data.frame(
  periodontitis = as.numeric(mc_meta$disease == "periodontitis"),
  Immune = as.numeric(mc_meta$fibroblast_type == "Immune"),
  ECM_remodeling = as.numeric(mc_meta$fibroblast_type == "ECM remodeling"),
  Vascular = as.numeric(mc_meta$fibroblast_type == "Vascular"),
  Matrix_homeostasis = as.numeric(mc_meta$fibroblast_type == "Matrix homeostasis"),
  Pre_ECM = as.numeric(mc_meta$fibroblast_type == "Pre-extracellular matrix"),
  Study_Caetano = as.numeric(mc_meta$Study == "Caetano"),
  Study_Pagella = as.numeric(mc_meta$Study == "Pagella"),
  Study_Williams = as.numeric(mc_meta$Study == "Williams")
)
rownames(trait) <- rownames(mc_meta)
common_mc <- intersect(rownames(MEs), rownames(trait))
modTraitCor <- cor(MEs[common_mc, ], trait[common_mc, ], use = "p")
modTraitP <- WGCNA::corPvalueStudent(modTraitCor, length(common_mc))
write.csv(data.frame(trait = colnames(trait), t(modTraitCor), check.names = FALSE),
          file.path(OUT, "P2hd_module_trait_cor.csv"), row.names = FALSE)
write.csv(data.frame(trait = colnames(trait), t(modTraitP), check.names = FALSE),
          file.path(OUT, "P2hd_module_trait_p.csv"), row.names = FALSE)

kME <- GetKME(seurat_w)
gdf_mod <- as.character(mods_tbl$module[mods_tbl$gene_name == "GDF15"])
cat("GDF15 module:", gdf_mod, "\n")
sens <- list()
if (length(gdf_mod) && gdf_mod != "grey" && !is.na(gdf_mod)) {
  sens$gdf_kME_own <- kME["GDF15", paste0("kME", gdf_mod)]
  me_col <- paste0(gdf_mod)
  mod_genes <- mods_tbl$gene_name[mods_tbl$module == gdf_mod]
  mod_wo <- setdiff(mod_genes, "GDF15")
  
  expr_mat <- as.matrix(GetAssayData(mc, assay = "RNA", layer = "data"))
  expr_mat <- expr_mat[intersect(mod_genes, rownames(expr_mat)), common_mc, drop = FALSE]
  me_full <- WGCNA::moduleEigengenes(t(expr_mat), colors = rep(1, nrow(expr_mat)))$eigengenes[, 1]
  expr_wo <- expr_mat[setdiff(rownames(expr_mat), "GDF15"), , drop = FALSE]
  me_wo <- WGCNA::moduleEigengenes(t(expr_wo), colors = rep(1, nrow(expr_wo)))$eigengenes[, 1]
  gdf_expr <- as.numeric(expr_mat["GDF15", ])
  sens$cor_ME_with_GDF15 <- cor(me_full, gdf_expr)
  sens$cor_MEwo_with_GDF15 <- cor(me_wo, gdf_expr)
  sens$cor_ME_disease <- cor(me_full, trait[common_mc, "periodontitis"])
  sens$cor_MEwo_disease <- cor(me_wo, trait[common_mc, "periodontitis"])
  sens$cor_ME_disease_p <- WGCNA::corPvalueStudent(sens$cor_ME_disease, length(common_mc))
  sens$cor_MEwo_disease_p <- WGCNA::corPvalueStudent(sens$cor_MEwo_disease, length(common_mc))
  cat("--- GDF15 sensitivity ---\n"); print(unlist(sens))
  sens$module_n_genes <- length(mod_genes)
  sens$module_top_hub <- head(mod_genes[order(-kME[mod_genes, paste0("kME", gdf_mod)])], 15)
}
saveRDS(list(seurat_w = seurat_w, sens = sens), file.path(OUT, "P2hd_result.rds"))
write.csv(data.frame(item = names(unlist(sens[1:6])), value = unlist(sens[1:6])),
          file.path(OUT, "P2hd_GDF15_sensitivity.csv"), row.names = FALSE)
cat("DONE P2hd\n")
