suppressMessages({library(SeuratObject); library(Seurat); library(Matrix); library(WGCNA)})
allowWGCNAThreads()
options(stringsAsFactors = FALSE)

DER <- "C:/wb_links/dlc_derived"
OUT <- file.path(DER, "P2")
dir.create(OUT, showWarnings = FALSE, recursive = TRUE)

obj <- readRDS("C:/wb_links/fb_rds/all_conditions_allStudies_CELLxGENE_direct_fibroblast_counts_only.rds")
counts <- obj@assays$RNA@counts
cellmeta <- as.data.frame(data.table::fread("C:/wb_links/fig4_src/01_cell_metadata_UMAP_GDF15.csv.gz"))
inv <- as.data.frame(data.table::fread(file.path(DER, "sample_inventory_GSE164241.csv")))
gsm2donor <- setNames(inv$donor_merged, inv$gsm)
merge_donor <- function(d) {
  g <- sub(".*(GSM[0-9]+)$", "\\1", d)
  ifelse(g %in% names(gsm2donor), paste0("Williams_", gsm2donor[g]), d)
}
cellmeta$donor_merged <- merge_donor(cellmeta$donor_id)
common <- intersect(colnames(counts), cellmeta$cell_barcode)
counts <- counts[, common]
cellmeta <- cellmeta[match(common, cellmeta$cell_barcode), ]
cat("cells:", length(common), "\n")

is_sym <- !grepl("^ENSG", rownames(counts))
counts_sym <- counts[is_sym, ]

counts_sym <- counts_sym[!duplicated(rownames(counts_sym)), ]
lib <- colSums(counts_sym)
lognorm <- as.matrix(t(t(counts_sym) / lib * 1e4))
lognorm <- log1p(lognorm)
cat("genes(symbol):", nrow(lognorm), "\n")

grp <- paste(cellmeta$donor_merged, cellmeta$fibroblast_type, sep = "||")
set.seed(42)
meta_assign <- rep(NA_character_, length(grp))
CELLS_PER_MC <- 10
for (g in unique(grp)) {
  idx <- which(grp == g)
  n <- length(idx)
  if (n < 30) next  
  k <- max(2, floor(n / CELLS_PER_MC))
  
  sub <- lognorm[, idx, drop = FALSE]
  v <- apply(sub, 1, var)
  topg <- names(sort(v, decreasing = TRUE))[1:min(2000, length(v))]
  km <- kmeans(t(sub[topg, ]), centers = k, iter.max = 50, nstart = 5)
  meta_assign[idx] <- paste(g, km$cluster, sep = "::mc")
}
keep_cell <- !is.na(meta_assign)
cat("cells in metacells:", sum(keep_cell), "/", length(keep_cell), "\n")
mc_key <- factor(meta_assign[keep_cell])
mm <- fac2sparse(mc_key)
mc_counts <- as.matrix(mm %*% t(counts_sym[, keep_cell]))
mc_counts <- t(mc_counts)  
colnames(mc_counts) <- levels(mc_key)

mc_meta <- data.frame(mc = colnames(mc_counts))
parts <- do.call(rbind, strsplit(mc_meta$mc, "||", fixed = TRUE))
mc_meta$donor <- parts[, 1]
mc_meta$subtype <- sub("::mc.*$", "", parts[, 2])
donor_info <- unique(cellmeta[, c("donor_merged", "Study", "disease")])
mc_meta$Study <- donor_info$Study[match(mc_meta$donor, donor_info$donor_merged)]
mc_meta$disease <- donor_info$disease[match(mc_meta$donor, donor_info$donor_merged)]

mc_size <- as.numeric(table(mc_key))
mc_meta$n_cells <- mc_size
keep_mc <- mc_meta$n_cells >= 5
mc_counts <- mc_counts[, keep_mc]
mc_meta <- mc_meta[keep_mc, ]
cat("metacells:", ncol(mc_counts), "\n")
print(table(mc_meta$disease, mc_meta$subtype))

mc_lib <- colSums(mc_counts)
mc_logcpm <- log2(t(t(mc_counts) / mc_lib * 1e6) + 0.5)

det <- rowSums(mc_counts >= 5) >= ceiling(0.10 * ncol(mc_counts))

mad_v <- apply(mc_logcpm[det, ], 1, mad)
top_genes <- names(sort(mad_v, decreasing = TRUE))[1:min(8000, sum(det))]

top_genes <- union(top_genes, "GDF15")
datExpr <- t(mc_logcpm[top_genes, ])  
cat("WGCNA input:", dim(datExpr), "\n")
stopifnot("GDF15" %in% colnames(datExpr))

subtype_f <- factor(mc_meta$subtype)
datExpr_resid <- apply(datExpr, 2, function(x) residuals(lm(x ~ subtype_f)))
colnames(datExpr_resid) <- colnames(datExpr)
rownames(datExpr_resid) <- rownames(datExpr)

powers <- c(1:10, seq(12, 20, 2))
sft <- pickSoftThreshold(datExpr_resid, powerVector = powers, networkType = "signed", verbose = 0)
saveRDS(sft, file.path(OUT, "P2_softthreshold.rds"))
pdf(file.path(OUT, "P2_softthreshold.pdf"), width = 8, height = 4)
par(mfrow = c(1, 2))
plot(sft$fitIndices[, 1], -sign(sft$fitIndices[, 3]) * sft$fitIndices[, 2],
     xlab = "Soft threshold power", ylab = "Scale-free fit R^2", type = "n",
     main = "Scale independence")
text(sft$fitIndices[, 1], -sign(sft$fitIndices[, 3]) * sft$fitIndices[, 2],
     labels = powers, cex = 0.8, col = "red")
abline(h = 0.8, col = "grey", lty = 2)
plot(sft$fitIndices[, 1], sft$fitIndices[, 5], xlab = "Soft threshold power",
     ylab = "Mean connectivity", type = "n", main = "Mean connectivity")
text(sft$fitIndices[, 1], sft$fitIndices[, 5], labels = powers, cex = 0.8, col = "red")
dev.off()

r2 <- -sign(sft$fitIndices[, 3]) * sft$fitIndices[, 2]
cand <- which(r2 >= 0.8)
softPower <- if (length(cand)) powers[min(cand)] else powers[which.max(r2)]
cat("softPower rule: smallest power with SFT.R.sq>=0.8 ->", softPower, "
")
cat("softPower:", softPower, "\n")

net <- blockwiseModules(datExpr_resid, power = softPower, networkType = "signed",
                        TOMType = "signed", minModuleSize = 30,
                        mergeCutHeight = 0.25, deepSplit = 2,
                        numericLabels = TRUE, pamRespectsDendro = FALSE,
                        saveTOMs = FALSE, verbose = 1)
mods <- net$colors
modLabels <- sort(unique(mods))
cat("modules:", length(modLabels) - 1, "(excluding grey)\n")
print(table(mods))

MEs <- moduleEigengenes(datExpr, colors = mods)$eigengenes
MEs <- orderMEs(MEs)
kME <- signedKME(datExpr, MEs)

trait <- data.frame(
  periodontitis = as.numeric(mc_meta$disease == "periodontitis"),
  Study_Caetano = as.numeric(mc_meta$Study == "Caetano"),
  Study_Pagella = as.numeric(mc_meta$Study == "Pagella"),
  Study_Williams = as.numeric(mc_meta$Study == "Williams"),
  Immune = as.numeric(mc_meta$subtype == "Immune"),
  ECM_remodeling = as.numeric(mc_meta$subtype == "ECM remodeling"),
  Vascular = as.numeric(mc_meta$subtype == "Vascular"),
  Matrix_homeostasis = as.numeric(mc_meta$subtype == "Matrix homeostasis"),
  Pre_ECM = as.numeric(mc_meta$subtype == "Pre-extracellular matrix")
)
rownames(trait) <- mc_meta$mc
modTraitCor <- cor(MEs, trait, use = "p")
modTraitP <- corPvalueStudent(modTraitCor, nrow(datExpr))

gdf_mod <- mods["GDF15"]
gdf_kME <- kME["GDF15", ]
cat("GDF15 module:", gdf_mod, "\n")
print(round(gdf_kME, 3))

sens <- list()
if (!is.na(gdf_mod) && gdf_mod != 0) {
  mod_genes <- names(mods)[mods == gdf_mod]
  mod_genes_wo <- setdiff(mod_genes, "GDF15")
  ME_wo <- moduleEigengenes(datExpr[, mod_genes_wo], colors = rep(1, length(mod_genes_wo)))$eigengenes[, 1]
  gdf_expr <- datExpr[, "GDF15"]
  sens$cor_ME_with_GDF15 <- cor(MEs[, paste0("ME", gdf_mod)], gdf_expr)
  sens$cor_MEwo_with_GDF15 <- cor(ME_wo, gdf_expr)
  sens$cor_ME_vs_MEwo <- cor(MEs[, paste0("ME", gdf_mod)], ME_wo)
  
  sens$cor_ME_disease <- cor(MEs[, paste0("ME", gdf_mod)], trait$periodontitis)
  sens$cor_MEwo_disease <- cor(ME_wo, trait$periodontitis)
  sens$cor_MEwo_disease_p <- corPvalueStudent(sens$cor_MEwo_disease, nrow(datExpr))
  cat("--- GDF15 sensitivity ---\n"); print(unlist(sens))
}

kme_cols <- colnames(kME)  
module_tbl <- data.frame(gene = names(mods), module = mods,
                         kME_own = sapply(names(mods), function(g) {
                           cn <- paste0("kME", mods[g])
                           if (cn %in% kme_cols) kME[g, cn] else NA_real_
                         }),
                         row.names = NULL)
module_tbl <- module_tbl[order(module_tbl$module, -module_tbl$kME_own), ]
write.csv(module_tbl, file.path(OUT, "P2_modules.csv"), row.names = FALSE)
write.csv(data.frame(mc = rownames(MEs), MEs, check.names = FALSE),
          file.path(OUT, "P2_module_eigengenes.csv"), row.names = FALSE)
write.csv(mc_meta, file.path(OUT, "P2_metacell_metadata.csv"), row.names = FALSE)
write.csv(data.frame(trait = colnames(trait),
                     t(modTraitCor), check.names = FALSE),
          file.path(OUT, "P2_module_trait_cor.csv"), row.names = FALSE)
write.csv(data.frame(trait = colnames(trait),
                     t(modTraitP), check.names = FALSE),
          file.path(OUT, "P2_module_trait_p.csv"), row.names = FALSE)
saveRDS(list(net = net, MEs = MEs, kME = kME, mods = mods, softPower = softPower,
             datExpr_top_genes = top_genes, mc_meta = mc_meta, sens = sens),
        file.path(OUT, "P2_wgcna_result.rds"))
cat("DONE P2\n")
