import os, sys
import numpy as np
import pandas as pd
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from style_npj import set_npj_style, save_npj, NPJ_CASE, NPJ_CTRL, MM
from gingiva_reference import bh_fdr
set_npj_style()
BASE = 'C:\\wb_links\\serum_vit\\\u539f\u59cb\u6570\u636e\\06_\u6700\u7ec8\u6295\u7a3f\u51fa\u56fe\u6e90\u8868\\05_\u6b63\u6587\u56fe5_\u865a\u62df\u6572\u9664\\Geneformer\\08_\u6269\u5c55\u56fe\u8868_\u6570\u636e\u8868'
MOD = 'E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\P2_hdWGCNA\\outputs\\02_source_data\\03_module_gene_membership.csv'
DER = 'E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\data_derived'
OUT = 'E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\\u7b2c8\u9879_\u865a\u62df\u6270\u52a8\u7a33\u5065\u6027'
os.makedirs(DER, exist_ok=True)
os.makedirs(OUT, exist_ok=True)
d = pd.read_csv(os.path.join(BASE, 'GDF15_downstream_gene_evidence_summary.csv'))
d = d[d['cohort'].isin(['Williams', 'Caetano'])].copy()
mod = pd.read_csv(MOD)[['gene_name', 'module']].drop_duplicates('gene_name')
d = d.merge(mod, left_on='Gene_name', right_on='gene_name', how='left')
d['module'] = d['module'].fillna('not_in_network')
d.to_csv(os.path.join(DER, 'C8_GDF15_downstream_hdWGCNA_gene_map.csv'), index=False)
rows = []
for (scenario, cohort), z in d.groupby(['scenario', 'cohort'], observed=True):
    background = z['Mean_token_cosine_shift'].dropna()
    for module, x in z.groupby('module', observed=True):
        vals = x['Mean_token_cosine_shift'].dropna()
        rest = z.loc[z['module'] != module, 'Mean_token_cosine_shift'].dropna()
        if len(vals) >= 3 and len(rest) >= 3:
            u = stats.mannwhitneyu(vals, rest, alternative='two-sided')
            delta = (np.subtract.outer(vals.to_numpy(), rest.to_numpy()) > 0).mean() - (np.subtract.outer(vals.to_numpy(), rest.to_numpy()) < 0).mean()
            p = u.pvalue
        else:
            delta = np.nan
            p = np.nan
        rng = np.random.default_rng(20260914)
        boots = [rng.choice(vals, len(vals), replace=True).mean() for _ in range(2000)] if len(vals) else [np.nan]
        rows.append({'scenario': scenario, 'cohort': cohort, 'module': module, 'n_genes': len(vals), 'mean_shift': vals.mean(), 'median_shift': vals.median(), 'mean_all_tested_genes': background.mean(), 'mean_shift_CI95_low': np.nanpercentile(boots, 2.5), 'mean_shift_CI95_high': np.nanpercentile(boots, 97.5), 'cliffs_delta_vs_other_modules': delta, 'MWU_p': p})
res = pd.DataFrame(rows)
res['MWU_FDR'] = res.groupby(['scenario', 'cohort'])['MWU_p'].transform(lambda x: bh_fdr(x.to_numpy()))
res.to_csv(os.path.join(DER, 'C8_GDF15_hdWGCNA_module_comparison.csv'), index=False)
cross_rows = []
for scenario, z in d.groupby('scenario', observed=True):
    w = z[z.cohort == 'Williams'][['Gene_name', 'Mean_token_cosine_shift']].rename(columns={'Mean_token_cosine_shift': 'Williams'})
    c = z[z.cohort == 'Caetano'][['Gene_name', 'Mean_token_cosine_shift']].rename(columns={'Mean_token_cosine_shift': 'Caetano'})
    m = w.merge(c, on='Gene_name').dropna()
    rho, p = stats.spearmanr(m.Williams, m.Caetano)
    cross_rows.append({'scenario': scenario, 'level': 'gene', 'n': len(m), 'spearman_rho': rho, 'p': p})
    mm = res[(res.scenario == scenario) & res.module.isin(['green', 'turquoise', 'yellow', 'blue', 'brown', 'red'])].pivot(index='module', columns='cohort', values='mean_shift').dropna()
    rho2, p2 = stats.spearmanr(mm.Williams, mm.Caetano) if len(mm) >= 3 else (np.nan, np.nan)
    cross_rows.append({'scenario': scenario, 'level': 'module', 'n': len(mm), 'spearman_rho': rho2, 'p': p2})
cross = pd.DataFrame(cross_rows)
cross.to_csv(os.path.join(DER, 'C8_GDF15_module_cross_cohort_robustness.csv'), index=False)
modules = [m for m in ['green', 'turquoise', 'yellow', 'blue', 'brown', 'red'] if m in set(res.module)]
scenarios = ['Periodontitis_GDF15_KO_to_Healthy', 'Healthy_GDF15_OE_to_Periodontitis']
fig = plt.figure(figsize=(180 * MM, 105 * MM))
gs = fig.add_gridspec(2, 2, left=0.08, right=0.98, bottom=0.12, top=0.88, wspace=0.34, hspace=0.55)
colors = {'Williams': NPJ_CASE, 'Caetano': NPJ_CTRL}
for col, scenario in enumerate(scenarios):
    ax = fig.add_subplot(gs[0, col])
    zz = res[(res.scenario == scenario) & res.module.isin(modules)]
    for j, cohort in enumerate(['Williams', 'Caetano']):
        q = zz[zz.cohort == cohort].set_index('module').reindex(modules)
        x = np.arange(len(modules)) + (-0.12 if j == 0 else 0.12)
        ax.errorbar(x, q.mean_shift, yerr=[q.mean_shift - q.mean_shift_CI95_low, q.mean_shift_CI95_high - q.mean_shift], fmt='o', ms=3.2, lw=0.7, capsize=1.5, color=colors[cohort], label=cohort)
    ax.set_xticks(range(len(modules)))
    ax.set_xticklabels(modules, rotation=35, ha='right')
    ax.set_ylabel('Mean token-cosine shift')
    title = 'GDF15 deletion: PD \u2192 healthy' if 'KO' in scenario else 'GDF15 overexpression: healthy \u2192 PD'
    ax.set_title(title, bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=.35'))
    if col == 0:
        ax.legend(frameon=False, loc='best')
    fig.text(0.045 + col * 0.48, 0.925, chr(65 + col), fontsize=12, fontweight='bold')
for col, scenario in enumerate(scenarios):
    ax = fig.add_subplot(gs[1, col])
    q = d[d.scenario == scenario].pivot_table(index='Gene_name', columns='cohort', values='Mean_token_cosine_shift').dropna()
    ax.scatter(q.Williams, q.Caetano, s=6, c='#8F8F8F', alpha=0.65, lw=0, rasterized=True)
    rho, p = stats.spearmanr(q.Williams, q.Caetano)
    ax.text(0.04, 0.96, f'Spearman \u03c1={rho:.2f}\np={p:.2g}; n={len(q)} genes', transform=ax.transAxes, va='top', fontsize=6.5)
    ax.set_xlabel('Williams mean shift')
    ax.set_ylabel('Caetano mean shift')
    ax.set_title('Cross-cohort gene concordance', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=.35'))
    fig.text(0.045 + col * 0.48, 0.475, chr(67 + col), fontsize=12, fontweight='bold')
save_npj(fig, os.path.join(OUT, '\u7b2c8\u9879_GDF15\u6270\u52a8_hdWGCNA\u6a21\u5757\u5bf9\u7167_20260914'), 180, 105, 600)
print(res.sort_values(['scenario', 'cohort', 'MWU_FDR']).to_string(index=False))
print(cross.to_string(index=False))
