options(stringsAsFactors = FALSE)
source("E:/\u8840\u6e05\u7ef4\u751f\u7d20D DLC/00_\u5171\u7528\u914d\u7f6e/project_paths.R")
ensure_dirs("01_\u6570\u636e\u51c6\u5907")

suppressPackageStartupMessages({
  library(Seurat); library(SeuratObject); library(Matrix)
  library(data.table)
})

set.seed(20260910L)
t0 <- Sys.time()
cat("[1] reading seurat object:", FB_RDS, "\n"); flush.console()
fb <- readRDS(FB_RDS)
cat("    dims:", nrow(fb), "x", ncol(fb), "\n")

cat("[2] reading mapping tables\n")
cm <- fread(CELL_MAP)
fm <- fread(FIVE_MAP)
um <- fread(CELL_UMAP_GZ)
stopifnot(nrow(cm) == ncol(fb))

mi <- match(colnames(fb), cm$cell_barcode)
stopifnot(!any(is.na(mi)))
fb$fb_id  <- cm$fb_id[mi]
fb$cluster_raw <- as.character(cm$cluster_raw[mi])

fm2 <- fm[fm$action != "delete", ]
type_of <- setNames(fm2$final_fibroblast_type, fm2$original_fb_id)
fb$fibroblast_type   <- unname(type_of[fb$fb_id])
fb$fibroblast_short  <- unname(FIVE_SHORT[fb$fibroblast_type])
keep <- !is.na(fb$fibroblast_type)
fb <- fb[, keep]
cat("    retained cells after FB8 exclusion:", ncol(fb), "\n")

ui <- match(colnames(fb), um$cell_barcode)
cat("    UMAP matched:", sum(!is.na(ui)), "/", ncol(fb), "\n")

if (any(is.na(ui))) {
  drop <- colnames(fb)[is.na(ui)]
  cat("    dropped cells not present in submitted panel (gingivitis by contract):",
      length(drop), "\n")
  fb <- fb[, !is.na(ui)]
  ui <- match(colnames(fb), um$cell_barcode)
}
fb$frozen_umap_1 <- um$UMAP_1[ui]
fb$frozen_umap_2 <- um$UMAP_2[ui]
stopifnot(sum(is.na(ui)) == 0)

fb$fibroblast_type  <- factor(fb$fibroblast_type,  levels = FIVE_ORDER)
fb$fibroblast_short <- factor(fb$fibroblast_short, levels = unname(FIVE_SHORT[FIVE_ORDER]))
fb$disease <- factor(as.character(fb$disease), levels = c("normal", "periodontitis"))

cat("[3] normalization + variable features + PCA (npcs = 50)\n"); flush.console()
fb <- NormalizeData(fb, verbose = FALSE)
fb <- FindVariableFeatures(fb, nfeatures = 2000, verbose = FALSE)
fb <- ScaleData(fb, features = VariableFeatures(fb), verbose = FALSE)
fb <- RunPCA(fb, features = VariableFeatures(fb), npcs = 50, verbose = FALSE)

emb <- as.matrix(fb[[]][, c("frozen_umap_1", "frozen_umap_2")])
colnames(emb) <- c("UMAP_1", "UMAP_2")
fb[["frozen_umap"]] <- CreateDimReducObject(
  embeddings = emb[colnames(fb), , drop = FALSE],
  key = "UMAP_", assay = DefaultAssay(fb))

cat("[4] GDF15 log-normalized expression\n")
fb$GDF15_log_normalized <- as.numeric(GetAssayData(fb, layer = "data")["GDF15", ])

out_rds <- file.path(WORK, "01_\u6570\u636e\u51c6\u5907/outputs/fb_seurat_annotated.rds")
saveRDS(fb, out_rds)
cat("    saved:", out_rds, " size:", round(file.size(out_rds)/1e6), "MB\n")

md <- fb[[]]
md$cell_barcode <- rownames(md)
fwrite(md, file.path(WORK, "01_\u6570\u636e\u51c6\u5907/outputs/01_per_cell_metadata.csv.gz"))

qa <- list(
  created_at = format(Sys.time()), retained_cells = ncol(fb),
  genes = nrow(fb),
  by_study_disease = as.data.frame(table(fb$Study, fb$disease)),
  by_type_disease = as.data.frame(table(fb$fibroblast_short, fb$disease)),
  donors = data.frame(table(fb$donor_id, fb$disease)),
  sessionInfo = paste(capture.output(sessionInfo()), collapse = "\n")
)
writeLines(jsonlite::toJSON(qa, pretty = TRUE, auto_unbox = TRUE),
           file.path(WORK, "01_\u6570\u636e\u51c6\u5907/outputs/02_QA_prepare.json"))
cat("[done] elapsed:", round(difftime(Sys.time(), t0, units = "mins"), 1), "min\n")
