from pathlib import Path
import gzip, itertools, json, shutil, sys
import numpy as np
import pandas as pd
from scipy.stats import t
from PIL import Image
import fitz
sys.stdout.reconfigure(encoding='utf8')
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
OUT = ROOT / 'output' / 'GDF15_\u6210\u7ea4\u7ef4\u7ec6\u80de\u5f71\u54cd_AB_20261008'
SD, FIG, CODE = [OUT / x for x in ['source_data', 'figures', 'code']]
a = pd.read_csv(SD / '04_FANTOM5_paired_GDF15_expression.csv')
ast = pd.read_csv(SD / '05_FANTOM5_paired_GDF15_statistics.csv').iloc[0]
assert len(a) == 6 and a.donor.nunique() == 3
assert not a.duplicated(['donor', 'condition']).any()
peaks = pd.read_csv(SD / '02_FANTOM5_GDF15_promoter_counts_all_GFs.csv', index_col=0)
ann = pd.read_csv(SD / '01_FANTOM5_GDF15_promoter_annotations.csv')
assert set(peaks.index) == set(ann['00Annotation'])
assert (ann.entrezgene_id == 'entrezgene:9518').all()
for _, r in a.iterrows():
    assert r.GDF15_peak_count == int(peaks[r['sample']].sum())
    assert np.isclose(r.GDF15_log2_TPM, np.log2(r.GDF15_peak_count / r.mapped_CAGE_tags * 1000000.0 + 0.5))
pv = a.pivot(index='donor', columns='condition', values='GDF15_log2_TPM')
delta = (pv.Periodontitis - pv['Healthy site']).to_numpy()
exact = np.mean([abs(np.mean(delta * np.array(v))) >= abs(delta.mean()) - 1e-12 for v in itertools.product([-1, 1], repeat=3)])
assert np.isclose(exact, ast.exact_sign_flip_two_sided_p)
p1 = ann[ann.short_description == 'p1@GDF15']['00Annotation'].iloc[0]
ps = []
for _, r in a.iterrows():
    ps.append(dict(donor=r.donor, condition=r.condition, p1_count=int(peaks.loc[p1, r['sample']]), p1_log2_CPM=float(np.log2(peaks.loc[p1, r['sample']] / r.mapped_CAGE_tags * 1000000.0 + 0.5))))
ps = pd.DataFrame(ps)
ps.to_csv(SD / '12_FANTOM5_dominant_promoter_sensitivity.csv', index=False)
p1v = ps.pivot(index='donor', columns='condition', values='p1_log2_CPM')
p1d = p1v.Periodontitis - p1v['Healthy site']
inputs = pd.read_csv(SD / '06_bulk_model_input.csv')
models = pd.read_csv(SD / '07_bulk_four_models_and_HC3.csv')
checks = []
for _, r in models[models.variance == 'OLS'].iterrows():
    ds = inputs[inputs.dataset == r.dataset]
    cols = r.formula.split(' ~ ')[1].split(' + ')
    X = np.column_stack([np.ones(len(ds)), ds[cols].to_numpy()])
    y = ds.GDF15_log2_CPM.to_numpy()
    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    df = len(ds) - X.shape[1]
    s2 = np.sum((y - X @ beta) ** 2) / df
    se = np.sqrt(np.diag(np.linalg.inv(X.T @ X) * s2))[1]
    ci = beta[1] + np.array([-1, 1]) * t.ppf(0.975, df) * se
    p = 2 * t.sf(abs(beta[1] / se), df)
    assert np.allclose([beta[1], *ci, p], [r.PD_beta, r.PD_CI_low, r.PD_CI_high, r.PD_p], rtol=1e-08, atol=1e-10)
    checks.append(dict(dataset=r.dataset, model=r.model, independent_beta=float(beta[1]), independent_P=float(p)))
pd.DataFrame(checks).to_csv(SD / '13_independent_model_QA.csv', index=False)
exports = []
for png in FIG.glob('*.png'):
    im = Image.open(png)
    exports.append(dict(file=png.name, width=im.width, height=im.height, dpi=im.info.get('dpi')))
    assert im.width > 600 and im.height > 600
pdfs = []
for pdf in FIG.glob('*.pdf'):
    doc = fitz.open(pdf)
    page = doc[0]
    texts = page.get_text()
    assert 'GDF15' in texts
    fonts = page.get_fonts()
    assert any(('Arial' in font[3] for font in fonts))
    clipped = []
    for block in page.get_text('dict')['blocks']:
        for line in block.get('lines', []):
            for span in line['spans']:
                r = fitz.Rect(span['bbox'])
                if r.x0 < -0.5 or r.y0 < -0.5 or r.x1 > page.rect.width + 0.5 or (r.y1 > page.rect.height + 0.5):
                    clipped.append(span['text'])
    assert not clipped, clipped
    pdfs.append(dict(file=pdf.name, pages=len(doc), width_pt=page.rect.width, height_pt=page.rect.height, fonts=[f[3] for f in fonts], out_of_page_text=clipped))
    if pdf.name.startswith('GDF15_'):
        page.get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False).save(SD / '14_combined_PDF_render_QA.png')
    doc.close()
qa = dict(status='PASS', paired_samples=6, paired_patients=3, A_exact_P=float(exact), A_p1_mean_difference=float(p1d.mean()), A_p1_pairs_increased=int((p1d > 0).sum()), B_independently_verified_models=len(checks), png_exports=exports, PDF_exports=pdfs, visual_check='Combined PNG and independently rendered PDF must be inspected by the assistant')
(SD / '15_verification.json').write_text(json.dumps(qa, indent=2, ensure_ascii=False), encoding='utf8')
shutil.copy2(__file__, CODE / Path(__file__).name)
print(json.dumps(qa, indent=2, ensure_ascii=False), flush=True)
