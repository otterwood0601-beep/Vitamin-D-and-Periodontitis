options(stringsAsFactors = FALSE, scipen = 999)
set.seed(20260925)

.libPaths(c("C:/wb_temp/no2uc_Rlib_20260925", .libPaths()))

suppressPackageStartupMessages({
  library(Seurat)
  library(AUCell)
  library(data.table)
  library(Matrix)
  library(edgeR)
  library(limma)
  library(jsonlite)
})

OUT <- "C:/wb_links/jhazmat2026_no2uc_20260925"
SD <- file.path(OUT, "source_data")
FD <- file.path(OUT, "figures")
dir.create(SD, recursive = TRUE, showWarnings = FALSE)
dir.create(FD, recursive = TRUE, showWarnings = FALSE)

FB <- "C:/wb_links/dlc_data/outputs/fb_seurat_annotated.rds"
PREV <- "C:/wb_links/tranoncol2026_Williams_20260920/05_cell_marker_and_program_scores.csv.gz"
SIG <- "C:/wb_links/bioorgchem2026_20260924/source_data/09_vitaminD_gingiva_overlap_genes.csv"

zscore <- function(x) {
  s <- stats::sd(x, na.rm = TRUE)
  if (!is.finite(s) || s == 0) return(rep(0, length(x)))
  (x - mean(x, na.rm = TRUE)) / s
}

safe_spearman <- function(x, y) {
  ok <- is.finite(x) & is.finite(y)
  if (sum(ok) < 4 || length(unique(x[ok])) < 2 || length(unique(y[ok])) < 2) {
    return(list(rho = NA_real_, p = NA_real_, n = sum(ok)))
  }
  ans <- suppressWarnings(stats::cor.test(x[ok], y[ok], method = "spearman", exact = FALSE))
  list(rho = unname(ans$estimate), p = ans$p.value, n = sum(ok))
}

paired_wilcox <- function(dt, value_col) {
  z <- dt[n_cells >= 5, .(value = mean(get(value_col), na.rm = TRUE)),
          by = .(pair_id, score_group)]
  w <- dcast(z, pair_id ~ score_group, value.var = "value")
  if (!all(c("Low", "High") %in% names(w))) {
    return(list(p = NA_real_, n_pairs = 0L, median_delta = NA_real_))
  }
  w <- w[is.finite(Low) & is.finite(High)]
  if (nrow(w) < 3) {
    return(list(p = NA_real_, n_pairs = nrow(w), median_delta = median(w$High - w$Low)))
  }
  wt <- suppressWarnings(wilcox.test(w$High, w$Low, paired = TRUE, exact = FALSE))
  list(p = wt$p.value, n_pairs = nrow(w), median_delta = median(w$High - w$Low))
}

message("[1/8] Loading Williams human gingival fibroblasts")
fb_all <- readRDS(FB)
fb <- subset(fb_all, subset = Study == "Williams")
rm(fb_all); invisible(gc())
DefaultAssay(fb) <- "RNA"
stopifnot(ncol(fb) == 14302)

meta <- as.data.table(fb[[]], keep.rownames = "cell_id")
setnames(meta, "fibroblast_short", "state")
meta[, disease := factor(disease, levels = c("normal", "periodontitis"))]
meta[, state := factor(state, levels = c("Immune", "ECM remodeling", "Vascular",
                                         "Pre-ECM", "Matrix homeostasis"))]

prev <- fread(PREV)
setnames(prev, "fibroblast_short", "state_prev")
prev <- prev[, .(cell_id, frozen_umap_1, frozen_umap_2, GDF15,
                 MAPK1, MAPK3, MAPK_ERK, ECM_degradation)]
cells <- merge(meta[, .(cell_id, donor_id, disease, state, sample_id)], prev,
               by = "cell_id", all.x = TRUE, sort = FALSE)
stopifnot(nrow(cells) == ncol(fb), !anyDuplicated(cells$cell_id))

message("[2/8] Auditing predefined 17-gene vitamin-D/VDR-gingival intersection")
sig <- fread(SIG)
sig_genes <- unique(sig$gene)
norm <- GetAssayData(fb, assay = "RNA", layer = "data")
counts <- GetAssayData(fb, assay = "RNA", layer = "counts")
sig_present <- intersect(sig_genes, rownames(norm))
if (length(sig_present) < 5) stop("Too few signature genes are present in Williams data")

sig_audit <- data.table(gene = sig_genes)
sig_audit[sig, on = "gene", `:=`(bulk_logFC = i.logFC, bulk_FDR = i.FDR)]
sig_audit[, present_in_Williams := gene %in% rownames(norm)]
sig_audit[, detection_fraction := NA_real_]
sig_audit[present_in_Williams == TRUE,
          detection_fraction := Matrix::rowMeans(counts[gene, , drop = FALSE] > 0)]
fwrite(sig_audit, file.path(SD, "01_VD17_signature_gene_audit.csv"))

message("[3/8] Computing Seurat AddModuleScore")
fb <- AddModuleScore(
  object = fb,
  features = list(sig_present),
  assay = "RNA",
  name = "VD17_AddModuleScore",
  ctrl = 100,
  nbin = 24,
  seed = 20260925,
  search = FALSE
)
add_scores <- data.table(
  cell_id = colnames(fb),
  AddModuleScore = fb$VD17_AddModuleScore1
)

message("[4/8] Computing AUCell rank-based score")

auc_keep <- Matrix::rowSums(counts > 0) >= 10 | rownames(counts) %in% sig_present
auc_expr <- norm[auc_keep, , drop = FALSE]
rankings <- AUCell_buildRankings(
  auc_expr,
  plotStats = FALSE,
  nCores = 1,
  splitByBlocks = TRUE,
  verbose = TRUE
)
auc_max_rank <- max(50L, ceiling(0.05 * nrow(auc_expr)))
auc_obj <- AUCell_calcAUC(
  geneSets = list(VD17 = sig_present),
  rankings = rankings,
  aucMaxRank = auc_max_rank,
  nCores = 1
)
auc_mat <- getAUC(auc_obj)
auc_scores <- data.table(
  cell_id = colnames(auc_mat),
  AUCell = as.numeric(auc_mat["VD17", ])
)
rm(rankings, auc_obj, auc_mat, auc_expr); invisible(gc())

cells[add_scores, on = "cell_id", AddModuleScore := i.AddModuleScore]
cells[auc_scores, on = "cell_id", AUCell := i.AUCell]
stopifnot(!anyNA(cells$AddModuleScore), !anyNA(cells$AUCell))
cells[, AddModuleScore_z := zscore(AddModuleScore)]
cells[, AUCell_z := zscore(AUCell)]
cells[, consensus_score := (AddModuleScore_z + AUCell_z) / 2]

cells[, score_group := ifelse(
  consensus_score > median(consensus_score, na.rm = TRUE), "High", "Low"
), by = .(donor_id, state)]
cells[, score_group := factor(score_group, levels = c("Low", "High"))]
cells[, pair_id := paste(donor_id, state, sep = "||")]

message("[5/8] Preparing dot-plot expression and donor-level summaries")
selected_genes <- intersect(
  c("AQP3", "CYP24A1", "IGFBP3", "KLF4", "LGMN", "RXRA", "SPP1",
    "GDF15", "MAPK3", "MAPK1", "MMP1", "MMP2", "MMP3", "MMP9", "MMP14"),
  rownames(norm)
)
dot_rows <- vector("list", length(selected_genes))
for (i in seq_along(selected_genes)) {
  g <- selected_genes[i]
  v <- as.numeric(norm[g, cells$cell_id])
  tmp <- data.table(state = cells$state, value = v)
  dot_rows[[i]] <- tmp[, .(
    average_expression = mean(value),
    percent_detected = mean(value > 0) * 100
  ), by = state][, gene := g]
}
dot_dt <- rbindlist(dot_rows)
dot_dt[, gene := factor(gene, levels = rev(selected_genes))]
fwrite(dot_dt, file.path(SD, "02_selected_gene_dotplot.csv"))

cell_out <- cells[, .(
  cell_id, frozen_umap_1, frozen_umap_2, donor_id, disease, state,
  AddModuleScore, AUCell, AddModuleScore_z, AUCell_z, consensus_score,
  score_group, GDF15, MAPK1, MAPK3, MAPK_ERK, ECM_degradation
)]
fwrite(cell_out, file.path(SD, "03_Williams_VD17_dual_scores.csv.gz"))

donor_scores <- cells[, .(
  AddModuleScore = median(AddModuleScore),
  AUCell = median(AUCell),
  consensus_score = median(consensus_score),
  n_cells = .N
), by = .(donor_id, disease)]
state_scores <- cells[, .(
  AddModuleScore = median(AddModuleScore),
  AUCell = median(AUCell),
  consensus_score = median(consensus_score),
  n_cells = .N
), by = .(donor_id, disease, state)]
fwrite(donor_scores, file.path(SD, "04_donor_score_summary.csv"))
fwrite(state_scores, file.path(SD, "05_donor_state_score_summary.csv"))

endpoint_agg <- cells[, .(
  consensus_score = median(consensus_score),
  AddModuleScore = median(AddModuleScore),
  AUCell = median(AUCell),
  GDF15_detection = mean(GDF15 > 0),
  GDF15_mean = mean(GDF15),
  MAPK_ERK = median(MAPK_ERK),
  ECM_degradation = median(ECM_degradation),
  n_cells = .N
), by = .(pair_id, donor_id, disease, state, score_group)]
fwrite(endpoint_agg, file.path(SD, "06_donor_state_group_endpoint_summary.csv"))

overall_agg <- cells[, .(
  consensus_score = median(consensus_score),
  GDF15_detection = mean(GDF15 > 0),
  GDF15_mean = mean(GDF15),
  MAPK_ERK = median(MAPK_ERK),
  ECM_degradation = median(ECM_degradation),
  n_cells = .N
), by = .(pair_id, donor_id, disease, state)]
fwrite(overall_agg, file.path(SD, "07_donor_state_endpoint_summary.csv"))

message("[6/8] Running donor-paired pseudobulk differential expression")

cells[, pb_id := paste(donor_id, score_group, sep = "||")]
pb_levels <- unique(cells$pb_id)
membership <- sparseMatrix(
  i = seq_len(nrow(cells)),
  j = match(cells$pb_id, pb_levels),
  x = 1,
  dims = c(nrow(cells), length(pb_levels)),
  dimnames = list(cells$cell_id, pb_levels)
)
pb_counts <- counts[, cells$cell_id, drop = FALSE] %*% membership
pb_meta <- unique(cells[, .(pb_id, donor_id, disease, score_group)])
pb_meta <- pb_meta[match(colnames(pb_counts), pb_id)]
stopifnot(identical(pb_meta$pb_id, colnames(pb_counts)))
pb_meta[, score_group := factor(score_group, levels = c("Low", "High"))]
pb_meta[, donor_id := factor(donor_id)]

y <- DGEList(counts = pb_counts)
keep <- filterByExpr(y, group = pb_meta$score_group, min.count = 10,
                     min.total.count = 20)
y <- y[keep, , keep.lib.sizes = FALSE]
y <- calcNormFactors(y)
design <- model.matrix(~ donor_id + score_group, data = pb_meta)
v <- voom(y, design, plot = FALSE)
fit <- eBayes(lmFit(v, design), robust = TRUE)
coef_name <- grep("^score_groupHigh$", colnames(design), value = TRUE)
stopifnot(length(coef_name) == 1)
de <- as.data.table(topTable(fit, coef = coef_name, number = Inf, sort.by = "P"),
                    keep.rownames = "gene")
de[, in_VD17_signature := gene %in% sig_genes]
de[, direction := fifelse(adj.P.Val < 0.05 & logFC > 0.25, "Up",
                          fifelse(adj.P.Val < 0.05 & logFC < -0.25, "Down", "NS"))]
de[, neglog10_FDR := -log10(pmax(adj.P.Val, 1e-300))]
fwrite(de, file.path(SD, "08_paired_pseudobulk_high_vs_low_DE.csv.gz"))

enrich_genes <- de[in_VD17_signature == FALSE & direction == "Up", gene]
enrich_rule <- "FDR < 0.05 and logFC > 0.25; predefined 17 signature genes excluded"
if (length(enrich_genes) < 15) {
  enrich_genes <- de[in_VD17_signature == FALSE & logFC > 0][order(P.Value), head(gene, 100)]
  enrich_rule <- "Sensitivity fallback: top 100 positive genes by P value; predefined 17 signature genes excluded"
}
writeLines(enrich_genes, file.path(SD, "09_enrichment_input_genes.txt"))
writeLines(enrich_rule, file.path(SD, "09_enrichment_selection_rule.txt"))

message("[7/8] Testing disease differences and GDF15/ERK/MMP-related endpoints")
disease_tests <- rbindlist(lapply(c("AddModuleScore", "AUCell", "consensus_score"), function(vn) {
  x <- donor_scores[disease == "normal", get(vn)]
  yv <- donor_scores[disease == "periodontitis", get(vn)]
  wt <- suppressWarnings(wilcox.test(yv, x, exact = FALSE))
  data.table(endpoint = vn, comparison = "periodontitis_vs_normal",
             n_normal = length(x), n_periodontitis = length(yv),
             median_normal = median(x), median_periodontitis = median(yv),
             delta = median(yv) - median(x), p_value = wt$p.value)
}))

paired_tests <- rbindlist(lapply(
  c("GDF15_detection", "GDF15_mean", "MAPK_ERK", "ECM_degradation"),
  function(vn) {
    ans <- paired_wilcox(endpoint_agg, vn)
    data.table(endpoint = vn, comparison = "High_vs_Low_within_donor_state",
               n_pairs = ans$n_pairs, median_delta = ans$median_delta,
               p_value = ans$p)
  }
), fill = TRUE)

corr_rows <- rbindlist(lapply(
  c("GDF15_detection", "GDF15_mean", "MAPK_ERK", "ECM_degradation"),
  function(vn) {
    ans <- safe_spearman(overall_agg$consensus_score, overall_agg[[vn]])
    data.table(endpoint = vn, comparison = "consensus_score_spearman_donor_state",
               rho = ans$rho, p_value = ans$p, n = ans$n)
  }
))

fwrite(disease_tests, file.path(SD, "10_disease_score_tests.csv"))
fwrite(paired_tests, file.path(SD, "11_high_low_endpoint_tests.csv"))
fwrite(corr_rows, file.path(SD, "12_endpoint_correlations.csv"))

method_agreement <- safe_spearman(cells$AddModuleScore, cells$AUCell)
method_agreement_donor <- safe_spearman(donor_scores$AddModuleScore, donor_scores$AUCell)
agreement <- data.table(
  level = c("cell", "donor"),
  rho = c(method_agreement$rho, method_agreement_donor$rho),
  p_value = c(method_agreement$p, method_agreement_donor$p),
  n = c(method_agreement$n, method_agreement_donor$n)
)
fwrite(agreement, file.path(SD, "13_AddModuleScore_AUCell_agreement.csv"))

message("[8/8] Writing analysis manifest")
manifest <- list(
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  reference_article = "Wang et al., Journal of Hazardous Materials 516 (2026) 143449",
  migrated_method = "Figure 2-style AddModuleScore plus AUCell dual scoring, high/low DE and enrichment",
  dataset = "Williams GSE164241",
  tissue = "human gingiva",
  cell_scope = "gingival fibroblasts only",
  n_cells = nrow(cells),
  n_donors = uniqueN(cells$donor_id),
  signature = "17-gene predefined Vitamin-D/VDR-target and gingival-disease overlap from prior analysis",
  signature_genes = sig_genes,
  signature_present = sig_present,
  auc_genes_ranked = sum(auc_keep),
  auc_max_rank = auc_max_rank,
  consensus = "mean of globally z-scored AddModuleScore and AUCell",
  high_low_definition = "within-donor and within-fibroblast-state median split",
  de_model = "edgeR TMM + limma-voom; paired design ~ donor + high/low; 42 pseudobulks",
  enrichment_rule = enrich_rule,
  caveats = c(
    "The signature score measures expression of a vitamin-D/VDR-related gingival disease-overlap gene set; it is not a direct measurement of vitamin-D exposure or VDR activation.",
    "Associations with GDF15, MAPK/ERK and ECM-degradation/MMP programs are observational and do not prove causality.",
    "All inferential tests use donor-level or donor-state aggregates; cell-level P values are not used."
  )
)
write_json(manifest, file.path(SD, "14_analysis_manifest.json"),
           auto_unbox = TRUE, pretty = TRUE)

print(disease_tests)
print(paired_tests)
print(corr_rows)
print(agreement)
message("Analysis completed")
