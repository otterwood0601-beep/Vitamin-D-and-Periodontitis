import os, sys, re
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy import stats
import statsmodels.formula.api as smf
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from style_npj import set_npj_style, save_npj, NPJ_CASE, NPJ_CTRL, MM
set_npj_style()
SRC = 'C:\\wb_links\\fig4_src'
DER = 'C:\\wb_links\\dlc_derived'
OUTDIR = 'C:\\wb_links\\dlc_out\\\u6838\u5fc3\u7ed3\u679cA_\u75c5\u7076\u9a8c\u8bc1'
os.makedirs(OUTDIR, exist_ok=True)
SUBTYPES = ['Immune', 'ECM remodeling', 'Vascular', 'Matrix homeostasis', 'Pre-extracellular matrix']
SUB_COL = {'Immune': '#398AF6', 'ECM remodeling': '#2AAC4A', 'Vascular': '#E9A34D', 'Matrix homeostasis': '#FF79B8', 'Pre-extracellular matrix': '#A892FF'}
SUB_SHORT = {'Immune': 'ImFB', 'ECM remodeling': 'EmFB', 'Vascular': 'VFB', 'Matrix homeostasis': 'HoFB', 'Pre-extracellular matrix': 'PreFB'}
DIS_COL = {'normal': NPJ_CTRL, 'periodontitis': NPJ_CASE}
DIS_LAB = {'normal': 'Healthy', 'periodontitis': 'Periodontitis'}
cells = pd.read_csv(os.path.join(SRC, '01_cell_metadata_UMAP_GDF15.csv.gz'), encoding='utf-8-sig')
inv = pd.read_csv(os.path.join(DER, 'sample_inventory_GSE164241.csv'))
gsm2donor = dict(zip(inv['gsm'], inv['donor_merged']))

def merge_donor(donor_id):
    m = re.search('(GSM\\d+)$', donor_id)
    if m and m.group(1) in gsm2donor:
        return 'Williams_' + gsm2donor[m.group(1)]
    return donor_id
cells['donor_merged'] = cells['donor_id'].map(merge_donor)
donor_tbl = cells[['donor_merged', 'Study', 'disease']].drop_duplicates()
print('donors:', donor_tbl.groupby(['Study', 'disease']).size().to_dict())
ct = cells.groupby(['donor_merged', 'fibroblast_type']).size().unstack(fill_value=0).reindex(columns=SUBTYPES, fill_value=0)
prop = ct.div(ct.sum(axis=1), axis=0)
prop['disease'] = donor_tbl.set_index('donor_merged').loc[prop.index, 'disease']
prop['Study'] = donor_tbl.set_index('donor_merged').loc[prop.index, 'Study']
prop.to_csv(os.path.join(DER, 'A1_donor_subtype_proportions.csv'))
stats_rows = []
for st in SUBTYPES:
    h = prop.loc[prop.disease == 'normal', st]
    p = prop.loc[prop.disease == 'periodontitis', st]
    u = stats.mannwhitneyu(p, h, alternative='two-sided')
    fit = smf.ols("Q('%s') ~ disease + Study" % st, data=prop).fit()
    beta = fit.params.get('disease[T.periodontitis]', np.nan)
    ci = fit.conf_int().loc['disease[T.periodontitis]'].tolist()
    stats_rows.append({'subtype': st, 'n_healthy': len(h), 'n_pd': len(p), 'median_healthy': h.median(), 'median_pd': p.median(), 'MWU_p': u.pvalue, 'LM_beta': beta, 'LM_CI_lo': ci[0], 'LM_CI_hi': ci[1], 'LM_p': fit.pvalues.get('disease[T.periodontitis]', np.nan)})
prop_stats = pd.DataFrame(stats_rows)
prop_stats.to_csv(os.path.join(DER, 'A1_proportion_stats.csv'), index=False)
obs = cells.groupby(['disease', 'fibroblast_type']).size().unstack(fill_value=0).reindex(columns=SUBTYPES, fill_value=0)
expected = np.outer(obs.sum(axis=1), obs.sum(axis=0)) / obs.values.sum()
roe = obs / expected
roe.to_csv(os.path.join(DER, 'A1_roe_table.csv'))

def roe_star(x):
    return '+++' if x > 1.5 else '++' if x > 1.2 else '+' if x > 1 else '+/-' if x > 0.8 else '-'
gdf_donor = pd.read_csv(os.path.join(DER, 'A1_GDF15_pseudobulk_donor.csv'))
gdf_ds = pd.read_csv(os.path.join(DER, 'A1_GDF15_pseudobulk_donor_subtype.csv'))
gdf_ds = gdf_ds[gdf_ds.libsize >= 5000]
gdf_rows = []
for st in ['All'] + SUBTYPES:
    if st == 'All':
        h = gdf_donor.loc[gdf_donor.disease == 'normal', 'GDF15_logCPM']
        p = gdf_donor.loc[gdf_donor.disease == 'periodontitis', 'GDF15_logCPM']
    else:
        h = gdf_ds.query("disease=='normal' and fibroblast_type==@st")['GDF15_logCPM']
        p = gdf_ds.query("disease=='periodontitis' and fibroblast_type==@st")['GDF15_logCPM']
    u = stats.mannwhitneyu(p, h, alternative='two-sided') if len(h) > 2 and len(p) > 2 else None
    gdf_rows.append({'scope': st, 'n_healthy': len(h), 'n_pd': len(p), 'mean_healthy': h.mean(), 'mean_pd': p.mean(), 'MWU_p': u.pvalue if u else np.nan})
gdf_stats = pd.DataFrame(gdf_rows)
gdf_stats.to_csv(os.path.join(DER, 'A1_GDF15_donor_stats.csv'), index=False)
print(gdf_stats.to_string())

def star_of(pv):
    return '***' if pv < 0.001 else '**' if pv < 0.01 else '*' if pv < 0.05 else 'ns'

def mini_box(ax, h, p, ylab=None):
    data = [np.asarray(h), np.asarray(p)]
    bp = ax.boxplot(data, positions=[0, 1], widths=0.55, patch_artist=True, showfliers=False, medianprops=dict(color='black', lw=0.8), whiskerprops=dict(lw=0.6), capprops=dict(lw=0.6), boxprops=dict(lw=0.6))
    for patch, c in zip(bp['boxes'], [NPJ_CTRL, NPJ_CASE]):
        patch.set_facecolor(c)
        patch.set_alpha(0.75)
    rng = np.random.default_rng(42)
    for x, vals, c in [(0, data[0], NPJ_CTRL), (1, data[1], NPJ_CASE)]:
        ax.scatter(x + rng.uniform(-0.12, 0.12, len(vals)), vals, s=6, c=c, ec='black', lw=0.3, zorder=3)
    pv = stats.mannwhitneyu(data[1], data[0], alternative='two-sided').pvalue
    y0 = max((d.max() if len(d) else 0 for d in data))
    ymin = min((d.min() if len(d) else 0 for d in data))
    yr = max((y0 - ymin) * 0.15, y0 * 0.05, 1e-06)
    ax.plot([0, 0, 1, 1], [y0 + yr * 0.4, y0 + yr, y0 + yr, y0 + yr * 0.4], lw=0.7, c='black')
    ax.text(0.5, y0 + yr * 1.15, star_of(pv), ha='center', va='bottom', fontsize=8)
    ax.set_xlim(-0.6, 1.6)
    ax.set_xticks([0, 1])
    ax.set_xticklabels(['H', 'PD'], fontsize=7)
    ax.set_ylim(ymin - yr, y0 + yr * 2.6)
    if ylab:
        ax.set_ylabel(ylab, fontsize=7)
    return pv
fig = plt.figure(figsize=(180 * MM, 200 * MM))
gs = fig.add_gridspec(3, 2, height_ratios=[1.0, 0.82, 0.95], hspace=0.42, wspace=0.22, left=0.08, right=0.94, top=0.94, bottom=0.07)
axA = fig.add_subplot(gs[0, 0])
for st in SUBTYPES:
    d = cells[cells.fibroblast_type == st]
    axA.scatter(d.UMAP_1, d.UMAP_2, s=0.3, c=SUB_COL[st], lw=0, rasterized=True)
axA.set_xticks([])
axA.set_yticks([])
axA.set_xlabel('UMAP_1')
axA.set_ylabel('UMAP_2')
axA.set_title('Fibroblast subtype', fontsize=8, fontweight='bold', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=0.35'))
handles = [Line2D([], [], marker='o', ls='', mfc=SUB_COL[st], mec='none', ms=4, label=f'{SUB_SHORT[st]} ({st})') for st in SUBTYPES]
axA.legend(handles=handles, loc='lower left', frameon=False, handletextpad=0.1, borderaxespad=0.1, labelspacing=0.25)
fig.text(0.065, 0.955, 'A', fontsize=12, fontweight='bold')
axB = fig.add_subplot(gs[0, 1])
for dis in ['normal', 'periodontitis']:
    d = cells[cells.disease == dis]
    axB.scatter(d.UMAP_1, d.UMAP_2, s=0.3, c=DIS_COL[dis], lw=0, rasterized=True)
axB.set_xticks([])
axB.set_yticks([])
axB.set_xlabel('UMAP_1')
axB.set_ylabel('UMAP_2')
axB.set_title('Disease', fontsize=8, fontweight='bold', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=0.35'))
handles = [Line2D([], [], marker='o', ls='', mfc=DIS_COL[d], mec='none', ms=4, label=DIS_LAB[d]) for d in ['normal', 'periodontitis']]
axB.legend(handles=handles, loc='lower left', frameon=False, handletextpad=0.1, borderaxespad=0.1, labelspacing=0.25)
fig.text(0.545, 0.955, 'B', fontsize=12, fontweight='bold')
gsC = gs[1, 0].subgridspec(1, 5, wspace=0.12)
c_axes = []
for i, st in enumerate(SUBTYPES):
    ax = fig.add_subplot(gsC[0, i], sharey=c_axes[0] if c_axes else None)
    c_axes.append(ax)
    mini_box(ax, prop.loc[prop.disease == 'normal', st].values, prop.loc[prop.disease == 'periodontitis', st].values, ylab='Proportion within donor' if i == 0 else None)
    ax.set_ylim(0, 1.0)
    ax.set_yticks([0.0, 0.2, 0.4, 0.6, 0.8, 1.0])
    ax.set_title(SUB_SHORT[st], fontsize=7.5, fontweight='bold', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=0.3'))
    if i > 0:
        ax.tick_params(labelleft=False)
fig.text(0.065, 0.635, 'C', fontsize=12, fontweight='bold')
axD = fig.add_subplot(gs[1, 1])
mat = roe.loc[['normal', 'periodontitis'], SUBTYPES].values
im = axD.imshow(mat, cmap='Reds', vmin=0, vmax=max(2.0, mat.max() * 1.05), aspect='auto')
axD.set_xticks(range(5))
axD.set_xticklabels([SUB_SHORT[s] for s in SUBTYPES], fontsize=7)
axD.set_yticks([0, 1])
axD.set_yticklabels(['Healthy', 'Periodontitis'], fontsize=7)
for i in range(2):
    for j in range(5):
        axD.text(j, i, f'{mat[i, j]:.2f}\n{roe_star(mat[i, j])}', ha='center', va='center', fontsize=6.5, color='white' if mat[i, j] > 1.4 else 'black')
cb = fig.colorbar(im, ax=axD, fraction=0.03, pad=0.02)
cb.set_label('Ro/e', fontsize=7)
cb.ax.tick_params(labelsize=6)
axD.set_title('Tissue prevalence (Ro/e)', fontsize=8, fontweight='bold', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=0.35'))
fig.text(0.545, 0.635, 'D', fontsize=12, fontweight='bold')
gsE = gs[2, :].subgridspec(1, 6, wspace=0.5)
for i, st in enumerate(['All'] + SUBTYPES):
    ax = fig.add_subplot(gsE[0, i])
    if st == 'All':
        h = gdf_donor.loc[gdf_donor.disease == 'normal', 'GDF15_logCPM'].values
        p = gdf_donor.loc[gdf_donor.disease == 'periodontitis', 'GDF15_logCPM'].values
        ttl = 'All fibroblasts'
    else:
        h = gdf_ds.query("disease=='normal' and fibroblast_type==@st")['GDF15_logCPM'].values
        p = gdf_ds.query("disease=='periodontitis' and fibroblast_type==@st")['GDF15_logCPM'].values
        ttl = SUB_SHORT[st]
    mini_box(ax, h, p, ylab='GDF15 log2(CPM+0.5), donor' if i == 0 else None)
    ax.set_title(ttl, fontsize=7.5, fontweight='bold', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=0.3'))
fig.text(0.03, 0.315, 'E', fontsize=12, fontweight='bold')
save_npj(fig, os.path.join(OUTDIR, '\u6838\u5fc3\u7ed3\u679cA_\u75c5\u7076\u9a8c\u8bc1_\u4f9b\u8005\u5c42\u9762ABCDE_20260914'), width_mm=180, height_mm=200, dpi=600)
print('FIG SAVED')
print(prop_stats.to_string())
