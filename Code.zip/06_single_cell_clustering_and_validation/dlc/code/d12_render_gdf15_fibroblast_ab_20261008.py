from pathlib import Path
import json, shutil, sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
sys.path.insert(0, str(ROOT / 'code'))
from style_npj import set_npj_style, save_npj, MM, NPJ_CTRL, NPJ_CASE
set_npj_style()
OUT = ROOT / 'output' / 'GDF15_\u6210\u7ea4\u7ef4\u7ec6\u80de\u5f71\u54cd_AB_20261008'
SD, FIG, CODE = [OUT / x for x in ['source_data', 'figures', 'code']]
a = pd.read_csv(SD / '04_FANTOM5_paired_GDF15_expression.csv')
astat = pd.read_csv(SD / '05_FANTOM5_paired_GDF15_statistics.csv').iloc[0]
b = pd.read_csv(SD / '07_bulk_four_models_and_HC3.csv')
b = b[b.variance == 'OLS'].copy()
model_order = ['Unadjusted', 'Fibroblast-adjusted', 'Other-major-cell-adjusted', 'All-major-cell-adjusted']
labels = ['No fraction adjustment', 'Fibroblast fraction', 'Epithelial + immune', 'Fibroblast + epithelial\n+ immune']
colors = ['#8F8F8F', '#7E5AA7', '#4A8FD4', '#C9403B']

def p_label(p):
    return '<0.001' if p < 0.001 else f'{p:.3f}'

def header(fig, left, right, text, y=0.905):
    fig.add_artist(Rectangle((left, y), right - left, 0.051, transform=fig.transFigure, facecolor='#E4E6EB', edgecolor='none'))
    fig.text((left + right) / 2, y + 0.0255, text, ha='center', va='center', fontsize=8, fontweight='bold')

def panel_a(ax):
    pv = a.pivot(index='donor', columns='condition', values='GDF15_log2_TPM')
    markers = ['o', 's', 'D']
    for (donor, row), marker in zip(pv.iterrows(), markers):
        ys = [row['Healthy site'], row['Periodontitis']]
        ax.plot([0, 1], ys, color='#A6A6A6', lw=0.8, zorder=1)
        ax.scatter([0, 1], ys, c=[NPJ_CTRL, NPJ_CASE], marker=marker, s=32, edgecolor='white', linewidth=0.5, zorder=3)
        label_offset = {6: -6, 7: 0, 8: 6}[donor]
        ax.annotate(f'{donor}', (0, ys[0]), xytext=(-9, label_offset), textcoords='offset points', ha='right', va='center', fontsize=6.5, color='#5C5C5C')
    lo = a.GDF15_log2_TPM.min()
    hi = a.GDF15_log2_TPM.max()
    span = max(hi - lo, 1)
    ax.set_ylim(lo - 0.18 * span, hi + 0.22 * span)
    ax.set_xlim(-0.35, 1.35)
    ax.set_xticks([0, 1])
    ax.set_xticklabels(['Healthy site', 'Periodontitis\nsite'])
    ax.set_ylabel('GDF15 expression\nlog2(CAGE tags per million + 0.5)')
    ax.text(0.5, 1.08, f'3 matched patients | exact paired P = {p_label(astat.exact_sign_flip_two_sided_p)}', transform=ax.transAxes, ha='center', fontsize=6.5)
    ax.spines[['top', 'right']].set_visible(False)
    ax.tick_params(width=0.5, length=3)
    ax.text(0.5, -0.205, f'{int(astat.n_pairs_increased)}/3 pairs increased; each line = one patient', transform=ax.transAxes, ha='center', fontsize=6.5)

def panel_b(ax):
    yblocks = [[8, 7, 6, 5], [3, 2, 1, 0]]
    for ds, ys, n in zip(['GSE223924', 'GSE173078'], yblocks, [10, 12]):
        sub = b[b.dataset == ds].set_index('model').loc[model_order]
        for y, (_, r), color in zip(ys, sub.iterrows(), colors):
            ax.errorbar(r.PD_beta, y, xerr=[[r.PD_beta - r.PD_CI_low], [r.PD_CI_high - r.PD_beta]], fmt='o', ms=4.5, color=color, elinewidth=1, capsize=2, zorder=3)
            ax.text(1.05, y, p_label(r.PD_p), transform=ax.get_yaxis_transform(), ha='left', va='center', fontsize=6.5)
        ax.text(-0.44, ys[0] + 0.62, f'{ds} | {n} healthy / {n} PD', transform=ax.get_yaxis_transform(), ha='left', va='center', fontsize=7, fontweight='bold', clip_on=False)
    ax.set_yticks(yblocks[0] + yblocks[1])
    ax.set_yticklabels(labels + labels, fontsize=6.5)
    ax.set_ylim(-0.6, 9.3)
    limlo = min(-0.5, b.PD_CI_low.min() - 0.15)
    limhi = max(2.5, b.PD_CI_high.max() + 0.15)
    ax.set_xlim(limlo, limhi)
    ax.axvline(0, color='#4B4B4B', ls='--', lw=0.65)
    ax.set_xlabel('GDF15 difference (PD \u2212 healthy)\nlog2(CPM + 0.5); bars: 95% CI')
    ax.text(1.05, 9.14, 'P', transform=ax.get_yaxis_transform(), ha='left', va='center', fontsize=7, fontweight='bold')
    ax.spines[['top', 'right', 'left']].set_visible(False)
    ax.tick_params(axis='y', length=0, pad=7)
    ax.tick_params(axis='x', width=0.5, length=3)
    ax.axhline(4.05, color='#DADADA', lw=0.5)
fig = plt.figure(figsize=(180 * MM, 120 * MM))
axa = fig.add_axes([0.105, 0.255, 0.235, 0.53])
panel_a(axa)
axb = fig.add_axes([0.665, 0.215, 0.27, 0.605])
panel_b(axb)
header(fig, 0.055, 0.385, 'Clinical gingival fibroblasts')
header(fig, 0.44, 0.985, 'Bulk GDF15 and cell fractions')
fig.text(0.026, 0.932, 'A', fontsize=12, fontweight='bold')
fig.text(0.411, 0.932, 'B', fontsize=12, fontweight='bold')
fig.text(0.055, 0.115, 'A: FANTOM5; primary cultured fibroblasts from matched healthy/diseased sites; CAGE profiling.', fontsize=6.3)
fig.text(0.055, 0.079, 'B: existing BisqueRNA fractions; GDF15 excluded from markers; GSE173078 models include batch.', fontsize=6.3)
fig.text(0.055, 0.043, 'Other major cells = epithelial + pooled immune. These observational results do not establish causation.', fontsize=6.3)
stem = FIG / 'GDF15_\u6210\u7ea4\u7ef4\u7ec6\u80de\u53ca\u7ec4\u7ec7\u7ec4\u6210\u6821\u6b63_AB_20261008'
save_npj(fig, str(stem), 180, 120, 600)
fig.savefig(FIG / 'AB_\u5ba1\u9605\u9884\u89c8.png', dpi=200)
plt.close(fig)
fig = plt.figure(figsize=(90 * MM, 100 * MM))
panel_a(fig.add_axes([0.23, 0.28, 0.62, 0.49]))
header(fig, 0.1, 0.95, 'Clinical gingival fibroblasts')
fig.text(0.036, 0.93, 'A', fontsize=12, fontweight='bold')
fig.text(0.1, 0.12, 'FANTOM5: 3 matched patients; primary cultured fibroblasts.', fontsize=6)
fig.text(0.1, 0.075, 'Healthy site and periodontitis site from the same patient.', fontsize=6)
fig.text(0.1, 0.031, 'CAGE expression; observational comparison.', fontsize=6)
save_npj(fig, str(FIG / 'A_\u4e34\u5e8a\u914d\u5bf9\u6210\u7ea4\u7ef4\u7ec6\u80de_GDF15_20261008'), 90, 100, 600)
plt.close(fig)
fig = plt.figure(figsize=(120 * MM, 120 * MM))
panel_b(fig.add_axes([0.44, 0.245, 0.43, 0.56]))
header(fig, 0.055, 0.975, 'Bulk GDF15 and cell fractions')
fig.text(0.025, 0.932, 'B', fontsize=12, fontweight='bold')
fig.text(0.055, 0.12, 'BisqueRNA fraction adjustment; GDF15 excluded from markers.', fontsize=6)
fig.text(0.055, 0.076, 'Other major cells = epithelial + pooled immune; reference remainder omitted.', fontsize=6)
fig.text(0.055, 0.032, 'GSE173078 includes batch. Composition sensitivity does not establish causation.', fontsize=6)
save_npj(fig, str(FIG / 'B_\u7259\u9f88bulk_\u56db\u79cd\u7ec4\u6210\u6821\u6b63_GDF15_20261008'), 120, 120, 600)
plt.close(fig)
shutil.copy2(__file__, CODE / Path(__file__).name)
shutil.copy2(ROOT / 'code' / 'style_npj.py', CODE / 'style_npj.py')
(SD / '11_figure_manifest.json').write_text(json.dumps(dict(main=str(stem), dpi=600, PDF='vector with embedded Arial TrueType', A_source='04_FANTOM5_paired_GDF15_expression.csv', B_source='07_bulk_four_models_and_HC3.csv', primary_variance='OLS; HC3 sensitivity in source table'), indent=2), encoding='utf8')
print('[DONE] Combined and separate A/B PNG/PDF exports', flush=True)
