options(stringsAsFactors = FALSE, scipen = 999)
set.seed(20260924)

suppressPackageStartupMessages({
  library(Seurat)
  library(data.table)
  library(Matrix)
  library(ggplot2)
  library(patchwork)
  library(cowplot)
  library(ggrepel)
})

OUT <- "C:/wb_links/bioorgchem2026_20260924"
SD <- file.path(OUT, "source_data")
FD <- file.path(OUT, "figures")
PT <- "C:/wb_links/tranoncol2026_Williams_20260920"
FB <- "C:/wb_links/dlc_data/outputs/fb_seurat_annotated.rds"

message("[1/5] Load Williams human gingival fibroblasts only")
fb_all <- readRDS(FB)
fb <- subset(fb_all, subset = Study == "Williams")
rm(fb_all); invisible(gc())
DefaultAssay(fb) <- "RNA"
stopifnot(ncol(fb) == 14302)

emb <- as.data.table(Embeddings(fb, "frozen_umap"), keep.rownames = "cell_id")
setnames(emb, c("cell_id", "UMAP1", "UMAP2"))
md <- as.data.table(fb[[]], keep.rownames = "cell_id")
cells <- merge(emb, md[, .(cell_id, cluster_raw, fibroblast_short, disease,
                            donor_id, Study)], by = "cell_id", all.x = TRUE, sort = FALSE)

message("[2/5] Recreate 2500-variable-gene selection panel")
fb <- FindVariableFeatures(fb, selection.method = "vst", nfeatures = 2500, verbose = FALSE)
hv <- HVFInfo(fb)
hvdt <- as.data.table(hv, keep.rownames = "gene")
if (!"variance.standardized" %in% names(hvdt)) {
  vcol <- grep("variance.*standard", names(hvdt), value = TRUE)[1]
  setnames(hvdt, vcol, "variance.standardized")
}
hvdt[, variable := gene %in% VariableFeatures(fb)]
fwrite(hvdt, file.path(SD, "21_Williams_2500_HVGs.csv.gz"))

message("[3/5] Add Williams-only pseudotime and axis summaries")
pt <- fread(file.path(PT, "32_pseudotime_cell_assignments.csv.gz"))
defs <- fread(file.path(PT, "33_pseudotime_lineage_definitions.csv"))
curves <- fread(file.path(PT, "34_pseudotime_curve_coordinates.csv"))
pt <- pt[cell_id %in% cells$cell_id]
lineages <- as.character(defs$lineage)
pt_cols <- paste0(lineages, "_pseudotime_01")
wt_cols <- paste0(lineages, "_weight")
pt_mat <- as.matrix(pt[, ..pt_cols])
wt_mat <- as.matrix(pt[, ..wt_cols])
choice <- max.col(wt_mat, ties.method = "first")
pt[, dominant_lineage := lineages[choice]]
pt[, dominant_pseudotime := pt_mat[cbind(seq_len(.N), choice)]]
pt[, dominant_weight := wt_mat[cbind(seq_len(.N), choice)]]
pt[dominant_weight <= 0.05, dominant_pseudotime := NA_real_]
cells[pt, on = "cell_id", `:=`(dominant_lineage = i.dominant_lineage,
                                dominant_pseudotime = i.dominant_pseudotime,
                                dominant_weight = i.dominant_weight)]

norm <- GetAssayData(fb, assay = "RNA", layer = "data")
axis_genes <- intersect(c("GDF15", "VDR", "MAPK1", "MAPK3", "MMP1", "MMP2",
                          "MMP3", "MMP7", "MMP8", "MMP9", "MMP13", "MMP14"),
                        rownames(norm))
axis_mat <- t(as.matrix(norm[axis_genes, cells$cell_id, drop = FALSE]))
axis_dt <- as.data.table(axis_mat, keep.rownames = "cell_id")
mmp_genes <- intersect(grep("^MMP", axis_genes, value = TRUE), colnames(axis_dt))
axis_dt[, MMP_mean := rowMeans(.SD), .SDcols = mmp_genes]
axis_dt[, ERK1_2_mean := rowMeans(.SD), .SDcols = intersect(c("MAPK1", "MAPK3"), names(axis_dt))]
axis_dt[cells, on = "cell_id", `:=`(fibroblast_short = i.fibroblast_short,
                                     disease = i.disease, donor_id = i.donor_id,
                                     dominant_pseudotime = i.dominant_pseudotime)]
axis_summary <- axis_dt[, c(
  lapply(.SD, mean, na.rm = TRUE),
  list(GDF15_detection = mean(GDF15 > 0, na.rm = TRUE), n_cells = .N)
), by = .(fibroblast_short, disease),
.SDcols = c(intersect(c("GDF15", "VDR", "MAPK1", "MAPK3"), names(axis_dt)),
            "ERK1_2_mean", "MMP_mean")]
fwrite(axis_summary, file.path(SD, "22_Williams_axis_state_summary.csv"))
fwrite(cells[, .(cell_id, UMAP1, UMAP2, cluster_raw, fibroblast_short, disease,
                 donor_id, dominant_lineage, dominant_pseudotime, dominant_weight)],
       file.path(SD, "23_Williams_Fig8_cell_coordinates.csv.gz"))

paper_theme <- theme_classic(base_size = 8, base_family = "Arial") +
  theme(
    axis.title = element_text(size = 8),
    axis.text = element_text(size = 6.5, colour = "black"),
    plot.title = element_text(hjust = 0.5, size = 9),
    legend.title = element_text(size = 7),
    legend.text = element_text(size = 6.3),
    legend.key.size = grid::unit(0.34, "cm"),
    plot.margin = ggplot2::margin(3, 3, 3, 3)
  )
type_levels <- c("Immune", "ECM remodeling", "Vascular", "Pre-ECM", "Matrix homeostasis")
type_cols <- c(
  "Immune" = "#E78383",
  "ECM remodeling" = "#D7CE62",
  "Vascular" = "#8EB7C4",
  "Pre-ECM" = "#E6CDD5",
  "Matrix homeostasis" = "#9AD9CB"
)
cluster_levels <- sort(unique(as.character(cells$cluster_raw)))
cluster_cols <- setNames(scales::hue_pal()(length(cluster_levels)), cluster_levels)

message("[4/5] Build Bioorganic Chemistry Fig. 8 style panels")
pA <- ggplot(hvdt, aes(mean, variance.standardized, colour = variable)) +
  geom_point(size = 0.30, alpha = 0.85) +
  scale_colour_manual(values = c(`FALSE` = "black", `TRUE` = "red"),
                      labels = c(`FALSE` = paste0("Non-variable count: ", sum(!hvdt$variable)),
                                 `TRUE` = paste0("Variable count: ", sum(hvdt$variable))),
                      name = NULL) +
  scale_x_log10() + labs(x = "Average Expression", y = "Standardized Variance") +
  paper_theme + theme(legend.position = c(0.33, 0.85),
                      legend.background = element_blank())

cent_cluster <- cells[, .(UMAP1 = median(UMAP1), UMAP2 = median(UMAP2)), by = cluster_raw]
pB <- ggplot(cells, aes(UMAP1, UMAP2, colour = factor(cluster_raw))) +
  geom_point(size = 0.16, alpha = 0.72) +
  geom_text(data = cent_cluster, aes(label = cluster_raw), colour = "black",
            size = 3, family = "Arial") +
  scale_colour_manual(values = cluster_cols, name = NULL) +
  labs(x = "UMAP1", y = "UMAP2") + paper_theme +
  theme(legend.position = "right")

cent_type <- cells[, .(UMAP1 = median(UMAP1), UMAP2 = median(UMAP2)), by = fibroblast_short]
pC <- ggplot(cells, aes(UMAP1, UMAP2, colour = fibroblast_short)) +
  geom_point(size = 0.16, alpha = 0.72) +
  stat_ellipse(aes(group = fibroblast_short), linewidth = 0.35,
               level = 0.80, show.legend = FALSE) +
  geom_text_repel(data = cent_type, aes(label = fibroblast_short), colour = "black",
                  size = 2.4, family = "Arial", min.segment.length = 0) +
  scale_colour_manual(values = type_cols, name = "Cell Type") +
  labs(title = "Cell Types with Cluster Boundaries", x = "UMAP1", y = "UMAP2") +
  paper_theme + theme(legend.position = "right")

pD1 <- ggplot(cells, aes(UMAP1, UMAP2, colour = fibroblast_short)) +
  geom_point(size = 0.16, alpha = 0.70) +
  geom_path(data = curves, aes(umap_1, umap_2, group = lineage),
            inherit.aes = FALSE, colour = "#555555", linewidth = 0.65,
            arrow = arrow(type = "closed", length = grid::unit(2.5, "pt"))) +
  scale_colour_manual(values = type_cols, name = "Fibroblast state") +
  labs(x = "UMAP1", y = "UMAP2") + paper_theme +
  theme(legend.position = "right")

pD2 <- ggplot(cells, aes(UMAP1, UMAP2, colour = dominant_pseudotime)) +
  geom_point(size = 0.18, alpha = 0.82, na.rm = TRUE) +
  geom_path(data = curves, aes(umap_1, umap_2, group = lineage),
            inherit.aes = FALSE, colour = "#333333", linewidth = 0.45) +
  scale_colour_viridis_c(option = "plasma", direction = -1, name = "Pseudotime",
                         na.value = "#D9D9D9") +
  labs(x = "UMAP1", y = "UMAP2") + paper_theme +
  theme(legend.position = "right")
pD <- plot_grid(pD1, pD2, nrow = 1, rel_widths = c(1, 1), align = "hv")

gdf <- axis_dt[, .(cell_id, GDF15)]
gdf[cells, on = "cell_id", `:=`(UMAP1 = i.UMAP1, UMAP2 = i.UMAP2)]
setorder(gdf, GDF15)
pE <- ggplot(gdf, aes(UMAP1, UMAP2, colour = GDF15)) +
  geom_point(size = 0.22, alpha = 0.86) +
  scale_colour_gradient(low = "#D4D4D4", high = "red", name = "GDF15") +
  labs(title = "GDF15 Expression (UMAP)", x = "UMAP1", y = "UMAP2") +
  paper_theme + theme(legend.position = "right")

props <- cells[, .N, by = .(donor_id, fibroblast_short)]
props[, proportion := N / sum(N), by = donor_id]
props[, fibroblast_short := factor(fibroblast_short, levels = type_levels)]
fwrite(props, file.path(SD, "24_Williams_donor_state_proportions.csv"))
pF <- ggplot(props, aes(proportion, factor(donor_id), fill = fibroblast_short)) +
  geom_col(width = 0.82, colour = "white", linewidth = 0.15) +
  scale_x_continuous(labels = scales::percent_format(accuracy = 1), expand = c(0, 0)) +
  scale_fill_manual(values = type_cols, name = "Cell Type") +
  labs(title = "Sample", x = "Proportion", y = NULL) + paper_theme +
  theme(axis.text.y = element_text(size = 5.2), legend.position = "right")

layout_design <- "
AAABBBCCC
DDDDDDDDD
EEEEFFFFF
"
fig8 <- pA + pB + pC + pD + pE + pF +
  plot_layout(design = layout_design, heights = c(0.88, 1.38, 1.12)) +
  plot_annotation(tag_levels = "A", theme = theme(
    plot.tag = element_text(family = "Arial", size = 15, face = "plain")
  ))

ggsave(file.path(FD, "Fig8_Williams_gingival_fibroblast_scRNA_pseudotime_BioorgChem_style.pdf"),
       fig8, width = 10.8, height = 13.3, units = "in", device = cairo_pdf)

manifest <- list(
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  study = "Williams only",
  tissue = "Human gingiva",
  n_cells = ncol(fb),
  n_donors = uniqueN(cells$donor_id),
  cell_states = type_levels,
  variable_genes = 2500,
  pseudotime_source = "Williams-only Slingshot analysis already completed on 2026-09-20",
  pseudotime_lineages = setNames(as.list(defs$label), defs$lineage),
  feature_plot = "GDF15 log-normalized RNA expression",
  caveat = paste(
    "Pseudotime is an inferred transcriptomic state continuum.",
    "It is not chronological time and cannot prove vitamin D-to-GDF15-to-ERK causality."
  )
)
jsonlite::write_json(manifest, file.path(SD, "25_Fig8_manifest.json"),
                     auto_unbox = TRUE, pretty = TRUE)

message("[5/5] Completed Fig. 8")
print(axis_summary)
