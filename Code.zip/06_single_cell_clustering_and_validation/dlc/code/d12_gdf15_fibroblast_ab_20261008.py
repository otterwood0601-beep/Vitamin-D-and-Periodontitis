from pathlib import Path
import gzip, hashlib, itertools, json, re, shutil, sys, urllib.parse
import requests
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
sys.stdout.reconfigure(encoding='utf-8')
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
OUT = ROOT / 'output' / 'GDF15_\u6210\u7ea4\u7ef4\u7ec6\u80de\u5f71\u54cd_AB_20261008'
RAW, SD, FIG, CODE = [OUT / x for x in ['raw_data', 'source_data', 'figures', 'code']]
for p in [RAW, SD, FIG, CODE]:
    p.mkdir(parents=True, exist_ok=True)
BASE = 'https://fantom.gsc.riken.jp/5/datafiles/latest/extra/CAGE_peaks/'
ANN = 'hg19.cage_peak_phase1and2combined_ann.txt.gz'
COUNTS = 'hg19.cage_peak_phase1and2combined_counts.osc.txt.gz'

def download(name):
    dest = RAW / name
    if not dest.exists():
        print('Downloading', name, flush=True)
        size = int(requests.head(BASE + name, timeout=30).headers.get('Content-Length', 0))
        with dest.with_suffix(dest.suffix + '.partial').open('wb') as f:
            if size > 20000000:
                chunk_size = 4 * 1024 * 1024
                for start in range(0, size, chunk_size):
                    end = min(size - 1, start + chunk_size - 1)
                    with requests.get(BASE + name, headers={'Range': f'bytes={start}-{end}'}, timeout=(30, 60)) as r:
                        r.raise_for_status()
                        if r.status_code != 206 or len(r.content) != end - start + 1:
                            raise ValueError('Unexpected HTTP range response')
                        f.write(r.content)
                    if start // chunk_size % 5 == 0:
                        print(f'Received {end + 1:,}/{size:,} bytes', flush=True)
            else:
                with requests.get(BASE + name, stream=True, timeout=(30, 60)) as r:
                    r.raise_for_status()
                    for chunk in r.iter_content(1024 * 1024):
                        f.write(chunk)
        dest.with_suffix(dest.suffix + '.partial').replace(dest)
    return dest

def clinical_panel():
    annfile = download(ANN)
    ann = pd.read_csv(annfile, sep='\t', comment='#')
    is_symbol = ann.short_description.fillna('').str.contains('(?:^|@|,)GDF15(?:$|,)', regex=True)
    is_entrez = ann.entrezgene_id.fillna('').astype(str).str.contains('(?:^|[^0-9])9518(?:$|[^0-9])', regex=True)
    target = ann[is_symbol | is_entrez].copy()
    if target.empty:
        raise ValueError('No GDF15 CAGE peaks identified')
    print('GDF15 promoter annotations:', target.to_dict('records'), flush=True)
    target.to_csv(SD / '01_FANTOM5_GDF15_promoter_annotations.csv', index=False)
    countfile = download(COUNTS)
    wanted = set(target['00Annotation'])
    rows, statrows = ([], [])
    with gzip.open(countfile, 'rt', encoding='utf-8') as f:
        for line in f:
            if not line.startswith('#'):
                header = line.rstrip().split('\t')
                break
        selected = [(i, urllib.parse.unquote(col)) for i, col in enumerate(header) if 'fibroblast' in col.lower() and 'gingival' in col.lower()]
        names = [col for _, col in selected]
        for line in f:
            fields = line.rstrip().split('\t')
            peak = fields[0]
            if peak.startswith('01STAT:'):
                statrows.append([peak] + [int(fields[i]) for i, _ in selected])
            if peak in wanted:
                rows.append([peak] + [int(fields[i]) for i, _ in selected])
                if len(rows) == len(wanted):
                    break
    if len(rows) != len(wanted):
        raise ValueError('Missing annotated promoter rows')
    sub = pd.DataFrame(rows, columns=['peak'] + names).set_index('peak')
    libstats = pd.DataFrame(statrows, columns=['statistic'] + names).set_index('statistic')
    sub.to_csv(SD / '02_FANTOM5_GDF15_promoter_counts_all_GFs.csv')
    libstats.to_csv(SD / '03_FANTOM5_library_statistics.csv')
    mapped = libstats.loc['01STAT:MAPPED']
    records = []
    for donor in [6, 7, 8]:
        for disease in [False, True]:
            matches = [col for col in names if f'donor{donor} (' in col and ('periodontitis' in col) == disease]
            if len(matches) != 1:
                raise ValueError((donor, disease, matches))
            col = matches[0]
            count = int(sub[col].sum())
            lib = int(mapped[col])
            records.append(dict(donor=donor, condition='Periodontitis' if disease else 'Healthy site', sample=col, GDF15_peak_count=count, mapped_CAGE_tags=lib, GDF15_TPM=count / lib * 1000000.0, GDF15_log2_TPM=float(np.log2(count / lib * 1000000.0 + 0.5)), clinical_subtype='control' if not disease else 'chronic' if donor == 8 else 'aggressive'))
    d = pd.DataFrame(records)
    d.to_csv(SD / '04_FANTOM5_paired_GDF15_expression.csv', index=False)
    p = d.pivot(index='donor', columns='condition', values='GDF15_log2_TPM')
    dif = p['Periodontitis'] - p['Healthy site']
    tt = stats.ttest_rel(p['Periodontitis'], p['Healthy site'])
    se = stats.sem(dif)
    ci = stats.t.interval(0.95, len(dif) - 1, loc=dif.mean(), scale=se)
    flips = np.array(list(itertools.product([-1, 1], repeat=len(dif)))) @ dif.to_numpy() / len(dif)
    exact_p = float(np.mean(np.abs(flips) >= abs(dif.mean()) - 1e-12))
    result = dict(dataset='FANTOM5', n_pairs=len(dif), mean_PD_minus_H=float(dif.mean()), paired_CI_low=float(ci[0]), paired_CI_high=float(ci[1]), paired_t_p=float(tt.pvalue), exact_sign_flip_two_sided_p=exact_p, n_pairs_increased=int((dif > 0).sum()), scale='log2(GDF15 CAGE tags per million mapped tags + 0.5)', note='Paired diseased and clinically healthy sites within three periodontitis patients; primary cultured GFs; CAGE promoter activity, not conventional RNA-seq.')
    pd.DataFrame([result]).to_csv(SD / '05_FANTOM5_paired_GDF15_statistics.csv', index=False)
    print('A result:', json.dumps(result, ensure_ascii=False), flush=True)
    return (d, result)

def composition_panel():
    der = ROOT / 'data_derived' / 'D11_deconvolution'
    audit = pd.read_csv(der / 'D11_marker_gene_audit.csv')
    if (audit.gene == 'GDF15').any():
        raise ValueError('GDF15 included in proportion markers: requires re-estimation')
    allmodels = []
    inputs = []
    fractiontests = []
    designqa = []
    for ds in ['GSE223924', 'GSE173078']:
        frac = pd.read_csv(der / f'D11_{ds}_Bisque_cell_fractions.csv').set_index('sample')
        if ds == 'GSE223924':
            counts = pd.read_csv(ROOT / '01_\u6570\u636e\u51c6\u5907' / 'external_GSE223924' / 'GSE223924_raw_count.csv.gz', index_col=0)
        else:
            counts = pd.read_csv(ROOT / '01_\u6570\u636e\u51c6\u5907' / 'external_GSE173078' / 'GSE173078_rnaseq_raw_counts.txt.gz', sep='\t', index_col=0)
        counts = counts.groupby(level=0, sort=False).sum()
        counts = counts.loc[:, frac.index]
        cellcols = [x for x in frac.columns if x not in ['group', 'batch']]
        if not np.allclose(frac[cellcols].sum(axis=1), 1, atol=1e-08):
            raise ValueError('Fractions do not sum to 1')
        d = pd.DataFrame(index=frac.index)
        d['dataset'] = ds
        d['group'] = frac.group
        d['PD'] = (frac.group == 'Periodontitis').astype(int)
        d['library_count'] = counts.sum(axis=0)
        d['GDF15_count'] = counts.loc['GDF15']
        d['GDF15_log2_CPM'] = np.log2(d.GDF15_count / d.library_count * 1000000.0 + 0.5)
        d['fibroblast'] = frac.Fibroblast
        d['epithelial'] = frac.Epithelial
        immune = ['T/NK', 'B/Plasma', 'Myeloid/DC', 'Neutrophil', 'Mast']
        d['immune'] = frac[immune].sum(axis=1)
        d['reference_remainder'] = 1 - d[['fibroblast', 'epithelial', 'immune']].sum(axis=1)
        base = ['PD']
        if 'batch' in frac:
            d['batch_B'] = (frac.batch == 'B').astype(int)
            base.append('batch_B')
        designs = [('Unadjusted', []), ('Fibroblast-adjusted', ['fibroblast']), ('Other-major-cell-adjusted', ['epithelial', 'immune']), ('All-major-cell-adjusted', ['fibroblast', 'epithelial', 'immune'])]
        for model, co in designs:
            X = sm.add_constant(d[base + co], has_constant='add')
            rank = int(np.linalg.matrix_rank(X))
            if rank != X.shape[1]:
                raise ValueError('Non-estimable model')
            fit = sm.OLS(d.GDF15_log2_CPM, X).fit()
            for variance, cfit in [('OLS', fit), ('HC3', fit.get_robustcov_results(cov_type='HC3', use_t=True))]:
                j = list(X.columns).index('PD')
                ci = np.asarray(cfit.conf_int())[j]
                allmodels.append(dict(dataset=ds, model=model, variance=variance, n_H=int((d.PD == 0).sum()), n_PD=int((d.PD == 1).sum()), PD_beta=float(np.asarray(cfit.params)[j]), PD_CI_low=float(ci[0]), PD_CI_high=float(ci[1]), PD_p=float(np.asarray(cfit.pvalues)[j]), residual_df=float(cfit.df_resid), formula='GDF15_log2_CPM ~ ' + ' + '.join(base + co)))
            designqa.append(dict(dataset=ds, model=model, rank=rank, n_columns=X.shape[1], condition_number=float(fit.condition_number), max_leverage=float(fit.get_influence().hat_matrix_diag.max())))
        for col in ['fibroblast', 'epithelial', 'immune']:
            h = d.loc[d.PD == 0, col]
            pdv = d.loc[d.PD == 1, col]
            fractiontests.append(dict(dataset=ds, cell_group=col, median_H=float(h.median()), median_PD=float(pdv.median()), median_difference=float(pdv.median() - h.median()), wilcox_p=float(stats.mannwhitneyu(pdv, h, alternative='two-sided', method='asymptotic').pvalue)))
        inputs.append(d.reset_index())
        shutil.copy2(der / f'D11_{ds}_Bisque_cell_fractions.csv', SD / f'original_{ds}_Bisque_cell_fractions.csv')
    models = pd.DataFrame(allmodels)
    raw = models[(models.model == 'Unadjusted') & (models.variance == 'OLS')].set_index('dataset').PD_beta
    models['beta_attenuation_pct'] = [100 * (1 - b / raw[ds]) for b, ds in zip(models.PD_beta, models.dataset)]
    pd.concat(inputs).to_csv(SD / '06_bulk_model_input.csv', index=False)
    models.to_csv(SD / '07_bulk_four_models_and_HC3.csv', index=False)
    pd.DataFrame(fractiontests).to_csv(SD / '08_bulk_fraction_group_tests.csv', index=False)
    pd.DataFrame(designqa).to_csv(SD / '09_model_design_QA.csv', index=False)
    print('B models:\n', models[models.variance == 'OLS'].to_string(index=False), flush=True)
    for ds in raw.index:
        old = pd.read_csv(der / f'D11_{ds}_Bisque_GDF15_models.csv')
        for current, previous in [('Unadjusted', 'unadjusted'), ('All-major-cell-adjusted', 'composition_adjusted')]:
            v = models[(models.dataset == ds) & (models.model == current) & (models.variance == 'OLS')].iloc[0]
            ov = old[old.model == previous].iloc[0]
            if not np.allclose(v[['PD_beta', 'PD_p']].astype(float), ov[['PD_beta', 'PD_p']].astype(float), rtol=1e-08, atol=1e-10):
                raise ValueError('Reused model does not reproduce prior results')
    return models
if __name__ == '__main__':
    plan = dict(primary_panel_A='FANTOM5 three paired clinical GFs, all exact GDF15 promoters; CPM using mapped tags; two-sided exact paired sign flips', primary_panel_B='GSE223924 four prespecified models; GSE173078 full independent cohort sensitivity', other_major_cells='epithelial plus pooled immune; omitted reference = endothelial/mural/neural; avoiding compositional collinearity', selection='Clinical paired design selected before testing GDF15; no dataset switching based on statistical significance', inference='Associations and composition sensitivity do not establish fibroblast causation', sources=[BASE + ANN, BASE + COUNTS, 'https://pmc.ncbi.nlm.nih.gov/articles/PMC5028883/', 'https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE223924', 'https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE173078', 'https://www.nature.com/articles/s41467-020-15816-6'])
    (SD / '00_analysis_plan.json').write_text(json.dumps(plan, indent=2, ensure_ascii=False), encoding='utf-8')
    clinical_panel()
    composition_panel()
    hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in RAW.glob('*.gz')}
    (SD / '10_raw_file_SHA256.json').write_text(json.dumps(hashes, indent=2), encoding='utf-8')
    shutil.copy2(__file__, CODE / Path(__file__).name)
    print('[DONE] Analysis and audited source tables complete', flush=True)
