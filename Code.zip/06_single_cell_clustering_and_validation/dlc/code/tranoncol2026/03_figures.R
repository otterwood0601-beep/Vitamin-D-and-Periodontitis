options(stringsAsFactors = FALSE)
set.seed(20260915L)

.libPaths(c(
  "C:/Users/Lin/R/win-library/4.5",
  "C:/Users/Lin/AppData/Local/R/win-library/4.5",
  "C:/Program Files/R/R-4.5.3/library"
))

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(ggrepel)
  library(cowplot)
  library(patchwork)
  library(igraph)
  library(scales)
  library(ragg)
  library(png)
  library(grid)
})

ROOT <- "C:/wb_links/dlc"
DAT <- Sys.getenv("DLC_ANALYSIS_DIR", file.path(ROOT, "data_derived/tranoncol2026"))
OUT <- Sys.getenv("DLC_FIGURE_OUT", "C:/wb_links/tranoncol_out")
RASTER_OUT <- Sys.getenv("DLC_FIGURE_RASTER_OUT", "C:/wb_links/tranoncol_renders")
OUTPUT_TAG <- Sys.getenv("DLC_OUTPUT_TAG", "")
SC_DATASET_LABEL <- Sys.getenv("DLC_SC_DATASET_LABEL", "Gingival scRNA")
SIGNATURE_SOURCE_TITLE <- Sys.getenv("DLC_SIGNATURE_SOURCE_TITLE",
                                     "GDF15-associated signature specificity")
SIGNATURE_SOURCE_AXIS <- Sys.getenv("DLC_SIGNATURE_SOURCE_AXIS",
                                    "scRNA GDF15 association t")
dir.create(OUT, recursive = TRUE, showWarnings = FALSE)
dir.create(RASTER_OUT, recursive = TRUE, showWarnings = FALSE)

FONT <- "Arial"
TEAL <- "#86C7BC"
ORANGE <- "#F0A04B"
BLUE <- "#395E9D"
RED <- "#C74440"
GREY <- "#B7B7B7"
TYPE_COLORS <- c(
  "Immune" = "#4FA8C5",
  "ECM remodeling" = "#6CB354",
  "Vascular" = "#F29A3A",
  "Pre-ECM" = "#D95C5C",
  "Matrix homeostasis" = "#9880B9"
)
MODULE_COLORS <- c(
  "green" = "#66BC29", "blue" = "#2A55A5", "turquoise" = "#65C7C8",
  "red" = "#ED1C24", "yellow" = "#F4E500", "brown" = "#B02525"
)

theme_article <- theme_gray(base_size = 6.4, base_family = FONT) +
  theme(
    panel.grid.major = element_line(colour = "#D8D8D8", linewidth = 0.22),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(colour = "#777777", fill = NA, linewidth = 0.35),
    axis.text = element_text(colour = "black", size = 5.7),
    axis.title = element_text(colour = "black", size = 6.3),
    strip.background = element_blank(),
    strip.text = element_text(colour = "black", face = "bold", size = 6.2),
    legend.title = element_text(size = 5.7),
    legend.text = element_text(size = 5.1),
    plot.title = element_text(size = 6.8, face = "bold", hjust = 0.5),
    plot.margin = margin(2, 2, 2, 2, unit = "pt")
  )

theme_umap <- theme_void(base_family = FONT) +
  theme(
    plot.title = element_text(size = 6.5, face = "bold", hjust = 0.5,
                              margin = margin(b = 1.5, unit = "pt")),
    legend.title = element_text(size = 5.8),
    legend.text = element_text(size = 5.0),
    legend.key.height = unit(7, "pt"),
    legend.key.width = unit(5, "pt"),
    plot.margin = margin(1, 1, 1, 1, unit = "pt")
  )

tag_panel <- function(p, lab, pad = 0.035, size = 15) {
  ggdraw() +
    draw_plot(p, x = pad, y = 0, width = 1 - pad, height = 0.97) +
    draw_label(lab, x = 0.003, y = 0.995, hjust = 0, vjust = 1,
               fontfamily = FONT, fontface = "plain", size = size)
}

save_exact <- function(plot, stem, width_px, height_px) {
  png_path <- file.path(RASTER_OUT, paste0(stem, ".png"))
  pdf_path <- file.path(OUT, paste0(stem, ".pdf"))
  tif_path <- file.path(RASTER_OUT, paste0(stem, ".tiff"))
  agg_png(png_path, width = width_px, height = height_px, units = "px",
          res = 300, background = "white")
  print(plot); dev.off()
  cairo_pdf(pdf_path, width = width_px / 300, height = height_px / 300,
            family = FONT, onefile = TRUE)
  print(plot); dev.off()
  agg_tiff(tif_path, width = width_px, height = height_px, units = "px",
           res = 300, compression = "lzw", background = "white")
  print(plot); dev.off()
  invisible(c(png_path, pdf_path, tif_path))
}

add_umap_axes <- function(p, x, y) {
  xr <- range(x, na.rm = TRUE); yr <- range(y, na.rm = TRUE)
  x0 <- xr[1] + 0.05 * diff(xr); y0 <- yr[1] + 0.07 * diff(yr)
  p +
    annotate("segment", x = x0, xend = x0 + 0.19 * diff(xr), y = y0, yend = y0,
             arrow = arrow(length = unit(2.8, "pt")), linewidth = 0.35) +
    annotate("segment", x = x0, xend = x0, y = y0, yend = y0 + 0.19 * diff(yr),
             arrow = arrow(length = unit(2.8, "pt")), linewidth = 0.35) +
    annotate("text", x = x0 + 0.095 * diff(xr), y = y0 - 0.06 * diff(yr),
             label = "UMAP1", size = 1.7, family = FONT) +
    annotate("text", x = x0 - 0.06 * diff(xr), y = y0 + 0.095 * diff(yr),
             label = "UMAP2", angle = 90, size = 1.7, family = FONT)
}

short_term <- function(x, n = 36L) {
  x <- gsub(" \\(GO:[0-9]+\\)$", "", x)
  x <- gsub("_", " ", x, fixed = TRUE)
  ifelse(nchar(x) > n, paste0(substr(x, 1, n - 1), "…"), x)
}

network_plot <- function(nodes, edges, title = NULL, max_edges = 360L,
                         label_reps = 10L) {
  nodes <- copy(nodes)
  edges <- copy(edges)
  nodes[, cluster := as.character(cluster)]
  nodes[is.na(cluster) | cluster == "", cluster := "1"]
  if (nrow(edges) > max_edges) edges <- edges[order(-jaccard)][1:max_edges]
  gr <- graph_from_data_frame(edges, directed = FALSE, vertices = nodes$term)
  set.seed(20260915L)
  lay <- layout_with_fr(gr, weights = if ("jaccard" %in% names(edges)) E(gr)$jaccard else NULL,
                        niter = 1200)
  lay[, 1] <- rescale(lay[, 1], to = c(-1, 1))
  lay[, 2] <- rescale(lay[, 2], to = c(-1, 1))
  nd <- data.table(term = V(gr)$name, x = lay[, 1], y = lay[, 2])
  nd[nodes, on = "term", `:=`(cluster = i.cluster, cluster_label = i.cluster_label,
                                padj = i.padj, hit = i.hit)]
  ed <- as_data_frame(gr, what = "edges")
  ed <- as.data.table(ed)
  ed[nd, on = c(from = "term"), `:=`(x = i.x, y = i.y)]
  ed[nd, on = c(to = "term"), `:=`(xend = i.x, yend = i.y)]
  cl_order <- nodes[, .N, by = .(cluster, cluster_label)][order(-N, cluster)]
  cl_order[, cluster_f := factor(cluster, levels = cluster)]
  nd[cl_order, on = "cluster", cluster_f := i.cluster_f]
  net_cols <- if (nrow(cl_order) == 1L) "#4FA8C5" else hcl.colors(nrow(cl_order), "Set 3")
  pal <- setNames(net_cols, levels(cl_order$cluster_f))
  labels <- nd[term == cluster_label][order(padj)][1:min(label_reps, .N)]
  labels[, lab := short_term(term)]
  ggplot() +
    geom_segment(data = ed, aes(x, y, xend = xend, yend = yend),
                 colour = "#A8A8A8", alpha = 0.45, linewidth = 0.25) +
    geom_point(data = nd, aes(x, y, fill = cluster_f, size = pmin(-log10(padj), 12)),
               shape = 21, colour = "white", stroke = 0.18) +
    geom_text_repel(data = labels, aes(x, y, label = lab, colour = cluster_f),
                    family = FONT, size = 1.7, max.overlaps = Inf,
                    min.segment.length = 0, segment.size = 0.2, box.padding = 0.2,
                    show.legend = FALSE) +
    scale_fill_manual(values = pal, name = NULL,
                      labels = short_term(cl_order$cluster_label, 30)) +
    scale_colour_manual(values = pal, guide = "none") +
    scale_size_continuous(range = c(1.2, 3.2), guide = "none") +
    coord_equal(clip = "off") +
    theme_void(base_family = FONT) +
    theme(legend.position = "none",
          plot.title = element_text(size = 6.5, face = "bold", hjust = 0.5),
          plot.margin = margin(1, 2, 1, 1, unit = "pt")) +
    labs(title = title)
}

cat("Build Fig.2-style receptor feasibility screen\n")
rec <- fread(file.path(DAT, "01_receptor_detection_by_celltype.csv"))
overall <- fread(file.path(DAT, "02_receptor_overall_summary.csv"))
genes_rec <- c("GDF15", "GFRAL", "RET", "ERBB2", "EGFR")
rec <- rec[gene %in% genes_rec]
ord_ct <- rec[gene == "GDF15"][order(-detection_fraction)]$cell_type
rec[, cell_type := factor(cell_type, levels = rev(ord_ct))]
rec[, gene := factor(gene, levels = genes_rec)]
rec[, log_detection := log10(detection_fraction + 1e-5)]

p2A <- ggplot(rec, aes(gene, cell_type, fill = log_detection)) +
  geom_tile(colour = "white", linewidth = 0.28) +
  scale_fill_gradient2(low = "#31578B", mid = "white", high = "#C94540",
                       midpoint = -2, name = "log10(detection\n+ 10^-5)") +
  labs(x = NULL, y = NULL, title = "Detection across human gingival cell types") +
  theme_article + theme(axis.text.y = element_text(size = 4.6),
                        axis.text.x = element_text(angle = 45, hjust = 1))

p2B <- ggplot(rec, aes(gene, cell_type)) +
  geom_point(aes(size = detection_fraction * 100, colour = mean_expression_all_cells)) +
  scale_colour_gradient(low = "#E2E2E2", high = "#C7352E", name = "Mean\nexpression") +
  scale_size_continuous(range = c(0.15, 4.2), name = "% detected") +
  labs(x = NULL, y = NULL, title = "Expression and detection by cell type") +
  theme_article + theme(axis.text.y = element_text(size = 4.6),
                        axis.text.x = element_text(angle = 45, hjust = 1))

fib_over <- overall[scope == "Fibroblasts" & gene %in% c("GDF15", "GFRAL", "RET", "MAPK1", "MAPK3")]
node_order <- c("GDF15", "GFRAL", "RET", "MAPK1", "MAPK3")
node_xy <- data.table(gene = node_order,
                      x = c(0, 1, 2, 3.1, 3.1),
                      y = c(0, 0, 0, 0.38, -0.38))
node_xy[fib_over, on = "gene", `:=`(frac = i.detection_fraction,
                                      n_det = i.n_detected, n_cells = i.n_cells)]
node_xy[is.na(frac), `:=`(frac = 0, n_det = 0)]
gfral_note <- node_xy[gene == "GFRAL",
  sprintf("GFRAL: %s/%s fibroblasts", comma(n_det), comma(n_cells))]
edge_xy <- data.table(x = c(0.15, 1.15, 2.15, 2.15), y = c(0, 0, 0, 0),
                      xend = c(0.85, 1.85, 2.95, 2.95), yend = c(0, 0, 0.38, -0.38),
                      supported = c(TRUE, FALSE, TRUE, TRUE))
p2C <- ggplot() +
  geom_segment(data = edge_xy, aes(x, y, xend = xend, yend = yend,
                                    linetype = supported),
               arrow = arrow(length = unit(4, "pt")), linewidth = 0.65,
               colour = "#555555") +
  geom_point(data = node_xy, aes(x, y, fill = log10(frac + 1e-5)),
             shape = 21, size = 9, stroke = 0.7, colour = "black") +
  geom_text(data = node_xy, aes(x, y, label = gene), family = FONT,
            fontface = "bold", size = 2.3) +
  annotate("text", x = 1, y = -0.48, label = gfral_note,
           family = FONT, size = 2.2, colour = RED) +
  annotate("text", x = 1.55, y = 0.62,
           label = "Canonical GDF15-GFRAL-RET signaling is not estimable",
           family = FONT, size = 2.4, fontface = "bold") +
  scale_fill_gradient2(low = "white", mid = "#F6C9B9", high = "#C43E35",
                       midpoint = -2, guide = "none") +
  scale_linetype_manual(values = c(`TRUE` = "solid", `FALSE` = "dashed"), guide = "none") +
  coord_cartesian(xlim = c(-0.35, 3.55), ylim = c(-0.75, 0.82), clip = "off") +
  theme_void(base_family = FONT) +
  labs(title = "Canonical receptor prerequisite in gingival fibroblasts") +
  theme(plot.title = element_text(size = 6.8, face = "bold", hjust = 0.5))

overall_plot <- overall[gene %in% genes_rec]
overall_plot[, pct_for_plot := pmax(detection_fraction * 100, 1e-4)]
p2D <- ggplot(overall_plot, aes(gene, pct_for_plot, colour = scope, shape = scope,
                                group = scope)) +
  geom_line(linewidth = 0.5) + geom_point(size = 2.2, stroke = 0.5) +
  scale_y_log10(labels = label_number(accuracy = 0.001),
                breaks = c(1e-4, 1e-3, 1e-2, 0.1, 1, 10, 100)) +
  scale_colour_manual(values = c("All gingival cells" = TEAL, "Fibroblasts" = ORANGE)) +
  scale_shape_manual(values = c("All gingival cells" = 16, "Fibroblasts" = 17)) +
  labs(x = NULL, y = "Detected cells (%) - log scale", colour = NULL, shape = NULL,
       title = "Detection in whole gingiva and fibroblasts") +
  theme_article + theme(axis.text.x = element_text(angle = 45, hjust = 1),
                        legend.position = "top")

gdf_ct <- rec[gene == "GDF15" & n_detected > 0][order(n_detected)]
p2E <- ggplot(gdf_ct, aes(n_detected, cell_type)) +
  geom_segment(aes(x = 0, xend = n_detected, yend = cell_type),
               colour = "#BDBDBD", linewidth = 0.45) +
  geom_point(aes(colour = detection_fraction), size = 2.1) +
  scale_colour_gradient(low = "#F6D7C8", high = "#B3312B", name = "Detection\nfraction") +
  labs(x = "GDF15-positive cells (n)", y = NULL,
       title = "Cellular sources of detectable GDF15") +
  theme_article + theme(axis.text.y = element_text(size = 4.8))

decision <- data.table(
  component = c("Ligand", "Obligate receptor", "Co-receptor/kinase", "Downstream genes"),
  item = c("GDF15", "GFRAL", "RET", "MAPK1 / MAPK3"),
  observed = c("Detected but sparse", "Absent in fibroblasts", "Detected without GFRAL",
               "Expressed;\nno phospho-ERK data"),
  status = factor(c("Available", "Fails prerequisite", "Insufficient alone", "Transcript only"),
                  levels = c("Available", "Fails prerequisite", "Insufficient alone", "Transcript only"))
)
p2F <- ggplot(decision, aes(status, component, fill = status)) +
  geom_tile(colour = "white", linewidth = 0.7) +
  geom_text(aes(label = paste0(item, "\n", observed)), family = FONT, size = 2.0,
            lineheight = 0.9) +
  scale_fill_manual(values = c("Available" = TEAL, "Fails prerequisite" = "#D8655A",
                               "Insufficient alone" = "#E6B56B", "Transcript only" = "#9AB4D2"),
                    guide = "none") +
  labs(x = NULL, y = NULL, title = "Eligibility decision for communication analysis") +
  theme_minimal(base_family = FONT, base_size = 6.2) +
  theme(panel.grid = element_blank(), axis.text.x = element_blank(), axis.ticks = element_blank(),
        plot.title = element_text(size = 6.8, face = "bold", hjust = 0.5),
        axis.text.y = element_text(colour = "black", size = 5.5))

fig2 <- plot_grid(
  plot_grid(tag_panel(p2A, "A"), tag_panel(p2B, "B"), nrow = 1, rel_widths = c(1, 1)),
  plot_grid(tag_panel(p2C, "C"), tag_panel(p2D, "D"), nrow = 1, rel_widths = c(1.08, 0.92)),
  plot_grid(tag_panel(p2E, "E"), tag_panel(p2F, "F"), nrow = 1, rel_widths = c(0.9, 1.1)),
  ncol = 1, rel_heights = c(1.12, 0.82, 0.82)
)

cat("Build Fig.3-style fibroblast state figure\n")
cell <- fread(file.path(DAT, "05_cell_marker_and_program_scores.csv.gz"))
cell[, fibroblast_short := factor(fibroblast_short, levels = names(TYPE_COLORS))]
cell <- cell[sample(.N)]
cent <- cell[, .(x = median(frozen_umap_1), y = median(frozen_umap_2)), by = fibroblast_short]
cent[, label := fifelse(fibroblast_short == "ECM remodeling", "ECM",
                        fifelse(fibroblast_short == "Matrix homeostasis", "Homeost.",
                                as.character(fibroblast_short)))]
cent[, `:=`(label_x = x, label_y = y)]
cent[fibroblast_short == "Immune", `:=`(label_x = -3.6, label_y = 1.3)]
cent[fibroblast_short == "Vascular", `:=`(label_x = 1.4, label_y = 3.5)]
cent[fibroblast_short == "ECM remodeling", `:=`(label_x = 4.2, label_y = -1.6)]
cent[fibroblast_short == "Pre-ECM", `:=`(label_x = -3.7, label_y = -4.8)]
cent[fibroblast_short == "Matrix homeostasis", `:=`(label_x = -0.5, label_y = -2.6)]
p3A <- ggplot(cell, aes(frozen_umap_1, frozen_umap_2, colour = fibroblast_short)) +
  geom_point(size = 0.12, alpha = 0.78) +
  geom_label(data = cent, aes(label_x, label_y, label = label),
             family = FONT, size = 1.65, colour = "black",
             fill = alpha("white", 0.78), label.size = NA,
             label.padding = unit(0.08, "lines"), show.legend = FALSE) +
  scale_colour_manual(values = TYPE_COLORS, name = "Celltype") +
  coord_equal() + theme_umap
p3A <- add_umap_axes(p3A, cell$frozen_umap_1, cell$frozen_umap_2)

feature_violin <- function(g) {
  d <- cell[order(get(g))]
  lim <- quantile(d[[g]], 0.995, na.rm = TRUE)
  pf <- ggplot(d, aes(frozen_umap_1, frozen_umap_2, colour = pmin(get(g), lim))) +
    geom_point(size = 0.10) + coord_equal() +
    scale_colour_gradientn(colours = c("#D8D8D8", "#F6C1B4", "#D7301F"),
                           name = NULL) + theme_umap + labs(title = g)
  pv <- ggplot(cell, aes(fibroblast_short, get(g), fill = fibroblast_short)) +
    geom_violin(scale = "width", trim = TRUE, linewidth = 0.2, colour = "#777777") +
    scale_fill_manual(values = TYPE_COLORS, guide = "none") +
    labs(x = "Celltype", y = "Expression", title = g) + theme_article +
    theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 4.2),
          plot.title = element_blank())
  plot_grid(pf, pv, nrow = 1, rel_widths = c(0.44, 0.56))
}
p3B <- plot_grid(feature_violin("GDF15"), feature_violin("MAPK1"),
                 feature_violin("MAPK3"), feature_violin("JUND"),
                 ncol = 2)

cell_sum <- fread(file.path(DAT, "06_cell_score_subtype_disease_summary.csv"))
curated_dot <- cell_sum[feature %in% c("MAPK_ERK", "MAPK_JNK_p38", "ECM_synthesis",
                                      "ECM_organization", "ECM_degradation", "ECM_inhibitors",
                                      "ECM_adhesion", "WNT_niche"),
                        .(value = mean(mean), size_value = mean(detection_or_positive_fraction)),
                        by = .(fibroblast_short, pathway = feature)]
curated_dot[, value_z := as.numeric(scale(value)), by = pathway]
prog_dt <- fread(file.path(DAT, "07_PROGENy_pathway_by_fibroblast_subtype.csv"))
prog_dt[, fibroblast_short := gsub("\\.", " ", fibroblast_short)]
prog_dot <- prog_dt[, .(fibroblast_short, pathway = paste0("PROGENy ", pathway),
                        value_z = activity_z, size_value = pmin(abs(activity_z) / 2.5, 1))]
dot <- rbindlist(list(curated_dot[, .(fibroblast_short, pathway, value_z, size_value)], prog_dot),
                 fill = TRUE)
dot[, fibroblast_short := factor(fibroblast_short, levels = names(TYPE_COLORS))]
dot[, pathway := factor(pathway, levels = rev(unique(pathway)))]
p3C <- ggplot(dot, aes(fibroblast_short, pathway)) +
  geom_point(aes(fill = value_z, size = size_value), shape = 21, colour = "#777777", stroke = 0.15) +
  scale_fill_gradient2(low = "#31558C", mid = "white", high = "#C6423B", midpoint = 0,
                       limits = c(-2.5, 2.5), oob = squish, name = "Z score") +
  scale_size_continuous(range = c(0.5, 3.2), name = "Relative\nmagnitude") +
  labs(x = NULL, y = NULL, title = "Pathway activity patterns") +
  theme_article + theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 4.4),
                        axis.text.y = element_text(size = 4.2))

score_umap_violin <- function(s, title) {
  d <- cell[order(get(s))]
  lims <- quantile(d[[s]], c(0.01, 0.99), na.rm = TRUE)
  pu <- ggplot(d, aes(frozen_umap_1, frozen_umap_2, colour = pmin(pmax(get(s), lims[1]), lims[2]))) +
    geom_point(size = 0.10) + coord_equal() +
    scale_colour_gradientn(colours = c("#2469A0", "#F4E95B", "#D94A3A"), name = NULL) +
    theme_umap + labs(title = title)
  pv <- ggplot(cell, aes(fibroblast_short, get(s), fill = fibroblast_short)) +
    geom_violin(scale = "width", trim = TRUE, linewidth = 0.2, colour = "#777777") +
    geom_boxplot(width = 0.13, outlier.shape = NA, fill = "white", linewidth = 0.22) +
    scale_fill_manual(values = TYPE_COLORS, guide = "none") +
    labs(x = "Celltype", y = "UCell score") + theme_article +
    theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 4.0))
  plot_grid(pu, pv, ncol = 1, rel_heights = c(0.62, 0.38))
}
p3D <- plot_grid(score_umap_violin("MAPK_ERK", "MAPK/ERK response"),
                 score_umap_violin("ECM_synthesis", "Collagen synthesis"),
                 score_umap_violin("ECM_organization", "ECM organization"), nrow = 1)

prog_heat <- copy(prog_dt)
prog_heat[, fibroblast_short := factor(fibroblast_short, levels = names(TYPE_COLORS))]
prog_heat[, pathway := factor(pathway, levels = rev(unique(pathway)))]
p3E <- ggplot(prog_heat, aes(fibroblast_short, pathway, fill = activity_z)) +
  geom_tile(colour = "#777777", linewidth = 0.25) +
  scale_fill_gradient2(low = "#31558C", mid = "white", high = "#C6423B",
                       midpoint = 0, limits = c(-2.2, 2.2), oob = squish, name = "Activity") +
  labs(x = NULL, y = NULL, title = "Signaling pathway activity") +
  theme_article + theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5, size = 4.4),
                        axis.text.y = element_text(size = 4.5), legend.position = "right")

vde <- fread(file.path(DAT, "08_vascular_vs_other_donor_aware_DE.csv.gz"))
vde[, logFDR := -log10(pmax(adj.P.Val, 1e-300))]
lab_v <- unique(rbind(vde[order(adj.P.Val)][1:6], vde[gene %in% c("GDF15", "THBS2", "COL1A1", "COL1A2")]))
p3F <- ggplot(vde, aes(diff_detection, logFDR, colour = logFC)) +
  geom_point(size = 0.65, alpha = 0.65) +
  geom_hline(yintercept = -log10(0.05), linewidth = 0.35, colour = "#555555") +
  geom_vline(xintercept = 0, linewidth = 0.35, colour = "#555555") +
  geom_text_repel(data = lab_v, aes(label = gene), size = 1.9, family = FONT,
                  max.overlaps = Inf, min.segment.length = 0, segment.size = 0.2) +
  scale_colour_gradient2(low = "#31558C", mid = "#F7F2E8", high = "#B63B36",
                         midpoint = 0, name = "log2FC") +
  labs(x = "Difference in detection fraction", y = "-log10(BH FDR)",
       title = "Vascular vs other fibroblast states") + theme_article

vn <- fread(file.path(DAT, "09_vascular_enrichment_network_nodes.csv"))
ve <- fread(file.path(DAT, "09_vascular_enrichment_network_edges.csv"))
p3G <- network_plot(vn, ve, title = "Functional enrichment network", label_reps = 9)

fig3 <- plot_grid(
  plot_grid(tag_panel(p3A, "A"), tag_panel(p3B, "B"), nrow = 1, rel_widths = c(0.29, 0.71)),
  plot_grid(tag_panel(p3C, "C"), tag_panel(p3D, "D"), nrow = 1, rel_widths = c(0.31, 0.69)),
  plot_grid(tag_panel(p3E, "E"), tag_panel(p3F, "F", pad = 0.075), tag_panel(p3G, "G"),
            nrow = 1, rel_widths = c(0.31, 0.25, 0.44)),
  ncol = 1, rel_heights = c(0.27, 0.36, 0.37)
)

cat("Build Fig.4-style GDF15 signature figure\n")
spec <- fread(file.path(DAT, "12_signature_expression_specificity.csv.gz"))
cat_cols <- c("MAPK/ERK response" = "#D73027", "ECM/collagen" = "#377EB8",
              "AP-1" = "#4DAF4A", "Other signature gene" = "#7F7F7F")
p4A <- ggplot(spec, aes(log10_mean_CPM, maximum_subtype_specificity)) +
  geom_point(data = spec[in_signature == FALSE], colour = "#CFCFCF", size = 0.35, alpha = 0.55) +
  geom_point(data = spec[in_signature == TRUE], aes(colour = category), size = 1.1, alpha = 0.85) +
  geom_text_repel(data = spec[in_signature == TRUE][order(-maximum_subtype_specificity)][1:8],
                  aes(label = gene, colour = category), family = FONT, size = 1.8,
                  max.overlaps = Inf, min.segment.length = 0, segment.size = 0.2,
                  show.legend = FALSE) +
  scale_colour_manual(values = cat_cols, name = NULL) +
  labs(x = "log10 mean expression (CPM)", y = "Maximum subtype specificity",
       title = SIGNATURE_SOURCE_TITLE) +
  theme_article + theme(legend.position = c(0.73, 0.25), legend.background = element_blank())

cross <- fread(file.path(DAT, "18_scRNA_bulk_signature_preservation.csv.gz"))
bulk_score <- fread(file.path(DAT, "13_bulk_signature_and_pathway_scores.csv"))
pres_panel <- function(ds) {
  d <- cross[dataset == ds & feature_biotype == "protein_coding"]
  rho <- unique(d$preservation_rho)[1]; pval <- unique(d$preservation_p)[1]
  ps <- ggplot(d, aes(sc_t, bulk_t)) +
    geom_point(size = 0.28, colour = "#BDBDBD", alpha = 0.55) +
    geom_smooth(method = "lm", se = FALSE, colour = "#EE6A55", linewidth = 0.55,
                linetype = "dashed") +
    annotate("text", x = Inf, y = -Inf,
             label = sprintf("Spearman R = %.3f\nP = %.3g", rho, pval),
             hjust = 1.05, vjust = -0.25, family = FONT, size = 2.0) +
    labs(x = SIGNATURE_SOURCE_AXIS, y = "Bulk score association t",
         title = "protein coding") + theme_article
  b <- bulk_score[dataset == ds]
  p_group <- wilcox.test(GDF15_signature ~ group, data = b, exact = FALSE)$p.value
  pv <- ggplot(b, aes(group, GDF15_signature, fill = group)) +
    geom_violin(trim = TRUE, scale = "width", linewidth = 0.25, colour = "#777777") +
    geom_boxplot(width = 0.18, outlier.shape = NA, fill = "white", linewidth = 0.25) +
    geom_jitter(width = 0.07, size = 0.75, shape = 21, fill = "white", stroke = 0.2) +
    scale_fill_manual(values = c("Healthy" = TEAL, "Periodontitis" = ORANGE), guide = "none") +
    annotate("text", x = 1.5, y = Inf, label = sprintf("P = %.3g", p_group),
             vjust = 1.2, family = FONT, size = 2.0) +
    labs(x = NULL, y = "ssGSEA", title = ds) + theme_article +
    theme(axis.text.x = element_text(angle = 35, hjust = 1, size = 4.7))
  plot_grid(ps, pv, nrow = 1, rel_widths = c(0.66, 0.34))
}
p4B <- pres_panel("GSE223924")
p4C <- pres_panel("GSE173078")

meta <- fread(file.path(DAT, "19_bulk_signature_association_meta.csv.gz"))
meta[, regulation := fifelse(meta_fdr < 0.05 & meta_beta > 0, "Up-regulated",
                             fifelse(meta_fdr < 0.05 & meta_beta < 0, "Down-regulated", "Not significant"))]
meta[, logFDR := -log10(pmax(meta_fdr, 1e-300))]
lab_m <- meta[order(meta_fdr)][1:12]
p4D <- ggplot(meta, aes(meta_beta, logFDR, colour = regulation)) +
  geom_point(size = 0.7, alpha = 0.75) +
  geom_vline(xintercept = 0, linetype = "dashed", linewidth = 0.35) +
  geom_hline(yintercept = -log10(0.05), linetype = "dashed", linewidth = 0.35) +
  geom_text_repel(data = lab_m, aes(label = gene), family = FONT, size = 1.8,
                  max.overlaps = Inf, min.segment.length = 0, segment.size = 0.2,
                  show.legend = FALSE) +
  scale_colour_manual(values = c("Down-regulated" = "#4C5D9A", "Not significant" = "#777777",
                                 "Up-regulated" = "#C96342"), name = "Regulation") +
  labs(x = "Meta coefficient (per 1-SD signature)", y = "-log10(BH FDR)",
       title = "Adjusted gene association") + theme_article +
  theme(plot.title = element_text(size = 6.2, face = "bold", hjust = 0.5))

sn <- fread(file.path(DAT, "20_signature_meta_enrichment_network_nodes.csv"))
se <- fread(file.path(DAT, "20_signature_meta_enrichment_network_edges.csv"))
p4E <- network_plot(sn, se, title = "Functional enrichment network", label_reps = 10)

rc <- fread(file.path(DAT, "22_MAPK_ERK_running_enrichment_curve.csv"))
gsea_stat <- unique(rc[, .(NES, padj)])[1]
p4F <- ggplot(rc, aes(rank, running_ES, colour = statistic)) +
  geom_line(linewidth = 0.75) +
  geom_hline(yintercept = 0, linetype = "dashed", linewidth = 0.4) +
  geom_segment(data = rc[hit == TRUE], aes(x = rank, xend = rank, y = min(running_ES) - 0.10,
                                            yend = min(running_ES) - 0.02),
               inherit.aes = FALSE, linewidth = 0.18, colour = "black") +
  scale_colour_gradient2(low = "#2C8C62", mid = "#D6CC5A", high = "#D8483E",
                         midpoint = 0, guide = "none") +
  annotate("text", x = Inf, y = Inf,
           label = sprintf("NES = %.2f\nAdjusted P = %.3g", gsea_stat$NES, gsea_stat$padj),
           hjust = 1.05, vjust = 1.15, family = FONT, size = 2.1) +
  labs(x = "Rank in ordered dataset", y = "Running enrichment score",
       title = "MAPK/ERK transcriptional response") + theme_article

pooled <- fread(file.path(DAT, "23_pooled_bulk_standardized_scores.csv"))
assoc <- fread(file.path(DAT, "24_signature_pathway_associations.csv"))
paths4 <- c("MAPK_ERK", "ECM_synthesis", "ECM_organization", "ECM_degradation")
title4 <- c("MAPK/ERK", "Collagen synthesis", "ECM organization", "ECM degradation")
violin_score <- function(pn, ttl) {
  d <- pooled[, .(signature_group, value = get(paste0(pn, "_z")))]
  pp <- assoc[pathway == pn]$high_vs_low_p
  ggplot(d, aes(signature_group, value, fill = signature_group)) +
    geom_violin(scale = "width", trim = TRUE, linewidth = 0.25, colour = "#777777") +
    geom_boxplot(width = 0.2, outlier.shape = NA, fill = "#F4C77C", linewidth = 0.28) +
    geom_jitter(width = 0.08, size = 0.55, alpha = 0.55) +
    scale_fill_manual(values = c("Low" = TEAL, "High" = ORANGE), guide = "none") +
    annotate("text", x = 1.5, y = Inf, label = sprintf("P = %.3g", pp),
             vjust = 1.1, size = 1.9, family = FONT) +
    labs(x = NULL, y = "Cohort-standardized ssGSEA", title = ttl) + theme_article
}
p4G <- plot_grid(plotlist = Map(violin_score, paths4, title4), nrow = 1)

scatter_score <- function(pn, ttl) {
  d <- pooled[, .(x = signature_z_cohort, y = get(paste0(pn, "_z")), dataset)]
  st <- assoc[pathway == pn]
  ggplot(d, aes(x, y)) +
    geom_point(size = 0.7, colour = TEAL, alpha = 0.7) +
    geom_smooth(method = "lm", se = TRUE, colour = ORANGE, fill = "#E4E4E4", linewidth = 0.55) +
    annotate("text", x = Inf, y = -Inf,
             label = sprintf("Spearman R = %.3f\nP = %.3g\nAdjusted P = %.3g",
                             st$spearman_rho, st$spearman_p,
                             st$disease_composition_adjusted_p),
             hjust = 1.05, vjust = -0.2, family = FONT, size = 1.75) +
    labs(x = "GDF15 signature (Z)", y = ttl, title = ttl) + theme_article +
    theme(plot.title = element_text(size = 5.9, face = "bold", hjust = 0.5),
          axis.title = element_text(size = 5.4))
}
p4H <- plot_grid(plotlist = Map(scatter_score, paths4, title4), nrow = 1)

fig4 <- plot_grid(
  plot_grid(tag_panel(p4A, "A"),
            plot_grid(tag_panel(p4B, "B"), tag_panel(p4C, "C"), ncol = 1),
            nrow = 1, rel_widths = c(0.34, 0.66)),
  plot_grid(tag_panel(p4D, "D", pad = 0.070), tag_panel(p4E, "E"), nrow = 1,
            rel_widths = c(0.34, 0.66)),
  plot_grid(tag_panel(p4F, "F"),
            plot_grid(tag_panel(p4G, "G", pad = 0.060), tag_panel(p4H, "H", pad = 0.055), ncol = 1,
                      rel_heights = c(0.48, 0.52)),
            nrow = 1, rel_widths = c(0.34, 0.66)),
  ncol = 1, rel_heights = c(0.29, 0.28, 0.43)
)

cat("Build Fig.5-style hdWGCNA figure\n")
dendro_png <- "C:/wb_links/tranoncol_P2_dendrogram.png"
p5A <- ggdraw() +
  draw_image(dendro_png, x = 0.01, y = 0.02, width = 0.98, height = 0.95) +
  draw_label("hdWGCNA Dendrogram", x = 0.5, y = 0.97, hjust = 0.5, vjust = 1,
             fontfamily = FONT, fontface = "bold", size = 7)

mem <- fread(file.path(ROOT, "P2_hdWGCNA/outputs/02_source_data/03_module_gene_membership.csv"))
mods <- names(MODULE_COLORS)
membership_plot <- function(mn) {
  kcol <- paste0("kME_", mn)
  d <- mem[module == mn & is.finite(get(kcol)), .(gene_name, kME = get(kcol))][order(kME)]
  d[, idx := seq_len(.N)]
  labs_d <- d[order(-kME)][1:min(7, .N)]
  ggplot(d, aes(idx, kME)) +
    geom_area(fill = MODULE_COLORS[mn], alpha = 0.95) +
    geom_text_repel(data = labs_d, aes(label = gene_name), family = FONT, size = 1.45,
                    max.overlaps = Inf, min.segment.length = 0, segment.size = 0.15,
                    nudge_x = max(d$idx) * 0.05) +
    labs(x = NULL, y = "kME", title = mn) +
    theme_classic(base_family = FONT, base_size = 5.5) +
    theme(axis.text.x = element_blank(), axis.ticks.x = element_blank(),
          plot.title = element_text(size = 6.3, face = "bold", hjust = 0.5),
          plot.margin = margin(1, 2, 1, 1, unit = "pt"))
}
p5B <- plot_grid(plotlist = lapply(mods, membership_plot), ncol = 3)

mod_cell <- fread(file.path(DAT, "26_cell_hdWGCNA_top50_UCell_scores.csv.gz"))
feature_module <- function(mn) {
  d <- mod_cell[order(get(mn))]
  lim <- quantile(d[[mn]], 0.99, na.rm = TRUE)
  ggplot(d, aes(frozen_umap_1, frozen_umap_2, colour = pmin(get(mn), lim))) +
    geom_point(size = 0.10) + coord_equal() +
    scale_colour_gradient(low = "#E4E4E4", high = MODULE_COLORS[mn], guide = "none") +
    labs(title = mn) + theme_umap
}
p5C <- plot_grid(plotlist = lapply(mods, feature_module), ncol = 3)

ms <- fread(file.path(DAT, "27_hdWGCNA_module_by_subtype_summary.csv"))
ms <- ms[module %in% mods]
ms[, mean_z := as.numeric(scale(mean_score)), by = module]
ms[, module := factor(module, levels = rev(mods))]
ms[, fibroblast_short := factor(fibroblast_short, levels = names(TYPE_COLORS))]
p5D <- ggplot(ms, aes(fibroblast_short, module)) +
  geom_point(aes(size = pct_positive * 100, colour = mean_z)) +
  scale_colour_gradient2(low = "#5077A6", mid = "#E5E5E5", high = "#BD3F39",
                         midpoint = 0, guide = "none") +
  scale_size_continuous(range = c(0.8, 4.0), guide = "none") +
  labs(x = NULL, y = "Features", title = "Module scores\nsize=% positive; color=mean") +
  theme_article +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 4.4),
        plot.title = element_text(size = 5.4, face = "plain", hjust = 0.5))

tn <- fread(file.path(DAT, "28_turquoise_network_nodes.csv"))
te <- fread(file.path(DAT, "29_turquoise_network_edges.csv"))
gr <- graph_from_data_frame(te[, .(from = as.character(from), to = as.character(to), rho)],
                            directed = FALSE, vertices = tn$gene)
set.seed(20260915L)
xy <- layout_with_fr(gr, weights = E(gr)$rho, niter = 1200)
nd <- data.table(gene = V(gr)$name, x = xy[, 1], y = xy[, 2])
nd[tn, on = "gene", `:=`(kME = i.kME, category = i.category)]
ed <- as.data.table(as_data_frame(gr, what = "edges"))
ed[nd, on = c(from = "gene"), `:=`(x = i.x, y = i.y)]
ed[nd, on = c(to = "gene"), `:=`(xend = i.x, yend = i.y)]
lab_e <- nd[order(-kME)][1:min(15L, .N)]
lab_e <- unique(rbind(lab_e, nd[category == "MAPK/ERK response"], fill = TRUE), by = "gene")
net_cols <- c("Other" = "#7654A8", "MAPK/ERK response" = "#D64D43", "ECM/collagen" = "#3B76B5")
p5E <- ggplot() +
  geom_segment(data = ed, aes(x, y, xend = xend, yend = yend, alpha = rho),
               colour = "#B9A8D0", linewidth = 0.45) +
  geom_point(data = nd, aes(x, y, fill = category, size = kME), shape = 21,
             colour = "#4B3866", stroke = 0.35) +
  geom_text_repel(data = lab_e, aes(x, y, label = gene), size = 1.8, family = FONT,
                  max.overlaps = Inf, min.segment.length = 0, segment.size = 0.15) +
  scale_fill_manual(values = net_cols, name = NULL) +
  scale_size_continuous(range = c(2.0, 4.2), guide = "none") +
  scale_alpha_continuous(range = c(0.2, 0.8), guide = "none") +
  coord_equal() + theme_void(base_family = FONT) +
  theme(legend.position = "bottom", legend.text = element_text(size = 4.5),
        plot.title = element_text(size = 6.5, face = "bold", hjust = 0.5)) +
  labs(title = "turquoise")

mt <- fread(file.path(DAT, "25_module_cross_cohort_tests.csv"))
mt[, dataset := factor(dataset, levels = c(SC_DATASET_LABEL, "GSE223924", "GSE173078"))]
mt[, module := factor(module, levels = rev(mods))]
p5F <- ggplot(mt, aes(dataset, module, fill = t)) +
  geom_tile(colour = "white", linewidth = 0.45) +
  geom_text(aes(label = sprintf("%.2f", t)), family = FONT, size = 2.0) +
  scale_fill_gradient2(low = "#4FAEA6", mid = "#F4E7BF", high = "#E3A13A",
                       midpoint = 0, name = "Disease t") +
  labs(x = NULL, y = NULL, title = "Cross-cohort disease association") +
  theme_article + theme(axis.text.x = element_text(angle = 30, hjust = 1),
                        panel.grid = element_blank())

mod_scores <- fread(file.path(DAT, "16_bulk_module_scores.csv"))
turq_scores <- mod_scores[program == "turquoise"]
turq_scores[bulk_score, on = c("sample", "dataset"), `:=`(GDF15_expression = i.GDF15_expression)]
turq_scores[, score_z := as.numeric(scale(score)), by = dataset]
turq_scores[, GDF15_z := as.numeric(scale(GDF15_expression)), by = dataset]
bulk_turq_panel <- function(ds) {
  d <- turq_scores[dataset == ds]
  pp <- mt[dataset == ds & module == "turquoise"]$p
  ggplot(d, aes(group, score_z, fill = group)) +
    geom_violin(scale = "width", trim = TRUE, colour = "#777777", linewidth = 0.25) +
    geom_boxplot(width = 0.18, outlier.shape = NA, fill = "white", linewidth = 0.25) +
    geom_jitter(width = 0.07, size = 0.65) +
    scale_fill_manual(values = c("Healthy" = TEAL, "Periodontitis" = ORANGE), guide = "none") +
    annotate("text", x = 1.5, y = Inf, label = sprintf("P = %.3g", pp),
             vjust = 1.1, size = 1.9, family = FONT) +
    labs(x = NULL, y = "turquoise score (Z)", title = ds) + theme_article +
    theme(axis.text.x = element_text(angle = 35, hjust = 1, size = 4.6))
}
ct_t <- cor.test(turq_scores$GDF15_z, turq_scores$score_z, method = "spearman", exact = FALSE)
p5G3 <- ggplot(turq_scores, aes(GDF15_z, score_z, colour = group)) +
  geom_point(size = 0.9, alpha = 0.8) +
  geom_smooth(aes(group = 1), method = "lm", se = TRUE, colour = "#6C6C6C",
              fill = "#D7D7D7", linewidth = 0.5) +
  scale_colour_manual(values = c("Healthy" = TEAL, "Periodontitis" = ORANGE), name = NULL) +
  annotate("text", x = Inf, y = -Inf,
           label = sprintf("Spearman R = %.2f\nP = %.3g", unname(ct_t$estimate), ct_t$p.value),
           hjust = 1.05, vjust = -0.2, size = 1.9, family = FONT) +
  labs(x = "GDF15 expression (cohort Z)", y = "turquoise score (cohort Z)",
       title = "GDF15-module association") + theme_article +
  theme(legend.position = "top")
p5G <- plot_grid(bulk_turq_panel("GSE223924"), bulk_turq_panel("GSE173078"), p5G3,
                 nrow = 1, rel_widths = c(0.28, 0.28, 0.44))

fig5 <- plot_grid(
  plot_grid(tag_panel(p5A, "A"), tag_panel(p5B, "B"), nrow = 1, rel_widths = c(0.38, 0.62)),
  plot_grid(tag_panel(p5C, "C"), tag_panel(p5D, "D"), tag_panel(p5E, "E"),
            nrow = 1, rel_widths = c(0.44, 0.24, 0.32)),
  plot_grid(tag_panel(p5F, "F"), tag_panel(p5G, "G"), nrow = 1,
            rel_widths = c(0.43, 0.57)),
  ncol = 1, rel_heights = c(0.34, 0.35, 0.31)
)

save_exact(fig2, paste0("Reference_Fig2_style_GDF15_receptor_feasibility_20260915", OUTPUT_TAG), 2000, 1897)
save_exact(fig3, paste0("Reference_Fig3_style_gingival_fibroblast_GDF15_ERK_state_20260915", OUTPUT_TAG), 2000, 2432)
save_exact(fig4, paste0("Reference_Fig4_style_GDF15_signature_two_gingiva_cohorts_20260915", OUTPUT_TAG), 2000, 1931)
save_exact(fig5, paste0("Reference_Fig5_style_hdWGCNA_GDF15_ERK_module_20260915", OUTPUT_TAG), 2000, 1858)

cat("Figures completed\n")
