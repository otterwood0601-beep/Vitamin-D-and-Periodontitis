$ErrorActionPreference = "Stop"
$PSNativeCommandUseErrorActionPreference = $true
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)

$projectRoot = "E:\$([char]0x8840)$([char]0x6E05)$([char]0x7EF4)$([char]0x751F)$([char]0x7D20)D DLC"
$analysisDir = Join-Path $projectRoot "data_derived\tranoncol2026_Williams_20260920"
$hdwgcnaProject = Join-Path $projectRoot "P2_hdWGCNA_Williams_20260920"
$hdwgcnaSource = Join-Path $hdwgcnaProject "outputs\02_source_data"
$figureDir = Join-Path $projectRoot "output\$([char]0x539F)$([char]0x6587)$([char]0x683C)$([char]0x5F0F)$([char]0x8FC1)$([char]0x79FB)_GDF15_ERK\Williams$([char]0x7EDF)$([char]0x4E00)$([char]0x91CD)$([char]0x5206)$([char]0x6790)_20260920"
$fallbackDir = Join-Path $projectRoot "data_derived\tranoncol2026"
$scriptDir = Join-Path $projectRoot "code\tranoncol2026"
$p2ScriptDir = Join-Path $projectRoot "P2_hdWGCNA\scripts"

$pythonExe = "C:\Users\Lin\.workbuddy\binaries\python\envs\default\Scripts\python.exe"
$rscriptExe = "C:\Program Files\R\R-4.5.3\bin\Rscript.exe"

foreach ($requiredPath in @($pythonExe, $rscriptExe, $scriptDir, $p2ScriptDir, $fallbackDir)) {
    if (-not (Test-Path -LiteralPath $requiredPath)) {
        throw "$([char]0x7F3A)$([char]0x5C11)$([char]0x8FD0)$([char]0x884C)$([char]0x6240)$([char]0x9700)$([char]0x8DEF)$([char]0x5F84)：$requiredPath"
    }
}

New-Item -ItemType Directory -Force -Path $analysisDir, $hdwgcnaProject, $figureDir | Out-Null

$env:LANG = "zh_CN.UTF-8"
$env:LC_ALL = "zh_CN.UTF-8"
$env:DLC_STUDY_FILTER = "Williams"
$env:DLC_ANALYSIS_DIR = $analysisDir
$env:DLC_HDWGCNA_PROJ = $hdwgcnaProject
$env:DLC_HDWGCNA_SOURCE_DIR = $hdwgcnaSource
$env:DLC_SC_DATASET_LABEL = "Williams gingival scRNA"
$env:DLC_SIGNATURE_FALLBACK_DIR = $fallbackDir
$env:DLC_FIGURE_OUT = $figureDir
$env:DLC_FIGURE_RASTER_OUT = $figureDir
$env:DLC_OUTPUT_TAG = "_Williams_20260920"
$env:DLC_SIGNATURE_SOURCE_TITLE = "CELLxGENE GDF15 signature"
$env:DLC_SIGNATURE_SOURCE_AXIS = "All-study CELLxGENE association t"

function Invoke-CheckedStep {
    param(
        [Parameter(Mandatory = $true)][string]$Label,
        [Parameter(Mandatory = $true)][string]$Executable,
        [Parameter(Mandatory = $true)][string[]]$ArgumentList
    )
    Write-Host "`n[$Label]"
    & $Executable @ArgumentList
    if ($LASTEXITCODE -ne 0) {
        throw "$Label $([char]0x5931)$([char]0x8D25)，$([char]0x9000)$([char]0x51FA)$([char]0x7801)：$LASTEXITCODE"
    }
}

Push-Location $projectRoot
try {
    Invoke-CheckedStep "1/7 Williams$([char]0x53D7)$([char]0x4F53)$([char]0x53EF)$([char]0x884C)$([char]0x6027)" $pythonExe @(
        (Join-Path $scriptDir "01_receptor_feasibility.py")
    )
    Invoke-CheckedStep "2/7 Williams hdWGCNA" $rscriptExe @(
        "--vanilla", (Join-Path $p2ScriptDir "P2_01_hdwgcna_fibroblast_modules.R")
    )
    Invoke-CheckedStep "3/7 hdWGCNA$([char]0x5916)$([char]0x90E8)$([char]0x590D)$([char]0x73B0)" $rscriptExe @(
        "--vanilla", (Join-Path $p2ScriptDir "P2_02_module_external_replication_GSE223924.R")
    )
    Invoke-CheckedStep "4/7 Williams$([char]0x7EFC)$([char]0x5408)$([char]0x5206)$([char]0x6790)" $rscriptExe @(
        "--vanilla", (Join-Path $scriptDir "02_analysis.R")
    )
    Invoke-CheckedStep "5/7 Williams$([char]0x4F2A)$([char]0x65F6)$([char]0x5E8F)" $rscriptExe @(
        "--vanilla", (Join-Path $scriptDir "04_pseudotime_analysis.R")
    )
    Invoke-CheckedStep "6/7 Williams$([char]0x4E3B)$([char]0x56FE)" $rscriptExe @(
        "--vanilla", (Join-Path $scriptDir "03_figures.R")
    )
    Invoke-CheckedStep "7/7 Williams$([char]0x4F2A)$([char]0x65F6)$([char]0x5E8F)$([char]0x56FE)" $rscriptExe @(
        "--vanilla", (Join-Path $scriptDir "05_pseudotime_figure.R")
    )
}
finally {
    Pop-Location
}

Write-Host "
Williams$([char]0x7EDF)$([char]0x4E00)$([char]0x91CD)$([char]0x5206)$([char]0x6790)$([char]0x5B8C)$([char]0x6210)。"
Write-Host "$([char]0x5206)$([char]0x6790)$([char]0x7ED3)$([char]0x679C)：$analysisDir"
Write-Host "hdWGCNA$([char]0x7ED3)$([char]0x679C)：$hdwgcnaProject"
Write-Host "$([char]0x6295)$([char]0x7A3F)$([char]0x683C)$([char]0x5F0F)$([char]0x56FE)：$figureDir"
