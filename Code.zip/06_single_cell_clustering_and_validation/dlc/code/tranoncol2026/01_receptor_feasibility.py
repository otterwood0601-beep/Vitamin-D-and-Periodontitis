from __future__ import annotations
import json
import os
from pathlib import Path
import anndata as ad
import numpy as np
import pandas as pd
from scipy import sparse
H5AD = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u8865\u5145\u56fe\\\u3010\u5f85\u5b9a\u3011SCENIC\\1.\u6e90\u6570\u636e\\01_\u539f\u59cb\u8f93\u5165\\01_CELLxGENE\u6574\u5408\u7259\u5468\u56fe\u8c31\\Integrated_Human_Periodontitis_Atlas_105918cells.h5ad')
OUT = Path(os.environ.get('DLC_ANALYSIS_DIR', 'E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\data_derived\\tranoncol2026'))
STUDY_FILTER = os.environ.get('DLC_STUDY_FILTER', '').strip()
GENES = ['GDF15', 'GFRAL', 'RET', 'ERBB2', 'EGFR', 'MAPK1', 'MAPK3']

def dense_vector(x) -> np.ndarray:
    if sparse.issparse(x):
        return np.asarray(x.toarray()).ravel()
    return np.asarray(x).ravel()

def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    adata = ad.read_h5ad(H5AD, backed='r')
    try:
        obs_all = adata.obs[['cell_type', 'disease', 'tissue', 'donor_id', 'Study']].copy()
        if STUDY_FILTER:
            keep_positions = np.flatnonzero(obs_all['Study'].astype(str).to_numpy() == STUDY_FILTER)
            if keep_positions.size == 0:
                raise RuntimeError(f'No cells matched Study == {STUDY_FILTER!r}')
        else:
            keep_positions = np.arange(adata.n_obs, dtype=int)
        obs = obs_all.iloc[keep_positions].copy()
        feature = adata.var[['feature_name', 'feature_biotype', 'feature_type']].copy()
        feature['ensembl_id'] = adata.var_names.astype(str)
        feature = feature.drop_duplicates(subset='feature_name', keep='first')
        feature.to_csv(OUT / '00_gene_annotations.csv.gz', index=False)
        gene_index: dict[str, int] = {}
        names = adata.var['feature_name'].astype(str).to_numpy()
        for gene in GENES:
            hits = np.flatnonzero(names == gene)
            if hits.size:
                gene_index[gene] = int(hits[0])
        if 'GDF15' not in gene_index:
            raise RuntimeError('GDF15 is absent from the gingival atlas feature table')
        expr = pd.DataFrame(index=obs.index)
        for gene, idx in gene_index.items():
            expr[gene] = dense_vector(adata.X[keep_positions, idx])
        long_rows: list[dict[str, object]] = []
        grouped = obs.groupby('cell_type', observed=True, sort=True).indices
        for cell_type, positions in grouped.items():
            pos = np.asarray(positions, dtype=int)
            for gene in GENES:
                v = expr[gene].to_numpy()[pos] if gene in expr else np.zeros(pos.size)
                long_rows.append({'cell_type': str(cell_type), 'gene': gene, 'n_cells': int(pos.size), 'n_detected': int(np.count_nonzero(v > 0)), 'detection_fraction': float(np.mean(v > 0)), 'mean_expression_all_cells': float(np.mean(v)), 'mean_expression_detected_cells': float(np.mean(v[v > 0])) if np.any(v > 0) else 0.0})
        by_type = pd.DataFrame(long_rows)
        by_type.to_csv(OUT / '01_receptor_detection_by_celltype.csv', index=False)
        overall_rows: list[dict[str, object]] = []
        fibro_mask = obs['cell_type'].astype(str).str.lower().eq('fibroblast').to_numpy()
        for scope, mask in {'All gingival cells': np.ones(len(obs), dtype=bool), 'Fibroblasts': fibro_mask}.items():
            for gene in GENES:
                v = expr.loc[mask, gene].to_numpy() if gene in expr else np.zeros(mask.sum())
                overall_rows.append({'scope': scope, 'gene': gene, 'n_cells': int(mask.sum()), 'n_detected': int(np.count_nonzero(v > 0)), 'detection_fraction': float(np.mean(v > 0)), 'mean_expression_all_cells': float(np.mean(v))})
        overall = pd.DataFrame(overall_rows)
        overall.to_csv(OUT / '02_receptor_overall_summary.csv', index=False)
        gfral_fib = overall.query("scope == 'Fibroblasts' and gene == 'GFRAL'").iloc[0]
        decision = pd.DataFrame([{'question': 'Can a canonical GDF15-GFRAL-RET axis be tested in gingival fibroblasts?', 'criterion': 'GDF15 and the obligate receptor GFRAL must be detectably expressed in the scoped cells.', 'observed': f'GFRAL detected in {int(gfral_fib.n_detected)}/{int(gfral_fib.n_cells)} gingival fibroblasts.', 'decision': 'Not estimable as a canonical direct axis', 'reason': 'The obligate receptor GFRAL is absent in the fibroblast compartment; RET alone is insufficient.'}])
        decision.to_csv(OUT / '03_canonical_GDF15_axis_decision.csv', index=False)
        manifest = {'source': str(H5AD), 'n_cells': int(len(obs)), 'n_cells_source_atlas': int(adata.n_obs), 'n_genes': int(adata.n_vars), 'tissues': sorted(obs['tissue'].astype(str).unique().tolist()), 'study_filter': STUDY_FILTER or 'All studies', 'genes_requested': GENES, 'genes_found': sorted(gene_index), 'expression_matrix': 'AnnData.X; nonzero values used for detection', 'scope_rule': 'Human gingiva only; no substitute tissue'}
        (OUT / '04_receptor_feasibility_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    finally:
        adata.file.close()
if __name__ == '__main__':
    main()
