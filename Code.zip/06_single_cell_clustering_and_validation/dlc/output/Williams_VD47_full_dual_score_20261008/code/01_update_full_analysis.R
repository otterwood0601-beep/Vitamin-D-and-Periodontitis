options(stringsAsFactors = FALSE, scipen = 999)
.libPaths(c('C:/wb_temp/no2uc_Rlib_20260925', .libPaths()))
suppressPackageStartupMessages({library(data.table); library(Seurat); library(AUCell)
  library(Matrix); library(edgeR); library(limma); library(UCell); library(jsonlite)})
set.seed(20260925)
OUT <- 'C:/wb_links/williams_vd47_full_20261008'
SD <- file.path(OUT, 'source_data')
OLD <- 'C:/wb_links/jhazmat2026_no2uc_20260925/source_data'
LATEST <- 'C:/wb_links/williams_vd47_fg_20261008/source_data'
if (file.exists(file.path(SD, '14_analysis_manifest.json'))) stop('Already completed: preserve outputs')
zscore <- function(x) (x - mean(x)) / sd(x)
safe_spearman <- function(x, y) {
  ans <- suppressWarnings(cor.test(x, y, method = 'spearman', exact = FALSE))
  list(rho = unname(ans$estimate), p = ans$p.value, n = length(x))
}
message('[1/7] Reusing latest scores and original Williams embedding/metadata')
audit <- fread(file.path(LATEST, '01_VD46plusGDF15_gene_audit.csv'))
sig_genes <- audit$gene
sig_present <- audit[present_in_Williams == TRUE, gene]
stopifnot(length(sig_genes) == 47L, length(sig_present) == 46L, 'GDF15' %in% sig_present)
fwrite(audit, file.path(SD, '01_VD47_signature_gene_audit.csv'))
old <- fread(file.path(OLD, '03_Williams_VD17_dual_scores.csv.gz'))
fresh <- fread(file.path(LATEST, '03_Williams_VD47_dual_scores.csv.gz'))
cells <- old[, .(cell_id, frozen_umap_1, frozen_umap_2, donor_id, disease, state,
                 GDF15, MAPK1, MAPK3)]
stopifnot(setequal(cells$cell_id, fresh$cell_id), !anyDuplicated(fresh$cell_id))
cells[fresh, on = 'cell_id', `:=`(AddModuleScore = i.AddModuleScore, AUCell = i.AUCell)]
cells[, `:=`(AddModuleScore_z = zscore(AddModuleScore), AUCell_z = zscore(AUCell))]
cells[, consensus_score := (AddModuleScore_z + AUCell_z)/2]
cells[, score_group := ifelse(consensus_score > median(consensus_score), 'High', 'Low'),
      by = .(donor_id, state)]
cells[, pair_id := paste(donor_id, state, sep = '||')]
fb_all <- readRDS('C:/wb_links/dlc_data/outputs/fb_seurat_annotated.rds')
fb <- subset(fb_all, subset = Study == 'Williams')
rm(fb_all); invisible(gc())
DefaultAssay(fb) <- 'RNA'
norm <- GetAssayData(fb, assay = 'RNA', layer = 'data')
counts <- GetAssayData(fb, assay = 'RNA', layer = 'counts')
message('[2/7] Held-out GDF15 scoring: GDF15 itself is excluded only for panels M/N')
held_genes <- setdiff(sig_present, 'GDF15')
fb <- AddModuleScore(fb, features = list(held_genes), ctrl = 100, nbin = 24,
                     seed = 20260925, assay = 'RNA', name = 'VDheld', search = FALSE)
keep_auc <- Matrix::rowSums(counts > 0) >= 10 | rownames(counts) %in% sig_present
rankings <- AUCell_buildRankings(norm[keep_auc,,drop = FALSE], plotStats = FALSE,
                                nCores = 1, splitByBlocks = TRUE, verbose = FALSE)
auc_max_rank <- max(50L, ceiling(.05 * sum(keep_auc)))
held_auc <- getAUC(AUCell_calcAUC(list(VD_noGDF15 = held_genes), rankings,
                                aucMaxRank = auc_max_rank, nCores = 1))
h <- data.table(cell_id = colnames(fb), held_AddModuleScore = fb$VDheld1)
h[, held_AUCell := as.numeric(held_auc['VD_noGDF15', cell_id])]
cells[h, on = 'cell_id', `:=`(held_AddModuleScore = i.held_AddModuleScore,
                            held_AUCell = i.held_AUCell)]
cells[, GDF15_heldout_consensus_score := (zscore(held_AddModuleScore) + zscore(held_AUCell))/2]
cells[, GDF15_heldout_group := ifelse(GDF15_heldout_consensus_score >
             median(GDF15_heldout_consensus_score), 'High', 'Low'), by = .(donor_id, state)]
rm(rankings, held_auc, h, fb); invisible(gc())
message('[3/7] Updating ERK/MMP programs without shared signature genes')
gmt <- lapply(readLines('C:/wb_links/dlc_data/outputs/curated_gene_sets_v1.gmt'),
              function(ln) strsplit(ln, '\t', fixed = TRUE)[[1]])
gmt <- setNames(lapply(gmt, function(z) unique(z[-c(1,2)])), vapply(gmt, `[`, '', 1))
program_sets <- list(MAPK_ERK = gmt$MAPK_ERK_transcriptional_response,
                     ECM_degradation = gmt$ECM_degradation_MMP_ADAMTS)
program_audit <- rbindlist(lapply(names(program_sets), function(n) {
  gs <- program_sets[[n]]
  data.table(program = n, gene = gs, present = gs %in% rownames(counts),
             overlaps_VD_signature = gs %in% sig_genes,
             used = gs %in% rownames(counts) & !gs %in% sig_genes)
}))
fwrite(program_audit, file.path(SD, '22_ERK_MMP_program_gene_audit.csv'))
program_sets <- lapply(program_sets, function(gs) intersect(setdiff(gs, sig_genes), rownames(counts)))
uc <- ScoreSignatures_UCell(matrix = counts, features = program_sets,
                            maxRank = 1500, ncores = 1, missing_genes = 'skip')
uc <- as.data.table(uc, keep.rownames = 'cell_id')
setnames(uc, names(uc), sub('_UCell$', '', names(uc)))
cells[uc, on = 'cell_id', `:=`(MAPK_ERK = i.MAPK_ERK, ECM_degradation = i.ECM_degradation)]
stopifnot(nrow(cells) == 14302L, !anyNA(cells$MAPK_ERK), !anyNA(cells$GDF15_heldout_consensus_score))
rm(uc); invisible(gc())
message('[4/7] Latest representative VD genes and donor-level summaries')
selected_genes <- intersect(c('CYP24A1', 'ITPR1', 'APBB1IP', 'VEGFD', 'EFL1', 'OSR1', 'ROM1',
                             'GDF15', 'MAPK3', 'MAPK1', 'MMP1', 'MMP2', 'MMP3', 'MMP9', 'MMP14'),
                           rownames(norm))
dot <- rbindlist(lapply(selected_genes, function(g) {
  d <- data.table(state = cells$state, value = as.numeric(norm[g,cells$cell_id]))
  d[, .(average_expression = mean(value), percent_detected = mean(value > 0)*100), by = state][, gene := g]
}))
fwrite(dot, file.path(SD, '02_selected_gene_dotplot.csv'))
fwrite(cells, file.path(SD, '03_Williams_VD47_dual_scores.csv.gz'))
donor_scores <- cells[, .(AddModuleScore = median(AddModuleScore), AUCell = median(AUCell),
  consensus_score = median(consensus_score), n_cells = .N), by = .(donor_id, disease)]
state_scores <- cells[, .(AddModuleScore = median(AddModuleScore), AUCell = median(AUCell),
  consensus_score = median(consensus_score), n_cells = .N), by = .(donor_id, disease, state)]
fwrite(donor_scores, file.path(SD, '04_donor_score_summary.csv'))
fwrite(state_scores, file.path(SD, '05_donor_state_score_summary.csv'))

aggregate_groups <- function(group_col, endpoints) {
  d <- cells[, c(list(n_cells = .N), lapply(.SD, mean)),
    by = c('donor_id','disease','state',group_col), .SDcols = endpoints]
  setnames(d, group_col, 'score_group')
  complete <- d[n_cells >= 5, .N, by = .(donor_id,state)][N == 2, .(donor_id,state)]
  d <- d[complete, on = .(donor_id,state), nomatch = 0][n_cells >= 5]
  ans <- d[, c(list(n_cells = sum(n_cells), n_states = .N), lapply(.SD, mean)),
           by = .(donor_id, disease, score_group), .SDcols = endpoints]
  ans[, pair_id := donor_id]
  ans
}
cells[, `:=`(GDF15_detection = as.numeric(GDF15 > 0), GDF15_mean = GDF15)]
gdf_agg <- aggregate_groups('GDF15_heldout_group', c('GDF15_detection','GDF15_mean'))
prog_agg <- aggregate_groups('score_group', c('MAPK_ERK','ECM_degradation'))
endpoint_agg <- merge(prog_agg, gdf_agg[, .(donor_id,score_group,GDF15_detection,GDF15_mean)],
                      by = c('donor_id','score_group'), all = TRUE)
stopifnot(nrow(endpoint_agg) == 42L)
fwrite(endpoint_agg, file.path(SD, '06_donor_state_group_endpoint_summary.csv'))
overall_agg <- cells[, .(pair_id = donor_id[1], consensus_score = median(consensus_score),
  GDF15_heldout_consensus_score = median(GDF15_heldout_consensus_score),
  GDF15_detection = mean(GDF15 > 0), GDF15_mean = mean(GDF15),
  MAPK_ERK = median(MAPK_ERK), ECM_degradation = median(ECM_degradation), n_cells = .N),
  by = .(donor_id,disease)]
fwrite(overall_agg, file.path(SD, '07_donor_state_endpoint_summary.csv'))
message('[5/7] Re-running donor-paired pseudobulk high/low differential expression')
cells[, pb_id := paste(donor_id,score_group,sep = '||')]
pb_levels <- unique(cells$pb_id)
membership <- sparseMatrix(i = seq_len(nrow(cells)), j = match(cells$pb_id,pb_levels), x = 1,
  dims = c(nrow(cells),length(pb_levels)), dimnames = list(cells$cell_id,pb_levels))
pb_counts <- counts[,cells$cell_id,drop = FALSE] %*% membership
pb_meta <- unique(cells[,.(pb_id,donor_id,disease,score_group)])
pb_meta <- pb_meta[match(colnames(pb_counts),pb_id)]
pb_meta[, `:=`(score_group = factor(score_group,levels = c('Low','High')), donor_id = factor(donor_id))]
y <- DGEList(pb_counts)
y <- y[filterByExpr(y,group = pb_meta$score_group,min.count = 10,min.total.count = 20),,
       keep.lib.sizes = FALSE]
y <- calcNormFactors(y)
design <- model.matrix(~ donor_id + score_group, data = pb_meta)
fit <- eBayes(lmFit(voom(y,design,plot = FALSE),design),robust = TRUE)
de <- as.data.table(topTable(fit,coef = 'score_groupHigh',number = Inf,sort.by = 'P'),keep.rownames = 'gene')
de[, in_VD47_signature := gene %in% sig_genes]
de[, direction := fifelse(adj.P.Val < .05 & logFC > .25,'Up',
                         fifelse(adj.P.Val < .05 & logFC < -.25,'Down','NS'))]
de[, neglog10_FDR := -log10(pmax(adj.P.Val,1e-300))]
fwrite(de,file.path(SD,'08_paired_pseudobulk_high_vs_low_DE.csv.gz'))
fwrite(pb_meta,file.path(SD,'23_pseudobulk_sample_metadata.csv'))
enrich_genes <- de[in_VD47_signature == FALSE & direction == 'Up',gene]
writeLines(enrich_genes,file.path(SD,'09_enrichment_input_genes.txt'))
writeLines('FDR < 0.05 and logFC > 0.25; all 47 candidate signature genes excluded; no fallback',
           file.path(SD,'09_enrichment_selection_rule.txt'))
message('[6/7] Donor-level tests; no cell or donor-state pseudoreplication')
disease_tests <- rbindlist(lapply(c('AddModuleScore','AUCell','consensus_score'),function(vn) {
  x <- donor_scores[disease == 'normal',get(vn)]; z <- donor_scores[disease == 'periodontitis',get(vn)]
  data.table(endpoint = vn,n_normal = length(x),n_periodontitis = length(z),
    median_normal = median(x),median_periodontitis = median(z),delta = median(z)-median(x),
    p_value = wilcox.test(z,x,exact = FALSE)$p.value)
}))
paired_tests <- rbindlist(lapply(c('GDF15_detection','GDF15_mean','MAPK_ERK','ECM_degradation'),function(vn) {
  w <- dcast(endpoint_agg,donor_id ~ score_group,value.var = vn)
  w <- w[is.finite(Low) & is.finite(High)]
  delta <- w$High-w$Low
  p <- if (all(delta == 0)) 1 else suppressWarnings(wilcox.test(w$High,w$Low,paired = TRUE,exact = FALSE)$p.value)
  data.table(endpoint = vn,n_pairs = nrow(w),median_delta = median(delta),p_value = p,
    grouping_score = if (grepl('GDF15',vn)) 'GDF15-held-out signature' else 'full signature; program overlap removed')
}))
corr_rows <- rbindlist(lapply(c('GDF15_detection','GDF15_mean','MAPK_ERK','ECM_degradation'),function(vn) {
  score <- if (grepl('GDF15',vn)) overall_agg$GDF15_heldout_consensus_score else overall_agg$consensus_score
  ans <- safe_spearman(score,overall_agg[[vn]])
  data.table(endpoint = vn,rho = ans$rho,p_value = ans$p,n = ans$n)
}))
paired_tests[, FDR := p.adjust(p_value,'BH')]
corr_rows[, FDR := p.adjust(p_value,'BH')]
fwrite(disease_tests,file.path(SD,'10_disease_score_tests.csv'))
fwrite(paired_tests,file.path(SD,'11_high_low_endpoint_tests.csv'))
fwrite(corr_rows,file.path(SD,'12_endpoint_correlations.csv'))
previous <- fread(file.path(LATEST,'10_disease_score_tests.csv'))
stopifnot(max(abs(disease_tests[endpoint != 'consensus_score',p_value]-previous$p_value)) < 1e-12)
agreement <- rbindlist(lapply(list(cell = cells,donor = donor_scores),function(d) {
  a <- safe_spearman(d$AddModuleScore,d$AUCell)
  data.table(rho = a$rho,p_value = a$p,n = a$n)
}),idcol = 'level')
fwrite(agreement,file.path(SD,'13_AddModuleScore_AUCell_agreement.csv'))
message('[7/7] Saving provenance')
write_json(list(created_at = format(Sys.time()),dataset = 'Williams GSE164241',tissue = 'human gingiva',
  cells = nrow(cells),donor_labels = uniqueN(cells$donor_id),signature_candidates = sig_genes,
  scored_genes = sig_present,missing = setdiff(sig_genes,sig_present),GDF15_user_exception = TRUE,
  scoring_direction = 'unsigned; up and down D3-responsive genes pooled as in original method',
  full_scores_reused_from = LATEST,high_low = 'within donor and fibroblast state median',
  inference = '21 donor_id labels, not 14302 cells or donor-state observations',
  GDF15_analysis = 'M/N use GDF15-held-out score (45 genes) to avoid part-whole circularity',
  ERK_analysis = 'O/P UCell program excludes overlap with VD signature; transcriptional not phospho-ERK',
  program_sources = 'original project curated_gene_sets_v1.gmt; no new curated VD list used',
  pseudobulks = nrow(pb_meta),DE_model = '~ donor_id + score_group',
  enrichment_genes = length(enrich_genes),no_enrichment_sensitivity_fallback = TRUE,
  raw_P_in_figure = TRUE,FDR_in_tables = TRUE,old_outputs_unchanged = TRUE),
  file.path(SD,'14_analysis_manifest.json'),pretty = TRUE,auto_unbox = TRUE)
writeLines(capture.output(sessionInfo()),file.path(SD,'24_sessionInfo.txt'))
print(disease_tests); print(paired_tests); print(corr_rows)
message('FULL ANALYSIS COMPLETED')
