.libPaths(c('C:/wb_temp/no2uc_Rlib_20260925',.libPaths()))
suppressPackageStartupMessages({library(data.table); library(jsonlite); library(Seurat);
  library(Matrix); library(edgeR); library(limma)})
ROOT <- 'C:/wb_links/williams_vd47_global_20261008'
OLD <- 'C:/wb_links/williams_vd47_full_20261008'
SD <- file.path(ROOT,'source_data')
if (file.exists(file.path(SD,'14_analysis_manifest.json'))) stop('Completed analysis must be preserved')
old_files <- list.files(file.path(OLD,'source_data'),full.names=TRUE)
old_md5 <- tools::md5sum(old_files)
for (name in c('01_VD47_signature_gene_audit.csv','02_selected_gene_dotplot.csv',
  '10_disease_score_tests.csv','22_ERK_MMP_program_gene_audit.csv','KEGG_2021_Human.gmt')) {
  src_copy <- file.path(OLD,'source_data',name)
  dst_copy <- file.path(SD,name)
  if (!file.exists(dst_copy)) stopifnot(file.copy(src_copy,dst_copy,overwrite=FALSE))
  else stopifnot(unname(tools::md5sum(src_copy))==unname(tools::md5sum(dst_copy)))
}
cells <- fread(file.path(OLD,'source_data','03_Williams_VD47_dual_scores.csv.gz'))
methods <- c('AddModuleScore','AUCell','consensus_score','GDF15_heldout_consensus_score')
thresholds <- data.table(method=methods,threshold=vapply(methods,function(m) median(cells[[m]]),0.))
for (m in methods) {
  col <- switch(m,consensus_score='score_group',GDF15_heldout_consensus_score='GDF15_heldout_group',paste0(m,'_group'))
  cut <- thresholds[method==m,threshold]
  cells[,(col):=ifelse(get(m)>cut,'High','Low')]
}
cells[,display_in_UMAP:=frozen_umap_1>=-8]
stopifnot(nrow(cells)==14302L,sum(!cells$display_in_UMAP)==4L)
fwrite(thresholds,file.path(SD,'00_global_score_thresholds.csv'))
fwrite(cells,file.path(SD,'03_Williams_VD47_dual_scores.csv.gz'))
fwrite(cells[,.(AddModuleScore=median(AddModuleScore),AUCell=median(AUCell),
  consensus_score=median(consensus_score),n_cells=.N),by=.(donor_id,disease)],
  file.path(SD,'04_donor_score_summary.csv'))
fwrite(cells[,.(AddModuleScore=median(AddModuleScore),AUCell=median(AUCell),
  consensus_score=median(consensus_score),n_cells=.N),by=.(donor_id,disease,state)],
  file.path(SD,'05_donor_state_score_summary.csv'))
props <- rbindlist(lapply(c('AddModuleScore','AUCell'),function(m) {
  p <- cells[,.(n_cells=.N),by=c('state',paste0(m,'_group'))]
  setnames(p,paste0(m,'_group'),'score_group')
  p[,total_cells:=sum(n_cells),by=state]
  p[,`:=`(percent=100*n_cells/total_cells,method=m)]
  p
}))
fwrite(props,file.path(SD,'53_state_method_high_low_proportions.csv'))
fwrite(dcast(props,state+total_cells~method+score_group,value.var='percent'),
  file.path(SD,'54_state_method_high_low_proportions_wide.csv'))
fwrite(cells[,.(n=.N),by=.(donor_id,score_group)],file.path(SD,'01_global_group_donor_counts.csv'))

message('[1/3] Recompute global-group donor endpoints')
cells[,`:=`(GDF15_detection=as.numeric(GDF15>0),GDF15_mean=GDF15)]
aggregate_groups <- function(group_col,vars) {
  d <- cells[,c(list(n_cells=.N),lapply(.SD,mean)),by=c('donor_id','disease',group_col),.SDcols=vars]
  setnames(d,group_col,'score_group')
  valid <- d[n_cells>=5,.N,by=donor_id][N==2,donor_id]
  d <- d[donor_id %in% valid & n_cells>=5]
  d[,pair_id:=donor_id]
  d
}
gdf <- aggregate_groups('GDF15_heldout_group',c('GDF15_detection','GDF15_mean'))
prog <- aggregate_groups('score_group',c('MAPK_ERK','ECM_degradation'))
stopifnot(nrow(gdf)==42L,nrow(prog)==42L)
endpoints <- merge(prog,gdf[,.(donor_id,score_group,GDF15_detection,GDF15_mean)],
                   by=c('donor_id','score_group'),all=TRUE)
fwrite(endpoints,file.path(SD,'06_donor_state_group_endpoint_summary.csv'))
overall <- cells[,.(pair_id=donor_id[1],consensus_score=median(consensus_score),
  GDF15_heldout_consensus_score=median(GDF15_heldout_consensus_score),
  GDF15_detection=mean(GDF15>0),GDF15_mean=mean(GDF15),
  MAPK_ERK=median(MAPK_ERK),ECM_degradation=median(ECM_degradation),n_cells=.N),by=.(donor_id,disease)]
fwrite(overall,file.path(SD,'07_donor_state_endpoint_summary.csv'))
paired <- rbindlist(lapply(c('GDF15_detection','GDF15_mean','MAPK_ERK','ECM_degradation'),function(v) {
  w <- dcast(endpoints,donor_id~score_group,value.var=v)
  w <- w[is.finite(Low)&is.finite(High)]
  p <- suppressWarnings(wilcox.test(w$High,w$Low,paired=TRUE,exact=FALSE)$p.value)
  data.table(endpoint=v,n_pairs=nrow(w),median_delta=median(w$High-w$Low),p_value=p)
}))
corr <- rbindlist(lapply(c('GDF15_detection','GDF15_mean','MAPK_ERK','ECM_degradation'),function(v) {
  x <- if (grepl('GDF15',v)) overall$GDF15_heldout_consensus_score else overall$consensus_score
  a <- suppressWarnings(cor.test(x,overall[[v]],method='spearman',exact=FALSE))
  data.table(endpoint=v,rho=unname(a$estimate),p_value=a$p.value,n=length(x))
}))
fwrite(paired,file.path(SD,'11_high_low_endpoint_tests.csv'))
fwrite(corr,file.path(SD,'12_endpoint_correlations.csv'))

message('[2/3] Rebuild global-group paired pseudobulks and differential expression')
fb_all <- readRDS('C:/wb_links/dlc_data/outputs/fb_seurat_annotated.rds')
fb <- subset(fb_all,subset=Study=='Williams')
rm(fb_all); invisible(gc())
counts <- GetAssayData(fb,assay='RNA',layer='counts')
stopifnot(setequal(colnames(counts),cells$cell_id))
cells[,pb_id:=paste(donor_id,score_group,sep='||')]
lev <- unique(cells$pb_id)
membership <- sparseMatrix(i=seq_len(nrow(cells)),j=match(cells$pb_id,lev),x=1,
  dims=c(nrow(cells),length(lev)),dimnames=list(cells$cell_id,lev))
pb <- counts[,cells$cell_id,drop=FALSE] %*% membership
meta <- unique(cells[,.(pb_id,donor_id,disease,score_group)])
meta <- meta[match(colnames(pb),pb_id)]
meta[,`:=`(score_group=factor(score_group,levels=c('Low','High')),donor_id=factor(donor_id))]
y <- DGEList(pb)
y <- y[filterByExpr(y,group=meta$score_group,min.count=10,min.total.count=20),,keep.lib.sizes=FALSE]
y <- calcNormFactors(y)
design <- model.matrix(~donor_id+score_group,data=meta)
fit <- eBayes(lmFit(voom(y,design,plot=FALSE),design),robust=TRUE)
de <- as.data.table(topTable(fit,coef='score_groupHigh',number=Inf,sort.by='P'),keep.rownames='gene')
signature <- fread(file.path(SD,'01_VD47_signature_gene_audit.csv'))$gene
de[,in_VD47_signature:=gene %in% signature]
de[,direction:=fifelse(P.Value<.05&logFC>.25,'Up',fifelse(P.Value<.05&logFC < -.25,'Down','NS'))]

fwrite(de,file.path(SD,'08_paired_pseudobulk_high_vs_low_DE.csv.gz'))
fwrite(meta,file.path(SD,'23_pseudobulk_sample_metadata.csv'))
foreground <- de[in_VD47_signature==FALSE&direction=='Up',gene]
universe <- de[in_VD47_signature==FALSE,gene]
writeLines(foreground,file.path(SD,'39_rawp_enrichment_input_genes.txt'))
rm(fb,counts,pb,fit,y); invisible(gc())
message('[3/3] Recompute enrichment using raw-p foreground and measured background')
gmt <- c(GO_Biological_Process_2025='C:/wb_links/genesets/GO_Biological_Process_2025.gmt',
         KEGG_2021_Human=file.path(SD,'KEGG_2021_Human.gmt'))
for (db in names(gmt)) {
  sets <- lapply(readLines(gmt[[db]],warn=FALSE),function(ln) {
    z <- strsplit(ln,'\t',fixed=TRUE)[[1]]
    list(Term=z[1],genes=intersect(unique(z[-c(1,2)]),universe))
  })
  sets <- Filter(function(z) length(z$genes)>=5&length(z$genes)<=500,sets)
  res <- rbindlist(lapply(sets,function(z) {
    ov <- intersect(foreground,z$genes)
    data.table(Term=z$Term,Count=length(ov),P.value=phyper(length(ov)-1,length(z$genes),
      length(universe)-length(z$genes),length(foreground),lower.tail=FALSE),
      Genes=paste(ov,collapse=';'),term_background_genes=length(z$genes),
      input_gene_count=length(foreground),universe_count=length(universe))
  }))
  setorder(res,P.value)
  fwrite(res,file.path(SD,paste0('40_rawp_',db,'.csv')))
}
stopifnot(identical(unname(old_md5),unname(tools::md5sum(old_files))))
write_json(list(created_at=format(Sys.time()),old_inputs=OLD,old_inputs_md5_unchanged=as.list(old_md5),
  cells=nrow(cells),donor_labels=21,signature_measured=46,GDF15_heldout_measured=45,
  method_groups='separate global median of all Williams fibroblasts for each scoring method',
  mechanism_groups='global median of existing two-method z-score mean; held-out GDF15 uses separate global median',
  paired_endpoint_aggregation='cell mean per donor and global group, no within-state balancing',
  raw_p=TRUE,DE_threshold='raw p < .05 and |log2FC| > .25, all signature genes excluded from volcano/enrichment',
  pseudobulks=nrow(meta),DE_model='~ donor_id + global_score_group',
  DE_non_signature_counts=as.list(de[in_VD47_signature==FALSE,.N,by=direction]),
  measured_background_n=length(universe),enrichment_input_n=length(foreground),
  interpretation='global high/low captures fibroblast state-composition differences as well as within-state expression; exploratory association, not vitamin D treatment'),
  file.path(SD,'14_analysis_manifest.json'),auto_unbox=TRUE,pretty=TRUE)
print(thresholds);print(paired);print(corr);print(de[in_VD47_signature==FALSE,.N,by=direction])
print(dcast(props,state+total_cells~method+score_group,value.var='percent'))
