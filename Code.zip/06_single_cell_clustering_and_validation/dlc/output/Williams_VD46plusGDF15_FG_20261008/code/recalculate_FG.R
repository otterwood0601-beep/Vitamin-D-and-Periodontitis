options(stringsAsFactors = FALSE, scipen = 999)
.libPaths(c('C:/wb_temp/no2uc_Rlib_20260925', .libPaths()))
suppressPackageStartupMessages({
  library(Seurat); library(AUCell); library(data.table); library(Matrix)
  library(ggplot2); library(patchwork); library(jsonlite)
})
set.seed(20260925)
OUT <- 'C:/wb_links/williams_vd47_fg_20261008'
SD <- file.path(OUT, 'source_data')
FD <- file.path(OUT, 'figures')
audit_path <- 'C:/wb_links/vd47_source_20261008/08_vitaminD_DEG_gene_set_audit.csv'
de_path <- 'C:/wb_links/vd47_deseq_source_20261008/11_DESeq2_D3_vs_ethanol_all_genes.csv'
fb_path <- 'C:/wb_links/dlc_data/outputs/fb_seurat_annotated.rds'
if (file.exists(file.path(SD, '12_analysis_manifest.json'))) stop('Completed run exists: do not overwrite')
message('[1/5] Independently checking the 46 strict Vitamin-D DEGs plus user-added GDF15')
audit <- fread(audit_path)
de <- fread(de_path)
strict <- unique(de[!is.na(padj) & padj < .05 & abs(log2FoldChange) >= 1 &
                      !is.na(gene_symbol) & nzchar(gene_symbol), gene_symbol])
genes <- unique(c(strict, 'GDF15'))
stopifnot(length(strict) == 46L, length(genes) == 47L, setequal(genes, audit$gene))
audit[, user_added := gene == 'GDF15' & !gene %in% strict]
audit[, is_strict_vitaminD_DEG := gene %in% strict]
audit[, signature_id := 'VD46plusGDF15']
message('[2/5] Loading the original Williams gingival fibroblasts')
fb_all <- readRDS(fb_path)
fb <- subset(fb_all, subset = Study == 'Williams')
rm(fb_all); invisible(gc())
DefaultAssay(fb) <- 'RNA'
stopifnot(ncol(fb) == 14302L)
norm <- GetAssayData(fb, assay = 'RNA', layer = 'data')
counts <- GetAssayData(fb, assay = 'RNA', layer = 'counts')

present <- audit$gene[audit$gene %in% rownames(norm)]
stopifnot('GDF15' %in% present, !anyDuplicated(present))
audit[, present_in_Williams := gene %in% rownames(norm)]
audit[, detected_cells := vapply(gene, function(g) {
  if (!g %in% rownames(counts)) return(NA_integer_)
  as.integer(sum(counts[g, ] > 0))
}, integer(1))]
fwrite(audit, file.path(SD, '01_VD46plusGDF15_gene_audit.csv'))
fwrite(data.table(gene = present), file.path(SD, '02_actual_scoring_genes.csv'))
message('Requested genes: ', length(genes), '; present: ', length(present),
        '; absent: ', paste(setdiff(genes, present), collapse = ', '))
message('[3/5] Recalculating AddModuleScore with the original seed and controls')
fb <- AddModuleScore(fb, features = list(present), assay = 'RNA',
                     name = 'VD47_AddModuleScore', ctrl = 100, nbin = 24,
                     seed = 20260925, search = FALSE)
meta <- as.data.table(fb[[]], keep.rownames = 'cell_id')
cells <- meta[, .(cell_id, donor_id, disease, sample_id,
                   state = fibroblast_short,
                   AddModuleScore = VD47_AddModuleScore1)]
message('[4/5] Recalculating AUCell using the original detected-gene background and top 5%')
auc_keep <- Matrix::rowSums(counts > 0) >= 10 | rownames(counts) %in% present
auc_expr <- norm[auc_keep, , drop = FALSE]
rankings <- AUCell_buildRankings(auc_expr, plotStats = FALSE, nCores = 1,
                                splitByBlocks = TRUE, verbose = TRUE)
auc_max_rank <- max(50L, ceiling(.05 * nrow(auc_expr)))
auc_obj <- AUCell_calcAUC(geneSets = list(VD47 = present), rankings = rankings,
                          aucMaxRank = auc_max_rank, nCores = 1)
auc_mat <- getAUC(auc_obj)
auc_dt <- data.table(cell_id = colnames(auc_mat), AUCell = as.numeric(auc_mat['VD47', ]))
cells[auc_dt, on = 'cell_id', AUCell := i.AUCell]
stopifnot(nrow(cells) == 14302L, !anyNA(cells$AUCell), !anyNA(cells$AddModuleScore))
fwrite(cells, file.path(SD, '03_Williams_VD47_dual_scores.csv.gz'))
donor <- cells[, .(n_cells = .N, AddModuleScore = median(AddModuleScore),
                    AUCell = median(AUCell)), by = .(donor_id, disease)]
stopifnot(nrow(donor) == 21L, uniqueN(donor$donor_id) == 21L,
          sum(donor$disease == 'normal') == 13L, sum(donor$disease == 'periodontitis') == 8L)
fwrite(donor, file.path(SD, '04_donor_score_summary.csv'))
tests <- rbindlist(lapply(c('AddModuleScore', 'AUCell'), function(v) {
  x <- donor[disease == 'normal', get(v)]
  y <- donor[disease == 'periodontitis', get(v)]
  wt <- wilcox.test(y, x, exact = FALSE, alternative = 'two.sided')
  data.table(endpoint = v, n_normal = length(x), n_periodontitis = length(y),
             median_normal = median(x), median_periodontitis = median(y),
             median_difference_PD_minus_normal = median(y) - median(x),
             p_value = wt$p.value, statistic = unname(wt$statistic),
             test = 'two-sided Wilcoxon on donor-label medians; exact=FALSE')
}))
tests[, FDR_two_tests := p.adjust(p_value, method = 'BH')]
fwrite(tests, file.path(SD, '10_disease_score_tests.csv'))
message('[5/5] Exporting only F/G in the original recipe; old full figure unchanged')
donor[, disease := factor(disease, levels = c('normal', 'periodontitis'))]
disease_cols <- c(normal = '#E68173', periodontitis = '#4D8FC2')
paper_theme <- theme_classic(base_size = 7.6, base_family = 'Arial') +
  theme(axis.title = element_text(size = 7.5, colour = 'black'),
        axis.text = element_text(size = 6.3, colour = 'black'),
        axis.line = element_line(linewidth = .35, colour = 'black'),
        axis.ticks = element_line(linewidth = .3, colour = 'black'),
        plot.title = element_text(size = 8.2, hjust = .5, face = 'plain'),
        strip.text = element_text(size = 6.8, colour = 'black'),
        strip.background = element_rect(fill = 'white', colour = 'black', linewidth = .3),
        legend.title = element_text(size = 6.5), legend.text = element_text(size = 5.8),
        legend.key.size = grid::unit(.28, 'cm'), plot.margin = margin(3, 3, 3, 3))
fmt_p <- function(p) {
  if (p < .001) return('p < 0.001')
  if (p < .01) return(paste0('p = ', formatC(p, digits = 3, format = 'g')))
  paste0('p = ', formatC(p, digits = 2, format = 'f'))
}
box_disease <- function(value, title, ylab) {
  pval <- tests[endpoint == value, p_value][1]
  ggplot(donor, aes(disease, .data[[value]], fill = disease)) +
    geom_boxplot(width = .54, outlier.shape = NA, linewidth = .38, alpha = .88) +
    geom_jitter(width = .09, size = 1.05, shape = 21, colour = 'black', stroke = .2) +
    scale_fill_manual(values = disease_cols, guide = 'none') +
    annotate('text', x = 1.5, y = Inf, label = fmt_p(pval), vjust = 1.2, size = 2.2, family = 'Arial') +
    labs(title = title, x = NULL, y = ylab) + paper_theme +
    theme(axis.text.x = element_text(angle = 20, hjust = 1))
}
pF <- box_disease('AddModuleScore', 'AddModuleScore by disease', paste0('VD', length(present), ' AddModuleScore'))
pG <- box_disease('AUCell', 'AUCell by disease', paste0('VD', length(present), ' AUCell'))
fig <- (pF | pG) + plot_annotation(tag_levels = list(c('F', 'G')),
  theme = theme(plot.tag = element_text(family = 'Arial', size = 10.5, face = 'plain')))
pdf_path <- file.path(FD, 'Fig2FG_Williams_VD46plusGDF15_dual_scoring_JHazMat_style.pdf')
png_path <- sub('[.]pdf$', '.png', pdf_path)
ggsave(pdf_path, fig, width = 7.65, height = 3.1, units = 'in', device = cairo_pdf)
ggsave(png_path, fig, width = 7.65, height = 3.1, units = 'in', dpi = 600, bg = 'white')
manifest <- list(created_at = format(Sys.time(), '%Y-%m-%d %H:%M:%S %Z'),
  signature = 'VD46plusGDF15', requested_n = length(genes), scored_n = length(present),
  missing_genes = setdiff(genes, present), strictly_filtered_n = length(strict),
  strict_filter = 'DESeq2 padj < 0.05 AND abs(log2FoldChange) >= 1',
  GDF15_user_added_despite_failing_strict_filter = TRUE,
  signature_direction = 'unsigned: all up/down-responsive genes pooled, matching original F/G method',
  source_gene_audit = audit_path, source_DE = de_path, Williams_expression = fb_path,
  cells = nrow(cells), donor_labels = nrow(donor),
  disease_units = 'one median per donor_id label; independence not newly revalidated',
  AddModuleScore = list(ctrl = 100, nbin = 24, seed = 20260925, assay = 'RNA', layer = 'data'),
  AUCell = list(background_n = nrow(auc_expr), aucMaxRank = auc_max_rank,
                detected_in_at_least_n_cells = 10, all_signature_genes_retained = TRUE,
                nCores = 1, seed = 20260925),
  plot = list(panels = c('F', 'G'), width_inches = 7.65, height_inches = 3.1,
              font = 'Arial', normal = disease_cols[['normal']],
              periodontitis = disease_cols[['periodontitis']], png_dpi = 600),
  original_script_reused = c('01_williams_dual_score_analysis.R', '03_make_figure2.R'),
  old_figures_unchanged = TRUE, outputs = c(pdf_path, png_path))
write_json(manifest, file.path(SD, '12_analysis_manifest.json'), auto_unbox = TRUE, pretty = TRUE)
writeLines(capture.output(sessionInfo()), file.path(SD, '13_sessionInfo.txt'))
writeLines(c('F/G recalculated only. Old full A-P figure retained unchanged.',
             '46 strict D3-responsive DEGs plus GDF15 added explicitly at user request.',
             'GDF15 does not meet the original strict Vitamin-D DEG cutoff.',
             'Unsigned scores measure expression of responsive genes, not Vitamin-D concentration or protective effect.',
             'Each dot is one donor_id median; comparison is healthy 13 vs periodontitis 8 labels.',
             paste0('Genes absent from Williams: ', paste(setdiff(genes, present), collapse = ', '))),
           file.path(OUT, 'README.txt'))
print(tests)
cat('DONE\n', pdf_path, '\n')
