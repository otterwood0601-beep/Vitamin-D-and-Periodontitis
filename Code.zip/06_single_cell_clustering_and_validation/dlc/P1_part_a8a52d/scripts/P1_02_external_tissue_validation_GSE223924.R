options(stringsAsFactors = FALSE)
source("E:/\u8840\u6e05\u7ef4\u751f\u7d20D DLC/00_\u5171\u7528\u914d\u7f6e/project_paths.R")
PROJ <- "P1_\u75be\u75c5\u72b6\u6001\u9a8c\u8bc1"; ensure_dirs(PROJ)
FIG <- SEG_FIGDIR(PROJ); SD <- SEG_SRC(PROJ); QA <- SEG_QA(PROJ)
EXT <- file.path(WORK, "01_\u6570\u636e\u51c6\u5907/external_GSE223924")

suppressPackageStartupMessages({
  library(data.table); library(ggplot2); library(limma); library(edgeR); library(patchwork)
})
set.seed(20260910L)

cat("[0] load GSE223924 raw counts\n")
cnt <- fread(file.path(EXT, "GSE223924_raw_count.csv.gz"))
setnames(cnt, 1, "gene")
mat <- as.matrix(cnt[, -1]); rownames(mat) <- cnt$gene
keep_samples <- grep("^(H|PT)[0-9]+$", colnames(mat), value = TRUE)
mat <- mat[, keep_samples]
grp <- ifelse(grepl("^H[0-9]+$", colnames(mat)), "normal", "periodontitis")
cat("    genes:", nrow(mat), " samples:", ncol(mat),
    " (H:", sum(grp == "normal"), " PT:", sum(grp == "periodontitis"), ")\n")

dge <- DGEList(counts = mat)
keep <- filterByExpr(dge, group = grp)
dge <- dge[keep, , keep.lib.sizes = FALSE]
dge <- calcNormFactors(dge, method = "TMM")
lcpm <- cpm(dge, log = TRUE, prior.count = 0.5)
cat("    retained genes:", nrow(dge), "; GDF15 present:", "GDF15" %in% rownames(dge), "\n")

des <- model.matrix(~ 0 + grp); colnames(des) <- c("normal", "periodontitis")
fit <- lmFit(lcpm, des)
con <- makeContrasts(periodontitis - normal, levels = des)
fit2 <- eBayes(contrasts.fit(fit, con), trend = TRUE, robust = TRUE)
tt <- topTable(fit2, number = Inf, sort.by = "none", confint = TRUE)
res <- data.table(Study = "GSE223924 (tissue bulk)", gene = rownames(tt),
                  log2FC = tt$logFC, CI.L = tt$CI.L, CI.R = tt$CI.R,
                  t = tt$t, P.Value = tt$P.Value, adj.P.Val = tt$adj.P.Val)
fwrite(res, file.path(SD, "13_GSE223924_tissue_bulk_DE.csv.gz"))
fwrite(data.table(gene = rownames(lcpm), as.data.table(lcpm, keep.rownames = FALSE)),
       file.path(SD, "14_GSE223924_log2CPM.csv.gz"))

gmt <- list()
for (ln in readLines(file.path(WORK, "01_\u6570\u636e\u51c6\u5907/outputs/curated_gene_sets_v1.gmt"))) {
  p <- strsplit(ln, "\t", fixed = TRUE)[[1]]
  gmt[[p[1]]] <- p[-c(1, 2)]
}
mods <- rbindlist(lapply(names(gmt), function(s) {
  g <- intersect(gmt[[s]], rownames(lcpm))
  if (length(g) < 3) return(NULL)
  z <- t(scale(t(lcpm[g, , drop = FALSE])))
  data.table(module = s, sample = colnames(lcpm), score = colMeans(z),
             n_genes = length(g))
}))
mod_sum <- mods[, .(median_normal = median(score[grp[sample] == "normal"]),
                    median_pd = median(score[grp[sample] == "periodontitis"])),
                by = module]
mod_w <- dcast(mods, sample ~ module, value.var = "score")
mod_w[, grp := grp[match(sample, colnames(lcpm))]]
mod_stats <- rbindlist(lapply(names(gmt), function(s) {
  if (!s %in% names(mod_w)) return(NULL)
  h <- mod_w[grp == "normal"][[s]]; p <- mod_w[grp == "periodontitis"][[s]]
  wt <- suppressWarnings(wilcox.test(h, p, exact = FALSE))
  data.table(module = s, n_h = length(h), n_p = length(p),
             median_h = median(h), median_p = median(p),
             diff = median(p) - median(h), p_wilcox = wt$p.value)
}))
mod_stats[, p_BH := p.adjust(p_wilcox, "BH")]
fwrite(mod_stats, file.path(SD, "15_GSE223924_module_donor_stats.csv"))

eff_sc <- fread(file.path(SD, "08_GDF15_disease_effect_forest.csv"))
eff_bulk <- res[gene == "GDF15"]
eff_all <- rbind(eff_sc, eff_bulk, fill = TRUE)

ok <- eff_all[Study != "Fixed-effect meta"]
w <- 1 / ((ok$CI.R - ok$CI.L) / (2 * 1.96))^2
ml <- sum(w * ok$log2FC) / sum(w); se <- sqrt(1 / sum(w))
eff_all <- rbind(eff_all, data.table(Study = "Fixed-effect meta (all 3)", gene = "GDF15",
                                     log2FC = ml, CI.L = ml - 1.96 * se, CI.R = ml + 1.96 * se,
                                     t = NA, P.Value = NA, adj.P.Val = NA))
fwrite(eff_all, file.path(SD, "16_GDF15_effect_forest_incl_tissue_bulk.csv"))

eff_all[, Study := factor(Study, levels = c("Williams", "Caetano",
                                            "GSE223924 (tissue bulk)",
                                            "Fixed-effect meta (all 3)"))]
gp <- ggplot(eff_all, aes(log2FC, Study)) +
  geom_vline(xintercept = 0, linetype = "dashed", colour = "grey40", linewidth = 0.4) +
  geom_errorbarh(aes(xmin = CI.L, xmax = CI.R), height = 0.14, linewidth = 0.5) +
  geom_point(aes(fill = Study), shape = 22, size = 2.6, colour = "black", stroke = 0.4) +
  scale_fill_manual(values = c(Williams = "#398AF6", Caetano = "#E9A34D",
                               "GSE223924 (tissue bulk)" = "#2AAC4A",
                               "Fixed-effect meta (all 3)" = "#B2182B"), guide = "none") +
  labs(x = "log2 FC  periodontitis vs healthy (GDF15)",
       y = NULL, title = "GDF15 disease effect: scRNA cohorts + independent tissue bulk") +
  THEME_NPJ + theme(plot.tag = element_text(face = "bold", size = 12), plot.tag.position = "topleft")
ggsave(file.path(FIG, "\u56feP1G_GDF15\u542b\u7ec4\u7ec7bulk\u68ee\u6797\u56fe.pdf"), gp, width = 4.2, height = 2.2)
ggsave(file.path(FIG, "\u56feP1G_GDF15\u542b\u7ec4\u7ec7bulk\u68ee\u6797\u56fe.png"), gp, width = 4.2, height = 2.2, dpi = 300)

ml2 <- melt(mod_stats, id.vars = c("module", "n_h", "n_p", "p_wilcox", "p_BH"),
            measure.vars = c("median_h", "median_p"))
ml2[, dataset := fifelse(variable == "median_h", "Healthy (n=10)", "Periodontitis (n=10)")]
gp2 <- ggplot(ml2, aes(dataset, value, fill = dataset)) +
  geom_col(colour = "black", linewidth = 0.3, width = 0.65) +
  facet_wrap(~module, scales = "free_y") +
  scale_fill_manual(values = c("#3F9B8C", "#D9534F"), guide = "none") +
  labs(x = NULL, y = "median module score (z, logCPM)",
       title = "Locked modules in independent tissue bulk (GSE223924)") +
  THEME_NPJ + theme(axis.text.x = element_text(angle = 30, hjust = 1)) +
  theme(plot.tag = element_text(face = "bold", size = 12), plot.tag.position = "topleft")
ggsave(file.path(FIG, "\u56feP1H_GSE223924\u56fa\u5b9a\u6a21\u5757.pdf"), gp2, width = 5.6, height = 3.2)
ggsave(file.path(FIG, "\u56feP1H_GSE223924\u56fa\u5b9a\u6a21\u5757.png"), gp2, width = 5.6, height = 3.2, dpi = 300)

val <- list(created_at = format(Sys.time()),
            n_genes_raw = nrow(mat), n_genes_retained = nrow(dge),
            gdf15 = res[gene == "GDF15"],
            module_stats = mod_stats,
            meta_all3 = eff_all[Study == "Fixed-effect meta (all 3)"],
            sessionInfo = paste(capture.output(sessionInfo()), collapse = "\n"))
writeLines(jsonlite::toJSON(val, pretty = TRUE, auto_unbox = TRUE, na = "null", digits = 6),
           file.path(QA, "P1_external_QA.json"))
cat("[done] external validation complete\n")
