options(stringsAsFactors = FALSE)
source("E:/\u8840\u6e05\u7ef4\u751f\u7d20D DLC/00_\u5171\u7528\u914d\u7f6e/project_paths.R")
PROJ <- "P1_\u75be\u75c5\u72b6\u6001\u9a8c\u8bc1"; ensure_dirs(PROJ)
FIG <- SEG_FIGDIR(PROJ); SD <- SEG_SRC(PROJ); QA <- SEG_QA(PROJ)

suppressPackageStartupMessages({
  library(Seurat); library(Matrix); library(data.table); library(ggplot2)
  library(limma); library(patchwork); library(ggrepel); library(pheatmap)
})
set.seed(20260910L)
t0 <- Sys.time()
val <- list(created_at = format(Sys.time()))

cat("[0] load annotated fibroblast object\n"); flush.console()
fb <- readRDS(file.path(WORK, "01_\u6570\u636e\u51c6\u5907/outputs/fb_seurat_annotated.rds"))
md <- as.data.table(fb[[]])
md$cell_barcode <- colnames(fb)

gmt <- list()
for (ln in readLines(file.path(WORK, "01_\u6570\u636e\u51c6\u5907/outputs/curated_gene_sets_v1.gmt"))) {
  p <- strsplit(ln, "\t", fixed = TRUE)[[1]]
  gmt[[p[1]]] <- p[-c(1, 2)]
}
counts <- GetAssayData(fb, layer = "counts")

manifest <- md[, .(n_fb_cells = .N), by = .(donor_id, Study, sample_id, disease)]
manifest[, disease_label := fifelse(disease == "normal", "Healthy", "Periodontitis")]
setorder(manifest, Study, disease, donor_id)
fwrite(manifest, file.path(SD, "01_donor_sample_manifest.csv"))
val$n_donors <- nrow(manifest); val$n_cells <- nrow(md)

COMPARISON_STUDIES <- c("Williams", "Caetano")
sub <- md[Study %in% COMPARISON_STUDIES & disease %in% c("normal", "periodontitis")]
cat("    comparison cells:", nrow(sub), " donors:", uniqueN(sub$donor_id), "\n")

cat("[A] donor-level subtype proportions\n")
prop <- sub[, .(n = .N), by = .(donor_id, Study, disease, fibroblast_type, fibroblast_short)]
prop[, prop_in_donor := n / sum(n), by = donor_id]
dstat <- prop[, {
  h <- prop_in_donor[disease == "normal"]; p <- prop_in_donor[disease == "periodontitis"]
  data.table(healthy_n = length(h), pd_n = length(p),
             median_healthy = median(h), median_pd = median(p),
             p_wilcox = if (length(h) >= 3 & length(p) >= 3)
               suppressWarnings(wilcox.test(h, p, exact = FALSE))$p.value else NA_real_)
}, by = .(Study, fibroblast_type)]
dstat[, p_wilcox_BH := p.adjust(p_wilcox, "BH"), by = Study]
fwrite(prop, file.path(SD, "02_donor_subtype_proportions.csv"))
fwrite(dstat, file.path(SD, "03_donor_subtype_proportion_stats.csv"))

dstat[, fibroblast_type := factor(fibroblast_type, levels = rev(FIVE_ORDER))]
prop[, fibroblast_type := factor(fibroblast_short, levels = unname(FIVE_SHORT[FIVE_ORDER]))]
prop[, Study := factor(Study, levels = c("Williams", "Caetano"))]
prop[, disease := factor(disease, levels = c("normal", "periodontitis"))]
gpA <- ggplot(prop, aes(disease, prop_in_donor, fill = disease)) +
  geom_violin(scale = "width", trim = TRUE, colour = "black", linewidth = 0.3, alpha = 0.85) +
  geom_boxplot(width = 0.12, outlier.shape = NA, colour = "black", linewidth = 0.3) +
  geom_jitter(width = 0.06, size = 0.7, shape = 21, fill = "white", colour = "black", stroke = 0.25) +
  facet_grid(Study ~ fibroblast_type, scales = "free_y") +
  scale_fill_manual(values = DISEASE_HEX, labels = DISEASE_LAB, name = NULL) +
  scale_x_discrete(labels = DISEASE_LAB) +
  scale_y_continuous(labels = scales::percent) +
  labs(x = NULL, y = "Fraction of donor fibroblasts",
       title = "Subtype composition per donor (donor as unit, n = 23 Williams / 4 Caetano)") +
  THEME_NPJ + theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 6)) +
  theme(plot.tag = element_text(face = "bold", size = 12), plot.tag.position = "topleft") +
  labs(tag = "A")
ggsave(file.path(FIG, "\u56feP1A_\u4f9b\u8005\u5c42\u9762\u4e94\u7c7b\u4e9a\u7fa4\u6bd4\u4f8b.pdf"), gpA, width = 7.2, height = 4.2)
ggsave(file.path(FIG, "\u56feP1A_\u4f9b\u8005\u5c42\u9762\u4e94\u7c7b\u4e9a\u7fa4\u6bd4\u4f8b.png"), gpA, width = 7.2, height = 4.2, dpi = 300)

cat("[B] Ro/e enrichment heatmap\n")
roe <- rbindlist(lapply(COMPARISON_STUDIES, function(st) {
  tab <- sub[Study == st, .(n = .N), by = .(fibroblast_type, disease)]
  m <- dcast(tab, fibroblast_type ~ disease, value.var = "n", fill = 0)
  mat <- as.matrix(m[, -1]); rownames(mat) <- m$fibroblast_type
  E <- outer(rowSums(mat), colSums(mat)) / sum(mat)
  R <- mat / E
  p_chi <- apply(mat, 1, function(x) suppressWarnings(
    tryCatch(chisq.test(matrix(x, nrow = 1), correct = TRUE)$p.value, error = function(e) NA_real_)))
  data.table(Study = st, fibroblast_type = rownames(mat), as.data.table(R),
             p_chi = p_chi, n_obs = rowSums(mat))
}))
roe[, star := as.character(cut(p_chi, c(-Inf, 0.001, 0.01, 0.05, Inf),
                               labels = c("***", "**", "*", "")))]
fwrite(roe, file.path(SD, "04_RoE_subtype_enrichment.csv"))

roe_long <- melt(roe, id.vars = c("Study", "fibroblast_type", "p_chi", "star", "n_obs"),
                 measure.vars = c("normal", "periodontitis"),
                 variable.name = "disease", value.name = "Roe")
roe_long[, lab := paste0(sprintf("%.2f", Roe), star)]
roe_long[, fibroblast_type := factor(fibroblast_type, levels = FIVE_ORDER)]
gpB <- ggplot(roe_long, aes(disease, fibroblast_type, fill = Roe)) +
  geom_tile(colour = "white", linewidth = 0.6) +
  geom_text(aes(label = lab), size = 2.3) +
  facet_wrap(~Study, nrow = 1) +
  scale_fill_gradient2(low = "#2166AC", mid = "#F7F7F7", high = "#B2182B",
                       midpoint = 1, limits = c(0, NA), name = "Ro/e") +
  labs(x = NULL, y = NULL, title = "Subgroup enrichment (observed / expected)") +
  THEME_NPJ + theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  theme(plot.tag = element_text(face = "bold", size = 12), plot.tag.position = "topleft") +
  labs(tag = "B")
ggsave(file.path(FIG, "\u56feP1B_RoE\u4e9a\u7fa4\u5bcc\u96c6\u70ed\u56fe.pdf"), gpB, width = 4.6, height = 2.4)
ggsave(file.path(FIG, "\u56feP1B_RoE\u4e9a\u7fa4\u5bcc\u96c6\u70ed\u56fe.png"), gpB, width = 4.6, height = 2.4, dpi = 300)

cat("[C] donor-level GDF15 effect + donor x subtype module scores\n")
locked_genes <- intersect(unlist(gmt), rownames(counts))
donor_bcs <- split(sub$cell_barcode, sub$donor_id)
db <- sapply(donor_bcs, function(bc) Matrix::rowSums(counts[, bc, drop = FALSE]))
db <- db[Matrix::rowSums(db) > 0, ]
dlcpm <- log2(sweep(as.matrix(db), 2, colSums(db), FUN = "/") * 1e6 + 0.5)
keep_d <- Matrix::rowSums(db >= 10) >= 3 | (rownames(db) %in% locked_genes) | rownames(db) == "GDF15"
dlcpm <- dlcpm[keep_d, , drop = FALSE]
dlcpm <- dlcpm[apply(dlcpm, 1, sd) > 0, , drop = FALSE]
cat("    donor-level matrix:", nrow(dlcpm), "genes x", ncol(dlcpm),
    "donors; GDF15 included:", "GDF15" %in% rownames(dlcpm), "\n")
dmeta <- data.table(donor_id = colnames(dlcpm))
dmeta[, c("Study", "disease") := {
  k <- match(donor_id, md$donor_id); .(md$Study[k], as.character(md$disease[k])) }]
fwrite(data.table(gene = rownames(dlcpm), as.data.table(dlcpm, keep.rownames = FALSE)),
       file.path(SD, "06_donor_pseudobulk_log2CPM.csv.gz"))

per_study_eff <- rbindlist(lapply(COMPARISON_STUDIES, function(st) {
  sel <- which(dmeta$Study == st)
  des <- model.matrix(~ 0 + disease, data = dmeta[sel])
  colnames(des) <- c("healthy", "periodontitis")
  fit <- lmFit(dlcpm[, sel, drop = FALSE], des)
  con <- makeContrasts(periodontitis - healthy, levels = des)
  fit2 <- eBayes(contrasts.fit(fit, con), trend = TRUE, robust = TRUE)
  tt <- topTable(fit2, number = Inf, sort.by = "none", confint = TRUE)
  data.table(Study = st, gene = rownames(tt),
             log2FC = tt$logFC, CI.L = tt$CI.L, CI.R = tt$CI.R,
             t = tt$t, P.Value = tt$P.Value, adj.P.Val = tt$adj.P.Val)
}))
fwrite(per_study_eff, file.path(SD, "07_per_study_donor_pseudobulk_DE.csv.gz"))

eff <- per_study_eff[gene == "GDF15"]
w <- 1 / ((eff$CI.R - eff$CI.L) / (2 * 1.96))^2
meta_lfc <- sum(w * eff$log2FC) / sum(w); meta_se <- sqrt(1 / sum(w))
eff_meta <- data.table(Study = "Fixed-effect meta", gene = "GDF15", log2FC = meta_lfc,
                       CI.L = meta_lfc - 1.96 * meta_se, CI.R = meta_lfc + 1.96 * meta_se,
                       t = NA, P.Value = NA, adj.P.Val = NA)
eff_plot <- rbind(eff, eff_meta)
fwrite(eff_plot, file.path(SD, "08_GDF15_disease_effect_forest.csv"))

eff_plot[, Study := factor(Study, levels = c("Williams", "Caetano", "Fixed-effect meta"))]
gpC <- ggplot(eff_plot, aes(log2FC, Study)) +
  geom_vline(xintercept = 0, linetype = "dashed", colour = "grey40", linewidth = 0.4) +
  geom_errorbarh(aes(xmin = CI.L, xmax = CI.R), height = 0.12, linewidth = 0.5, colour = "black") +
  geom_point(aes(fill = Study), shape = 22, size = 2.4, colour = "black", stroke = 0.4) +
  scale_fill_manual(values = c(Williams = "#398AF6", Caetano = "#E9A34D",
                               "Fixed-effect meta" = "#B2182B"), guide = "none") +
  labs(x = "log2 FC  periodontitis vs healthy (donor pseudobulk, all fibroblasts)",
       y = NULL, title = "GDF15 disease effect by cohort (limma, donor as unit)") +
  THEME_NPJ + theme(plot.tag = element_text(face = "bold", size = 12), plot.tag.position = "topleft") +
  labs(tag = "C")
ggsave(file.path(FIG, "\u56feP1C_GDF15\u8de8\u961f\u5217\u68ee\u6797\u56fe.pdf"), gpC, width = 3.6, height = 2.0)
ggsave(file.path(FIG, "\u56feP1C_GDF15\u8de8\u961f\u5217\u68ee\u6797\u56fe.png"), gpC, width = 3.6, height = 2.0, dpi = 300)

sub[, gdf15_pos := as.logical(counts["GDF15", cell_barcode])]
det_dt <- sub[, .(n_cells = .N, n_pos = sum(gdf15_pos)),
              by = .(donor_id, Study, disease, fibroblast_type)][n_cells >= 10]
det_dt[, det_frac := n_pos / n_cells]
det_stats <- det_dt[, {
  h <- det_frac[disease == "normal"]; p <- det_frac[disease == "periodontitis"]
  wt <- if (length(h) >= 3 & length(p) >= 3) suppressWarnings(wilcox.test(h, p, exact = FALSE)) else NULL
  data.table(n_h = length(h), n_p = length(p),
             median_h = median(h), median_p = median(p),
             p_wilcox = if (is.null(wt)) NA_real_ else wt$p.value)
}, by = .(Study, fibroblast_type)]
det_stats[, p_BH := p.adjust(p_wilcox, "BH"), by = Study]
fwrite(det_dt, file.path(SD, "08b_GDF15_detection_fraction_donor_subtype.csv"))
fwrite(det_stats, file.path(SD, "08c_GDF15_detection_fraction_stats.csv"))
overall_det <- sub[, .(n_cells = .N, n_pos = sum(gdf15_pos))]

cat("[C2] donor x subtype pseudobulk\n")
sub[, unit := paste(donor_id, fibroblast_type, sep = "@@")]
bc_by_unit <- split(sub$cell_barcode, sub$unit)
bc_by_unit <- bc_by_unit[sapply(bc_by_unit, length) >= 10]
cmat <- as(counts[, unlist(bc_by_unit), drop = FALSE], "dgCMatrix")
pb <- sapply(bc_by_unit, function(bc) Matrix::rowSums(cmat[, bc, drop = FALSE]))
pb <- pb[Matrix::rowSums(pb) > 0, ]
pb <- pb[, colSums(pb) >= 500]
meta_units <- data.table(unit = colnames(pb))
meta_units[, donor_id := tstrsplit(unit, "@@", keep = 1)]
meta_units[, fibroblast_type := tstrsplit(unit, "@@", keep = 2)]
meta_units[, c("Study", "disease") := {
  k <- match(donor_id, md$donor_id); .(md$Study[k], as.character(md$disease[k])) }]
fwrite(meta_units, file.path(SD, "05_pseudobulk_unit_metadata.csv"))
lib <- colSums(pb)
lcpm <- log2(sweep(as.matrix(pb), 2, lib, FUN = "/") * 1e6 + 0.5)
keep_g <- (Matrix::rowSums(pb >= 10) >= 3) |
  (rownames(pb) %in% locked_genes & Matrix::rowSums(pb > 0) >= 5)
lcpm <- lcpm[keep_g, , drop = FALSE]
lcpm <- lcpm[apply(lcpm, 1, sd) > 0, , drop = FALSE]
cat("    unit matrix:", nrow(lcpm), "genes x", ncol(lcpm), "units\n")
fwrite(data.table(gene = rownames(lcpm), as.data.table(lcpm, keep.rownames = FALSE)),
       file.path(SD, "06b_pseudobulk_donor_subtype_log2CPM.csv.gz"))

cat("[D] locked module scores\n")
genes_present <- intersect(unlist(gmt), rownames(lcpm))
zmat <- t(apply(lcpm[genes_present, , drop = FALSE], 1, function(v) (v - mean(v)) / sd(v)))
colnames(zmat) <- colnames(lcpm)
mod_score <- sapply(names(gmt), function(s) {
  g <- intersect(gmt[[s]], genes_present)
  if (length(g) < 3) return(rep(NA_real_, ncol(zmat)))
  colMeans(zmat[g, , drop = FALSE])
})
mod_dt <- as.data.table(mod_score); mod_dt$unit <- colnames(lcpm)
setcolorder(mod_dt, "unit")
fwrite(mod_dt, file.path(SD, "09_module_scores_donor_subtype.csv"))

mod_long <- melt(mod_dt, id.vars = "unit", variable.name = "module", value.name = "score")
mod_long[meta_units, on = "unit", `:=`(donor_id = i.donor_id,
                                       fibroblast_type = i.fibroblast_type,
                                       Study = i.Study, disease = i.disease)]
det_unit <- sub[, .(det_frac = mean(gdf15_pos)), by = unit]
mod_long[det_unit, GDF15_det_frac := i.det_frac, on = "unit"]
fwrite(mod_long, file.path(SD, "10_module_scores_long.csv"))

mod_stats <- mod_long[!is.na(disease), {
  h <- score[disease == "normal"]; p <- score[disease == "periodontitis"]
  wt <- if (length(h) >= 3 & length(p) >= 3) suppressWarnings(wilcox.test(h, p, exact = FALSE)) else NULL
  data.table(n_h = length(h), n_p = length(p), median_h = median(h), median_p = median(p),
             diff = median(p) - median(h), p_wilcox = if (is.null(wt)) NA_real_ else wt$p.value)
}, by = module]
mod_stats[, p_BH := p.adjust(p_wilcox, "BH")]
fwrite(mod_stats, file.path(SD, "11_module_score_donor_stats.csv"))

gdf15_vec <- mod_long[module == names(gmt)[1], GDF15_det_frac]
cor_tab <- rbindlist(lapply(names(gmt), function(s) {
  g <- intersect(gmt[[s]], rownames(lcpm))
  if (length(g) < 3) return(NULL)
  v1 <- mod_score[, s]; v1x <- colMeans(zmat[setdiff(g, "GDF15"), , drop = FALSE])
  ok <- !is.na(v1) & !is.na(gdf15_vec)
  ct <- suppressWarnings(cor.test(v1[ok], gdf15_vec[ok], method = "spearman"))
  ct2 <- suppressWarnings(cor.test(v1x[ok], gdf15_vec[ok], method = "spearman"))
  data.table(module = s, n_unit = sum(ok), n_genes = length(g),
             rho = unname(ct$estimate), p = ct$p.value,
             rho_excl_GDF15 = unname(ct2$estimate), p_excl_GDF15 = ct2$p.value)
}))
cor_tab[, p_BH := p.adjust(p, "BH")]
fwrite(cor_tab, file.path(SD, "12_GDF15_module_spearman_with_sensitivity.csv"))

SEL_MODULES <- c("MAPK_ERK_transcriptional_response", "MAPK_JNK_p38_transcriptional_response",
                 "ECM_synthesis_collagen", "ECM_organization_structure",
                 "ECM_degradation_MMP_ADAMTS", "WNT_niche_fibroblast_signature")
mod_long[, fibroblast_type := factor(unname(FIVE_SHORT[fibroblast_type]),
                                     levels = unname(FIVE_SHORT[FIVE_ORDER]))]
mod_long[, Study := factor(Study, levels = c("Williams", "Caetano"))]
mod_long[, disease := factor(disease, levels = c("normal", "periodontitis"))]
gpD <- ggplot(mod_long[module %in% SEL_MODULES & !is.na(disease)],
              aes(disease, score, fill = disease)) +
  geom_boxplot(outlier.shape = NA, width = 0.55, colour = "black", linewidth = 0.3) +
  geom_jitter(width = 0.1, size = 0.45, shape = 21, fill = "white", colour = "black", stroke = 0.2) +
  facet_grid(Study + module ~ fibroblast_type, scales = "free_y") +
  scale_fill_manual(values = DISEASE_HEX, labels = DISEASE_LAB, name = NULL) +
  scale_x_discrete(labels = DISEASE_LAB) +
  labs(x = NULL, y = "Locked module score (donor x subtype)",
       title = "Pre-registered modules compared at donor level") +
  THEME_NPJ + theme(axis.text.x = element_blank(), axis.ticks.x = element_blank(),
                    strip.text.y = element_text(size = 6),
                    plot.tag = element_text(face = "bold", size = 12),
                    plot.tag.position = "topleft") +
  labs(tag = "D")
ggsave(file.path(FIG, "\u56feP1D_\u56fa\u5b9a\u6a21\u5757\u5206\u6570\u4f9b\u8005\u7ea7.pdf"), gpD, width = 7.2, height = 6.5)
ggsave(file.path(FIG, "\u56feP1D_\u56fa\u5b9a\u6a21\u5757\u5206\u6570\u4f9b\u8005\u7ea7.png"), gpD, width = 7.2, height = 6.5, dpi = 300)

cat("[E] GDF15 display\n")
um_df <- md[, .(frozen_umap_1, frozen_umap_2, GDF15_log_normalized, fibroblast_short,
                disease = as.character(disease), Study)]
gpE <- ggplot(um_df, aes(frozen_umap_1, frozen_umap_2, colour = GDF15_log_normalized)) +
  geom_point(size = 0.08, shape = 16) +
  scale_colour_viridis_c(name = "GDF15\nlog-normalized", option = "magma") +
  coord_equal() + labs(x = "UMAP 1", y = "UMAP 2",
                       title = sprintf("GDF15 expression, %s fibroblasts\n(detection %d/%d cells = %.2f%%)",
                                       prettyNum(nrow(md), big.mark = ","),
                                       overall_det$n_pos, overall_det$n_cells,
                                       100 * overall_det$n_pos / overall_det$n_cells)) +
  THEME_NPJ + theme(panel.background = element_rect(fill = "grey95", colour = NA),
                    plot.tag = element_text(face = "bold", size = 12), plot.tag.position = "topleft") +
  labs(tag = "E")
ggsave(file.path(FIG, "\u56feP1E_GDF15\u5355\u7ec6\u80deUMAP.pdf"), gpE, width = 3.2, height = 2.7)
ggsave(file.path(FIG, "\u56feP1E_GDF15\u5355\u7ec6\u80deUMAP.png"), gpE, width = 3.2, height = 2.7, dpi = 300)

hm_dt <- data.table(unit = colnames(lcpm))
hm_dt[det_unit, GDF15_det := i.det_frac, on = "unit"]
hm_dt[meta_units, on = "unit", `:=`(donor_id = i.donor_id, fibroblast_type = i.fibroblast_type,
                                    Study = i.Study, disease = i.disease)]
hm_dt <- hm_dt[!is.na(disease)]
mat <- dcast(hm_dt, donor_id ~ fibroblast_type, value.var = "GDF15_det", fun.aggregate = mean)
mm <- as.matrix(mat[, -1]); rownames(mm) <- mat$donor_id
ord <- hm_dt[!duplicated(donor_id)][order(disease, -GDF15_det)]$donor_id
mm <- mm[intersect(ord, rownames(mm)), , drop = FALSE]
ann <- data.frame(disease = DISEASE_LAB[as.character(hm_dt[!duplicated(donor_id)][order(disease, -GDF15_det)]$disease)],
                  row.names = hm_dt[!duplicated(donor_id)][order(disease, -GDF15_det)]$donor_id)
ann <- ann[rownames(mm), , drop = FALSE]
for (ext in c("pdf", "png")) {
  pheatmap(mm, scale = "column", cluster_cols = FALSE, cluster_rows = FALSE,
           na_col = "grey90",
           annotation_row = ann, annotation_col = data.frame(row.names = colnames(mm),
                                                             subtype = colnames(mm)),
           fontsize = 6.5, fontsize_row = 5, border_color = NA,
           main = sprintf("GDF15 detection fraction (donor x subtype)\noverall detection %d/%d cells = %.2f%%",
                          overall_det$n_pos, overall_det$n_cells, 100 * overall_det$n_pos / overall_det$n_cells),
           filename = file.path(FIG, paste0("\u56feP1F_GDF15\u68c0\u51fa\u7387\u4f9b\u8005\u4e9a\u578b\u70ed\u56fe.", ext)),
           width = 5.2, height = 5.8, res = if (ext == "png") 300 else NULL)
}

val$units_kept <- ncol(lcpm); val$genes_tested <- nrow(lcpm)
val$gdf15_detection <- overall_det
val$gdf15_effects <- eff_plot
val$module_stats <- mod_stats
val$gdf15_module_correlation <- cor_tab
val$elapsed_min <- round(as.numeric(difftime(Sys.time(), t0, units = "mins")), 2)
val$sessionInfo <- paste(capture.output(sessionInfo()), collapse = "\n")
writeLines(jsonlite::toJSON(val, pretty = TRUE, auto_unbox = TRUE, na = "null", digits = 6),
           file.path(QA, "P1_QA_report.json"))
cat("[done] P1 in", val$elapsed_min, "min\n")
