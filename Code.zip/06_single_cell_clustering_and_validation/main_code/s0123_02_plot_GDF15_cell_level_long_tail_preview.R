options(stringsAsFactors = FALSE)

args <- commandArgs(trailingOnly = TRUE)
out_dir <- if (length(args) >= 1L) args[[1L]] else file.path(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/04_\u5355\u7ec6\u80de",
  "20260822_GDF15\u5065\u5eb7vs\u7259\u5468\u708e_\u4e94\u7c7b\u6210\u7ea4\u7ef4\u7ec6\u80de\u8868\u8fbe_\u5206\u88c2\u5c0f\u63d0\u7434_v1"
)
fb_rds_path <- if (length(args) >= 2L) args[[2L]] else paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/05_\u5355\u7ec6\u80deRNA/\u6d3e\u751f\u8f93\u5165/GDF15_Figure1/input_fb/",
  "all_conditions_allStudies_CELLxGENE_direct_fibroblast_counts_only.rds"
)
cell_map_path <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/05_\u5355\u7ec6\u80deRNA/\u6d3e\u751f\u8f93\u5165/GDF15_Figure1/cell_cluster_mapping.csv.gz"
merge_map_path <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/05_\u5355\u7ec6\u80deRNA/\u6d3e\u751f\u8f93\u5165/GDF15_Figure1/five_type_merge_mapping.csv"

.libPaths(c(
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_Seurat4",
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_stage11",
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library",
  .libPaths()
))
suppressPackageStartupMessages({
  library(data.table)
  library(SeuratObject)
  library(Matrix)
  library(ragg)
})

five_order <- c(
  "Vascular-associated fibroblasts",
  "Immune-associated fibroblasts",
  "ECM remodeling-associated fibroblasts",
  "Pre-extracellular matrix-associated fibroblasts",
  "Matrix homeostasis-associated fibroblasts"
)
five_short <- c(
  "Vascular-associated fibroblasts" = "Vascular",
  "Immune-associated fibroblasts" = "Immune",
  "ECM remodeling-associated fibroblasts" = "ECM remodeling",
  "Pre-extracellular matrix-associated fibroblasts" = "Pre-ECM",
  "Matrix homeostasis-associated fibroblasts" = "Matrix homeostasis"
)

stats_path <- file.path(
  out_dir,
  "01_source_data_and_audit",
  "02_GDF15_healthy_vs_periodontitis_five_FB_Zscore_statistics.csv"
)
donor_data_path <- file.path(
  out_dir,
  "01_source_data_and_audit",
  "01_donor_subtype_GDF15_scale_data.csv"
)
inputs <- c(
  fb_rds_path,
  cell_map_path,
  merge_map_path,
  stats_path,
  donor_data_path
)
if (!all(file.exists(inputs))) {
  stop("Missing input(s):\n", paste(inputs[!file.exists(inputs)], collapse = "\n"))
}

fb_obj <- readRDS(fb_rds_path)
fb_counts <- LayerData(fb_obj, assay = "RNA", layer = "counts")
cell_map <- fread(cell_map_path)
merge_map <- fread(merge_map_path)
cell_map <- merge(
  cell_map,
  merge_map[, .(
    fb_id = original_fb_id,
    final_fibroblast_type
  )],
  by = "fb_id",
  all.x = TRUE,
  sort = FALSE
)
index <- match(colnames(fb_counts), cell_map$cell_barcode)
if (sum(!is.na(index)) != ncol(fb_counts)) {
  stop("Some fibroblast cells lack mapping rows")
}
cell_info <- cell_map[index, ]
keep_cell <- !is.na(cell_info$final_fibroblast_type) &
  nzchar(cell_info$final_fibroblast_type) &
  cell_info$final_fibroblast_type %in% five_order
fb_counts <- fb_counts[, keep_cell, drop = FALSE]
cell_info <- cell_info[keep_cell, ]

gdf15_index <- which(toupper(rownames(fb_counts)) == "GDF15")
if (length(gdf15_index) != 1L) stop("Expected exactly one GDF15 row")
cell_library <- as.numeric(Matrix::colSums(fb_counts))
gdf15_counts <- as.numeric(fb_counts[gdf15_index, ])
gdf15_log_normalized <- log1p(gdf15_counts / pmax(cell_library, 1) * 1e4)
scale_center <- mean(gdf15_log_normalized)
scale_sd <- sd(gdf15_log_normalized)
gdf15_scale_data <- pmax(
  -10,
  pmin(10, (gdf15_log_normalized - scale_center) / scale_sd)
)

cell_data <- data.frame(
  donor_id = cell_info$donor_id,
  disease = cell_info$disease,
  study = cell_info$Study,
  fibroblast_type = cell_info$final_fibroblast_type,
  GDF15_scale_data = gdf15_scale_data,
  stringsAsFactors = FALSE
)
cell_data <- subset(
  cell_data,
  disease %in% c("normal", "periodontitis") &
    fibroblast_type %in% five_order
)
cell_data$disease_label <- ifelse(
  cell_data$disease == "normal", "Healthy", "Periodontitis"
)
cell_data$fibroblast_type <- factor(
  cell_data$fibroblast_type,
  levels = five_order
)

study_gse_map <- c(
  "Caetano" = "GSE152042",
  "Pagella" = "GSE161267",
  "Williams" = "GSE164241",
  "Huang" = "GSE266897"
)
cohort_audit <- as.data.table(cell_info)[, .(
  retained_fibroblast_cells = .N
), by = .(Study, disease)]
cohort_audit[, GSE := unname(study_gse_map[Study])]
cohort_audit[, input_matrix_orientation := "gene x cell"]
cohort_audit[, input_layer := "RNA counts"]
cohort_audit[, included_in_healthy_vs_periodontitis :=
  disease %in% c("normal", "periodontitis")]
cohort_audit[, exclusion_reason := fifelse(
  included_in_healthy_vs_periodontitis,
  "",
  "gingivitis excluded from binary comparison"
)]
setcolorder(cohort_audit, c(
  "GSE",
  "Study",
  "disease",
  "retained_fibroblast_cells",
  "input_matrix_orientation",
  "input_layer",
  "included_in_healthy_vs_periodontitis",
  "exclusion_reason"
))
setorder(cohort_audit, GSE, disease)
fwrite(
  cohort_audit,
  file.path(
    out_dir,
    "01_source_data_and_audit",
    "03_four_GSE_gene_by_cell_source_audit.csv"
  )
)

stats <- fread(stats_path, data.table = FALSE)
stats$significance <- as.character(cut(
  stats$study_adjusted_p_value,
  breaks = c(-Inf, 0.001, 0.01, 0.05, Inf),
  labels = c("***", "**", "*", "ns"),
  right = FALSE
))
donor_data <- fread(donor_data_path, data.table = FALSE)
donor_data$disease_label <- ifelse(
  donor_data$disease == "normal", "Healthy", "Periodontitis"
)

healthy_color <- "#F07A73"
periodontitis_color <- "#55BBD8"
visual_y_minimum <- -1
visual_y_maximum <- 1
violin_half_width <- 0.19
summary_horizontal_offset <- 0.08
cell_center_spacing <- 0.50
adjacent_violin_edge_gap <- cell_center_spacing - 2 * violin_half_width
figure_width_inches <- 10
figure_height_inches <- 8.5

draw_half_violin <- function(
  values,
  position,
  side,
  color,
  width = violin_half_width
) {
  values <- values[is.finite(values)]
  if (length(values) < 2L) return(invisible(NULL))
  den <- density(
    values,
    n = 512L,
    bw = "nrd0",
    adjust = 1,
    from = visual_y_minimum,
    to = visual_y_maximum,
    cut = 3
  )
  keep <- is.finite(den$y) & den$y >= 0
  y <- den$x[keep]
  density_values <- den$y[keep]
  density_values <- density_values / max(density_values) * width
  x <- if (side == "left") position - density_values else position + density_values
  polygon(
    x = c(rep(position, length(y)), rev(x)),
    y = c(y, rev(y)),
    col = color,
    border = "black",
    lwd = 0.7
  )
}

draw_mean_sem <- function(values, position, side) {
  values <- values[is.finite(values)]
  if (length(values) < 2L) return(invisible(NULL))
  center <- mean(values)
  sem <- sd(values) / sqrt(length(values))
  interval <- pmax(
    visual_y_minimum,
    pmin(visual_y_maximum, c(center - sem, center + sem))
  )
  offset <- if (side == "left") {
    -summary_horizontal_offset
  } else {
    summary_horizontal_offset
  }
  segments(
    position + offset,
    interval[[1L]],
    position + offset,
    interval[[2L]],
    lwd = 1.6,
    col = "black"
  )
  segments(
    position + offset - 0.035,
    interval[[1L]],
    position + offset + 0.035,
    interval[[1L]],
    lwd = 1.6,
    col = "black"
  )
  segments(
    position + offset - 0.035,
    interval[[2L]],
    position + offset + 0.035,
    interval[[2L]],
    lwd = 1.6,
    col = "black"
  )
  points(
    position + offset,
    center,
    pch = 16,
    cex = 0.9,
    col = "black"
  )
}

draw_figure <- function() {
  old_par <- par(no.readonly = TRUE)
  on.exit(par(old_par), add = TRUE)
  par(
    mar = c(9.2, 5.5, 5.6, 5.2),
    mgp = c(3.3, 0.85, 0),
    las = 1,
    family = "sans",
    xpd = NA
  )
  x_positions <- 1 + (seq_along(five_order) - 1) * cell_center_spacing
  plot(
    NA,
    xlim = c(0.35, max(x_positions) + 1.45),
    ylim = c(visual_y_minimum, visual_y_maximum),
    yaxs = "i",
    axes = FALSE,
    xlab = "",
    ylab = "GDF15 expression Z-score (scale.data)",
    cex.lab = 1.05
  )
  mtext(
    "GDF15 expression across five fibroblast types",
    side = 3,
    line = 3.0,
    cex = 1.15,
    font = 2
  )
  mtext(
    "Healthy vs periodontitis; cell-level scale.data from gene x cell matrices; donor-level raw P",
    side = 3,
    line = 1.6,
    cex = 0.84,
    col = "#444444"
  )
  grid_y <- seq(-1, 1, by = 0.5)
  abline(h = grid_y, col = "#DFDFDF", lwd = 1.0)
  axis(2, at = grid_y, labels = sprintf("%.1f", grid_y), lwd = 1.6,
       lwd.ticks = 1.2, cex.axis = 0.88)
  axis(1, at = x_positions, labels = FALSE, lwd = 1.6, lwd.ticks = 1.2)
  abline(h = 0, col = "#777777", lwd = 1.0)

  x_labels <- character(length(five_order))
  for (i in seq_along(five_order)) {
    position <- x_positions[[i]]
    z <- cell_data[cell_data$fibroblast_type == five_order[[i]], ]
    healthy <- z$GDF15_scale_data[z$disease_label == "Healthy"]
    periodontitis <- z$GDF15_scale_data[z$disease_label == "Periodontitis"]
    draw_half_violin(healthy, position, "left", healthy_color)
    draw_half_violin(periodontitis, position, "right", periodontitis_color)

    donor_z <- donor_data[donor_data$fibroblast_type == five_order[[i]], ]
    donor_healthy <- donor_z$GDF15_mean_Z_score[
      donor_z$disease_label == "Healthy"
    ]
    donor_periodontitis <- donor_z$GDF15_mean_Z_score[
      donor_z$disease_label == "Periodontitis"
    ]
    draw_mean_sem(donor_healthy, position, "left")
    draw_mean_sem(donor_periodontitis, position, "right")

    stat_row <- stats[stats$fibroblast_type == five_order[[i]], , drop = FALSE]
    text(position, 0.91, stat_row$significance[[1L]], font = 2, cex = 0.88)
    x_labels[[i]] <- paste0(
      five_short[[five_order[[i]]]],
      "\nH", stat_row$healthy_n_donors[[1L]],
      " / P", stat_row$periodontitis_n_donors[[1L]]
    )
  }

  text(
    x_positions,
    par("usr")[[3L]] - 0.045 * diff(par("usr")[3:4]),
    labels = x_labels,
    srt = 42,
    adj = 1,
    cex = 0.82
  )
  box(bty = "l", lwd = 1.6)
  mtext(
    "(E)",
    side = 3,
    line = 2.0,
    at = par("usr")[[1L]] - 0.28,
    adj = 0,
    cex = 1.35,
    font = 2
  )
  legend(
    x = max(x_positions) + 0.70,
    y = mean(c(visual_y_minimum, visual_y_maximum)),
    legend = c("Healthy", "Periodontitis"),
    fill = c(healthy_color, periodontitis_color),
    border = NA,
    title = "Groups",
    bty = "n",
    cex = 0.9,
    xpd = NA
  )
  mtext(
    "Sources: GSE152042, GSE161267, GSE164241, GSE266897; GSE266897 gingivitis cells excluded from this comparison.",
    side = 1,
    line = 7.4,
    adj = 0,
    cex = 0.64,
    col = "#555555"
  )
  mtext(
    "Black dot and whiskers: donor mean +/- SEM; raw P uses study-adjusted donor-level models.",
    side = 1,
    line = 8.2,
    adj = 0,
    cex = 0.64,
    col = "#555555"
  )
}

png_path <- file.path(
  out_dir,
  "GDF15_cell_level_preview.png"
)
pdf_path <- file.path(
  out_dir,
  "GDF15_cell_level_preview.pdf"
)
png(
  png_path,
  width = figure_width_inches,
  height = figure_height_inches,
  units = "in",
  res = 600,
  pointsize = 12,
  bg = "white"
)
draw_figure()
dev.off()

cairo_pdf(
  pdf_path,
  width = figure_width_inches,
  height = figure_height_inches,
  family = "sans"
)
draw_figure()
dev.off()

qa <- data.frame(
  check = c(
    "cell-level rows plotted",
    "both disease groups present",
    "all five fibroblast types present",
    "negative values present",
    "upper tail exceeds 1 before display clipping",
    "four GSE source cohorts documented",
    "donor summaries available for all ten halves",
    "violin half-width reduced by 50 percent",
    "adjacent violin edge gap reduced by 50 percent",
    "summary pair spacing restored",
    "vertical canvas extended to 8.5 inches",
    "axis fixed to -1 and 1",
    "PNG created",
    "PDF created"
  ),
  result = c(
    nrow(cell_data) > 0,
    all(c("normal", "periodontitis") %in% cell_data$disease),
    all(five_order %in% as.character(unique(cell_data$fibroblast_type))),
    any(cell_data$GDF15_scale_data < 0),
    any(cell_data$GDF15_scale_data > 1),
    identical(sort(unique(cohort_audit$GSE)), sort(unname(study_gse_map))),
    nrow(aggregate(
      GDF15_mean_Z_score ~ fibroblast_type + disease_label,
      data = donor_data,
      FUN = length
    )) == 10,
    identical(violin_half_width, 0.19),
    isTRUE(all.equal(adjacent_violin_edge_gap, 0.12)),
    identical(summary_horizontal_offset, 0.08),
    identical(figure_height_inches, 8.5),
    identical(visual_y_minimum, -1) && identical(visual_y_maximum, 1),
    file.exists(png_path),
    file.exists(pdf_path)
  ),
  stringsAsFactors = FALSE
)
fwrite(
  qa,
  file.path(out_dir, "03_QA", "02_cell_level_long_tail_preview_QA.csv")
)
if (!all(qa$result)) stop("One or more cell-level preview QA checks failed")

message("Created: ", png_path)
message("Created: ", pdf_path)
