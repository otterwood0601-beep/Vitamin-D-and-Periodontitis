args <- commandArgs(trailingOnly = TRUE)
output_root <- if (length(args) >= 1L) args[[1]] else stop("output_root argument is required")
runtime_root <- if (length(args) >= 2L) args[[2]] else stop("runtime_root argument is required")
audit_dir <- file.path(output_root, "00_\u6e90\u6570\u636e\u4e0e\u5ba1\u8ba1")

source(file.path(audit_dir, "00_common.R"), encoding = "UTF-8")
configure_runtime(runtime_root)

input_A <- file.path(audit_dir, "\u8f93\u5165_A.27\u79cd\u7ec6\u80de\u5206\u7c7b\u5730\u56fe_\u6e90\u6570\u636e.csv.gz")
input_B <- file.path(audit_dir, "\u8f93\u5165_B.27\u79cd\u7ec6\u80de\u5806\u79ef\u67f1\u72b6\u56fe_21\u6837\u672c\u6e90\u6570\u636e.csv")
input_C <- file.path(audit_dir, "\u8f93\u5165_C.27\u79cd\u7ec6\u80de\u7684\u5bf9\u89d2\u7ebfDotPlot\u56fe_\u6e90\u6570\u636e.csv")
input_counts <- file.path(audit_dir, "\u8f93\u5165_27\u79cd\u7ec6\u80de_\u7f16\u53f7\u82f1\u6587\u4e2d\u6587\u4e0e\u603b\u6570.csv")
input_meta <- file.path(audit_dir, "\u8f93\u5165_Williams\u76ee\u6807\u961f\u5217_QC\u540e\u9010\u7ec6\u80de\u6807\u7b7e\u4e0eQC.csv.gz")

invisible(lapply(c(input_A, input_B, input_C, input_counts, input_meta), assert_file))

message("Validating the Williams-only source scope ...")
meta <- fread(input_meta, select = c("Study", "sample_id", "donor_id", "disease", "cell_type"))
if (!identical(unique(meta$Study), "Williams")) stop("The source contains non-Williams cells")
if (!setequal(unique(meta$disease), c("normal", "periodontitis"))) stop("The disease scope is not normal + periodontitis")
if (uniqueN(meta$sample_id) != 21L || uniqueN(meta$donor_id) != 21L) stop("Expected 21 Williams samples/donors")
if (nrow(meta) != 66962L || uniqueN(meta$cell_type) != 27L) stop("Expected 66,962 cells and 27 cell types")

cell_counts <- fread(input_counts)
if (nrow(cell_counts) != 27L || sum(cell_counts$N) != 66962L) stop("Cell-count table does not match the validated source scope")
cell_levels <- cell_counts$cell_type_display
pal <- setNames(palette_n(length(cell_levels)), cell_levels)

message("Creating A without title/subtitle ...")
umap <- fread(input_A)
umap[, cell_type_display := factor(cell_type_display, levels = cell_levels)]
centroids <- umap[, .(
  UMAP_1 = median(UMAP_1),
  UMAP_2 = median(UMAP_2),
  cell_type_id = data.table::first(cell_type_id)
), by = cell_type_display]

pA <- ggplot(umap, aes(UMAP_1, UMAP_2, colour = cell_type_display)) +
  geom_point(size = 0.12, alpha = 0.72) +
  scale_colour_manual(values = pal, drop = FALSE) +
  ggrepel::geom_label_repel(
    data = centroids,
    aes(label = cell_type_id),
    size = 2.7,
    fontface = "bold",
    colour = "black",
    fill = alpha("white", 0.86),
    label.size = 0.15,
    min.segment.length = 0,
    seed = 42,
    show.legend = FALSE,
    max.overlaps = Inf
  ) +
  labs(colour = "CELLxGENE cell type", x = "UMAP 1", y = "UMAP 2") +
  theme_submission(10) +
  theme(
    legend.position = "right",
    legend.key.height = grid::unit(0.32, "cm"),
    legend.text = element_text(size = 7.2)
  ) +
  guides(colour = guide_legend(override.aes = list(size = 2.6, alpha = 1), ncol = 1))

path_A <- file.path(output_root, "A.27\u79cd\u7ec6\u80de\u5206\u7c7b\u5730\u56fe\uff08\u6700\u7ec8\u7a3f-\u5168\u7ec6\u80de\uff09.pdf")
save_pdf(pA, path_A, width = 13.5, height = 9.2)
write_table(umap, file.path(audit_dir, "A.27\u79cd\u7ec6\u80de\u5206\u7c7b\u5730\u56fe\uff08\u6700\u7ec8\u7a3f\uff09_\u6e90\u6570\u636e.csv.gz"))

message("Creating B as one Williams-wide 100% stacked bar ...")
composition_input <- fread(input_B)
if (uniqueN(composition_input$sample_id) != 21L || sum(composition_input$N) != 66962L) stop("B input is not the complete 21-sample Williams cohort")
composition <- composition_input[, .(N = sum(N)), by = cell_type_display]
composition <- merge(
  data.table(cell_type_display = cell_levels),
  composition,
  by = "cell_type_display",
  all.x = TRUE,
  sort = FALSE
)
composition[is.na(N), N := 0L]
composition[, proportion := N / sum(N)]
composition[, cohort := "Williams"]
composition[, cell_type_display := factor(cell_type_display, levels = cell_levels)]
composition[, label_y := 1 - cumsum(proportion) + proportion / 2]
if (sum(composition$N) != 66962L || abs(sum(composition$proportion) - 1) > 1e-12) stop("Aggregated B denominator/proportion check failed")

pB <- ggplot(composition, aes(cohort, proportion, fill = cell_type_display)) +
  geom_col(width = 0.62, colour = "white", linewidth = 0.35) +
  geom_text(
    data = composition[proportion >= 0.03],
    aes(y = label_y, label = percent(proportion, accuracy = 0.1)),
    size = 3.1,
    colour = "#111111",
    fontface = "bold",
    show.legend = FALSE
  ) +
  scale_fill_manual(values = pal, drop = FALSE) +
  scale_y_continuous(labels = percent_format(accuracy = 1), expand = expansion(mult = c(0, 0.01))) +
  labs(x = NULL, y = "Proportion of retained cells", fill = "CELLxGENE cell type") +
  theme_submission(11) +
  theme(
    axis.text.x = element_text(face = "bold"),
    legend.text = element_text(size = 7.4),
    legend.key.height = grid::unit(0.34, "cm")
  ) +
  guides(fill = guide_legend(ncol = 1))

path_B <- file.path(output_root, "B.27\u79cd\u7ec6\u80de\u5806\u79ef\u67f1\u72b6\u56fe\uff08\u6700\u7ec8\u7a3f-\u5168\u7ec6\u80de\uff09.pdf")
save_pdf(pB, path_B, width = 9.8, height = 8.4)
write_table(composition, file.path(audit_dir, "B.27\u79cd\u7ec6\u80de\u5806\u79ef\u67f1\u72b6\u56fe\uff08\u6700\u7ec8\u7a3f\uff09_\u6e90\u6570\u636e.csv"))

message("Creating C without title/subtitle or diagonal frames ...")
dot_data <- fread(input_C)
if (uniqueN(dot_data$group) != 27L) stop("C input does not contain 27 cell types")
key_levels <- unique(dot_data$key)
key_labels <- setNames(dot_data[match(key_levels, key)]$gene, key_levels)

pC <- plot_diagonal_dot(
  dot_data = dot_data,
  key_levels = key_levels,
  group_levels = cell_levels,
  x_title = "Canonical marker genes (ordered by reference cell type)",
  y_title = "CELLxGENE cell type",
  title = NULL,
  subtitle = NULL,
  key_labels = key_labels
)

path_C <- file.path(output_root, "C.27\u79cd\u7ec6\u80de\u7684\u5bf9\u89d2\u7ebfDotPlot\u56fe\uff08\u6700\u7ec8\u7a3f-\u5168\u7ec6\u80de\uff09.pdf")
save_pdf(pC, path_C, width = 23.5, height = 11.5)
write_table(dot_data, file.path(audit_dir, "C.27\u79cd\u7ec6\u80de\u7684\u5bf9\u89d2\u7ebfDotPlot\u56fe\uff08\u6700\u7ec8\u7a3f\uff09_\u6e90\u6570\u636e.csv"))

scope_check <- data.table(
  item = c("Study", "diseases", "samples", "donors", "QC-retained cells", "cell types", "B aggregated N", "B proportion sum"),
  value = c(
    paste(unique(meta$Study), collapse = ","),
    paste(sort(unique(meta$disease)), collapse = ","),
    uniqueN(meta$sample_id),
    uniqueN(meta$donor_id),
    nrow(meta),
    uniqueN(meta$cell_type),
    sum(composition$N),
    format(sum(composition$proportion), digits = 16)
  )
)
write_table(scope_check, file.path(audit_dir, "Williams\u6570\u636e\u8303\u56f4\u4e0eB\u56fe\u5206\u6bcd\u6821\u9a8c.csv"))

manifest <- list(
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  scope = list(Study = "Williams", disease = c("normal", "periodontitis"), samples = 21, cells = 66962, cell_types = 27),
  modifications = list(
    A = "Original Williams UMAP data and styling; title/subtitle removed only",
    B = "All 21 Williams samples aggregated by raw retained-cell counts into one 100% stacked bar; title/subtitle removed",
    C = "Original Williams canonical-marker DotPlot data and styling; title/subtitle and diagonal black frames removed"
  ),
  output_pdfs = c(path_A, path_B, path_C)
)
write_json_manifest(manifest, file.path(audit_dir, "\u6700\u7ec8\u7a3f_\u5206\u6790\u4e0e\u7ed8\u56fe\u6e05\u5355.json"))
write_session_info(file.path(audit_dir, "\u6700\u7ec8\u7a3f_R_sessionInfo.txt"))

message("FINAL_THREE_FIGURES_COMPLETE")
