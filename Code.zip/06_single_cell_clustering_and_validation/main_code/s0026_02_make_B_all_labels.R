options(stringsAsFactors = FALSE)
set.seed(42)

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(scales)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 4L) {
  stop("Four path arguments are required: input_csv, original_pdf, output_pdf, output_csv")
}
input_csv <- args[[1]]
original_pdf <- args[[2]]
output_pdf <- args[[3]]
output_csv <- args[[4]]

if (!file.exists(input_csv)) stop("Input table not found: ", input_csv)
if (!file.exists(original_pdf)) stop("Original PDF not found: ", original_pdf)
if (normalizePath(original_pdf, winslash = "/", mustWork = TRUE) ==
    normalizePath(output_pdf, winslash = "/", mustWork = FALSE)) {
  stop("Output path must not overwrite the original PDF")
}

reference_palette_9 <- c(
  "#D95F5F", "#7B61A8", "#E69F00", "#56B4E9", "#9C5D50",
  "#1F83B4", "#00A087", "#F4E43A", "#6A994E"
)

palette_n <- function(n) {
  if (n <= length(reference_palette_9)) return(reference_palette_9[seq_len(n)])
  grDevices::hcl.colors(n, palette = "Dynamic")
}

theme_submission <- function(base_size = 11) {
  theme_classic(base_size = base_size, base_family = "Arial") +
    theme(
      text = element_text(colour = "#1A1A1A"),
      axis.text = element_text(colour = "#333333"),
      legend.title = element_text(face = "bold"),
      legend.key = element_blank()
    )
}

composition <- fread(input_csv, encoding = "UTF-8")
required_columns <- c("cell_type_display", "N", "proportion")
if (!all(required_columns %in% names(composition))) {
  stop("Input table is missing required columns: ",
       paste(setdiff(required_columns, names(composition)), collapse = ", "))
}
if (nrow(composition) != 27L || uniqueN(composition$cell_type_display) != 27L) {
  stop("Expected exactly 27 unique cell types")
}
if (sum(composition$N) != 66962L) stop("Expected a Williams-only denominator of 66,962 cells")
if (abs(sum(composition$proportion) - 1) > 1e-12) stop("Cell-type proportions do not sum to 1")

cell_levels <- composition$cell_type_display
composition[, cell_type_display := factor(cell_type_display, levels = cell_levels)]
composition[, label_y := 1 - cumsum(proportion) + proportion / 2]
composition[, type_id := substr(as.character(cell_type_display), 1L, 2L)]
composition[, percent_label := fifelse(
  proportion < 0.001,
  percent(proportion, accuracy = 0.01),
  percent(proportion, accuracy = 0.1)
)]
composition[, label_mode := fifelse(proportion >= 0.03, "inside", "outside")]

major <- composition[label_mode == "inside"]
minor <- copy(composition[label_mode == "outside"])
setorder(minor, -label_y)
minor[, label_y_out := seq(0.36, 0.02, length.out = .N)]
minor[, outside_label := paste(type_id, percent_label)]
composition <- merge(
  composition,
  minor[, .(cell_type_display, label_y_out, outside_label)],
  by = "cell_type_display",
  all.x = TRUE,
  sort = FALSE
)
composition[, cell_type_display := factor(cell_type_display, levels = cell_levels)]

pal <- setNames(palette_n(length(cell_levels)), cell_levels)
bar_right <- 1.31
elbow_x <- 1.50
label_x <- 1.54

p <- ggplot(composition, aes(x = 1, y = proportion, fill = cell_type_display)) +
  geom_col(width = 0.62, colour = "white", linewidth = 0.35) +
  geom_text(
    data = major,
    aes(x = 1, y = label_y, label = percent_label),
    inherit.aes = FALSE,
    size = 3.1,
    colour = "#111111",
    fontface = "bold"
  ) +
  geom_segment(
    data = minor,
    aes(x = bar_right, xend = elbow_x, y = label_y, yend = label_y_out),
    inherit.aes = FALSE,
    linewidth = 0.32,
    colour = "#555555",
    lineend = "round"
  ) +
  geom_segment(
    data = minor,
    aes(x = elbow_x, xend = label_x - 0.015, y = label_y_out, yend = label_y_out),
    inherit.aes = FALSE,
    linewidth = 0.32,
    colour = "#555555",
    lineend = "round"
  ) +
  geom_text(
    data = minor,
    aes(x = label_x, y = label_y_out, label = outside_label),
    inherit.aes = FALSE,
    hjust = 0,
    size = 2.85,
    colour = "#111111",
    fontface = "bold"
  ) +
  scale_fill_manual(values = pal, drop = FALSE) +
  scale_x_continuous(
    limits = c(0.55, 2.05),
    breaks = 1,
    labels = "Williams",
    expand = expansion(mult = c(0, 0))
  ) +
  scale_y_continuous(
    labels = percent_format(accuracy = 1),
    breaks = seq(0, 1, 0.2),
    expand = expansion(mult = c(0, 0.01))
  ) +
  coord_cartesian(ylim = c(0, 1), clip = "off") +
  labs(x = NULL, y = "Proportion of retained cells", fill = "CELLxGENE cell type") +
  theme_submission(11) +
  theme(
    axis.text.x = element_text(face = "bold"),
    legend.position = "right",
    legend.text = element_text(size = 7.4),
    legend.key.height = grid::unit(0.34, "cm"),
    plot.margin = margin(6, 10, 6, 6)
  ) +
  guides(fill = guide_legend(ncol = 1))

dir.create(dirname(output_pdf), recursive = TRUE, showWarnings = FALSE)
ggsave(
  filename = output_pdf,
  plot = p,
  width = 13.5,
  height = 8.4,
  units = "in",
  device = grDevices::cairo_pdf,
  limitsize = FALSE
)

if (!file.exists(output_pdf) || file.info(output_pdf)$size < 5000) {
  stop("Output PDF was not created correctly: ", output_pdf)
}
fwrite(composition, output_csv)

cat("OUTPUT_PDF=", output_pdf, "\n", sep = "")
cat("TOTAL_N=", sum(composition$N), "\n", sep = "")
cat("PROPORTION_SUM=", format(sum(composition$proportion), digits = 16), "\n", sep = "")
cat("INSIDE_LABELS=", nrow(major), "\n", sep = "")
cat("OUTSIDE_LABELS=", nrow(minor), "\n", sep = "")
