options(stringsAsFactors = FALSE)

if (.Platform$OS.type == "windows") {
  try(Sys.setlocale("LC_ALL", "Chinese (Simplified)_China.utf8"), silent = TRUE)
}

.libPaths(c(
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library",
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_enrichment",
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_Seurat4",
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_raw",
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_drylab_20260904",
  "C:/Users/Lin/AppData/Local/R/win-library/4.5",
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_stage11",
  .libPaths()
))

suppressPackageStartupMessages({
  library(SeuratObject)
  library(Matrix)
  library(data.table)
  library(limma)
  library(AnnotationDbi)
  library(org.Hs.eg.db)
  library(GO.db)
  library(GSVA)
  library(fgsea)
  library(jsonlite)
})

set.seed(20260907L)

args <- commandArgs(trailingOnly = TRUE)
out_dir <- if (length(args) >= 1L) args[[1L]] else paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/",
  "20260907_\u56fe4_\u6210\u7ea4\u7ef4\u7ec6\u80de_\u7259\u5468\u708e_vs_\u5065\u5eb7_\u9664G\u5916_\u540c\u683c\u5f0f_\u4e0d\u8986\u76d6_v1"
)
source_dir <- file.path(out_dir, "02_source_data")
qa_dir <- file.path(out_dir, "03_QA")
dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(qa_dir, recursive = TRUE, showWarnings = FALSE)

fb_rds <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/05_\u5355\u7ec6\u80deRNA/\u6d3e\u751f\u8f93\u5165/GDF15_Figure1/input_fb/",
  "all_conditions_allStudies_CELLxGENE_direct_fibroblast_counts_only.rds"
)
cell_map_path <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/05_\u5355\u7ec6\u80deRNA/\u6d3e\u751f\u8f93\u5165/GDF15_Figure1/",
  "cell_cluster_mapping.csv.gz"
)
five_map_path <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/05_\u5355\u7ec6\u80deRNA/\u6d3e\u751f\u8f93\u5165/GDF15_Figure1/",
  "five_type_merge_mapping.csv"
)
umap_path <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u6280\u672f\u6821\u51c6_20260906_\u65e7\u6b63\u5f0fUMAP\u5750\u6807\u6062\u590d_\u975e\u7814\u7a76\u8f93\u5165/",
  "\u56db\u961f\u5217\u5386\u53f2\u6b63\u5f0fUMAP_\u4ec5\u7528\u4e8e\u5750\u6807\u6761\u7801\u6821\u51c6.csv.gz"
)
hallmark_gmt <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/05_\u5355\u7ec6\u80deRNA/gene_sets/",
  "MSigDB_Hallmark_2020.gmt"
)

required <- c(fb_rds, cell_map_path, five_map_path, umap_path, hallmark_gmt)
if (!all(file.exists(required))) {
  stop("Missing input(s):\n", paste(required[!file.exists(required)], collapse = "\n"))
}

five_order_long <- c(
  "Vascular-associated fibroblasts",
  "Immune-associated fibroblasts",
  "ECM remodeling-associated fibroblasts",
  "Pre-extracellular matrix-associated fibroblasts",
  "Matrix homeostasis-associated fibroblasts"
)
five_short <- c(
  "Vascular-associated fibroblasts" = "Vascular",
  "Immune-associated fibroblasts" = "Immune",
  "ECM remodeling-associated fibroblasts" = "ECM remodeling",
  "Pre-extracellular matrix-associated fibroblasts" = "Pre-extracellular matrix",
  "Matrix homeostasis-associated fibroblasts" = "Matrix homeostasis"
)

message("[1/7] Loading the frozen fibroblast object and audited mappings")
obj <- readRDS(fb_rds)
counts <- GetAssayData(obj, assay = "RNA", slot = "counts")
cell_map <- fread(cell_map_path)
five_map <- fread(five_map_path)
umap <- fread(umap_path)

if (ncol(counts) != 15371L || nrow(cell_map) != 15371L || nrow(umap) != 15371L) {
  stop("Expected 15,371 fibroblasts in the frozen all-condition object and maps")
}
if (anyDuplicated(colnames(counts)) || anyDuplicated(cell_map$cell_barcode) ||
    anyDuplicated(umap$cell_barcode)) {
  stop("Duplicate cell barcodes detected")
}

cell_meta <- merge(cell_map, five_map[, .(
  fb_id = original_fb_id, final_fibroblast_type
)], by = "fb_id", all.x = TRUE, sort = FALSE)
cell_meta <- merge(cell_meta, umap[, .(
  cell_barcode, UMAP_1, UMAP_2
)], by = "cell_barcode", all.x = TRUE, sort = FALSE)
cell_meta <- cell_meta[match(colnames(counts), cell_barcode)]
if (!identical(cell_meta$cell_barcode, colnames(counts)) ||
    anyNA(cell_meta$UMAP_1) || anyNA(cell_meta$UMAP_2)) {
  stop("Cell metadata failed to align to the count matrix")
}

keep <- cell_meta$disease %in% c("normal", "periodontitis") &
  !is.na(cell_meta$final_fibroblast_type) &
  nzchar(cell_meta$final_fibroblast_type) &
  cell_meta$final_fibroblast_type %in% five_order_long
cell_meta <- cell_meta[keep]
counts <- counts[, keep, drop = FALSE]
if (ncol(counts) != 15290L) stop("Expected 15,290 retained normal/periodontitis FB1-FB7 cells")

cell_meta[, fibroblast_type := unname(five_short[final_fibroblast_type])]
cell_meta[, fibroblast_type := factor(
  fibroblast_type, levels = unname(five_short[five_order_long])
)]
cell_meta[, disease_label := fifelse(
  disease == "normal", "Fibroblasts (Healthy)", "Fibroblasts (Periodontitis)"
)]
cell_meta[, disease_label := factor(
  disease_label,
  levels = c("Fibroblasts (Healthy)", "Fibroblasts (Periodontitis)")
)]

cell_library <- as.numeric(Matrix::colSums(counts))
gdf15_idx <- which(toupper(rownames(counts)) == "GDF15")
if (length(gdf15_idx) != 1L) stop("Expected exactly one GDF15 row")
cell_meta[, GDF15_log_normalized := log1p(
  as.numeric(counts[gdf15_idx, ]) / pmax(cell_library, 1) * 1e4
)]

fwrite(cell_meta[, .(
  cell_barcode, Study, sample_id, donor_id, disease, disease_label,
  fb_id, fibroblast_type, UMAP_1, UMAP_2, GDF15_log_normalized
)], file.path(source_dir, "01_cell_metadata_UMAP_GDF15.csv.gz"), bom = TRUE)

type_counts <- cell_meta[, .N, by = .(disease_label, fibroblast_type)]
type_counts[, disease_total := sum(N), by = disease_label]
type_counts[, percent_within_disease := 100 * N / disease_total]
type_counts[, type_total := sum(N), by = fibroblast_type]
type_counts[, percent_disease_within_type := 100 * N / type_total]
setorder(type_counts, disease_label, fibroblast_type)
fwrite(type_counts, file.path(source_dir, "02_fibroblast_type_by_disease_counts.csv"), bom = TRUE)

message("[2/7] Building donor-level pseudobulk expression")
donor_levels <- unique(cell_meta$donor_id)
donor_factor <- factor(cell_meta$donor_id, levels = donor_levels)
indicator <- sparseMatrix(
  i = seq_along(donor_factor), j = as.integer(donor_factor), x = 1,
  dims = c(length(donor_factor), length(donor_levels)),
  dimnames = list(cell_meta$cell_barcode, donor_levels)
)
pseudobulk_counts <- counts %*% indicator
donor_meta <- unique(cell_meta[, .(donor_id, Study, disease, disease_label)])
donor_meta <- donor_meta[match(colnames(pseudobulk_counts), donor_id)]
if (anyNA(donor_meta$donor_id) || nrow(donor_meta) != 30L) {
  stop("Expected 30 unique healthy/periodontitis donors")
}
lib_size <- as.numeric(Matrix::colSums(pseudobulk_counts))
cpm <- sweep(as.matrix(pseudobulk_counts), 2L, pmax(lib_size, 1), "/") * 1e6
log_cpm_all <- log2(cpm + 0.5)
colnames(log_cpm_all) <- donor_levels

tested <- rowSums(cpm >= 1) >= 3L
log_cpm <- log_cpm_all[tested, , drop = FALSE]
donor_meta[, disease_factor := factor(disease, levels = c("normal", "periodontitis"))]
donor_meta[, Study := factor(Study)]
design <- model.matrix(~ Study + disease_factor, data = donor_meta)
coef_name <- "disease_factorperiodontitis"
if (!coef_name %in% colnames(design)) stop("Disease coefficient is not estimable")
fit <- lmFit(log_cpm, design)
fit <- eBayes(fit, trend = TRUE, robust = TRUE)
de <- as.data.table(topTable(
  fit, coef = coef_name, number = Inf, sort.by = "none", adjust.method = "BH"
), keep.rownames = "gene")
setnames(de, c("logFC", "AveExpr", "t", "P.Value", "adj.P.Val", "B"),
         c("log2FC_periodontitis_minus_healthy", "mean_logCPM", "t_statistic",
           "p_value", "FDR", "B_statistic"))
setorder(de, p_value)
fwrite(de, file.path(source_dir, "03_donor_pseudobulk_DE_periodontitis_vs_healthy.csv.gz"), bom = TRUE)
fwrite(donor_meta[, .(donor_id, Study, disease, disease_label)],
       file.path(source_dir, "04_donor_metadata.csv"), bom = TRUE)

message("[3/7] Mapping tested genes to GO")
go_map <- suppressMessages(AnnotationDbi::select(
  org.Hs.eg.db,
  keys = unique(de$gene),
  keytype = "SYMBOL",
  columns = c("GOALL", "ONTOLOGYALL")
))
go_map <- as.data.table(go_map)
go_map <- unique(go_map[
  !is.na(GOALL) & ONTOLOGYALL %in% c("BP", "CC", "MF"),
  .(SYMBOL, GO = GOALL, ontology = ONTOLOGYALL)
])
term_ids <- unique(go_map$GO)
term_names <- AnnotationDbi::Term(GO.db::GOTERM[term_ids])
term_lookup <- data.table(GO = names(term_names), Description = unname(term_names))
go_map <- merge(go_map, term_lookup, by = "GO", all.x = TRUE, sort = FALSE)
go_map <- go_map[!is.na(Description) & nzchar(Description)]

choose_direction_genes <- function(direction) {
  if (direction == "periodontitis") {
    direction_ok <- de$log2FC_periodontitis_minus_healthy > 0
  } else {
    direction_ok <- de$log2FC_periodontitis_minus_healthy < 0
  }
  rules <- list(
    list(name = "FDR<0.05 and |log2FC|>=0.25",
         keep = direction_ok & de$FDR < 0.05 & abs(de$log2FC_periodontitis_minus_healthy) >= 0.25),
    list(name = "raw P<0.05 and |log2FC|>=0.25",
         keep = direction_ok & de$p_value < 0.05 & abs(de$log2FC_periodontitis_minus_healthy) >= 0.25),
    list(name = "top 250 direction-consistent genes by raw P",
         keep = direction_ok)
  )
  for (i in seq_along(rules)) {
    idx <- which(rules[[i]]$keep)
    if (i == length(rules)) idx <- head(idx[order(de$p_value[idx])], 250L)
    if (length(idx) >= 50L || i == length(rules)) {
      return(list(genes = unique(de$gene[idx]), rule = rules[[i]]$name, n = length(idx)))
    }
  }
}

run_ora <- function(selected_symbols, ontology, group_name, rule_name) {
  ontology_value <- ontology
  gm <- go_map[ontology == ontology_value]
  universe <- intersect(unique(de$gene), unique(gm$SYMBOL))
  selected <- intersect(unique(selected_symbols), universe)
  if (length(selected) < 5L) stop("Too few mapped selected genes for ", group_name, " ", ontology)
  sizes <- gm[SYMBOL %in% universe, .(set_size = uniqueN(SYMBOL)), by = .(GO, Description)]
  hits <- gm[SYMBOL %in% selected, .(
    Count = uniqueN(SYMBOL),
    genes = paste(sort(unique(SYMBOL)), collapse = ";")
  ), by = .(GO, Description)]
  ans <- merge(sizes, hits, by = c("GO", "Description"), all.x = TRUE)
  ans[is.na(Count), Count := 0L]
  ans[is.na(genes), genes := ""]
  ans <- ans[set_size >= 10L & set_size <= 500L & Count > 0L]
  ans[, p_value := phyper(
    Count - 1L, set_size, length(universe) - set_size, length(selected),
    lower.tail = FALSE
  )]
  ans[, FDR := p.adjust(p_value, method = "BH")]
  ans[, `:=`(
    ontology = ontology,
    group = group_name,
    selection_rule = rule_name,
    selected_gene_n = length(selected),
    universe_gene_n = length(universe),
    GeneRatio = paste0(Count, "/", length(selected)),
    ratio = Count / length(selected),
    log10pvalue = log10(pmax(p_value, .Machine$double.xmin))
  )]
  setorder(ans, FDR, p_value, -Count)
  ans[]
}

healthy_selection <- choose_direction_genes("healthy")
periodontitis_selection <- choose_direction_genes("periodontitis")
selection_audit <- data.table(
  group = c("Fibroblasts (Healthy)", "Fibroblasts (Periodontitis)"),
  selection_rule = c(healthy_selection$rule, periodontitis_selection$rule),
  selected_gene_n = c(healthy_selection$n, periodontitis_selection$n)
)
fwrite(selection_audit, file.path(source_dir, "05_DE_gene_selection_for_enrichment.csv"), bom = TRUE)

message("[4/7] Computing directional GO over-representation")
ora_healthy <- rbindlist(lapply(c("BP", "CC", "MF"), function(ont) {
  run_ora(healthy_selection$genes, ont, "Fibroblasts (Healthy)", healthy_selection$rule)
}))
ora_periodontitis <- rbindlist(lapply(c("BP", "CC", "MF"), function(ont) {
  run_ora(periodontitis_selection$genes, ont, "Fibroblasts (Periodontitis)", periodontitis_selection$rule)
}))
ora_all <- rbindlist(list(ora_healthy, ora_periodontitis), use.names = TRUE)
fwrite(ora_all, file.path(source_dir, "06_GO_ORA_all_directions.csv.gz"), bom = TRUE)

c_selected <- rbindlist(list(
  head(ora_healthy[ontology == "BP"], 5L),
  head(ora_periodontitis[ontology == "BP"], 5L)
), use.names = TRUE)
c_selected[, within_group_rank := seq_len(.N), by = group]
c_selected[, term_key := paste(group, GO, sep = "__")]
setorder(c_selected, group, within_group_rank)
fwrite(c_selected, file.path(source_dir, "07_C_diagonal_GO_selected.csv"), bom = TRUE)

message("[5/7] Computing donor-level Hallmark GSVA")
read_gmt <- function(path) {
  lines <- readLines(path, warn = FALSE, encoding = "UTF-8")
  parts <- strsplit(lines, "\t", fixed = TRUE)
  sets <- lapply(parts, function(x) unique(x[seq.int(3L, length(x))]))
  names(sets) <- vapply(parts, `[[`, character(1), 1L)
  sets
}
hallmark_sets <- read_gmt(hallmark_gmt)
hallmark_order <- c(
  "Epithelial Mesenchymal Transition",
  "TGF-beta Signaling",
  "TNF-alpha Signaling via NF-kB",
  "Angiogenesis",
  "Inflammatory Response",
  "Hypoxia",
  "KRAS Signaling Up",
  "IL-6/JAK/STAT3 Signaling",
  "Reactive Oxygen Species Pathway",
  "Coagulation"
)
missing_sets <- setdiff(hallmark_order, names(hallmark_sets))
if (length(missing_sets)) stop("Missing Hallmark sets: ", paste(missing_sets, collapse = ", "))
hallmark_sets <- hallmark_sets[hallmark_order]
hallmark_sets <- lapply(hallmark_sets, intersect, rownames(log_cpm_all))
param <- gsvaParam(
  exprData = log_cpm_all,
  geneSets = hallmark_sets,
  minSize = 10L,
  maxSize = 500L,
  kcdf = "Gaussian",
  sparse = FALSE
)
gsva_raw <- gsva(param, verbose = FALSE)
gsva_centered <- t(apply(gsva_raw, 1L, function(x) x - median(x, na.rm = TRUE)))
gsva_centered[gsva_centered > 0.5] <- 0.5
gsva_centered[gsva_centered < -0.5] <- -0.5

gsva_long <- data.table(
  pathway = rep(rownames(gsva_centered), times = ncol(gsva_centered)),
  donor_id = rep(colnames(gsva_centered), each = nrow(gsva_centered)),
  GSVA_score = as.numeric(gsva_centered)
)
gsva_long <- merge(
  gsva_long,
  donor_meta[, .(donor_id, Study, disease, disease_label)],
  by = "donor_id", all.x = TRUE, sort = FALSE
)
gsva_long[, pathway := factor(pathway, levels = hallmark_order)]
setorder(gsva_long, pathway, disease_label, donor_id)
fwrite(gsva_long, file.path(source_dir, "08_H_Hallmark_GSVA_scores.csv"), bom = TRUE)

gsva_stats <- rbindlist(lapply(hallmark_order, function(pathway_name) {
  z <- gsva_long[pathway == pathway_name]
  z[, disease_factor := factor(disease, levels = c("normal", "periodontitis"))]
  z[, Study := factor(Study)]
  model <- lm(GSVA_score ~ Study + disease_factor, data = z)
  co <- coef(summary(model))["disease_factorperiodontitis", ]
  data.table(
    pathway = pathway_name,
    difference_periodontitis_minus_healthy = unname(co[["Estimate"]]),
    t_statistic = unname(co[["t value"]]),
    p_value = unname(co[["Pr(>|t|)"]])
  )
}))
gsva_stats[, FDR := p.adjust(p_value, "BH")]
fwrite(gsva_stats, file.path(source_dir, "09_H_Hallmark_GSVA_group_statistics.csv"), bom = TRUE)

message("[6/7] Computing selected-term GO GSEA for panel I")
i_selected <- rbindlist(lapply(c("BP", "CC", "MF"), function(ont) {
  head(ora_periodontitis[ontology == ont], 5L)
}), use.names = TRUE)
i_selected[, display_order := seq_len(.N)]
selected_go_ids <- unique(i_selected$GO)
stats_vector <- de$t_statistic
names(stats_vector) <- de$gene
stats_vector <- stats_vector[is.finite(stats_vector)]
stats_vector <- sort(stats_vector[!duplicated(names(stats_vector))], decreasing = TRUE)
pathways <- split(
  go_map[GO %in% selected_go_ids & SYMBOL %in% names(stats_vector), SYMBOL],
  go_map[GO %in% selected_go_ids & SYMBOL %in% names(stats_vector), GO]
)
pathways <- lapply(pathways, unique)
gsea <- suppressWarnings(fgseaMultilevel(
  pathways = pathways,
  stats = stats_vector,
  minSize = 10L,
  maxSize = 500L,
  eps = 0,
  nproc = 1L
))
gsea <- as.data.table(gsea)
if (nrow(gsea)) {
  gsea[, leadingEdge := vapply(leadingEdge, paste, collapse = ";", character(1))]
  setnames(gsea, "pathway", "GO")
}
i_selected <- merge(
  i_selected,
  gsea[, .(GO, ES, NES, gsea_p_value = pval, gsea_FDR = padj, leadingEdge)],
  by = "GO", all.x = TRUE, sort = FALSE
)
setorder(i_selected, display_order)
fwrite(i_selected, file.path(source_dir, "10_I_GO_ORA_and_GSEA_selected.csv"), bom = TRUE)

message("[7/7] Writing audit and QA tables")
counts_by_disease <- cell_meta[, .N, by = disease]
counts_by_study_disease <- cell_meta[, .N, by = .(Study, disease)]
donors_by_study_disease <- unique(cell_meta[, .(Study, disease, donor_id)])[, .N, by = .(Study, disease)]
qa <- data.table(
  check = c(
    "Frozen full fibroblast input has 15,371 cells",
    "Retained normal/periodontitis FB1-FB7 cells equal 15,290",
    "Gingivitis excluded",
    "FB8 excluded",
    "Both disease groups present",
    "Five fibroblast types present in both groups",
    "Thirty unique donors retained",
    "GDF15 expression finite",
    "Ten C-panel GO rows selected",
    "Ten Hallmark pathways scored",
    "Fifteen I-panel GO rows selected",
    "Disease coefficient estimable"
  ),
  value = c(
    ncol(obj), nrow(cell_meta), sum(cell_meta$disease == "gingivitis"),
    sum(cell_meta$fb_id == "FB8"), uniqueN(cell_meta$disease),
    min(type_counts[, uniqueN(fibroblast_type), by = disease_label]$V1),
    uniqueN(cell_meta$donor_id), all(is.finite(cell_meta$GDF15_log_normalized)),
    nrow(c_selected), nrow(gsva_centered), nrow(i_selected), coef_name %in% colnames(design)
  ),
  pass = c(
    ncol(obj) == 15371L, nrow(cell_meta) == 15290L,
    !any(cell_meta$disease == "gingivitis"), !any(cell_meta$fb_id == "FB8"),
    uniqueN(cell_meta$disease) == 2L,
    min(type_counts[, uniqueN(fibroblast_type), by = disease_label]$V1) == 5L,
    uniqueN(cell_meta$donor_id) == 30L,
    all(is.finite(cell_meta$GDF15_log_normalized)),
    nrow(c_selected) == 10L, nrow(gsva_centered) == 10L,
    nrow(i_selected) == 15L, coef_name %in% colnames(design)
  )
)
fwrite(qa, file.path(qa_dir, "01_analysis_QA.csv"), bom = TRUE)
fwrite(counts_by_disease, file.path(qa_dir, "02_cell_counts_by_disease.csv"), bom = TRUE)
fwrite(counts_by_study_disease, file.path(qa_dir, "03_cell_counts_by_study_disease.csv"), bom = TRUE)
fwrite(donors_by_study_disease, file.path(qa_dir, "04_donor_counts_by_study_disease.csv"), bom = TRUE)

contract <- list(
  created_at = format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE),
  purpose = "Condition-comparison companion to the existing Figure 4 A-I panel set; G intentionally excluded",
  retained_cells = nrow(cell_meta),
  retained_diseases = c("normal", "periodontitis"),
  excluded = c("gingivitis", "FB8"),
  frozen_five_type_mapping = "FB3+FB7=Vascular; FB1+FB4=Immune; FB2=ECM remodeling; FB6=Pre-ECM; FB5=Matrix homeostasis; FB8 excluded",
  umap = "Previously reconstructed project UMAP coordinates; coordinates are not altered; visual limits match the submitted panel",
  differential_expression = "Donor-level pseudobulk log2(CPM+0.5), linear model expression ~ Study + disease, limma empirical Bayes with trend and robust moderation",
  contrast = "periodontitis minus healthy",
  go_ora = "Hypergeometric GO over-representation against tested gene universe; BH correction within direction and ontology; 10<=set size<=500",
  enrichment_gene_selection = as.list(selection_audit),
  gsva = "Donor-level Hallmark GSVA; per-pathway median centering; values clipped to -0.5..0.5 only for the reference-matched display",
  gsea = "fgseaMultilevel on donor-pseudobulk limma t statistics for the 15 displayed GO terms",
  source_paths = required,
  original_reference_pdfs = c(
    "C:/Users/Lin/Desktop/\u6700\u7ec8\u6295\u7a3f\u6587\u672c/\u6b63\u6587\u56fe/\u6b63\u6587\u56fe4 sc-RNA/A.5\u79cd\u7ec6\u80de\u5206\u7c7b\u5730\u56fe.pdf",
    "C:/Users/Lin/Desktop/\u6700\u7ec8\u6295\u7a3f\u6587\u672c/\u6b63\u6587\u56fe/\u6b63\u6587\u56fe4 sc-RNA/B.5\u79cd\u7ec6\u80de\u5806\u79ef\u67f1\u72b6\u56fe.pdf",
    "C:/Users/Lin/Desktop/\u6700\u7ec8\u6295\u7a3f\u6587\u672c/\u6b63\u6587\u56fe/\u6b63\u6587\u56fe4 sc-RNA/C.5\u79cd\u7ec6\u80de\u7684\u5bf9\u89d2\u7ebfGO\u56fe.pdf",
    "C:/Users/Lin/Desktop/\u6700\u7ec8\u6295\u7a3f\u6587\u672c/\u6b63\u6587\u56fe/\u6b63\u6587\u56fe4 sc-RNA/D.scissors\u9634\u6027\u9633\u6027\u5730\u56fe.pdf",
    "C:/Users/Lin/Desktop/\u6700\u7ec8\u6295\u7a3f\u6587\u672c/\u6b63\u6587\u56fe/\u6b63\u6587\u56fe4 sc-RNA/E.scissors\u9634\u6027\u9633\u6027\u6bd4\u4f8b.pdf",
    "C:/Users/Lin/Desktop/\u6700\u7ec8\u6295\u7a3f\u6587\u672c/\u6b63\u6587\u56fe/\u6b63\u6587\u56fe4 sc-RNA/F.GDF15\u5728\u5404\u4e2a\u7ec6\u80de\u4e2d\u7684\u8868\u8fbe\u5730\u56fe.pdf",
    "C:/Users/Lin/Desktop/\u6700\u7ec8\u6295\u7a3f\u6587\u672c/\u6b63\u6587\u56fe/\u6b63\u6587\u56fe4 sc-RNA/H.GSVA.pdf",
    "C:/Users/Lin/Desktop/\u6700\u7ec8\u6295\u7a3f\u6587\u672c/\u6b63\u6587\u56fe/\u6b63\u6587\u56fe4 sc-RNA/I.\u5168\u90e8\u6210\u7ea4\u7ef4\u7ec6\u80de_Scissor+\u5dee\u5f02\u57fa\u56e0_GO\u5bcc\u96c6\u4e0eNES\u80cc\u5bf9\u80cc\u56fe_\u7d27\u51d1\u53bb\u6807\u9898\u6ce8\u91ca\u7248.pdf"
  )
)
writeLines(toJSON(contract, auto_unbox = TRUE, pretty = TRUE, null = "null"),
           file.path(source_dir, "11_analysis_contract.json"), useBytes = TRUE)
writeLines(capture.output(sessionInfo()), file.path(source_dir, "R_sessionInfo.txt"), useBytes = TRUE)

if (!all(qa$pass)) stop("Analysis QA failed: ", paste(qa[pass == FALSE, check], collapse = "; "))
message("Prepared all condition-comparison source tables: ", out_dir)
