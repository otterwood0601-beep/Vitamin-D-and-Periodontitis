options(stringsAsFactors = FALSE)

args <- commandArgs(trailingOnly = TRUE)
out_dir <- if (length(args) >= 1L) args[[1L]] else file.path(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/04_\u5355\u7ec6\u80de",
  "20260822_GDF15\u5065\u5eb7vs\u7259\u5468\u708e_\u4e94\u7c7b\u6210\u7ea4\u7ef4\u7ec6\u80de\u8868\u8fbe_\u5206\u88c2\u5c0f\u63d0\u7434_v1"
)
fb_rds_path <- if (length(args) >= 2L) args[[2L]] else paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/05_\u5355\u7ec6\u80deRNA/\u6d3e\u751f\u8f93\u5165/GDF15_Figure1/input_fb/",
  "all_conditions_allStudies_CELLxGENE_direct_fibroblast_counts_only.rds"
)
cell_map_path <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/05_\u5355\u7ec6\u80deRNA/\u6d3e\u751f\u8f93\u5165/GDF15_Figure1/cell_cluster_mapping.csv.gz"
merge_map_path <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/05_\u5355\u7ec6\u80deRNA/\u6d3e\u751f\u8f93\u5165/GDF15_Figure1/five_type_merge_mapping.csv"

.libPaths(c(
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_Seurat4",
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_stage11",
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library",
  .libPaths()
))
suppressPackageStartupMessages({
  library(data.table)
  library(SeuratObject)
  library(Matrix)
  library(jsonlite)
  library(ragg)
})

source_dir <- file.path(out_dir, "01_source_data_and_audit")
qa_dir <- file.path(out_dir, "03_QA")
dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(qa_dir, recursive = TRUE, showWarnings = FALSE)

inputs <- c(fb_rds_path, cell_map_path, merge_map_path)
if (!all(file.exists(inputs))) {
  stop("Missing input(s):\n", paste(inputs[!file.exists(inputs)], collapse = "\n"))
}

five_order <- c(
  "Vascular-associated fibroblasts",
  "Immune-associated fibroblasts",
  "ECM remodeling-associated fibroblasts",
  "Pre-extracellular matrix-associated fibroblasts",
  "Matrix homeostasis-associated fibroblasts"
)
five_short <- c(
  "Vascular-associated fibroblasts" = "Vascular",
  "Immune-associated fibroblasts" = "Immune",
  "ECM remodeling-associated fibroblasts" = "ECM remodeling",
  "Pre-extracellular matrix-associated fibroblasts" = "Pre-ECM",
  "Matrix homeostasis-associated fibroblasts" = "Matrix homeostasis"
)

expression_cache <- file.path(source_dir, "01_donor_subtype_GDF15_scale_data.csv")
stats_cache <- file.path(source_dir, "02_GDF15_healthy_vs_periodontitis_five_FB_Zscore_statistics.csv")
reuse_cache <- identical(Sys.getenv("GDF15_REUSE_CACHE"), "1") &&
  file.exists(expression_cache) && file.exists(stats_cache)

if (reuse_cache) {
  message("Reusing validated donor-level source tables for rendering")
  analysis_data <- fread(expression_cache, data.table = FALSE)
  stats <- fread(stats_cache, data.table = FALSE)
  stats$significance <- as.character(cut(
    stats$study_adjusted_p_value,
    breaks = c(-Inf, 0.001, 0.01, 0.05, Inf),
    labels = c("***", "**", "*", "ns"),
    right = FALSE
  ))
  fwrite(stats, stats_cache)
  minimum_cells_per_donor_subtype <- 10L
  total_fibroblast_cells <- 15371L
  retained_fibroblast_cells <- 15313L
} else {
  fb_obj <- readRDS(fb_rds_path)
  fb_counts <- LayerData(fb_obj, assay = "RNA", layer = "counts")
  total_fibroblast_cells <- ncol(fb_counts)

  cell_map <- fread(cell_map_path)
  merge_map <- fread(merge_map_path)
  cell_map <- merge(
    cell_map,
    merge_map[, .(
      fb_id = original_fb_id,
      final_fibroblast_type
    )],
    by = "fb_id",
    all.x = TRUE,
    sort = FALSE
  )
  index <- match(colnames(fb_counts), cell_map$cell_barcode)
  if (sum(!is.na(index)) != ncol(fb_counts)) {
    stop("Some fibroblast cells lack mapping rows")
  }
  cell_info <- cell_map[index, ]

  keep_cell <- !is.na(cell_info$final_fibroblast_type) &
    nzchar(cell_info$final_fibroblast_type) &
    cell_info$final_fibroblast_type %in% five_order
  fb_counts <- fb_counts[, keep_cell, drop = FALSE]
  cell_info <- cell_info[keep_cell, ]
  retained_fibroblast_cells <- ncol(fb_counts)

  gdf15_index <- which(toupper(rownames(fb_counts)) == "GDF15")
  if (length(gdf15_index) != 1L) stop("Expected exactly one GDF15 row")

  group <- paste(
    cell_info$donor_id,
    cell_info$disease,
    cell_info$Study,
    cell_info$final_fibroblast_type,
    sep = "||"
  )
  group_levels <- unique(group)
  group_code <- match(group, group_levels)
  indicator <- sparseMatrix(
    i = group_code,
    j = seq_along(group_code),
    x = 1,
    dims = c(length(group_levels), length(group_code)),
    giveCsparse = TRUE
  )

  group_parts <- do.call(rbind, strsplit(group_levels, "\\|\\|"))
  n_cells_by_group <- tabulate(group_code, nbins = length(group_levels))
  cell_library <- as.numeric(Matrix::colSums(fb_counts))
  cell_library_safe <- pmax(cell_library, 1)
  GDF15_cell_counts <- as.numeric(fb_counts[gdf15_index, ])
  GDF15_cell_log_normalized <- log1p(
    GDF15_cell_counts / cell_library_safe * 1e4
  )
  scale_center <- mean(GDF15_cell_log_normalized)
  scale_sd <- sd(GDF15_cell_log_normalized)
  if (!is.finite(scale_sd) || scale_sd <= 0) stop("GDF15 scale SD is invalid")
  scale_clip <- 10
  GDF15_cell_scale_data <- (
    GDF15_cell_log_normalized - scale_center
  ) / scale_sd
  GDF15_cell_scale_data <- pmax(
    -scale_clip,
    pmin(scale_clip, GDF15_cell_scale_data)
  )

  donor_expression_all <- data.frame(
    donor_id = group_parts[, 1L],
    disease = group_parts[, 2L],
    study = group_parts[, 3L],
    fibroblast_type = group_parts[, 4L],
    n_cells = n_cells_by_group,
    GDF15_total_counts = as.numeric(
      indicator %*% GDF15_cell_counts
    ),
    total_raw_counts = as.numeric(
      indicator %*% cell_library
    ),
    GDF15_mean_log_normalized = as.numeric(
      indicator %*% GDF15_cell_log_normalized
    ) / n_cells_by_group,
    GDF15_mean_Z_score = as.numeric(
      indicator %*% GDF15_cell_scale_data
    ) / n_cells_by_group,
    GDF15_detected_fraction = as.numeric(
      indicator %*% as.numeric(GDF15_cell_counts > 0)
    ) / n_cells_by_group,
    stringsAsFactors = FALSE
  )
  donor_expression_all$GDF15_scale_center <- scale_center
  donor_expression_all$GDF15_scale_sd <- scale_sd
  donor_expression_all$GDF15_scale_clip <- scale_clip

  minimum_cells_per_donor_subtype <- 10L
  analysis_data <- subset(
    donor_expression_all,
    disease %in% c("normal", "periodontitis") &
      n_cells >= minimum_cells_per_donor_subtype &
      fibroblast_type %in% five_order
  )
  analysis_data$disease_label <- ifelse(
    analysis_data$disease == "normal", "Healthy", "Periodontitis"
  )
  analysis_data$fibroblast_type <- factor(
    analysis_data$fibroblast_type,
    levels = five_order
  )
  analysis_data <- analysis_data[order(
    analysis_data$fibroblast_type,
    analysis_data$disease_label,
    analysis_data$donor_id
  ), ]

  fit_one_type <- function(cell_type_name) {
    z <- analysis_data[
      as.character(analysis_data$fibroblast_type) == cell_type_name,
      ,
      drop = FALSE
    ]
    z$disease <- factor(z$disease, levels = c("normal", "periodontitis"))
    z$study <- droplevels(factor(z$study))
    healthy_values <- z$GDF15_mean_Z_score[z$disease == "normal"]
    periodontitis_values <- z$GDF15_mean_Z_score[
      z$disease == "periodontitis"
    ]
    if (length(healthy_values) < 3L || length(periodontitis_values) < 3L) {
      stop("Insufficient donor support for ", cell_type_name)
    }

    fit <- lm(GDF15_mean_Z_score ~ disease + study, data = z)
    coef_table <- coef(summary(fit))
    term <- "diseaseperiodontitis"
    if (!(term %in% rownames(coef_table))) {
      stop("Disease coefficient not estimable for ", cell_type_name)
    }
    ci <- suppressMessages(confint(fit, term, level = 0.95))
    wilcox_p <- suppressWarnings(
      wilcox.test(
        periodontitis_values,
        healthy_values,
        alternative = "two.sided"
      )$p.value
    )

    data.frame(
      fibroblast_type = cell_type_name,
      healthy_n_donors = length(healthy_values),
      periodontitis_n_donors = length(periodontitis_values),
      healthy_n_cells = sum(z$n_cells[z$disease == "normal"]),
      periodontitis_n_cells = sum(z$n_cells[z$disease == "periodontitis"]),
      healthy_median_Z_score = median(healthy_values),
      periodontitis_median_Z_score = median(periodontitis_values),
      raw_median_Z_difference_periodontitis_minus_healthy =
        median(periodontitis_values) - median(healthy_values),
      study_adjusted_Z_difference = coef_table[term, "Estimate"],
      study_adjusted_CI_low = ci[[1L]],
      study_adjusted_CI_high = ci[[2L]],
      study_adjusted_p_value = coef_table[term, "Pr(>|t|)"],
      unadjusted_two_sided_Wilcoxon_p = wilcox_p,
      stringsAsFactors = FALSE
    )
  }

  stats <- do.call(rbind, lapply(five_order, fit_one_type))
  stats$BH_FDR_over_five_subtypes <- p.adjust(
    stats$study_adjusted_p_value,
    method = "BH"
  )
  stats$direction <- ifelse(
    stats$study_adjusted_Z_difference > 0,
    "Higher in periodontitis",
    "Lower in periodontitis"
  )
  stats$significance <- cut(
    stats$study_adjusted_p_value,
    breaks = c(-Inf, 0.001, 0.01, 0.05, Inf),
    labels = c("***", "**", "*", "ns"),
    right = FALSE
  )

  fwrite(analysis_data, expression_cache)
  fwrite(stats, stats_cache)

  group_counts <- stats[, c(
    "fibroblast_type",
    "healthy_n_donors",
    "periodontitis_n_donors",
    "healthy_n_cells",
    "periodontitis_n_cells"
  )]
  fwrite(
    group_counts,
    file.path(source_dir, "03_subtype_donor_and_cell_counts.csv")
  )

  mapping_audit <- merge_map[, .(
    original_fb_id,
    action,
    final_fibroblast_type
  )]
  fwrite(
    mapping_audit,
    file.path(source_dir, "04_five_type_mapping_used.csv")
  )

  donor_metadata <- unique(cell_info[, .(donor_id, disease, Study)])
  donor_metadata <- donor_metadata[order(Study, disease, donor_id)]
  fwrite(
    donor_metadata,
    file.path(source_dir, "05_fibroblast_donor_metadata.csv")
  )

  parameters <- list(
    generated_at = format(Sys.time(), tz = "Asia/Shanghai", usetz = TRUE),
    input_fibroblast_rds = fb_rds_path,
    cell_mapping = cell_map_path,
    five_type_mapping = merge_map_path,
    total_fibroblast_cells_before_FB8_removal = total_fibroblast_cells,
    retained_fibroblast_cells = retained_fibroblast_cells,
    included_diseases = c("normal", "periodontitis"),
    excluded_disease = "gingivitis",
    analysis_unit = "donor x fibroblast subtype mean of cell-level GDF15 scale.data",
    expression_unit = "GDF15 Z-score (Seurat-equivalent scale.data)",
    cell_normalization = "log1p(raw GDF15 count / cell library size * 10000)",
    scale_center_across_retained_fibroblast_cells = scale_center,
    scale_sd_across_retained_fibroblast_cells = scale_sd,
    scale_clip = c(-scale_clip, scale_clip),
    minimum_cells_per_donor_subtype = minimum_cells_per_donor_subtype,
    fibroblast_type_order = five_order,
    model = "OLS per subtype: expression ~ disease + study",
    contrast = "periodontitis - normal",
    multiple_testing = "Benjamini-Hochberg across five fibroblast subtypes",
    plot_stars = "Raw P values from study-corrected models; no multiplicity adjustment",
    visual_y_axis_minimum = -1,
    visual_y_axis_maximum = 1
  )
  write_json(
    parameters,
    file.path(source_dir, "06_analysis_parameters.json"),
    pretty = TRUE,
    auto_unbox = TRUE
  )
}

parameter_path <- file.path(source_dir, "06_analysis_parameters.json")
if (file.exists(parameter_path)) {
  display_parameters <- fromJSON(parameter_path, simplifyVector = FALSE)
  display_parameters$plot_stars <-
    "Raw P values from study-corrected models; no multiplicity adjustment"
  display_parameters$visual_y_axis_minimum <- -1
  display_parameters$visual_y_axis_maximum <- 1
  write_json(
    display_parameters,
    parameter_path,
    pretty = TRUE,
    auto_unbox = TRUE
  )
}

healthy_color <- "#F07A73"
periodontitis_color <- "#55BBD8"
visual_y_minimum <- -1
visual_y_maximum <- 1

draw_half_violin <- function(values, position, side, color, width = 0.38) {
  values <- values[is.finite(values)]
  if (length(values) < 2L) return(invisible(NULL))
  if (sd(values) < 1e-10) {
    y <- seq(values[[1L]] - 0.02, values[[1L]] + 0.02, length.out = 100L)
    density_values <- rep(1, length(y))
  } else {
    den <- density(
      values,
      n = 256L,
      bw = "nrd0",
      from = min(values),
      to = max(values)
    )
    y <- den$x
    density_values <- den$y
  }
  density_values <- density_values / max(density_values) * width
  x <- if (side == "left") position - density_values else position + density_values
  polygon(
    x = c(rep(position, length(y)), rev(x)),
    y = c(y, rev(y)),
    col = color,
    border = "black",
    lwd = 0.7
  )
  quartiles <- quantile(values, c(0.25, 0.5, 0.75), names = FALSE)
  offset <- if (side == "left") -0.08 else 0.08
  segments(
    position + offset,
    quartiles[[1L]],
    position + offset,
    quartiles[[3L]],
    lwd = 2.4,
    col = "black"
  )
  segments(
    position + offset - 0.035,
    quartiles[[2L]],
    position + offset + 0.035,
    quartiles[[2L]],
    lwd = 3.0,
    col = "black"
  )
}

draw_figure <- function() {
  old_par <- par(no.readonly = TRUE)
  on.exit(par(old_par), add = TRUE)
  par(
    mar = c(9.2, 5.5, 5.6, 5.2),
    mgp = c(3.3, 0.85, 0),
    las = 1,
    family = "sans",
    xpd = NA
  )

  x_positions <- seq_along(five_order)
  value_range <- range(analysis_data$GDF15_mean_Z_score, finite = TRUE)
  y_padding <- max(diff(value_range) * 0.14, 0.3)
  y_limits <- c(visual_y_minimum, visual_y_maximum)

  plot(
    NA,
    xlim = c(0.35, length(five_order) + 1.45),
    ylim = y_limits,
    yaxs = "i",
    axes = FALSE,
    xlab = "",
    ylab = "GDF15 expression Z-score (scale.data)",
    cex.lab = 1.05
  )
  mtext(
    "GDF15 expression across five fibroblast types",
    side = 3,
    line = 3.0,
    cex = 1.15,
    font = 2
  )
  mtext(
    "Healthy vs periodontitis; donor mean of cell-level scale.data; study-adjusted raw P",
    side = 3,
    line = 1.6,
    cex = 0.84,
    col = "#444444"
  )

  grid_y <- pretty(y_limits, n = 6L)
  grid_y <- grid_y[grid_y >= visual_y_minimum & grid_y <= y_limits[[2L]]]
  grid_y <- sort(unique(c(visual_y_minimum, grid_y)))
  abline(h = grid_y, col = "#DFDFDF", lwd = 1.0)
  axis(
    2,
    at = grid_y,
    labels = format(grid_y, trim = TRUE),
    lwd = 1.6,
    lwd.ticks = 1.2,
    cex.axis = 0.88
  )
  axis(1, at = x_positions, labels = FALSE, lwd = 1.6, lwd.ticks = 1.2)

  x_labels <- character(length(five_order))
  for (i in seq_along(five_order)) {
    type_name <- five_order[[i]]
    z <- analysis_data[
      as.character(analysis_data$fibroblast_type) == type_name,
      ,
      drop = FALSE
    ]
    healthy <- z$GDF15_mean_Z_score[z$disease_label == "Healthy"]
    periodontitis <- z$GDF15_mean_Z_score[
      z$disease_label == "Periodontitis"
    ]
    draw_half_violin(healthy, i, "left", healthy_color)
    draw_half_violin(periodontitis, i, "right", periodontitis_color)
    annotation_y <- max(c(healthy, periodontitis), na.rm = TRUE) +
      0.035 * diff(y_limits)
    text(
      i,
      annotation_y,
      as.character(stats$significance[[i]]),
      cex = 0.88,
      font = 2
    )
    x_labels[[i]] <- paste0(
      five_short[[type_name]],
      "\nH", stats$healthy_n_donors[[i]],
      " / P", stats$periodontitis_n_donors[[i]]
    )
  }

  text(
    x_positions,
    par("usr")[[3L]] - 0.045 * diff(par("usr")[3:4]),
    labels = x_labels,
    srt = 42,
    adj = 1,
    cex = 0.82
  )
  box(bty = "l", lwd = 1.6)
  mtext(
    "(E)",
    side = 3,
    line = 2.0,
    at = par("usr")[[1L]] - 0.28,
    adj = 0,
    cex = 1.35,
    font = 2
  )
  legend(
    x = length(five_order) + 0.70,
    y = mean(y_limits),
    legend = c("Healthy", "Periodontitis"),
    fill = c(healthy_color, periodontitis_color),
    border = NA,
    title = "Groups",
    bty = "n",
    cex = 0.9,
    xpd = NA
  )
  mtext(
    paste0(
      "Source: integrated periodontal CELLxGENE fibroblast counts; ",
      retained_fibroblast_cells,
      " cells after FB8 removal. H/P labels show donor n."
    ),
    side = 1,
    line = 7.8,
    adj = 0,
    cex = 0.68,
    col = "#555555"
  )
}

pdf_path <- file.path(
  out_dir,
  "Figure_GDF15_5FB_Healthy_vs_Periodontitis_Zscore.pdf"
)
png_path <- file.path(
  out_dir,
  "Figure_GDF15_5FB_Healthy_vs_Periodontitis_Zscore_600dpi.png"
)

cairo_pdf(pdf_path, width = 14.5, height = 6.8, family = "sans")
draw_figure()
dev.off()

agg_png(
  png_path,
  width = 14.5,
  height = 6.8,
  units = "in",
  res = 600,
  background = "white",
  scaling = 1
)
draw_figure()
dev.off()

qa_checks <- data.frame(
  check = c(
    "All input files exist",
    "Five mapped fibroblast types plotted",
    "FB8 excluded",
    "Gingivitis excluded from analysis",
    "At least 3 donors per disease group for every subtype",
    "Every plotted donor-subtype row has at least 10 cells",
    "Plot stars use raw study-adjusted P values",
    "Y-axis fixed at -1 to 1",
    "PDF created",
    "600 dpi PNG created",
    "Z-score data include values below zero",
    "All model statistics finite"
  ),
  value = c(
    all(file.exists(inputs)),
    nrow(stats),
    total_fibroblast_cells - retained_fibroblast_cells,
    !any(analysis_data$disease == "gingivitis"),
    all(stats$healthy_n_donors >= 3L & stats$periodontitis_n_donors >= 3L),
    all(analysis_data$n_cells >= minimum_cells_per_donor_subtype),
    all(stats$significance == as.character(cut(
      stats$study_adjusted_p_value,
      breaks = c(-Inf, 0.001, 0.01, 0.05, Inf),
      labels = c("***", "**", "*", "ns"),
      right = FALSE
    ))),
    paste0(visual_y_minimum, " to ", visual_y_maximum),
    file.exists(pdf_path),
    file.exists(png_path),
    any(analysis_data$GDF15_mean_Z_score < 0),
    all(is.finite(stats$study_adjusted_Z_difference))
  ),
  pass = c(
    all(file.exists(inputs)),
    nrow(stats) == 5L,
    total_fibroblast_cells - retained_fibroblast_cells == 58L,
    !any(analysis_data$disease == "gingivitis"),
    all(stats$healthy_n_donors >= 3L & stats$periodontitis_n_donors >= 3L),
    all(analysis_data$n_cells >= minimum_cells_per_donor_subtype),
    all(stats$significance == as.character(cut(
      stats$study_adjusted_p_value,
      breaks = c(-Inf, 0.001, 0.01, 0.05, Inf),
      labels = c("***", "**", "*", "ns"),
      right = FALSE
    ))),
    identical(visual_y_minimum, -1) && identical(visual_y_maximum, 1),
    file.exists(pdf_path),
    file.exists(png_path),
    any(analysis_data$GDF15_mean_Z_score < 0),
    all(is.finite(stats$study_adjusted_Z_difference))
  ),
  stringsAsFactors = FALSE
)
fwrite(qa_checks, file.path(qa_dir, "01_QA_checks.csv"))

caption <- paste0(
  "GDF15 expression across five predefined fibroblast types in healthy and ",
  "periodontitis donors. Each half-violin represents donor-by-subtype means of ",
  "cell-level GDF15 Z-scores. Per-cell values were library-size normalized to ",
  "10,000 counts, log1p transformed, and standardized across retained fibroblasts; ",
  "vertical black segments show ",
  "the interquartile range and horizontal segments show the median. FB8 and ",
  "gingivitis cells were excluded. Stars denote raw (multiplicity-unadjusted) P ",
  "values from subtype-specific linear models of expression on disease status ",
  "with study as a covariate. The y-axis range is fixed at -1 to 1."
)
writeLines(
  caption,
  file.path(out_dir, "Figure_\u82f1\u6587\u56fe\u6ce8.txt"),
  useBytes = TRUE
)

readme <- c(
  "\u76ee\u7684\uff1a\u6bd4\u8f83\u5065\u5eb7\u4e0e\u7259\u5468\u708e\u4f9b\u8005\u5728\u5df2\u5b9a\u4e49\u7684\u4e94\u7c7b\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e2d\u7684GDF15\u8868\u8fbe\u3002",
  "\u4e94\u7c7b\uff1aVascular\u3001Immune\u3001ECM remodeling\u3001Pre-ECM\u3001Matrix homeostasis\u3002",
  "\u6620\u5c04\uff1aFB3+FB7\u3001FB1+FB4\u3001FB2\u3001FB6\u3001FB5\uff1bFB8\u5220\u9664\u3002",
  "\u7edf\u8ba1\u5355\u4f4d\uff1a\u4f9b\u8005\u00d7\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e9a\u578b\uff1b\u6bcf\u4e2a\u4f9b\u8005-\u4e9a\u578b\u53d6\u7ec6\u80de\u7ea7Z-score\u5e73\u5747\uff0c\u4e0d\u628a\u5355\u7ec6\u80de\u5f53\u72ec\u7acb\u751f\u7269\u5b66\u91cd\u590d\u3002",
  "\u8868\u8fbe\u91cf\uff1a\u6bcf\u7ec6\u80de\u63091\u4e07\u5f52\u4e00\u5316\u5e76log1p\uff0c\u5bf9GDF15\u8de8\u4fdd\u7559\u6210\u7ea4\u7ef4\u7ec6\u80de\u505aZ\u6807\u51c6\u5316\uff08scale.data\u540c\u7b49\u5b9a\u4e49\uff0c\u622a\u65ad\u00b110\uff09\u3002",
  "\u7eb3\u5165\uff1anormal\u4e0eperiodontitis\uff1b\u6392\u9664gingivitis\uff1b\u6bcf\u4e2a\u4f9b\u8005-\u4e9a\u578b\u81f3\u5c1110\u4e2a\u7ec6\u80de\u3002",
  "\u6a21\u578b\uff1a\u5404\u4e9a\u578b\u5206\u522b\u62df\u5408 expression ~ disease + study\uff1b\u65b9\u5411\u4e3a\u7259\u5468\u708e\u51cf\u5065\u5eb7\u3002",
  "\u56fe\u4e2d\u661f\u53f7\uff1a\u4f7f\u7528study\u6821\u6b63\u6a21\u578b\u7684raw P\uff0c\u4e0d\u4f7f\u7528FDR\uff1b\u7ed3\u679c\u8868\u4ecd\u4fdd\u7559BH-FDR\u5217\u4f9b\u5ba1\u8ba1\u3002",
  "\u7eb5\u8f74\uff1a\u56fa\u5b9a\u4e3a-1\u81f31\u3002",
  "\u6a2a\u8f74H/P\u6570\u5b57\u4e3a\u8be5\u4e9a\u578b\u5065\u5eb7/\u7259\u5468\u708e\u4f9b\u8005\u6570\u3002",
  "\u6ce8\u610f\uff1a\u56fe\u6309\u771f\u5b9e\u6570\u636e\u5c55\u793a\uff0c\u4e0d\u9884\u8bbe\u6240\u6709\u4e9a\u578b\u5747\u5347\u9ad8\u3002",
  paste0("\u4e3b\u56fe\uff1a", basename(pdf_path)),
  paste0("\u9ad8\u6e05\u56fe\uff1a", basename(png_path)),
  "\u6e90\u6570\u636e\u4e0e\u7edf\u8ba1\u7ed3\u679c\uff1a01_source_data_and_audit/",
  "\u590d\u73b0\u4ee3\u7801\uff1a02_code/01_analyze_GDF15_five_fibroblast_types.R"
)
writeLines(
  readme,
  file.path(out_dir, "README_\u590d\u73b0\u8bf4\u660e.txt"),
  useBytes = TRUE
)

writeLines(
  capture.output(sessionInfo()),
  file.path(source_dir, "R_sessionInfo.txt")
)
message("Completed: ", out_dir)
