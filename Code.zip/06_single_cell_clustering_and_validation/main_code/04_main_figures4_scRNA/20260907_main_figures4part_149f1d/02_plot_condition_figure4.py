from __future__ import annotations
import json
import math
import textwrap
from pathlib import Path
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle
from scipy.cluster.hierarchy import leaves_list, linkage
from scipy.spatial.distance import pdist, squareform
OUT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260907_\u56fe4_\u6210\u7ea4\u7ef4\u7ec6\u80de_\u7259\u5468\u708e_vs_\u5065\u5eb7_\u9664G\u5916_\u540c\u683c\u5f0f_\u4e0d\u8986\u76d6_v1')
SRC = OUT / '02_source_data'
PANELS = OUT / '01_publication_panels'
QA = OUT / '03_QA'
PANELS.mkdir(parents=True, exist_ok=True)
QA.mkdir(parents=True, exist_ok=True)
mpl.rcParams.update({'font.family': 'Arial', 'font.sans-serif': ['Arial', 'DejaVu Sans'], 'pdf.fonttype': 42, 'ps.fonttype': 42, 'axes.linewidth': 0.8, 'axes.edgecolor': '#333333', 'axes.labelcolor': '#222222', 'xtick.color': '#222222', 'ytick.color': '#222222', 'figure.facecolor': 'white', 'savefig.facecolor': 'white'})
TYPE_ORDER = ['Vascular', 'Immune', 'ECM remodeling', 'Pre-extracellular matrix', 'Matrix homeostasis']
TYPE_COLORS = {'Vascular': '#F2A541', 'Immune': '#4C78A8', 'ECM remodeling': '#59A14F', 'Pre-extracellular matrix': '#9C6BB3', 'Matrix homeostasis': '#E899A7'}
GROUP_ORDER = ['Fibroblasts (Healthy)', 'Fibroblasts (Periodontitis)']
GROUP_COLORS = {'Fibroblasts (Healthy)': '#3377B6', 'Fibroblasts (Periodontitis)': '#EF7D75'}
HALLMARK_ORDER = ['Epithelial Mesenchymal Transition', 'TGF-beta Signaling', 'TNF-alpha Signaling via NF-kB', 'Angiogenesis', 'Inflammatory Response', 'Hypoxia', 'KRAS Signaling Up', 'IL-6/JAK/STAT3 Signaling', 'Reactive Oxygen Species Pathway', 'Coagulation']
PAGE_SIZES = {'A': (10.0, 7.4), 'B': (318.772 / 72.0, 428.248 / 72.0), 'C': (655.12 / 72.0, 787.712 / 72.0), 'D': (10.0, 7.4), 'E': (442.082 / 72.0, 521.627 / 72.0), 'F': (10.0, 7.4), 'H': (520.102 / 72.0, 432.45 / 72.0), 'I': (15.5, 7.6)}
FILES = {'A': 'A.\u6210\u7ea4\u7ef4\u7ec6\u80de\uff08\u5065\u5eb7\u4e0e\u7259\u5468\u708e\uff095\u79cd\u4e9a\u578b\u5206\u7c7b\u5730\u56fe', 'B': 'B.\u6210\u7ea4\u7ef4\u7ec6\u80de\uff08\u5065\u5eb7\u4e0e\u7259\u5468\u708e\uff095\u79cd\u4e9a\u578b\u5806\u79ef\u67f1\u72b6\u56fe', 'C': 'C.\u6210\u7ea4\u7ef4\u7ec6\u80de\uff08\u5065\u5eb7\u4e0e\u7259\u5468\u708e\uff09\u5bf9\u89d2\u7ebfGO\u56fe', 'D': 'D.\u6210\u7ea4\u7ef4\u7ec6\u80de\uff08\u5065\u5eb7\u4e0e\u7259\u5468\u708e\uff09\u5206\u7ec4\u5730\u56fe', 'E': 'E.\u6210\u7ea4\u7ef4\u7ec6\u80de\uff08\u5065\u5eb7\u4e0e\u7259\u5468\u708e\uff09\u5206\u7ec4\u6bd4\u4f8b', 'F': 'F.GDF15\u5728\u6210\u7ea4\u7ef4\u7ec6\u80de\uff08\u5065\u5eb7\u4e0e\u7259\u5468\u708e\uff09\u4e2d\u7684\u8868\u8fbe\u5730\u56fe', 'H': 'H.\u6210\u7ea4\u7ef4\u7ec6\u80de\uff08\u5065\u5eb7\u4e0e\u7259\u5468\u708e\uff09GSVA', 'I': 'I.\u6210\u7ea4\u7ef4\u7ec6\u80de\uff08\u7259\u5468\u708evs\u5065\u5eb7\uff09\u5dee\u5f02\u57fa\u56e0GO\u5bcc\u96c6\u4e0eNES\u80cc\u5bf9\u80cc\u56fe'}

def panel_letter(fig: plt.Figure, letter: str, x: float=0.018, y: float=0.975, size: float=32) -> None:
    fig.text(x, y, letter, ha='left', va='top', fontsize=size, fontweight='normal', color='black')

def save_figure(fig: plt.Figure, key: str) -> None:
    pdf = PANELS / f'{FILES[key]}.pdf'
    png = PANELS / f'{FILES[key]}.png'
    fig.savefig(pdf, format='pdf', dpi=600, transparent=False)
    fig.savefig(png, format='png', dpi=600, transparent=False)
    plt.close(fig)

def style_umap(ax: plt.Axes) -> None:
    ax.set_xlim(-6.0, 7.25)
    ax.set_ylim(-6.5, 6.75)
    ax.set_aspect('equal', adjustable='box')
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)

def wrap_label(value: str, width: int) -> str:
    return '\n'.join(textwrap.wrap(str(value), width=width, break_long_words=False, break_on_hyphens=False))

def draw_panel_a(cells: pd.DataFrame) -> None:
    fig, axes = plt.subplots(1, 2, figsize=PAGE_SIZES['A'], gridspec_kw={'wspace': 0.03})
    rng = np.random.default_rng(20260907)
    for ax, group in zip(axes, GROUP_ORDER):
        z = cells.loc[cells['disease_label'] == group].copy()
        z = z.iloc[rng.permutation(len(z))]
        for tp in TYPE_ORDER:
            q = z.loc[z['fibroblast_type'] == tp]
            ax.scatter(q['UMAP_1'], q['UMAP_2'], s=4.8, c=TYPE_COLORS[tp], alpha=0.92, linewidths=0, rasterized=True)
        style_umap(ax)
        ax.set_title(group, fontsize=14, fontweight='bold', pad=5)
    handles = [Line2D([0], [0], marker='o', linestyle='', markersize=6.5, markerfacecolor=TYPE_COLORS[t], markeredgewidth=0, label=t) for t in TYPE_ORDER]
    fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(0.52, 0.025), ncol=3, frameon=False, fontsize=9, handletextpad=0.45, columnspacing=1.2)
    panel_letter(fig, 'A')
    fig.subplots_adjust(left=0.055, right=0.985, top=0.9, bottom=0.16)
    save_figure(fig, 'A')

def draw_panel_b(type_counts: pd.DataFrame) -> None:
    fig, ax = plt.subplots(figsize=PAGE_SIZES['B'])
    bottoms = np.zeros(len(GROUP_ORDER))
    for tp in TYPE_ORDER:
        vals = []
        for group in GROUP_ORDER:
            row = type_counts[(type_counts['disease_label'] == group) & (type_counts['fibroblast_type'] == tp)]
            vals.append(float(row['percent_within_disease'].iloc[0]))
        vals = np.asarray(vals)
        bars = ax.bar(np.arange(2), vals, bottom=bottoms, width=0.63, color=TYPE_COLORS[tp], edgecolor='white', linewidth=0.6, label=tp)
        for j, (bar, val) in enumerate(zip(bars, vals)):
            if val >= 4.0:
                ax.text(bar.get_x() + bar.get_width() / 2, bottoms[j] + val / 2, f'{val:.1f}%', ha='center', va='center', fontsize=7.5, color='white' if tp in {'Immune', 'Pre-extracellular matrix'} else '#222222')
        bottoms += vals
    ax.set_ylim(0, 100)
    ax.set_ylabel('Percentage of fibroblasts (%)', fontsize=10)
    ax.set_xticks([0, 1], ['Fibroblasts\n(Healthy)', 'Fibroblasts\n(Periodontitis)'], fontsize=8.5)
    ax.tick_params(axis='y', labelsize=8)
    ax.grid(axis='y', color='#E7E7E7', linewidth=0.7)
    ax.set_axisbelow(True)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.12), frameon=False, fontsize=7.3, ncol=1, handlelength=1.3)
    panel_letter(fig, 'B', x=0.025, y=0.985, size=28)
    fig.subplots_adjust(left=0.19, right=0.97, top=0.93, bottom=0.34)
    save_figure(fig, 'B')

def draw_panel_c(go: pd.DataFrame) -> None:
    go = go.copy()
    go['minus_log10_p'] = -np.log10(np.maximum(go['p_value'].astype(float), np.finfo(float).tiny))
    ordered_rows = []
    for group in GROUP_ORDER:
        ordered_rows.extend(go.loc[go['group'] == group].sort_values('within_group_rank')['term_key'].tolist())
    go['term_key'] = pd.Categorical(go['term_key'], categories=ordered_rows, ordered=True)
    go = go.sort_values('term_key')
    y_map = {k: len(ordered_rows) - 1 - i for i, k in enumerate(ordered_rows)}
    x_map = {GROUP_ORDER[0]: 0, GROUP_ORDER[1]: 1}
    x = go['group'].map(x_map).astype(float).to_numpy()
    y = go['term_key'].map(y_map).astype(float).to_numpy()
    fig, ax = plt.subplots(figsize=PAGE_SIZES['C'])
    ax.axhspan(4.5, 9.5, color='#3377B6', alpha=0.035, zorder=0)
    ax.axhspan(-0.5, 4.5, color='#EF7D75', alpha=0.045, zorder=0)
    cmap = LinearSegmentedColormap.from_list('go_ref', ['#F5D76E', '#E98B9B', '#7B3294'])
    pmin, pmax = (float(go['minus_log10_p'].min()), float(go['minus_log10_p'].max()))
    sizes = 45 + 14 * go['Count'].astype(float).to_numpy()
    sc = ax.scatter(x, y, s=sizes, c=go['minus_log10_p'], cmap=cmap, norm=Normalize(pmin, pmax), edgecolor='#555555', linewidth=0.45, zorder=3)
    ax.set_xlim(-0.65, 1.65)
    ax.set_ylim(-0.8, 9.8)
    ax.set_xticks([0, 1], ['Fibroblasts\n(Healthy)', 'Fibroblasts\n(Periodontitis)'], fontsize=10)
    term_labels = []
    y_ticks = []
    for k in ordered_rows:
        row = go.loc[go['term_key'] == k].iloc[0]
        term_labels.append(wrap_label(row['Description'], 44))
        y_ticks.append(y_map[k])
    ax.set_yticks(y_ticks, term_labels, fontsize=8.4)
    ax.grid(color='#E7E7E7', linewidth=0.75)
    ax.set_axisbelow(True)
    for s in ax.spines.values():
        s.set_visible(False)
    cbar = fig.colorbar(sc, ax=ax, fraction=0.035, pad=0.035)
    cbar.set_label('\u2212log10(P value)', fontsize=9)
    cbar.ax.tick_params(labelsize=7.5, length=2)
    count_levels = sorted(set((int(v) for v in go['Count'])))
    if len(count_levels) > 4:
        idx = np.linspace(0, len(count_levels) - 1, 4).round().astype(int)
        count_levels = [count_levels[i] for i in sorted(set(idx))]
    size_handles = [plt.scatter([], [], s=45 + 14 * v, facecolor='#999999', edgecolor='#555555', linewidth=0.4, label=str(v)) for v in count_levels]
    ax.legend(handles=size_handles, title='Count', loc='upper left', bbox_to_anchor=(1.02, 0.42), frameon=False, fontsize=8, title_fontsize=9, labelspacing=0.8)
    panel_letter(fig, 'C', x=0.018, y=0.985, size=32)
    fig.subplots_adjust(left=0.47, right=0.87, top=0.96, bottom=0.09)
    save_figure(fig, 'C')

def draw_panel_d(cells: pd.DataFrame) -> None:
    fig, ax = plt.subplots(figsize=PAGE_SIZES['D'])
    for group in GROUP_ORDER:
        q = cells.loc[cells['disease_label'] == group]
        ax.scatter(q['UMAP_1'], q['UMAP_2'], s=5.0, color=GROUP_COLORS[group], alpha=0.88, linewidths=0, rasterized=True, label=group)
    style_umap(ax)
    ax.legend(loc='center left', bbox_to_anchor=(1.01, 0.5), frameon=False, title='Group', title_fontsize=11, fontsize=9, markerscale=2.0)
    panel_letter(fig, 'D')
    fig.subplots_adjust(left=0.06, right=0.79, top=0.94, bottom=0.06)
    save_figure(fig, 'D')

def draw_panel_e(type_counts: pd.DataFrame) -> None:
    fig, ax = plt.subplots(figsize=PAGE_SIZES['E'])
    x = np.arange(len(TYPE_ORDER))
    bottoms = np.zeros(len(TYPE_ORDER))
    for group in [GROUP_ORDER[1], GROUP_ORDER[0]]:
        vals = []
        for tp in TYPE_ORDER:
            row = type_counts[(type_counts['disease_label'] == group) & (type_counts['fibroblast_type'] == tp)]
            vals.append(float(row['percent_disease_within_type'].iloc[0]))
        vals = np.asarray(vals)
        bars = ax.bar(x, vals, bottom=bottoms, width=0.72, color=GROUP_COLORS[group], edgecolor='white', linewidth=0.55, label=group)
        for j, (bar, val) in enumerate(zip(bars, vals)):
            if val >= 6.0:
                ax.text(bar.get_x() + bar.get_width() / 2, bottoms[j] + val / 2, f'{val:.1f}%', ha='center', va='center', fontsize=7.1, color='white')
        bottoms += vals
    ax.set_ylim(0, 100)
    ax.set_ylabel('Percentage within fibroblast type (%)', fontsize=9.5)
    ax.set_xticks(x, [wrap_label(t, 15) for t in TYPE_ORDER], rotation=43, ha='right', fontsize=7.8)
    ax.tick_params(axis='y', labelsize=8)
    ax.grid(axis='y', color='#E7E7E7', linewidth=0.7)
    ax.set_axisbelow(True)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.31), frameon=False, fontsize=7.7, ncol=1, handlelength=1.5)
    panel_letter(fig, 'E', x=0.02, y=0.985, size=28)
    fig.subplots_adjust(left=0.17, right=0.98, top=0.94, bottom=0.42)
    save_figure(fig, 'E')

def draw_panel_f(cells: pd.DataFrame) -> None:
    vals = cells['GDF15_log_normalized'].astype(float).to_numpy()
    nonzero = vals[vals > 0]
    vmax = float(np.quantile(nonzero, 0.99)) if len(nonzero) else 1.0
    cmap = LinearSegmentedColormap.from_list('gdf15', ['#D9D9D9', '#F6B1A7', '#DE5A4F'])
    norm = Normalize(0, max(vmax, 1e-06), clip=True)
    fig, axes = plt.subplots(1, 2, figsize=PAGE_SIZES['F'], gridspec_kw={'wspace': 0.03})
    mappable = None
    for ax, group in zip(axes, GROUP_ORDER):
        z = cells.loc[cells['disease_label'] == group].sort_values('GDF15_log_normalized')
        mappable = ax.scatter(z['UMAP_1'], z['UMAP_2'], s=5.0, c=z['GDF15_log_normalized'], cmap=cmap, norm=norm, linewidths=0, rasterized=True)
        style_umap(ax)
        ax.set_title(group, fontsize=14, fontweight='bold', pad=5)
    cax = fig.add_axes([0.9, 0.24, 0.018, 0.48])
    cb = fig.colorbar(mappable, cax=cax)
    cb.set_label('GDF15 expression', fontsize=10)
    cb.ax.tick_params(labelsize=8)
    panel_letter(fig, 'F')
    fig.subplots_adjust(left=0.055, right=0.87, top=0.9, bottom=0.07)
    save_figure(fig, 'F')

def constrained_linkage(matrix: np.ndarray) -> list[tuple[int, int, float, int]]:
    n = matrix.shape[0]
    d = squareform(pdist(matrix, metric='correlation'))
    d[~np.isfinite(d)] = 1.0
    clusters = [{'id': i, 'leaves': [i], 'height': 0.0} for i in range(n)]
    next_id = n
    merges: list[tuple[int, int, float, int]] = []
    while len(clusters) > 1:
        costs = []
        for i in range(len(clusters) - 1):
            a, b = (clusters[i]['leaves'], clusters[i + 1]['leaves'])
            costs.append(float(np.mean(d[np.ix_(a, b)])))
        j = int(np.argmin(costs))
        left, right = (clusters[j], clusters[j + 1])
        height = max(costs[j], left['height'] + 0.0001, right['height'] + 0.0001)
        merged = {'id': next_id, 'leaves': left['leaves'] + right['leaves'], 'height': height}
        merges.append((left['id'], right['id'], height, len(merged['leaves'])))
        clusters[j:j + 2] = [merged]
        next_id += 1
    return merges

def draw_fixed_order_dendrogram(ax: plt.Axes, matrix: np.ndarray) -> None:
    n = matrix.shape[0]
    y = {i: n - 1 - i for i in range(n)}
    x = {i: 0.0 for i in range(n)}
    count = {i: 1 for i in range(n)}
    merges = constrained_linkage(matrix)
    for idx, (left, right, height, _) in enumerate(merges, start=n):
        yl, yr = (y[left], y[right])
        xl, xr = (x[left], x[right])
        ax.plot([xl, height], [yl, yl], color='#4A4A4A', lw=0.75)
        ax.plot([xr, height], [yr, yr], color='#4A4A4A', lw=0.75)
        ax.plot([height, height], [yr, yl], color='#4A4A4A', lw=0.75)
        y[idx] = (yl * count[left] + yr * count[right]) / (count[left] + count[right])
        x[idx] = height
        count[idx] = count[left] + count[right]
    max_height = max((m[2] for m in merges), default=1.0)
    ax.set_xlim(max_height * 1.05, -0.02)
    ax.set_ylim(-0.5, n - 0.5)
    ax.axis('off')

def draw_panel_h(gsva: pd.DataFrame) -> None:
    pivot = gsva.pivot(index='pathway', columns='donor_id', values='GSVA_score').loc[HALLMARK_ORDER]
    donor_meta = gsva[['donor_id', 'disease_label']].drop_duplicates().set_index('donor_id')
    donor_order = []
    for group in GROUP_ORDER:
        ids = [x for x in pivot.columns if donor_meta.loc[x, 'disease_label'] == group]
        if len(ids) > 2:
            z = pivot[ids].T.to_numpy()
            order = leaves_list(linkage(z, method='average', metric='euclidean'))
            ids = [ids[i] for i in order]
        donor_order.extend(ids)
    matrix = pivot[donor_order].to_numpy()
    fig = plt.figure(figsize=PAGE_SIZES['H'])
    gs = fig.add_gridspec(2, 2, height_ratios=[0.28, 5.2], width_ratios=[1.25, 4.7], hspace=0.035, wspace=0.015)
    strip = fig.add_subplot(gs[0, 1])
    dend = fig.add_subplot(gs[1, 0])
    ax = fig.add_subplot(gs[1, 1])
    strip_colors = np.array([[mpl.colors.to_rgb(GROUP_COLORS[donor_meta.loc[d, 'disease_label']]) for d in donor_order]])
    strip.imshow(strip_colors, aspect='auto', interpolation='nearest')
    strip.set_xticks([])
    strip.set_yticks([])
    for s in strip.spines.values():
        s.set_visible(False)
    strip.text(-0.035, 0.5, 'Group', transform=strip.transAxes, ha='right', va='center', fontsize=10, fontweight='bold')
    im = ax.imshow(matrix, aspect='auto', interpolation='nearest', cmap='RdBu_r', vmin=-0.5, vmax=0.5)
    ax.set_xticks([])
    ax.set_yticks(np.arange(len(HALLMARK_ORDER)), [wrap_label(x, 29) for x in HALLMARK_ORDER], fontsize=7.0)
    ax.yaxis.tick_right()
    ax.tick_params(axis='y', length=0, pad=4)
    for s in ax.spines.values():
        s.set_color('#222222')
        s.set_linewidth(0.8)
    draw_fixed_order_dendrogram(dend, matrix)
    cax = fig.add_axes([0.93, 0.27, 0.018, 0.43])
    cb = fig.colorbar(im, cax=cax, extend='both')
    cb.set_ticks([-0.5, -0.25, 0, 0.25, 0.5])
    cb.set_label('GSVA score', fontsize=8.5)
    cb.ax.tick_params(labelsize=7)
    handles = [Patch(facecolor=GROUP_COLORS[g], edgecolor='none', label=g) for g in GROUP_ORDER]
    fig.legend(handles=handles, title='Group', loc='lower left', bbox_to_anchor=(0.8, 0.03), frameon=False, fontsize=6.8, title_fontsize=8, handlelength=1.5)
    panel_letter(fig, 'H', x=0.014, y=0.985, size=30)
    fig.subplots_adjust(left=0.035, right=0.74, top=0.92, bottom=0.06)
    save_figure(fig, 'H')

def draw_panel_i(data: pd.DataFrame) -> None:
    data = data.sort_values('display_order').reset_index(drop=True).copy()
    data['minus_log10_fdr'] = -np.log10(np.maximum(data['FDR'].astype(float), np.finfo(float).tiny))
    data['abs_nes'] = np.abs(data['NES'].astype(float))
    n = len(data)
    y = np.arange(n)[::-1]
    ontology_colors = {'BP': '#E98E5B', 'CC': '#F1D778', 'MF': '#9EB38E'}
    nes_colors = np.where(data['NES'].astype(float) >= 0, '#E9A1AE', '#9ABCD7')
    fig = plt.figure(figsize=PAGE_SIZES['I'])
    gs = fig.add_gridspec(1, 3, width_ratios=[1.45, 3.4, 1.8], wspace=0.02)
    left = fig.add_subplot(gs[0, 0])
    middle = fig.add_subplot(gs[0, 1], sharey=left)
    right = fig.add_subplot(gs[0, 2], sharey=left)
    left.barh(y, -data['abs_nes'], color=nes_colors, edgecolor='white', height=0.68)
    left.axvline(0, color='#333333', lw=0.8)
    max_nes = float(data['abs_nes'].max())
    left.set_xlim(-max_nes * 1.34, 0.05)
    left.set_ylim(-0.8, n - 0.2)
    left.set_xlabel('GSEA |NES|', fontsize=10)
    left.set_yticks([])
    left.grid(axis='x', color='#E7E7E7', linewidth=0.7)
    left.set_axisbelow(True)
    left.spines['top'].set_visible(False)
    left.spines['left'].set_visible(False)
    for yy, nes in zip(y, data['NES'].astype(float)):
        left.text(-abs(nes) - max_nes * 0.025, yy, f'{nes:+.2f}', ha='right', va='center', fontsize=7.3)
    middle.set_xlim(0, 1)
    middle.set_ylim(-0.8, n - 0.2)
    middle.axis('off')
    for yy, (_, row) in zip(y, data.iterrows()):
        middle.add_patch(Rectangle((0.0, yy - 0.34), 0.035, 0.68, facecolor=ontology_colors[row['ontology']], edgecolor='none'))
        middle.text(0.055, yy, wrap_label(row['Description'], 57), ha='left', va='center', fontsize=8.1)
    middle.text(0.5, 1.025, 'GO pathway', transform=middle.transAxes, ha='center', va='bottom', fontsize=11, fontweight='bold')
    ora_colors = [ontology_colors[x] for x in data['ontology']]
    right.barh(y, data['minus_log10_fdr'], color=ora_colors, edgecolor='white', height=0.68)
    right.axvline(-math.log10(0.05), color='#666666', linestyle='--', linewidth=0.8)
    right.set_xlabel('ORA \u2212log10(FDR)', fontsize=10)
    right.set_yticks([])
    right.grid(axis='x', color='#E7E7E7', linewidth=0.7)
    right.set_axisbelow(True)
    right.spines['top'].set_visible(False)
    right.spines['right'].set_visible(False)
    for yy, v in zip(y, data['minus_log10_fdr']):
        right.text(v + data['minus_log10_fdr'].max() * 0.015, yy, f'{v:.2f}', ha='left', va='center', fontsize=7.2)
    right.set_xlim(0, data['minus_log10_fdr'].max() * 1.22)
    left.legend(handles=[Patch(facecolor='#E9A1AE', label='NES > 0'), Patch(facecolor='#9ABCD7', label='NES < 0')], loc='lower left', frameon=False, fontsize=8)
    right.legend(handles=[Patch(facecolor=ontology_colors[k], label=k) for k in ['BP', 'CC', 'MF']], title='ONTOLOGY', loc='lower right', frameon=False, fontsize=8, title_fontsize=8.5)
    panel_letter(fig, 'I', x=0.012, y=0.985, size=31)
    fig.subplots_adjust(left=0.055, right=0.985, top=0.94, bottom=0.11)
    save_figure(fig, 'I')

def main() -> None:
    cells = pd.read_csv(SRC / '01_cell_metadata_UMAP_GDF15.csv.gz')
    type_counts = pd.read_csv(SRC / '02_fibroblast_type_by_disease_counts.csv')
    go = pd.read_csv(SRC / '07_C_diagonal_GO_selected.csv')
    gsva = pd.read_csv(SRC / '08_H_Hallmark_GSVA_scores.csv')
    i_data = pd.read_csv(SRC / '10_I_GO_ORA_and_GSEA_selected.csv')
    assert len(cells) == 15290
    assert set(cells['disease_label']) == set(GROUP_ORDER)
    assert set(cells['fibroblast_type']) == set(TYPE_ORDER)
    assert len(go) == 10 and set(go['ontology']) == {'BP'}
    assert len(i_data) == 15 and i_data.groupby('ontology').size().to_dict() == {'BP': 5, 'CC': 5, 'MF': 5}
    draw_panel_a(cells)
    draw_panel_b(type_counts)
    draw_panel_c(go)
    draw_panel_d(cells)
    draw_panel_e(type_counts)
    draw_panel_f(cells)
    draw_panel_h(gsva)
    draw_panel_i(i_data)
    manifest = []
    for key in ['A', 'B', 'C', 'D', 'E', 'F', 'H', 'I']:
        for ext in ['pdf', 'png']:
            p = PANELS / f'{FILES[key]}.{ext}'
            manifest.append({'panel': key, 'file': p.name, 'bytes': p.stat().st_size})
    pd.DataFrame(manifest).to_csv(QA / '05_figure_output_manifest.csv', index=False, encoding='utf-8-sig')
    (QA / '06_plot_contract.json').write_text(json.dumps({'panels_created': ['A', 'B', 'C', 'D', 'E', 'F', 'H', 'I'], 'panel_G': 'intentionally excluded by user request', 'original_files_overwritten': False, 'condition_labels': GROUP_ORDER, 'page_sizes_inches': PAGE_SIZES, 'umap_limits': {'x': [-6.0, 7.25], 'y': [-6.5, 6.75]}, 'figure_semantics': {'A': 'Five frozen fibroblast subtypes, faceted by disease condition', 'B': 'Within-condition subtype composition', 'C': 'Top five condition-direction GO-BP terms per condition', 'D': 'All retained fibroblasts colored by disease condition', 'E': 'Healthy/periodontitis composition within each frozen subtype', 'F': 'GDF15 log-normalized expression faceted by disease condition', 'H': 'Donor-level Hallmark GSVA, median-centered, condition annotation', 'I': 'Periodontitis-vs-healthy donor-pseudobulk GO ORA with matched GO GSEA NES'}}, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'Created {len(manifest)} figure files in {PANELS}')
if __name__ == '__main__':
    main()
