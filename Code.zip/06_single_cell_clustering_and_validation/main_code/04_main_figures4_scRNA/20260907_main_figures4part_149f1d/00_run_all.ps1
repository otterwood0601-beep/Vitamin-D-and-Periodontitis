$ErrorActionPreference = 'Stop'

$analysisDir = "G:\$([char]0x8840)$([char]0x6E05)$([char]0x7EF4)$([char]0x751F)$([char]0x7D20)\E$([char]0x76D8)$([char]0x7CBE)$([char]0x7B80)$([char]0x5F52)$([char]0x6863)_20260908_v2\E$([char]0x76D8)$([char]0x539F)$([char]0x76F8)$([char]0x5BF9)$([char]0x7ED3)$([char]0x6784)\$([char]0x4EE3)$([char]0x7801)\$([char]0x9879)$([char]0x76EE)$([char]0x811A)$([char]0x672C)\04_$([char]0x5355)$([char]0x7EC6)$([char]0x80DE)\20260907_$([char]0x56FE)4_$([char]0x6210)$([char]0x7EA4)$([char]0x7EF4)$([char]0x7EC6)$([char]0x80DE)_$([char]0x7259)$([char]0x5468)$([char]0x708E)_vs_$([char]0x5065)$([char]0x5EB7)_$([char]0x9664)G$([char]0x5916)_$([char]0x540C)$([char]0x683C)$([char]0x5F0F)_v1"
$outputDir = "E:\$([char]0x8840)$([char]0x6E05)$([char]0x7EF4)$([char]0x751F)$([char]0x7D20)\$([char]0x4EE3)$([char]0x7801)\$([char]0x8FD0)$([char]0x884C)$([char]0x8F93)$([char]0x51FA)\20260907_$([char]0x56FE)4_$([char]0x6210)$([char]0x7EA4)$([char]0x7EF4)$([char]0x7EC6)$([char]0x80DE)_$([char]0x7259)$([char]0x5468)$([char]0x708E)_vs_$([char]0x5065)$([char]0x5EB7)_$([char]0x9664)G$([char]0x5916)_$([char]0x540C)$([char]0x683C)$([char]0x5F0F)_$([char]0x4E0D)$([char]0x8986)$([char]0x76D6)_v1"
$rscriptExe = 'C:\Program Files\R\R-4.5.3\bin\Rscript.exe'

& $rscriptExe "$analysisDir\01_prepare_condition_figure4.R" $outputDir
if ($LASTEXITCODE -ne 0) { throw 'R analysis failed.' }

python "$analysisDir\02_plot_condition_figure4.py"
if ($LASTEXITCODE -ne 0) { throw 'Figure generation failed.' }

Write-Host "Completed: $outputDir"
