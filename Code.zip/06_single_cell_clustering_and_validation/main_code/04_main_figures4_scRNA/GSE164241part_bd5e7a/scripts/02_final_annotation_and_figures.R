options(stringsAsFactors = FALSE)
options(future.globals.maxSize = 32 * 1024^3)
options(Seurat.object.assay.version = "v3")

SEED <- 20260815L
set.seed(SEED)

OUT_ROOT <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260815-GSE164241\u5065\u5eb7\u7259\u9f88-\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e25\u683c\u91cd\u5206\u6790-v1"
INPUT_RDS <- file.path(OUT_ROOT, "02_intermediate", "strict_integrated_clustered.rds")
R_LIB <- "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library"
.libPaths(c(R_LIB, .libPaths()))

suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
  library(data.table)
  library(ggplot2)
  library(ggrepel)
  library(patchwork)
  library(scales)
  library(svglite)
})

write_csv <- function(x, path) {
  fwrite(as.data.table(x), path, bom = TRUE)
}

save_figure <- function(plot, stem, width, height) {
  figure_dir <- file.path(OUT_ROOT, "04_figures")
  ggsave(
    filename = file.path(figure_dir, paste0(stem, ".pdf")),
    plot = plot,
    device = grDevices::cairo_pdf,
    width = width,
    height = height,
    units = "in",
    bg = "white"
  )
  png_device <- if (requireNamespace("ragg", quietly = TRUE)) {
    ragg::agg_png
  } else {
    "png"
  }
  ggsave(
    filename = file.path(figure_dir, paste0(stem, ".png")),
    plot = plot,
    device = png_device,
    width = width,
    height = height,
    units = "in",
    dpi = 400,
    bg = "white"
  )
  ggsave(
    filename = file.path(figure_dir, paste0(stem, ".svg")),
    plot = plot,
    device = svglite::svglite,
    width = width,
    height = height,
    units = "in",
    bg = "white"
  )
}

base_theme <- theme_minimal(base_family = "sans", base_size = 10) +
  theme(
    plot.title = element_text(face = "bold", size = 14, color = "#1F2933"),
    plot.subtitle = element_text(size = 9.5, color = "#52606D", lineheight = 1.15),
    plot.caption = element_text(size = 8, color = "#7B8794", hjust = 0),
    axis.title = element_text(face = "bold", color = "#364152"),
    axis.text = element_text(color = "#364152"),
    legend.title = element_text(face = "bold", color = "#364152"),
    legend.text = element_text(color = "#364152"),
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(color = "#E7EBEF", linewidth = 0.35),
    plot.margin = margin(10, 14, 10, 10)
  )

message("[1/7] Loading the strict integrated object")
integrated_object <- readRDS(INPUT_RDS)
stopifnot(ncol(integrated_object) == 10105L)
metadata_all <- integrated_object[[]]
metadata_all$cell <- rownames(metadata_all)

ARTIFACT_CLUSTER <- "5"
artifact_cells <- metadata_all$cell[
  as.character(metadata_all$data_driven_cluster) == ARTIFACT_CLUSTER
]
final_cells <- setdiff(colnames(integrated_object), artifact_cells)
stopifnot(length(artifact_cells) == 50L, length(final_cells) == 10055L)
final_object <- subset(integrated_object, cells = final_cells)
rm(integrated_object)
gc()

CLASS_MAP <- data.table(
  cluster = c("0", "1", "2", "3", "4", "6"),
  class_code = paste0("FB", 1:6),
  class_label = c(
    "CXCL13+ inflammatory FB",
    "CFD+APOD+ homeostatic FB",
    "COL11A1+ ECM-remodeling FB",
    "F13A1+ matrix FB",
    "COL7A1+ activated FB",
    "Cycling FB (cell state)"
  ),
  interpretation_cn = c(
    "CXCL13/CCL19\u53caCXCL1/2/3\u9ad8\u8868\u8fbe\u7684\u708e\u75c7\u76f8\u5173\u6210\u7ea4\u7ef4\u7ec6\u80de",
    "CFD\u3001APOD\u3001ANGPTL1\u53caSFRP1\u9ad8\u8868\u8fbe\u7684\u7a33\u6001\u6210\u7ea4\u7ef4\u7ec6\u80de",
    "COL11A1\u3001SFRP4\u3001FNDC1\u53caASPN\u9ad8\u8868\u8fbe\u7684ECM\u91cd\u5851\u6210\u7ea4\u7ef4\u7ec6\u80de",
    "F13A1\u3001TNFRSF11B\u3001CYP26B1\u53caBMP4\u9ad8\u8868\u8fbe\u7684\u57fa\u8d28\u6210\u7ea4\u7ef4\u7ec6\u80de",
    "COL7A1\u3001ADAM12\u3001MMP11\u53caTAGLN\u9ad8\u8868\u8fbe\u7684\u6d3b\u5316\u6210\u7ea4\u7ef4\u7ec6\u80de",
    "MKI67/TOP2A\u53ca\u6709\u4e1d\u5206\u88c2\u57fa\u56e0\u9ad8\u8868\u8fbe\uff1b\u5c5e\u4e8e\u7ec6\u80de\u72b6\u6001\u800c\u975e\u7a33\u5b9a\u4e9a\u578b"
  ),
  classification_status = c(rep("stable_fibroblast_subtype", 5L), "cell_state_not_stable_subtype")
)

cluster_values <- as.character(final_object$data_driven_cluster)
map_label <- setNames(CLASS_MAP$class_label, CLASS_MAP$cluster)
map_code <- setNames(CLASS_MAP$class_code, CLASS_MAP$cluster)
map_status <- setNames(CLASS_MAP$classification_status, CLASS_MAP$cluster)
class_levels <- CLASS_MAP$class_label
code_levels <- CLASS_MAP$class_code
final_object$fibroblast_class <- factor(
  unname(map_label[cluster_values]),
  levels = class_levels
)
final_object$class_code <- factor(
  unname(map_code[cluster_values]),
  levels = code_levels
)
final_object$classification_status <- unname(map_status[cluster_values])
stopifnot(!anyNA(final_object$fibroblast_class))
Idents(final_object) <- "fibroblast_class"
DefaultAssay(final_object) <- "RNA"

message("[2/7] Recomputing final independent RNA markers after artifact exclusion")
final_markers <- FindAllMarkers(
  final_object,
  assay = "RNA",
  slot = "data",
  only.pos = TRUE,
  test.use = "wilcox",
  logfc.threshold = 0.20,
  min.pct = 0.10,
  return.thresh = 0.05,
  verbose = TRUE
)
final_markers_dt <- as.data.table(final_markers, keep.rownames = "marker_row")
if (!"gene" %in% names(final_markers_dt)) {
  final_markers_dt[, gene := marker_row]
}
final_markers_dt[, class_label := as.character(cluster)]
final_markers_dt <- merge(
  final_markers_dt,
  CLASS_MAP[, .(class_label, class_code)],
  by = "class_label",
  all.x = TRUE,
  sort = FALSE
)
write_csv(
  final_markers_dt,
  file.path(OUT_ROOT, "03_source_tables", "08_final_class_FindAllMarkers.csv.gz")
)

message("[3/7] Selecting non-circular diagonal DotPlot markers")
CURATED_CANDIDATES <- list(
  FB1 = c("CXCL13", "CHI3L2", "LBP", "CXCL3", "CXCL2", "CCL19", "IL6"),
  FB2 = c("CFD", "APOD", "ANGPTL1", "SFRP1", "PTGDS", "ABCA8", "TNXB"),
  FB3 = c("COL11A1", "SFRP4", "FNDC1", "ASPN", "PRSS35", "COL12A1", "LRRC15"),
  FB4 = c("F13A1", "TNFRSF11B", "CYP26B1", "BMP4", "RDH10", "PDGFD", "ITIH5"),
  FB5 = c("COL7A1", "ADAM12", "MMP11", "TAGLN", "SPHK1", "ENPP1", "INHBA"),
  FB6 = c("MKI67", "TOP2A", "KIF20A", "CEP55", "ASPM", "FAM64A", "BUB1B")
)

technical_pattern <- paste0(
  "^(MT-|RPS[0-9]|RPL[0-9]|HB[ABDEGQZ]|IG[HKL]|TR[ABDG]|HLA-)|",
  "^(MALAT1|NEAT1|XIST|KDM5D|DDX3Y|UTY|RPS4Y1|EIF1AY)$"
)
stress_genes <- c(
  "FOS", "FOSB", "JUN", "JUNB", "JUND", "ATF3", "DDIT3", "IER2",
  "IER3", "HSPA1A", "HSPA1B", "HSP90AA1", "DNAJB1", "GDF15"
)

marker_pool <- final_markers_dt[
  p_val_adj < 0.05 & pct.1 >= 0.15 & avg_log2FC >= 0.25 &
    !grepl(technical_pattern, gene)
][order(class_code, p_val_adj, -avg_log2FC)]
marker_pool[class_code != "FB6", eligible_for_dotplot := !gene %in% stress_genes]
marker_pool[class_code == "FB6", eligible_for_dotplot := TRUE]
marker_pool <- marker_pool[eligible_for_dotplot == TRUE]

candidate_genes <- unique(c(
  unlist(CURATED_CANDIDATES, use.names = FALSE),
  marker_pool[, head(gene, 100L), by = class_code]$V1
))
DefaultAssay(final_object) <- "RNA"
rna_data <- GetAssayData(final_object, assay = "RNA", layer = "data")
candidate_genes <- intersect(candidate_genes, rownames(rna_data))
candidate_average <- rbindlist(lapply(code_levels, function(code) {
  cells <- colnames(final_object)[as.character(final_object$class_code) == code]
  data.table(
    class_code = code,
    gene = candidate_genes,
    average_expression = Matrix::rowMeans(rna_data[candidate_genes, cells, drop = FALSE]),
    percent_expressed = Matrix::rowMeans(rna_data[candidate_genes, cells, drop = FALSE] > 0) * 100
  )
}))
candidate_average[, max_expression_class := class_code[which.max(average_expression)], by = gene]
candidate_average[, diagonal_maximum := class_code == max_expression_class]

selected_rows <- lapply(code_levels, function(code) {
  curated <- CURATED_CANDIDATES[[code]]
  ranked_de <- marker_pool[class_code == code, gene]
  ordered_candidates <- unique(c(curated, ranked_de))
  diagonal_genes <- candidate_average[
    class_code == code & diagonal_maximum == TRUE,
    gene
  ]
  chosen <- head(intersect(ordered_candidates, diagonal_genes), 4L)
  if (length(chosen) < 4L) {
    stop("Fewer than four diagonal markers were available for ", code)
  }
  data.table(
    class_code = code,
    marker_order = seq_along(chosen),
    gene = chosen
  )
})
selected_markers <- rbindlist(selected_rows)
selected_markers <- merge(
  selected_markers,
  CLASS_MAP[, .(class_code, class_label, classification_status)],
  by = "class_code",
  all.x = TRUE,
  sort = FALSE
)
selected_markers <- merge(
  selected_markers,
  final_markers_dt[, .(
    class_code,
    gene,
    p_val,
    avg_log2FC,
    pct.1,
    pct.2,
    p_val_adj
  )],
  by = c("class_code", "gene"),
  all.x = TRUE,
  sort = FALSE
)
selected_markers[, class_order := match(class_code, code_levels)]
setorder(selected_markers, class_order, marker_order)
selected_markers[, class_order := NULL]
selected_markers[, display_order := seq_len(.N)]
write_csv(
  selected_markers,
  file.path(OUT_ROOT, "03_source_tables", "09_selected_diagonal_DotPlot_markers.csv")
)

dotplot_source <- candidate_average[
  gene %in% selected_markers$gene
]
dotplot_source <- merge(
  dotplot_source,
  selected_markers[, .(
    gene,
    intended_class_code = class_code,
    intended_class_label = class_label,
    marker_order,
    display_order
  )],
  by = "gene",
  all.x = TRUE,
  sort = FALSE
)
dotplot_source[, scaled_average_expression := {
  if (sd(average_expression) == 0) {
    rep(0, .N)
  } else {
    pmax(-2.5, pmin(2.5, as.numeric(scale(average_expression))))
  }
}, by = gene]
dotplot_source[, diagonal_cell := class_code == intended_class_code]
dotplot_source[, intended_order := match(intended_class_code, code_levels)]
dotplot_source[, observed_order := match(class_code, code_levels)]
setorder(dotplot_source, intended_order, marker_order, observed_order)
dotplot_source[, c("intended_order", "observed_order") := NULL]
write_csv(
  dotplot_source,
  file.path(OUT_ROOT, "03_source_tables", "10_final_diagonal_DotPlot_source.csv")
)

message("[4/7] Exporting final annotation and composition tables")
final_metadata <- final_object[[]]
final_metadata$cell <- rownames(final_metadata)
umap <- Embeddings(final_object, reduction = "umap_strict")
final_metadata$UMAP_1 <- umap[rownames(final_metadata), 1L]
final_metadata$UMAP_2 <- umap[rownames(final_metadata), 2L]
write_csv(
  final_metadata,
  file.path(OUT_ROOT, "03_source_tables", "11_final_cell_metadata.csv.gz")
)

overall_composition <- as.data.table(table(
  class_code = factor(final_metadata$class_code, levels = code_levels)
))
overall_composition[, percent := N / sum(N) * 100]
overall_composition <- merge(
  overall_composition,
  CLASS_MAP[, .(class_code, class_label, classification_status)],
  by = "class_code",
  all.x = TRUE,
  sort = FALSE
)
overall_composition[, class_order := match(class_code, code_levels)]
setorder(overall_composition, class_order)
overall_composition[, class_order := NULL]
write_csv(
  overall_composition,
  file.path(OUT_ROOT, "03_source_tables", "12_final_overall_composition.csv")
)

donor_composition <- as.data.table(table(
  donor_id = final_metadata$donor_id,
  class_code = factor(final_metadata$class_code, levels = code_levels)
))
donor_composition[, donor_total := sum(N), by = donor_id]
donor_composition[, donor_percent := N / donor_total * 100]
donor_composition <- merge(
  donor_composition,
  CLASS_MAP[, .(class_code, class_label, classification_status)],
  by = "class_code",
  all.x = TRUE,
  sort = FALSE
)
donor_composition[, class_order := match(class_code, code_levels)]
setorder(donor_composition, donor_id, class_order)
donor_composition[, class_order := NULL]
write_csv(
  donor_composition,
  file.path(OUT_ROOT, "03_source_tables", "13_final_donor_composition.csv")
)

annotation_summary <- overall_composition[, .(
  class_code,
  class_label,
  classification_status,
  cells = N,
  percent
)]
annotation_summary <- merge(
  annotation_summary,
  CLASS_MAP[, .(class_code, cluster, interpretation_cn)],
  by = "class_code",
  all.x = TRUE,
  sort = FALSE
)
donor_validation <- donor_composition[, .(
  donors_present = sum(N > 0),
  max_donor_fraction = max(N) / sum(N),
  effective_donors = 1 / sum((N / sum(N))^2)
), by = class_code]
annotation_summary <- merge(
  annotation_summary,
  donor_validation,
  by = "class_code",
  all.x = TRUE,
  sort = FALSE
)
hallmarks <- selected_markers[order(display_order), .(
  hallmark_markers = paste(gene, collapse = ";")
), by = class_code]
annotation_summary <- merge(
  annotation_summary,
  hallmarks,
  by = "class_code",
  all.x = TRUE,
  sort = FALSE
)
annotation_summary[, class_order := match(class_code, code_levels)]
setorder(annotation_summary, class_order)
annotation_summary[, class_order := NULL]
write_csv(
  annotation_summary,
  file.path(OUT_ROOT, "03_source_tables", "14_final_class_annotation.csv")
)

stage1_markers <- fread(file.path(
  OUT_ROOT,
  "03_source_tables",
  "03_all_cluster_markers.csv.gz"
))
artifact_marker_text <- stage1_markers[
  as.character(cluster) == ARTIFACT_CLUSTER
][order(p_val_adj, -avg_log2FC), paste(head(gene, 20L), collapse = ";")]
artifact_metadata <- metadata_all[
  as.character(metadata_all$data_driven_cluster) == ARTIFACT_CLUSTER,
  ,
  drop = FALSE
]
artifact_donor_table <- sort(table(artifact_metadata$donor_id), decreasing = TRUE)
artifact_audit <- data.table(
  excluded_cluster = ARTIFACT_CLUSTER,
  cells = nrow(artifact_metadata),
  donors_present = length(artifact_donor_table),
  dominant_donor = names(artifact_donor_table)[1L],
  dominant_donor_cells = as.integer(artifact_donor_table[1L]),
  dominant_donor_fraction = as.integer(artifact_donor_table[1L]) / nrow(artifact_metadata),
  median_nFeature_RNA = median(artifact_metadata$nFeature_RNA),
  median_nCount_RNA = median(artifact_metadata$nCount_RNA),
  top_markers = artifact_marker_text,
  decision = paste(
    "excluded_post_clustering: donor-specific residual mixed-lineage",
    "signal (endothelial/epithelial/myeloid), not a fibroblast subtype"
  )
)
write_csv(
  artifact_audit,
  file.path(OUT_ROOT, "05_validation", "03_excluded_residual_artifact_cluster.csv")
)

message("[5/7] Building A, B, and C figures")
CLASS_COLORS <- c(
  FB1 = "#E76F51",
  FB2 = "#3B82B4",
  FB3 = "#D4A72C",
  FB4 = "#718C3A",
  FB5 = "#C65D8A",
  FB6 = "#4B5563"
)
legend_labels <- setNames(
  paste0(CLASS_MAP$class_code, " — ", CLASS_MAP$class_label),
  CLASS_MAP$class_code
)

umap_data <- as.data.table(final_metadata)
umap_data[, class_code := factor(as.character(class_code), levels = code_levels)]
umap_centroids <- umap_data[, .(
  UMAP_1 = median(UMAP_1),
  UMAP_2 = median(UMAP_2)
), by = class_code]

plot_a <- ggplot(umap_data, aes(x = UMAP_1, y = UMAP_2, color = class_code)) +
  geom_point(size = 0.24, alpha = 0.78, stroke = 0) +
  geom_label_repel(
    data = umap_centroids,
    aes(label = class_code),
    seed = SEED,
    size = 3.6,
    family = "sans",
    fontface = "bold",
    color = "#1F2933",
    fill = alpha("white", 0.92),
    label.size = 0.25,
    label.padding = unit(0.18, "lines"),
    min.segment.length = 0,
    segment.color = "#7B8794",
    show.legend = FALSE
  ) +
  scale_color_manual(
    values = CLASS_COLORS,
    breaks = code_levels,
    labels = legend_labels,
    drop = FALSE
  ) +
  coord_equal() +
  labs(
    title = "Strictly re-annotated healthy gingival fibroblasts",
    subtitle = paste0(
      "Lineage and high-information QC followed by donor-aware RPCA integration; ",
      "n = 10,055 cells from 13 donors"
    ),
    caption = paste0(
      "Five stable fibroblast subtypes plus one cycling cell state. ",
      "A residual mixed-lineage donor-specific cluster (n = 50) was excluded."
    ),
    x = "UMAP 1",
    y = "UMAP 2",
    color = NULL
  ) +
  guides(color = guide_legend(override.aes = list(size = 3, alpha = 1), ncol = 2)) +
  base_theme +
  theme(
    panel.grid = element_blank(),
    axis.ticks = element_blank(),
    legend.position = "bottom",
    legend.box = "vertical"
  )

overall_plot_data <- copy(overall_composition)
overall_plot_data[, class_code := factor(as.character(class_code), levels = code_levels)]
overall_plot_data[, label := ifelse(percent >= 3, sprintf("%.1f%%", percent), "")]
overall_plot_data[, text_color := ifelse(class_code == "FB3", "#1F2933", "white")]
overall_plot_data[, stack_rank := match(class_code, code_levels)]
setorder(overall_plot_data, -stack_rank)
overall_plot_data[, label_y := cumsum(percent) - percent / 2]
p_overall <- ggplot(
  overall_plot_data,
  aes(x = "Overall", y = percent, fill = class_code)
) +
  geom_col(width = 0.72, color = "white", linewidth = 0.3) +
  geom_text(
    aes(y = label_y, label = label, color = text_color),
    size = 3,
    family = "sans",
    fontface = "bold",
    show.legend = FALSE
  ) +
  scale_color_identity() +
  scale_fill_manual(values = CLASS_COLORS, breaks = code_levels, drop = FALSE) +
  scale_y_continuous(
    breaks = seq(0, 100, 20),
    labels = label_percent(scale = 1),
    expand = expansion(mult = c(0, 0))
  ) +
  coord_cartesian(ylim = c(0, 100)) +
  labs(x = NULL, y = "Cells within sample", fill = NULL) +
  base_theme +
  theme(
    panel.grid.major.x = element_blank(),
    axis.text.x = element_text(face = "bold"),
    legend.position = "none",
    plot.margin = margin(5, 5, 5, 5)
  )

donor_plot_data <- copy(donor_composition)
donor_plot_data[, class_code := factor(as.character(class_code), levels = code_levels)]
donor_levels <- sort(unique(donor_plot_data$donor_id))
donor_plot_data[, donor_id := factor(donor_id, levels = donor_levels)]
p_donor <- ggplot(
  donor_plot_data,
  aes(x = donor_id, y = donor_percent, fill = class_code)
) +
  geom_col(width = 0.78, color = "white", linewidth = 0.22) +
  scale_fill_manual(
    values = CLASS_COLORS,
    breaks = code_levels,
    labels = legend_labels,
    drop = FALSE
  ) +
  scale_y_continuous(
    breaks = seq(0, 100, 20),
    labels = label_percent(scale = 1),
    expand = expansion(mult = c(0, 0))
  ) +
  coord_cartesian(ylim = c(0, 100)) +
  labs(x = "Donor", y = NULL, fill = NULL) +
  base_theme +
  theme(
    panel.grid.major.x = element_blank(),
    axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1),
    axis.text.y = element_blank(),
    axis.ticks.y = element_blank(),
    legend.position = "bottom",
    plot.margin = margin(5, 5, 5, 5)
  ) +
  guides(fill = guide_legend(ncol = 2, byrow = TRUE))

plot_b <- (p_overall + p_donor + plot_layout(widths = c(1.15, 5.85))) +
  plot_annotation(
    title = "Fibroblast-class composition overall and by donor",
    subtitle = paste0(
      "Each bar sums to 100%; denominator is the final strictly retained fibroblast set ",
      "(n = 10,055; 13 donors)"
    ),
    caption = "Donor-level bars make donor enrichment visible; the cycling class is a state, not a stable subtype.",
    theme = theme(
      text = element_text(family = "sans", color = "#1F2933"),
      plot.title = element_text(face = "bold", size = 14),
      plot.subtitle = element_text(size = 9.5, color = "#52606D"),
      plot.caption = element_text(size = 8, color = "#7B8794", hjust = 0),
      plot.margin = margin(10, 14, 10, 10)
    )
  )

dot_data <- copy(dotplot_source)
dot_data[, class_code := factor(as.character(class_code), levels = code_levels)]
dot_data[, intended_class_code := factor(as.character(intended_class_code), levels = code_levels)]
dot_data[, marker_group := factor(
  paste0(intended_class_code, " — ", intended_class_label),
  levels = paste0(code_levels, " — ", CLASS_MAP$class_label)
)]
gene_levels <- selected_markers[order(display_order), gene]
dot_data[, gene := factor(gene, levels = rev(gene_levels))]
diagonal_tiles <- dot_data[diagonal_cell == TRUE]

plot_c <- ggplot(dot_data, aes(x = class_code, y = gene)) +
  geom_tile(
    data = diagonal_tiles,
    width = 0.94,
    height = 0.92,
    fill = "#EEF3F8",
    color = NA
  ) +
  geom_point(
    aes(size = percent_expressed, color = scaled_average_expression),
    alpha = 0.95
  ) +
  facet_grid(
    rows = vars(marker_group),
    scales = "free_y",
    space = "free_y",
    switch = "y"
  ) +
  scale_size_continuous(
    name = "% expressed",
    range = c(0.35, 5.6),
    limits = c(0, 100),
    breaks = c(25, 50, 75, 100)
  ) +
  scale_color_gradient2(
    name = "Scaled mean\nexpression",
    low = "#DCE6EF",
    mid = "#3B82B4",
    high = "#D49A24",
    midpoint = 0,
    limits = c(-2.5, 2.5),
    oob = squish
  ) +
  labs(
    title = "Diagonal marker DotPlot for the strict fibroblast solution",
    subtitle = paste0(
      "Four independent positive DE markers per class; pale cells indicate the intended marker block. ",
      "FB6 is a cycling state."
    ),
    caption = paste0(
      "Dot size: percent of cells with detected expression. Color: gene-wise scaled mean log-normalized expression. ",
      "Markers were selected after clustering and artifact exclusion."
    ),
    x = "Fibroblast class",
    y = NULL
  ) +
  base_theme +
  theme(
    panel.grid.major = element_line(color = "#EDF0F2", linewidth = 0.3),
    panel.grid.minor = element_blank(),
    axis.text.x = element_text(face = "bold", angle = 0, hjust = 0.5),
    axis.text.y = element_text(face = "italic", size = 8.5),
    strip.placement = "outside",
    strip.background = element_rect(fill = "#F7F9FB", color = "#D7DEE5", linewidth = 0.35),
    strip.text.y.left = element_text(angle = 0, face = "bold", size = 8, hjust = 1),
    panel.spacing.y = unit(0.10, "lines"),
    legend.position = "right"
  ) +
  guides(
    size = guide_legend(order = 1),
    color = guide_colorbar(order = 2, barheight = unit(3.2, "cm"))
  )

save_figure(plot_a, "A_strict_fibroblast_UMAP", width = 10.5, height = 7.8)
save_figure(plot_b, "B_fibroblast_composition_stacked_bars", width = 13.0, height = 6.9)
save_figure(plot_c, "C_diagonal_marker_DotPlot", width = 12.2, height = 11.4)

message("[6/7] Running numerical validation gates")
validation_checks <- rbindlist(list(
  data.table(
    check = "final_cell_count",
    value = ncol(final_object),
    expected = 10055,
    pass = ncol(final_object) == 10055L
  ),
  data.table(
    check = "final_class_count_including_state",
    value = nlevels(final_object$fibroblast_class),
    expected = 6,
    pass = nlevels(final_object$fibroblast_class) == 6L
  ),
  data.table(
    check = "stable_subtype_count",
    value = sum(CLASS_MAP$classification_status == "stable_fibroblast_subtype"),
    expected = 5,
    pass = sum(CLASS_MAP$classification_status == "stable_fibroblast_subtype") == 5L
  ),
  data.table(
    check = "overall_percent_sum",
    value = sum(overall_composition$percent),
    expected = 100,
    pass = abs(sum(overall_composition$percent) - 100) < 1e-8
  ),
  data.table(
    check = "donor_percent_sum_max_error",
    value = max(abs(donor_composition[, sum(donor_percent), by = donor_id]$V1 - 100)),
    expected = 0,
    pass = max(abs(donor_composition[, sum(donor_percent), by = donor_id]$V1 - 100)) < 1e-8
  ),
  data.table(
    check = "selected_marker_count",
    value = nrow(selected_markers),
    expected = 24,
    pass = nrow(selected_markers) == 24L
  ),
  data.table(
    check = "all_selected_markers_diagonal_maximum",
    value = sum(dotplot_source$diagonal_cell & dotplot_source$diagonal_maximum),
    expected = 24,
    pass = sum(dotplot_source$diagonal_cell & dotplot_source$diagonal_maximum) == 24L
  ),
  data.table(
    check = "artifact_cells_excluded",
    value = length(artifact_cells),
    expected = 50,
    pass = length(artifact_cells) == 50L
  )
), fill = TRUE)
write_csv(
  validation_checks,
  file.path(OUT_ROOT, "05_validation", "04_final_numeric_validation.csv")
)
if (!all(validation_checks$pass)) {
  stop("One or more final numerical validation gates failed")
}

write_csv(
  selected_markers[, .(
    class_code,
    class_label,
    gene,
    avg_log2FC,
    pct.1,
    pct.2,
    p_val_adj,
    diagonal_maximum_verified = TRUE
  )],
  file.path(OUT_ROOT, "05_validation", "05_selected_marker_validation.csv")
)

message("[7/7] Saving the final annotated object and figure manifest")
saveRDS(
  final_object,
  file.path(OUT_ROOT, "02_intermediate", "strict_final_annotated_fibroblasts.rds"),
  compress = FALSE
)

figure_manifest <- c(
  "A_strict_fibroblast_UMAP: UMAP of 10,055 retained cells; five stable subtypes plus one cycling state.",
  "B_fibroblast_composition_stacked_bars: overall and donor-level 100% stacked composition.",
  "C_diagonal_marker_DotPlot: four independently selected positive DE markers per class.",
  "Each figure is exported as PDF, PNG (400 dpi), and SVG.",
  "Residual artifact cluster: 50 cells excluded after post-clustering validation."
)
writeLines(
  figure_manifest,
  file.path(OUT_ROOT, "logs", "03_figure_manifest.txt"),
  useBytes = TRUE
)
message("Final figures complete: ", file.path(OUT_ROOT, "04_figures"))
