options(stringsAsFactors = FALSE)

OUT_ROOT <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260815-GSE164241\u5065\u5eb7\u7259\u9f88-\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e25\u683c\u91cd\u5206\u6790-v1"
R_LIB <- "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library"
.libPaths(c(R_LIB, .libPaths()))

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(patchwork)
  library(scales)
  library(svglite)
})

code_levels <- paste0("FB", 1:6)
CLASS_COLORS <- c(
  FB1 = "#E76F51",
  FB2 = "#3B82B4",
  FB3 = "#D4A72C",
  FB4 = "#718C3A",
  FB5 = "#C65D8A",
  FB6 = "#4B5563"
)

overall_composition <- fread(file.path(
  OUT_ROOT,
  "03_source_tables",
  "12_final_overall_composition.csv"
))
donor_composition <- fread(file.path(
  OUT_ROOT,
  "03_source_tables",
  "13_final_donor_composition.csv"
))
legend_labels <- setNames(
  paste0(
    overall_composition$class_code,
    " — ",
    overall_composition$class_label
  ),
  overall_composition$class_code
)

base_theme <- theme_minimal(base_family = "sans", base_size = 10) +
  theme(
    axis.title = element_text(face = "bold", color = "#364152"),
    axis.text = element_text(color = "#364152"),
    legend.title = element_text(face = "bold", color = "#364152"),
    legend.text = element_text(color = "#364152"),
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(color = "#E7EBEF", linewidth = 0.35)
  )

overall_plot_data <- copy(overall_composition)
overall_plot_data[, class_code := factor(as.character(class_code), levels = code_levels)]
overall_plot_data[, label := ifelse(percent >= 3, sprintf("%.1f%%", percent), "")]
overall_plot_data[, text_color := ifelse(class_code == "FB3", "#1F2933", "white")]
overall_plot_data[, stack_rank := match(class_code, code_levels)]
setorder(overall_plot_data, -stack_rank)
overall_plot_data[, label_y := cumsum(percent) - percent / 2]

p_overall <- ggplot(
  overall_plot_data,
  aes(x = "Overall", y = percent, fill = class_code)
) +
  geom_col(width = 0.72, color = "white", linewidth = 0.3) +
  geom_text(
    aes(y = label_y, label = label, color = text_color),
    size = 3,
    family = "sans",
    fontface = "bold",
    show.legend = FALSE
  ) +
  scale_color_identity() +
  scale_fill_manual(values = CLASS_COLORS, breaks = code_levels, drop = FALSE) +
  scale_y_continuous(
    breaks = seq(0, 100, 20),
    labels = label_percent(scale = 1),
    expand = expansion(mult = c(0, 0))
  ) +
  coord_cartesian(ylim = c(0, 100)) +
  labs(x = NULL, y = "Cells within sample", fill = NULL) +
  base_theme +
  theme(
    panel.grid.major.x = element_blank(),
    axis.text.x = element_text(face = "bold"),
    legend.position = "none",
    plot.margin = margin(5, 5, 5, 5)
  )

donor_plot_data <- copy(donor_composition)
donor_plot_data[, class_code := factor(as.character(class_code), levels = code_levels)]
donor_levels <- sort(unique(donor_plot_data$donor_id))
donor_plot_data[, donor_id := factor(donor_id, levels = donor_levels)]

p_donor <- ggplot(
  donor_plot_data,
  aes(x = donor_id, y = donor_percent, fill = class_code)
) +
  geom_col(width = 0.78, color = "white", linewidth = 0.22) +
  scale_fill_manual(
    values = CLASS_COLORS,
    breaks = code_levels,
    labels = legend_labels,
    drop = FALSE
  ) +
  scale_y_continuous(
    breaks = seq(0, 100, 20),
    labels = label_percent(scale = 1),
    expand = expansion(mult = c(0, 0))
  ) +
  coord_cartesian(ylim = c(0, 100)) +
  labs(x = "Donor", y = NULL, fill = NULL) +
  base_theme +
  theme(
    panel.grid.major.x = element_blank(),
    axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1),
    axis.text.y = element_blank(),
    axis.ticks.y = element_blank(),
    legend.position = "bottom",
    plot.margin = margin(5, 5, 5, 5)
  ) +
  guides(fill = guide_legend(ncol = 2, byrow = TRUE))

plot_b <- (p_overall + p_donor + patchwork::plot_layout(widths = c(1.15, 5.85))) +
  patchwork::plot_annotation(
    title = "Fibroblast-class composition overall and by donor",
    subtitle = paste0(
      "Each bar sums to 100%; denominator is the final strictly retained fibroblast set ",
      "(n = 10,055; 13 donors)"
    ),
    caption = "Donor-level bars make donor enrichment visible; the cycling class is a state, not a stable subtype.",
    theme = theme(
      text = element_text(family = "sans", color = "#1F2933"),
      plot.title = element_text(face = "bold", size = 14),
      plot.subtitle = element_text(size = 9.5, color = "#52606D"),
      plot.caption = element_text(size = 8, color = "#7B8794", hjust = 0),
      plot.margin = margin(10, 14, 10, 10)
    )
  )

figure_dir <- file.path(OUT_ROOT, "04_figures")
ggsave(
  file.path(figure_dir, "B_fibroblast_composition_stacked_bars.pdf"),
  plot_b,
  device = grDevices::cairo_pdf,
  width = 13,
  height = 6.9,
  units = "in",
  bg = "white"
)
png_device <- if (requireNamespace("ragg", quietly = TRUE)) ragg::agg_png else "png"
ggsave(
  file.path(figure_dir, "B_fibroblast_composition_stacked_bars.png"),
  plot_b,
  device = png_device,
  width = 13,
  height = 6.9,
  units = "in",
  dpi = 400,
  bg = "white"
)
ggsave(
  file.path(figure_dir, "B_fibroblast_composition_stacked_bars.svg"),
  plot_b,
  device = svglite::svglite,
  width = 13,
  height = 6.9,
  units = "in",
  bg = "white"
)

message("Corrected B figure regenerated")
