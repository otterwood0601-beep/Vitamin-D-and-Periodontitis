import pandas as pd, numpy as np, os, re, json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
BASE = 'E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260730-\u591a\u6570\u636e\u5e93-\u7259\u9f88\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e9a\u7fa4-Scissor-Figure4\u590d\u7b97/01_GSE164241/GSE164241-\u5065\u5eb7\u7259\u9f88/01_fibroblast_atlas'
OUT = 'E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260816_Figure4_\u91cd\u5206\u7c7b\u4fee\u6b63\u7248'
FIG = os.path.join(OUT, 'figures')
os.makedirs(FIG, exist_ok=True)
meta = pd.read_csv(os.path.join(BASE, '01_fibroblast_UMAP_metadata.csv.gz'))
ann = pd.read_csv(os.path.join(BASE, '06_fibroblast_subtype_annotation.csv'))
dot = pd.read_csv(os.path.join(BASE, '03_fibroblast_marker_DotPlot_source.csv'))
mark = pd.read_csv(os.path.join(BASE, '04_FindAllMarkers_fibroblast_subclusters.csv.gz'))
SUBTYPES = ['Inflammatory (CXCL+)', 'ECM-remodeling', 'Matrix-homeostatic', 'Myofibroblast/perivascular', 'Proliferative', 'Secretory/stress-response', 'Complement/immune-support']
cluster_map = {0: ('Inflammatory (CXCL+)', 'CRTAC1;CXCL13;CXCL2 -> \u708e\u75c7\u8d8b\u5316', 'Williams Fib1.1 (CXCL1/2/13)'), 6: ('Inflammatory (CXCL+)', 'CHI3L2;CCL19;CXCL2 -> \u708e\u75c7', 'Williams Fib1.1'), 2: ('ECM-remodeling', 'LUM;COL1A1;COL3A1;SPARC;POSTN -> ECM \u5408\u6210', 'Williams Fib1.2/Fib1.4'), 12: ('ECM-remodeling', '\u5f31/\u672a\u6ce8\u91ca marker\uff0c\u4f46\u540c ECM \u6a21\u5757', 'Williams Fib1.2/Fib1.4'), 3: ('Matrix-homeostatic', 'S100A6;LGALS1;CD9;IGFBP2 -> \u7a33\u6001/\u9759\u606f', 'homeostatic fibroblast'), 10: ('Matrix-homeostatic', 'PI16;TNXB;MFAP5 -> \u9759\u606f\u57fa\u8d28\u7684\u6210\u7ea4\u7ef4', 'homeostatic fibroblast'), 8: ('Myofibroblast/perivascular', 'RGS5;CDH6;TINAGL1 -> \u5468\u7ec6\u80de/\u808c\u6210\u7ea4\u7ef4', 'eLife MyFB/VFB'), 16: ('Myofibroblast/perivascular', 'MCAM;ITGA7;SYNPO2 -> \u808c\u6210\u7ea4\u7ef4', 'eLife MyFB'), 19: ('Proliferative', 'NEK2;CEP55;HMMR;ASPM -> \u6709\u4e1d\u5206\u88c2/\u7ec6\u80de\u5468\u671f', 'cycling fibroblast'), 14: ('Secretory/stress-response', 'MYOC;GREM2;ANGPTL1;CHRDL1 -> \u5206\u6ccc/\u5e94\u6fc0\uff08\u65e0 GDF15\uff09', '(\u91cd\u547d\u540d, \u539f Stress_GDF15 \u8bef\u79f0)'), 7: ('Complement/immune-support', 'APOD;CFD;CXCL12 -> \u8865\u4f53/\u514d\u75ab\u652f\u6301\uff08\u539f\u8bef\u6807 Osteogenic\uff09', 'Williams Fib1.3 (APOD/CFD)'), 1: (None, 'ZFY;KDM5D;DDX3Y;UTY;RPS4Y1;EIF1AY -> Y\u67d3\u8272\u4f53/\u6027\u522b artifact', 'REMOVE'), 4: (None, 'PLVAP;SOX17;SOX18;CLEC14A -> \u5185\u76ae\u7ec6\u80de', 'REMOVE'), 5: (None, 'S100A8;S100A9;HBB;IGKC -> \u9ad3\u7cfb/\u4e2d\u6027\u7c92\u7ec6\u80de', 'REMOVE'), 9: (None, 'IGHG4;IGHG3;IGLC2 -> \u6d46\u7ec6\u80de(B)', 'REMOVE'), 11: (None, 'CD2;CD3G;CD7;GZMA;GZMK -> T \u7ec6\u80de', 'REMOVE'), 13: (None, 'SPRR1A;MUC21;PRSS22;TMPRSS11D -> \u4e0a\u76ae', 'REMOVE'), 15: (None, 'FLT4;PROX1;MMRN1 -> \u6dcb\u5df4/\u5185\u76ae', 'REMOVE'), 17: (None, 'C1QC;C1QA;MS4A6A;CD86 -> \u5de8\u566c', 'REMOVE'), 18: (None, 'MLANA;PMEL;DCT -> \u9ed1\u7d20\u7ec6\u80de', 'REMOVE'), 20: (None, 'MYF5;PAX7;MYF6 -> \u808c\u536b\u661f\u7ec6\u80de', 'REMOVE')}

def new_subtype(cl):
    return cluster_map.get(int(cl), (None, '', 'REMOVE'))[0]
meta['new_subtype'] = meta['seurat_clusters'].apply(new_subtype)
meta['is_fibroblast'] = meta['new_subtype'].notna()
n_total = len(meta)
n_fib = int(meta['is_fibroblast'].sum())
n_removed = n_total - n_fib
print(f'\u603b\u7ec6\u80de {n_total} | \u4fdd\u7559\u6210\u7ea4\u7ef4 {n_fib} ({n_fib / n_total:.1%}) | \u79fb\u9664\u6c61\u67d3 {n_removed} ({n_removed / n_total:.1%})')
rows = []
for _, r in ann.iterrows():
    cl = int(r['cluster'])
    ns, ev, pub = cluster_map.get(cl, (None, '', 'REMOVE'))
    rows.append({'cluster': cl, 'n_cells': int(r['cells']), 'old_9state': r['best_state'], 'old_state_score': round(float(r['state_score']), 3), 'old_top_markers': r['top_markers'], 'new_subtype': ns if ns else 'REMOVED: non-fibroblast', 'evidence': ev, 'maps_to_published': pub})
map_df = pd.DataFrame(rows).sort_values('cluster')
map_df.to_csv(os.path.join(OUT, 'cluster_reannotation_table.csv'), index=False, encoding='utf-8-sig')
sub_counts = meta[meta['is_fibroblast']]['new_subtype'].value_counts().reindex(SUBTYPES).fillna(0).astype(int)
sub_prop = sub_counts / sub_counts.sum()
sub_counts.to_csv(os.path.join(OUT, 'subtype_counts.csv'), header=['n_cells'], encoding='utf-8-sig')
print('\n\u4e9a\u578b\u8ba1\u6570\uff1a')
print(sub_counts)
print('\n\u4e9a\u578b\u5360\u6bd4\uff1a')
print((sub_prop * 100).round(2))
donor_tab = pd.crosstab(meta[meta['is_fibroblast']]['donor_id'], meta[meta['is_fibroblast']]['new_subtype'])
donor_prop = donor_tab.div(donor_tab.sum(1), axis=0)
donor_prop.to_csv(os.path.join(OUT, 'subtype_proportion_by_donor.csv'), encoding='utf-8-sig')
palette = {'Inflammatory (CXCL+)': '#E4572E', 'ECM-remodeling': '#2E86AB', 'Matrix-homeostatic': '#3CB371', 'Myofibroblast/perivascular': '#8338EC', 'Proliferative': '#F4A300', 'Secretory/stress-response': '#17BEBB', 'Complement/immune-support': '#E365B8'}
GREY = '#B8B8B8'
figA, ax = plt.subplots(figsize=(9, 7.5))
removed = meta[~meta['is_fibroblast']]
ax.scatter(removed['UMAP_1'], removed['UMAP_2'], s=2, c=GREY, alpha=0.25, label='Filtered non-fibroblast', linewidths=0)
for st in SUBTYPES:
    s = meta[meta['new_subtype'] == st]
    ax.scatter(s['UMAP_1'], s['UMAP_2'], s=4, c=palette[st], alpha=0.8, label=st, linewidths=0)
ax.set_title('GSE164241 Healthy Gingiva \u2014 Reclassified Fibroblast Subtypes\n(UMAP, 10 contaminant clusters removed)', fontsize=12)
ax.set_xlabel('UMAP_1')
ax.set_ylabel('UMAP_2')
ax.tick_params(labelsize=8)
handles, labels = ax.get_legend_handles_labels()
leg = ax.legend(handles, labels, fontsize=7.5, loc='upper left', framealpha=0.9, ncol=1, markerscale=2)
plt.tight_layout()
figA.savefig(os.path.join(FIG, 'A_UMAP_reclassified.png'), dpi=200)
figA.savefig(os.path.join(FIG, 'A_UMAP_reclassified.pdf'))
plt.close(figA)
figB, axes = plt.subplots(1, 2, figsize=(13, 5.5))
ax = axes[0]
bottom = 0
for st in SUBTYPES:
    v = sub_prop[st]
    ax.bar(['Healthy\nfibroblasts'], [v], bottom=bottom, color=palette[st], label=st, edgecolor='white')
    if v > 0.03:
        ax.text(0, bottom + v / 2, f'{v * 100:.1f}%', ha='center', va='center', fontsize=8, color='white')
    bottom += v
ax.set_ylabel('Proportion within fibroblasts')
ax.set_title_sentinel = None
ax.set_title('Reclassified subtype composition\n(among retained fibroblasts, n=%d)' % n_fib, fontsize=11)
ax.set_ylim(0, 1.02)
ax.set_xticks([0])
ax.set_xticklabels(['Healthy'])
ax.legend(fontsize=7.5, loc='upper right', bbox_to_anchor=(1.32, 1), framealpha=0.9)
ax2 = axes[1]
donors = list(donor_prop.index)
x = np.arange(len(donors))
bottom = np.zeros(len(donors))
for st in SUBTYPES:
    vals = donor_prop[st].values
    ax2.bar(x, vals, bottom=bottom, color=palette[st], label=st, edgecolor='white')
    bottom += vals
ax2.set_xticks(x)
ax2.set_xticklabels(donors, rotation=45, ha='right', fontsize=7)
ax2.set_ylabel('Proportion within fibroblasts')
ax2.set_title('Subtype proportion by donor\n(donor effect not driving clusters)', fontsize=11)
ax2.set_ylim(0, 1.02)
plt.tight_layout()
figB.savefig(os.path.join(FIG, 'B_stacked_bar.png'), dpi=200, bbox_inches='tight')
figB.savefig(os.path.join(FIG, 'B_stacked_bar.pdf'), bbox_inches='tight')
plt.close(figB)
marker_panel = {'Inflammatory (CXCL+)': ['CXCL13', 'CXCL2', 'CRTAC1', 'CCL19', 'CHI3L2', 'POSTN'], 'ECM-remodeling': ['LUM', 'COL1A1', 'COL3A1', 'SPARC', 'ASPN', 'POSTN'], 'Matrix-homeostatic': ['S100A6', 'LGALS1', 'CD9', 'IGFBP2', 'PI16', 'MFAP5'], 'Myofibroblast/perivascular': ['RGS5', 'CDH6', 'MCAM', 'ITGA7', 'TINAGL1', 'SYNPO2'], 'Proliferative': ['NEK2', 'CEP55', 'HMMR', 'ASPM', 'ANLN', 'TTK'], 'Secretory/stress-response': ['MYOC', 'PCOLCE2', 'GPC3', 'CHRDL1', 'GREM2', 'ANGPTL1'], 'Complement/immune-support': ['APOD', 'CFD', 'CXCL12', 'PTGDS', 'C7', 'ABCA8']}
cluster_to_sub = {}
for cl, (ns, _, _) in cluster_map.items():
    if ns:
        cluster_to_sub[cl] = ns
agg_expr = {}
agg_pct = {}
for st in SUBTYPES:
    members = [c for c, s in cluster_to_sub.items() if s == st]
    sub_rows = dot[dot['fibroblast_subtype'].str.extract('FB(\\d+)')[0].astype('float').astype('Int64').isin(members)] if False else None
    mask = dot['fibroblast_subtype'].apply(lambda x: bool(re.match('FB(\\d+)', x)) and int(re.match('FB(\\d+)', x).group(1)) in members)
    sub = dot[mask]
    g = sub.groupby('feature')
    agg_expr[st] = g['average_expression'].mean()
    agg_pct[st] = g['percent_expressed'].mean()
genes_order = []
for st in SUBTYPES:
    for g in marker_panel[st]:
        if g not in genes_order:
            genes_order.append(g)
subtypes_col = SUBTYPES
expr_mat = pd.DataFrame({st: agg_expr[st] for st in subtypes_col}).reindex(genes_order)
pct_mat = pd.DataFrame({st: agg_pct[st] for st in subtypes_col}).reindex(genes_order)
figC, ax = plt.subplots(figsize=(10, 8))
expr_log = np.log2(expr_mat.clip(lower=0.001) + 0.001)
vmax = np.nanpercentile(expr_log.values, 98)
im = ax.imshow(expr_log.values, aspect='auto', cmap='Reds', vmin=0, vmax=vmax)
ax2 = ax.twinx() if False else None
for i, g in enumerate(genes_order):
    for j, st in enumerate(subtypes_col):
        p = pct_mat.iloc[i, j]
        if pd.notna(p) and p > 0:
            size = 6 + p / 100.0 * 40
            ax.scatter(j, i, s=size, c='none', edgecolors='black', linewidths=0.6, zorder=3)
ax.set_xticks(range(len(subtypes_col)))
ax.set_xticklabels(subtypes_col, rotation=40, ha='right', fontsize=8)
ax.set_yticks(range(len(genes_order)))
ax.set_yticklabels(genes_order, fontsize=8)
ax.set_title('Marker gene DotPlot \u2014 7 reclassified fibroblast subtypes\n(dot size = % cells expressing; color = avg log2 expression)', fontsize=11)
cbar = figC.colorbar(im, ax=ax, fraction=0.025, pad=0.02)
cbar.set_label('avg log2 expression', fontsize=8)
ax.set_xlabel('Reclassified subtype')
plt.tight_layout()
figC.savefig(os.path.join(FIG, 'C_dotplot.png'), dpi=200, bbox_inches='tight')
figC.savefig(os.path.join(FIG, 'C_dotplot.pdf'), bbox_inches='tight')
plt.close(figC)
print('\nFIGURES + TABLES WRITTEN to:', OUT)
for f in sorted(os.listdir(FIG)):
    print('  figures/', f)
