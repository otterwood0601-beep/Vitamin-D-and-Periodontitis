import pandas as pd, numpy as np, os, re
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
BASE = 'E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260730-\u591a\u6570\u636e\u5e93-\u7259\u9f88\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e9a\u7fa4-Scissor-Figure4\u590d\u7b97/01_GSE164241/GSE164241-\u5065\u5eb7\u7259\u9f88/01_fibroblast_atlas'
OUT = 'E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260816_Figure4_eLife7\u91cd\u5206\u7c7b'
FIG = os.path.join(OUT, 'figures')
os.makedirs(FIG, exist_ok=True)
meta = pd.read_csv(os.path.join(BASE, '01_fibroblast_UMAP_metadata.csv.gz'))
ann = pd.read_csv(os.path.join(BASE, '06_fibroblast_subtype_annotation.csv'))
dot = pd.read_csv(os.path.join(BASE, '03_fibroblast_marker_DotPlot_source.csv'))
mark = pd.read_csv(os.path.join(BASE, '04_FindAllMarkers_fibroblast_subclusters.csv.gz'))
SUBTYPES = ['CD81+ senescent-like fibroblasts', 'EmFB', 'P-EmB', 'MyFB', 'P-MyFB', 'VFB', 'ImFB']
cluster_map = {1: ('CD81+ senescent-like fibroblasts', 'CD81 99.3%; SERPINE1/CDKN1A high -> senescent-like', 'eLife subpop 0'), 2: ('EmFB', 'COL1A1;LUM;DCN;SPARC;POSTN -> ECM-associated', 'eLife EmFB'), 12: ('EmFB', 'COL1A1;LUM;DCN -> ECM-associated', 'eLife EmFB'), 3: ('P-EmB', 'PI16;S100A6;CFD -> pre-ECM transitional', 'eLife P-EmB'), 10: ('P-EmB', 'PI16;S100A6;CFD;MFAP5 -> pre-ECM transitional', 'eLife P-EmB'), 14: ('P-EmB', 'PCOLCE2;CFD;C7;PI16 -> pre-ECM transitional/secretory', 'eLife P-EmB'), 16: ('MyFB', 'ACTA2;MYH11;TAGLN;RGS5;PDGFRB -> myofibroblast', 'eLife MyFB'), 19: ('P-MyFB', 'MKI67;TOP2A;CEP55;HMMR;ASPM -> pre-myofibroblast/cycling', 'eLife P-MyFB'), 8: ('VFB', 'RGS5;ACTA2;TAGLN;TINAGL1 -> vascular-associated/perivascular', 'eLife VFB'), 0: ('ImFB', 'CXCL13;CXCL2;CCL19;IL33 -> immune-associated', 'eLife ImFB'), 6: ('ImFB', 'CCL19;CXCL2;IL33 -> immune-associated', 'eLife ImFB'), 7: ('ImFB', 'APOD;CFD;CXCL12;C7;CCL19 -> immune-associated/complement', 'eLife ImFB'), 4: (None, 'PLVAP;SOX17;SOX18;CLEC14A -> endothelial', 'REMOVE'), 5: (None, 'S100A8;S100A9;HBB;LYZ -> myeloid/neutrophil', 'REMOVE'), 9: (None, 'IGHG4;IGHG3;IGLC2 -> plasma B', 'REMOVE'), 11: (None, 'CD2;CD3G;CD7;GZMA -> T/NK', 'REMOVE'), 13: (None, 'SPRR1A;MUC21;PRSS22 -> epithelial', 'REMOVE'), 15: (None, 'FLT4;PROX1;MMRN1 -> lymphatic endothelial', 'REMOVE'), 17: (None, 'C1QC;C1QA;MS4A6A;CD86 -> macrophage', 'REMOVE'), 18: (None, 'MLANA;PMEL;DCT -> melanocyte', 'REMOVE'), 20: (None, 'MYF5;PAX7;MYF6 -> muscle satellite', 'REMOVE')}

def new_subtype(cl):
    return cluster_map.get(int(cl), (None, '', 'REMOVE'))[0]
meta['new_subtype'] = meta['seurat_clusters'].apply(new_subtype)
meta['is_fibroblast'] = meta['new_subtype'].notna()
n_total = len(meta)
n_fib = int(meta['is_fibroblast'].sum())
n_removed = n_total - n_fib
print(f'\u603b\u7ec6\u80de {n_total} | \u4fdd\u7559\u6210\u7ea4\u7ef4 {n_fib} ({n_fib / n_total:.1%}) | \u79fb\u9664\u6c61\u67d3 {n_removed} ({n_removed / n_total:.1%})')
rows = []
for _, r in ann.iterrows():
    cl = int(r['cluster'])
    ns, ev, pub = cluster_map.get(cl, (None, '', 'REMOVE'))
    rows.append({'cluster': cl, 'n_cells': int(r['cells']), 'old_9state': r['best_state'], 'old_state_score': round(float(r['state_score']), 3), 'old_top_markers': r['top_markers'], 'new_subtype': ns if ns else 'REMOVED: non-fibroblast', 'evidence': ev, 'maps_to_published': pub})
map_df = pd.DataFrame(rows).sort_values('cluster')
map_df.to_csv(os.path.join(OUT, 'cluster_reannotation_table_elife7.csv'), index=False, encoding='utf-8-sig')
sub_counts = meta[meta['is_fibroblast']]['new_subtype'].value_counts().reindex(SUBTYPES).fillna(0).astype(int)
sub_prop = sub_counts / sub_counts.sum()
sub_counts.to_csv(os.path.join(OUT, 'subtype_counts_elife7.csv'), header=['n_cells'], encoding='utf-8-sig')
print('\n\u4e9a\u578b\u8ba1\u6570\uff1a')
print(sub_counts)
print('\n\u4e9a\u578b\u5360\u6bd4\uff1a')
print((sub_prop * 100).round(2))
donor_tab = pd.crosstab(meta[meta['is_fibroblast']]['donor_id'], meta[meta['is_fibroblast']]['new_subtype'])
donor_prop = donor_tab.div(donor_tab.sum(1), axis=0)
donor_prop.to_csv(os.path.join(OUT, 'subtype_proportion_by_donor_elife7.csv'), encoding='utf-8-sig')
palette = {'CD81+ senescent-like fibroblasts': '#B07AA1', 'EmFB': '#2E86AB', 'P-EmB': '#66C2A5', 'MyFB': '#E4572E', 'P-MyFB': '#F4A300', 'VFB': '#8338EC', 'ImFB': '#17BEBB'}
GREY = '#B8B8B8'
figA, ax = plt.subplots(figsize=(9, 7.5))
removed = meta[~meta['is_fibroblast']]
ax.scatter(removed['UMAP_1'], removed['UMAP_2'], s=2, c=GREY, alpha=0.25, label='Filtered non-fibroblast', linewidths=0)
for st in SUBTYPES:
    s = meta[meta['new_subtype'] == st]
    if len(s):
        ax.scatter(s['UMAP_1'], s['UMAP_2'], s=5, c=palette[st], alpha=0.8, label=st, linewidths=0)
ax.set_title('GSE164241 Healthy Gingiva \u2014 eLife 7 Fibroblast Subtypes\n(UMAP, 9 contaminant clusters removed)', fontsize=12)
ax.set_xlabel('UMAP_1')
ax.set_ylabel('UMAP_2')
ax.tick_params(labelsize=8)
handles, labels = ax.get_legend_handles_labels()
leg = ax.legend(handles, labels, fontsize=7.5, loc='upper left', framealpha=0.9, ncol=1, markerscale=2)
for handle in leg.legend_handles:
    handle.set_sizes([20])
plt.tight_layout()
figA.savefig(os.path.join(FIG, 'A_UMAP_elife7.png'), dpi=200)
figA.savefig(os.path.join(FIG, 'A_UMAP_elife7.pdf'))
plt.close(figA)
figB, axes = plt.subplots(1, 2, figsize=(13, 5.5))
ax = axes[0]
bottom = 0
for st in SUBTYPES:
    v = sub_prop[st]
    if pd.isna(v):
        continue
    ax.bar(['Healthy\nfibroblasts'], [v], bottom=bottom, color=palette[st], label=st, edgecolor='white')
    if v > 0.03:
        ax.text(0, bottom + v / 2, f'{v * 100:.1f}%', ha='center', va='center', fontsize=8, color='white')
    bottom += v
ax.set_ylabel('Proportion within fibroblasts')
ax.set_title('eLife 7 subtype composition\n(among retained fibroblasts, n=%d)' % n_fib, fontsize=11)
ax.set_ylim(0, 1.02)
ax.set_xticks([0])
ax.set_xticklabels(['Healthy'])
ax.legend(fontsize=7.5, loc='upper right', bbox_to_anchor=(1.42, 1), framealpha=0.9)
ax2 = axes[1]
donors = list(donor_prop.index)
x = np.arange(len(donors))
bottom = np.zeros(len(donors))
for st in SUBTYPES:
    vals = donor_prop[st].values
    ax2.bar(x, vals, bottom=bottom, color=palette[st], label=st, edgecolor='white')
    bottom += vals
ax2.set_xticks(x)
ax2.set_xticklabels(donors, rotation=45, ha='right', fontsize=7)
ax2.set_ylabel('Proportion within fibroblasts')
ax2.set_title('eLife 7 subtype proportion by donor\n(donor effect not driving clusters)', fontsize=11)
ax2.set_ylim(0, 1.02)
plt.tight_layout()
figB.savefig(os.path.join(FIG, 'B_stacked_bar_elife7.png'), dpi=200, bbox_inches='tight')
figB.savefig(os.path.join(FIG, 'B_stacked_bar_elife7.pdf'), bbox_inches='tight')
plt.close(figB)
marker_panel = {'CD81+ senescent-like fibroblasts': ['CD81', 'SERPINE1', 'CDKN1A', 'CDKN2A', 'GLB1', 'GDF15'], 'EmFB': ['COL1A1', 'LUM', 'DCN', 'COL3A1', 'SPARC', 'POSTN'], 'P-EmB': ['PI16', 'S100A6', 'CFD', 'PTGDS', 'MFAP5', 'TNXB'], 'MyFB': ['ACTA2', 'MYH11', 'TAGLN', 'RGS5', 'PDGFRB', 'SYNPO2'], 'P-MyFB': ['MKI67', 'TOP2A', 'CEP55', 'ASPM', 'ANLN', 'TTK'], 'VFB': ['RGS5', 'ACTA2', 'TAGLN', 'CDH6', 'TINAGL1', 'MCAM'], 'ImFB': ['CXCL13', 'CCL19', 'IL33', 'APOD', 'CFD', 'CD69']}
cluster_to_sub = {cl: ns for cl, (ns, _, _) in cluster_map.items() if ns}

def cluster_members(st):
    return [c for c, s in cluster_to_sub.items() if s == st]

def gene_values(gene, st):
    members = cluster_members(st)

    def in_members(x):
        m = re.match('FB(\\d+)', x)
        return bool(m) and int(m.group(1)) in members
    src = dot[(dot['feature'] == gene) & dot['fibroblast_subtype'].apply(in_members)]
    if len(src):
        return (float(src['average_expression'].mean()), float(src['percent_expressed'].mean()), 'dot')
    sub = mark[(mark['gene'].str.upper() == gene.upper()) & mark['cluster'].isin(members)]
    if len(sub):
        weights = []
        for c in sub['cluster']:
            cells = ann.loc[ann['cluster'] == c, 'cells']
            weights.append(int(cells.values[0]) if len(cells) else 1)
        lfc = np.average(sub['avg_log2FC'].values, weights=weights)
        pct = np.average(sub['pct.1'].values, weights=weights) * 100
        return (float(lfc), float(pct), 'DE')
    return (np.nan, np.nan, 'none')
genes_order = []
for st in SUBTYPES:
    for g in marker_panel[st]:
        if g not in genes_order:
            genes_order.append(g)
expr_mat = pd.DataFrame(index=genes_order, columns=SUBTYPES, dtype=float)
pct_mat = pd.DataFrame(index=genes_order, columns=SUBTYPES, dtype=float)
src_mat = pd.DataFrame(index=genes_order, columns=SUBTYPES, dtype=object)
for st in SUBTYPES:
    for g in marker_panel[st]:
        avg, pct, typ = gene_values(g, st)
        expr_mat.loc[g, st] = avg
        pct_mat.loc[g, st] = pct
        src_mat.loc[g, st] = typ
expr_display = pd.DataFrame(index=genes_order, columns=SUBTYPES, dtype=float)
for st in SUBTYPES:
    for g in genes_order:
        v = expr_mat.loc[g, st]
        if pd.isna(v):
            continue
        if src_mat.loc[g, st] == 'DE':
            expr_display.loc[g, st] = max(0.0, v)
        else:
            expr_display.loc[g, st] = np.log2(v + 0.001)
figC, ax = plt.subplots(figsize=(10, 8.5))
vmax = np.nanpercentile(expr_display.values, 98)
im = ax.imshow(expr_display.values, aspect='auto', cmap='Reds', vmin=0, vmax=vmax)
for i, g in enumerate(genes_order):
    for j, st in enumerate(SUBTYPES):
        p = pct_mat.iloc[i, j]
        if pd.notna(p) and p > 0:
            size = 6 + p / 100.0 * 40
            ax.scatter(j, i, s=size, c='none', edgecolors='black', linewidths=0.6, zorder=3)
ax.set_xticks(range(len(SUBTYPES)))
ax.set_xticklabels(SUBTYPES, rotation=40, ha='right', fontsize=8)
ax.set_yticks(range(len(genes_order)))
ax.set_yticklabels(genes_order, fontsize=8)
ax.set_title('eLife 7 subtype marker DotPlot\n(dot size = % cells expressing; color = normalized expression/log2FC)', fontsize=11)
cbar = figC.colorbar(im, ax=ax, fraction=0.025, pad=0.02)
cbar.set_label('normalized expression / log2FC', fontsize=8)
ax.set_xlabel('eLife 7 subtype')
plt.tight_layout()
figC.savefig(os.path.join(FIG, 'C_dotplot_elife7.png'), dpi=200, bbox_inches='tight')
figC.savefig(os.path.join(FIG, 'C_dotplot_elife7.pdf'), bbox_inches='tight')
plt.close(figC)
report = f'# Figure4 eLife 96908 7 \u4e9a\u7fa4\u91cd\u5206\u7c7b\u62a5\u544a\n\n## 1. \u6570\u636e\u8303\u56f4\n- \u4ec5\u4f7f\u7528 GSE164241 \u5065\u5eb7\u7259\u9f88\u6210\u7ea4\u7ef4\u7ec6\u80de\uff08\u539f 20260730 pipeline \u5bfc\u51fa\uff09\u3002\n- \u603b\u7ec6\u80de {n_total}\uff1b\u4fdd\u7559\u6210\u7ea4\u7ef4\u7ec6\u80de {n_fib} ({n_fib / n_total:.1%})\uff1b\u79fb\u9664\u6c61\u67d3 {n_removed} ({n_removed / n_total:.1%})\u3002\n\n## 2. eLife 7 \u4e9a\u7fa4\u6620\u5c04\uff0821 \u7c07 \u2192 7 \u7c7b\uff09\n\n| cluster | \u539f 9-state \u6807\u7b7e | eLife \u65b0\u6807\u7b7e | \u4f9d\u636e |\n|---|---|---|---|\n'
for _, r in map_df.iterrows():
    report += f"| {int(r['cluster'])} | {r['old_9state']} | {r['new_subtype']} | {r['evidence']} |\n"
report += f'\n## 3. \u8ba1\u6570\u4e0e\u5360\u6bd4\n\n| eLife \u4e9a\u578b | \u7ec6\u80de\u6570 | \u5360\u4fdd\u7559\u6210\u7ea4\u7ef4\u6bd4\u4f8b |\n|---|---|---|\n'
for st in SUBTYPES:
    report += f'| {st} | {sub_counts[st]} | {sub_prop[st] * 100:.2f}% |\n'
report += f'\n## 4. \u4e0e\u539f 9-state \u7684\u5173\u952e\u5dee\u522b\n- **FB1 (cluster 1)**\uff1a\u539f\u6807 "Perivascular adventitial"\uff0c\u4f9d\u636e Y \u67d3\u8272\u4f53\u57fa\u56e0\uff1b\u5b9e\u9645 CD81 \u8868\u8fbe\u6700\u9ad8\uff0899.3% \u7ec6\u80de\uff0clog2FC=2.42\uff09\uff0c\u4e14 SERPINE1/CDKN1A \u9ad8\uff0c\u5e94\u5f52\u4e3a **CD81+ senescent-like fibroblasts**\uff08eLife subpop 0\uff09\u3002\n- **FB7 (cluster 7)**\uff1a\u539f\u6807 "Osteogenic_MSC"\uff0c\u4f46\u65e0\u9aa8/\u8f6f\u9aa8 marker\uff1b\u5b9e\u9645 APOD/CFD/C7/CXCL12 \u9ad8\uff0c\u5e94\u5f52\u4e3a **ImFB**\uff08\u514d\u75ab\u76f8\u5173/\u8865\u4f53\u652f\u6301\uff0c\u5bf9\u5e94 Williams Fib1.3\uff09\u3002\n- **FB14 (cluster 14)**\uff1a\u539f\u6807 "Stress_GDF15"\uff0c\u4f46 GDF15 \u51e0\u4e4e\u4e0d\u8868\u8fbe\uff1b\u5b9e\u9645 PI16/CFD/C7/PCOLCE2 \u9ad8\uff0c\u5e94\u5f52\u4e3a **P-EmB**\uff08\u524d\u4f53/\u8fc7\u6e21\u6001\uff09\u3002\n- **FB16 (cluster 16)**\uff1a\u539f\u6807 "Myofibroblast"\uff0cMYH11/ACTA2/TAGLN \u6700\u9ad8\uff0c\u7ef4\u6301 **MyFB**\u3002\n- **FB8 (cluster 8)**\uff1aRGS5/ACTA2/TAGLN \u9ad8\uff0cMYH11 \u76f8\u5bf9\u4f4e\uff0c\u5f52\u5165 **VFB**\uff08vascular-associated/perivascular\uff09\u3002\n- **FB19 (cluster 19)**\uff1a\u9ad8\u589e\u6b96\uff08MKI67/TOP2A\uff09\uff0c\u5f52\u5165 **P-MyFB**\uff08\u8fc7\u6e21\u6001\uff09\u3002\n\n## 5. \u5c40\u9650\u8bf4\u660e\n- \u672c\u91cd\u5206\u7c7b\u57fa\u4e8e\u539f 21 \u7c07\u7684\u5df2\u5bfc\u51fa\u5dee\u5f02\u57fa\u56e0\u548c UMAP \u5750\u6807\uff0c**\u672a\u4ece\u539f\u59cb\u77e9\u9635\u91cd\u65b0\u8dd1\u805a\u7c7b/Silhouette**\u3002\n- eLife 96908 \u7684 7 \u4e9a\u7fa4\u662f\u57fa\u4e8e\u5176\u81ea\u8eab\u805a\u7c7b\uff08subpop 0-6\uff09\u5e76\u914d\u5408 GO \u5206\u6790\u547d\u540d\u7684\uff1b\u672c\u6587\u53ea\u662f\u5c06\u672c\u5730 21 \u7c07\u6309 marker \u76f8\u4f3c\u6027\u6620\u5c04\u5230\u8be5\u6846\u67b6\uff0c\u5c5e\u4e8e"\u8fd1\u4f3c\u590d\u523b"\u800c\u975e\u9010\u7ec6\u80de\u7cbe\u786e\u8fd8\u539f\u3002\n- \u7279\u522b\u5730\uff0c**VFB \u4e0e P-MyFB \u7684\u8fb9\u754c\u5728\u672c\u5730\u6570\u636e\u4e2d\u8f83\u6a21\u7cca**\uff1aFB8/FB16 \u5747\u542b RGS5/ACTA2/TAGLN\uff1b\u5f53\u524d\u5206\u914d\u4ee5 MYH11 \u548c\u589e\u6b96\u6307\u6570\u4f5c\u533a\u5206\u3002\n- FB1 \u540c\u65f6\u9ad8\u8868\u8fbe Y \u67d3\u8272\u4f53\u57fa\u56e0\uff0c\u63d0\u793a\u8be5\u7c07\u53ef\u80fd\u53d7\u7537\u6027\u6837\u672c\u9a71\u52a8\uff1b\u4f46\u56e0 CD81/SERPINE1/CDKN1A \u540c\u6b65\u5bcc\u96c6\uff0c\u4ecd\u6309 eLife \u6846\u67b6\u89e3\u91ca\u4e3a CD81+ \u8870\u8001\u6837\u6210\u7ea4\u7ef4\u3002\n\n## 6. \u8f93\u51fa\u6587\u4ef6\n- `figures/A_UMAP_elife7.pdf(.png)`\n- `figures/B_stacked_bar_elife7.pdf(.png)`\n- `figures/C_dotplot_elife7.pdf(.png)`\n- `cluster_reannotation_table_elife7.csv`\n- `subtype_counts_elife7.csv`\n- `subtype_proportion_by_donor_elife7.csv`\n'
with open(os.path.join(OUT, 'reclassification_report_elife7.md'), 'w', encoding='utf-8') as f:
    f.write(report)
print('\nFIGURES + TABLES WRITTEN to:', OUT)
for f in sorted(os.listdir(FIG)):
    print('  figures/', f)
