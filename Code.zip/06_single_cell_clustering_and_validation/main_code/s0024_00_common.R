options(stringsAsFactors = FALSE)
options(future.globals.maxSize = 32 * 1024^3)
set.seed(42)

if (.Platform$OS.type == "windows") {
  try(Sys.setlocale("LC_CTYPE", ".UTF-8"), silent = TRUE)
}

configure_runtime <- function(main_root) {
  task_lib <- file.path(main_root, "00_\u4ee3\u7801\u4e0e\u5ba1\u8ba1", "R_library_runtime")
  library_candidates <- c(
    task_lib,
    "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_Seurat4",
    "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_raw",
    "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_enrichment",
    "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_stage11",
    .libPaths()
  )
  library_candidates <- unique(library_candidates[dir.exists(library_candidates)])
  .libPaths(library_candidates)

  suppressPackageStartupMessages({
    library(Seurat)
    library(Matrix)
    library(data.table)
    library(ggplot2)
    library(patchwork)
    library(harmony)
    library(rhdf5)
    library(AnnotationDbi)
    library(org.Hs.eg.db)
    library(GO.db)
    library(jsonlite)
    library(scales)
  })
  invisible(library_candidates)
}

assert_file <- function(path, label = basename(path)) {
  if (!file.exists(path)) stop(label, " not found: ", path)
  invisible(path)
}

assert_dir <- function(path, label = basename(path)) {
  if (!dir.exists(path)) stop(label, " not found: ", path)
  invisible(path)
}

decode_h5ad_categorical <- function(h5ad, column) {
  base <- paste0("/obs/", column)
  categories <- h5read(h5ad, paste0(base, "/categories"))
  codes <- as.integer(h5read(h5ad, paste0(base, "/codes")))
  out <- rep(NA_character_, length(codes))
  ok <- !is.na(codes) & codes >= 0L
  out[ok] <- categories[codes[ok] + 1L]
  out
}

read_h5ad_obs <- function(h5ad) {
  index <- h5read(h5ad, "/obs/_index")
  data.frame(
    h5ad_index = index,
    Study = decode_h5ad_categorical(h5ad, "Study"),
    sample_id = decode_h5ad_categorical(h5ad, "Sample ID"),
    donor_id = decode_h5ad_categorical(h5ad, "donor_id"),
    disease = decode_h5ad_categorical(h5ad, "disease"),
    cell_type = decode_h5ad_categorical(h5ad, "cell_type"),
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

read_h5ad_feature_symbols <- function(h5ad) {
  categories <- h5read(h5ad, "/raw/var/feature_name/categories")
  codes <- as.integer(h5read(h5ad, "/raw/var/feature_name/codes"))
  symbols <- categories[codes + 1L]
  if (anyNA(symbols) || any(symbols == "")) {
    stop("Missing feature symbols in /raw/var/feature_name")
  }
  make.unique(symbols, sep = ".")
}

split_contiguous_runs <- function(rows) {
  rows <- sort(unique(as.integer(rows)))
  if (!length(rows)) return(list())
  run_id <- cumsum(c(TRUE, diff(rows) != 1L))
  unname(split(rows, run_id))
}

extract_h5ad_csr_rows <- function(h5ad, rows, feature_names, group = "/raw/X") {
  rows <- sort(unique(as.integer(rows)))
  if (!length(rows)) stop("No H5AD rows selected")
  indptr <- as.numeric(h5read(h5ad, paste0(group, "/indptr")))
  n_cells <- length(indptr) - 1L
  if (min(rows) < 1L || max(rows) > n_cells) stop("Selected row outside H5AD bounds")

  runs <- split_contiguous_runs(rows)
  i_parts <- vector("list", length(runs))
  j_parts <- vector("list", length(runs))
  x_parts <- vector("list", length(runs))
  selected_offset <- 0L

  for (r in seq_along(runs)) {
    run <- runs[[r]]
    start_row <- min(run)
    end_row <- max(run)
    ptr <- indptr[start_row:(end_row + 1L)]
    lens <- diff(ptr)
    nnz <- sum(lens)
    if (nnz > 0) {
      first <- ptr[1] + 1
      data_part <- h5read(
        h5ad,
        paste0(group, "/data"),
        start = first,
        count = nnz
      )
      index_part <- h5read(
        h5ad,
        paste0(group, "/indices"),
        start = first,
        count = nnz
      )
      i_parts[[r]] <- as.integer(index_part) + 1L
      j_parts[[r]] <- rep.int(
        seq.int(selected_offset + 1L, selected_offset + length(run)),
        lens
      )
      x_parts[[r]] <- as.numeric(data_part)
    } else {
      i_parts[[r]] <- integer()
      j_parts[[r]] <- integer()
      x_parts[[r]] <- numeric()
    }
    selected_offset <- selected_offset + length(run)
    message(
      sprintf(
        "H5AD raw.X run %d/%d: rows %d-%d, cells=%d, nnz=%s",
        r, length(runs), start_row, end_row, length(run),
        format(nnz, big.mark = ",", scientific = FALSE)
      )
    )
  }

  i <- unlist(i_parts, use.names = FALSE)
  j <- unlist(j_parts, use.names = FALSE)
  x <- unlist(x_parts, use.names = FALSE)
  if (length(x) && max(abs(x - round(x))) > 1e-6) {
    warning("raw.X contains non-integer values; retaining numeric values")
  }
  mat <- sparseMatrix(
    i = i,
    j = j,
    x = x,
    dims = c(length(feature_names), length(rows)),
    dimnames = list(feature_names, NULL),
    giveCsparse = TRUE
  )
  rm(i_parts, j_parts, x_parts, i, j, x)
  gc(verbose = FALSE)
  mat
}

reference_palette_9 <- c(
  "#D95F5F", "#7B61A8", "#E69F00", "#56B4E9", "#9C5D50",
  "#1F83B4", "#00A087", "#F4E43A", "#6A994E"
)

palette_n <- function(n) {
  if (n <= length(reference_palette_9)) return(reference_palette_9[seq_len(n)])
  grDevices::hcl.colors(n, palette = "Dynamic")
}

theme_submission <- function(base_size = 11) {
  theme_classic(base_size = base_size, base_family = "Arial") +
    theme(
      text = element_text(colour = "#1A1A1A"),
      axis.text = element_text(colour = "#333333"),
      plot.title = element_text(face = "bold", hjust = 0, size = rel(1.15)),
      plot.subtitle = element_text(colour = "#555555", margin = margin(b = 8)),
      legend.title = element_text(face = "bold"),
      legend.key = element_blank()
    )
}

save_pdf <- function(plot, path, width, height) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  ggsave(
    filename = path,
    plot = plot,
    width = width,
    height = height,
    units = "in",
    device = grDevices::cairo_pdf,
    limitsize = FALSE
  )
  if (!file.exists(path) || file.info(path)$size < 5000) {
    stop("PDF was not created correctly: ", path)
  }
  invisible(path)
}

write_table <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  fwrite(as.data.table(x), path)
  invisible(path)
}

write_session_info <- function(path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  writeLines(capture.output(sessionInfo()), con = path, useBytes = TRUE)
  invisible(path)
}

standardize_gene_symbol <- function(x) {
  sub("\\.[0-9]+$", "", as.character(x))
}

dotplot_stats <- function(object, feature_keys, group_col) {
  stopifnot(all(c("key", "gene") %in% names(feature_keys)))
  groups <- as.character(object[[group_col]][, 1])
  group_levels <- levels(object[[group_col]][, 1])
  if (is.null(group_levels)) group_levels <- unique(groups)
  present <- feature_keys$gene %in% rownames(object)
  feature_keys <- feature_keys[present, , drop = FALSE]
  if (!nrow(feature_keys)) stop("No requested DotPlot genes are present")
  genes <- unique(feature_keys$gene)
  counts <- GetAssayData(object, assay = "RNA", slot = "counts")[genes, , drop = FALSE]
  norm <- GetAssayData(object, assay = "RNA", slot = "data")[genes, , drop = FALSE]

  avg <- matrix(NA_real_, nrow = length(genes), ncol = length(group_levels),
                dimnames = list(genes, group_levels))
  pct <- avg
  for (g in seq_along(group_levels)) {
    cells <- which(groups == group_levels[g])
    avg[, g] <- Matrix::rowMeans(norm[, cells, drop = FALSE])
    pct[, g] <- Matrix::rowMeans(counts[, cells, drop = FALSE] > 0) * 100
  }
  scaled <- t(scale(t(avg)))
  scaled[!is.finite(scaled)] <- 0
  scaled[scaled < -2] <- -2
  scaled[scaled > 2] <- 2

  base <- CJ(gene = genes, group = group_levels, unique = TRUE)
  base[, avg_exp := as.numeric(avg[cbind(match(gene, genes), match(group, group_levels))])]
  base[, pct_exp := as.numeric(pct[cbind(match(gene, genes), match(group, group_levels))])]
  base[, scaled_avg := as.numeric(scaled[cbind(match(gene, genes), match(group, group_levels))])]
  keyed <- merge(as.data.table(feature_keys), base, by = "gene", allow.cartesian = TRUE)
  keyed[]
}

plot_diagonal_dot <- function(dot_data, key_levels, group_levels,
                              x_title, y_title, title, subtitle,
                              key_labels = NULL, width_hint = 14) {
  dot_data$key <- factor(dot_data$key, levels = key_levels)
  dot_data$group <- factor(dot_data$group, levels = rev(group_levels))
  if (is.null(key_labels)) key_labels <- setNames(key_levels, key_levels)
  ggplot(dot_data, aes(x = key, y = group)) +
    geom_point(aes(size = pct_exp, fill = scaled_avg), shape = 21,
               colour = "#3A3A3A", stroke = 0.18) +
    scale_size_continuous(range = c(0.5, 6), limits = c(0, 100),
                          breaks = c(25, 50, 75, 100), name = "Percent expressed") +
    scale_fill_gradient2(
      low = "#4169B1", mid = "#F4F4F4", high = "#C51B2D", midpoint = 0,
      limits = c(-2, 2), name = "Scaled average\nexpression"
    ) +
    scale_x_discrete(labels = key_labels, drop = FALSE) +
    labs(x = x_title, y = y_title, title = title, subtitle = subtitle) +
    theme_submission(10) +
    theme(
      axis.text.x = element_text(angle = 70, hjust = 1, vjust = 1),
      axis.ticks = element_blank(),
      axis.line = element_blank(),
      panel.grid.major = element_line(colour = "#EEEEEE", linewidth = 0.25),
      legend.position = "right"
    )
}

build_go_bp_map <- function(cache_path) {
  if (file.exists(cache_path)) return(readRDS(cache_path))
  message("Building GO BP background map from org.Hs.eg.db ...")
  all_entrez <- AnnotationDbi::keys(org.Hs.eg.db, keytype = "ENTREZID")
  go_map <- suppressMessages(AnnotationDbi::select(
    org.Hs.eg.db,
    keys = all_entrez,
    columns = c("GO", "ONTOLOGY"),
    keytype = "ENTREZID"
  ))
  go_map <- unique(go_map[
    !is.na(go_map$GO) & go_map$ONTOLOGY == "BP",
    c("ENTREZID", "GO")
  ])
  saveRDS(go_map, cache_path, compress = TRUE)
  go_map
}

map_symbols_to_entrez <- function(symbols) {
  symbols <- unique(standardize_gene_symbol(symbols))
  suppressMessages(AnnotationDbi::select(
    org.Hs.eg.db,
    keys = symbols,
    columns = "ENTREZID",
    keytype = "SYMBOL"
  ))
}

enrich_go_bp_by_cluster <- function(filtered_markers, go_map) {
  if (!nrow(filtered_markers)) return(data.frame())
  symbol_map <- map_symbols_to_entrez(filtered_markers$gene_symbol)
  marker_map <- merge(
    as.data.table(filtered_markers),
    as.data.table(symbol_map),
    by.x = "gene_symbol",
    by.y = "SYMBOL",
    allow.cartesian = TRUE
  )
  marker_map <- marker_map[!is.na(ENTREZID)]
  universe <- unique(go_map$ENTREZID)
  bg_counts <- table(go_map$GO)
  M <- length(universe)

  out <- vector("list", length(unique(marker_map$cluster)))
  clusters <- sort(unique(as.character(marker_map$cluster)))
  for (idx in seq_along(clusters)) {
    cl <- clusters[idx]
    genes <- intersect(unique(marker_map[as.character(cluster) == cl, ENTREZID]), universe)
    if (length(genes) < 3L) next
    hits <- table(go_map$GO[go_map$ENTREZID %in% genes])
    go_ids <- names(hits)
    k <- as.integer(hits)
    m <- as.integer(bg_counts[go_ids])
    n <- length(genes)
    p <- phyper(k - 1L, m, M - m, n, lower.tail = FALSE)
    descriptions <- AnnotationDbi::Term(GO.db::GOTERM[go_ids])
    out[[idx]] <- data.frame(
      cluster = cl,
      ID = go_ids,
      Description = unname(descriptions),
      GeneRatio = paste0(k, "/", n),
      BgRatio = paste0(m, "/", M),
      Count = k,
      pvalue = p,
      p.adjust = p.adjust(p, method = "BH"),
      stringsAsFactors = FALSE
    )
  }
  ans <- rbindlist(out, fill = TRUE)
  if (nrow(ans)) setorder(ans, cluster, p.adjust, -Count)
  as.data.frame(ans)
}

select_diagonal_go <- function(go_table, cluster_levels, n_per_cluster = 3L) {
  if (!nrow(go_table)) return(data.frame())
  dt <- as.data.table(go_table)
  dt <- dt[!is.na(Description) & Description != ""]
  occurrence <- dt[p.adjust < 0.05, .(n_clusters = uniqueN(cluster)), by = ID]
  dt <- merge(dt, occurrence, by = "ID", all.x = TRUE)
  dt[is.na(n_clusters), n_clusters := max(2L, uniqueN(cluster))]
  dt[, specificity_score := -log10(pmax(p.adjust, 1e-300)) - 0.35 * (n_clusters - 1)]
  selected <- vector("list", length(cluster_levels))
  for (i in seq_along(cluster_levels)) {
    cl <- cluster_levels[i]
    cand <- dt[as.character(cluster) == cl & p.adjust < 0.05]
    if (!nrow(cand)) cand <- dt[as.character(cluster) == cl]
    setorder(cand, -specificity_score, p.adjust, -Count)
    selected[[i]] <- head(cand, n_per_cluster)
  }
  ans <- unique(rbindlist(selected, fill = TRUE), by = c("cluster", "ID"))
  ans[, term_key := paste0("C", cluster, "__", ID)]
  ans[]
}

fibroblast_signatures <- list(
  `CD81+ senescent-like FB` = c("CD81", "GDF15", "C3", "ATF3", "FOS", "JUN", "DDIT3", "IER3"),
  EmFB = c("COL1A1", "COL1A2", "COL3A1", "COL6A1", "COL6A2", "DCN", "LUM", "SPARC"),
  `P-EmFB` = c("DPT", "PI16", "COL15A1", "CFD", "APOD", "C7", "CLEC3B"),
  MyFB = c("ACTA2", "TAGLN", "MYL9", "TPM2", "CNN1", "CALD1"),
  `P-MyFB` = c("POSTN", "ASPN", "CTHRC1", "TNC", "FAP", "THY1"),
  VFB = c("RGS5", "MCAM", "CSPG4", "RBP1", "COL4A1", "COL4A2", "NOTCH3", "PDGFRB"),
  ImFB = c("CXCL1", "CXCL2", "CXCL3", "CXCL8", "IL6", "CCL2", "CCL19", "TNFAIP6", "ICAM1"),
  `Cycling FB` = c("MKI67", "TOP2A", "UBE2C", "CENPF", "HMGB2", "TYMS", "STMN1", "PTTG1", "PCLAF", "PBK", "TK1", "CDKN3"),
  `WNT-regulatory FB` = c("F13A1", "TNFRSF11B", "IGFBP2", "APCDD1", "RDH10", "COMP", "SLC5A3", "DIO2", "MRPS6", "DKK3"),
  `Ig-high FB (low-confidence)` = c("IGLC2", "IGKC", "IGHG4", "IGHG3", "HBB", "FDCSP", "S100A8"),
  `Osteogenic-like FB` = c("ALPL", "RUNX2", "SPP1", "BGLAP", "IBSP", "COL11A1")
)

fibroblast_go_patterns <- list(
  `CD81+ senescent-like FB` = "senesc|cellular stress|oxidative stress|apopt|unfolded protein|response to stress",
  EmFB = "extracellular matrix|collagen|matrix organization|matrix assembly",
  `P-EmFB` = "matrix homeostasis|connective tissue|mesenchym|tissue development|extracellular structure",
  MyFB = "muscle contraction|actin filament|smooth muscle|contractile|cell contraction",
  `P-MyFB` = "wound healing|tgf|fibroblast activation|cell migration|tissue remodeling",
  VFB = "vascul|angiogen|blood vessel|circulatory|perivascular",
  ImFB = "cytokine|chemokine|immune response|leukocyte|inflammatory|neutrophil",
  `Cycling FB` = "cell cycle|mitotic|dna replication|chromosome segregation|nuclear division",
  `WNT-regulatory FB` = "wnt signaling|cell population proliferation|development|growth",
  `Ig-high FB (low-confidence)` = "immunoglobulin|b cell receptor|adaptive immune|erythrocyte",
  `Osteogenic-like FB` = "ossification|osteoblast|bone|skeletal|mineralization"
)

fibroblast_label_cn <- c(
  `CD81+ senescent-like FB` = "CD81\u9633\u6027\u8870\u8001\u6837\u6210\u7ea4\u7ef4\u7ec6\u80de",
  EmFB = "\u7ec6\u80de\u5916\u57fa\u8d28\u76f8\u5173\u6210\u7ea4\u7ef4\u7ec6\u80de",
  `P-EmFB` = "\u524d\u4f53/\u8fc7\u6e21\u6001\u7ec6\u80de\u5916\u57fa\u8d28\u76f8\u5173\u6210\u7ea4\u7ef4\u7ec6\u80de",
  MyFB = "\u808c\u6210\u7ea4\u7ef4\u7ec6\u80de",
  `P-MyFB` = "\u524d\u4f53/\u8fc7\u6e21\u6001\u808c\u6210\u7ea4\u7ef4\u7ec6\u80de",
  VFB = "\u8840\u7ba1\u76f8\u5173\u6210\u7ea4\u7ef4\u7ec6\u80de",
  ImFB = "\u514d\u75ab\u76f8\u5173\u6210\u7ea4\u7ef4\u7ec6\u80de",
  `Cycling FB` = "\u589e\u6b96\u578b\u6210\u7ea4\u7ef4\u7ec6\u80de",
  `WNT-regulatory FB` = "WNT\u8c03\u63a7\u578b\u6210\u7ea4\u7ef4\u7ec6\u80de",
  `Ig-high FB (low-confidence)` = "\u514d\u75ab\u7403\u86cb\u767d\u9ad8\u8868\u8fbe\u6210\u7ea4\u7ef4\u7ec6\u80de\uff08\u4f4e\u7f6e\u4fe1\u5ea6\uff09",
  `Mixed non-cycling FB` = "\u6df7\u5408\u578b\u975e\u589e\u6b96\u6210\u7ea4\u7ef4\u7ec6\u80de",
  `Mixed immune-remodeling FB` = "\u514d\u75ab-\u7ec4\u7ec7\u91cd\u5851\u6df7\u5408\u578b\u6210\u7ea4\u7ef4\u7ec6\u80de",
  `ImFB-CCL19` = "CCL19\u578b\u514d\u75ab\u76f8\u5173\u6210\u7ea4\u7ef4\u7ec6\u80de",
  `ImFB-CXCL8` = "CXCL8\u578b\u514d\u75ab\u76f8\u5173\u6210\u7ea4\u7ef4\u7ec6\u80de",
  `VFB (angiogenic/inflammatory)` = "\u8840\u7ba1\u751f\u6210-\u708e\u75c7\u76f8\u5173\u6210\u7ea4\u7ef4\u7ec6\u80de",
  `P-MyFB (Ig-high mixed)` = "\u514d\u75ab\u7403\u86cb\u767d\u504f\u9ad8\u7684\u524d\u4f53\u808c\u6210\u7ea4\u7ef4\u7ec6\u80de",
  `Osteogenic-like FB` = "\u6210\u9aa8\u6837\u95f4\u5145\u8d28\u6210\u7ea4\u7ef4\u7ec6\u80de"
)

auto_name_fibroblast_clusters <- function(object, cluster_levels, markers, go_table) {
  signature_genes <- unique(unlist(fibroblast_signatures))
  signature_genes <- intersect(signature_genes, rownames(object))
  if (!length(signature_genes)) stop("No fibroblast signature genes present")

  avg <- AverageExpression(
    object,
    assays = "RNA",
    features = signature_genes,
    group.by = "cluster_key",
    slot = "data",
    verbose = FALSE
  )$RNA
  avg <- as.matrix(avg)
  z <- t(scale(t(avg)))
  z[!is.finite(z)] <- 0

  score <- matrix(
    0,
    nrow = length(cluster_levels),
    ncol = length(fibroblast_signatures),
    dimnames = list(cluster_levels, names(fibroblast_signatures))
  )
  for (label in names(fibroblast_signatures)) {
    genes <- intersect(fibroblast_signatures[[label]], rownames(z))
    if (length(genes)) {
      vals <- colMeans(z[genes, , drop = FALSE])
      names(vals) <- sub("^C", "", names(vals))
      score[names(vals), label] <- vals
    }
  }

  go_bonus <- matrix(0, nrow = nrow(score), ncol = ncol(score), dimnames = dimnames(score))
  if (nrow(go_table)) {
    for (cl in cluster_levels) {
      terms <- go_table[
        as.character(go_table$cluster) == cl & go_table$p.adjust < 0.10,
        , drop = FALSE
      ]
      terms <- head(terms[order(terms$p.adjust), , drop = FALSE], 30)
      desc <- tolower(paste(terms$Description, collapse = " | "))
      for (label in colnames(go_bonus)) {
        if (nzchar(desc)) {
          hits <- gregexpr(fibroblast_go_patterns[[label]], desc, perl = TRUE)[[1]]
          go_bonus[cl, label] <- if (hits[1] < 0) 0 else length(hits)
        }
      }
    }
  }
  for (label in colnames(go_bonus)) {
    mx <- max(go_bonus[, label])
    if (mx > 0) go_bonus[, label] <- go_bonus[, label] / mx
  }
  combined <- score + 0.25 * go_bonus
  signature_winner <- colnames(combined)[max.col(combined, ties.method = "first")]

  marker_dt <- as.data.table(markers)
  fc_col <- intersect(c("avg_log2FC", "avg_logFC"), names(marker_dt))[1]
  if (!is.na(fc_col)) setorderv(marker_dt, c("cluster", fc_col), c(1, -1))

  weighted_hits <- function(top10, top30, genes) {
    2L * sum(top10 %in% genes) + sum(setdiff(top30, top10) %in% genes)
  }

  classify_one <- function(cl) {
    genes <- unique(marker_dt[as.character(cluster) == cl, gene_symbol])
    genes <- standardize_gene_symbol(genes)
    top10 <- head(genes, 10L)
    top30 <- head(genes, 30L)
    go_desc <- ""
    if (nrow(go_table) && "cluster" %in% names(go_table)) {
      g <- go_table[as.character(go_table$cluster) == cl, , drop = FALSE]
      if (nrow(g)) {
        g <- head(g[order(g$p.adjust), , drop = FALSE], 30L)
        go_desc <- tolower(paste(g$Description, collapse = " | "))
      }
    }

    sets <- list(
      cycling = c("MKI67", "TOP2A", "UBE2C", "CENPF", "HMGB2", "TYMS", "STMN1", "PTTG1", "PCLAF", "PBK", "TK1", "CDKN3", "TUBA1B", "H2AZ1"),
      ig_high = c("IGLC2", "IGKC", "IGHG4", "IGHG3", "HBB", "HBA1", "HBA2", "FDCSP", "S100A8", "S100A9"),
      p_em = c("CFD", "APOD", "GSN", "PLA2G2A", "TSPAN8", "PTGDS", "ABCA8", "CLU", "MFAP5", "SPARCL1", "PLAC9"),
      wnt = c("F13A1", "TNFRSF11B", "IGFBP2", "APCDD1", "RDH10", "COMP", "SLC5A3", "DIO2", "MRPS6", "DKK3", "WNT5A"),
      remodeling = c("COL11A1", "TIMP3", "ASPN", "POSTN", "COL12A1", "OGN", "SFRP4", "CTHRC1", "NBL1", "TNC", "FAP"),
      vascular = c("COL4A1", "COL4A2", "RGS5", "MCAM", "CSPG4", "RBP1", "NOTCH3", "PDGFRB", "ADM", "KDR"),
      im_ccl19 = c("CCL19", "CXCL13", "CXCL2", "CXCL3", "IL6", "RGS16", "NFKBIA", "SOD2"),
      im_cxcl8 = c("CXCL8", "CXCL1", "CXCL6", "IL24", "SAA1", "CHI3L2", "DEPP1")
    )
    hs <- vapply(sets, function(s) weighted_hits(top10, top30, s), integer(1))
    go_cycle <- grepl("cell division|chromosome segregation|mitotic|cell cycle|dna replication", go_desc)
    go_angiogenic <- grepl("angiogenesis|blood vessel|vascul", go_desc)

    label <- NA_character_
    confidence <- "moderate"
    rule <- "ranked DEG and GO fallback"
    if (hs[["cycling"]] >= 6L || go_cycle) {
      label <- "Cycling FB"
      confidence <- "high"
      rule <- "cell-cycle DEG/GO override"
    } else if (length(cluster_levels) > 3L && hs[["remodeling"]] >= 6L && hs[["ig_high"]] >= 4L) {
      label <- "P-MyFB (Ig-high mixed)"
      rule <- "POSTN/ASPN/COL11A1 remodeling program merged with Ig-high cells at this resolution"
    } else if (hs[["ig_high"]] >= 6L) {
      label <- "Ig-high FB (low-confidence)"
      confidence <- "low"
      rule <- "immunoglobulin/erythroid/neutrophil transcript override; possible ambient RNA or doublet"
    } else if (length(cluster_levels) <= 3L) {
      if (hs[["p_em"]] >= 6L) {
        label <- "P-EmFB"
        confidence <- "high"
        rule <- "CFD/APOD/GSN complement-homeostatic program"
      } else if ((hs[["im_ccl19"]] + hs[["im_cxcl8"]]) >= 5L && hs[["remodeling"]] >= 3L) {
        label <- "Mixed immune-remodeling FB"
        rule <- "low-resolution cluster merges chemokine and matrix-remodeling programs"
      } else {
        label <- "Mixed non-cycling FB"
        rule <- "low-resolution cluster is not separable into a single literature state"
      }
    } else if (hs[["p_em"]] >= 6L) {
      label <- "P-EmFB"
      confidence <- "high"
      rule <- "CFD/APOD/GSN complement-homeostatic program"
    } else if (hs[["wnt"]] >= 6L) {
      label <- "WNT-regulatory FB"
      confidence <- "high"
      rule <- "APCDD1/IGFBP2/TNFRSF11B WNT-regulatory Williams H.Fib program"
    } else if (hs[["remodeling"]] >= 6L) {
      label <- "P-MyFB"
      confidence <- "high"
      rule <- "POSTN/ASPN/COL11A1 matrix-remodeling pre-myofibroblast program"
    } else if (hs[["vascular"]] >= 5L && go_angiogenic) {
      label <- "VFB (angiogenic/inflammatory)"
      confidence <- "high"
      rule <- "COL4A1/COL4A2/ADM plus angiogenesis GO program"
    } else if (hs[["im_cxcl8"]] >= 5L) {
      label <- "ImFB-CXCL8"
      confidence <- "high"
      rule <- "CXCL1/CXCL8/CXCL6 acute inflammatory program"
    } else if (hs[["im_ccl19"]] >= 5L) {
      label <- "ImFB-CCL19"
      confidence <- "high"
      rule <- "CCL19/CXCL13 immune-recruitment program"
    } else if ((hs[["im_ccl19"]] + hs[["im_cxcl8"]]) >= 4L) {
      label <- "ImFB"
      rule <- "chemokine/inflammatory DEG and GO program"
    } else {
      label <- signature_winner[match(cl, cluster_levels)]
      rule <- "signature-score fallback because no strong ranked-marker rule fired"
    }

    data.table(
      cluster = cl,
      proposed_label = label,
      naming_confidence = confidence,
      naming_rule = rule,
      top30_genes = paste(top30, collapse = ";"),
      hit_cycling = hs[["cycling"]],
      hit_ig_high = hs[["ig_high"]],
      hit_p_em = hs[["p_em"]],
      hit_wnt = hs[["wnt"]],
      hit_remodeling = hs[["remodeling"]],
      hit_vascular = hs[["vascular"]],
      hit_im_ccl19 = hs[["im_ccl19"]],
      hit_im_cxcl8 = hs[["im_cxcl8"]],
      go_cycle = go_cycle,
      go_angiogenic = go_angiogenic
    )
  }

  rule_mapping <- rbindlist(lapply(cluster_levels, classify_one), fill = TRUE)
  mapping <- data.frame(
    cluster = cluster_levels,
    fb_id = paste0("FB", seq_along(cluster_levels)),
    signature_best_label = signature_winner,
    signature_best_score = apply(score, 1, max),
    signature_go_bonus = go_bonus[cbind(seq_len(nrow(go_bonus)), match(signature_winner, colnames(go_bonus)))],
    stringsAsFactors = FALSE
  )
  mapping <- merge(mapping, as.data.frame(rule_mapping), by = "cluster", all.x = TRUE, sort = FALSE)
  mapping <- mapping[match(cluster_levels, mapping$cluster), , drop = FALSE]

  duplicate_count <- ave(seq_len(nrow(mapping)), mapping$proposed_label, FUN = length)
  duplicate_rank <- ave(seq_len(nrow(mapping)), mapping$proposed_label, FUN = seq_along)
  suffix <- ifelse(
    duplicate_count > 1,
    paste0("-", LETTERS[duplicate_rank]),
    ""
  )
  mapping$final_label <- paste0(mapping$proposed_label, suffix)
  mapping$display_label <- paste(mapping$fb_id, mapping$final_label)
  mapping$chinese_name <- unname(fibroblast_label_cn[mapping$proposed_label])

  mapping$top_markers <- vapply(mapping$cluster, function(cl) {
    paste(head(marker_dt[as.character(cluster) == cl, gene_symbol], 8), collapse = ";")
  }, character(1))
  mapping$top_go_bp <- vapply(mapping$cluster, function(cl) {
    g <- go_table[as.character(go_table$cluster) == cl, , drop = FALSE]
    g <- head(g[order(g$p.adjust), "Description", drop = TRUE], 3)
    paste(g, collapse = ";")
  }, character(1))

  metric_genes <- intersect(c("CD81", "C3", "IL6", "CXCL8", "CDKN1A", "GDF15"), rownames(object))
  if (length(metric_genes)) {
    norm <- GetAssayData(object, assay = "RNA", slot = "data")[metric_genes, , drop = FALSE]
    cnt <- GetAssayData(object, assay = "RNA", slot = "counts")[metric_genes, , drop = FALSE]
    groups <- sub("^C", "", as.character(object$cluster_key))
    for (gene in metric_genes) {
      mapping[[paste0("avg_log_normalized_", gene)]] <- vapply(
        cluster_levels,
        function(cl) mean(norm[gene, groups == cl]),
        numeric(1)
      )
      mapping[[paste0("pct_expressed_", gene)]] <- vapply(
        cluster_levels,
        function(cl) mean(cnt[gene, groups == cl] > 0) * 100,
        numeric(1)
      )
    }
  }

  score_df <- as.data.frame(score)
  score_df$cluster <- rownames(score_df)
  go_df <- as.data.frame(go_bonus)
  names(go_df) <- paste0(names(go_df), "_GO_bonus")
  go_df$cluster <- rownames(go_df)
  mapping <- merge(mapping, score_df, by = "cluster", all.x = TRUE, sort = FALSE)
  mapping <- merge(mapping, go_df, by = "cluster", all.x = TRUE, sort = FALSE)
  mapping <- mapping[match(cluster_levels, mapping$cluster), , drop = FALSE]
  mapping
}

select_diagonal_markers <- function(filtered_markers, all_markers,
                                    cluster_levels, n_per_cluster = 5L) {
  filtered <- as.data.table(filtered_markers)
  fallback <- as.data.table(all_markers)
  fc_col <- intersect(c("avg_log2FC", "avg_logFC"), names(fallback))[1]
  if (!is.na(fc_col)) {
    setorderv(filtered, c("cluster", fc_col), c(1, -1))
    setorderv(fallback, c("cluster", fc_col), c(1, -1))
  }
  used <- character()
  selected <- vector("list", length(cluster_levels))
  for (i in seq_along(cluster_levels)) {
    cl <- cluster_levels[i]
    cand <- filtered[as.character(cluster) == cl & !gene %in% used]
    if (nrow(cand) < n_per_cluster) {
      extra <- fallback[as.character(cluster) == cl & !gene %in% c(used, cand$gene)]
      cand <- rbind(cand, extra, fill = TRUE)
    }
    cand <- head(cand, n_per_cluster)
    if (nrow(cand)) {
      cand[, source_cluster := cl]
      selected[[i]] <- cand
      used <- c(used, cand$gene)
    }
  }
  ans <- rbindlist(selected, fill = TRUE)
  ans[, key := paste0("C", source_cluster, "__", gene)]
  ans[]
}

write_json_manifest <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  jsonlite::write_json(x, path, auto_unbox = TRUE, pretty = TRUE, na = "null")
  invisible(path)
}
