options(stringsAsFactors = FALSE)
options(future.globals.maxSize = 32 * 1024^3)
options(Seurat.object.assay.version = "v3")

SEED <- 20260815L
set.seed(SEED)

OUT_ROOT <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260815-GSE164241\u5065\u5eb7\u7259\u9f88-\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e25\u683c\u91cd\u5206\u6790-v1"
SOURCE_RDS <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260730-\u591a\u6570\u636e\u5e93-\u7259\u9f88\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e9a\u7fa4-",
  "Scissor-Figure4\u590d\u7b97/01_GSE164241/GSE164241-\u5065\u5eb7\u7259\u9f88/",
  "source_data/fibroblast_atlas_full.rds"
)
R_LIB <- "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library"
.libPaths(c(R_LIB, .libPaths()))

suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
  library(data.table)
  library(ggplot2)
  library(cluster)
})

dir.create(file.path(OUT_ROOT, "01_QC"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(OUT_ROOT, "02_intermediate"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(OUT_ROOT, "03_source_tables"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(OUT_ROOT, "04_figures"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(OUT_ROOT, "05_validation"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(OUT_ROOT, "logs"), recursive = TRUE, showWarnings = FALSE)

write_csv <- function(x, path) {
  fwrite(as.data.table(x), path, bom = TRUE)
}

message("[1/8] Reading the original object in read-only mode")
source_object <- readRDS(SOURCE_RDS)
stopifnot(inherits(source_object, "Seurat"), ncol(source_object) == 16603L)
DefaultAssay(source_object) <- "RNA"
source_meta <- source_object[[]]
source_meta$cell <- rownames(source_meta)
source_meta$source_cluster <- as.character(source_meta$seurat_clusters)
source_meta$source_forced_subtype <- as.character(source_meta$fibroblast_subtype)

LINEAGE_MARKERS <- list(
  Fibroblast = c(
    "COL1A1", "COL1A2", "COL3A1", "DCN", "LUM", "C7", "CFD",
    "PDGFRA", "COL6A1", "COL6A2", "DPT", "COL14A1", "PI16"
  ),
  Endothelial = c(
    "PECAM1", "VWF", "EMCN", "KDR", "ESAM", "CLDN5", "RAMP2",
    "PLVAP", "FLT1", "SOX17", "PROX1", "FLT4", "CCL21"
  ),
  Immune = c(
    "PTPRC", "CD3D", "CD3E", "TRAC", "CD2", "CD7", "NKG7", "GNLY",
    "LST1", "TYROBP", "AIF1", "FCER1G", "C1QA", "C1QB", "C1QC",
    "MS4A1", "CD79A", "TPSAB1", "TPSB2"
  ),
  Epithelial = c(
    "EPCAM", "KRT5", "KRT14", "KRT15", "KRT17", "KRT19", "KRT8",
    "KRT18", "SPRR1A", "SPRR1B", "MUC21"
  ),
  Melanocyte = c("PMEL", "MLANA", "TYR", "DCT", "SLC45A2", "SLC24A5"),
  Myogenic = c("PAX7", "MYF5", "MYF6", "MYOD1", "CALCR", "ZIC1"),
  Mural = c(
    "RGS5", "CSPG4", "MCAM", "ABCC9", "KCNJ8", "NOTCH3",
    "NDUFA4L2", "COX4I2", "HIGD1B"
  )
)

KNOWN_NON_FIBRO_CLUSTERS <- c("4", "8", "11", "13", "15", "16", "17", "18", "20")
counts <- GetAssayData(source_object, assay = "RNA", layer = "counts")
detected_marker_counts <- sapply(LINEAGE_MARKERS, function(genes) {
  genes <- intersect(genes, rownames(counts))
  Matrix::colSums(counts[genes, , drop = FALSE] > 0)
})
foreign_columns <- setdiff(colnames(detected_marker_counts), "Fibroblast")
foreign_max <- apply(detected_marker_counts[, foreign_columns, drop = FALSE], 1L, max)
foreign_top <- foreign_columns[max.col(
  detected_marker_counts[, foreign_columns, drop = FALSE],
  ties.method = "first"
)]
cluster_excluded <- source_meta$source_cluster %in% KNOWN_NON_FIBRO_CLUSTERS
low_fibro_support <- detected_marker_counts[, "Fibroblast"] < 3L
coherent_foreign_signal <- foreign_max >= 3L
high_information_qc <- (
  source_meta$nFeature_RNA >= 500L &
    source_meta$percent.mt <= 15
)
strict_keep <- (
  !cluster_excluded &
    !low_fibro_support &
    !coherent_foreign_signal &
    high_information_qc
)

source_meta$fibroblast_marker_count <- detected_marker_counts[, "Fibroblast"]
for (lineage in foreign_columns) {
  source_meta[[paste0(tolower(lineage), "_marker_count")]] <-
    detected_marker_counts[, lineage]
}
source_meta$top_foreign_lineage <- foreign_top
source_meta$top_foreign_marker_count <- foreign_max
source_meta$excluded_known_non_fibro_cluster <- cluster_excluded
source_meta$excluded_low_fibroblast_support <- low_fibro_support
source_meta$excluded_coherent_foreign_signal <- coherent_foreign_signal
source_meta$excluded_low_information_qc <- !high_information_qc
source_meta$strict_fibroblast_keep <- strict_keep
source_meta$filter_decision <- ifelse(
  strict_keep,
  "keep_strict_fibroblast",
  ifelse(
    cluster_excluded,
    "exclude_known_non_fibroblast_cluster",
    ifelse(
      low_fibro_support,
      "exclude_low_fibroblast_marker_support",
      ifelse(
        coherent_foreign_signal,
        "exclude_coherent_foreign_lineage_signal",
        "exclude_low_information_qc"
      )
    )
  )
)
write_csv(source_meta, file.path(OUT_ROOT, "01_QC", "01_cell_level_lineage_filter_audit.csv.gz"))

filter_summary <- as.data.table(table(
  filter_decision = source_meta$filter_decision,
  useNA = "ifany"
))
filter_summary[, percent_of_input := N / sum(N) * 100]
write_csv(filter_summary, file.path(OUT_ROOT, "01_QC", "02_filter_summary.csv"))

cluster_filter_summary <- as.data.table(table(
  source_cluster = source_meta$source_cluster,
  retained = source_meta$strict_fibroblast_keep
))
cluster_filter_summary <- dcast(
  cluster_filter_summary,
  source_cluster ~ retained,
  value.var = "N",
  fill = 0
)
setnames(
  cluster_filter_summary,
  old = intersect(c("FALSE", "TRUE"), names(cluster_filter_summary)),
  new = c("excluded_cells", "retained_cells")[
    match(intersect(c("FALSE", "TRUE"), names(cluster_filter_summary)), c("FALSE", "TRUE"))
  ]
)
cluster_filter_summary[, input_cells := excluded_cells + retained_cells]
cluster_filter_summary[, retained_percent := retained_cells / input_cells * 100]
cluster_filter_summary[, source_cluster_numeric := as.integer(source_cluster)]
setorder(cluster_filter_summary, source_cluster_numeric)
cluster_filter_summary[, source_cluster_numeric := NULL]
write_csv(cluster_filter_summary, file.path(OUT_ROOT, "01_QC", "03_filter_by_source_cluster.csv"))

donor_filter_summary <- as.data.table(table(
  donor_id = source_meta$donor_id,
  retained = source_meta$strict_fibroblast_keep
))
donor_filter_summary <- dcast(
  donor_filter_summary,
  donor_id ~ retained,
  value.var = "N",
  fill = 0
)
setnames(
  donor_filter_summary,
  old = intersect(c("FALSE", "TRUE"), names(donor_filter_summary)),
  new = c("excluded_cells", "retained_cells")[
    match(intersect(c("FALSE", "TRUE"), names(donor_filter_summary)), c("FALSE", "TRUE"))
  ]
)
donor_filter_summary[, input_cells := excluded_cells + retained_cells]
donor_filter_summary[, retained_percent := retained_cells / input_cells * 100]
write_csv(donor_filter_summary, file.path(OUT_ROOT, "01_QC", "04_filter_by_donor.csv"))

stopifnot(sum(strict_keep) == 10105L)
stopifnot(length(unique(source_meta$donor_id[strict_keep])) == 13L)

message("[2/8] Building a clean fibroblast-only object")
clean_object <- subset(source_object, cells = source_meta$cell[strict_keep])
clean_meta <- clean_object[[]]
clean_meta$source_cluster <- as.character(clean_meta$seurat_clusters)
clean_meta$source_forced_subtype <- as.character(clean_meta$fibroblast_subtype)
clean_object@meta.data <- clean_meta
for (reduction_name in Reductions(clean_object)) {
  clean_object[[reduction_name]] <- NULL
}
clean_object@graphs <- list()
clean_object@neighbors <- list()
DefaultAssay(clean_object) <- "RNA"
clean_object <- NormalizeData(clean_object, verbose = FALSE)

message("[3/8] Selecting integration features without technical/confounding genes")
object_list <- SplitObject(clean_object, split.by = "donor_id")
object_list <- lapply(object_list, function(object) {
  DefaultAssay(object) <- "RNA"
  object <- NormalizeData(object, verbose = FALSE)
  object <- FindVariableFeatures(
    object,
    selection.method = "vst",
    nfeatures = min(3000L, nrow(object)),
    verbose = FALSE
  )
  object
})
integration_features_all <- SelectIntegrationFeatures(
  object.list = object_list,
  nfeatures = 3000L
)

stress_genes <- c(
  "FOS", "FOSB", "JUN", "JUNB", "JUND", "ATF3", "DDIT3", "IER2",
  "IER3", "HSPA1A", "HSPA1B", "HSP90AA1", "DNAJB1", "GDF15"
)
sex_genes <- c("RPS4Y1", "KDM5D", "DDX3Y", "UTY", "ZFY", "EIF1AY", "XIST")
cell_cycle_genes <- unique(c(
  Seurat::cc.genes.updated.2019$s.genes,
  Seurat::cc.genes.updated.2019$g2m.genes
))
regex_confounders <- grep(
  paste0(
    "^(MT-|RPS[0-9]|RPL[0-9]|HB[ABDEGQZ]|IG[HKL]|TR[ABDG])"
  ),
  rownames(clean_object),
  value = TRUE
)
confounders <- unique(c(
  regex_confounders,
  stress_genes,
  sex_genes,
  cell_cycle_genes,
  unlist(LINEAGE_MARKERS[setdiff(names(LINEAGE_MARKERS), "Fibroblast")])
))
integration_features <- setdiff(integration_features_all, confounders)
if (length(integration_features) < 1500L) {
  stop("Too few integration features after confounder exclusion: ", length(integration_features))
}
write_csv(
  data.table(
    gene = integration_features_all,
    retained_for_integration = integration_features_all %in% integration_features,
    exclusion_reason = ifelse(
      integration_features_all %in% integration_features,
      "retained",
      "technical_or_lineage_confounder"
    )
  ),
  file.path(OUT_ROOT, "03_source_tables", "01_integration_feature_audit.csv")
)

message("[4/8] Running donor-aware reciprocal-PCA integration")
object_list <- lapply(object_list, function(object) {
  object <- ScaleData(object, features = integration_features, verbose = FALSE)
  object <- RunPCA(
    object,
    features = integration_features,
    npcs = 30L,
    seed.use = SEED,
    verbose = FALSE
  )
  object
})
anchors <- FindIntegrationAnchors(
  object.list = object_list,
  anchor.features = integration_features,
  reduction = "rpca",
  dims = 1:30,
  k.anchor = 5L,
  k.filter = 150L,
  k.score = 30L,
  verbose = TRUE
)
integrated_object <- IntegrateData(
  anchorset = anchors,
  dims = 1:30,
  new.assay.name = "integrated",
  verbose = TRUE
)
rm(anchors, object_list, clean_object, counts)
gc()

DefaultAssay(integrated_object) <- "integrated"
integrated_object <- ScaleData(integrated_object, verbose = FALSE)
integrated_object <- RunPCA(
  integrated_object,
  npcs = 30L,
  seed.use = SEED,
  verbose = FALSE
)
integrated_object <- FindNeighbors(
  integrated_object,
  reduction = "pca",
  dims = 1:20,
  graph.name = c("strict_nn", "strict_snn"),
  verbose = FALSE
)

message("[5/8] Testing clustering resolutions")
resolutions <- c(0.10, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50, 0.60)
resolution_columns <- character(length(resolutions))
for (index in seq_along(resolutions)) {
  resolution <- resolutions[index]
  integrated_object <- FindClusters(
    integrated_object,
    graph.name = "strict_snn",
    algorithm = 1L,
    resolution = resolution,
    random.seed = SEED,
    verbose = FALSE
  )
  column_name <- paste0("strict_res_", gsub("\\.", "_", sprintf("%.2f", resolution)))
  integrated_object[[column_name]] <- as.character(integrated_object$seurat_clusters)
  resolution_columns[index] <- column_name
}

pca_embeddings <- Embeddings(integrated_object, reduction = "pca")[, 1:20, drop = FALSE]
metadata <- integrated_object[[]]
donor_split <- split(rownames(metadata), metadata$donor_id)
sample_cells <- unique(unlist(lapply(donor_split, function(cells) {
  sample(cells, min(length(cells), ceiling(3000L / length(donor_split))))
}), use.names = FALSE))
if (length(sample_cells) > 3000L) {
  sample_cells <- sample(sample_cells, 3000L)
}
distance_sample <- dist(pca_embeddings[sample_cells, , drop = FALSE])

cramers_v <- function(cluster_labels, donor_labels) {
  contingency <- table(cluster_labels, donor_labels)
  denominator <- length(cluster_labels) * min(nrow(contingency) - 1L, ncol(contingency) - 1L)
  if (denominator <= 0) {
    return(NA_real_)
  }
  statistic <- suppressWarnings(chisq.test(contingency, correct = FALSE)$statistic)
  sqrt(as.numeric(statistic) / denominator)
}

resolution_diagnostics <- rbindlist(lapply(seq_along(resolutions), function(index) {
  column_name <- resolution_columns[index]
  labels <- as.character(metadata[[column_name]])
  cluster_sizes <- table(labels)
  donor_table <- table(labels, metadata$donor_id)
  donor_coverage <- rowSums(donor_table > 0)
  max_donor_share <- apply(prop.table(donor_table, margin = 1L), 1L, max)
  sample_labels <- labels[match(sample_cells, rownames(metadata))]
  silhouette_value <- if (length(unique(sample_labels)) > 1L) {
    mean(cluster::silhouette(as.integer(factor(sample_labels)), distance_sample)[, 3L])
  } else {
    NA_real_
  }
  data.table(
    resolution = resolutions[index],
    metadata_column = column_name,
    n_clusters = length(cluster_sizes),
    min_cluster_cells = min(cluster_sizes),
    median_cluster_cells = median(as.numeric(cluster_sizes)),
    median_donor_coverage = median(donor_coverage),
    min_donor_coverage = min(donor_coverage),
    median_max_donor_share = median(max_donor_share),
    max_single_donor_share = max(max_donor_share),
    donor_cramers_v = cramers_v(labels, metadata$donor_id),
    mean_silhouette = silhouette_value
  )
}))

safe_z <- function(values) {
  if (all(is.na(values)) || sd(values, na.rm = TRUE) == 0) {
    return(rep(0, length(values)))
  }
  as.numeric(scale(values))
}
resolution_diagnostics[, eligible_primary := (
  n_clusters >= 4L & n_clusters <= 10L &
    min_cluster_cells >= 75L & median_donor_coverage >= 6
)]
resolution_diagnostics[, selection_score := (
  safe_z(mean_silhouette) +
    0.50 * safe_z(median_donor_coverage) -
    0.75 * safe_z(donor_cramers_v) -
    0.50 * safe_z(median_max_donor_share) +
    0.35 * safe_z(log10(min_cluster_cells))
)]
write_csv(
  resolution_diagnostics,
  file.path(OUT_ROOT, "03_source_tables", "02a_resolution_diagnostics_preselection.csv")
)
eligible <- resolution_diagnostics[eligible_primary == TRUE]
selection_tier <- "primary_strict"
if (!nrow(eligible)) {
  eligible <- resolution_diagnostics[
    n_clusters >= 3L & n_clusters <= 15L &
      min_cluster_cells >= 20L & median_donor_coverage >= 4
  ]
  selection_tier <- "secondary_relaxed"
}
if (!nrow(eligible)) {
  eligible <- resolution_diagnostics[n_clusters >= 2L & n_clusters <= 20L]
  selection_tier <- "exploratory_fallback"
}
if (!nrow(eligible)) {
  stop("No interpretable clustering resolution was produced")
}
selected_resolution_row <- eligible[order(-selection_score, resolution)][1L]
selected_resolution <- selected_resolution_row$resolution
selected_column <- selected_resolution_row$metadata_column
resolution_diagnostics[, selected := metadata_column == selected_column]
resolution_diagnostics[, selection_tier := ifelse(selected, selection_tier, NA_character_)]
write_csv(
  resolution_diagnostics,
  file.path(OUT_ROOT, "03_source_tables", "02_resolution_diagnostics.csv")
)

selected_cluster_values <- as.character(integrated_object[[selected_column, drop = TRUE]])
selected_cluster_levels <- as.character(sort(unique(as.integer(selected_cluster_values))))
integrated_object$data_driven_cluster <- factor(
  selected_cluster_values,
  levels = selected_cluster_levels
)
Idents(integrated_object) <- "data_driven_cluster"
integrated_object <- RunUMAP(
  integrated_object,
  reduction = "pca",
  dims = 1:20,
  n.neighbors = 30L,
  min.dist = 0.30,
  seed.use = SEED,
  reduction.name = "umap_strict",
  reduction.key = "UMAPstrict_",
  verbose = FALSE
)

message("[6/8] Calling independent RNA markers for the selected clusters")
DefaultAssay(integrated_object) <- "RNA"
Idents(integrated_object) <- "data_driven_cluster"
markers <- FindAllMarkers(
  integrated_object,
  assay = "RNA",
  slot = "data",
  only.pos = TRUE,
  test.use = "wilcox",
  logfc.threshold = 0.20,
  min.pct = 0.10,
  return.thresh = 0.05,
  verbose = TRUE
)
markers_dt <- as.data.table(markers, keep.rownames = "marker_row")
if (!"gene" %in% names(markers_dt)) {
  markers_dt[, gene := marker_row]
}
markers_dt[, cluster := as.character(cluster)]
markers_dt[, integration_confounder := gene %in% confounders]
write_csv(markers_dt, file.path(OUT_ROOT, "03_source_tables", "03_all_cluster_markers.csv.gz"))

top_marker_preview <- markers_dt[
  integration_confounder == FALSE & pct.1 >= 0.20
][order(cluster, p_val_adj, -avg_log2FC), head(.SD, 25L), by = cluster]
write_csv(
  top_marker_preview,
  file.path(OUT_ROOT, "03_source_tables", "04_top25_markers_for_annotation.csv")
)

message("[7/8] Exporting UMAP, composition, lineage, and donor diagnostics")
umap <- Embeddings(integrated_object, reduction = "umap_strict")
final_metadata <- integrated_object[[]]
final_metadata$cell <- rownames(final_metadata)
final_metadata$UMAP_1 <- umap[rownames(final_metadata), 1L]
final_metadata$UMAP_2 <- umap[rownames(final_metadata), 2L]
write_csv(
  final_metadata,
  file.path(OUT_ROOT, "03_source_tables", "05_cell_metadata_with_strict_umap.csv.gz")
)

cluster_counts <- as.data.table(table(
  cluster = integrated_object$data_driven_cluster
))
cluster_counts[, proportion := N / sum(N)]
write_csv(cluster_counts, file.path(OUT_ROOT, "03_source_tables", "06_cluster_composition.csv"))

donor_cluster_counts <- as.data.table(table(
  donor_id = integrated_object$donor_id,
  cluster = integrated_object$data_driven_cluster
))
donor_cluster_counts <- donor_cluster_counts[N > 0]
donor_cluster_counts[, donor_total := sum(N), by = donor_id]
donor_cluster_counts[, donor_percent := N / donor_total * 100]
write_csv(
  donor_cluster_counts,
  file.path(OUT_ROOT, "03_source_tables", "07_cluster_by_donor_composition.csv")
)

kept_detected <- detected_marker_counts[
  colnames(integrated_object),
  ,
  drop = FALSE
]
lineage_audit <- rbindlist(lapply(levels(integrated_object$data_driven_cluster), function(cluster_id) {
  cells <- colnames(integrated_object)[integrated_object$data_driven_cluster == cluster_id]
  rbindlist(lapply(colnames(kept_detected), function(lineage) {
    values <- kept_detected[cells, lineage]
    data.table(
      cluster = cluster_id,
      lineage = lineage,
      cells = length(cells),
      median_detected_markers = median(values),
      p90_detected_markers = as.numeric(quantile(values, 0.90)),
      percent_with_at_least_2 = mean(values >= 2L) * 100,
      percent_with_at_least_3 = mean(values >= 3L) * 100
    )
  }))
}))
write_csv(lineage_audit, file.path(OUT_ROOT, "05_validation", "01_residual_lineage_audit.csv"))

donor_balance <- donor_cluster_counts[, .(
  cluster_cells = sum(N),
  donors_present = uniqueN(donor_id),
  max_donor_fraction = max(N) / sum(N),
  effective_donors = 1 / sum((N / sum(N))^2)
), by = cluster]
write_csv(donor_balance, file.path(OUT_ROOT, "05_validation", "02_cluster_donor_balance.csv"))

message("[8/8] Saving the integrated object and run manifest")
saveRDS(
  integrated_object,
  file.path(OUT_ROOT, "02_intermediate", "strict_integrated_clustered.rds"),
  compress = FALSE
)

manifest <- c(
  paste0("run_date=2026-08-15"),
  paste0("seed=", SEED),
  paste0("source_rds=", SOURCE_RDS),
  paste0("input_cells=", ncol(source_object)),
  paste0("strict_retained_cells=", ncol(integrated_object)),
  paste0("post_lineage_qc=nFeature_RNA>=500; percent.mt<=15"),
  paste0("donors=", length(unique(integrated_object$donor_id))),
  paste0("integration=Seurat reciprocal PCA by donor_id"),
  paste0("integration_features=", length(integration_features)),
  paste0("tested_resolutions=", paste(resolutions, collapse = ",")),
  paste0("selected_resolution=", selected_resolution),
  paste0("selected_clusters=", nlevels(integrated_object$data_driven_cluster)),
  paste0("R=", R.version.string),
  paste0("Seurat=", as.character(packageVersion("Seurat")))
)
writeLines(manifest, file.path(OUT_ROOT, "logs", "01_run_manifest.txt"), useBytes = TRUE)
writeLines(capture.output(sessionInfo()), file.path(OUT_ROOT, "logs", "02_sessionInfo.txt"), useBytes = TRUE)
message("Stage 1 complete: ", OUT_ROOT)
