options(stringsAsFactors = FALSE)
set.seed(20260915L)

.libPaths(c(
  "C:/Users/Lin/R/win-library/4.5",
  "C:/Users/Lin/AppData/Local/R/win-library/4.5",
  "C:/Program Files/R/R-4.5.3/library"
))

suppressPackageStartupMessages({
  library(data.table)
  library(Seurat)
  library(Matrix)
  library(edgeR)
  library(limma)
  library(GSVA)
  library(UCell)
  library(progeny)
  library(fgsea)
  library(igraph)
})

ROOT <- "C:/wb_links/dlc"
OUT <- Sys.getenv("DLC_ANALYSIS_DIR", file.path(ROOT, "data_derived/tranoncol2026"))
STUDY_FILTER <- trimws(Sys.getenv("DLC_STUDY_FILTER", ""))
SC_DATASET_LABEL <- Sys.getenv("DLC_SC_DATASET_LABEL", "Gingival scRNA")
SIGNATURE_FALLBACK_DIR <- trimws(Sys.getenv("DLC_SIGNATURE_FALLBACK_DIR", ""))
dir.create(OUT, recursive = TRUE, showWarnings = FALSE)

FB_RDS <- "C:/wb_links/dlc_data/outputs/fb_seurat_annotated.rds"
PB_RDS <- "C:/wb_links/dlc_derived/donor_pseudobulk_matrices.rds"
CURATED_GMT <- "C:/wb_links/dlc_data/outputs/curated_gene_sets_v1.gmt"
GO_GMT <- "C:/wb_links/genesets/GO_Biological_Process_2025.gmt"
REACTOME_GMT <- "C:/wb_links/genesets/Reactome_Pathways_2024.gmt"
P2_SD <- Sys.getenv("DLC_HDWGCNA_SOURCE_DIR",
                    file.path(ROOT, "P2_hdWGCNA/outputs/02_source_data"))

read_gmt <- function(path) {
  z <- list()
  for (ln in readLines(path, warn = FALSE)) {
    p <- strsplit(ln, "\t", fixed = TRUE)[[1]]
    if (length(p) >= 3) z[[p[1]]] <- unique(p[-c(1, 2)])
  }
  z
}

zmean_scores <- function(expr, sets, min_genes = 5L) {
  ans <- lapply(names(sets), function(nm) {
    g <- intersect(unique(sets[[nm]]), rownames(expr))
    if (length(g) < min_genes) return(NULL)
    zz <- t(scale(t(expr[g, , drop = FALSE])))
    zz[!is.finite(zz)] <- 0
    data.table(sample = colnames(expr), program = nm,
               score = colMeans(zz), n_genes = length(g))
  })
  rbindlist(ans, fill = TRUE)
}

run_ora_network <- function(selected_genes, universe, gmt_files, prefix,
                            max_terms = 80L, jaccard_cutoff = 0.12) {
  selected_genes <- unique(intersect(selected_genes, universe))
  term_rows <- list()
  for (source_name in names(gmt_files)) {
    gs <- read_gmt(gmt_files[[source_name]])
    for (term in names(gs)) {
      bg <- intersect(gs[[term]], universe)
      if (length(bg) < 10 || length(bg) > 500) next
      hit <- intersect(selected_genes, bg)
      if (length(hit) < 3) next
      p <- phyper(length(hit) - 1, length(bg), length(universe) - length(bg),
                  length(selected_genes), lower.tail = FALSE)
      term_rows[[length(term_rows) + 1L]] <- data.table(
        term = term, source = source_name, hit = length(hit),
        term_size = length(bg), p = p, genes = paste(sort(hit), collapse = ";")
      )
    }
  }
  tab <- rbindlist(term_rows, fill = TRUE)
  if (!nrow(tab)) stop("No ORA terms produced for ", prefix)
  tab[, padj := p.adjust(p, "BH")]
  tab[, fold := (hit / length(selected_genes)) / (term_size / length(universe))]
  setorder(tab, padj, p, -hit)
  tab <- head(tab, max_terms)

  gene_sets <- lapply(tab$genes, function(x) strsplit(x, ";", fixed = TRUE)[[1]])
  edge_rows <- list()
  if (nrow(tab) >= 2) {
    for (i in seq_len(nrow(tab) - 1L)) {
      for (j in (i + 1L):nrow(tab)) {
        ji <- length(intersect(gene_sets[[i]], gene_sets[[j]])) /
          length(union(gene_sets[[i]], gene_sets[[j]]))
        if (is.finite(ji) && ji >= jaccard_cutoff) {
          edge_rows[[length(edge_rows) + 1L]] <- data.table(
            from = tab$term[i], to = tab$term[j], jaccard = ji)
        }
      }
    }
  }
  edges <- rbindlist(edge_rows, fill = TRUE)
  if (nrow(edges)) {
    gr <- graph_from_data_frame(edges, directed = FALSE, vertices = tab$term)
    cl <- cluster_louvain(gr, weights = E(gr)$jaccard)$membership
    tab[, cluster := as.integer(cl[term])]
  } else {
    tab[, cluster := seq_len(.N)]
  }
  reps <- tab[, .SD[which.min(padj)], by = cluster][, .(cluster, cluster_label = term)]
  tab <- merge(tab, reps, by = "cluster", all.x = TRUE, sort = FALSE)
  fwrite(tab, file.path(OUT, paste0(prefix, "_nodes.csv")))
  if (nrow(edges)) fwrite(edges, file.path(OUT, paste0(prefix, "_edges.csv"))) else
    fwrite(data.table(from = character(), to = character(), jaccard = numeric()),
           file.path(OUT, paste0(prefix, "_edges.csv")))
  invisible(list(nodes = tab, edges = edges))
}

cat("[1/8] Load gingival fibroblasts and score cell programs\n")
fb <- readRDS(FB_RDS)
if (nzchar(STUDY_FILTER)) {
  keep_cells <- rownames(fb[[]])[as.character(fb$Study) == STUDY_FILTER]
  if (!length(keep_cells)) stop("No cells matched Study == ", STUDY_FILTER)
  fb <- subset(fb, cells = keep_cells)
  cat("    study filter:", STUDY_FILTER, "cells:", ncol(fb), "\n")
}
md <- as.data.table(fb[[]])
md[, cell_id := colnames(fb)]
counts <- LayerData(fb, assay = "RNA", layer = "counts")
norm <- LayerData(fb, assay = "RNA", layer = "data")
gmt <- read_gmt(CURATED_GMT)

score_sets <- list(
  MAPK_ERK = gmt$MAPK_ERK_transcriptional_response,
  MAPK_JNK_p38 = gmt$MAPK_JNK_p38_transcriptional_response,
  ECM_synthesis = gmt$ECM_synthesis_collagen,
  ECM_organization = gmt$ECM_organization_structure,
  ECM_degradation = gmt$ECM_degradation_MMP_ADAMTS,
  ECM_inhibitors = gmt$ECM_inhibitors_TIMP,
  ECM_adhesion = gmt$ECM_adhesion_integrin,
  WNT_niche = gmt$WNT_niche_fibroblast_signature
)
score_sets <- score_sets[lengths(score_sets) > 0]
marker_genes <- intersect(c("GDF15", "MAPK1", "MAPK3", "JUND"), rownames(norm))
cell_keep <- c("cell_id", "frozen_umap_1", "frozen_umap_2", "fibroblast_short",
               "fibroblast_type", "disease", "Study", "donor_id",
               marker_genes, names(score_sets))
cell_score_path <- file.path(OUT, "05_cell_marker_and_program_scores.csv.gz")
if (file.exists(cell_score_path)) {
  md <- fread(cell_score_path)
  md <- md[match(colnames(fb), cell_id)]
} else {
  uc <- ScoreSignatures_UCell(matrix = counts, features = score_sets,
                              maxRank = 1500, ncores = 1, missing_genes = "skip")
  uc <- as.data.table(uc, keep.rownames = "cell_id")
  setnames(uc, names(uc), sub("_UCell$", "", names(uc)))
  md <- merge(md, uc, by = "cell_id", all.x = TRUE, sort = FALSE)
  md <- md[match(colnames(fb), cell_id)]
  marker_mat <- as.matrix(norm[marker_genes, , drop = FALSE])
  for (g in marker_genes) md[[g]] <- as.numeric(marker_mat[g, ])
  fwrite(md[, ..cell_keep], cell_score_path)
}

cell_summary <- rbindlist(lapply(c(marker_genes, names(score_sets)), function(v) {
  md[, .(n_cells = .N, mean = mean(get(v), na.rm = TRUE),
         median = median(get(v), na.rm = TRUE),
         detection_or_positive_fraction = mean(get(v) > 0, na.rm = TRUE)),
     by = .(fibroblast_short, disease)][, feature := v]
}))
fwrite(cell_summary, file.path(OUT, "06_cell_score_subtype_disease_summary.csv"))

type_levels <- c("Immune", "ECM remodeling", "Vascular", "Pre-ECM", "Matrix homeostasis")
avg_norm <- sapply(type_levels, function(tp) {
  Matrix::rowMeans(norm[, md$fibroblast_short == tp, drop = FALSE])
})
colnames(avg_norm) <- type_levels
prog <- progeny(as.matrix(avg_norm), scale = TRUE, organism = "Human", top = 100,
                 perm = 1, verbose = FALSE)
prog_long <- melt(as.data.table(prog, keep.rownames = "fibroblast_short"),
                  id.vars = "fibroblast_short", variable.name = "pathway",
                  value.name = "activity_z")
fwrite(prog_long, file.path(OUT, "07_PROGENy_pathway_by_fibroblast_subtype.csv"))

cat("[2/8] Donor-aware vascular fibroblast contrast\n")
pb <- readRDS(PB_RDS)
pb_counts <- pb$counts_donor_subtype
units <- colnames(pb_counts)
usp <- strsplit(units, "||", fixed = TRUE)
unit_meta <- data.table(
  unit = units,
  donor = vapply(usp, function(z) z[1], character(1)),
  subtype = vapply(usp, function(z) z[2], character(1))
)
di <- as.data.table(pb$donor_info)
unit_meta[di, on = c(donor = "donor_merged"), `:=`(Study = i.Study, disease = i.disease)]
if (nzchar(STUDY_FILTER)) {
  keep_units <- which(unit_meta$Study == STUDY_FILTER)
  unit_meta <- unit_meta[keep_units]
  pb_counts <- pb_counts[, keep_units, drop = FALSE]
  if (!ncol(pb_counts)) stop("No pseudobulk units matched Study == ", STUDY_FILTER)
}
unit_meta[, type_clean := factor(make.names(subtype), levels = make.names(c(
  "Immune", "ECM remodeling", "Vascular", "Pre-extracellular matrix", "Matrix homeostasis"
)))]

dge <- DGEList(pb_counts)
keep <- filterByExpr(dge, group = unit_meta$type_clean) |
  rownames(dge) %in% unique(c("GDF15", unlist(score_sets)))
dge <- calcNormFactors(dge[keep, , keep.lib.sizes = FALSE])
lcpm <- cpm(dge, log = TRUE, prior.count = 0.5)

form_v <- if (uniqueN(unit_meta$Study) > 1L)
  ~ 0 + type_clean + Study + disease else ~ 0 + type_clean + disease
design_v <- model.matrix(form_v, data = unit_meta)
colnames(design_v) <- make.names(colnames(design_v))
cor_v <- duplicateCorrelation(lcpm, design_v, block = unit_meta$donor)
fit_v <- lmFit(lcpm, design_v, block = unit_meta$donor,
               correlation = cor_v$consensus.correlation)
cn <- colnames(design_v)
v_name <- grep("type_cleanVascular$", cn, value = TRUE)
other_names <- grep("^type_clean", cn, value = TRUE)
other_names <- setdiff(other_names, v_name)
contrast_text <- paste0(v_name, "-(`", paste(other_names, collapse = "+"), "`)/4")
contrast_text <- gsub("`", "", contrast_text, fixed = TRUE)
cont_v <- makeContrasts(contrasts = contrast_text, levels = design_v)
fit_v2 <- eBayes(contrasts.fit(fit_v, cont_v), trend = TRUE, robust = TRUE)
tt_v <- as.data.table(topTable(fit_v2, number = Inf, sort.by = "P"), keep.rownames = "gene")

is_v <- md$fibroblast_short == "Vascular"
det_v <- Matrix::rowMeans(counts[, is_v, drop = FALSE] > 0)
det_o <- Matrix::rowMeans(counts[, !is_v, drop = FALSE] > 0)
tt_v[, diff_detection := det_v[gene] - det_o[gene]]
fwrite(tt_v, file.path(OUT, "08_vascular_vs_other_donor_aware_DE.csv.gz"))

universe_v <- tt_v$gene
top_v <- tt_v[logFC > 0][order(-t)][1:min(300, .N), gene]
run_ora_network(top_v, universe_v,
                c(GO_BP = GO_GMT, Reactome = REACTOME_GMT),
                "09_vascular_enrichment_network")

cat("[3/8] Derive donor-aware GDF15-associated protein-coding signature\n")
ann <- fread(file.path(OUT, "00_gene_annotations.csv.gz"))
ann <- ann[!duplicated(feature_name)]
gdf_z <- as.numeric(scale(lcpm["GDF15", ]))
form_g <- if (uniqueN(unit_meta$Study) > 1L)
  ~ gdf_z + type_clean + Study + disease else ~ gdf_z + type_clean + disease
design_g <- model.matrix(form_g, data = unit_meta)
cor_g <- duplicateCorrelation(lcpm, design_g, block = unit_meta$donor)
fit_g <- eBayes(lmFit(lcpm, design_g, block = unit_meta$donor,
                      correlation = cor_g$consensus.correlation),
                trend = TRUE, robust = TRUE)
tt_g <- as.data.table(topTable(fit_g, coef = "gdf_z", number = Inf, sort.by = "P"),
                      keep.rownames = "gene")
tt_g[ann, on = c(gene = "feature_name"), feature_biotype := i.feature_type]
fwrite(tt_g, file.path(OUT, "10_GDF15_association_all_genes.csv.gz"))

sig <- tt_g[gene != "GDF15" & feature_biotype == "protein_coding" &
              adj.P.Val < 0.05 & logFC > 0][order(-t)]
signature_candidate_n <- nrow(sig)
signature_source <- if (nzchar(STUDY_FILTER)) paste0(STUDY_FILTER, " scRNA") else "All-study scRNA"
if (nrow(sig) < 15) {
  fwrite(tt_g, file.path(OUT, "10a_GDF15_association_Williams_insufficient.csv.gz"))
  if (!nzchar(SIGNATURE_FALLBACK_DIR)) {
    stop("Fewer than 15 FDR-significant positive protein-coding GDF15 associates; no score was forced")
  }
  fallback_tt <- file.path(SIGNATURE_FALLBACK_DIR, "10_GDF15_association_all_genes.csv.gz")
  fallback_sig <- file.path(SIGNATURE_FALLBACK_DIR, "11_GDF15_associated_signature_genes.csv")
  if (!file.exists(fallback_tt) || !file.exists(fallback_sig)) {
    stop("Signature fallback files are missing from ", SIGNATURE_FALLBACK_DIR)
  }
  tt_g <- fread(fallback_tt)
  sig <- fread(fallback_sig)
  signature_source <- paste0(
    "All-study CELLxGENE fallback; ", STUDY_FILTER,
    " produced only ", signature_candidate_n,
    " eligible genes under the prespecified FDR rule"
  )
  fwrite(tt_g, file.path(OUT, "10_GDF15_association_all_genes.csv.gz"))
}
sig <- head(sig, 100)
sig[, signature_rank := seq_len(.N)]
fwrite(sig, file.path(OUT, "11_GDF15_associated_signature_genes.csv"))
sig_genes <- sig$gene

cpm_lin <- cpm(dge, log = FALSE)
mean_by_type <- sapply(levels(unit_meta$type_clean), function(tp) {
  rowMeans(cpm_lin[, unit_meta$type_clean == tp, drop = FALSE])
})
spec <- data.table(
  gene = rownames(mean_by_type),
  log10_mean_CPM = log10(rowMeans(mean_by_type) + 1e-3),
  maximum_subtype_specificity = apply(mean_by_type, 1, max) /
    pmax(rowSums(mean_by_type), 1e-12),
  max_subtype = levels(unit_meta$type_clean)[max.col(mean_by_type, ties.method = "first")]
)
spec[, in_signature := gene %in% sig_genes]
spec[, category := "Other signature gene"]
spec[gene %in% unique(score_sets$MAPK_ERK), category := "MAPK/ERK response"]
spec[gene %in% unique(c(score_sets$ECM_synthesis, score_sets$ECM_organization)),
     category := "ECM/collagen"]
spec[gene %in% c("FOS", "FOSB", "JUN", "JUNB", "JUND", "ATF3"), category := "AP-1"]
spec[in_signature == FALSE, category := "Background"]
fwrite(spec, file.path(OUT, "12_signature_expression_specificity.csv.gz"))

cat("[4/8] Prepare two independent human gingiva bulk cohorts\n")
module_membership <- fread(file.path(P2_SD, "03_module_gene_membership.csv"))
module_sets <- split(module_membership[module != "grey"]$gene_name,
                     module_membership[module != "grey"]$module)

prepare_bulk <- function(dataset) {
  if (dataset == "GSE223924") {
    x <- fread("C:/wb_links/dlc_data/external_GSE223924/GSE223924_raw_count.csv.gz")
    setnames(x, 1, "gene")
    samples <- c(paste0("H", 1:10), paste0("PT", c(1:8, 10, 11)))
    mat <- as.matrix(x[, ..samples]); rownames(mat) <- x$gene
    frac <- fread("C:/wb_links/dlc_derived/D11_deconvolution/D11_GSE223924_Bisque_cell_fractions.csv")
    batch <- NULL
  } else {
    x <- fread("C:/wb_links/dlc_data/external_GSE173078/GSE173078_rnaseq_raw_counts.txt.gz")
    setnames(x, 1, "gene")
    pd_a <- c("AC001", "AC003", "AC005", "AC007", "AC009", "AC011")
    h_a <- c("AC013", "AC016", "AC018", "AC019", "AC022", "AC024")
    pd_b <- c("AC037", "AC039", "AC042", "AC044", "AC046", "AC048")
    h_b <- c("AC050", "AC052", "AC054", "AC056", "AC058", "AC060")
    samples <- c(h_a, h_b, pd_a, pd_b)
    mat <- as.matrix(x[, ..samples]); rownames(mat) <- x$gene
    frac <- fread("C:/wb_links/dlc_derived/D11_deconvolution/D11_GSE173078_Bisque_cell_fractions.csv")
    batch <- frac$batch
  }
  storage.mode(mat) <- "numeric"
  ed <- DGEList(mat)
  keep_b <- filterByExpr(ed, group = frac$group) | rownames(ed) %in%
    unique(c(sig_genes, unlist(score_sets), unlist(module_sets), "GDF15"))
  ed <- calcNormFactors(ed[keep_b, , keep.lib.sizes = FALSE])
  ex <- cpm(ed, log = TRUE, prior.count = 0.5)
  ex <- ex[, frac$sample, drop = FALSE]

  sets_bulk <- c(list(GDF15_signature = sig_genes), score_sets)
  param <- ssgseaParam(exprData = ex, geneSets = sets_bulk,
                       minSize = 5, maxSize = 5000, normalize = TRUE,
                       verbose = FALSE)
  ss <- gsva(param, verbose = FALSE)
  score <- as.data.table(t(ss), keep.rownames = "sample")
  score[, dataset := dataset]
  score[, group := frac$group[match(sample, frac$sample)]]
  score[, batch := if ("batch" %in% names(frac)) frac$batch[match(sample, frac$sample)] else NA_character_]
  score[, fibroblast := frac$Fibroblast[match(sample, frac$sample)]]
  score[, epithelial := frac$Epithelial[match(sample, frac$sample)]]
  immune_cols <- intersect(c("T/NK", "B/Plasma", "Myeloid/DC", "Neutrophil", "Mast"), names(frac))
  immune_vec <- rowSums(as.matrix(frac[, ..immune_cols]))
  score[, immune := immune_vec[match(sample, frac$sample)]]
  score[, GDF15_expression := as.numeric(ex["GDF15", sample])]
  score[, signature_z := as.numeric(scale(GDF15_signature))]
  score[, PD := as.integer(group == "Periodontitis")]

  form <- if (dataset == "GSE173078")
    GDF15_signature ~ PD + factor(batch) + fibroblast + epithelial + immune else
    GDF15_signature ~ PD + fibroblast + epithelial + immune
  mod <- lm(form, data = score)
  ci <- confint(mod, "PD")
  group_test <- data.table(
    dataset = dataset,
    n_H = sum(score$group == "Healthy"), n_PD = sum(score$group == "Periodontitis"),
    median_H = median(score[group == "Healthy"]$GDF15_signature),
    median_PD = median(score[group == "Periodontitis"]$GDF15_signature),
    wilcox_p = wilcox.test(GDF15_signature ~ group, data = score, exact = FALSE)$p.value,
    adjusted_PD_beta = coef(mod)["PD"], adjusted_CI_low = ci[1],
    adjusted_CI_high = ci[2], adjusted_PD_p = summary(mod)$coefficients["PD", "Pr(>|t|)"]
  )

  design <- if (dataset == "GSE173078")
    model.matrix(~ signature_z + PD + factor(batch) + fibroblast + epithelial + immune, data = score) else
    model.matrix(~ signature_z + PD + fibroblast + epithelial + immune, data = score)
  fit <- eBayes(lmFit(ex, design), trend = TRUE, robust = TRUE)
  assoc <- as.data.table(topTable(fit, coef = "signature_z", number = Inf, sort.by = "none"),
                         keep.rownames = "gene")
  assoc[, dataset := dataset]

  mod_scores <- zmean_scores(ex, module_sets)
  mod_scores[, dataset := dataset]
  mod_scores[, group := frac$group[match(sample, frac$sample)]]
  mod_wide <- dcast(mod_scores, sample + dataset + group ~ program, value.var = "score")
  module_tests <- rbindlist(lapply(names(module_sets), function(mn) {
    sc <- mod_scores[program == mn]
    des <- if (dataset == "GSE173078")
      model.matrix(~ as.integer(group == "Periodontitis") + factor(frac$batch[match(sample, frac$sample)]), data = sc) else
      model.matrix(~ as.integer(group == "Periodontitis"), data = sc)
    ft <- eBayes(lmFit(matrix(sc$score, nrow = 1), des), trend = TRUE)
    cf <- 2L
    data.table(dataset = dataset, module = mn, beta_PD = ft$coefficients[1, cf],
               t = ft$t[1, cf], p = ft$p.value[1, cf])
  }))

  list(expr = ex, scores = score, group_test = group_test,
       gene_assoc = assoc, module_scores = mod_scores,
       module_wide = mod_wide, module_tests = module_tests)
}

b1 <- prepare_bulk("GSE223924")
b2 <- prepare_bulk("GSE173078")
bulk_scores <- rbindlist(list(b1$scores, b2$scores), fill = TRUE)
fwrite(bulk_scores, file.path(OUT, "13_bulk_signature_and_pathway_scores.csv"))
fwrite(rbindlist(list(b1$group_test, b2$group_test)),
       file.path(OUT, "14_bulk_signature_group_and_adjusted_tests.csv"))
fwrite(rbindlist(list(b1$gene_assoc, b2$gene_assoc)),
       file.path(OUT, "15_bulk_signature_gene_associations.csv.gz"))
fwrite(rbindlist(list(b1$module_scores, b2$module_scores)),
       file.path(OUT, "16_bulk_module_scores.csv"))
module_tests <- rbindlist(list(b1$module_tests, b2$module_tests))
fwrite(module_tests, file.path(OUT, "17_bulk_module_disease_tests.csv"))

cat("[5/8] Cross-platform preservation and fixed-effect meta-analysis\n")
cross_rows <- list()
for (ds in c("GSE223924", "GSE173078")) {
  ba <- if (ds == "GSE223924") b1$gene_assoc else b2$gene_assoc
  z <- merge(tt_g[, .(gene, sc_beta = logFC, sc_t = t, sc_fdr = adj.P.Val)],
             ba[, .(gene, bulk_beta = logFC, bulk_t = t, bulk_fdr = adj.P.Val)],
             by = "gene")
  z[ann, on = c(gene = "feature_name"), feature_biotype := i.feature_type]
  ct <- cor.test(z[feature_biotype == "protein_coding"]$sc_t,
                 z[feature_biotype == "protein_coding"]$bulk_t,
                 method = "spearman", exact = FALSE)
  z[, dataset := ds]
  z[, preservation_rho := unname(ct$estimate)]
  z[, preservation_p := ct$p.value]
  cross_rows[[ds]] <- z
}
cross <- rbindlist(cross_rows)
fwrite(cross, file.path(OUT, "18_scRNA_bulk_signature_preservation.csv.gz"))

m <- merge(b1$gene_assoc[, .(gene, beta1 = logFC, t1 = t)],
           b2$gene_assoc[, .(gene, beta2 = logFC, t2 = t)], by = "gene")
m[, `:=`(se1 = abs(beta1 / t1), se2 = abs(beta2 / t2))]
m <- m[is.finite(se1) & is.finite(se2) & se1 > 0 & se2 > 0]
m[, weight1 := 1 / se1^2][, weight2 := 1 / se2^2]
m[, meta_beta := (beta1 * weight1 + beta2 * weight2) / (weight1 + weight2)]
m[, meta_se := sqrt(1 / (weight1 + weight2))]
m[, meta_z := meta_beta / meta_se]
m[, meta_p := 2 * pnorm(-abs(meta_z))]
m[, meta_fdr := p.adjust(meta_p, "BH")]
m[ann, on = c(gene = "feature_name"), feature_biotype := i.feature_type]
fwrite(m, file.path(OUT, "19_bulk_signature_association_meta.csv.gz"))

meta_universe <- m$gene
top_meta <- m[meta_z > 0][order(-meta_z)][1:min(300, .N), gene]
run_ora_network(top_meta, meta_universe,
                c(GO_BP = GO_GMT, Reactome = REACTOME_GMT),
                "20_signature_meta_enrichment_network")

rank_vec <- m$meta_z
names(rank_vec) <- m$gene
rank_vec <- sort(rank_vec, decreasing = TRUE)
fg <- fgseaMultilevel(pathways = score_sets, stats = rank_vec,
                      minSize = 5, maxSize = 500, eps = 1e-50,
                      BPPARAM = BiocParallel::SerialParam())
fg <- as.data.table(fg)
fg[, leadingEdge := vapply(leadingEdge, paste, collapse = ";", character(1))]
fwrite(fg, file.path(OUT, "21_signature_meta_pathway_GSEA.csv"))

running_curve <- function(ranks, genes) {
  hits <- names(ranks) %in% genes
  nh <- sum(hits); nm <- length(hits) - nh
  if (!nh || !nm) return(data.table())
  w <- abs(ranks)
  hit_step <- ifelse(hits, w / sum(w[hits]), 0)
  miss_step <- ifelse(!hits, 1 / nm, 0)
  data.table(rank = seq_along(ranks), running_ES = cumsum(hit_step - miss_step),
             hit = hits, gene = names(ranks), statistic = ranks)
}
rc <- running_curve(rank_vec, score_sets$MAPK_ERK)
fg_erk <- fg[pathway == "MAPK_ERK"]
if (nrow(fg_erk)) rc[, `:=`(NES = fg_erk$NES[1], pval = fg_erk$pval[1], padj = fg_erk$padj[1])]
fwrite(rc, file.path(OUT, "22_MAPK_ERK_running_enrichment_curve.csv"))

cat("[6/8] Pooled bulk pathway associations\n")
path_names <- intersect(c("MAPK_ERK", "MAPK_JNK_p38", "ECM_synthesis",
                          "ECM_organization", "ECM_degradation", "WNT_niche"),
                        names(bulk_scores))
pooled <- copy(bulk_scores)
pooled[, signature_z_cohort := as.numeric(scale(GDF15_signature)), by = dataset]
pooled[, signature_group := ifelse(signature_z_cohort >= median(signature_z_cohort), "High", "Low"),
       by = dataset]
for (pn in path_names) pooled[, (paste0(pn, "_z")) := as.numeric(scale(get(pn))), by = dataset]
fwrite(pooled, file.path(OUT, "23_pooled_bulk_standardized_scores.csv"))

path_assoc <- rbindlist(lapply(path_names, function(pn) {
  y <- pooled[[paste0(pn, "_z")]]
  x <- pooled$signature_z_cohort
  ct <- cor.test(x, y, method = "spearman", exact = FALSE)
  lm_cont <- lm(y ~ x + factor(pooled$dataset))
  lm_full <- lm(y ~ x + pooled$PD + factor(pooled$dataset) +
                  pooled$fibroblast + pooled$epithelial + pooled$immune)
  lm_group <- lm(y ~ factor(pooled$signature_group) + factor(pooled$dataset))
  data.table(
    pathway = pn, n = length(y), spearman_rho = unname(ct$estimate),
    spearman_p = ct$p.value,
    continuous_beta = coef(lm_cont)["x"],
    continuous_p = summary(lm_cont)$coefficients["x", "Pr(>|t|)"],
    disease_composition_adjusted_beta = coef(lm_full)["x"],
    disease_composition_adjusted_p = summary(lm_full)$coefficients["x", "Pr(>|t|)"],
    high_vs_low_beta = coef(lm_group)["factor(pooled$signature_group)Low"] * -1,
    high_vs_low_p = summary(lm_group)$coefficients["factor(pooled$signature_group)Low", "Pr(>|t|)"]
  )
}))
path_assoc[, FDR := p.adjust(continuous_p, "BH")]
path_assoc[, adjusted_FDR := p.adjust(disease_composition_adjusted_p, "BH")]
fwrite(path_assoc, file.path(OUT, "24_signature_pathway_associations.csv"))

cat("[7/8] hdWGCNA module projections and turquoise network\n")
sc_mod <- fread(file.path(P2_SD, "07_module_disease_donor_stats.csv"))
sc_mod[, `:=`(dataset = SC_DATASET_LABEL, beta_PD = diff,
              t = qnorm(p_wilcox / 2, lower.tail = FALSE) * sign(diff), p = p_wilcox)]
module_all_tests <- rbindlist(list(
  sc_mod[, .(dataset, module, beta_PD, t, p)], module_tests
))
module_all_tests[, FDR := p.adjust(p, "BH"), by = dataset]
fwrite(module_all_tests, file.path(OUT, "25_module_cross_cohort_tests.csv"))

module_top_sets <- list()
for (mn in sort(unique(module_membership$module[module_membership$module != "grey"]))) {
  kcol <- paste0("kME_", mn)
  z <- module_membership[module == mn & is.finite(get(kcol))][order(-get(kcol))]
  module_top_sets[[mn]] <- head(z$gene_name, 50)
}
mod_cell_path <- file.path(OUT, "26_cell_hdWGCNA_top50_UCell_scores.csv.gz")
if (file.exists(mod_cell_path)) {
  mod_cell <- fread(mod_cell_path)
} else {
  mod_uc <- ScoreSignatures_UCell(matrix = counts, features = module_top_sets,
                                  maxRank = 1500, ncores = 1, missing_genes = "skip")
  mod_uc <- as.data.table(mod_uc, keep.rownames = "cell_id")
  setnames(mod_uc, names(mod_uc), sub("_UCell$", "", names(mod_uc)))
  mod_cell <- merge(md[, .(cell_id, frozen_umap_1, frozen_umap_2,
                           fibroblast_short, disease, Study, donor_id)],
                    mod_uc, by = "cell_id", all.x = TRUE, sort = FALSE)
  fwrite(mod_cell, mod_cell_path)
}
mod_cell_long <- melt(mod_cell, id.vars = c("cell_id", "fibroblast_short", "disease", "Study", "donor_id"),
                      measure.vars = names(module_top_sets), variable.name = "module", value.name = "score")
mod_sum <- mod_cell_long[, .(mean_score = mean(score), pct_positive = mean(score > 0)),
                         by = .(fibroblast_short, module)]
fwrite(mod_sum, file.path(OUT, "27_hdWGCNA_module_by_subtype_summary.csv"))

turq <- module_membership[module == "turquoise"]
turq <- turq[order(-kME_turquoise)][1:min(24, .N)]
expr_net <- lcpm[intersect(turq$gene_name, rownames(lcpm)), , drop = FALSE]
rho_net <- cor(t(expr_net), method = "spearman")
diag(rho_net) <- NA
edge_net <- as.data.table(as.table(rho_net))
setnames(edge_net, c("from", "to", "rho"))
edge_net <- edge_net[as.character(from) < as.character(to) & is.finite(rho) & rho > 0]
setorder(edge_net, -rho)
edge_net <- head(edge_net, 75)
node_net <- turq[gene_name %in% unique(c(as.character(edge_net$from), as.character(edge_net$to))),
                 .(gene = gene_name, kME = kME_turquoise)]
node_net[, category := "Other"]
node_net[gene %in% unique(score_sets$MAPK_ERK), category := "MAPK/ERK response"]
node_net[gene %in% unique(c(score_sets$ECM_synthesis, score_sets$ECM_organization)),
         category := "ECM/collagen"]
fwrite(node_net, file.path(OUT, "28_turquoise_network_nodes.csv"))
fwrite(edge_net, file.path(OUT, "29_turquoise_network_edges.csv"))

cat("[8/8] Analysis manifest\n")
manifest <- list(
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  scope = "Human gingiva and gingival fibroblasts only",
  study_filter = if (nzchar(STUDY_FILTER)) STUDY_FILTER else "All studies",
  n_fibroblast_cells = nrow(md),
  n_fibroblast_donors = uniqueN(md$donor_id),
  n_donor_subtype_units = nrow(unit_meta),
  GDF15_signature_rule = paste0(
    "Positive GDF15 coefficient, protein-coding, BH FDR < 0.05, donor-blocked limma; ",
    "GDF15 excluded; top 100 by moderated t. Selected n=", length(sig_genes)),
  GDF15_signature_source = signature_source,
  Williams_signature_candidate_n = signature_candidate_n,
  vascular_contrast = "Vascular fibroblasts minus mean of four other fibroblast states; donor-blocked limma",
  bulk_cohorts = c("GSE223924: 10 healthy + 10 periodontitis gingiva",
                   "GSE173078: 12 healthy + 12 periodontitis gingiva; gingivitis excluded"),
  causality_boundary = paste(
    "All transcriptomic scores are associative.",
    "They do not measure ERK1/2 phosphorylation and do not establish a direct GDF15 receptor mechanism."),
  sessionInfo = capture.output(sessionInfo())
)
saveRDS(list(manifest = manifest, signature = sig_genes, score_sets = score_sets,
             module_sets = module_sets), file.path(OUT, "30_analysis_checkpoint.rds"))
writeLines(jsonlite::toJSON(manifest, pretty = TRUE, auto_unbox = TRUE),
           file.path(OUT, "31_analysis_manifest.json"))
cat("Analysis completed successfully\n")
