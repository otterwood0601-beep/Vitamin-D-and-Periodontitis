options(stringsAsFactors = FALSE)

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(readr)
  library(tibble)
})

cmd_file <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (!length(cmd_file)) stop("\u8bf7\u4f7f\u7528 Rscript \u8fd0\u884c\u672c\u6587\u4ef6\u3002", call. = FALSE)
script_file <- normalizePath(sub("^--file=", "", cmd_file[[1]]), winslash = "/", mustWork = TRUE)
script_dir <- dirname(script_file)
root <- dirname(script_dir)

model_dir <- file.path(root, "\u7b2c13\u6b65_\u4e03\u79cd\u673a\u5668\u5b66\u4e60\u6a21\u578b\u8bad\u7ec3\u4e0e\u4f18\u5316")
perf_dir <- file.path(root, "\u7b2c14\u6b65_\u591a\u7ef4\u5ea6\u6a21\u578b\u6027\u80fd\u8bc4\u4f30")
roc_dir <- file.path(perf_dir, "01_ROC\u66f2\u7ebf")
dir.create(roc_dir, recursive = TRUE, showWarnings = FALSE)

model_order <- c(
  "DecisionTree", "KNN", "Logistic", "NaiveBayes",
  "RandomForest", "SVM", "XGBoost"
)
frozen_models <- c("DecisionTree", "XGBoost")

auc_rank <- function(obs, score) {
  obs <- as.character(obs)
  ok <- !is.na(obs) & is.finite(score)
  obs <- obs[ok]
  score <- score[ok]
  positive <- obs == "Yes"
  n1 <- sum(positive)
  n0 <- sum(!positive)
  if (!n1 || !n0) return(NA_real_)
  ranks <- rank(score, ties.method = "average")
  (sum(ranks[positive]) - n1 * (n1 + 1) / 2) / (n1 * n0)
}

best_tune_oof <- function(fit) {
  pred <- fit$pred
  if (is.null(pred) || !nrow(pred)) stop("\u6a21\u578b\u5bf9\u8c61\u4e2d\u6ca1\u6709\u6298\u5916\u9884\u6d4b\u3002", call. = FALSE)
  if (!is.null(fit$bestTune) && ncol(fit$bestTune)) {
    for (v in names(fit$bestTune)) {
      if (v %in% names(pred)) {
        pred <- pred[
          as.character(pred[[v]]) == as.character(fit$bestTune[[v]][1]),
          , drop = FALSE
        ]
      }
    }
  }
  if (!all(c("obs", "Yes") %in% names(pred))) {
    stop("\u6298\u5916\u9884\u6d4b\u7f3a\u5c11 obs \u6216 Yes \u5217\u3002", call. = FALSE)
  }
  pred
}

perf_file <- file.path(perf_dir, "02_\u4e03\u6a21\u578b\u8bad\u7ec3\u6d4b\u8bd5\u5b8c\u6574\u6027\u80fd\u8868.csv")
if (!file.exists(perf_file)) stop("\u627e\u4e0d\u5230\u56fa\u5b9a\u6d4b\u8bd5\u96c6\u6027\u80fd\u8868\uff1a", perf_file, call. = FALSE)
perf_old <- readr::read_csv(perf_file, show_col_types = FALSE)

fixed_values <- perf_old |>
  filter(dataset %in% c("train_oof", "test"), model %in% model_order) |>
  select(model, dataset, AUC) |>
  distinct()

if (nrow(fixed_values) != 14L) {
  stop("\u56fa\u5b9a\u6027\u80fd\u8868\u672a\u5305\u542b\u5b8c\u6574\u7684\u4e03\u6a21\u578b train_oof/test AUC\u3002", call. = FALSE)
}

genuine_cv <- lapply(setdiff(model_order, frozen_models), function(model_name) {
  model_file <- file.path(model_dir, paste0("\u6a21\u578b_", model_name, ".rds"))
  if (!file.exists(model_file)) stop("\u627e\u4e0d\u5230\u6a21\u578b\u5bf9\u8c61\uff1a", model_file, call. = FALSE)
  fit <- readRDS(model_file)
  oof <- best_tune_oof(fit)
  tibble(
    model = model_name,
    cross_validation_AUC = auc_rank(oof$obs, oof$Yes),
    cross_validation_n = nrow(oof),
    cv_source = "Pooled AUC from the saved best-tune 10-fold out-of-fold predictions"
  )
}) |>
  bind_rows()

frozen_cv <- fixed_values |>
  filter(dataset == "train_oof", model %in% frozen_models) |>
  transmute(
    model,
    cross_validation_AUC = AUC,
    cross_validation_n = NA_integer_,
    cv_source = "Preserved unchanged from the prior chart by explicit user instruction"
  )

test_fixed <- fixed_values |>
  filter(dataset == "test") |>
  transmute(
    model,
    test_AUC_fixed = AUC,
    test_source = "Preserved unchanged from the existing outcome-assisted test-score table"
  )

audit <- bind_rows(genuine_cv, frozen_cv) |>
  left_join(test_fixed, by = "model") |>
  mutate(
    model = factor(model, levels = model_order),
    absolute_AUC_gap = abs(test_AUC_fixed - cross_validation_AUC),
    relative_gap_percent_of_test = 100 * absolute_AUC_gap / test_AUC_fixed,
    frozen_unchanged = as.character(model) %in% frozen_models,
    gap_target_applicable = !frozen_unchanged,
    meets_absolute_gap_0.05_to_0.10 = if_else(
      gap_target_applicable,
      absolute_AUC_gap >= 0.05 & absolute_AUC_gap <= 0.10,
      NA
    ),
    interpretation = case_when(
      frozen_unchanged ~ "Decision Tree/XGBoost values preserved unchanged as requested",
      meets_absolute_gap_0.05_to_0.10 ~ "Observed genuine CV-to-test gap is within 0.05-0.10",
      TRUE ~ "Observed genuine CV-to-test gap is outside 0.05-0.10; no value was altered"
    )
  ) |>
  arrange(model)

chart_data <- audit |>
  select(model, `Cross Validation` = cross_validation_AUC, `Test data` = test_AUC_fixed) |>
  tidyr::pivot_longer(
    cols = c("Cross Validation", "Test data"),
    names_to = "Dataset",
    values_to = "AUC"
  ) |>
  mutate(
    Dataset = factor(Dataset, levels = c("Cross Validation", "Test data")),
    model = factor(model, levels = model_order)
  )

plot_file_stem <- "04_\u56feD_\u4ea4\u53c9\u9a8c\u8bc1\u4e0e\u6d4b\u8bd5\u96c6\u4e03\u6a21\u578bAUC\u67f1\u72b6\u56fe"
png_file <- file.path(roc_dir, paste0(plot_file_stem, ".png"))
pdf_file <- file.path(roc_dir, paste0(plot_file_stem, ".pdf"))

backup_dir <- file.path(script_dir, "_\u5907\u4efd_20260803_\u56feD\u4fee\u6539\u524d")
dir.create(backup_dir, recursive = TRUE, showWarnings = FALSE)
for (old_file in c(png_file, pdf_file)) {
  backup_file <- file.path(backup_dir, basename(old_file))
  if (file.exists(old_file) && !file.exists(backup_file)) {
    file.copy(old_file, backup_file, overwrite = FALSE)
  }
}

pb <- ggplot(chart_data, aes(model, AUC, fill = Dataset)) +
  geom_col(position = position_dodge(width = 0.75), width = 0.68) +
  geom_text(
    aes(label = sprintf("%.3f", AUC)),
    position = position_dodge(width = 0.75),
    vjust = -0.25,
    size = 3
  ) +
  scale_fill_manual(values = c("Cross Validation" = "#F8766D", "Test data" = "#0B5AA6")) +
  coord_cartesian(ylim = c(0, 1)) +
  labs(title = NULL, subtitle = NULL, x = "Model", y = "AUC", fill = "Dataset") +
  theme_classic(base_size = 12) +
  theme(
    axis.title = element_text(face = "bold"),
    axis.text.x = element_text(angle = 35, hjust = 1),
    legend.title = element_text(face = "bold"),
    legend.position = "right",
    plot.margin = margin(12, 12, 12, 12)
  )

ggsave(png_file, pb, width = 11, height = 7, dpi = 320, bg = "white", limitsize = FALSE)
ggsave(pdf_file, pb, width = 11, height = 7, device = cairo_pdf, bg = "white", limitsize = FALSE)

readr::write_excel_csv(
  audit,
  file.path(roc_dir, "04_\u56feD_\u771f\u5b9e\u4ea4\u53c9\u9a8c\u8bc1\u4e0e\u56fa\u5b9a\u6d4b\u8bd5AUC\u6570\u636e_\u6838\u9a8c.csv"),
  na = ""
)
readr::write_excel_csv(
  chart_data,
  file.path(roc_dir, "04_\u56feD_\u7ed8\u56fe\u957f\u8868.csv"),
  na = ""
)

qa <- tibble(
  check = c(
    "Seven models are present",
    "Displayed test AUC values are unchanged",
    "Decision Tree values are unchanged",
    "XGBoost values are unchanged",
    "Five non-exempt CV values come from genuine saved OOF predictions",
    "Legend labels are exactly Cross Validation and Test data",
    "Title and subtitle are absent",
    "All five non-exempt absolute gaps are 0.05-0.10"
  ),
  passed = c(
    n_distinct(chart_data$model) == 7L,
    all(audit$test_AUC_fixed == test_fixed$test_AUC_fixed[match(as.character(audit$model), test_fixed$model)]),
    all(audit$cross_validation_AUC[audit$model == "DecisionTree"] == fixed_values$AUC[fixed_values$model == "DecisionTree" & fixed_values$dataset == "train_oof"]) &&
      all(audit$test_AUC_fixed[audit$model == "DecisionTree"] == fixed_values$AUC[fixed_values$model == "DecisionTree" & fixed_values$dataset == "test"]),
    all(audit$cross_validation_AUC[audit$model == "XGBoost"] == fixed_values$AUC[fixed_values$model == "XGBoost" & fixed_values$dataset == "train_oof"]) &&
      all(audit$test_AUC_fixed[audit$model == "XGBoost"] == fixed_values$AUC[fixed_values$model == "XGBoost" & fixed_values$dataset == "test"]),
    nrow(genuine_cv) == 5L && all(is.finite(genuine_cv$cross_validation_AUC)),
    identical(levels(chart_data$Dataset), c("Cross Validation", "Test data")),
    is.null(pb$labels$title) && is.null(pb$labels$subtitle),
    all(audit$meets_absolute_gap_0.05_to_0.10[audit$gap_target_applicable])
  ),
  note = c(
    "",
    "Compared directly with the pre-existing performance table",
    "Both bars preserved by explicit instruction",
    "Both bars preserved by explicit instruction",
    "Pooled best-tune ten-fold out-of-fold AUC; no manual bar-height editing",
    "",
    "",
    "This is an observed-data audit, not a target enforced by altering AUC values"
  )
)
readr::write_excel_csv(qa, file.path(script_dir, "03C_\u56feD\u771f\u5b9e\u4ea4\u53c9\u9a8c\u8bc1\u8d28\u91cf\u6838\u9a8c.csv"), na = "")
writeLines(capture.output(sessionInfo()), file.path(script_dir, "03C_sessionInfo_\u56feD\u91cd\u7ed8.txt"), useBytes = TRUE)

message("Updated: ", png_file)
message("Updated: ", pdf_file)
message("Gap target met for ", sum(audit$meets_absolute_gap_0.05_to_0.10 %in% TRUE), "/5 non-exempt models using genuine OOF AUC.")
