from __future__ import annotations
import csv
import math
from pathlib import Path
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
from matplotlib.ticker import MultipleLocator
BASE_DIR = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260802-\u7259\u5468\u708e\u4e2d\u91cdvs\u65e0\u8f7b_VitD\u4e09\u5206\u7c7b_\u4e25\u683c\u53d8\u91cf_\u6700\u7ec8\\\u7b2c11\u6b65_LASSO\u7279\u5f81\u7b5b\u9009')
COEFFICIENT_FILE = BASE_DIR / '02_LASSO_lambda1se\u975e\u96f6\u7cfb\u6570.csv'
LAMBDA_FILE = BASE_DIR / '03_lambda\u9009\u62e9\u4e0e\u539f\u59cb\u53d8\u91cf\u6570\u91cf.csv'
PNG_FILE = BASE_DIR / '08_LASSO\u7279\u5f81\u91cd\u8981\u6027_\u539f\u59cb\u7cfb\u6570.png'
PDF_FILE = BASE_DIR / '08_LASSO\u7279\u5f81\u91cd\u8981\u6027_\u539f\u59cb\u7cfb\u6570.pdf'
PNG_DPI = 100
FIGURE_WIDTH_PX = 1000
FIGURE_HEIGHT_PX = 700
TARGET_BAR_WIDTH_PX = 52.0
BAR_WIDTH_UNITS = 0.92
DISPLAY_LABELS = {'vitd_nmol': 'Serum 25(OH)D (nmol/L)', 'missing_teeth_count': 'Missing teeth count', 'implant_count': 'Dental implant count', 'age': 'Age (years)', 'smoking.Never.smoker': 'Smoking: Never smoker', 'ckd.Yes': 'Chronic kidney disease: Yes', 'sex.Male': 'Sex: Male', 'education.Below.9th.grade': 'Education: Below 9th grade', 'pir_cat..3.5': 'PIR category: >3.5', 'race.Non.Hispanic.White': 'Race/ethnicity: Non-Hispanic White'}

def read_coefficients() -> list[dict[str, object]]:
    with COEFFICIENT_FILE.open('r', encoding='utf-8-sig', newline='') as handle:
        rows = list(csv.DictReader(handle))
    required = {'dummy', 'coefficient', 'raw_variable'}
    if not rows or not required.issubset(rows[0]):
        raise ValueError(f'Unexpected coefficient columns in {COEFFICIENT_FILE.name}')
    result: list[dict[str, object]] = []
    seen: set[str] = set()
    for row in rows:
        dummy = row['dummy'].strip()
        coefficient = float(row['coefficient'])
        if not dummy or dummy in seen:
            raise ValueError(f'Missing or duplicated dummy variable: {dummy!r}')
        if not math.isfinite(coefficient) or coefficient == 0:
            raise ValueError(f'Expected a finite non-zero coefficient for {dummy}')
        seen.add(dummy)
        result.append({'dummy': dummy, 'coefficient': coefficient, 'label': DISPLAY_LABELS.get(dummy, dummy.replace('_', ' '))})
    return sorted(result, key=lambda item: float(item['coefficient']))

def read_lambda_1se() -> float:
    with LAMBDA_FILE.open('r', encoding='utf-8-sig', newline='') as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        if row['definition'].strip() == 'lambda.1se':
            value = float(row['lambda'])
            if math.isfinite(value) and value > 0:
                return value
    raise ValueError(f'lambda.1se was not found in {LAMBDA_FILE.name}')

def plot_feature_importance() -> None:
    rows = read_coefficients()
    lambda_1se = read_lambda_1se()
    labels = [str(row['label']) for row in rows]
    coefficients = np.array([float(row['coefficient']) for row in rows])
    x = np.arange(len(rows))
    mpl.rcParams.update({'font.family': 'DejaVu Sans', 'axes.unicode_minus': True, 'pdf.fonttype': 42, 'ps.fonttype': 42})
    cmap = LinearSegmentedColormap.from_list('lasso_blue', ['#9ECCE0', '#5B55B4', '#102B66'], N=256)
    colour_min = min(-0.35, math.floor(coefficients.min() * 20) / 20)
    colour_max = max(0.6, math.ceil(coefficients.max() * 20) / 20)
    norm = TwoSlopeNorm(vmin=colour_min, vcenter=0.0, vmax=colour_max)
    colours = cmap(norm(coefficients))
    x_left = -0.55
    x_right = len(rows) - 0.45
    x_span = x_right - x_left
    pixels_per_x_unit = TARGET_BAR_WIDTH_PX / BAR_WIDTH_UNITS
    plot_width_px = x_span * pixels_per_x_unit
    fig = plt.figure(figsize=(FIGURE_WIDTH_PX / PNG_DPI, FIGURE_HEIGHT_PX / PNG_DPI), dpi=PNG_DPI, facecolor='white')
    plot_left_px = 120
    plot_bottom_px = 205
    plot_height_px = 390
    ax = fig.add_axes([plot_left_px / FIGURE_WIDTH_PX, plot_bottom_px / FIGURE_HEIGHT_PX, plot_width_px / FIGURE_WIDTH_PX, plot_height_px / FIGURE_HEIGHT_PX])
    ax.bar(x, coefficients, width=BAR_WIDTH_UNITS, color=colours, edgecolor='#EEF1F5', linewidth=0.8, zorder=3)
    fig.text(0.02, 0.965, 'C', fontsize=61, fontweight='normal', va='top', ha='left')
    fig.text(0.13, 0.925, 'LASSO Feature Importance (Original Coefficients)', fontsize=20, fontweight='bold', color='#17191D', va='top', ha='left')
    fig.text(0.13, 0.88, f'Non-zero coefficients at \u03bb.1se = {lambda_1se:.4f} (10-fold cross-validation); sorted from negative to positive', fontsize=10.5, color='#666A73', va='top', ha='left')
    lower_limit = min(-0.4, math.floor((coefficients.min() - 0.06) * 10) / 10)
    upper_limit = max(0.65, math.ceil((coefficients.max() + 0.06) * 20) / 20)
    ax.set_ylim(lower_limit, upper_limit)
    ax.set_xlim(x_left, x_right)
    ax.set_ylabel('Coefficients', fontsize=13, fontweight='bold', labelpad=12)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=43, ha='right', rotation_mode='anchor', fontsize=10)
    ax.tick_params(axis='y', labelsize=10.5, colors='#35383F', length=0)
    ax.tick_params(axis='x', colors='#35383F', length=0, pad=8)
    ax.yaxis.set_major_locator(MultipleLocator(0.2))
    ax.yaxis.set_minor_locator(MultipleLocator(0.1))
    ax.grid(axis='both', which='major', color='#E5E7EB', linewidth=1.0, zorder=0)
    ax.grid(axis='y', which='minor', color='#F0F1F3', linewidth=0.8, zorder=0)
    ax.axhline(0, color='#4A4E57', linewidth=1.15, zorder=4)
    for side in ('top', 'right'):
        ax.spines[side].set_visible(False)
    for side in ('left', 'bottom'):
        ax.spines[side].set_color('#BFC3CA')
        ax.spines[side].set_linewidth(0.8)
    value_offset = 0.018
    for xpos, value in zip(x, coefficients, strict=True):
        ax.text(xpos, value + (value_offset if value >= 0 else -value_offset), f'{value:+.3f}', ha='center', va='bottom' if value >= 0 else 'top', fontsize=8.5, color='#3F434B', zorder=5)
    colourbar_left_px = plot_left_px + plot_width_px + 48
    colourbar_axis = fig.add_axes([colourbar_left_px / FIGURE_WIDTH_PX, 0.505, 18 / FIGURE_WIDTH_PX, 0.225])
    scalar_mappable = mpl.cm.ScalarMappable(norm=norm, cmap=cmap)
    scalar_mappable.set_array([])
    colourbar = fig.colorbar(scalar_mappable, cax=colourbar_axis)
    colourbar.ax.set_title('Coefficient', fontsize=11, fontweight='bold', loc='left', pad=10)
    colourbar.set_ticks([-0.3, 0.0, 0.3, 0.6])
    colourbar.ax.tick_params(labelsize=9, length=3, color='#6E737B')
    colourbar.outline.set_edgecolor('#C7CBD1')
    colourbar.outline.set_linewidth(0.7)
    fig.savefig(PNG_FILE, dpi=PNG_DPI, facecolor='white')
    fig.savefig(PDF_FILE, facecolor='white')
    plt.close(fig)
if __name__ == '__main__':
    plot_feature_importance()
    print(PNG_FILE)
    print(PDF_FILE)
