options(stringsAsFactors = FALSE)
suppressPackageStartupMessages({
  library(caret)
  library(glmnet)
  library(ggplot2)
  library(readr)
  library(tibble)
})

cmd_file <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (!length(cmd_file)) stop("\u8bf7\u4f7f\u7528 Rscript \u8fd0\u884c\u672c\u6587\u4ef6\u3002", call. = FALSE)
script_file <- normalizePath(sub("^--file=", "", cmd_file[[1]]), winslash = "/", mustWork = TRUE)
script_dir <- dirname(script_file)
root <- dirname(script_dir)

lasso_dir <- file.path(root, "\u7b2c11\u6b65_LASSO\u7279\u5f81\u7b5b\u9009")
split_dir <- file.path(root, "\u7b2c12\u6b65_\u6570\u636e\u96c6\u5212\u5206")
screen_dir <- file.path(root, "\u7b2c12\u6b65\u9644\u52a0_\u591a\u91cd\u5171\u7ebf\u6027\u4e0eSpearman\u76f8\u5173\u5206\u6790")

split_object <- readRDS(file.path(split_dir, "07_\u56fa\u5b9a\u5212\u5206\u4e0e\u8bad\u7ec3\u96c6\u63d2\u8865\u5bf9\u8c61.rds"))
train <- split_object$train
lasso_candidates <- readr::read_csv(
  file.path(screen_dir, "07_\u6700\u7ec8\u8fdb\u5165LASSO\u7684\u5019\u9009\u53d8\u91cf\u5217\u8868.csv"),
  show_col_types = FALSE
)$variable
cv_auc <- readRDS(file.path(lasso_dir, "05_LASSO_cv\u5bf9\u8c61.rds"))

dummy_lasso <- caret::dummyVars(~ ., data = train[lasso_candidates], fullRank = TRUE)
XL <- predict(dummy_lasso, train[lasso_candidates]) |> as.matrix()
colnames(XL) <- make.names(colnames(XL), unique = TRUE)
y <- as.integer(train$outcome == "Yes")
raw_map <- vapply(colnames(XL), function(z) {
  hits <- lasso_candidates[startsWith(z, make.names(lasso_candidates))]
  if (length(hits)) hits[which.max(nchar(hits))] else z
}, character(1))
penalty <- ifelse(raw_map == "vitd_nmol", 0, 1)

if (length(cv_auc$foldid) != nrow(train)) stop("\u539fAUC\u5bf9\u8c61\u672a\u4fdd\u5b58\u5b8c\u6574foldid\u3002", call. = FALSE)
if (length(unique(cv_auc$foldid)) != 10L) stop("\u539fAUC\u5bf9\u8c61\u4e0d\u662f10\u6298\u4ea4\u53c9\u9a8c\u8bc1\u3002", call. = FALSE)

cv_class <- cv.glmnet(
  XL, y, family = "binomial", alpha = 1,
  lambda = cv_auc$lambda,
  foldid = cv_auc$foldid, nfolds = 10,
  type.measure = "class",
  penalty.factor = penalty,
  standardize = TRUE,
  keep = TRUE
)

misclass_path <- tibble(
  lambda = cv_class$lambda,
  log_lambda = log(cv_class$lambda),
  misclassification_error = cv_class$cvm,
  standard_error = cv_class$cvsd,
  lower = cv_class$cvlo,
  upper = cv_class$cvup,
  retained_raw_variables = vapply(cv_class$lambda, function(lambda_value) {
    coefficient <- as.matrix(coef(cv_auc$glmnet.fit, s = lambda_value))
    nonzero <- setdiff(rownames(coefficient)[coefficient[, 1] != 0], "(Intercept)")
    length(unique(raw_map[match(nonzero, colnames(XL))]))
  }, integer(1)),
  reference_lambda_min_auc = abs(lambda - cv_auc$lambda.min) == min(abs(lambda - cv_auc$lambda.min)),
  reference_lambda_1se_auc = abs(lambda - cv_auc$lambda.1se) == min(abs(lambda - cv_auc$lambda.1se))
)

smooth_input <- misclass_path[order(misclass_path$log_lambda), ]
display_spar <- 0.78
error_spline <- smooth.spline(
  x = smooth_input$log_lambda,
  y = smooth_input$misclassification_error,
  spar = display_spar
)
se_spline <- smooth.spline(
  x = smooth_input$log_lambda,
  y = smooth_input$standard_error,
  spar = display_spar
)
smooth_grid <- tibble(
  log_lambda = seq(min(smooth_input$log_lambda), max(smooth_input$log_lambda), length.out = 500),
  misclassification_error = predict(error_spline, x = log_lambda)$y,
  standard_error = pmax(predict(se_spline, x = log_lambda)$y, 0)
) |>
  transform(
    lower = pmax(misclassification_error - standard_error, 0),
    upper = pmin(misclassification_error + standard_error, 1)
  )
smooth_at_raw_x <- predict(error_spline, x = smooth_input$log_lambda)$y
raw_roughness <- sum(abs(diff(smooth_input$misclassification_error, differences = 2)))
smooth_roughness <- sum(abs(diff(smooth_at_raw_x, differences = 2)))

theme_pub <- function(bs = 12) {
  theme_classic(base_size = bs) +
    theme(
      plot.title = element_text(face = "bold", size = bs + 3),
      plot.subtitle = element_text(colour = "grey30"),
      axis.title = element_text(face = "bold"),
      legend.title = element_text(face = "bold")
    )
}

p_error <- ggplot() +
  geom_ribbon(
    data = smooth_grid,
    aes(x = log_lambda, ymin = lower, ymax = upper),
    fill = "grey85"
  ) +
  geom_line(
    data = smooth_grid,
    aes(x = log_lambda, y = misclassification_error),
    colour = "#2C7FB8", linewidth = 1
  ) +
  geom_point(
    data = misclass_path,
    aes(x = log_lambda, y = misclassification_error),
    colour = "#2C7FB8", size = 1.25, alpha = .58
  ) +
  geom_vline(xintercept = log(cv_auc$lambda.min), linetype = 3, colour = "#2C7FB8") +
  geom_vline(xintercept = log(cv_auc$lambda.1se), linetype = 2, colour = "#D7301F") +
  labs(
    title = "LASSO cross-validation curve",
    subtitle = "10-fold misclassification error; smoothed display; raw CV points and lambda references retained",
    x = "log(lambda)", y = "Misclassification Error"
  ) +
  theme_pub()

stem <- "06C_LASSO\u5341\u6298\u4ea4\u53c9\u9a8c\u8bc1MisclassificationError\u66f2\u7ebf"
png_path <- file.path(lasso_dir, paste0(stem, ".png"))
pdf_path <- file.path(lasso_dir, paste0(stem, ".pdf"))
ggsave(png_path, p_error, width = 10, height = 7, dpi = 320, bg = "white", limitsize = FALSE)
ggsave(pdf_path, p_error, width = 10, height = 7, device = cairo_pdf, bg = "white", limitsize = FALSE)
readr::write_excel_csv(misclass_path, file.path(lasso_dir, paste0(stem, "_\u5b8c\u6574\u8def\u5f84.csv")), na = "")
readr::write_excel_csv(smooth_grid, file.path(lasso_dir, paste0(stem, "_\u5e73\u6ed1\u663e\u793a\u6570\u636e.csv")), na = "")
saveRDS(cv_class, file.path(lasso_dir, "05C_LASSO_cv_MisclassificationError\u5bf9\u8c61.rds"))

qa <- tibble(
  check = c(
    "Misclassification error computed with cv.glmnet type.measure=class",
    "Same 10-fold allocation as original AUC curve",
    "Same lambda grid as original AUC curve",
    "Original AUC-based lambda reference lines retained",
    "Smoothing changes display only; original CV estimates retained",
    "Smoothed line has lower second-difference roughness",
    "Misclassification error is bounded between 0 and 1",
    "Final PNG and PDF exist and are non-empty"
  ),
  passed = c(
    identical(as.character(cv_class$call$type.measure), "class"),
    identical(as.integer(cv_class$foldid), as.integer(cv_auc$foldid)),
    isTRUE(all.equal(as.numeric(cv_class$lambda), as.numeric(cv_auc$lambda), tolerance = 1e-12)),
    is.finite(cv_auc$lambda.min) && is.finite(cv_auc$lambda.1se),
    nrow(misclass_path) == length(cv_class$cvm) && nrow(smooth_grid) == 500L,
    is.finite(raw_roughness) && is.finite(smooth_roughness) && smooth_roughness < raw_roughness,
    all(is.finite(misclass_path$misclassification_error)) &&
      all(misclass_path$misclassification_error >= 0 & misclass_path$misclassification_error <= 1),
    file.exists(png_path) && file.info(png_path)$size > 0 &&
      file.exists(pdf_path) && file.info(pdf_path)$size > 0
  ),
  detail = c(
    "Actual held-out class error; not a relabelled AUC and not 1-AUC",
    paste(length(unique(cv_class$foldid)), "folds"),
    paste(length(cv_class$lambda), "lambda values"),
    sprintf("lambda.min=%.8g; lambda.1se=%.8g", cv_auc$lambda.min, cv_auc$lambda.1se),
    sprintf("display spar=%.2f; %d raw points preserved", display_spar, nrow(misclass_path)),
    sprintf("roughness %.6f -> %.6f", raw_roughness, smooth_roughness),
    sprintf("range %.4f to %.4f", min(misclass_path$misclassification_error), max(misclass_path$misclassification_error)),
    paste(basename(png_path), basename(pdf_path), sep = " | ")
  ), check.names = FALSE
)
readr::write_excel_csv(qa, file.path(script_dir, "03B_LASSO\u8bef\u5206\u7c7b\u7387\u66f2\u7ebf\u8d28\u91cf\u6838\u9a8c.csv"), na = "")
writeLines(capture.output(sessionInfo()), file.path(script_dir, "03B_sessionInfo_LASSO\u8bef\u5206\u7c7b\u7387\u66f2\u7ebf.txt"), useBytes = TRUE)
if (!all(qa$passed)) stop("LASSO\u8bef\u5206\u7c7b\u7387\u66f2\u7ebf\u8d28\u91cf\u6838\u9a8c\u672a\u5168\u90e8\u901a\u8fc7\u3002", call. = FALSE)
message("LASSO misclassification-error curve completed: ", pdf_path)
