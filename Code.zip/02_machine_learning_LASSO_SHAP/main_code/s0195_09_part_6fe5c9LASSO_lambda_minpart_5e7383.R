suppressPackageStartupMessages(library(glmnet))

args_all <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args_all, value = TRUE)
if (length(file_arg) != 1L) {
  stop("Unable to resolve the script path.")
}

script_path <- normalizePath(sub("^--file=", "", file_arg), winslash = "/")
base_dir <- dirname(script_path)
model_path <- file.path(base_dir, "05_LASSO_cv\u5bf9\u8c61.rds")
output_path <- file.path(base_dir, "09_LASSO_lambda_min\u975e\u96f6\u7cfb\u6570.csv")

cv_fit <- readRDS(model_path)
if (!inherits(cv_fit, "cv.glmnet")) {
  stop("05_LASSO_cv\u5bf9\u8c61.rds is not a cv.glmnet object.")
}

coefficient_matrix <- as.matrix(coef(cv_fit, s = "lambda.min"))
keep <- rownames(coefficient_matrix) != "(Intercept)" & coefficient_matrix[, 1] != 0
selected <- coefficient_matrix[keep, 1]

if (length(selected) == 0L || any(!is.finite(selected))) {
  stop("No finite non-zero coefficients were found at lambda.min.")
}

dummy_names <- names(selected)
raw_variables <- sub("\\..*$", "", dummy_names)

output <- data.frame(
  dummy = dummy_names,
  coefficient = unname(selected),
  raw_variable = raw_variables,
  lambda = rep(cv_fit$lambda.min, length(selected)),
  selection_rule = rep("Non-zero coefficient at lambda.min", length(selected)),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

write.csv(output, output_path, row.names = FALSE, fileEncoding = "UTF-8")
cat(sprintf("lambda.min = %.15g\n", cv_fit$lambda.min))
cat(sprintf("non-zero coefficients excluding intercept = %d\n", nrow(output)))
cat(sprintf("raw variables = %d\n", length(unique(output$raw_variable))))
cat(output_path, "\n")
