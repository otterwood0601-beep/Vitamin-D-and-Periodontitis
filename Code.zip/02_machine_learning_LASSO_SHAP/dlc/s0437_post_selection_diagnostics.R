options(stringsAsFactors=FALSE,scipen=999)
.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(pROC);library(splines)})
ROOT<-'C:/wb_links/pan_multicohort_20261008_other';SD<-file.path(ROOT,'Exploratory_Axis5_20261008')
rr<-readRDS(file.path(SD,'07_exploration_results.rds'))
norm<-readRDS(file.path(ROOT,'08_normalized_cohorts.rds'))
meta<-copy(norm$meta);genes<-c('GDF15','MAPK1','MAPK3','MMP1','MMP3')
y<-as.integer(meta$group=='Periodontitis')
X<-t(do.call(cbind,lapply(norm$exprs,function(z)z[genes,,drop=FALSE])))
warnings<-list();errors<-list()
for(e in parse(file.path(SD,'run_exploration.R'))){
 if(is.call(e)&&identical(e[[1]],as.name('<-'))&&is.symbol(e[[2]])&&as.character(e[[2]]) %in% c('folds','predict_fold'))eval(e)
}
winner_id<-rr$summary$selected_subset$subset_id
ii<-rr$subsets[[winner_id]]$index;left<-setdiff(seq_len(nrow(meta)),ii)
fwrite(meta[left],file.path(SD,'10_complement_sample_metadata.csv'))
out<-list();pp<-list()
for(g in genes){
 meth<-rr$chosen[gene==g,method]
 p<-predict_fold(seq_len(nrow(meta)),list(tr=ii,te=left),meth,g,winner_id)
 a<-as.numeric(pROC::auc(pROC::roc(y[left],p,levels=c(0,1),direction='<',quiet=TRUE)))
 out[[g]]<-data.table(gene=g,method=meth,complement_N=length(left),complement_AUC=a,
  note='Complement was exposed during other subset searches; NOT untouched independent validation')
 pp[[g]]<-data.table(gene=g,sample=meta$sample[left],group=y[left],probability=sprintf('%.17g',p))
}
fwrite(rbindlist(out),file.path(SD,'10_complement_AUCs_NOT_independent.csv'))
fwrite(rbindlist(pp),file.path(SD,'10_complement_predictions_full_precision.csv'))
st<-list();stp<-list()
for(s in 1:20){
 seed<-30261008L+s;fid<-folds(y[ii],5L,seed)
 for(g in genes){
  meth<-rr$chosen[gene==g,method];p<-rep(NA_real_,length(ii))
  for(f in 1:5){a<-list(tr=which(fid!=f),te=which(fid==f));p[a$te]<-predict_fold(ii,a,meth,g,winner_id)}
  av<-as.numeric(pROC::auc(pROC::roc(y[ii],p,levels=c(0,1),direction='<',quiet=TRUE)))
  st[[length(st)+1L]]<-data.table(repeat_id=s,seed=seed,gene=g,method=meth,AUC=av)
  stp[[length(stp)+1L]]<-data.table(repeat_id=s,gene=g,sample=meta$sample[ii],group=y[ii],fold=fid,probability=sprintf('%.17g',p))
 }
}
stab<-rbindlist(st)
fwrite(stab,file.path(SD,'10_selected_subset_20_repeats_AUCs.csv'))
fwrite(rbindlist(stp),file.path(SD,'10_selected_subset_20_repeats_predictions.csv.gz'))
ss<-stab[,.(median_AUC=median(AUC),minimum=min(AUC),maximum=max(AUC),
 q05=quantile(AUC,.05),q95=quantile(AUC,.95),fraction_gt07=mean(AUC>.7)),by=gene]
fwrite(ss,file.path(SD,'10_repeat_stability_summary.csv'))
rate<-stab[,.(all_five_gt07=all(AUC>.7)),by=repeat_id]
fwrite(rate,file.path(SD,'10_repeat_all_five_gt07.csv'))
fullid<-rr$rankings[N==72 & type=='Complete cohort combination',subset_id]
fwrite(rr$results[subset_id==fullid],file.path(SD,'10_full_72_samples_all_methods_baseline.csv'))
print(rbindlist(out));print(ss);print(rate[,.(repeats=.N,repeats_all_five_gt07=sum(all_five_gt07))])
