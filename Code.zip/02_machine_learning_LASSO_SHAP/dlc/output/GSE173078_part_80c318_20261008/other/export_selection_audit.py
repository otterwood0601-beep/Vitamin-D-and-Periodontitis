from pathlib import Path
import csv
root = Path('E:/\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
sd = root / 'output/GSE173078_\u4ec5\u57fa\u56e0\u5efa\u6a21_20261008/\u5176\u4ed6'
old = root / 'output/BioorganicChemistry2026_\u5e72\u5b9e\u9a8c\u8fc1\u79fb_20260924/source_data'
with (old / '17_ML_candidate_genes.csv').open(encoding='utf-8-sig', newline='') as f:
    candidates = list(csv.DictReader(f))
with (old / '08_vitaminD_VDR_gene_set_audit.csv').open(encoding='utf-8-sig', newline='') as f:
    audits = {r['gene']: r for r in csv.DictReader(f)}
with (sd / '19_gene_selection_provenance.csv').open('w', encoding='utf-8-sig', newline='') as f:
    w = csv.writer(f)
    w.writerow(['gene', 'selection_type', 'original_annotation_source', 'historical_disease_FDR', 'selection_history_cohorts', 'new_analysis_cohort', 'independent_discovery'])
    for r in candidates:
        prior = r['role'].startswith('Prespecified')
        a = audits.get(r['gene'], {})
        w.writerow([r['gene'], r['role'], 'Research hypothesis' if prior else a.get('sources', ''), '' if prior else a.get('disease_FDR', ''), 'Hypothesis-prespecified' if prior else 'GSE223924 + GSE173078', 'GSE173078 only', 'No'])
print('Exported selection provenance: 11 prespecified + 9 historical vitamin D/gingiva overlap genes.')
