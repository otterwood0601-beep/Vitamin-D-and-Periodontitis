options(stringsAsFactors = FALSE)
p <- c('data.table','ggplot2','patchwork','glmnet','randomForest','e1071',
       'xgboost','pROC','GGally','ggplotify','edgeR','limma','ragg','jsonlite')
print(.libPaths())
print(sapply(p, requireNamespace, quietly=TRUE))
library(data.table)
z <- fread('C:/wb_links/dlc_data/external_GSE173078/GSE173078_rnaseq_raw_counts.txt.gz')
print(dim(z)); print(names(z)[1:8]); setnames(z, 1, 'gene')
print(z[gene %in% c('GDF15')])
