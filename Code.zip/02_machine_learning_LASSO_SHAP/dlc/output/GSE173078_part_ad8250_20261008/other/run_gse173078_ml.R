options(stringsAsFactors=FALSE, scipen=999)
set.seed(20261008)
suppressPackageStartupMessages({
  library(data.table); library(ggplot2); library(patchwork); library(glmnet)
  library(randomForest); library(e1071); library(xgboost); library(pROC)
  library(GGally); library(ggplotify); library(edgeR); library(limma)
  library(jsonlite); library(ragg)
})
SD <- 'C:/wb_links/gse173078_ml_20261008_other'
FD <- 'C:/wb_links/gse173078_ml_20261008_figures'
COUNTS <- 'C:/wb_links/dlc_data/external_GSE173078/GSE173078_rnaseq_raw_counts.txt.gz'
MATRIX <- 'C:/wb_links/dlc_data/external_GSE173078/GSE173078_series_matrix.txt.gz'
OLD_CODE <- 'C:/wb_links/bioorgchem2026_code/03_fig3_ml.R'
BASE <- 'Fig3_GSE173078_only_ML_GDF15_ERK_MMP_20261008'
METHOD_VERSION <- 'phenotype_balanced_repeated5fold_v2'
if (file.exists(file.path(FD,paste0(BASE,'.pdf'))) &&
    !identical(Sys.getenv('GSE173078_REBUILD'),'1')) stop('Final PDF already exists; no overwrite.')
logcon <- file(file.path(SD,'analysis.log'),open='wt')
sink(logcon,split=TRUE); sink(logcon,type='message')
message('[1/6] Load GSE173078 raw counts and verify donor/sample labels')
raw <- fread(COUNTS); setnames(raw,1,'gene')
if (anyDuplicated(raw$gene)) stop('Duplicate gene symbols require explicit resolution.')
mlines <- readLines(gzfile(MATRIX))
get_values <- function(line) gsub('^"|"$','',strsplit(line,'\t')[[1]][-1])
titles <- get_values(mlines[startsWith(mlines,'!Sample_title\t')])
gsm <- get_values(mlines[startsWith(mlines,'!Sample_geo_accession\t')])
chars <- mlines[startsWith(mlines,'!Sample_characteristics_ch1\t')]
get_char <- function(prefix) {
  vals <- lapply(chars,get_values)
  rows <- vapply(vals,function(v) all(startsWith(tolower(v),tolower(paste0(prefix,':')))),logical(1))
  stopifnot(sum(rows)==1)
  sub('^[^:]+: *','',vals[[which(rows)]])
}
meta_all <- data.table(sample=sub('_.*','',titles),GSM=gsm,dataset='GSE173078',
                       phenotype=get_char('phenotype'),batch=get_char('batch'),
                       sex=get_char('Sex'),age=as.numeric(get_char('age')),
                       tissue=get_char('tissue'))
stopifnot(nrow(meta_all)==36,all(grepl('gingival',meta_all$tissue,ignore.case=TRUE)))
meta <- copy(meta_all[phenotype %in% c('Healthy','Periodontitis')])
meta[,group:=factor(ifelse(phenotype=='Healthy','Control','Periodontitis'),
                     levels=c('Control','Periodontitis'))]
meta[,batch:=factor(batch,levels=c('A','B'))]
setorder(meta,group,batch,sample)
stopifnot(nrow(meta)==24,uniqueN(meta$sample)==24,
          all(table(meta$group)==12),all(table(meta$group,meta$batch)==6))
fwrite(meta,file.path(SD,'01_GSE173078_sample_metadata.csv'))
fwrite(meta_all[phenotype=='Gingivitis'],file.path(SD,'02_excluded_gingivitis.csv'))
samples <- meta$sample
counts <- as.matrix(raw[,..samples]); rownames(counts) <- raw$gene
storage.mode(counts) <- 'numeric'
stopifnot(all(is.finite(counts)),all(counts>=0),all(counts==round(counts)))
library_sizes <- colSums(counts)
stopifnot(all(library_sizes>0))

expr_raw <- log2(sweep(counts,2,library_sizes/1e6,'/')+1)
feature_genes <- c('GDF15','MAPK1','MAPK3','MMP1','MMP7','MMP9')

candidate_genes <- c('GDF15','MAPK1','MAPK3','MMP1','MMP2','MMP3',
  'MMP7','MMP8','MMP9','MMP13','MMP14','NCOA3','CYP24A1','SPP1',
  'SNAI1','MN1','LGMN','AQP3','LPL','SFRP1')
stopifnot(all(candidate_genes %in% rownames(expr_raw)),
          all(apply(expr_raw[candidate_genes,,drop=FALSE],1,sd)>0))
fwrite(data.table(gene=candidate_genes,role=ifelse(candidate_genes %in% feature_genes,
  'Fixed six-gene panel','Historical comparison gene (fixed, not reselected)')),
  file.path(SD,'03_fixed_candidate_genes.csv'))
fwrite(data.table(sample=samples,library_size=library_sizes),file.path(SD,'04_library_sizes.csv'))
X <- t(expr_raw[candidate_genes,,drop=FALSE])
y <- as.integer(meta$group=='Periodontitis'); b <- as.integer(meta$batch=='B')
N <- length(y)

for (e in parse(OLD_CODE)) {
  if (is.call(e) && identical(e[[1]],as.name('<-')) && is.symbol(e[[2]]) &&
      as.character(e[[2]]) %in% c('safe_auc','predict_model','paper_theme','roc_cols','layout_design'))
    eval(e)
}
prep <- function(train,test,genes) {
  z <- X[train,genes,drop=FALSE]
  
  design <- cbind(intercept=1,batchB=b[train],disease=y[train])
  nuisance_coef <- lm.fit(design,z)$coefficients
  beta <- if (is.null(dim(nuisance_coef))) unname(nuisance_coef['batchB']) else
    nuisance_coef['batchB',]
  if (any(!is.finite(beta))) stop('Training batch coefficient not estimable.')
  ztr <- z-outer(b[train],beta)
  zte <- X[test,genes,drop=FALSE]-outer(b[test],beta)
  mu <- colMeans(ztr); ss <- apply(ztr,2,sd); ss[!is.finite(ss)|ss<1e-12] <- 1
  ztr <- sweep(sweep(ztr,2,mu,'-'),2,ss,'/')
  zte <- sweep(sweep(zte,2,mu,'-'),2,ss,'/')
  stopifnot(all(is.finite(ztr)),all(is.finite(zte)))
  list(xtr=ztr,xte=zte,mu=mu,sd=ss,batch_beta=beta)
}
stratified_folds <- function(indices,k,seed) {
  set.seed(seed); fid <- integer(length(indices))

  strata <- factor(y[indices])
  for (s in levels(strata)) {
    positions <- which(strata==s)
    fid[positions] <- sample(rep(seq_len(k),length.out=length(positions)))
  }
  stopifnot(all(seq_len(k) %in% fid))
  fid
}
warns <- data.table(stage=character(),model=character(),warning=character())
errors <- data.table(stage=character(),model=character(),error=character())
fit_once <- function(model,train,test,genes,seed,stage) {
  tryCatch(withCallingHandlers({
    set.seed(seed)
    pp <- prep(train,test,genes)
    if (model %in% c('Ridge','Lasso','Elastic net')) {
      alpha <- unname(c(Ridge=0,Lasso=1,`Elastic net`=0.5)[model])
      lambda_grid <- 10^seq(1,-4,length.out=24)
      inner <- stratified_folds(train,5,seed+100000)
      losses <- matrix(NA_real_,length(train),length(lambda_grid))
      for (f in 1:5) {
        itrain <- train[inner!=f]; ival <- train[inner==f]
        ip <- prep(itrain,ival,genes)
        fit <- glmnet(ip$xtr,y[itrain],family='binomial',alpha=alpha,
                      lambda=lambda_grid,standardize=FALSE)
        prob <- as.matrix(predict(fit,newx=ip$xte,s=lambda_grid,type='response'))
        prob <- pmin(pmax(prob,1e-8),1-1e-8)
        losses[which(inner==f),] <- -(y[ival]*log(prob)+(1-y[ival])*log(1-prob))
      }
      j <- which.min(colMeans(losses))
      fit <- glmnet(pp$xtr,y[train],family='binomial',alpha=alpha,
                    lambda=lambda_grid,standardize=FALSE)
      out <- as.numeric(predict(fit,newx=pp$xte,s=lambda_grid[j],type='response'))
    } else out <- predict_model(model,pp$xtr,y[train],pp$xte)
    if (length(out)!=length(test) || any(!is.finite(out))) stop('Invalid prediction.')
    out
  },warning=function(w) {
    warns <<- rbind(warns,data.table(stage=stage,model=model,warning=conditionMessage(w)))
    invokeRestart('muffleWarning')
  }),error=function(e) {
    errors <<- rbind(errors,data.table(stage=stage,model=model,error=conditionMessage(e)))
    rep(NA_real_,length(test))
  })
}
model_names <- c('Logistic','Ridge','Lasso','Elastic net','Random forest',
                 'SVM linear','SVM radial','XGBoost')
row_names <- c(model_names,paste0('Gene: ',candidate_genes))
model_genes <- setNames(c(rep(list(feature_genes),length(model_names)),
                         lapply(candidate_genes,function(g) g)),row_names)
algorithms <- setNames(c(model_names,rep('Logistic',length(candidate_genes))),row_names)
apparent <- loo <- matrix(NA_real_,N,length(row_names),dimnames=list(samples,row_names))
repeated <- array(NA_real_,dim=c(N,length(row_names),10),
                  dimnames=list(samples,row_names,paste0('Repeat',1:10)))
fold_map <- rbindlist(lapply(1:10,function(r) data.table(sample=samples,repeat_id=r,
  fold_id=stratified_folds(seq_len(N),5,20261008+r*100))))
fwrite(fold_map,file.path(SD,'05_repeated5fold_assignments.csv'))
checkpoint <- file.path(SD,'06_model_inputs_predictions.rds')
if (file.exists(checkpoint)) {
  cp <- readRDS(checkpoint)
  stopifnot(identical(lapply(cp$meta,as.character),lapply(meta,as.character)),
            identical(cp$expr_raw,expr_raw[candidate_genes,,drop=FALSE]),
            identical(dimnames(cp$loo),dimnames(loo)))
  if (identical(cp$method_version,METHOD_VERSION)) {
    apparent <- cp$apparent; loo <- cp$loo; repeated <- cp$repeated
  }
  if (identical(cp$method_version,METHOD_VERSION) && file.exists(file.path(SD,'07_model_warnings.csv')))
    warns <- fread(file.path(SD,'07_model_warnings.csv'))
  if (file.exists(file.path(SD,'08_model_errors.csv')) &&
      !file.exists(file.path(SD,'08_initial_attempt_errors.csv')))
    file.copy(file.path(SD,'08_model_errors.csv'),file.path(SD,'08_initial_attempt_errors.csv'))
}
message('[2/6] Fit 8 models and 20 fixed single-gene models; fold-local preprocessing')
for (j in seq_along(row_names)) {
  label <- row_names[j]; alg <- algorithms[[label]]; genes <- model_genes[[label]]
  if (all(is.finite(apparent[,j])) && all(is.finite(loo[,j])) && all(is.finite(repeated[,j,]))) {
    message(sprintf('Reuse completed model %02d/%02d: %s',j,length(row_names),label)); next
  }
  message(sprintf('Model %02d/%02d: %s',j,length(row_names),label))
  apparent[,j] <- fit_once(alg,seq_len(N),seq_len(N),genes,20261008+j,
                           paste0(label,' apparent'))
  for (i in seq_len(N)) {
    loo[i,j] <- fit_once(alg,setdiff(seq_len(N),i),i,genes,20261008+j*1000+i,
                         paste0(label,' LOOCV ',i))
  }
  for (r in 1:10) {
    fold_ids <- fold_map[repeat_id==r,fold_id]
    for (f in 1:5) {
      test <- which(fold_ids==f); train <- which(fold_ids!=f)
      repeated[test,j,r] <- fit_once(alg,train,test,genes,
        20261008+j*10000+r*100+f,paste0(label,' repeat ',r,' fold ',f))
    }
  }
}
repmean <- apply(repeated,c(1,2),mean)
saveRDS(list(method_version=METHOD_VERSION,meta=meta,expr_raw=expr_raw[candidate_genes,,drop=FALSE],
             apparent=apparent,loo=loo,repeated=repeated,repeated_mean=repmean),
        file.path(SD,'06_model_inputs_predictions.rds'))
fwrite(warns,file.path(SD,'07_model_warnings.csv'))
fwrite(errors,file.path(SD,'08_model_errors.csv'))
if (nrow(errors)) stop('Some model fits failed; see 08_model_errors.csv. Do not silently report partial models.')
auc_rows <- data.table(model=row_names,
  Apparent=vapply(seq_along(row_names),function(j) safe_auc(y,apparent[,j]),numeric(1)),
  LOOCV=vapply(seq_along(row_names),function(j) safe_auc(y,loo[,j]),numeric(1)),
  Repeated5CV=vapply(seq_along(row_names),function(j) safe_auc(y,repmean[,j]),numeric(1)),
  model_class=c(rep('Six-gene panel',length(model_names)),rep('Single gene',length(candidate_genes))))
setorder(auc_rows,-Repeated5CV,-LOOCV)
fwrite(auc_rows,file.path(SD,'09_ML_model_AUCs.csv'))
prediction_table <- rbindlist(lapply(seq_along(row_names),function(j) rbindlist(list(
  data.table(sample=samples,dataset='GSE173078',group=as.character(meta$group),
    model=row_names[j],method='Apparent',probability=apparent[,j]),
  data.table(sample=samples,dataset='GSE173078',group=as.character(meta$group),
    model=row_names[j],method='LOOCV',probability=loo[,j]),
  data.table(sample=samples,dataset='GSE173078',group=as.character(meta$group),
    model=row_names[j],method='Repeated5CV_mean',probability=repmean[,j])))))
fwrite(prediction_table,file.path(SD,'10_ML_predictions.csv.gz'))

set.seed(20261008)
boot_idx <- replicate(1000,c(sample(which(y==0),12,replace=TRUE),
                             sample(which(y==1),12,replace=TRUE)),simplify=FALSE)
ci_rows <- rbindlist(lapply(seq_along(row_names),function(j) {
  vals <- vapply(boot_idx,function(k) safe_auc(y[k],repmean[k,j]),numeric(1))
  data.table(model=row_names[j],Repeated5CV=safe_auc(y,repmean[,j]),
             CI_lower=quantile(vals,.025),CI_upper=quantile(vals,.975),
             interval_type='Stratified fixed-OOF-score bootstrap; model not refit')
}))
fwrite(ci_rows,file.path(SD,'11_repeated5CV_AUC_conditional_CI.csv'))
message('[3/6] Descriptive expression and batch-adjusted disease tests: GSE173078 only')
expressed <- rowSums(counts>=5)>=6
design <- model.matrix(~ batch+group,data=meta)
fit <- eBayes(lmFit(expr_raw[expressed,,drop=FALSE],design),trend=TRUE,robust=TRUE)
de_all <- as.data.table(topTable(fit,coef='groupPeriodontitis',number=Inf,sort.by='none'),
                        keep.rownames='gene')
fwrite(de_all,file.path(SD,'12_GSE173078_batch_adjusted_disease_tests.csv.gz'))
axis_tests <- de_all[gene %in% feature_genes]
stopifnot(nrow(axis_tests)==6)
axis_tests[,q_panel:=p.adjust(P.Value,method='BH')]
axis_tests[,label:=fifelse(q_panel<.001,'***',fifelse(q_panel<.01,'**',fifelse(q_panel<.05,'*','ns')))]
fwrite(axis_tests,file.path(SD,'13_six_gene_disease_tests.csv'))
expr_show <- removeBatchEffect(expr_raw[feature_genes,,drop=FALSE],batch=meta$batch,
                               design=model.matrix(~group,data=meta))
expr6 <- as.data.table(expr_show,keep.rownames='gene')
expr6 <- melt(expr6,id.vars='gene',variable.name='sample',value.name='expression')
expr6[meta,on='sample',group:=i.group]
fwrite(expr6,file.path(SD,'14_panelB_expression.csv'))
pair_df <- as.data.frame(t(expr_show))
corr_rows <- rbindlist(lapply(combn(feature_genes,2,simplify=FALSE),function(g) {
  ct <- cor.test(pair_df[[g[1]]],pair_df[[g[2]]],method='pearson')
  
  r1 <- residuals(lm(expr_raw[g[1],]~meta$group+meta$batch))
  r2 <- residuals(lm(expr_raw[g[2],]~meta$group+meta$batch))
  data.table(gene1=g[1],gene2=g[2],Pearson_r=unname(ct$estimate),P=ct$p.value,
    CI_lower=ct$conf.int[1],CI_upper=ct$conf.int[2],
    group_batch_adjusted_r=cor(r1,r2))
}))
corr_rows[,FDR:=p.adjust(P,'BH')]
fwrite(corr_rows,file.path(SD,'15_panelC_correlations.csv'))
message('[4/6] Rebuild A-D with the original figure dimensions, palette, fonts and layout')
auc_long <- melt(auc_rows,id.vars=c('model','model_class'),
  measure.vars=c('Apparent','LOOCV','Repeated5CV'),variable.name='Evaluation',value.name='AUC')
auc_long[,Evaluation:=factor(Evaluation,levels=c('Apparent','LOOCV','Repeated5CV'),
                             labels=c('Apparent (not CV)','LOOCV','10x5-fold CV'))]
auc_long[,model:=factor(model,levels=rev(auc_rows$model))]
pA <- ggplot(auc_long,aes(Evaluation,model,fill=AUC))+
  geom_tile(colour='white',linewidth=.35)+
  geom_text(aes(label=ifelse(is.finite(AUC),sprintf('%.3f',AUC),'NA')),
            size=2.25,family='Arial')+
  scale_fill_gradient2(low='#2878B5',mid='white',high='#D73027',midpoint=.6,
                       limits=c(0,1),name='AUC')+
  labs(x=NULL,y=NULL)+paper_theme+
  theme(axis.text.y=element_text(size=5.8),
        axis.text.x=element_text(angle=45,hjust=1),legend.position='bottom')
stars <- merge(axis_tests[,.(gene,label)],expr6[,.(y=max(expression)+.55),by=gene],by='gene')
expr6[,gene:=factor(gene,levels=feature_genes)]; stars[,gene:=factor(gene,levels=feature_genes)]
pB <- ggplot(expr6,aes(gene,expression,fill=group))+
  geom_boxplot(width=.64,outlier.size=.65,linewidth=.35,position=position_dodge(width=.72))+
  geom_text(data=stars,aes(gene,y,label=label),inherit.aes=FALSE,size=3.2,fontface='bold',family='Arial')+
  scale_fill_manual(values=c(Control='#3C91E6',Periodontitis='#F04E55'),name='Type')+
  labs(x=NULL,y='Gene expression (log2 CPM + 1)')+paper_theme+
  theme(axis.text.x=element_text(angle=40,hjust=1),legend.position='top')
pairs <- ggpairs(pair_df,
  upper=list(continuous=wrap('cor',size=3.2,colour='black')),
  lower=list(continuous=wrap('smooth',alpha=.45,size=.35,colour='#D65F73')),
  diag=list(continuous=wrap('densityDiag',fill='#BFBFBF',alpha=.6)),progress=FALSE)+
  theme_bw(base_size=6,base_family='Arial')
pC <- as.ggplot(~print(pairs))
roc_curves <- rbindlist(lapply(feature_genes,function(g) {
  r <- roc(y,repmean[,paste0('Gene: ',g)],levels=c(0,1),direction='<',quiet=TRUE)
  data.table(gene=g,specificity=r$specificities,sensitivity=r$sensitivities,AUC=as.numeric(auc(r)))
}))
roc_labels <- unique(roc_curves[,.(gene,AUC)])
roc_labels[,legend:=paste0(gene,', AUC=',sprintf('%.3f',AUC))]
roc_curves[roc_labels,on='gene',legend:=i.legend]
fwrite(roc_curves,file.path(SD,'16_panelD_repeated5CV_ROC.csv'))
pD <- ggplot(roc_curves,aes(1-specificity,sensitivity,colour=legend))+
  geom_abline(slope=1,intercept=0,colour='#777777',linewidth=.35)+geom_step(linewidth=.75)+
  scale_colour_manual(values=setNames(roc_cols[roc_labels$gene],roc_labels$legend),name=NULL)+
  coord_equal()+labs(x='1 - Specificity',y='Sensitivity',subtitle='GSE173078 - 10x5-fold CV')+paper_theme+
  theme(plot.subtitle=element_text(size=7,hjust=.5),legend.position=c(.62,.25),
        legend.background=element_rect(fill=scales::alpha('white',.78),colour=NA))
fig <- pA+pB+pC+pD+plot_layout(design=layout_design,heights=c(.72,1.15,1.05))+
  plot_annotation(tag_levels='A',caption=paste(
    'GSE173078 only: 12 control + 12 periodontitis; no external validation.',
    'A: apparent / LOOCV / 10x5-fold CV. B: within-study batch-adjusted expression; stars = panel BH q.',
    'C: pooled descriptive correlations (not causal). D: single-gene 10x5-fold CV ROC.',
    'LOOCV is sensitive to changing training class proportions; prioritize balanced 10x5-fold CV.',sep='\n'),
    theme=theme(plot.tag=element_text(family='Arial',size=15,face='plain'),
                plot.caption=element_text(family='Arial',size=7,hjust=0)))
ggsave(file.path(FD,paste0(BASE,'.pdf')),fig,width=10.8,height=13.3,units='in',device=cairo_pdf)
ggsave(file.path(SD,paste0(BASE,'.png')),fig,width=10.8,height=13.3,units='in',dpi=600,
       device=ragg::agg_png,limitsize=FALSE)
saveRDS(fig,file.path(SD,'17_figure_object.rds'))
message('[5/6] Save provenance, methods and limitations')
manifest <- list(created_at=format(Sys.time(),'%Y-%m-%d %H:%M:%S %z'),dataset='GSE173078',
  included=nrow(meta),groups=as.list(table(meta$group)),excluded='12 Gingivitis samples',
  tissue='Human gingival tissue bulk RNA-seq, not isolated fibroblasts',
  source_counts=COUNTS,source_metadata=MATRIX,source_md5=as.list(tools::md5sum(c(COUNTS,MATRIX))),
  other_cohorts_used=FALSE,merged_expression_used=FALSE,
  panel=feature_genes,candidate_genes=candidate_genes,
  candidates='Historical comparison list frozen in code; no DEG-driven feature selection or retuning to make a gene win',
  code_reused_from=OLD_CODE,reused=c('safe_auc','predict_model fixed non-penalized models',
  'paper_theme','roc_cols','layout_design','A-D plot geometry'),
  normalization='Per-library log2(CPM+1), no cross-cohort normalization',
  modeling_preprocessing='Train-fold-only batch coefficient from expression ~ batch + phenotype; training-fold z scores; test phenotype never used',
  penalized_tuning='Inner stratified five-fold CV; each inner training fold refits batch correction and scaling; fixed lambda grid; log-loss selection',
  evaluation='Apparent training AUC (not validation), outer LOOCV AUC, AUC of mean OOF probabilities across 10 five-fold repeats',
  apparent_caution='Apparent training AUC is optimistic and must not be reported as validated performance',
  uncertainty='Conditional fixed-OOF-score bootstrap intervals omit model-refitting and model-selection uncertainty',
  B='Expression batch-adjusted preserving phenotype; limma phenotype coefficient adjusted for batch; BH q across six displayed genes',
  C='Pearson correlations in pooled batch-adjusted expression; supplemental group+batch residual correlations provided',
  D='Single-gene logistic phenotype-balanced 10x5-fold mean OOF predictions; same six genes/colors as original',
  no_external_validation=TRUE,model_ranking='Exploratory ranking by repeated five-fold CV; selecting a winner on these CV AUCs is not an independent evaluation',
  LOOCV_caution='Training class proportions vary inversely with held-out class; null or weak models can have artificially very low LOOCV AUC. Do not invert direction or interpret as biological evidence.',
  no_vitaminD_intervention=TRUE,no_causal_mechanism_claim=TRUE,
  figure_pdf=file.path(FD,paste0(BASE,'.pdf')),figure_png=file.path(SD,paste0(BASE,'.png')),
  gene_auc_D=as.list(setNames(roc_labels$AUC,roc_labels$gene)),
  six_gene_model_auc=auc_rows[model_class=='Six-gene panel'],
  fit_warning_counts=as.list(table(warns$model)),number_fit_errors=nrow(errors))
write_json(manifest,file.path(SD,'18_analysis_manifest.json'),auto_unbox=TRUE,pretty=TRUE,
           dataframe='rows',na='null')
capture.output(sessionInfo(),file=file.path(SD,'sessionInfo.txt'))
message('[6/6] Completed. Internal validation only; all old figures preserved.')
print(auc_rows); print(axis_tests[,.(gene,logFC,P.Value,q_panel,label)])
sink(type='message'); sink(); close(logcon)
