from pathlib import Path
import csv
import gzip
import hashlib
import json
import math
from collections import Counter, defaultdict
from datetime import datetime
from PIL import Image
from pypdf import PdfReader
ROOT = Path('E:/\u8840\u6e05\u7ef4\u751f\u7d20D DLC/output/GSE173078_\u5355\u961f\u5217\u5efa\u6a21_20261008')
SD = ROOT / '\u5176\u4ed6'
PDF = ROOT / '\u56fe/Fig3_GSE173078_only_ML_GDF15_ERK_MMP_20261008.pdf'
PNG = SD / 'Fig3_GSE173078_only_ML_GDF15_ERK_MMP_20261008.png'
OLD = Path('E:/\u8840\u6e05\u7ef4\u751f\u7d20D DLC/output/BioorganicChemistry2026_\u5e72\u5b9e\u9a8c\u8fc1\u79fb_20260924/figures/Fig3_Gingiva_ML_GDF15_ERK_MMP_BioorgChem_style.pdf')
COUNTS = Path('E:/\u8840\u6e05\u7ef4\u751f\u7d20D DLC/01_\u6570\u636e\u51c6\u5907/external_GSE173078/GSE173078_rnaseq_raw_counts.txt.gz')
MATRIX = COUNTS.with_name('GSE173078_series_matrix.txt.gz')

def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(2 ** 20), b''):
            h.update(chunk)
    return h.hexdigest()

def rows(path):
    op = gzip.open if path.suffix == '.gz' else open
    with op(path, 'rt', encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def pair_auc(groups, probs):
    pos = [p for g, p in zip(groups, probs) if g == 'Periodontitis']
    neg = [p for g, p in zip(groups, probs) if g == 'Control']
    assert len(pos) == len(neg) == 12
    return sum((float(p > n) + 0.5 * float(p == n) for p in pos for n in neg)) / 144
meta = rows(SD / '01_GSE173078_sample_metadata.csv')
assert len(meta) == len({r['sample'] for r in meta}) == 24
assert Counter((r['group'] for r in meta)) == {'Control': 12, 'Periodontitis': 12}
assert all((r['dataset'] == 'GSE173078' and 'gingival' in r['tissue'].lower() for r in meta))
assert Counter(((r['group'], r['batch']) for r in meta)) == {('Control', 'A'): 6, ('Control', 'B'): 6, ('Periodontitis', 'A'): 6, ('Periodontitis', 'B'): 6}
assert len(rows(SD / '02_excluded_gingivitis.csv')) == 12
expected_samples = {r['sample'] for r in meta}
pred = rows(SD / '10_ML_predictions.csv.gz')
by_model = defaultdict(list)
for r in pred:
    assert r['dataset'] == 'GSE173078'
    p = float(r['probability'])
    assert math.isfinite(p) and 0 <= p <= 1
    by_model[r['model'], r['method']].append(r)
assert len(by_model) == 28 * 3 and len(pred) == 28 * 3 * 24
for rr in by_model.values():
    assert len(rr) == 24 and {r['sample'] for r in rr} == expected_samples
auc_table = rows(SD / '09_ML_model_AUCs.csv')
max_auc_error = 0.0
for r in auc_table:
    for col, method in [('Apparent', 'Apparent'), ('LOOCV', 'LOOCV'), ('Repeated5CV', 'Repeated5CV_mean')]:
        rr = by_model[r['model'], method]
        actual = pair_auc([x['group'] for x in rr], [float(x['probability']) for x in rr])
        error = abs(actual - float(r[col]))
        max_auc_error = max(max_auc_error, error)
        assert error < 1e-12, (r['model'], col, actual, r[col])
folds = rows(SD / '05_repeated5fold_assignments.csv')
for repeat in range(1, 11):
    rr = [r for r in folds if int(r['repeat_id']) == repeat]
    assert len(rr) == 24 and {r['sample'] for r in rr} == expected_samples
    assert {int(r['fold_id']) for r in rr} == {1, 2, 3, 4, 5}
assert len(rows(SD / '08_model_errors.csv')) == 0
with gzip.open(COUNTS, 'rt', newline='') as f:
    reader = csv.reader(f, delimiter='\t')
    sample_cols = next(reader)
    totals = {s: 0 for s in expected_samples}
    target_counts = {}
    for line in reader:
        for i, s in enumerate(sample_cols):
            if s in totals:
                totals[s] += int(line[i + 1])
        if line[0] == 'GDF15':
            target_counts = {s: int(line[i + 1]) for i, s in enumerate(sample_cols) if s in totals}
for r in rows(SD / '04_library_sizes.csv'):
    assert totals[r['sample']] == float(r['library_size'])
reader = PdfReader(PDF)
assert len(reader.pages) == 1
page = reader.pages[0]
width, height = (float(page.mediabox.width), float(page.mediabox.height))
assert abs(width / 72 - 10.8) < 0.01 and abs(height / 72 - 13.3) < 0.01
text = page.extract_text()
assert 'GSE173078' in text and 'GSE223924' not in text
for token in ('GDF15', 'MAPK1', 'MAPK3', 'MMP1', 'MMP7', 'MMP9', 'LOOCV'):
    assert token in text
fonts = set()
font_resources = page['/Resources'].get('/Font', {})
for font in font_resources.values():
    obj = font.get_object()
    fonts.add(str(obj.get('/BaseFont', 'unknown')))
    if obj.get('/Subtype') == '/Type0':
        for child in obj.get('/DescendantFonts', []):
            fonts.add(str(child.get_object().get('/BaseFont', 'unknown')))
assert fonts and all(('Arial' in name for name in fonts)), fonts
with Image.open(PNG) as img:
    png_size = img.size
    png_dpi = img.info.get('dpi')
    assert png_size == (6480, 7980), png_size
    assert png_dpi and all((abs(x - 600) < 1 for x in png_dpi)), png_dpi
assert sha256(OLD) == '03dcb9c702b7d5f01edd846e96af554734bffb2b8d7b877f1589de3ff75f763f'
report = {'checked_at': datetime.now().astimezone().isoformat(), 'status': 'PASS_numeric_and_file_checks_visual_review_separate', 'cohort': 'GSE173078 only', 'n_control': 12, 'n_periodontitis': 12, 'n_excluded_gingivitis': 12, 'fit_errors_final': 0, 'auc_independent_recomputations': len(auc_table) * 3, 'max_auc_error': max_auc_error, 'batch_counts': {'Control_A': 6, 'Control_B': 6, 'Periodontitis_A': 6, 'Periodontitis_B': 6}, 'pdf_pages': 1, 'pdf_dimensions_inches': [width / 72, height / 72], 'pdf_fonts': sorted(fonts), 'png_pixels': png_size, 'png_dpi': png_dpi, 'source_counts_sha256': sha256(COUNTS), 'source_metadata_sha256': sha256(MATRIX), 'new_pdf_sha256': sha256(PDF), 'old_pdf_sha256_unchanged': sha256(OLD), 'old_pdf_preserved': True, 'note': 'AUC comparison is exploratory internal CV; bootstrap intervals condition on fixed OOF predictions.'}
with (SD / 'verification.json').open('w', encoding='utf-8') as f:
    json.dump(report, f, ensure_ascii=False, indent=2)
print(json.dumps(report, ensure_ascii=False, indent=2))
