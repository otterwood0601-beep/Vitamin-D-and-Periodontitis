options(stringsAsFactors=FALSE,scipen=999)
.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(pROC);library(jsonlite);library(ggplot2)})
SD <- 'C:/wb_links/pan_multicohort_20261008_other'
FD <- 'C:/wb_links/pan_multicohort_20261008_figures'
BASE <- 'Fig3_Gingiva_Pan2026_80Models_AD_20261008'
obj <- readRDS(file.path(SD,'19_completed_models.rds'))
rows <- obj$results[order(is.na(Mean),-Mean,model)]
selected <- obj$selected_genes
stopifnot(nrow(rows)==80,all(rows$status=='Computed'),length(selected)==4)
X<-obj$X;y<-obj$y;meta<-obj$meta;train<-obj$train;tests<-obj$tests
foldid<-obj$foldid

for(e in parse('C:/wb_links/bioorgchem2026_code/03_fig3_ml.R')){
 if(is.call(e)&&identical(e[[1]],as.name('<-'))&&is.symbol(e[[2]])&&
   as.character(e[[2]]) %in% c('roc_cols','safe_auc'))eval(e)
}
roc_palette <- setNames(unname(roc_cols)[seq_along(selected)],selected)
prep <- function(tr,te){
 xt<-X[tr,selected,drop=FALSE];xv<-X[te,selected,drop=FALSE]
 for(acc in unique(meta$dataset[c(tr,te)])){
  a<-which(meta$dataset[tr]==acc);b<-which(meta$dataset[te]==acc)
  z<-if(length(a))xt[a,,drop=FALSE] else xv[b,,drop=FALSE]
  mu<-colMeans(z);ss<-apply(z,2,sd);ss[!is.finite(ss)|ss<1e-10]<-1
  if(length(a))xt[a,]<-sweep(sweep(xt[a,,drop=FALSE],2,mu,'-'),2,ss,'/')
  if(length(b))xv[b,]<-sweep(sweep(xv[b,,drop=FALSE],2,mu,'-'),2,ss,'/')
 }
 list(tr=xt,te=xv)
}
single<-list();single_auc<-list();single_predictions<-list()
for(g in selected){
 p<-rep(NA_real_,length(train))
 for(k in 1:10){
  tr<-train[foldid!=k];te<-train[foldid==k];pp<-prep(tr,te)
  f<-suppressWarnings(glm(y~x,data=data.frame(y=y[tr],x=pp$tr[,g]),family=binomial()))
  p[which(foldid==k)]<-suppressWarnings(predict(f,newdata=data.frame(x=pp$te[,g]),type='response'))
 }
 pp<-prep(train,unlist(tests));f<-suppressWarnings(glm(y~x,data=data.frame(y=y[train],x=pp$tr[,g]),family=binomial()))
 pv<-suppressWarnings(predict(f,newdata=data.frame(x=pp$te[,g]),type='response'))
 aa<-c(Train_10fold=safe_auc(y[train],p),GSE243173=safe_auc(y[tests$GSE243173],pv[seq_along(tests$GSE243173)]),
  GSE223924=safe_auc(y[tests$GSE223924],pv[length(tests$GSE243173)+seq_along(tests$GSE223924)]))
 single[[g]]<-pROC::roc(y[train],p,levels=c(0,1),direction='<',quiet=TRUE)
 single_auc[[g]]<-data.table(gene=g,Train_10fold=aa[1],GSE243173=aa[2],GSE223924=aa[3],
  passes_AUC_gt07_all_comparisons=all(aa>.7))
 single_predictions[[g]]<-rbind(data.table(gene=g,sample=meta$sample[train],dataset=meta$dataset[train],
  group=y[train],probability=p,prediction_type='Training 10-fold OOF'),
  data.table(gene=g,sample=meta$sample[unlist(tests)],dataset=meta$dataset[unlist(tests)],
  group=y[unlist(tests)],probability=pv,prediction_type='Comparison, not independent locked validation'))
}
aucs<-rbindlist(single_auc)
fwrite(aucs,file.path(SD,'20_selected_gene_ROC_AUCs.csv'))
fwrite(rbindlist(single_predictions),file.path(SD,'20_selected_gene_predictions.csv.gz'))
fwrite(rows,file.path(SD,'20_panel_A_80_models_source.csv'))
de<-fread(file.path(SD,'10_pooled_DE_batch_and_EBV_adjusted.csv.gz'))
comb<-fread(file.path(SD,'09_pooled_ComBat.csv.gz'))
bx<-t(as.matrix(comb[match(selected,gene),-1]));colnames(bx)<-selected
stopifnot(identical(rownames(bx),meta$sample))
stars<-function(p)ifelse(p<.001,'***',ifelse(p<.01,'**',ifelse(p<.05,'*','ns')))
bstat<-rbindlist(lapply(selected,function(g){
 tt<-t.test(bx[y==0,g],bx[y==1,g],var.equal=TRUE,alternative='two.sided')
 data.table(gene=g,unpaired_two_sided_t_P=tt$p.value,star=stars(tt$p.value))
}))
bstat[,BH_FDR:=p.adjust(unpaired_two_sided_t_P,'BH')]
fwrite(bstat,file.path(SD,'20_panel_B_statistics.csv'))
fwrite(as.data.table(bx,keep.rownames='sample'),file.path(SD,'20_panels_BC_gene_expression.csv'))
cx<-cor(bx)
cp<-matrix(NA_real_,ncol(bx),ncol(bx),dimnames=dimnames(cx))
for(i in seq_along(selected))for(j in seq_along(selected))if(i!=j)cp[i,j]<-cor.test(bx[,i],bx[,j],method='pearson')$p.value
fwrite(as.data.table(cx,keep.rownames='gene'),file.path(SD,'20_panel_C_correlations.csv'))
fwrite(as.data.table(cp,keep.rownames='gene'),file.path(SD,'20_panel_C_P_values.csv'))
curves<-rbindlist(lapply(selected,function(g)data.table(gene=g,specificity=single[[g]]$specificities,
 sensitivity=single[[g]]$sensitivities,AUC=as.numeric(auc(single[[g]])))))
fwrite(curves,file.path(SD,'20_panel_D_ROC_coordinates.csv'))

pdfpath<-file.path(FD,paste0(BASE,'.pdf'))
if(file.exists(pdfpath)&&!identical(Sys.getenv('PAN80_REBUILD'),'1'))stop('PDF exists; no overwrite')
cairo_pdf(pdfpath,width=10.8,height=13.3,family='Arial',pointsize=12)
par(mai=c(0,0,0,0),family='Arial',bg='white')
plot.new()

par(fig=c(.015,.575,.058,.987),mar=c(1.4,.05,.15,.05),new=TRUE,xpd=NA)
plot(NA,xlim=c(-4.55,5.20),ylim=c(-2.5,83),axes=FALSE,xlab='',ylab='',xaxs='i',yaxs='i')
text(-4.43,82.7,'A',cex=1.05,adj=0)
labels<-rows$model
labels[rows$provenance=='Prespecified conjectural extension']<-paste0(labels[rows$provenance=='Prespecified conjectural extension'],'*')
cohorts<-c('GSE243173','GSE223924','Train_10fold')
cohort_cols<-c(GSE243173='#A4DDF0',GSE223924='#B5EA86',Train_10fold='#64B438')
color_auc<-function(v){
 v<-pmax(.2,pmin(1,v));k<-round(100*(v-.2)/.8)+1L
 colorRampPalette(c('#2878B5','white','#D73027'))(101)[k]
}
for(j in 1:3)rect(j-1,80.9,j-.04,82.0,col=cohort_cols[j],border=NA)
for(i in 1:80){
 yy<-81-i
 text(-.14,yy-.48,labels[i],adj=1,cex=.48)
 for(j in 1:3){
  value<-rows[[cohorts[j]]][i]
  rect(j-1,yy-1,j-.015,yy-.015,col=color_auc(value),border='white',lwd=.3)
  text(j-.5,yy-.51,sprintf('%.3f',value),cex=.36)
 }
 rect(3.06,yy-1,3.06+1.18*rows$Mean[i],yy-.03,col='#4F8BBB',border='white',lwd=.3)
 text(3.06+.59*rows$Mean[i],yy-.51,sprintf('%.3f',rows$Mean[i]),cex=.36,col='white')
}
axis(1,at=3.06+1.18*c(.4,.6,.8,1),labels=c('0.4','0.6','0.8','1.0'),pos=0,cex.axis=.48,tck=-.003,lwd=.25)
legend(4.24,65,legend=c('GSE243173','GSE223924','Train'),fill=cohort_cols,
 title='Cohort',bty='n',cex=.65,pt.cex=.8,x.intersp=.5,y.intersp=.9)

for(i in 0:100)rect(4.33,45-i*.12,4.57,45.12-i*.12,col=color_auc(1-i*.008),border=NA)
text(4.30,46.6,'AUC',cex=.67,adj=0)
axis(4,at=45-(1-c(.2,.4,.6,.8,1))/.008*.12,labels=c('0.2','0.4','0.6','0.8','1.0'),
 pos=4.57,cex.axis=.57,tck=-.01,lwd=0,las=1)

par(fig=c(.59,.989,.727,.976),mar=c(3.9,3.45,2.2,.8),new=TRUE,xpd=FALSE)
lim<-range(bx);lim[2]<-lim[2]+diff(lim)*.17
plot(NA,xlim=c(.45,length(selected)+.55),ylim=lim,axes=FALSE,xlab='',ylab='Gene expression',
 cex.lab=.70,xaxs='i',yaxs='i')
axis(2,las=1,cex.axis=.60,tck=-.025,lwd=.35);abline(h=axTicks(2),col='#E7E7E7',lwd=.35)
for(i in seq_along(selected)){
 g<-selected[i]
 boxplot(list(bx[y==0,g],bx[y==1,g]),at=i+c(-.17,.17),add=TRUE,axes=FALSE,
  col=c('#3C91E6','#F04E55'),border='black',boxwex=.30,lwd=.45,
  outline=TRUE,pch=16,cex=.3,staplewex=.45)
 text(i,max(bx[,g])+diff(range(bx))*.08,bstat$star[match(g,bstat$gene)],cex=.90)
}
axis(1,at=seq_along(selected),labels=FALSE,tck=-.02,lwd=.35)
text(seq_along(selected),lim[1]-diff(lim)*.045,selected,srt=45,adj=1,xpd=NA,cex=.70)
box(lwd=.45)
legend(2.50,lim[2]+diff(lim)*.185,legend=c('Control','Periodontitis'),fill=c('#3C91E6','#F04E55'),
 title=NULL,bty='n',horiz=TRUE,xpd=NA,cex=.66,x.intersp=.5,xjust=.5,yjust=.5)
text(.91,lim[2]+diff(lim)*.185,'Type',cex=.66,xpd=NA)
mtext('B',side=3,line=1.65,at=par('usr')[1]-.43,cex=1.05,adj=0)

C<-c(.620,.970,.380,.704);n<-length(selected)
dw<-(C[2]-C[1])/n;dh<-(C[4]-C[3])/n
for(i in seq_len(n))for(j in seq_len(n)){
 cell<-c(C[1]+(j-1)*dw,C[1]+j*dw,C[4]-i*dh,C[4]-(i-1)*dh)
 par(fig=cell,mar=c(.02,.02,.02,.02),new=TRUE,xpd=FALSE)
 rx<-range(bx[,j]);ry<-range(bx[,i])
 if(i==j){
  h<-hist(bx[,j],plot=FALSE,breaks=10)
  den<-density(bx[,j]);ym<-max(h$density,den$y)*1.12
  plot(NA,xlim=rx,ylim=c(0,ym),axes=FALSE,xlab='',ylab='',xaxs='i',yaxs='i')
  for(z in seq_along(h$density))rect(h$breaks[z],0,h$breaks[z+1],h$density[z],col='#D0D0D0',border='grey35',lwd=.3)
  lines(den,col='#D65F73',lwd=.55)
  text(rx[1]+diff(rx)*.035,ym*.92,selected[j],adj=c(0,1),font=3,cex=.72)
 }else if(i>j){
  plot(bx[,j],bx[,i],pch=16,cex=.22,xlim=rx,ylim=ry,axes=FALSE,
   xlab='',ylab='',xaxs='i',yaxs='i')
  lines(lowess(bx[,j],bx[,i]),col='#D65F73',lwd=.55)
 }else{
  plot(NA,xlim=rx,ylim=ry,axes=FALSE,xlab='',ylab='',xaxs='i',yaxs='i')
  text(rx[1]+diff(rx)*.5,ry[1]+diff(ry)*.52,sprintf('%.2f',cx[i,j]),cex=.87)
  s<-stars(cp[i,j]);if(s!='ns')text(rx[1]+diff(rx)*.82,ry[1]+diff(ry)*.84,s,col='#CF4C6D',cex=.84)
 }
 box(lwd=.35,col='grey45')
 if(i==n){axis(1,at=pretty(rx,n=3),cex.axis=.58,tck=-.03,line=-.10,lwd=.3)}
 if(j==1&&i!=j){axis(2,at=pretty(ry,n=3),cex.axis=.58,tck=-.03,line=-.15,lwd=.3,las=1)}
 if(i==1){axis(3,at=pretty(rx,n=3),cex.axis=.58,tck=-.03,line=-.15,lwd=.3)}
 if(j==n&&i!=j){axis(4,at=pretty(ry,n=3),cex.axis=.58,tck=-.03,line=-.15,lwd=.3,las=1)}
}
par(fig=c(.59,.989,.365,.727),mar=c(0,0,0,0),new=TRUE)
plot(NA,xlim=c(0,1),ylim=c(0,1),axes=FALSE,xlab='',ylab='')
text(.015,1.025,'C',adj=c(0,1),cex=1.05,xpd=NA)

par(fig=c(.59,.989,.071,.354),mar=c(3.4,3.45,.9,.8),new=TRUE)
plot(NA,xlim=c(0,1),ylim=c(0,1),axes=FALSE,xlab='',ylab='Sensitivity',
 cex.lab=.70,xaxs='i',yaxs='i')
axis(1,at=seq(0,1,.2),cex.axis=.62,tck=-.025,lwd=.35)
axis(2,at=seq(0,1,.2),cex.axis=.62,tck=-.025,lwd=.35,las=1)
abline(a=0,b=1,col='#777777',lwd=.5)
for(g in selected)lines(1-single[[g]]$specificities,single[[g]]$sensitivities,
 col=roc_palette[g],lwd=1.0,type='s')
box(lwd=.45)
legend(.37,.36,legend=paste0(selected,', AUC=',sprintf('%.3f',aucs$Train_10fold)),
 col=roc_palette,lty=1,lwd=1,bty='n',cex=.70,y.intersp=.93,x.intersp=.5)
mtext('1 - Specificity',side=1,line=2.0,cex=.70)
mtext('D',side=3,line=.8,at=-.13,cex=1.05,adj=0)
par(fig=c(.02,.985,.007,.055),mar=c(0,0,0,0),new=TRUE)
plot(NA,xlim=c(0,1),ylim=c(0,1),axes=FALSE,xlab='',ylab='')
text(0,.75,'* On model labels: two inferred extensions. Train: GSE173078 + GSE223328 (n=40); comparisons: GSE243173 (n=12), GSE223924 (n=20).',adj=0,cex=.54)
text(0,.42,'AUCs are exploratory model-selection estimates, not independent validation. Panel D: training 10-fold single-gene ROC; B/C: pooled descriptive expression.',adj=0,cex=.54)
text(0,.09,'The comparison cohorts participated in upstream gene selection. No claim of GDF15/ERK/MMP pathway activation or vitamin D causality.',adj=0,cex=.54)
dev.off()
write_json(list(PDF=pdfpath,width_inches=10.8,height_inches=13.3,font='Arial',
 panels=list(A='80 ranked models, 3 cohort AUC columns plus blue mean-AUC bars',
 B='4 best-model genes; Control blue #3C91E6, Periodontitis red #F04E55; pooled unpaired two-sided t-test',
 C='Pearson correlations; gray histogram/red density, black scatter/red lowess, red significance stars',
 D='Training 10-fold OOF single-gene ROC; fixed direction; source rainbow positions'),
 two_inferred_models_marked_with_asterisk=TRUE,best_model=obj$best_model,best_model_genes=selected,
 source_visible_models=78,conjectural_models_run=2,models_drawn=80,
 source_layout_adaptations=c('Four data-selected genes, not copied six PCOS genes',
 'Two comparison cohorts plus Train, not the original three plus Train',
 'Footer added to disclose inferred algorithms and non-independent exploratory comparisons'),
 independently_validated=FALSE,ROC_AUC_gt07_all_comparisons_genes=aucs[passes_AUC_gt07_all_comparisons==TRUE,gene]),
 file.path(SD,'21_figure_manifest.json'),pretty=TRUE,auto_unbox=TRUE)
print(aucs);message('PDF written: ',pdfpath)
