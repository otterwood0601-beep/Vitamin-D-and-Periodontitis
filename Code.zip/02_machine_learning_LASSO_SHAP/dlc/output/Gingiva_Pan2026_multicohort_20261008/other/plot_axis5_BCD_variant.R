source_path <- 'C:/wb_links/pan_multicohort_20261008_other/plot_80_models_AD.R'
code <- paste(readLines(source_path, warn=FALSE), collapse='\n')
replace_once <- function(old, new){
  if(!grepl(old, code, fixed=TRUE))stop('Required source fragment missing: ', old)
  code <<- sub(old, new, code, fixed=TRUE)
}
replace_once("BASE <- 'Fig3_Gingiva_Pan2026_80Models_AD_20261008'",
 "BASE <- 'Fig3_Gingiva_Pan2026_80Models_A_Axis5_BCD_20261008'")
replace_once('selected <- obj$selected_genes',
 "selected <- c('GDF15','MAPK1','MAPK3','MMP1','MMP3')")
replace_once("length(selected)==4", "length(selected)==5")
replace_once('X<-obj$X;y<-obj$y;meta<-obj$meta;train<-obj$train;tests<-obj$tests',
 "normobj<-readRDS(file.path(SD,'08_normalized_cohorts.rds'))\nstopifnot(all(vapply(normobj$exprs,function(z)all(selected %in% rownames(z)),logical(1))))\nX<-t(do.call(cbind,lapply(normobj$exprs,function(z)z[selected,,drop=FALSE])))\ny<-obj$y;meta<-obj$meta;train<-obj$train;tests<-obj$tests\nstopifnot(identical(rownames(X),meta$sample),all(is.finite(X)))")

code <- gsub('20_', '24_axis5_', code, fixed=TRUE)
code <- gsub('21_figure_manifest.json', '25_axis5_figure_manifest.json', code, fixed=TRUE)
code <- gsub('selected_gene_ROC_AUCs', 'specified_gene_ROC_AUCs', code, fixed=TRUE)
code <- gsub('selected_gene_predictions', 'specified_gene_predictions', code, fixed=TRUE)
replace_once("'4 best-model genes; Control blue #3C91E6, Periodontitis red #F04E55; pooled unpaired two-sided t-test'",
 "'5 user-requested genes, NOT selected by panel A; Control blue #3C91E6, Periodontitis red #F04E55; pooled unpaired two-sided t-test'")
replace_once('best_model_genes=selected,',
 'best_model_genes=obj$selected_genes,plotted_genes=selected,genes_are_user_requested=TRUE,')
replace_once("'Four data-selected genes, not copied six PCOS genes'",
 "'Five explicitly user-requested axis genes; not output genes of the panel A model'")
replace_once("'AUCs are exploratory model-selection estimates, not independent validation. Panel D: training 10-fold single-gene ROC; B/C: pooled descriptive expression.'",
 "'Panels B-D: user-requested GDF15, MAPK1, MAPK3, MMP1, MMP3; NOT genes selected by panel A. D: training 10-fold single-gene ROC.'")
replace_once("'The comparison cohorts participated in upstream gene selection. No claim of GDF15/ERK/MMP pathway activation or vitamin D causality.'",
 "'B/C: pooled descriptive expression. AUCs are exploratory, not independent validation; no ERK activation, pathway or vitamin D causality claim.'")
eval(parse(text=code), envir=.GlobalEnv)

precise_predictions <- rbindlist(single_predictions)
precise_predictions[,probability:=sprintf('%.17g',probability)]
fwrite(precise_predictions,file.path(SD,'24_axis5_specified_gene_predictions_full_precision.csv.gz'))

axis_de <- de[gene %in% selected]
fwrite(axis_de, file.path(SD,'24_axis5_batch_EBV_adjusted_DE.csv'))
group_means <- data.table(gene=selected,
 Control_mean=colMeans(bx[y==0,,drop=FALSE]),
 Periodontitis_mean=colMeans(bx[y==1,,drop=FALSE]))
group_means[,difference_PD_minus_Control:=Periodontitis_mean-Control_mean]
fwrite(group_means,file.path(SD,'24_axis5_expression_group_means.csv'))
