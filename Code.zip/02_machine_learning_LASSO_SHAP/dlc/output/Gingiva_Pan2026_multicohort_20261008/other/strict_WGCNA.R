options(stringsAsFactors=FALSE,scipen=999)
.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(WGCNA);library(jsonlite)})
allowWGCNAThreads(nThreads=2)
set.seed(20261008)
SD <- 'C:/wb_links/pan_multicohort_20261008_other'
meta <- fread(file.path(SD,'08_pooled_sample_metadata.csv'))
d <- fread(file.path(SD,'10_pooled_DE_batch_and_EBV_adjusted.csv.gz'))
x <- fread(file.path(SD,'09_pooled_ComBat.csv.gz'))
genes <- d[strict_Pan_DEG==TRUE,gene]
stopifnot(length(genes)>=40)
dat <- as.matrix(x[match(genes,gene),-1]);rownames(dat)<-genes
dat <- t(dat)
stopifnot(identical(rownames(dat),meta$sample))
gs <- goodSamplesGenes(dat,verbose=0)
if(!all(gs$goodSamples))stop('Unexpected sample QC failure; do not silently drop donors')
dat <- dat[,gs$goodGenes,drop=FALSE]
soft <- pickSoftThreshold(dat,powerVector=c(1:10,seq(12,30,2),35,40),networkType='signed',verbose=0)
fi <- as.data.table(soft$fitIndices)
fwrite(fi,file.path(SD,'11_WGCNA_power_diagnostics.csv'))
pw <- fi[SFT.R.sq>=.8 & slope<0,Power]
if(length(pw))pw <- min(pw) else {
  write_json(list(status='Held: no adequate scale-free fit',strict_DEG_input_genes=ncol(dat),
    samples=nrow(dat),tested_powers=fi$Power,best_R2=max(fi$SFT.R.sq),
    R2_rule=.8,rule_source='Existing project operational choice, not a numerical threshold disclosed by Pan',
    reason='No tested power meets R2 >= .8 with negative slope; no arbitrary fallback modules or forced genes',
    downstream='Module/VD overlap, PPI candidate20, 113 models and A-D not completed'),
    file.path(SD,'12_WGCNA_VD_status.json'),pretty=TRUE,auto_unbox=TRUE)
  stop('No scale-free threshold met; do not silently use arbitrary power')
}
if(pw<=30) {
  net <- blockwiseModules(dat,power=pw,networkType='signed',TOMType='signed',
    minModuleSize=20,mergeCutHeight=.25,numericLabels=FALSE,pamRespectsDendro=FALSE,
    maxBlockSize=5000,verbose=0)
} else {

  adj <- adjacency(dat,power=pw,type='signed')
  tom <- TOMsimilarity(adj,TOMType='signed',verbose=0)
  dis <- 1-tom
  tree <- hclust(as.dist(dis),method='average')
  lab <- dynamicTreeCut::cutreeDynamic(dendro=tree,distM=dis,deepSplit=2,
    pamRespectsDendro=FALSE,minClusterSize=20,verbose=0)
  colors <- labels2colors(lab)
  merged <- mergeCloseModules(dat,colors,cutHeight=.25,verbose=0)
  net <- list(colors=merged$colors,MEs=merged$newMEs,dendrograms=list(tree),
    manual_same_algorithm=TRUE,power=pw)
}
mem <- data.table(gene=colnames(dat),module=unname(net$colors))
fwrite(mem,file.path(SD,'11_WGCNA_membership.csv'))
MEs <- orderMEs(net$MEs)
correlations <- as.numeric(cor(MEs,as.integer(meta$group=='Periodontitis')))
pvalues <- corPvalueStudent(correlations,nrow(dat))
stats <- data.table(module=sub('^ME','',colnames(MEs)),r=correlations,P=pvalues,FDR=p.adjust(pvalues,'BH'))
fwrite(stats,file.path(SD,'11_WGCNA_trait_associations.csv'))
significant <- stats[module!='grey' & FDR<.05,module]
selected <- mem[module %in% significant]
fwrite(selected,file.path(SD,'11_disease_associated_module_genes.csv'))
saveRDS(list(dat=dat,net=net,MEs=MEs,power=pw,meta=meta),file.path(SD,'11_WGCNA_objects.rds'))
vd <- fread(file.path(SD,'12_VD_input_all_genes.csv'))
stopifnot(all(c('gene_symbol','padj','log2FoldChange') %in% names(vd)))
vd <- vd[!is.na(gene_symbol) & gene_symbol!='']
setorder(vd,padj)
vd <- unique(vd,by='gene_symbol')

vgenes <- vd[padj<.05,gene_symbol]
overlap <- intersect(selected$gene,vgenes)
fwrite(data.table(gene=sort(overlap)),file.path(SD,'12_VD_disease_module_overlap.csv'))
axis <- data.table(gene=c('GDF15','MAPK1','MAPK3','MMP1','MMP3'))
axis <- merge(axis,mem,by='gene',all.x=TRUE)
axis[,VD_FDR:=vd$padj[match(gene,vd$gene_symbol)]]
axis[,eligible_candidate:=gene %in% overlap]
fwrite(axis,file.path(SD,'12_axis_selection_audit.csv'))
write_json(list(samples=nrow(dat),strict_DEG_input_genes=ncol(dat),power=pw,
  significant_modules=significant,module_genes=nrow(selected),
  VD_FDR05_genes=length(vgenes),VD_module_overlap=length(overlap),
  manually_added_genes=0,
  caveat='VD assay response is an adapted replacement for ICA target prediction; pooled module selection is not independent validation',
  candidate_status=if(length(overlap)<20)'Fewer than 20 overlap genes: cannot fabricate Pan top20 PPI inputs' else 'Ready for STRING and MCC ranking'),
  file.path(SD,'12_WGCNA_VD_status.json'),pretty=TRUE,auto_unbox=TRUE)
print(stats);print(axis);message('VD overlap genes: ',length(overlap))
