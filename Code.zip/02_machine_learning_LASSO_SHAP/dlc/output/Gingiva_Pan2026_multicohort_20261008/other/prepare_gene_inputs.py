import json, sys
import numpy as np
import pandas as pd
from fetch_candidate_inputs import ROOT, RAW
from prepare_cohort_audit import matrix, read_audit
sys.stdout.reconfigure(encoding='utf-8')

def platform(acc):
    with (ROOT / 'geo_metadata' / f'{acc}_platform.soft.txt').open(encoding='utf-8') as f:
        for line in f:
            if line.startswith('!platform_table_begin'):
                break
        return pd.read_csv(f, sep='\t', comment='!', dtype=str, low_memory=False)

def save_arrays():
    p5 = platform('GPL26963')
    p5['V4_probe'] = p5.ID.str.replace('V5$', '', regex=True)
    pm = p5[['V4_probe', 'ID', 'ORF', 'ACC']].dropna(subset=['ORF'])
    pm = pm[~pm.ORF.str.contains('///|;|\\s', regex=True)]
    ambiguous = pm.groupby('V4_probe').ORF.nunique()
    pm = pm[pm.V4_probe.isin(ambiguous[ambiguous == 1].index)].drop_duplicates('V4_probe')
    annotations = []
    for acc in ['GSE106090', 'GSE223328']:
        meta = read_audit(acc)
        exp = matrix(meta['matrix_path'])
        if acc == 'GSE106090':
            gp = platform('GPL21827')
            symbols = pm.set_index('V4_probe').ORF.reindex(exp.index)
            annotation = pd.DataFrame({'probe': exp.index, 'gene': symbols.values, 'annotation_source': 'GPL26963 ORF, unique V4 probe ID base -> V5 ID', 'annotation_evidence': 'https://bioconductor.posit.co/packages/devel/bioc/vignettes/GExPipe/inst/doc/GExPipe.html'})
            types = gp.set_index('ID').TRANSCRIPT_TYPE.reindex(exp.index)
            symbols = symbols.where(types.str.lower().eq('protein_coding'))
            annotation['transcript_type'] = types.values
            annotation['gene'] = symbols.values
            pm.to_csv(ROOT / '06_GPL21827_GPL26963_crosswalk.csv', index=False)
        else:
            gp = platform('GPL21185').set_index('ID')
            symbols = gp.GENE_SYMBOL.reindex(exp.index)
            symbols = symbols.where(~symbols.fillna('').str.contains('///|;|\\s', regex=True))
            annotation = pd.DataFrame({'probe': exp.index, 'gene': symbols.values, 'annotation_source': 'GPL21185 GENE_SYMBOL', 'annotation_evidence': 'https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GPL21185'})
        valid = symbols.notna() & symbols.ne('')
        if not valid.any():
            q = {'dataset': acc, 'status': 'Awaiting valid coding-gene annotation', 'original_probes': len(exp), 'mapped_coding_probes': 0, 'reason': 'V5 crosswalk covers shared noncoding probe IDs only; it does not resolve V4 mRNA probes', 'required_input': 'GPL21827 / Arraystar Human LncRNA V4 protein-coding probe-to-HGNC symbol annotation'}
            (ROOT / f'07_{acc}_mapping_QC.json').write_text(json.dumps(q, indent=2), encoding='utf-8')
            print(q, flush=True)
            continue
        mapped = exp.loc[valid].copy()
        mapped.index = symbols[valid]
        quantiles = np.nanpercentile(mapped.values, [0, 25, 50, 75, 99, 100])
        log_applied = False
        if quantiles[4] > 100:
            mapped = np.log2(mapped.clip(lower=1))
            log_applied = True
        genes = mapped.groupby(level=0).mean()
        genes.to_csv(ROOT / f'07_{acc}_processed_gene_expression.csv.gz', index_label='gene')
        annotation.to_csv(ROOT / f'06_{acc}_probe_gene_audit.csv', index=False)
        q = {'dataset': acc, 'original_probes': len(exp), 'mapped_coding_probes': int(valid.sum()), 'unique_genes': len(genes), 'input_quantiles': quantiles.tolist(), 'new_log2_applied': log_applied, 'normalization': 'Reuse public processed matrix; no claim that raw Agilent data underwent Affymetrix RMA', 'missing_core_genes': [g for g in ['GDF15', 'MAPK1', 'MAPK3', 'MMP1', 'MMP3'] if g not in genes.index]}
        (ROOT / f'07_{acc}_mapping_QC.json').write_text(json.dumps(q, indent=2), encoding='utf-8')
        print(q, flush=True)

def mapping243():
    src = 'E:/\u8840\u6e05\u7ef4\u751f\u7d20D DLC/data_derived/tranoncol2026/00_gene_annotations.csv.gz'
    ann = pd.read_csv(src).rename(columns={'ensembl_id': 'ensembl_gene_id', 'feature_name': 'gene'})
    ann = ann[['ensembl_gene_id', 'gene', 'feature_biotype']].drop_duplicates()
    amb = ann.groupby('ensembl_gene_id').gene.nunique()
    ann = ann[ann.ensembl_gene_id.isin(amb[amb == 1].index)].drop_duplicates('ensembl_gene_id')
    counts = pd.read_csv(RAW / 'GSE243173' / 'GSE243173_RawCountFile.txt.gz', sep='\t')
    joined = counts.merge(ann, on='ensembl_gene_id', how='left', validate='one_to_one')
    joined[['ensembl_gene_id', 'gene', 'feature_biotype']].to_csv(ROOT / '06_GSE243173_gene_mapping.csv', index=False)
    valid = joined.gene.notna()
    cols = list(counts.columns[1:])
    out = joined.loc[valid, ['gene'] + cols].groupby('gene').sum()
    out.to_csv(ROOT / '07_GSE243173_gene_counts.csv.gz', index_label='gene')
    q = {'dataset': 'GSE243173', 'rows': len(counts), 'mapped_rows': int(valid.sum()), 'unique_genes': len(out), 'annotation_local_source': src, 'core_genes_present': {g: g in out.index for g in ['GDF15', 'MAPK1', 'MAPK3', 'MMP1', 'MMP3']}, 'species_discrepancy': 'GEO description states mouse mapping but actual identifiers all ENSG; do not silently change source metadata'}
    (ROOT / '07_GSE243173_mapping_QC.json').write_text(json.dumps(q, indent=2), encoding='utf-8')
    print(q, flush=True)
if __name__ == '__main__':
    save_arrays()
    mapping243()
