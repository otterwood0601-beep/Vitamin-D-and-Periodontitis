from pathlib import Path
import hashlib, json
import numpy as np
import pandas as pd
from scipy.stats import rankdata, ttest_ind, pearsonr
from pypdf import PdfReader
from PIL import Image
root = Path(__file__).resolve().parent
genes = ['GDF15', 'MAPK1', 'MAPK3', 'MMP1', 'MMP3']
pdf = root.parent / '\u56fe' / 'Fig3_Gingiva_Pan2026_80Models_A_Axis5_BCD_20261008.pdf'
old = root.parent / '\u56fe' / 'Fig3_Gingiva_Pan2026_80Models_AD_20261008.pdf'
assert hashlib.sha256(old.read_bytes()).hexdigest() == 'f5a838097e927e65b408d786195b5c69181764bf392a572decf31e73de761f6a'
pd.testing.assert_frame_equal(pd.read_csv(root / '24_axis5_panel_A_80_models_source.csv'), pd.read_csv(root / '20_panel_A_80_models_source.csv'))
pred = pd.read_csv(root / '24_axis5_specified_gene_predictions_full_precision.csv.gz', float_precision='round_trip')
auc = pd.read_csv(root / '24_axis5_specified_gene_ROC_AUCs.csv').set_index('gene')
assert len(pred) == 360 and (not pred.duplicated(['gene', 'sample']).any())
assert set(pred.gene) == set(genes) and np.isfinite(pred.probability).all()
assert pred.probability.between(0, 1).all()
checks = 0
for g in genes:
    for cohort in ['Train_10fold', 'GSE243173', 'GSE223924']:
        if cohort == 'Train_10fold':
            z = pred[(pred.gene == g) & pred.dataset.isin(['GSE173078', 'GSE223328'])]
        else:
            z = pred[(pred.gene == g) & (pred.dataset == cohort)]
        y = z.group.to_numpy()
        p = z.probability.to_numpy()
        n1 = (y == 1).sum()
        n0 = (y == 0).sum()
        a = (rankdata(p)[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)
        assert np.isclose(a, auc.loc[g, cohort], atol=1e-12), (g, cohort, a, auc.loc[g, cohort], len(z))
        assert len(z) == {'Train_10fold': 40, 'GSE243173': 12, 'GSE223924': 20}[cohort]
        checks += 1
expr = pd.read_csv(root / '24_axis5_panels_BC_gene_expression.csv').set_index('sample')
labels = pred[pred.gene == 'GDF15'].set_index('sample').group.reindex(expr.index)
assert len(expr) == 72 and labels.notna().all()
assert labels.value_counts().to_dict() == {1: 38, 0: 34}
bs = pd.read_csv(root / '24_axis5_panel_B_statistics.csv').set_index('gene')
corr = pd.read_csv(root / '24_axis5_panel_C_correlations.csv').set_index('gene')
cp = pd.read_csv(root / '24_axis5_panel_C_P_values.csv').set_index('gene')
for g in genes:
    t = ttest_ind(expr.loc[labels == 0, g], expr.loc[labels == 1, g], equal_var=True)
    assert np.isclose(t.pvalue, bs.loc[g, 'unpaired_two_sided_t_P'], rtol=1e-10)
    for h in genes:
        r, p = pearsonr(expr[g], expr[h])
        assert np.isclose(r, corr.loc[g, h], atol=1e-12)
        if g != h:
            assert np.isclose(p, cp.loc[g, h], rtol=1e-09, atol=1e-14)
r = PdfReader(pdf)
assert len(r.pages) == 1
txt = r.pages[0].extract_text()
assert all((g in txt for g in genes)) and 'NOT genes selected by panel A' in txt
im = Image.open(root / 'Fig3_Axis5_BCD_preview.png')
previous = Image.open(root / 'Fig3_80Models_AD_preview.png')
assert im.size == previous.size
left = np.array(im.crop((0, 0, 900, 1870)))
prior_left = np.array(previous.crop((0, 0, 900, 1870)))
assert np.array_equal(left, prior_left), 'Panel A rendered pixels changed'
result = {'genes': genes, 'prediction_rows': 360, 'independent_AUC_checks': checks, 'independent_t_test_checks': 5, 'independent_correlation_checks': 25, 'panel_A_source_identical': True, 'panel_A_rendered_crop_identical': True, 'old_PDF_SHA256_unchanged': True, 'pdf_pages': 1, 'user_requested_not_model_selected': True, 'rendered_preview_visually_inspected': True, 'no_138_model_recomputation': True, 'not_independent_validation': True}
(root / '26_axis5_QA.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))
