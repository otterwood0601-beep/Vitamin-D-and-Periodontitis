options(stringsAsFactors=FALSE,scipen=999)
.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(glmnet);library(randomForest);library(e1071)
 library(xgboost);library(pROC);library(mboost);library(plsRglm);library(gbm);library(jsonlite)})
SD <- 'C:/wb_links/pan_multicohort_20261008_other'
set.seed(20261008)
logcon <- file(file.path(SD,'17_80_models_analysis.log'),'wt')
sink(logcon,split=TRUE);sink(logcon,type='message')
obj <- readRDS(file.path(SD,'08_normalized_cohorts.rds'))
meta <- copy(obj$meta)
genes <- fread(file.path(SD,'15_ML_PPI_candidate_genes.csv'))$gene
models <- readLines(file.path(SD,'16_selected_80_models.txt'))
stopifnot(length(models)==80,!anyDuplicated(models),length(genes)==16,
 !any(c('GDF15','MAPK1','MAPK3','MMP1','MMP3') %in% genes))
X <- t(do.call(cbind,lapply(obj$exprs,function(x)x[genes,,drop=FALSE])))
stopifnot(identical(rownames(X),meta$sample),all(is.finite(X)))
y <- as.integer(meta$group=='Periodontitis')
train <- which(meta$dataset %in% c('GSE173078','GSE223328'))
tests <- list(GSE243173=which(meta$dataset=='GSE243173'),GSE223924=which(meta$dataset=='GSE223924'))
stopifnot(length(train)==40,length(tests$GSE243173)==12,length(tests$GSE223924)==20,
 all(table(y[train])==20))
folds <- function(labels,k,seed){
 set.seed(seed);out<-integer(length(labels))
 for(g in unique(labels)){ii<-which(labels==g);out[ii]<-sample(rep(seq_len(k),length.out=length(ii)))}
 out
}
foldid <- folds(y[train],10,20261008)
fwrite(data.table(sample=meta$sample[train],dataset=meta$dataset[train],group=y[train],fold=foldid),
 file.path(SD,'17_train_10fold_assignments.csv'))
warns <- list();errors <- list()
safe <- function(expr,stage,model){
 tryCatch(withCallingHandlers(expr,warning=function(w){
   warns[[length(warns)+1L]] <<- data.table(stage=stage,model=model,message=conditionMessage(w))
   invokeRestart('muffleWarning')
 }),error=function(e){
   errors[[length(errors)+1L]] <<- data.table(stage=stage,model=model,message=conditionMessage(e));NULL
 })
}
safe_auc <- function(y,p){
 if(length(p)!=length(y)||any(!is.finite(p))||length(unique(y))!=2)return(NA_real_)
 as.numeric(pROC::auc(pROC::roc(y,p,levels=c(0,1),direction='<',quiet=TRUE)))
}

prep <- function(tr,te){
 xt <- X[tr,,drop=FALSE]; xv <- X[te,,drop=FALSE]
 for(acc in unique(meta$dataset[c(tr,te)])){
  a <- which(meta$dataset[tr]==acc);b <- which(meta$dataset[te]==acc)
  z <- if(length(a))xt[a,,drop=FALSE] else xv[b,,drop=FALSE]
  mu<-colMeans(z);ss<-apply(z,2,sd);ss[!is.finite(ss)|ss<1e-10]<-1
  if(length(a))xt[a,]<-sweep(sweep(xt[a,,drop=FALSE],2,mu,'-'),2,ss,'/')
  if(length(b))xv[b,]<-sweep(sweep(xv[b,,drop=FALSE],2,mu,'-'),2,ss,'/')
 }
 list(tr=xt,te=xv)
}
reg_fit <- function(x,y,alpha,seed){
 
 k<-min(10,min(table(y)));fid<-folds(y,k,seed)
 cv.glmnet(x,y,family='binomial',alpha=alpha,foldid=fid,type.measure='deviance',
  standardize=FALSE,nlambda=60)
}
step_fit <- function(x,y,direction){
 d<-data.frame(y=y,x,check.names=FALSE)
 full<-glm(y~.,data=d,family=binomial())
 if(direction=='forward'){
  empty<-glm(y~1,data=d,family=binomial())
  stats::step(empty,scope=list(lower=~1,upper=formula(full)),direction='forward',trace=0)
 }else stats::step(full,direction=direction,trace=0)
}
boost_fit <- function(x,y,mstop){
 mboost::glmboost(x=x,y=factor(y,levels=c(0,1)),family=mboost::Binomial(),center=FALSE,
  control=mboost::boost_control(mstop=mstop,nu=.1))
}
nonzero <- function(cf){
 if(is.list(cf))cf<-unlist(cf)
 n<-names(cf);n<-n[is.finite(cf)&abs(cf)>1e-8]
 intersect(n,genes)
}
select_genes <- function(selector,x,y,seed){
 if(selector=='All')return(colnames(x))
 if(selector=='Lasso'){
  f<-reg_fit(x,y,1,seed);cf<-as.matrix(coef(f,s='lambda.min'))[,1]
  return(intersect(names(cf)[abs(cf)>1e-8],colnames(x)))
 }
 if(startsWith(selector,'Stepglm')){
  direction<-gsub('^Stepglm\\[|\\]$','',selector)
  f<-step_fit(x,y,direction)
  return(intersect(attr(terms(f),'term.labels'),colnames(x)))
 }
 if(selector=='glmBoost'){
  f<-boost_fit(x,y,100);return(intersect(nonzero(coef(f)),colnames(x)))
 }
 stop('Unsupported selector: ',selector)
}
specs <- function(algo){
 if(algo %in% c('Lasso','Ridge')||startsWith(algo,'Enet'))return(c('lambda.min','lambda.1se'))
 if(algo=='glmBoost')return(c('50','100','200'))
 if(algo=='plsRglm')return(c('1','2','3'))
 if(algo=='RF')return(c('sqrt','third','half'))
 if(algo=='GBM')return(c('200_1','200_2','400_1'))
 if(algo=='XGBoost')return(c('80_1','80_2','160_2'))
 if(algo=='SVM')return(c('0.5','1','2'))
 'default'
}
fit_model <- function(algo,spec,x,y,seed){
 set.seed(seed)
 if(ncol(x)==0)return(list(kind='intercept',prob=mean(y),genes=character()))
 if(algo %in% c('Lasso','Ridge')||startsWith(algo,'Enet')){
  alpha<-if(algo=='Lasso')1 else if(algo=='Ridge')0 else as.numeric(gsub('^Enet\\[alpha=|\\]$','',algo))
  f<-reg_fit(x,y,alpha,seed)
  cf<-as.matrix(coef(f,s=spec))[,1]
  return(list(kind='glmnet',fit=f,s=spec,genes=intersect(names(cf)[abs(cf)>1e-8],colnames(x))))
 }
 if(startsWith(algo,'Stepglm')){
  f<-step_fit(x,y,gsub('^Stepglm\\[|\\]$','',algo))
  return(list(kind='step',fit=f,genes=intersect(attr(terms(f),'term.labels'),colnames(x))))
 }
 if(algo=='glmBoost'){
  f<-boost_fit(x,y,as.integer(spec))
  return(list(kind='boost',fit=f,genes=intersect(nonzero(coef(f)),colnames(x))))
 }
 if(algo=='plsRglm'){
  nt<-min(as.integer(spec),ncol(x),nrow(x)-2)
  f<-plsRglm::plsRglm(dataY=y,dataX=data.frame(x,check.names=FALSE),nt=nt,
   modele='pls-glm-logistic',scaleX=FALSE,verbose=FALSE)
  return(list(kind='pls',fit=f,genes=colnames(x)))
 }
 if(algo=='RF'){
  mt<-switch(spec,sqrt=floor(sqrt(ncol(x))),third=floor(ncol(x)/3),half=floor(ncol(x)/2))
  f<-randomForest(x=x,y=factor(y,levels=c(0,1)),ntree=400,mtry=max(1,mt))
  return(list(kind='rf',fit=f,genes=colnames(x)))
 }
 if(algo=='GBM'){
  a<-as.integer(strsplit(spec,'_')[[1]])
  f<-gbm::gbm.fit(x=x,y=y,distribution='bernoulli',n.trees=a[1],interaction.depth=a[2],
   n.minobsinnode=3,shrinkage=.05,bag.fraction=.8,verbose=FALSE)
  return(list(kind='gbm',fit=f,ntrees=a[1],genes=colnames(x)))
 }
 if(algo=='XGBoost'){
  a<-as.integer(strsplit(spec,'_')[[1]])
  f<-xgboost::xgb.train(params=list(objective='binary:logistic',eval_metric='logloss',
    eta=.05,max_depth=a[2],subsample=.85,colsample_bytree=.85,nthread=2),
    data=xgboost::xgb.DMatrix(x,label=y),nrounds=a[1],verbose=0)
  return(list(kind='xgb',fit=f,genes=colnames(x)))
 }
 if(algo=='SVM'){
  f<-e1071::svm(x=x,y=factor(y,levels=c(0,1)),kernel='radial',cost=as.numeric(spec),
    gamma=1/ncol(x),scale=FALSE,probability=TRUE)
  return(list(kind='svm',fit=f,genes=colnames(x)))
 }
 if(algo=='LDA')return(list(kind='lda',fit=MASS::lda(x=x,grouping=factor(y)),genes=colnames(x)))
 if(algo=='NaiveBayes')return(list(kind='nb',fit=e1071::naiveBayes(x=x,y=factor(y)),genes=colnames(x)))
 stop('Unsupported predictor: ',algo)
}
predict_fit <- function(f,x){
 switch(f$kind,
  intercept=rep(f$prob,nrow(x)),
  glmnet=as.numeric(predict(f$fit,newx=x,s=f$s,type='response')),
  step=as.numeric(predict(f$fit,newdata=data.frame(x,check.names=FALSE),type='response')),
  boost=as.numeric(predict(f$fit,newdata=x,type='response')),
  pls=as.numeric(predict(f$fit,newdata=data.frame(x,check.names=FALSE),type='response',verbose=FALSE)),
  rf=as.numeric(predict(f$fit,x,type='prob')[,'1']),
  gbm=as.numeric(predict(f$fit,newdata=x,n.trees=f$ntrees,type='response')),
  xgb=as.numeric(predict(f$fit,xgboost::xgb.DMatrix(x))),
  svm=as.numeric(attr(predict(f$fit,x,probability=TRUE),'probabilities')[,'1']),
  lda=as.numeric(predict(f$fit,x)$posterior[,'1']),
  nb=as.numeric(predict(f$fit,x,type='raw',threshold=1e-8,eps=1e-8)[,'1']))
}
split_recipe <- function(m){
 z<-strsplit(m,'+',fixed=TRUE)[[1]]
 if(length(z)==1)list(selector='All',predictor=z) else list(selector=z[1],predictor=z[2])
}
selector_cache <- new.env(parent=emptyenv())
get_selected <- function(selector,tr,pp,seed){
 key<-paste(selector,paste(sort(tr),collapse='_'),sep='__')
 if(exists(key,selector_cache,inherits=FALSE))return(get(key,selector_cache))
 z<-select_genes(selector,pp$tr,y[tr],seed)
 assign(key,z,selector_cache);z
}
rows<-list();preds<-list();full_fits<-list();tuning<-list()
cp_path <- file.path(SD,'17_80_models_checkpoint.rds')
if(file.exists(cp_path)){
 cp<-readRDS(cp_path);stopifnot(identical(cp$models,models),identical(cp$genes,genes))
 rows<-cp$rows;preds<-cp$preds;full_fits<-cp$full_fits;tuning<-cp$tuning
}
for(i in seq_along(models)){
 model<-models[i]
 if(model %in% names(rows))next
 message('[',i,'/80] ',model)
 recipe<-split_recipe(model);parameters<-specs(recipe$predictor)
 oof<-matrix(NA_real_,length(train),length(parameters))
 for(k in 1:10){
  tr<-train[foldid!=k];te<-train[foldid==k];pp<-prep(tr,te)
  selected<-safe(get_selected(recipe$selector,tr,pp,20261008+k),paste0('select fold',k),model)
  if(is.null(selected))next
  for(j in seq_along(parameters)){
   p<-safe({f<-fit_model(recipe$predictor,parameters[j],pp$tr[,selected,drop=FALSE],y[tr],20261008+k)
    predict_fit(f,pp$te[,selected,drop=FALSE])},paste0('fit fold',k,' spec',parameters[j]),model)
   if(length(p)==length(te)&&all(is.finite(p)))oof[which(foldid==k),j]<-p
  }
 }
 cv_aucs<-vapply(seq_along(parameters),function(j)safe_auc(y[train],oof[,j]),numeric(1))
 best<-if(any(is.finite(cv_aucs)))which.max(replace(cv_aucs,!is.finite(cv_aucs),-Inf)) else 1L
 tuning[[model]]<-data.table(model=model,parameter=parameters,Train_10fold= cv_aucs,selected=seq_along(parameters)==best)
 pp<-prep(train,unlist(tests));selected<-safe(get_selected(recipe$selector,train,pp,20261008), 'final selection',model)
 fit<-if(!is.null(selected))safe(fit_model(recipe$predictor,parameters[best],pp$tr[,selected,drop=FALSE],y[train],20261008), 'final fit',model) else NULL
 pv<-if(!is.null(fit))safe(predict_fit(fit,pp$te[,selected,drop=FALSE]),'heldout predict',model) else NULL
 if(length(pv)!=nrow(pp$te)||any(!is.finite(pv)))pv<-rep(NA_real_,nrow(pp$te))
 aucs<-c(Train_10fold=cv_aucs[best],GSE243173=safe_auc(y[tests$GSE243173],pv[seq_along(tests$GSE243173)]),
  GSE223924=safe_auc(y[tests$GSE223924],pv[length(tests$GSE243173)+seq_along(tests$GSE223924)]))
 complete<-all(is.finite(aucs))
 rows[[model]]<-data.table(model=model,Train_10fold=aucs[1],GSE243173=aucs[2],GSE223924=aucs[3],
  Mean=if(complete)mean(aucs) else NA_real_,status=if(complete)'Computed' else 'Failed/incomplete',
  provenance=if(i<=78)'Pan Fig3A visible' else 'Prespecified conjectural extension',
  selected_parameter=parameters[best],selected_gene_n=if(!is.null(fit))length(fit$genes) else NA_integer_,
  selected_genes=if(!is.null(fit))paste(fit$genes,collapse=';') else '')
 preds[[model]]<-rbind(data.table(model=model,sample=meta$sample[train],dataset=meta$dataset[train],
   group=y[train],probability=oof[,best],prediction_type='Training OOF, tuning-selected'),
  data.table(model=model,sample=meta$sample[unlist(tests)],dataset=meta$dataset[unlist(tests)],
   group=y[unlist(tests)],probability=pv,prediction_type='Model-selection cohort, not independent locked test'))
 full_fits[[model]]<-list(fit=fit,selected_features=selected,predictor=recipe$predictor,parameter=parameters[best])
 saveRDS(list(models=models,genes=genes,rows=rows,preds=preds,full_fits=full_fits,tuning=tuning),cp_path)
 fwrite(rbindlist(rows),file.path(SD,'17_model_AUCs_live.csv'))
}
results<-rbindlist(rows)
setorder(results,-Mean,model)
fwrite(results,file.path(SD,'18_80_model_AUCs.csv'))
fwrite(rbindlist(preds),file.path(SD,'18_80_model_predictions.csv.gz'))
fwrite(rbindlist(tuning),file.path(SD,'18_model_tuning.csv'))
if(length(errors))fwrite(rbindlist(errors),file.path(SD,'18_model_errors.csv'))
if(length(warns))fwrite(unique(rbindlist(warns)),file.path(SD,'18_model_warnings.csv'))
eligible<-results[status=='Computed' & selected_gene_n>0]
if(!nrow(eligible))stop('No complete non-intercept model available')
winner<-eligible[1]
fitted<-full_fits[[winner$model]]
selected<-fitted$fit$genes
fwrite(data.table(gene=selected),file.path(SD,'19_best_model_genes.csv'))
saveRDS(list(results=results,predictions=preds,best_model=winner$model,selected_genes=selected,
 train=train,tests=tests,X=X,y=y,meta=meta,foldid=foldid,full_fits=full_fits),file.path(SD,'19_completed_models.rds'))
write_json(list(attempted_models=80,complete_models=sum(results$status=='Computed'),
 failed_models=results[status!='Computed',model],best_model=winner$model,
 best_mean_AUC=winner$Mean,best_genes=selected,training_cohorts=c('GSE173078','GSE223328'),
 training_N=40,comparison_cohorts=c('GSE243173','GSE223924'),comparison_N=c(12,20),
 candidates=genes,manually_added_axis_genes=0,extensions=models[79:80],
 caveats=c('78 Fig3A combinations plus 2 inferred extensions; NOT 113-author-code replication',
 '16 connected PPI candidates available instead of padding to 20',
 'DE/WGCNA upstream selection used all 72 samples; comparison cohorts are NOT independent validation',
 'Hyperparameters selected with training 10-fold CV; these OOF AUCs are model-selection estimates, not nested-CV unbiased performance',
 'Unseen-cohort alignment uses unlabeled cohort-specific mean/SD; not deployable individual diagnostic scoring',
 'Best model picked on mean AUC of training and two comparison cohorts, as Pan; no locked untouched test cohort',
 'No GDF15, MAPK1, MAPK3, MMP1, MMP3 was manually inserted; disease discrimination does not establish vitamin D causality')),
 file.path(SD,'19_model_summary.json'),pretty=TRUE,auto_unbox=TRUE)
print(results[1:10]);message('Winner: ',winner$model,' Mean AUC ',round(winner$Mean,3),' genes: ',paste(selected,collapse=','))
sink(type='message');sink();close(logcon)
