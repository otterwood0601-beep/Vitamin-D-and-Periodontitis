import csv, json
from pathlib import Path
root = Path(__file__).resolve().parent
visible = (root / 'Pan_Fig3A_visible_models.txt').read_text().splitlines()
assert len(visible) == len(set(visible)) == 78
chosen = ['Stepglm[both]+Enet[alpha=0.9]', 'Stepglm[backward]+Enet[alpha=0.9]']
predictors = ['Lasso', 'Ridge'] + [f'Enet[alpha={i / 10:.1f}]' for i in range(1, 10)] + ['Stepglm[forward]', 'glmBoost', 'plsRglm', 'RF', 'GBM', 'XGBoost', 'SVM', 'LDA', 'NaiveBayes']
selectors = ['RF', 'Lasso', 'glmBoost', 'Stepglm[both]', 'Stepglm[backward]']
proposed = chosen.copy()
for first in selectors:
    for second in predictors:
        name = first + '+' + second
        if first != second and name not in visible and (name not in proposed):
            proposed.append(name)
assert len(proposed) >= 35
proposed = proposed[:35]
rows = []
for i, m in enumerate(visible + proposed, 1):
    rows.append({'catalog_id': i, 'model': m, 'provenance': 'Pan Fig3A visible' if i <= 78 else 'Conjectural extension, NOT author-confirmed', 'run_in_80_model_figure': i <= 80, 'reason': '' if i <= 78 else 'Complete alpha 0.1-0.9 grid already visible for this Stepglm selector' if m in chosen else 'Pair a disclosed first-stage selector with a disclosed prediction family; author usage unknown'})
with (root / '16_model_catalog_78_visible_35_conjectural.csv').open('w', newline='', encoding='utf-8-sig') as f:
    writer = csv.DictWriter(f, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)
(root / '16_selected_80_models.txt').write_text('\n'.join(visible + chosen) + '\n', encoding='utf-8')
(root / '16_model_catalog_status.json').write_text(json.dumps({'visible_model_count': 78, 'conjectural_count': 35, 'model_count_to_run': 80, 'selected_extensions': chosen, 'selection_time': 'Before computing model AUCs', 'selection_not_based_on_results': True, 'not_claiming_Pan_113_reproduction': True}, indent=2), encoding='utf-8')
print('80-model manifest frozen: 78 visible + 2 prespecified extensions')
