import hashlib, json, sys
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import rankdata
from pypdf import PdfReader
ROOT = Path(__file__).resolve().parent
sys.stdout.reconfigure(encoding='utf-8')
pred = pd.read_csv(ROOT / '18_80_model_predictions.csv.gz')
table = pd.read_csv(ROOT / '18_80_model_AUCs.csv')
catalog = pd.read_csv(ROOT / '16_model_catalog_78_visible_35_conjectural.csv')
assert len(table) == table.model.nunique() == 80
assert len(catalog) == 113 and catalog.run_in_80_model_figure.sum() == 80
assert len(pred) == 80 * 72 and (not pred[['model', 'sample']].duplicated().any())
assert np.isfinite(pred.probability).all() and pred.probability.between(0, 1).all()

def auc(y, p):
    y = np.asarray(y)
    ranks = rankdata(p)
    n1 = int((y == 1).sum())
    n0 = int((y == 0).sum())
    return float((ranks[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))
checks = []
for model, part in pred.groupby('model'):
    tr = part[part.prediction_type.str.startswith('Training')]
    assert len(tr) == 40 and tr.group.value_counts().to_dict() == {0: 20, 1: 20}
    a = auc(tr.group, tr.probability)
    rec = table.set_index('model').loc[model]
    vals = [a]
    checks.append(abs(a - rec.Train_10fold))
    for cohort, n in [('GSE243173', 12), ('GSE223924', 20)]:
        z = part[part.dataset.eq(cohort)]
        assert len(z) == n
        q = auc(z.group, z.probability)
        vals.append(q)
        checks.append(abs(q - rec[cohort]))
    checks.append(abs(np.mean(vals) - rec.Mean))
assert max(checks) < 1e-12
ranked = table.sort_values(['Mean', 'model'], ascending=[False, True])
eligible = ranked[ranked.selected_gene_n.gt(0)]
summary = json.loads((ROOT / '19_model_summary.json').read_text(encoding='utf-8'))
assert eligible.iloc[0].model == summary['best_model']
assert set(summary['best_genes']) == {'TLR4', 'VCAN', 'SLC2A3', 'STOM'}
assert not set(summary['best_genes']) & {'GDF15', 'MAPK1', 'MAPK3', 'MMP1', 'MMP3'}
sp = pd.read_csv(ROOT / '20_selected_gene_predictions.csv.gz')
sa = pd.read_csv(ROOT / '20_selected_gene_ROC_AUCs.csv').set_index('gene')
for gene, z in sp.groupby('gene'):
    tr = z[z.prediction_type.str.startswith('Training')]
    assert abs(auc(tr.group, tr.probability) - sa.loc[gene, 'Train_10fold']) < 1e-12
    for cohort in ['GSE243173', 'GSE223924']:
        v = z[z.dataset.eq(cohort)]
        assert abs(auc(v.group, v.probability) - sa.loc[gene, cohort]) < 1e-12
pdf = ROOT.parent / '\u56fe' / 'Fig3_Gingiva_Pan2026_80Models_AD_20261008.pdf'
reader = PdfReader(pdf)
assert len(reader.pages) == 1
text = reader.pages[0].extract_text()
assert all((w in text for w in ['TLR4', 'VCAN', 'SLC2A3', 'STOM', 'Specificity', 'exploratory']))
assert len(text) > 3500
old = Path('E:/\u8840\u6e05\u7ef4\u751f\u7d20D DLC/output/BioorganicChemistry2026_\u5e72\u5b9e\u9a8c\u8fc1\u79fb_20260924/figures/Fig3_Gingiva_ML_GDF15_ERK_MMP_BioorgChem_style.pdf')
oldhash = hashlib.sha256(old.read_bytes()).hexdigest().upper()
assert oldhash == '03DCB9C702B7D5F01EDD846E96AF554734BFFB2B8D7B877F1589DE3FF75F763F'
result = {'actual_model_rows': 80, 'models_with_complete_finite_predictions': 80, 'prediction_rows': len(pred), 'independent_AUC_checks': len(checks), 'max_AUC_difference': max(checks), 'genes': summary['best_genes'], 'qualifying_single_genes_AUC_gt07_all_three': sa.index[sa.passes_AUC_gt07_all_comparisons].tolist(), 'pdf_pages': len(reader.pages), 'pdf_size_pt': [float(v) for v in reader.pages[0].mediabox[2:]], 'original_figure_preserved_SHA256': oldhash, 'final_pdf_sha256': hashlib.sha256(pdf.read_bytes()).hexdigest(), 'not_independent_validation': True, 'no_forced_hypothesis_genes': True, 'rendered_visual_check': 'Recorded separately after inspecting final PNG; numerical checks do not establish visual fidelity'}
(ROOT / '22_independent_numeric_QA.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
pd.DataFrame(columns=['stage', 'model', 'message']).to_csv(ROOT / '18_model_errors.csv', index=False)
print(json.dumps(result, indent=2))
