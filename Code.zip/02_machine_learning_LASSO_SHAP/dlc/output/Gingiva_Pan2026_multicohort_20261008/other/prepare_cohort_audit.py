import csv, gzip, hashlib, io, json, sys, tarfile
from pathlib import Path
import numpy as np
import pandas as pd
from fetch_candidate_inputs import retrieve, ROOT, RAW
sys.stdout.reconfigure(encoding='utf-8')

def read_audit(acc):
    p = RAW / acc / 'metadata_expression_audit.json'
    return json.loads(p.read_text(encoding='utf-8'))['matrices'][0]

def values(sm, key):
    return sm.get(key, [[]])[0]

def chars(sm):
    out = {}
    for row in sm.get('!Sample_characteristics_ch1', []):
        name = row[0].split(':', 1)[0].strip().lower()
        out[name] = [v.split(':', 1)[1].strip() if ':' in v else v for v in row]
    return out

def matrix(path):
    with gzip.open(path, 'rt', encoding='utf-8') as f:
        for line in f:
            if line.startswith('!series_matrix_table_begin'):
                break
        return pd.read_csv(f, sep='\t', comment='!', index_col=0)

def sample_manifest():
    rows = []
    for acc in ['GSE173078', 'GSE223924', 'GSE106090', 'GSE223328', 'GSE243173']:
        a = read_audit(acc)
        sm = a['sample_metadata']
        c = chars(sm)
        titles = values(sm, '!Sample_title')
        gsms = values(sm, '!Sample_geo_accession')
        for i, title in enumerate(titles):
            reason = ''
            group = ''
            batch = acc
            note = ''
            if acc == 'GSE173078':
                sample = title.split('_')[0]
                ph = c['phenotype'][i]
                group = {'Healthy': 'Control', 'Periodontitis': 'Periodontitis'}.get(ph, '')
                if not group:
                    reason = 'Gingivitis is not the requested case-control endpoint'
                batch = acc + '_' + c['batch'][i]
            elif acc == 'GSE223924':
                sample = title.split('[')[-1].rstrip(']')
                ph = c['subject status'][i]
                group = {'Healthy control': 'Control', 'Periodontitis': 'Periodontitis'}.get(ph, '')
                if not group:
                    reason = 'Peri-implant tissue excluded'
                note = 'Periodontitis cases also have peri-implantitis; comorbidity sensitivity required'
            elif acc == 'GSE106090':
                sample = gsms[i]
                ph = c['subject status'][i]
                group = {'healthy individual': 'Control', 'periodontitis patient': 'Periodontitis'}.get(ph, '')
                if not group:
                    reason = 'Peri-implant tissue excluded'
            elif acc == 'GSE223328':
                sample = gsms[i]
                group = 'Control' if title.startswith('H_') else 'Periodontitis'
                note = 'EBV balanced 4 positive and 4 negative per group; retain EBV covariate'
            else:
                sample = values(sm, '!Sample_description')[i]
                aliases = {'perio10': 'Perio10', 'perio14': 'Perio14', 'perio16': 'Perio16', 'perio23': 'Perio_23'}
                sample = aliases.get(sample, sample)
                ph = c['disease'][i]
                group = {'Healthy': 'Control', 'chronic pariodontiits': 'Periodontitis'}.get(ph, '')
                if not group:
                    reason = 'LAD1 immunodeficiency-associated periodontitis excluded'
                note = 'GEO processing text says mouse reference but actual count identifiers are human ENSG; discrepancy retained'
            rows.append(dict(dataset=acc, sample=sample, unique_id=acc + '__' + sample, GSM=gsms[i], title=title, group=group, include=bool(group), exclusion_reason=reason, batch=batch, EBV=c.get('ebv status', ['Not measured'] * len(titles))[i], notes=note, source='https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=' + acc))
    df = pd.DataFrame(rows)
    assert not df.unique_id.duplicated().any()
    included = df[df.include]
    assert len(included) == 84
    df.to_csv(ROOT / '03_sample_eligibility_manifest.csv', index=False, encoding='utf-8-sig')
    included.to_csv(ROOT / '04_model_sample_metadata.csv', index=False, encoding='utf-8-sig')
    print(included.groupby(['dataset', 'group']).size().unstack().to_string(), flush=True)

def annotation106():
    p = RAW / 'GSE106090' / 'GSE106090_RAW.tar'
    retrieve('https://ftp.ncbi.nlm.nih.gov/geo/series/GSE106nnn/GSE106090/suppl/GSE106090_RAW.tar', p)
    with tarfile.open(p) as t:
        members = [m for m in t.getmembers() if m.isfile() and m.name.endswith('.txt.gz')]
        m = next((m for m in members if 'GSM2829425_' in m.name))
        with gzip.GzipFile(fileobj=t.extractfile(m)) as g:
            lines = io.TextIOWrapper(g, encoding='utf-8', errors='replace')
            first = [next(lines) for _ in range(15)]
            print('GSE106090 archive annotation header:\n' + ''.join(first)[:2200], flush=True)
            data = ''.join(first) + lines.read()
    out = ROOT / 'geo_metadata' / 'GSE106090_processed_annotation_example.txt'
    if not out.exists():
        out.write_text(data, encoding='utf-8')

def overlap():
    a = matrix(RAW / 'GSE10334' / 'GSE10334_series_matrix.txt.gz')
    b = matrix(RAW / 'GSE16134' / 'GSE16134_series_matrix.txt.gz')
    common = a.index.intersection(b.index)
    a = a.loc[common]
    b = b.loc[common]
    bh = {hashlib.sha256(np.asarray(b[c], dtype='<f8').tobytes()).hexdigest(): c for c in b}
    matches = []
    for c in a:
        h = hashlib.sha256(np.asarray(a[c], dtype='<f8').tobytes()).hexdigest()
        if h in bh:
            matches.append(dict(GSE10334_GSM=c, GSE16134_GSM=bh[h], compared_probe_rows=len(common), sha256=h, max_absolute_difference=0))
    pd.DataFrame(matches, columns=['GSE10334_GSM', 'GSE16134_GSM', 'compared_probe_rows', 'sha256', 'max_absolute_difference']).to_csv(ROOT / '05_exact_cross_GSE_duplicates.csv', index=False)
    receipt = dict(compared_rows=len(common), GSE10334_samples=len(a.columns), GSE16134_samples=len(b.columns), exact_duplicate_profiles=len(matches), interpretation='Exact duplicate columns are not independent validation samples; no match does not establish donor independence')
    (ROOT / '05_duplicate_check.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    print('Overlap check', receipt, flush=True)
if __name__ == '__main__':
    sample_manifest()
    annotation106()
    overlap()
