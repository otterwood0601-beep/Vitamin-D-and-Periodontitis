old_wrapper <- 'C:/wb_links/pan_multicohort_20261008_other/plot_axis5_BCD_variant.R'
for(e in parse(old_wrapper)){
 if(is.call(e)&&identical(e[[1]],as.name('eval')))break
 eval(e,envir=.GlobalEnv)
}
replace_once("BASE <- 'Fig3_Gingiva_Pan2026_80Models_A_Axis5_BCD_20261008'",
 "BASE <- 'Fig3_Gingiva_Pan2026_80Models_A_Axis5_NestedOptimized_BCD_20261008'")
code <- gsub('24_axis5_', '30_axis5_nested_', code, fixed=TRUE)
code <- gsub('25_axis5_figure_manifest.json', '31_axis5_nested_figure_manifest.json', code, fixed=TRUE)
start <- regexpr('single<-list();single_auc<-list();single_predictions<-list()',code,fixed=TRUE)[1]
end <- regexpr('aucs<-rbindlist(single_auc)',code,fixed=TRUE)[1]
stopifnot(start>0,end>start)
end <- end+nchar('aucs<-rbindlist(single_auc)')-1
replacement <- paste(
 "nested<-readRDS(file.path(SD,'29_axis5_nested_results.rds'))",
 "stopifnot(identical(nested$genes,selected),identical(nested$foldid,foldid))",
 "single<-nested$single;aucs<-nested$aucs",
 "single_predictions<-split(nested$predictions,nested$predictions$gene)",sep='\n')
code <- paste0(substr(code,1,start-1),replacement,substr(code,end+1,nchar(code)))
replace_once("'Training 10-fold OOF single-gene ROC; fixed direction; source rainbow positions'",
 "'Nested 10-outer/5-inner-fold single-gene ROC; 18 training-only configurations; fixed direction; conditional 95% DeLong intervals shown'")
replace_once("'Panels B-D: user-requested GDF15, MAPK1, MAPK3, MMP1, MMP3; NOT genes selected by panel A. D: training 10-fold single-gene ROC.'",
 "'B-D: user-requested genes, NOT selected by A. D: nested 10x5-fold ROC; 18 training-only configurations. A: exploratory, not independent validation.'")
replace_once("'B/C: pooled descriptive expression. AUCs are exploratory, not independent validation; no ERK activation, pathway or vitamin D causality claim.'",
 "'D brackets: conditional 95% DeLong CI, excluding model-selection uncertainty. B/C descriptive; no ERK activation or vitamin D causality claim.'")
replace_once("legend(.37,.36,legend=paste0(selected,', AUC=',sprintf('%.3f',aucs$Train_10fold)),",
 "legend(.37,.29,legend=paste0(selected,', AUC=',sprintf('%.3f',aucs$Train_10fold),' [',sprintf('%.2f',aucs$conditional_DeLong_95CI_low),'-',sprintf('%.2f',aucs$conditional_DeLong_95CI_high),']'),")
replace_once("col=roc_palette,lty=1,lwd=1,bty='n',cex=.70,y.intersp=.93,x.intersp=.5)",
 "col=roc_palette,lty=1,lwd=1,bty='n',cex=.61,y.intersp=.98,x.intersp=.5)")
eval(parse(text=code),envir=.GlobalEnv)
