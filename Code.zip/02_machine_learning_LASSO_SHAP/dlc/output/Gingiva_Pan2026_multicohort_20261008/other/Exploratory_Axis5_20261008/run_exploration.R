options(stringsAsFactors=FALSE,scipen=999)
.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(pROC);library(jsonlite);library(splines)})
ROOT<-'C:/wb_links/pan_multicohort_20261008_other'
SD<-file.path(ROOT,'Exploratory_Axis5_20261008')
if(file.exists(file.path(SD,'07_exploration_results.rds')))stop('Completed exploration exists; preserve it')
genes<-c('GDF15','MAPK1','MAPK3','MMP1','MMP3')
methods<-c('linear_logistic','quadratic_logistic','natural_spline_df3')
norm<-readRDS(file.path(ROOT,'08_normalized_cohorts.rds'))
meta<-copy(norm$meta);y<-as.integer(meta$group=='Periodontitis')
X<-t(do.call(cbind,lapply(norm$exprs,function(z)z[genes,,drop=FALSE])))
stopifnot(identical(rownames(X),meta$sample),all(is.finite(X)),length(unique(meta$sample))==72)
cohorts<-c('GSE173078','GSE223328','GSE243173','GSE223924')
subsets<-list();add<-function(name,indices,type,seed=NA_integer_){
 ii<-sort(indices);subsets[[length(subsets)+1L]]<<-list(name=name,index=ii,type=type,seed=seed)
}
for(k in 1:4)for(cc in combn(cohorts,k,simplify=FALSE))
 add(paste(cc,collapse='+'),which(meta$dataset %in% cc),'Complete cohort combination')
for(e in 0:1)add(paste0('GSE223328_EBV_',e),which(meta$dataset=='GSE223328' & meta$EBV_binary==e),'Clinical EBV stratum')

for(frac in c(.50,.75))for(s in 1:100){
 seed<-20261008L+as.integer(frac*100)*1000L+s;set.seed(seed)
 ii<-unlist(lapply(split(seq_len(nrow(meta)),paste(meta$dataset,y,sep='_')),function(z)
  sample(z,size=max(2L,floor(length(z)*frac)),replace=FALSE)),use.names=FALSE)
 add(sprintf('Random_stratified_%02dpct_%03d',as.integer(frac*100),s),ii,'Random stratified subset',seed)
}
stopifnot(length(subsets)==217)
inventory<-rbindlist(lapply(seq_along(subsets),function(i){a<-subsets[[i]]
 data.table(subset_id=i,subset_name=a$name,type=a$type,seed=a$seed,N=length(a$index),
 Control=sum(y[a$index]==0),Periodontitis=sum(y[a$index]==1),
 cohorts=paste(sort(unique(meta$dataset[a$index])),collapse=';'))}))
members<-rbindlist(lapply(seq_along(subsets),function(i)
 cbind(data.table(subset_id=i),meta[subsets[[i]]$index,.(sample,dataset,GSM,group,EBV)])))
fwrite(inventory,file.path(SD,'01_subset_inventory.csv'))
fwrite(members,file.path(SD,'02_all_subset_memberships.csv'))
write_json(list(plan_fixed_before_this_search=TRUE,search_is_post_hoc_to_prior_results=TRUE,
 subset_count=217,complete_cohort_or_EBV_subsets=17,random_subsets=200,
 random_fractions=c(.5,.75),draws_per_fraction=100,methods=methods,genes=genes,
 CV='Up to 5 stratified folds; same folds for every gene and method within a subset',
 preprocessing='Per-fold cohort-wise centering/scaling, no labels in transforms; no ComBat input to CV',
 selection_rule='For each subset choose highest OOF AUC method per gene; rank subsets by lowest gene AUC, then mean AUC, then larger N',
 all_five_genes_share_same_selected_sample_set=TRUE,values_or_labels_modified=FALSE,
 do_not_call_independent_validation=TRUE,stop_after_fixed_search_regardless_of_target=TRUE),
 file.path(SD,'00_frozen_exploration_plan.json'),pretty=TRUE,auto_unbox=TRUE)
folds<-function(labels,k,seed){set.seed(seed);f<-integer(length(labels))
 for(g in 0:1){z<-which(labels==g);f[z]<-sample(rep(seq_len(k),length.out=length(z)))};f}
warnings<-list();errors<-list()
predict_fold<-function(ii,fold,method,g,subset_id){
 tr<-ii[fold$tr];te<-ii[fold$te];xt<-X[tr,g];xv<-X[te,g]
 for(acc in unique(meta$dataset[c(tr,te)])){
  a<-which(meta$dataset[tr]==acc);b<-which(meta$dataset[te]==acc)
  zz<-if(length(a))xt[a] else xv[b]
  mu<-mean(zz);ss<-sd(zz);if(!is.finite(ss)||ss<1e-10)ss<-1
  if(length(a))xt[a]<-(xt[a]-mu)/ss
  if(length(b))xv[b]<-(xv[b]-mu)/ss
 }
 fm<-switch(method,linear_logistic=y~x,quadratic_logistic=y~x+I(x^2),natural_spline_df3=y~splines::ns(x,df=3))
 tryCatch(withCallingHandlers({
  fit<-glm(fm,data=data.frame(y=y[tr],x=xt),family=binomial())
  as.numeric(predict(fit,newdata=data.frame(x=xv),type='response'))
 },warning=function(w){warnings[[length(warnings)+1L]]<<-data.table(subset_id=subset_id,gene=g,method=method,message=conditionMessage(w));invokeRestart('muffleWarning')}),
 error=function(e){errors[[length(errors)+1L]]<<-data.table(subset_id=subset_id,gene=g,method=method,message=conditionMessage(e));rep(NA_real_,length(te))})
}
results<-list();preds<-list();fold_members<-list()
for(i in seq_along(subsets)){
 ii<-subsets[[i]]$index;k<-min(5L,min(table(y[ii])));fid<-folds(y[ii],k,20261008L+i)
 fold_members[[i]]<-data.table(subset_id=i,sample=meta$sample[ii],fold=fid)
 for(g in genes)for(method in methods){
  p<-rep(NA_real_,length(ii))
  for(f in seq_len(k)){a<-list(tr=which(fid!=f),te=which(fid==f))
   p[a$te]<-predict_fold(ii,a,method,g,i)}
  valid<-all(is.finite(p)) && all(p>=0 & p<=1)
  aucv<-if(valid)as.numeric(pROC::auc(pROC::roc(y[ii],p,levels=c(0,1),direction='<',quiet=TRUE))) else NA_real_
  results[[length(results)+1L]]<-data.table(subset_id=i,gene=g,method=method,K=k,N=length(ii),OOF_AUC=aucv,status=if(valid)'Computed' else 'Failed')
  preds[[length(preds)+1L]]<-data.table(subset_id=i,gene=g,method=method,sample=meta$sample[ii],group=y[ii],fold=fid,probability=p)
 }
 if(i %% 10L==0L || i==length(subsets))message('Exploration ',i,'/',length(subsets))
}
res<-rbindlist(results);pr<-rbindlist(preds)
fwrite(res,file.path(SD,'03_all_3255_gene_method_AUC_attempts.csv'))

precise<-copy(pr);precise[,probability:=sprintf('%.17g',probability)]
fwrite(precise,file.path(SD,'04_all_OOF_predictions_full_precision.csv.gz'))
fwrite(rbindlist(fold_members),file.path(SD,'02_all_CV_fold_assignments.csv'))
if(length(warnings))fwrite(unique(rbindlist(warnings)),file.path(SD,'03_all_fit_warnings.csv'))
if(length(errors))fwrite(rbindlist(errors),file.path(SD,'03_all_fit_errors.csv'))
best<-res[status=='Computed'][order(subset_id,gene,-OOF_AUC,method),.SD[1],by=.(subset_id,gene)]
ranked<-best[,.(gene_n=.N,min_AUC=min(OOF_AUC),mean_AUC=mean(OOF_AUC),all_five_gt07=all(OOF_AUC>.7)),by=subset_id]
ranked<-merge(ranked,inventory,by='subset_id');ranked<-ranked[gene_n==5]
setorder(ranked,-min_AUC,-mean_AUC,-N,subset_id)
fwrite(best,file.path(SD,'05_best_method_each_gene_each_subset.csv'))
fwrite(ranked,file.path(SD,'05_all_subset_rankings.csv'))
win<-ranked[1];chosen<-best[subset_id==win$subset_id][match(genes,gene)]
ii<-subsets[[win$subset_id]]$index
chosen_pred<-pr[subset_id==win$subset_id][chosen,on=.(subset_id,gene,method),nomatch=0]
fwrite(chosen,file.path(SD,'06_selected_same_subset_gene_AUCs.csv'))
fwrite(meta[ii],file.path(SD,'06_selected_sample_metadata.csv'))
precise_chosen<-copy(chosen_pred);precise_chosen[,probability:=sprintf('%.17g',probability)]
fwrite(precise_chosen,file.path(SD,'06_selected_OOF_predictions_full_precision.csv'))
comb<-fread(file.path(ROOT,'09_pooled_ComBat.csv.gz'))
bx_all<-t(as.matrix(comb[match(genes,gene),-1]));colnames(bx_all)<-genes
stopifnot(identical(rownames(bx_all),meta$sample))
bx<-bx_all[ii,,drop=FALSE];yy<-y[ii];mm<-meta[ii]
roc<-setNames(lapply(genes,function(g){z<-chosen_pred[gene==g];pROC::roc(z$group,z$probability,levels=c(0,1),direction='<',quiet=TRUE)}),genes)
summary<-list(subsets_tested=217,gene_method_attempts=nrow(res),successful_attempts=sum(res$status=='Computed'),
 selected_subset=as.list(win),selected_methods_and_AUCs=chosen,
 subsets_all_five_gt07=sum(ranked$all_five_gt07),not_independent_validation=TRUE,
 same_samples_for_every_gene=TRUE,no_values_or_labels_modified=TRUE,
 selection_bias='Best subset and best method selected after evaluating outcomes; these AUCs are optimistic exploratory maxima',
 small_sample_warning='Small subsets can have separation, unstable fits and wide uncertainty; all warnings retained',
 no_claim_of_ERK_activation_or_vitamin_D_causality=TRUE)
saveRDS(list(results=res,rankings=ranked,chosen=chosen,chosen_pred=chosen_pred,subsets=subsets,
 meta=mm,y=yy,bx=bx,roc=roc,summary=summary),file.path(SD,'07_exploration_results.rds'))
write_json(summary,file.path(SD,'07_exploration_summary.json'),pretty=TRUE,auto_unbox=TRUE)
print(win);print(chosen)
