from pathlib import Path
import json, hashlib
import numpy as np
import pandas as pd
from scipy.stats import rankdata, ttest_ind, pearsonr, norm
from pypdf import PdfReader
from PIL import Image
sd = Path(__file__).resolve().parent
root = sd.parent
genes = ['GDF15', 'MAPK1', 'MAPK3', 'MMP1', 'MMP3']
inv = pd.read_csv(sd / '01_subset_inventory.csv')
mem = pd.read_csv(sd / '02_all_subset_memberships.csv')
res = pd.read_csv(sd / '03_all_3255_gene_method_AUC_attempts.csv')
pred = pd.read_csv(sd / '04_all_OOF_predictions_full_precision.csv.gz', float_precision='round_trip')
assert len(inv) == 217 and len(res) == 3255
assert (res.status == 'Computed').all() and set(res.gene) == set(genes)
assert not pred.duplicated(['subset_id', 'gene', 'method', 'sample']).any()
assert np.isfinite(pred.probability).all() and pred.probability.between(0, 1).all()
source = pd.read_csv(root / '03_sample_eligibility_manifest.csv')
source = source[source.include & source.dataset.isin(['GSE173078', 'GSE223328', 'GSE243173', 'GSE223924'])]
labels = source.set_index('unique_id').group.map({'Control': 0, 'Periodontitis': 1})
assert len(labels) == 72 and pred['sample'].isin(labels.index).all()
assert (pred['sample'].map(labels).to_numpy() == pred.group.to_numpy()).all()
assert not mem.duplicated(['subset_id', 'sample']).any()
folds = pd.read_csv(sd / '02_all_CV_fold_assignments.csv')
joined = pred.merge(folds, on=['subset_id', 'sample'], validate='many_to_one', suffixes=('', '_audit'))
assert (joined.fold == joined.fold_audit).all()
checks = 0
maxdiff = 0
lookup = res.set_index(['subset_id', 'gene', 'method'])
for key, z in pred.groupby(['subset_id', 'gene', 'method']):
    y = z.group.to_numpy()
    p = z.probability.to_numpy()
    n1 = (y == 1).sum()
    n0 = (y == 0).sum()
    a = (rankdata(p)[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)
    delta = abs(a - lookup.loc[key, 'OOF_AUC'])
    maxdiff = max(maxdiff, delta)
    assert delta < 1e-12, (key, a, lookup.loc[key, 'OOF_AUC'])
    assert len(z) == lookup.loc[key, 'N']
    checks += 1
best = res.sort_values(['subset_id', 'gene', 'OOF_AUC', 'method'], ascending=[True, True, False, True]).drop_duplicates(['subset_id', 'gene'])
ranks = best.groupby('subset_id').OOF_AUC.agg(['min', 'mean', 'count']).join(inv.set_index('subset_id')[['N']])
ranks = ranks.sort_values(['min', 'mean', 'N'], ascending=[False, False, False])
chosen = pd.read_csv(sd / '06_selected_same_subset_gene_AUCs.csv').set_index('gene').loc[genes]
win = int(chosen.subset_id.iloc[0])
assert win == int(ranks.index[0]) == 88
assert (chosen.OOF_AUC > 0.7).all()
assert int((ranks['min'] > 0.7).sum()) == 1
diagnostic_checks = 0
for pname, tname, key, acol in [('10_complement_predictions_full_precision.csv', '10_complement_AUCs_NOT_independent.csv', ['gene'], 'complement_AUC'), ('10_selected_subset_20_repeats_predictions.csv.gz', '10_selected_subset_20_repeats_AUCs.csv', ['repeat_id', 'gene'], 'AUC')]:
    dp = pd.read_csv(sd / pname, float_precision='round_trip')
    dt = pd.read_csv(sd / tname).set_index(key)
    assert (dp['sample'].map(labels).to_numpy() == dp.group.to_numpy()).all()
    for dk, dz in dp.groupby(key):
        yy = dz.group.to_numpy()
        prob = dz.probability.to_numpy()
        n1 = (yy == 1).sum()
        n0 = (yy == 0).sum()
        av = (rankdata(prob)[yy == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)
        lk = dk[0] if len(key) == 1 else dk
        assert abs(av - dt.loc[lk, acol]) < 1e-12
        diagnostic_checks += 1
cpred = pd.read_csv(sd / '06_selected_OOF_predictions_full_precision.csv', float_precision='round_trip')
memberships = [set(cpred[cpred.gene == g]['sample']) for g in genes]
assert all((s == memberships[0] for s in memberships)) and len(memberships[0]) == 36
cis = pd.read_csv(sd / '08_selected_AUC_conditional_intervals.csv').set_index('gene')
for g in genes:
    z = cpred[cpred.gene == g]
    pos = z.loc[z.group == 1, 'probability'].to_numpy()
    neg = z.loc[z.group == 0, 'probability'].to_numpy()
    score = (pos[:, None] > neg[None, :]).astype(float) + 0.5 * (pos[:, None] == neg[None, :])
    a = score.mean()
    se = np.sqrt(score.mean(axis=1).var(ddof=1) / len(pos) + score.mean(axis=0).var(ddof=1) / len(neg))
    ci = np.clip([a - norm.ppf(0.975) * se, a + norm.ppf(0.975) * se], 0, 1)
    assert np.allclose(ci, cis.loc[g, ['conditional_DeLong_lower', 'conditional_DeLong_upper']].astype(float), atol=1e-12)
expr = pd.read_csv(sd / '08_panels_BC_selected_expression.csv').set_index('sample')
previous_expr = pd.read_csv(root / '24_axis5_panels_BC_gene_expression.csv').set_index('sample')
pd.testing.assert_frame_equal(expr, previous_expr.loc[expr.index], check_exact=False, atol=1e-12, rtol=1e-12)
lab = expr.index.to_series().map(labels)
bs = pd.read_csv(sd / '08_panel_B_descriptive_statistics.csv').set_index('gene')
corr = pd.read_csv(sd / '08_panel_C_correlations.csv').set_index('gene')
for g in genes:
    p = ttest_ind(expr.loc[lab == 0, g], expr.loc[lab == 1, g], equal_var=True).pvalue
    assert np.isclose(p, bs.loc[g, 'unpaired_two_sided_t_P'], rtol=1e-10)
    for h in genes:
        assert np.isclose(pearsonr(expr[g], expr[h]).statistic, corr.loc[g, h], atol=1e-12)
pd.testing.assert_frame_equal(pd.read_csv(sd / '08_panel_A_original_80_models.csv'), pd.read_csv(root / '20_panel_A_80_models_source.csv'))
oldpdf = root.parent / '\u56fe' / 'Fig3_Gingiva_Pan2026_80Models_A_Axis5_BCD_20261008.pdf'
assert hashlib.sha256(oldpdf.read_bytes()).hexdigest() == 'b94e63324b50c7108742d25a0bbcd0b35679def5812341360f6b7c4e32c8d419'
pdf = root.parent / '\u56fe' / 'Fig3_Gingiva_Axis5_PostHoc_Exploration_20261008.pdf'
r = PdfReader(pdf)
assert len(r.pages) == 1
txt = r.pages[0].extract_text()
assert all((g in txt for g in genes)) and 'POST-HOC SELECTED' in txt and ('NOT independent' in txt) and ('0.424' in txt)
im = Image.open(sd / 'Fig3_exploration_preview.png')
oldim = Image.open(root / 'Fig3_80Models_AD_preview.png')
assert np.array_equal(np.array(im.crop((0, 0, 900, 1870))), np.array(oldim.crop((0, 0, 900, 1870))))
check = {'subsets': 217, 'attempts': 3255, 'all_attempt_AUCs_independently_checked': checks, 'max_AUC_difference': maxdiff, 'selected_subset_id': win, 'selected_N': 36, 'all_genes_use_same_36_samples': True, 'all_original_labels_preserved': True, 'selected_expression_matches_unmodified_original_expression': True, 'conditional_DeLong_intervals_independently_checked': 5, 'B_t_tests_independently_checked': 5, 'C_correlations_independently_checked': 25, 'complement_and_repeated_CV_AUC_checks': diagnostic_checks, 'A_source_and_rendered_region_unchanged': True, 'old_axis5_PDF_preserved': True, 'post_hoc_warning_and_complement_performance_visible_on_PDF': True, 'pdf_pages': 1, 'no_independent_validation_claim': True, 'rendered_visual_check': 'Final preview inspected separately; numerical QA is not visual acceptance'}
(sd / '11_independent_QA.json').write_text(json.dumps(check, indent=2), encoding='utf-8')
print(json.dumps(check, indent=2))
