options(stringsAsFactors=FALSE,scipen=999)
.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(pROC);library(jsonlite)})
ROOT<-'C:/wb_links/pan_multicohort_20261008_other'
SD<-file.path(ROOT,'Exploratory_Axis5_20261008')
FD<-'C:/wb_links/pan_multicohort_20261008_figures'
BASE<-'Fig3_Gingiva_Axis5_PostHoc_Exploration_20261008'
rr<-readRDS(file.path(SD,'07_exploration_results.rds'))
obj<-readRDS(file.path(ROOT,'19_completed_models.rds'))
rows<-obj$results[order(is.na(Mean),-Mean,model)]
selected<-c('GDF15','MAPK1','MAPK3','MMP1','MMP3')
bx<-rr$bx;y<-rr$y;meta<-rr$meta;single<-rr$roc;aucs<-copy(rr$chosen)
stopifnot(identical(colnames(bx),selected),nrow(bx)==nrow(meta),all(aucs$gene==selected),nrow(rows)==80)
stars<-function(p)ifelse(p<.001,'***',ifelse(p<.01,'**',ifelse(p<.05,'*','ns')))
bstat<-rbindlist(lapply(selected,function(g){
 tt<-t.test(bx[y==0,g],bx[y==1,g],var.equal=TRUE)
 data.table(gene=g,unpaired_two_sided_t_P=tt$p.value,star=stars(tt$p.value))}))
bstat[,BH_FDR:=p.adjust(unpaired_two_sided_t_P,'BH')]
cx<-cor(bx);cp<-matrix(NA_real_,5,5,dimnames=list(selected,selected))
for(i in 1:5)for(j in 1:5)if(i!=j)cp[i,j]<-cor.test(bx[,i],bx[,j],method='pearson')$p.value
cis<-rbindlist(lapply(selected,function(g){
 ci<-as.numeric(pROC::ci.auc(single[[g]],method='delong'))
 data.table(gene=g,AUC=as.numeric(auc(single[[g]])),conditional_DeLong_lower=ci[1],conditional_DeLong_upper=ci[3],
 note='Conditional on selected predictions; NOT adjusted for subset/method selection and NOT independent validation')}))
fwrite(cis,file.path(SD,'08_selected_AUC_conditional_intervals.csv'))
fwrite(bstat,file.path(SD,'08_panel_B_descriptive_statistics.csv'))
fwrite(as.data.table(bx,keep.rownames='sample'),file.path(SD,'08_panels_BC_selected_expression.csv'))
fwrite(as.data.table(cx,keep.rownames='gene'),file.path(SD,'08_panel_C_correlations.csv'))
fwrite(as.data.table(cp,keep.rownames='gene'),file.path(SD,'08_panel_C_P_values.csv'))
fwrite(rows,file.path(SD,'08_panel_A_original_80_models.csv'))
fwrite(rbindlist(lapply(selected,function(g)data.table(gene=g,specificity=single[[g]]$specificities,
 sensitivity=single[[g]]$sensitivities))),file.path(SD,'08_panel_D_ROC_coordinates.csv'))
for(e in parse('C:/wb_links/bioorgchem2026_code/03_fig3_ml.R')){
 if(is.call(e)&&identical(e[[1]],as.name('<-'))&&is.symbol(e[[2]])&&
 as.character(e[[2]])=='roc_cols')eval(e)
}
roc_palette<-setNames(unname(roc_cols)[1:5],selected)

src<-readLines(file.path(ROOT,'plot_80_models_AD.R'),warn=FALSE)
first<-which(grepl("pdfpath<-file.path",src,fixed=TRUE))[1]
last<-which(trimws(src)=='dev.off()')[1]
code<-paste(src[first:last],collapse='\n')
replace_once<-function(old,new){stopifnot(grepl(old,code,fixed=TRUE));code<<-sub(old,new,code,fixed=TRUE)}
axis_ticks<-function(rx){
 z<-pretty(rx,n=4)
 z<-z[z>min(rx)+.20*diff(rx)&z<max(rx)-.20*diff(rx)]
 if(length(z)>2)z<-z[round(seq(1,length(z),length.out=2))]
 if(!length(z))z<-signif(mean(rx),2)
 z
}
code<-gsub('pretty(rx,n=3)','axis_ticks(rx)',code,fixed=TRUE)
code<-gsub('pretty(ry,n=3)','axis_ticks(ry)',code,fixed=TRUE)
replace_once('aucs$Train_10fold','aucs$OOF_AUC')
replace_once("legend(.37,.36,legend=paste0(selected,', AUC=',sprintf('%.3f',aucs$OOF_AUC)),",
 "legend(.33,.38,legend=paste0(selected,', AUC=',sprintf('%.3f',aucs$OOF_AUC),' (',sprintf('%.2f',cis$conditional_DeLong_lower),'-',sprintf('%.2f',cis$conditional_DeLong_upper),')'),")
replace_once("col=roc_palette,lty=1,lwd=1,bty='n',cex=.70,y.intersp=.93,x.intersp=.5)",
 "col=roc_palette,lty=1,lwd=1,bty='n',cex=.59,y.intersp=.93,x.intersp=.5)")
replace_once("mtext('D',side=3,line=.8,at=-.13,cex=1.05,adj=0)",
 paste0("mtext('D',side=3,line=.8,at=-.13,cex=1.05,adj=0)\nmtext('POST-HOC SELECTED: ",aucs$K[1],"-fold ROC',side=3,line=.20,at=.5,cex=.67,font=2,col='#A32020')"))
line1<-sprintf('A: original 80-model analysis unchanged. B-D: SAME post-hoc selected subset, n=%d (%d Control, %d Periodontitis).',nrow(meta),sum(y==0),sum(y==1))
line2<-'Selection searched 217 subsets and 3 methods per gene. Optimistic exploratory estimates, NOT independent validation; values/labels unchanged.'
line3<-'ROC intervals: conditional 95% DeLong, not selection-adjusted. B/C are descriptive. * In A: two inferred combinations. No pathway/VD causality claim.'
complement<-fread(file.path(SD,'10_complement_AUCs_NOT_independent.csv'))[match(selected,gene)]
line4<-paste0('Other 36 samples: AUCs ',paste(sprintf('%.3f',complement$complement_AUC),collapse=' / '),' (gene order above); selection-exposed, NOT independent.')
replace_once("'* On model labels: two inferred extensions. Train: GSE173078 + GSE223328 (n=40); comparisons: GSE243173 (n=12), GSE223924 (n=20).'",paste0("'",line1,"'"))
replace_once("'AUCs are exploratory model-selection estimates, not independent validation. Panel D: training 10-fold single-gene ROC; B/C: pooled descriptive expression.'",paste0("'",line2,"'"))
replace_once("'The comparison cohorts participated in upstream gene selection. No claim of GDF15/ERK/MMP pathway activation or vitamin D causality.'",paste0("'",line3,"'"))
replace_once("text(0,.75,", "text(0,.88,")
replace_once("text(0,.42,", "text(0,.62,")
replace_once("text(0,.09,", "text(0,.36,")
replace_once('dev.off()',paste0("text(0,.10,'",line4,"',adj=0,cex=.54)\ndev.off()"))
eval(parse(text=code),envir=.GlobalEnv)
write_json(list(PDF=file.path(FD,paste0(BASE,'.pdf')),post_hoc=TRUE,
 not_independent_validation=TRUE,user_requested_genes=selected,
 selected_subset=rr$summary$selected_subset,methods=aucs,
 original_80_model_panel_A_unchanged=TRUE,old_figures_preserved=TRUE,
 intervals='Conditional DeLong; not selection-adjusted',
 reference_palette_and_layout_reused=TRUE),file.path(SD,'09_figure_manifest.json'),pretty=TRUE,auto_unbox=TRUE)
message('PDF written: ',file.path(FD,paste0(BASE,'.pdf')))
