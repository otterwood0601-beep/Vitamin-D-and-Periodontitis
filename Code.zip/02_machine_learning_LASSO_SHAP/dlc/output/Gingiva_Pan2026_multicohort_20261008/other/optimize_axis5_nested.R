options(stringsAsFactors=FALSE,scipen=999)
.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(pROC);library(randomForest);library(e1071);library(jsonlite)})
SD<-'C:/wb_links/pan_multicohort_20261008_other'
z<-readRDS(file.path(SD,'08_normalized_cohorts.rds'))
old<-readRDS(file.path(SD,'19_completed_models.rds'))
genes<-c('GDF15','MAPK1','MAPK3','MMP1','MMP3')
X<-t(do.call(cbind,lapply(z$exprs,function(m)m[genes,,drop=FALSE])))
meta<-old$meta;y<-old$y;train<-old$train;tests<-old$tests;outer<-old$foldid
stopifnot(identical(rownames(X),meta$sample),length(train)==40,all(is.finite(X)))

algos<-c('logit','poly2','ns2','ns3','ns4','knn5','knn9','knn15','rf5','rf9','svm05','svm1')
specs<-rbind(data.table(transform='zscore',algorithm=algos),
 data.table(transform='rank_gauss',algorithm=c('logit','poly2','ns3','knn9','rf5','svm1')))
specs[,id:=paste(transform,algorithm,sep='__')]
fwrite(specs,file.path(SD,'28_axis5_frozen_18_configurations.csv'))
write_json(list(outer_folds=10,inner_folds=5,outer_split='Unchanged original 40-sample folds',
 candidates=nrow(specs),selection='Inner pooled OOF AUC; ties by log-loss then frozen order',
 validation_labels_used_for_tuning=FALSE,clinical_covariates_or_other_genes_added=FALSE,
 seed=20261008,not_changing_seed_to_hit_threshold=TRUE),file.path(SD,'28_axis5_optimization_protocol.json'),pretty=TRUE,auto_unbox=TRUE)
rank_auc<-function(a,p){
 if(any(!is.finite(p))||length(unique(a))!=2)return(NA_real_)
 n1<-sum(a==1);n0<-sum(a==0)
 (sum(rank(p,ties.method='average')[a==1])-n1*(n1+1)/2)/(n1*n0)
}
loss<-function(a,p){p<-pmax(1e-8,pmin(1-1e-8,p));-mean(a*log(p)+(1-a)*log(1-p))}
make_folds<-function(ii,seed){
 set.seed(seed);ans<-integer(length(ii))
 strata<-paste(meta$dataset[ii],y[ii])
 for(s in unique(strata)){j<-which(strata==s);ans[j]<-sample(rep(1:5,length.out=length(j)))}
 ans
}
qscale<-function(ref,v){
 q<-vapply(v,function(a)(sum(ref<a)+.5*sum(ref==a)+.5)/(length(ref)+1),numeric(1))
 qnorm(pmax(1e-5,pmin(1-1e-5,q)))
}
prep<-function(tr,te,g,transform){
 a<-X[tr,g];b<-X[te,g]
 for(co in unique(meta$dataset[c(tr,te)])){
  ia<-which(meta$dataset[tr]==co);ib<-which(meta$dataset[te]==co)
  ref<-if(length(ia))a[ia] else b[ib]
  if(transform=='zscore'){
   mu<-mean(ref);ss<-sd(ref);if(!is.finite(ss)||ss<1e-10)ss<-1
   if(length(ia))a[ia]<-(a[ia]-mu)/ss
   if(length(ib))b[ib]<-(b[ib]-mu)/ss
  }else{
   if(length(ia))a[ia]<-qscale(ref,a[ia])
   if(length(ib))b[ib]<-qscale(ref,b[ib])
  }
 }
 list(x=a,newx=b)
}
predict_one<-function(algorithm,x,a,newx,seed){
 set.seed(seed)
 if(sd(x)<1e-10)return(rep(mean(a),length(newx)))
 if(algorithm %in% c('logit','poly2','ns2','ns3','ns4')){
  formula<-switch(algorithm,logit=a~x,poly2=a~x+I(x^2),ns2=a~splines::ns(x,df=2),
   ns3=a~splines::ns(x,df=3),ns4=a~splines::ns(x,df=4))
  f<-suppressWarnings(glm(formula,data=data.frame(a=a,x=x),family=binomial(),control=list(maxit=100)))
  p<-suppressWarnings(predict(f,newdata=data.frame(x=newx),type='response'))
 }else if(startsWith(algorithm,'knn')){
  k<-as.integer(sub('knn','',algorithm,fixed=TRUE))
  
  p<-vapply(newx,function(v){d<-abs(x-v);cut<-sort(d)[min(k,length(d))];(sum(a[d<=cut])+.5)/(sum(d<=cut)+1)},numeric(1))
 }else if(startsWith(algorithm,'rf')){
  node<-as.integer(sub('rf','',algorithm,fixed=TRUE))
  f<-randomForest(x=data.frame(x=x),y=factor(a,levels=0:1),ntree=300,mtry=1,nodesize=node)
  p<-predict(f,data.frame(x=newx),type='prob')[,'1']
 }else{
  cost<-if(algorithm=='svm05').5 else 1
  f<-svm(x=data.frame(x=x),y=factor(a,levels=0:1),kernel='radial',cost=cost,gamma=.5,
   probability=TRUE,scale=FALSE)
  p<-attr(predict(f,data.frame(x=newx),probability=TRUE),'probabilities')[,'1']
 }
 as.numeric(p)
}
errors<-list();inner_records<-list();chosen_records<-list();outer_predictions<-list()
safe_predict<-function(tr,te,g,j,seed){
 tryCatch({pp<-prep(tr,te,g,specs$transform[j]);p<-predict_one(specs$algorithm[j],pp$x,y[tr],pp$newx,seed)
  stopifnot(length(p)==length(te),all(is.finite(p)),all(p>=0&p<=1));p},
  error=function(e){errors[[length(errors)+1]]<<-data.table(gene=g,spec=specs$id[j],seed=seed,message=conditionMessage(e));rep(NA_real_,length(te))})
}
tune<-function(tr,g,stage){
 fid<-make_folds(tr,20261008+stage)
 scores<-rbindlist(lapply(seq_len(nrow(specs)),function(j){
  p<-rep(NA_real_,length(tr))
  for(k in 1:5){aa<-tr[fid!=k];bb<-tr[fid==k];p[fid==k]<-safe_predict(aa,bb,g,j,20261008+stage*100+k)}
  data.table(gene=g,stage=stage,spec_id=j,spec=specs$id[j],inner_AUC=rank_auc(y[tr],p),
   inner_logloss=if(all(is.finite(p)))loss(y[tr],p) else Inf)
 }))
 inner_records[[length(inner_records)+1]]<<-scores
 eligible<-scores[is.finite(inner_AUC)]
 if(!nrow(eligible))stop('All inner configurations failed for ',g)
 setorder(eligible,-inner_AUC,inner_logloss,spec_id)
 eligible[1]
}
single<-list();aucs<-list();comparison_predictions<-list();final_choices<-list()
for(g in genes){
 message('Optimizing ',g,' using 18 configurations, nested 10 x 5 folds')
 p<-rep(NA_real_,length(train))
 for(k in 1:10){
  tr<-train[outer!=k];te<-train[outer==k];winner<-tune(tr,g,k)
  p[outer==k]<-safe_predict(tr,te,g,winner$spec_id,20261008+k)
  chosen_records[[length(chosen_records)+1]]<-data.table(gene=g,outer_fold=k,spec=winner$spec,
   inner_AUC=winner$inner_AUC,training_samples=paste(meta$sample[tr],collapse=';'),
   heldout_samples=paste(meta$sample[te],collapse=';'))
  message('  outer fold ',k,'/10: ',winner$spec)
 }
 stopifnot(all(is.finite(p)))
 final<-tune(train,g,0);final_choices[[g]]<-final
 te<-unlist(tests);pv<-safe_predict(train,te,g,final$spec_id,20261008)
 stopifnot(all(is.finite(pv)))
 roc<-pROC::roc(y[train],p,levels=c(0,1),direction='<',quiet=TRUE)
 single[[g]]<-roc;ci<-as.numeric(pROC::ci.auc(roc,method='delong'))
 aa<-c(Train_10fold=rank_auc(y[train],p),
  GSE243173=rank_auc(y[tests$GSE243173],pv[seq_along(tests$GSE243173)]),
  GSE223924=rank_auc(y[tests$GSE223924],pv[length(tests$GSE243173)+seq_along(tests$GSE223924)]))
 aucs[[g]]<-data.table(gene=g,Train_10fold=aa[1],GSE243173=aa[2],GSE223924=aa[3],
  conditional_DeLong_95CI_low=ci[1],conditional_DeLong_95CI_high=ci[3],
  passes_AUC_gt07_all_comparisons=all(aa>.7),final_training_only_configuration=final$spec)
 outer_predictions[[g]]<-rbind(data.table(gene=g,sample=meta$sample[train],dataset=meta$dataset[train],
  group=y[train],probability=p,prediction_type='Outer 10-fold OOF; inner 5-fold method selection'),
  data.table(gene=g,sample=meta$sample[te],dataset=meta$dataset[te],group=y[te],probability=pv,
  prediction_type='Comparison only; no tuning on comparison labels'))
 message(g,' nested AUC = ',round(aa[1],4))
}
aucs<-rbindlist(aucs);predictions<-rbindlist(outer_predictions)
fwrite(aucs,file.path(SD,'29_axis5_nested_AUCs.csv'))
pr<-copy(predictions);pr[,probability:=sprintf('%.17g',probability)]
fwrite(pr,file.path(SD,'29_axis5_nested_predictions_full_precision.csv.gz'))
fwrite(rbindlist(inner_records),file.path(SD,'29_axis5_all_inner_tuning.csv'))
fwrite(rbindlist(chosen_records),file.path(SD,'29_axis5_outer_selection_audit.csv'))
fwrite(rbindlist(final_choices),file.path(SD,'29_axis5_final_training_only_choices.csv'))
if(length(errors))fwrite(rbindlist(errors),file.path(SD,'29_axis5_fit_errors.csv'))
saveRDS(list(single=single,aucs=aucs,predictions=predictions,chosen=chosen_records,final_choices=final_choices,
 specs=specs,inner=inner_records,genes=genes,train=train,tests=tests,foldid=outer),file.path(SD,'29_axis5_nested_results.rds'))
oldauc<-fread(file.path(SD,'24_axis5_specified_gene_ROC_AUCs.csv'))
comparison<-merge(oldauc[,.(gene,Previous_logit_AUC=Train_10fold)],aucs[,.(gene,Nested_optimized_AUC=Train_10fold)],by='gene')
comparison[,difference:=Nested_optimized_AUC-Previous_logit_AUC]
fwrite(comparison,file.path(SD,'29_axis5_before_after.csv'))
print(aucs);print(comparison)
