from pathlib import Path
import hashlib, json
import numpy as np
import pandas as pd
from scipy.stats import rankdata, norm
from pypdf import PdfReader
from PIL import Image
root = Path(__file__).resolve().parent
g = ['GDF15', 'MAPK1', 'MAPK3', 'MMP1', 'MMP3']
old = root.parent / '\u56fe' / 'Fig3_Gingiva_Pan2026_80Models_A_Axis5_BCD_20261008.pdf'
assert hashlib.sha256(old.read_bytes()).hexdigest() == 'b94e63324b50c7108742d25a0bbcd0b35679def5812341360f6b7c4e32c8d419'
p = pd.read_csv(root / '29_axis5_nested_predictions_full_precision.csv.gz', float_precision='round_trip')
a = pd.read_csv(root / '29_axis5_nested_AUCs.csv').set_index('gene')
assert len(p) == 360 and (not p.duplicated(['gene', 'sample']).any())
assert set(p.gene) == set(g) and p.probability.between(0, 1).all()
ci_checks = 0
auc_checks = 0
for gene in g:
    for co in ['Train_10fold', 'GSE243173', 'GSE223924']:
        z = p[(p.gene == gene) & (p.dataset.isin(['GSE173078', 'GSE223328']) if co == 'Train_10fold' else p.dataset.eq(co))]
        pos = z.loc[z.group == 1, 'probability'].to_numpy()
        neg = z.loc[z.group == 0, 'probability'].to_numpy()
        pairs = (pos[:, None] > neg[None, :]).astype(float) + 0.5 * (pos[:, None] == neg[None, :])
        value = pairs.mean()
        assert np.isclose(value, a.loc[gene, co], atol=1e-12)
        auc_checks += 1
        if co == 'Train_10fold':
            se = np.sqrt(pairs.mean(axis=1).var(ddof=1) / len(pos) + pairs.mean(axis=0).var(ddof=1) / len(neg))
            lo, hi = np.clip(value + np.array([-1, 1]) * norm.ppf(0.975) * se, 0, 1)
            assert np.isclose(lo, a.loc[gene, 'conditional_DeLong_95CI_low'], atol=1e-12)
            assert np.isclose(hi, a.loc[gene, 'conditional_DeLong_95CI_high'], atol=1e-12)
            ci_checks += 1
folds = pd.read_csv(root / '29_axis5_outer_selection_audit.csv')
assert len(folds) == 50 and (not folds.duplicated(['gene', 'outer_fold']).any())
original = pd.read_csv(root / '17_train_10fold_assignments.csv')
for gene in g:
    seen = []
    for row in folds[folds.gene == gene].itertuples():
        tr = set(row.training_samples.split(';'))
        te = set(row.heldout_samples.split(';'))
        assert len(tr) == 36 and len(te) == 4 and (not tr.intersection(te))
        assert te == set(original.loc[original.fold == row.outer_fold, 'sample'])
        seen += list(te)
    assert len(seen) == len(set(seen)) == 40
tuning = pd.read_csv(root / '29_axis5_all_inner_tuning.csv')
assert len(tuning) == 5 * 11 * 18 and np.isfinite(tuning.inner_AUC).all()
for suffix in ['panel_A_80_models_source.csv', 'panel_B_statistics.csv', 'panels_BC_gene_expression.csv', 'panel_C_correlations.csv', 'panel_C_P_values.csv']:
    pd.testing.assert_frame_equal(pd.read_csv(root / ('30_axis5_nested_' + suffix)), pd.read_csv(root / ('24_axis5_' + suffix)))
new = root.parent / '\u56fe' / 'Fig3_Gingiva_Pan2026_80Models_A_Axis5_NestedOptimized_BCD_20261008.pdf'
r = PdfReader(new)
assert len(r.pages) == 1
txt = r.pages[0].extract_text()
assert all((gene in txt for gene in g)) and 'nested 10x5-fold' in txt
im = Image.open(root / 'Fig3_Axis5_NestedOptimized_preview.png')
prior = Image.open(root / 'Fig3_Axis5_BCD_preview.png')
assert im.size == prior.size
assert np.array_equal(np.array(im.crop((0, 0, 1619, 1235))), np.array(prior.crop((0, 0, 1619, 1235))))
assert np.array_equal(np.array(im.crop((0, 0, 900, 1870))), np.array(prior.crop((0, 0, 900, 1870))))
result = {'AUC_checks': auc_checks, 'conditional_CI_checks': ci_checks, 'no_outer_subject_overlap': True, 'all_990_inner_tuning_rows_valid': True, 'A_B_C_tables_and_rendered_regions_unchanged': True, 'old_PDF_hash_unchanged': True, 'new_PDF_pages': 1, 'no_forced_AUC_threshold': True, 'configuration_count': 18, 'no_138_model_recomputation': True}
(root / '32_axis5_nested_QA.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))
