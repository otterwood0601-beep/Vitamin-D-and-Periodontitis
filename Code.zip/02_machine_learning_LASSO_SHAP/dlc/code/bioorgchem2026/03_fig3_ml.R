options(stringsAsFactors = FALSE, scipen = 999)
set.seed(20260924)

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(patchwork)
  library(glmnet)
  library(randomForest)
  library(e1071)
  library(xgboost)
  library(pROC)
  library(GGally)
  library(ggplotify)
  library(ggrepel)
})

OUT <- "C:/wb_links/bioorgchem2026_20260924"
SD <- file.path(OUT, "source_data")
FD <- file.path(OUT, "figures")

bulk <- readRDS(file.path(SD, "01_bulk_merged_batch_corrected.rds"))
meta <- as.data.table(bulk$meta)
expr_raw <- bulk$expr_before
expr_combat <- bulk$expr_after
de <- fread(file.path(SD, "02_bulk_differential_expression.csv.gz"))
overlap <- fread(file.path(SD, "09_vitaminD_gingiva_overlap_genes.csv"))

axis_genes <- c("GDF15", "MAPK1", "MAPK3", "MMP1", "MMP2", "MMP3",
                "MMP7", "MMP8", "MMP9", "MMP13", "MMP14")
overlap_ranked <- overlap[order(FDR), gene]
candidate_genes <- unique(c(axis_genes, overlap_ranked))
candidate_genes <- intersect(candidate_genes, rownames(expr_raw))[1:20]
feature_genes <- c("GDF15", "MAPK1", "MAPK3", "MMP1", "MMP7", "MMP9")
stopifnot(all(feature_genes %in% candidate_genes))
fwrite(data.table(gene = candidate_genes,
                  role = ifelse(candidate_genes %in% axis_genes,
                                "Prespecified GDF15-ERK-MMP axis", "Vitamin D/gingiva overlap")),
       file.path(SD, "17_ML_candidate_genes.csv"))

message("[1/5] Prepare training and external validation gingiva cohorts")
cohort_z <- function(samples, genes) {
  x <- expr_raw[genes, samples, drop = FALSE]
  z <- t(scale(t(x)))
  z[!is.finite(z)] <- 0
  t(z)
}
train_samples <- meta[dataset == "GSE223924", sample]
valid_samples <- meta[dataset == "GSE173078", sample]
x_train_all <- cohort_z(train_samples, candidate_genes)
x_valid_all <- cohort_z(valid_samples, candidate_genes)
y_train <- as.integer(meta[match(train_samples, sample), group] == "Periodontitis")
y_valid <- as.integer(meta[match(valid_samples, sample), group] == "Periodontitis")

safe_auc <- function(y, p) {
  if (length(unique(y)) < 2 || any(!is.finite(p))) return(NA_real_)
  as.numeric(auc(roc(y, p, levels = c(0, 1), direction = "<", quiet = TRUE)))
}

predict_model <- function(model, xtr, ytr, xte) {
  xtr <- as.matrix(xtr); xte <- as.matrix(xte)
  if (model == "Logistic") {
    d <- data.frame(y = ytr, xtr, check.names = FALSE)
    fit <- suppressWarnings(glm(y ~ ., data = d, family = binomial()))
    return(as.numeric(predict(fit, newdata = data.frame(xte, check.names = FALSE), type = "response")))
  }
  if (model %in% c("Ridge", "Lasso", "Elastic net")) {
    alpha <- c(Ridge = 0, Lasso = 1, `Elastic net` = 0.5)[model]
    foldid <- rep(1:5, length.out = length(ytr))
    foldid <- sample(foldid)
    fit <- suppressWarnings(cv.glmnet(xtr, ytr, family = "binomial", alpha = alpha,
                                      nfolds = 5, foldid = foldid,
                                      type.measure = "deviance", standardize = FALSE))
    return(as.numeric(predict(fit, newx = xte, s = "lambda.min", type = "response")))
  }
  if (model == "Random forest") {
    fit <- randomForest(x = xtr, y = factor(ytr, levels = c(0, 1)),
                        ntree = 600, mtry = max(1, floor(sqrt(ncol(xtr)))))
    return(as.numeric(predict(fit, xte, type = "prob")[, "1"]))
  }
  if (model == "SVM linear") {
    fit <- svm(x = xtr, y = factor(ytr, levels = c(0, 1)), kernel = "linear",
               cost = 1, probability = TRUE, scale = FALSE)
    pr <- predict(fit, xte, probability = TRUE)
    return(as.numeric(attr(pr, "probabilities")[, "1"]))
  }
  if (model == "SVM radial") {
    fit <- svm(x = xtr, y = factor(ytr, levels = c(0, 1)), kernel = "radial",
               cost = 1, gamma = 1 / ncol(xtr), probability = TRUE, scale = FALSE)
    pr <- predict(fit, xte, probability = TRUE)
    return(as.numeric(attr(pr, "probabilities")[, "1"]))
  }
  if (model == "XGBoost") {
    dtr <- xgb.DMatrix(xtr, label = ytr)
    fit <- xgb.train(
      params = list(objective = "binary:logistic", eval_metric = "logloss",
                    max_depth = 2, eta = 0.05, subsample = 0.85,
                    colsample_bytree = 0.85, nthread = 2),
      data = dtr, nrounds = 80, verbose = 0
    )
    return(as.numeric(predict(fit, xgb.DMatrix(xte))))
  }
  stop("Unknown model")
}

message("[2/5] Generate leakage-controlled leave-one-out predictions")
model_names <- c("Logistic", "Ridge", "Lasso", "Elastic net",
                 "Random forest", "SVM linear", "SVM radial", "XGBoost")
x_train <- x_train_all[, feature_genes, drop = FALSE]
x_valid <- x_valid_all[, feature_genes, drop = FALSE]

multi_pred <- list()
for (model in model_names) {
  oof <- rep(NA_real_, nrow(x_train))
  for (i in seq_len(nrow(x_train))) {
    set.seed(20260924 + i + match(model, model_names) * 100)
    oof[i] <- tryCatch(
      predict_model(model, x_train[-i, , drop = FALSE], y_train[-i],
                    x_train[i, , drop = FALSE]),
      error = function(e) NA_real_
    )
  }
  set.seed(20260924 + match(model, model_names) * 1000)
  ext <- tryCatch(predict_model(model, x_train, y_train, x_valid),
                  error = function(e) rep(NA_real_, nrow(x_valid)))
  multi_pred[[model]] <- list(train = oof, valid = ext)
}

single_pred <- list()
for (gene in candidate_genes) {
  oof <- rep(NA_real_, nrow(x_train_all))
  for (i in seq_len(nrow(x_train_all))) {
    d <- data.frame(y = y_train[-i], x = x_train_all[-i, gene])
    fit <- suppressWarnings(glm(y ~ x, data = d, family = binomial()))
    oof[i] <- suppressWarnings(predict(fit, newdata = data.frame(x = x_train_all[i, gene]),
                                       type = "response"))
  }
  d <- data.frame(y = y_train, x = x_train_all[, gene])
  fit <- suppressWarnings(glm(y ~ x, data = d, family = binomial()))
  ext <- suppressWarnings(as.numeric(predict(fit, newdata = data.frame(x = x_valid_all[, gene]),
                                             type = "response")))
  single_pred[[gene]] <- list(train = oof, valid = ext)
}

auc_rows <- rbindlist(c(
  lapply(names(single_pred), function(g) data.table(
    model = paste0("Gene: ", g),
    Train_LOOCV = safe_auc(y_train, single_pred[[g]]$train),
    GSE173078 = safe_auc(y_valid, single_pred[[g]]$valid),
    model_class = "Single gene"
  )),
  lapply(names(multi_pred), function(m) data.table(
    model = m,
    Train_LOOCV = safe_auc(y_train, multi_pred[[m]]$train),
    GSE173078 = safe_auc(y_valid, multi_pred[[m]]$valid),
    model_class = "Six-gene axis"
  ))
))
auc_rows[, Mean := rowMeans(.SD, na.rm = TRUE), .SDcols = c("Train_LOOCV", "GSE173078")]
setorder(auc_rows, -Mean)
fwrite(auc_rows, file.path(SD, "18_ML_model_AUCs.csv"))

pred_out <- rbindlist(c(
  lapply(names(multi_pred), function(m) rbind(
    data.table(sample = train_samples, dataset = "GSE223924", group = y_train,
               model = m, probability = multi_pred[[m]]$train, prediction_type = "LOOCV"),
    data.table(sample = valid_samples, dataset = "GSE173078", group = y_valid,
               model = m, probability = multi_pred[[m]]$valid, prediction_type = "External")
  )),
  lapply(names(single_pred), function(g) rbind(
    data.table(sample = train_samples, dataset = "GSE223924", group = y_train,
               model = paste0("Gene: ", g), probability = single_pred[[g]]$train,
               prediction_type = "LOOCV"),
    data.table(sample = valid_samples, dataset = "GSE173078", group = y_valid,
               model = paste0("Gene: ", g), probability = single_pred[[g]]$valid,
               prediction_type = "External")
  ))
))
fwrite(pred_out, file.path(SD, "19_ML_predictions.csv.gz"))

message("[3/5] Build source-style ML heatmap and six-gene panels")
paper_theme <- theme_bw(base_size = 8, base_family = "Arial") +
  theme(
    panel.grid.major = element_line(colour = "#E7E7E7", linewidth = 0.25),
    panel.grid.minor = element_blank(),
    axis.title = element_text(size = 8),
    axis.text = element_text(size = 6.4, colour = "black"),
    plot.title = element_text(hjust = 0.5, size = 9),
    legend.title = element_text(size = 7),
    legend.text = element_text(size = 6.3),
    plot.margin = ggplot2::margin(3, 3, 3, 3)
  )

auc_long <- melt(auc_rows, id.vars = c("model", "model_class"),
                 measure.vars = c("Train_LOOCV", "GSE173078", "Mean"),
                 variable.name = "Cohort", value.name = "AUC")
auc_long[, model := factor(model, levels = rev(auc_rows$model))]
pA <- ggplot(auc_long, aes(Cohort, model, fill = AUC)) +
  geom_tile(colour = "white", linewidth = 0.35) +
  geom_text(aes(label = ifelse(is.finite(AUC), sprintf("%.3f", AUC), "NA")),
            size = 2.25, family = "Arial") +
  scale_fill_gradient2(low = "#2878B5", mid = "white", high = "#D73027",
                       midpoint = 0.6, limits = c(0.2, 1), name = "AUC") +
  labs(x = NULL, y = NULL) + paper_theme +
  theme(axis.text.y = element_text(size = 5.8),
        axis.text.x = element_text(angle = 45, hjust = 1),
        legend.position = "bottom")

expr6 <- as.data.table(expr_combat[feature_genes, , drop = FALSE], keep.rownames = "gene")
expr6 <- melt(expr6, id.vars = "gene", variable.name = "sample", value.name = "expression")
expr6[meta, on = "sample", group := i.group]
stars <- expr6[, {
  p <- wilcox.test(expression ~ group, exact = FALSE)$p.value
  list(p = p, label = fifelse(p < 0.001, "***", fifelse(p < 0.01, "**", fifelse(p < 0.05, "*", "ns"))),
       y = max(expression, na.rm = TRUE) + 0.55)
}, by = gene]
expr6[, gene := factor(gene, levels = feature_genes)]
stars[, gene := factor(gene, levels = feature_genes)]
pB <- ggplot(expr6, aes(gene, expression, fill = group)) +
  geom_boxplot(width = 0.64, outlier.size = 0.65, linewidth = 0.35,
               position = position_dodge(width = 0.72)) +
  geom_text(data = stars, aes(gene, y, label = label), inherit.aes = FALSE,
            size = 3.2, fontface = "bold", family = "Arial") +
  scale_fill_manual(values = c(Control = "#3C91E6", Periodontitis = "#F04E55"),
                    name = "Type") +
  labs(x = NULL, y = "Gene expression") + paper_theme +
  theme(axis.text.x = element_text(angle = 40, hjust = 1), legend.position = "top")

pair_df <- as.data.frame(t(expr_combat[feature_genes, , drop = FALSE]))
pairs <- ggpairs(
  pair_df,
  upper = list(continuous = wrap("cor", size = 3.2, colour = "black")),
  lower = list(continuous = wrap("smooth", alpha = 0.45, size = 0.35,
                                 colour = "#D65F73")),
  diag = list(continuous = wrap("densityDiag", fill = "#BFBFBF", alpha = 0.6)),
  progress = FALSE
) + theme_bw(base_size = 6, base_family = "Arial")
pC <- as.ggplot(~ print(pairs))

roc_cols <- c(GDF15 = "#F00000", MAPK1 = "#D9E600", MAPK3 = "#16DA2B",
              MMP1 = "#24D5DD", MMP7 = "#193BEB", MMP9 = "#F020F0")
roc_curves <- rbindlist(lapply(feature_genes, function(g) {
  r <- roc(y_valid, single_pred[[g]]$valid, levels = c(0, 1), direction = "<", quiet = TRUE)
  data.table(gene = g, specificity = r$specificities,
             sensitivity = r$sensitivities, AUC = as.numeric(auc(r)))
}))
roc_labels <- unique(roc_curves[, .(gene, AUC)])
roc_labels[, legend := paste0(gene, ", AUC=", sprintf("%.3f", AUC))]
roc_curves[roc_labels, on = "gene", legend := i.legend]
pD <- ggplot(roc_curves, aes(1 - specificity, sensitivity, colour = legend)) +
  geom_abline(slope = 1, intercept = 0, colour = "#777777", linewidth = 0.35) +
  geom_step(linewidth = 0.75) +
  scale_colour_manual(values = setNames(roc_cols[roc_labels$gene], roc_labels$legend),
                      name = NULL) +
  coord_equal() + labs(x = "1 - Specificity", y = "Sensitivity") + paper_theme +
  theme(legend.position = c(0.62, 0.25),
        legend.background = element_rect(fill = scales::alpha("white", 0.78), colour = NA))

layout_design <- "
AAAAAABBBB
AAAAAACCCC
AAAAAADDDD
"
fig3 <- pA + pB + pC + pD +
  plot_layout(design = layout_design, heights = c(0.72, 1.15, 1.05)) +
  plot_annotation(tag_levels = "A", theme = theme(
    plot.tag = element_text(family = "Arial", size = 15, face = "plain")
  ))

ggsave(file.path(FD, "Fig3_Gingiva_ML_GDF15_ERK_MMP_BioorgChem_style.pdf"),
       fig3, width = 10.8, height = 13.3, units = "in", device = cairo_pdf)

message("[4/5] Save interpretation manifest")
best <- auc_rows[which.max(Mean)]
axis_de <- de[gene %in% feature_genes, .(gene, logFC, adj.P.Val, status)]
manifest <- list(
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  training = "GSE223924 human gingiva: 10 control + 10 periodontitis",
  external_validation = "GSE173078 human gingiva: 12 control + 12 periodontitis; gingivitis excluded",
  scaling = "Within-cohort gene-wise z scores; no disease label used for scaling",
  training_resampling = "Leave-one-out out-of-fold predictions; internal tuning only within each training fold",
  six_gene_panel = feature_genes,
  best_displayed_model = as.list(best),
  axis_differential_expression = axis_de,
  caveat = paste(
    "The cohorts are small; AUC estimates are exploratory and imprecise.",
    "MAPK1/MAPK3 mRNA is not a proxy for ERK1/2 phosphorylation."
  )
)
jsonlite::write_json(manifest, file.path(SD, "20_Fig3_ML_manifest.json"),
                     auto_unbox = TRUE, pretty = TRUE, dataframe = "rows")

message("[5/5] Completed Fig. 3")
print(auc_rows[1:10])
