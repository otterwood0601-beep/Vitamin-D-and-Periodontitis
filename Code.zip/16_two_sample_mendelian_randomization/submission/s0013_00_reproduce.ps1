$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\Temp\fibro_mr_20261020'
New-Item -ItemType Directory -Path $taskRoot -Force | Out-Null
foreach ($taskFile in @('run_local_mr.py','make_figures.py','package_results.py','validate_results.py','verify_twosamplemr.R','TwoSampleMR_mr.R','TwoSampleMR_source_url.txt')) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot $taskFile) -Destination (Join-Path $taskRoot $taskFile) -Force
}
$taskSoftware = "E:\$([char]0x767D)$([char]0x8272)$([char]0x5FF5)$([char]0x73E0)$([char]0x83CC)\Agent$([char]0x6587)$([char]0x4EF6)$([char]0x5939)\$([char]0x8FD0)$([char]0x884C)$([char]0x73AF)$([char]0x5883)$([char]0x4E0E)$([char]0x5DE5)$([char]0x4F5C)$([char]0x533A)\$([char]0x4E34)$([char]0x65F6)$([char]0x5DE5)$([char]0x4F5C)$([char]0x533A)\_codex_tmp\smr_recalc_20260923\software"
Copy-Item -LiteralPath (Join-Path $taskSoftware 'smr\smr-1.3.1-win-x86_64\smr-1.3.1-win.exe') -Destination (Join-Path $taskRoot 'smr.exe') -Force
Copy-Item -LiteralPath (Join-Path $taskSoftware 'plink.exe') -Destination (Join-Path $taskRoot 'plink.exe') -Force
$taskPanel = "E:\$([char]0x8840)$([char]0x6E05)$([char]0x7EF4)$([char]0x751F)$([char]0x7D20)\$([char]0x539F)$([char]0x59CB)$([char]0x6570)$([char]0x636E)\03_xQTL$([char]0x4E0E)$([char]0x53C2)$([char]0x8003)$([char]0x9762)$([char]0x677F)\xQTL$([char]0x9762)$([char]0x677F)\GTEx_V8_cis_eqtl_summary_lite\eQTL_besd_lite\Cells_Cultured_fibroblasts.lite"
foreach ($taskExt in @('.besd','.epi','.esi')) {
    Copy-Item -LiteralPath ($taskPanel + $taskExt) -Destination (Join-Path $taskRoot ('fibro' + $taskExt)) -Force
}
if (-not (Test-Path -LiteralPath (Join-Path $taskRoot 'strong.txt'))) {
    & (Join-Path $taskRoot 'smr.exe') --beqtl-summary (Join-Path $taskRoot 'fibro') --query 5e-8 --out (Join-Path $taskRoot 'strong')
    if ($LASTEXITCODE -ne 0) { throw 'SMR extraction failed.' }
}
& python -X utf8 -u (Join-Path $taskRoot 'run_local_mr.py')
if ($LASTEXITCODE -ne 0) { throw 'MR analysis failed.' }
& python -X utf8 -u (Join-Path $taskRoot 'validate_results.py')
if ($LASTEXITCODE -ne 0) { throw 'TwoSampleMR validation failed.' }
& python -X utf8 -u (Join-Path $taskRoot 'make_figures.py')
if ($LASTEXITCODE -ne 0) { throw 'Figure rendering failed.' }
& python -X utf8 -u (Join-Path $taskRoot 'package_results.py')
if ($LASTEXITCODE -ne 0) { throw 'Result packaging failed.' }
