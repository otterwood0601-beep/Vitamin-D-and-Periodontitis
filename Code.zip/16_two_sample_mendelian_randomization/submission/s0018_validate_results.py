from pathlib import Path
import json, shutil, subprocess
import pandas as pd
import numpy as np
ROOT = Path('C:\\Temp\\fibro_mr_20261020')
OUT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u8f93\u51fa\\20261020_\u6210\u7ea4\u7ef4\u7ec6\u80deeQTL_MR_\u539f\u6587\u65b9\u6cd5')
shutil.copy2(OUT / 'tables/03_harmonization_FinnGen_chronic.csv', ROOT / 'harmonized_for_R.csv')
r = subprocess.run(['C:\\Program Files\\R\\R-4.5.3\\bin\\Rscript.exe', str(ROOT / 'verify_twosamplemr.R')], capture_output=True, text=True, errors='replace', timeout=180)
(OUT / 'audit/R_validation_console.log').write_text(r.stdout + r.stderr, encoding='utf8')
if r.returncode:
    raise RuntimeError(r.stderr)
a = pd.read_csv(OUT / 'tables/04_discovery_all_genes.csv')
b = pd.read_csv(ROOT / 'TwoSampleMR_independent_check.csv')
d = a.merge(b, on='Probe')
assert len(d) == len(a) == len(b)
result = {}
for x, y in [('beta', 'beta_R'), ('se', 'se_R'), ('p_MR', 'p_R'), ('FDR', 'FDR_R'), ('Q', 'Q_R'), ('egger_intercept', 'egger_intercept_R'), ('egger_intercept_p', 'egger_intercept_p_R')]:
    diff = abs(d[x] - d[y])
    assert np.allclose(d[x], d[y], rtol=1e-07, atol=1e-10, equal_nan=True), x
    result[x] = {'n_compared': int(diff.notna().sum()), 'max_abs_difference': float(diff.max())}
result.update(n_genes=len(d), passed=True)
(OUT / 'audit/TwoSampleMR_numerical_validation.json').write_text(json.dumps(result, indent=2), encoding='utf8')
shutil.copy2(ROOT / 'TwoSampleMR_independent_check.csv', OUT / 'audit/TwoSampleMR_independent_check.csv')
shutil.copy2(__file__, OUT / 'code' / Path(__file__).name)
print('[VALIDATION_DONE]')
