from pathlib import Path
import json, textwrap, shutil, hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib.backends.backend_pdf import PdfPages
from pypdf import PdfReader, PdfWriter
OUT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u8f93\u51fa\\20261020_\u6210\u7ea4\u7ef4\u7ec6\u80deeQTL_MR_\u539f\u6587\u65b9\u6cd5')
F = OUT / 'figures'
F.mkdir(exist_ok=True)
T = OUT / 'tables'
A = OUT / 'audit'
plt.rcParams.update({'font.family': 'Arial', 'font.size': 11, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none', 'axes.linewidth': 1, 'savefig.facecolor': 'white', 'axes.spines.top': False, 'axes.spines.right': False})
res = pd.read_csv(T / '04_discovery_all_genes.csv')
cand = pd.read_csv(T / '05_prespecified_candidates.csv')
cnt = pd.read_csv(T / '01_gene_instrument_counts.csv')
sel = json.loads((A / 'selection.json').read_text())
summary = json.loads((A / 'results_summary.json').read_text())
BLUE = '#e9f1f4'
PAPER = 'Zhou et al., Experimental Gerontology 223 (2026) 113251, Figs. 1-3.'
plots = []

def export(fig, name):
    for ext in ['pdf', 'svg']:
        fig.savefig(F / f'{name}.{ext}', bbox_inches='tight', pad_inches=0.12)
    fig.savefig(F / f'{name}.png', dpi=600, bbox_inches='tight', pad_inches=0.12)
    fig.savefig(A / f'{name}_preview.png', dpi=130, bbox_inches='tight', pad_inches=0.12)
    plots.append(F / f'{name}.pdf')
    plt.close(fig)

def note(fig, y, text, width=128):
    s = textwrap.fill(text, width=width, break_long_words=False, break_on_hyphens=False)
    fig.text(0.04, y, s, ha='left', va='top', fontsize=9, fontfamily='Times New Roman', linespacing=1.3)

def forest(ax, df, heading, empty_message=None, limits=None):
    ax.set_xlim(0, 1)
    n = max(1, len(df))
    ax.set_ylim(n + 2, 0)
    ax.axis('off')
    cols = [0.018, 0.195, 0.305, 0.411, 0.506, 0.87]
    headers = ['Cell type', 'eGene', 'Method', 'Pval', 'FDR', 'OR (95% CI)']
    for x, s in zip(cols, headers):
        ax.text(x, 0.55, s, fontfamily='Times New Roman', weight='bold', fontsize=12, ha='left' if x == cols[0] else 'center', va='center')
    ax.text(0.018, 1.52, heading, fontfamily='Times New Roman', weight='bold', fontsize=12, va='center')
    for y in [0, 1.05, 2, n + 2]:
        ax.plot([0, 1], [y, y], color='black', lw=0.9, clip_on=False)
    ax.plot([0, 0], [0, n + 2], color='black', lw=0.9, clip_on=False)
    ax.plot([1, 1], [0, n + 2], color='black', lw=0.9, clip_on=False)
    if len(df) == 0:
        ax.add_patch(Rectangle((0.001, 2), 0.998, 1, color=BLUE, zorder=0))
        ax.text(0.5, 2.5, empty_message or 'No eligible association.', fontfamily='Times New Roman', fontsize=12, ha='center', va='center')
        return
    valid = df[df.OR.notna()] if 'OR' in df else pd.DataFrame()
    if limits is None:
        lo = min(0.75, float(valid.OR_lower.min()) * 0.92) if len(valid) else 0.5
        hi = max(1.25, float(valid.OR_upper.max()) * 1.04) if len(valid) else 1.5
    else:
        lo, hi = limits
    left, right = (0.57, 0.755)
    trans = lambda z: left + (z - lo) / (hi - lo) * (right - left)
    ax.plot([trans(1), trans(1)], [2, n + 2], ls=(0, (5, 4)), color='black', lw=0.8, zorder=1)
    for i, (_, r) in enumerate(df.iterrows()):
        y = i + 2.5
        if i % 2 == 0:
            ax.add_patch(Rectangle((0.001, i + 2), 0.998, 1, color=BLUE, zorder=0))
        ax.text(cols[0], y, 'Fibroblast', fontsize=11, fontfamily='Times New Roman', va='center')
        ax.text(cols[1], y, r.Gene, fontsize=11, fontfamily='Times New Roman', ha='center', va='center')
        ok = pd.notna(r.get('OR', np.nan))
        vals = [r.get('method', '\u2014') if ok else '\u2014', f'{r.p_MR:.3g}' if ok else '\u2014', f'{r.FDR:.4f}' if ok else '\u2014']
        for x, s in zip(cols[2:5], vals):
            ax.text(x, y, s, fontsize=10.8, fontfamily='Times New Roman', ha='center', va='center')
        if ok:
            ax.plot([trans(r.OR_lower), trans(r.OR_upper)], [y, y], color='black', lw=1.5, zorder=3)
            for x in [trans(r.OR_lower), trans(r.OR_upper)]:
                ax.plot([x, x], [y - 0.16, y + 0.16], color='black', lw=1.5, zorder=3)
            ax.plot(trans(r.OR), y, marker='D', markersize=5, color='black', zorder=4)
            ci = f'{r.OR:.4f} ({r.OR_lower:.4f}, {r.OR_upper:.4f})'
        else:
            code = {'not_in_local_lite_panel': '1', 'no_eQTL_P_below_5e-8': '2', 'all_instruments_excluded_in_harmonization': '3'}.get(r.get('reason'), '4')
            ci = f'Not estimable [{code}]'
        ax.text(cols[-1], y, ci, fontsize=10.8, fontfamily='Times New Roman', ha='center', va='center')

def figure1():
    fig = plt.figure(figsize=(10.8, 7.1))
    fig.text(0.025, 0.96, 'A', fontsize=20, weight='bold')
    for rect, n, label in [([0.08, 0.42, 0.34, 0.5], sel['strong_genes_query'], 'Before clumping'), ([0.48, 0.42, 0.34, 0.5], sel['genes_after_clump'], 'After clumping')]:
        ax = fig.add_axes(rect)
        ax.pie([1], colors=['#a4cbdc'], startangle=90, wedgeprops={'width': 0.5, 'edgecolor': 'white', 'linewidth': 0.7})
        ax.text(0, 0, f'{label}\n{n:,} eGenes', ha='center', va='center', fontsize=12, weight='bold')
        ax.text(0, 0.75, '100%', ha='center', va='center', fontsize=8)
    fig.text(0.87, 0.7, 'cell', weight='bold', fontsize=12)
    fig.patches.append(Rectangle((0.87, 0.654), 0.014, 0.022, transform=fig.transFigure, facecolor='#a4cbdc'))
    fig.text(0.895, 0.665, 'Cultured\nfibroblasts', fontsize=10, va='center')
    fig.text(0.025, 0.4, 'B', fontsize=20, weight='bold')
    counts = cnt.n_independent.value_counts().to_dict()
    vals = [counts.get(1, 0), counts.get(2, 0), counts.get(3, 0), counts.get(4, 0), sum((v for k, v in counts.items() if k >= 5))]
    for rect, vs, cs, labs, label in [([0.15, 0.21, 0.46, 0.13], vals[:2][::-1], ['#76b879', '#9f96c0'], ['n=2', 'n=1'], True), ([0.68, 0.21, 0.24, 0.13], vals[2:][::-1], ['#f8d5c3', '#e88062', '#ad1d2d'], ['n\u22655', 'n=4', 'n=3'], False)]:
        ax = fig.add_axes(rect)
        base = 0
        for v, c, lab in zip(vs, cs, labs):
            ax.barh([0], [v], left=base, color=c, height=0.38, label=lab, edgecolor='white', linewidth=0.6)
            base += v
        ax.set_ylim(-0.5, 0.5)
        ax.set_xlim(0, max(1, base * 1.12))
        ax.set_yticks([0], ['Cultured\nfibroblasts'] if label else [''])
        ax.tick_params(axis='y', length=0)
        ax.tick_params(axis='x', labelsize=8)
        ax.spines[['top', 'right', 'left']].set_visible(False)
        ax.grid(axis='x', color='#dddddd', lw=0.5)
        ax.set_axisbelow(True)
        ax.set_xlabel('Number of eGenes', weight='bold', fontsize=10)
        handles, labels = ax.get_legend_handles_labels()
        ax.legend(handles[::-1], labels[::-1], title='IVs per eGene', loc='lower center', bbox_to_anchor=(0.5, 1.04), ncol=len(vs), frameon=False, fontsize=8, title_fontsize=8)
    note(fig, 0.09, "Fig. 1. Selection of cis-eQTL instruments. A: eGenes with P < 5 \xd7 10\u207b\u2078 before LD-reference matching/clumping and after PLINK clumping (r\xb2 < 0.001, 10 Mb; F \u2265 10). B: number of independent IVs per eGene before outcome harmonization. Only one cultured-fibroblast panel is available; the source paper's 14 immune-cell categories are not reproduced.", 132)
    export(fig, 'Figure_1_instrument_selection')

def figure2():
    fig = plt.figure(figsize=(10.8, 6.6))
    fig.text(0.025, 0.96, 'A', fontsize=20, weight='bold')
    ax = fig.add_axes([0.11, 0.36, 0.86, 0.56])
    palette = ['#528ec6', '#f7a21c', '#8bbb35', '#6950a2', '#73c3b5', '#c0dd93', '#e11e23', '#eeea10', '#527d38', '#9c5faa', '#5bc5ed', '#ffd126', '#f99021', '#ef5041', '#5d56aa', '#58ae4e', '#9c75bb', '#645cab', '#ef3264', '#74c6e9', '#fdd22a', '#71b75f', '#8a8a8a']
    starts = {}
    ticks = []
    x = 0
    for c in range(1, 24):
        d = res[res.Chr.astype(str) == str(c)]
        size = max(float(d.lead_BP.max()) if len(d) else 0, 50000000.0)
        starts[c] = x
        if len(d):
            ax.scatter(x + d.lead_BP, -np.log10(d.FDR), s=10, color=palette[c - 1], alpha=0.9, lw=0)
        ticks.append(x + size / 2)
        x += size + 12000000.0
    ax.axhline(-np.log10(0.05), color='#888888', ls=(0, (5, 5)), lw=1)
    ax.set_xlim(0, x)
    ax.set_ylim(0, max(1.48, float(-np.log10(res.FDR.min())) * 1.1))
    ax.set_xticks(ticks, [str(c) if c < 23 else 'X' for c in range(1, 24)])
    ax.tick_params(axis='x', labelsize=9, pad=2)
    ax.set_xlabel('Chr', weight='bold')
    ax.set_ylabel('$-\\log_{10}(\\mathrm{FDR})$', fontsize=11)
    ax.text(x * 0.995, 1.32, 'FDR = 0.05', ha='right', fontsize=9, color='#666666')
    fig.text(0.025, 0.255, 'B', fontsize=20, weight='bold')
    ax2 = fig.add_axes([0.05, 0.13, 0.92, 0.12])
    sig = res[res.FDR < 0.05]
    forest(ax2, sig, 'Chronic periodontitis (FinnGen)', f'No eGene passed FDR < 0.05 among {len(res):,} tested eGenes.')
    note(fig, 0.075, f"Fig. 2. Discovery-stage MR. A: each point is one cultured-fibroblast eGene, positioned at its lead instrumental variant. The dashed line marks FDR = 0.05; chromosomes are individually coloured. B: the source paper's FDR-significant forest-table criterion is retained. No association qualified. {summary['nominal_P_lt_005']} genes had nominal P < 0.05, which is not evidence of FDR significance.", 132)
    export(fig, 'Figure_2_discovery')

def figure3():
    fig = plt.figure(figsize=(11.8, 6.3))
    ax = fig.add_axes([0.03, 0.225, 0.94, 0.72])
    forest(ax, cand, 'Chronic periodontitis (FinnGen): 11 existing candidates + MAPK1/MAPK3')
    note(fig, 0.18, "Fig. 3. Candidate-gene results, displayed in the source paper's forest-table style. These are targeted displays of the discovery analysis, not an independent replication. FDR values are corrected across all 6,718 tested eGenes. Diamonds are odds ratios; whiskers are 95% confidence intervals; the dashed line is OR = 1.", 150)
    note(fig, 0.105, '[1] Gene absent from the local lite panel. [2] No cis-eQTL passed P < 5 \xd7 10\u207b\u2078 (GDF15 minimum P = 2.02 \xd7 10\u207b\u2076). [3] The clumped VDR instrument, rs12827401 (A/T), was excluded because exposure allele frequency was unavailable. Effects are per source-expression unit; an SD rescaling has not been independently verified. AR is on chromosome X.', 150)
    export(fig, 'Figure_3_candidate_genes')

def figure4():
    fig = plt.figure(figsize=(11.8, 5.1))
    ax = fig.add_axes([0.03, 0.21, 0.94, 0.72])
    top = res.head(10)
    forest(ax, top, 'Exploratory ranking: 10 smallest P values; no FDR-significant associations')
    note(fig, 0.15, "Fig. 4. Exploratory display of the ten smallest discovery P values, using the source paper's forest-table layout. This display differs from the source paper's replication figure: these are discovery estimates selected for description only. All FDR values exceed 0.05; none is a confirmed causal or therapeutic target. Full results for every tested gene are supplied in Table 04.", 150)
    export(fig, 'Figure_4_exploratory_ranking')

def summary_page():
    fig = plt.figure(figsize=(8.27, 11.69))
    fig.patch.set_facecolor('white')

    def tx(x, y, s, size=11, bold=False, color='#1b1b1b'):
        fig.text(x, y, s, fontfamily='Microsoft YaHei', fontsize=size, weight='bold' if bold else 'normal', color=color, va='top', linespacing=1.65)
    tx(0.08, 0.95, '\u6210\u7ea4\u7ef4\u7ec6\u80de eQTL \u2192 \u7259\u5468\u708e MR', 19, True)
    tx(0.08, 0.91, '\u672c\u5730\u6570\u636e\u5b9e\u8dd1\u7ed3\u679c\uff5c2026-10-20', 11, color='#555555')
    tx(0.08, 0.86, '\u4e3b\u8981\u7ed3\u679c\uff1a\u6ca1\u6709\u57fa\u56e0\u901a\u8fc7\u5168\u57fa\u56e0 FDR \u6821\u6b63\u3002', 14, True)
    tx(0.08, 0.81, '\u5df2\u5206\u6790 6,718 \u4e2a\u57fa\u56e0\uff1b383 \u4e2a\u540d\u4e49 P\uff1c0.05\uff0cFDR\uff1c0.05 \u4e3a 0\u3002\n\u6700\u5c0f FDR = 0.216\u3002\u73b0\u6709\u7ed3\u679c\u4e0d\u80fd\u786e\u7acb\u7259\u5468\u708e\u6cbb\u7597\u9776\u70b9\u3002')
    tx(0.08, 0.73, '\u4e0e\u4f60\u8bfe\u9898\u76f4\u63a5\u76f8\u5173\u7684\u7ed3\u679c', 13, True)
    tx(0.08, 0.69, 'GDF15\uff1a\u6700\u4f4e eQTL P = 2.02e-6\uff0c\u672a\u8fbe\u5230\u539f\u6587 5e-8 \u95e8\u69db\u3002\nVDR\uff1a\u5f3a eQTL \u5b58\u5728\uff0c\u4f46\u6240\u9009 A/T \u56de\u6587 SNP \u7f3a\u66b4\u9732\u7b49\u4f4d\u57fa\u56e0\u9891\u7387\uff0c\n\u6309\u4fdd\u5b88\u7edf\u4e00\u89c4\u5219\u6392\u9664\uff0c\u6545\u672c\u8f6e\u4e3b\u5206\u6790\u4e0d\u53ef\u4f30\u8ba1\u3002\nMAPK1\uff1aOR 0.405\uff0895% CI 0.205\u20130.797\uff09\uff0cP = 0.00895\uff0c\n\u5168\u57fa\u56e0 FDR = 0.755\uff0c\u5c5e\u4e8e\u540d\u4e49\u5173\u8054\u3002\nMAPK3\uff1aOR 0.865\uff080.696\u20131.075\uff09\uff0cP = 0.192\uff0cFDR = 0.934\u3002\nPLAU\u3001AR \u4e5f\u672a\u901a\u8fc7 FDR \u6821\u6b63\u3002')
    tx(0.08, 0.48, '\u6309\u539f\u6587\u6267\u884c\u7684\u6838\u5fc3\u6b65\u9aa4', 13, True)
    tx(0.08, 0.44, 'cis-eQTL P\uff1c5e-8\uff1bPLINK r\xb2\uff1c0.001\u300110 Mb\uff1bF\u226510\uff1b\nWald ratio / IVW\uff1b\u5168\u57fa\u56e0 BH-FDR\uff1b\u53ef\u4f30\u8ba1\u65f6\u8ba1\u7b97 Q \u548c Egger\u3002\n6,718 \u4e2a\u57fa\u56e0\u5df2\u7528 TwoSampleMR \u5b98\u65b9\u51fd\u6570\u9010\u4e2a\u590d\u7b97\u4e00\u81f4\u3002')
    tx(0.08, 0.34, '\u4e0d\u80fd\u4e0e\u539f\u6587\u7b49\u540c\u7684\u90e8\u5206', 13, True)
    tx(0.08, 0.3, '\u6570\u636e\u4e3a GTEx \u57f9\u517b\u6210\u7ea4\u7ef4\u7ec6\u80de eQTL\uff0c\u5e76\u975e\u7259\u9f88\u5355\u7ec6\u80de eQTL\u3002\n\u672c\u5730 lite \u6570\u636e\u4ec5\u542b\u663e\u8457 SNP\uff0c\u4e0d\u80fd\u5b8c\u6210\u5b8c\u6574\u533a\u57df\u5171\u5b9a\u4f4d\u3002\nGLIDE \u7f13\u5b58\u672a\u8986\u76d6\u6240\u9700\u5019\u9009 SNP\uff0c\u539f\u59cb\u4e0b\u8f7d\u6587\u4ef6\u4e5f\u4e0d\u5b8c\u6574\uff1b\n\u72ec\u7acb\u590d\u73b0\u3001Steiger\u3001PheWAS \u548c\u5b89\u5168\u6027\u5206\u6790\u672a\u5b8c\u6210\u3002\n\u8fd9\u6b21\u5206\u6790\u6ca1\u6709\u68c0\u9a8c\u201c\u7ef4\u751f\u7d20D\u2192GDF15\u2192ERK\u201d\u7684\u6574\u6761\u56e0\u679c\u94fe\u3002')
    tx(0.08, 0.16, '\u56fe\u7248\u8bf4\u660e', 13, True)
    tx(0.08, 0.125, '\u540e\u9644 4 \u5f20\u56fe\uff0c\u6309\u539f\u6587\u56fe 1\u20133 \u7684\u5e03\u5c40\u3001\u914d\u8272\u53ca\u68ee\u6797\u56fe\u6837\u5f0f\u7ed8\u5236\u3002\n\u6570\u636e\u7c7b\u522b\u3001\u884c\u6570\u548c\u9634\u6027\u7ed3\u679c\u6309\u5b9e\u9645\u5206\u6790\u5448\u73b0\u3002\u63d0\u4f9b\u77e2\u91cf PDF/SVG\u3001\n600 dpi PNG\u3001\u5168\u90e8\u7ed3\u679c\u8868\u3001\u4ee3\u7801\u548c\u6838\u9a8c\u8bb0\u5f55\u3002', 10)
    tx(0.08, 0.045, '\u53c2\u8003\uff1aZhou et al. Experimental Gerontology 223 (2026), 113251.', 8, color='#666666')
    path = A / 'summary_page.pdf'
    fig.savefig(path)
    fig.savefig(A / 'summary_page_preview.png', dpi=130)
    plt.close(fig)
    return path
figure1()
figure2()
figure3()
figure4()
writer = PdfWriter()
writer.append(str(summary_page()))
for p in plots:
    writer.append(str(p))
writer.add_metadata({'/Title': 'Cultured fibroblast eQTL and periodontitis: local MR analysis', '/Author': 'Local analysis, 2026-10-20'})
report = OUT / '\u6210\u7ea4\u7ef4\u7ec6\u80deMR_\u7ed3\u679c\u4e0e\u539f\u6587\u98ce\u683c\u56fe\u8868.pdf'
with report.open('wb') as h:
    writer.write(h)
shutil.copy2(__file__, OUT / 'code' / Path(__file__).name)
print(report)
print('[FIGURES_DONE]')
