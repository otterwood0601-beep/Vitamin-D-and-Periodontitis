from pathlib import Path
import json, os, sys, gzip, shutil, subprocess, time, hashlib
from concurrent.futures import ThreadPoolExecutor, as_completed
import numpy as np
import pandas as pd
from scipy import stats
ROOT = Path('C:\\Temp\\fibro_mr_20261020')
OUT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u8f93\u51fa\\20261020_\u6210\u7ea4\u7ef4\u7ec6\u80deeQTL_MR_\u539f\u6587\u65b9\u6cd5')
for d in [OUT, OUT / 'tables', OUT / 'figures', OUT / 'code', OUT / 'audit', ROOT / 'clumps']:
    d.mkdir(parents=True, exist_ok=True)
LD = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u539f\u59cb\u6570\u636e\\03_xQTL\u4e0e\u53c2\u8003\u9762\u677f\\1000G_EUR\\g1000_eur')
CACHE = Path('E:\\\u767d\u8272\u5ff5\u73e0\u83cc\\Agent\u6587\u4ef6\u5939\\\u8fd0\u884c\u73af\u5883\u4e0e\u5de5\u4f5c\u533a\\\u4e34\u65f6\u5de5\u4f5c\u533a\\_codex_tmp\\smr_recalc_all_20260924\\inputs\\gwas')
CANDIDATES = ['VDR', 'PLAU', 'TG', 'MYC', 'BTF3P11', 'PHEX', 'GDF15', 'CYP24A1', 'AR', 'GMNN', 'IL2', 'MAPK1', 'MAPK3']

def save(df, name):
    df.to_csv(OUT / 'tables' / name, index=False, encoding='utf-8-sig')

def bh(p):
    p = np.asarray(p, float)
    n = len(p)
    order = np.argsort(p)
    a = np.minimum.accumulate((p[order] * n / np.arange(1, n + 1))[::-1])[::-1]
    out = np.empty(n)
    out[order] = np.minimum(a, 1)
    return out

def prepare():
    df = pd.read_csv(ROOT / 'strong.txt', sep='\\s+', dtype={'Chr': str, 'Probe_Chr': str})
    total = len(df)
    df = df[(df.p < 5e-08) & (df.SE > 0) & df.b.notna()].copy()
    df['F'] = (df.b / df.SE) ** 2
    df = df[df.F >= 10]
    df = df[df.Chr.eq(df.Probe_Chr)]
    df.Chr = df.Chr.replace({'X': '23'})
    df.Probe_Chr = df.Probe_Chr.replace({'X': '23'})
    df = df[df.Chr.isin([str(i) for i in range(1, 24)])]
    want = set(df.SNP)
    found = {}
    n_bim = 0
    with Path(str(LD) + '.bim').open() as f:
        for i, line in enumerate(f):
            a = line.split()
            n_bim += 1
            if a[1] in want:
                found[a[1]] = (i, a, line)
    df['ld_index'] = df.SNP.map({k: v[0] for k, v in found.items()})
    missing = df[df.ld_index.isna()].copy()
    save(missing, 'excluded_absent_LD.csv')
    df = df[df.ld_index.notna()].copy()
    df.ld_index = df.ld_index.astype(int)
    df['ld_match'] = [str(found[s][1][0]) == c and int(found[s][1][3]) == bp and ({a, b} == set(found[s][1][4:6])) for s, c, bp, a, b in zip(df.SNP, df.Chr, df.BP, df.A1, df.A2)]
    save(df[~df.ld_match], 'excluded_LD_position_alleles.csv')
    df = df[df.ld_match].copy()
    nsamp = sum((1 for _ in Path(str(LD) + '.fam').open()))
    stride = (nsamp + 3) // 4
    with Path(str(LD) + '.bed').open('rb') as f:
        assert f.read(3) == b'l\x1b\x01'
    assert Path(str(LD) + '.bed').stat().st_size == 3 + stride * n_bim
    bed = np.memmap(Path(str(LD) + '.bed'), dtype='uint8', offset=3, mode='r', shape=(n_bim, stride))
    fam = Path(str(LD) + '.fam').read_bytes()
    groups = list(df.groupby('Probe', sort=True))

    def one(item):
        probe, g = item
        d = ROOT / 'clumps' / probe
        d.mkdir(exist_ok=True)
        g = g.sort_values('ld_index')
        prefix = d / 'ref'
        if not (d / 'complete.json').exists():
            Path(str(prefix) + '.fam').write_bytes(fam)
            Path(str(prefix) + '.bim').write_text(''.join((found[s][2] for s in g.SNP)), encoding='ascii')
            with Path(str(prefix) + '.bed').open('wb') as h:
                h.write(b'l\x1b\x01')
                h.write(bed[g.ld_index.to_numpy()].tobytes())
            g[['SNP', 'p']].rename(columns={'p': 'P'}).to_csv(d / 'association.tsv', sep='\t', index=False)
            cmd = [str(ROOT / 'plink.exe'), '--bfile', str(prefix), '--clump', str(d / 'association.tsv'), '--clump-p1', '5e-8', '--clump-p2', '5e-8', '--clump-r2', '0.001', '--clump-kb', '10000', '--threads', '1', '--memory', '256', '--out', str(d / 'result')]
            try:
                r = subprocess.run(cmd, capture_output=True, timeout=120)
            except subprocess.TimeoutExpired:
                log = (d / 'result.log').read_text() if (d / 'result.log').exists() else ''
                if 'End time:' not in log or not (d / 'result.clumped').exists():
                    raise
                r = subprocess.CompletedProcess(cmd, 0, b'Recovered completed output after process-exit timeout', b'')
            (d / 'console.log').write_bytes(r.stdout + r.stderr)
            if r.returncode:
                raise RuntimeError(f'PLINK failed {probe}: {r.stdout[-500:]}')
            cl = pd.read_csv(d / 'result.clumped', sep='\\s+')
            keep = cl.SNP.tolist()
            (d / 'complete.json').write_text(json.dumps({'probe': probe, 'snps': keep, 'command': cmd}), encoding='utf8')
            for ext in ['.bed', '.bim', '.fam']:
                p = Path(str(prefix) + ext)
                assert p.parent.parent == ROOT / 'clumps'
                p.unlink()
        else:
            keep = json.loads((d / 'complete.json').read_text())['snps']
        return g[g.SNP.isin(keep)].copy()
    results = []
    with ThreadPoolExecutor(max_workers=6) as pool:
        fs = [pool.submit(one, g) for g in groups]
        for i, f in enumerate(as_completed(fs), 1):
            results.append(f.result())
            if i % 500 == 0:
                print(f'CLUMP {i}/{len(groups)}', flush=True)
    iv = pd.concat(results, ignore_index=True).sort_values(['Probe', 'p', 'SNP'])
    save(iv, '01_clumped_instruments.csv')
    per = df.groupby(['Probe', 'Gene']).agg(n_strong=('SNP', 'size')).reset_index()
    n = iv.groupby('Probe').size()
    per['n_independent'] = per.Probe.map(n).fillna(0).astype(int)
    save(per, '01_gene_instrument_counts.csv')
    audit = {'input_genes_lite': 11463, 'strong_query_rows': total, 'strong_genes_query': int(pd.read_csv(ROOT / 'strong.txt', sep='\t', usecols=['Probe']).Probe.nunique()), 'LD_reference_samples': nsamp, 'LD_reference_variants': n_bim, 'eligible_gene_pairs_before_clump': len(df), 'eligible_genes_before_clump': df.Probe.nunique(), 'clumped_instruments': len(iv), 'genes_after_clump': iv.Probe.nunique(), 'absent_LD_pairs': len(missing), 'plink_version': '1.9.0-b.7.7', 'p_eqtl': 5e-08, 'r2': 0.001, 'clump_kb': 10000, 'F_min': 10}
    (OUT / 'audit' / 'selection.json').write_text(json.dumps(audit, indent=2), encoding='utf8')
    return iv

def extract_finngen(iv):
    dest = OUT / 'tables' / '02_finngen_extracted.csv'
    key = hashlib.sha256('\n'.join(sorted(set(iv.SNP))).encode()).hexdigest()
    keyfile = OUT / 'audit' / 'finngen_extraction_key.txt'
    if dest.exists() and keyfile.exists() and (keyfile.read_text() == key):
        return pd.read_csv(dest, dtype={'chr': str})
    mr = next(Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u5f52\u6863').glob('*MR'))
    p = next(mr.glob('GWAS/\u7259\u5468\u75c5 GWAS/finn-b-K11_PERIODON_CHRON/*.vcf.gz'))
    want = set(iv.SNP)
    rows = []
    n = 0
    header = []
    with gzip.open(p, 'rt') as f:
        for line in f:
            if line.startswith('#'):
                header.append(line.rstrip())
                continue
            n += 1
            a = line.rstrip().split('\t')
            if a[2] not in want:
                continue
            val = dict(zip(a[8].split(':'), a[9].split(':')))
            rows.append(dict(SNP=a[2], chr=a[0].replace('X', '23'), bp=int(a[1]), ea=a[4], oa=a[3], beta=float(val['ES']), se=float(val['SE']), p=10 ** (-float(val['LP'])), freq=float(val.get('AF', 'nan')), n=198441, ncase=3046, ncontrol=195395))
            if len(rows) % 2000 == 0:
                print('FINNGEN matched', len(rows), flush=True)
    out = pd.DataFrame(rows)
    save(out, '02_finngen_extracted.csv')
    keyfile.write_text(key)
    (OUT / 'audit' / 'finngen_header.txt').write_text('\n'.join(header), encoding='utf8')
    (OUT / 'audit' / 'finngen_scan.json').write_text(json.dumps({'source': str(p), 'total_variants': n, 'matched_rows': len(rows)}, indent=2), encoding='utf8')
    return out

def read_cache(name):
    d = pd.read_csv(CACHE / (name + '.ma'), sep='\t')
    d = d.rename(columns={'A1': 'ea', 'A2': 'oa', 'b': 'beta'})
    return d

def read_partial_glide(iv):
    mr = next(Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u5f52\u6863').glob('*MR'))
    p = next(mr.glob('GWAS\u5ba1\u8ba1/_20260830/Manousaki2020_\u7eafGLIDE\u7259\u5468\u708e_\u53cc\u5411_20260913/source/EUR_perio_incl_HCHSSOL.txt'))
    target = {(str(c), int(bp)): s for c, bp, s in zip(iv.Chr, iv.BP, iv.SNP)}
    cache = OUT / 'tables' / '02_GLIDE_partial_target_rows.csv'
    if cache.exists():
        return pd.read_csv(cache, dtype={'chr': str})
    rows = []
    valid = bad = zero = 0
    last_terminated = True
    with p.open('rb') as h:
        header = h.readline().decode().split()
        for raw in h:
            last_terminated = raw.endswith(b'\n')
            if b'\x00' in raw:
                zero += raw.count(b'\x00')
                bad += 1
                continue
            a = raw.split()
            if len(a) != len(header):
                bad += 1
                continue
            try:
                chrom, pos, *_ = a[0].decode().split(':')
                bp = int(pos)
                beta, se, pv = (float(a[3]), float(a[4]), float(a[5]))
                if not np.isfinite(beta) or not np.isfinite(se) or se <= 0 or (not 0 <= pv <= 1):
                    bad += 1
                    continue
                valid += 1
                if (chrom, bp) not in target:
                    continue
                ea, oa = (a[1].decode().upper(), a[2].decode().upper())
                if ea not in 'ACGT' or oa not in 'ACGT':
                    continue
                rows.append(dict(SNP=target[chrom, bp], chr=chrom, bp=bp, ea=ea, oa=oa, beta=beta, se=se, p=pv, freq=np.nan, n=float(a[11]), ncase=float(a[12]), ncontrol=float(a[13])))
            except (ValueError, IndexError):
                bad += 1
    d = pd.DataFrame(rows, columns=['SNP', 'chr', 'bp', 'ea', 'oa', 'beta', 'se', 'p', 'freq', 'n', 'ncase', 'ncontrol'])
    save(d, '02_GLIDE_partial_target_rows.csv')
    (OUT / 'audit' / 'partial_GLIDE_audit.json').write_text(json.dumps({'source': str(p), 'aria2_sidecar_present': Path(str(p) + '.aria2').exists(), 'valid_rows': valid, 'invalid_rows': bad, 'NUL_bytes': zero, 'last_line_terminated': last_terminated, 'matched_target_rows': len(d), 'requested_unique_targets': len(target), 'interpretation': 'Incomplete local source. Intact matched rows used only for exploratory clinical periodontitis follow-up; HCHS/SOL included, so ancestry equivalence is not asserted.'}, indent=2), encoding='utf8')
    return d

def harmonize(iv, gwas, outcome):
    dup = gwas[gwas.SNP.duplicated(False)]
    if len(dup):
        save(dup, f'duplicate_outcome_{outcome}.csv')
        gwas = gwas[~gwas.SNP.isin(dup.SNP)]
    a = iv.merge(gwas, on='SNP', how='left', suffixes=('_exp', '_out'))
    for col in ['beta', 'se', 'freq', 'bp']:
        if col in a:
            a[col] = pd.to_numeric(a[col], errors='coerce')
    a['status'] = 'ok'
    a.loc[a.beta.isna(), 'status'] = 'missing_outcome'
    a.loc[(a.status == 'ok') & (~np.isfinite(a.se) | (a.se <= 0)), 'status'] = 'invalid_outcome_SE'
    pal = [{x, y} in [{'A', 'T'}, {'C', 'G'}] for x, y in zip(a.A1, a.A2)]
    a.loc[(a.status == 'ok') & np.array(pal), 'status'] = 'palindromic_no_exposure_frequency'
    comp = {'A': 'T', 'T': 'A', 'G': 'C', 'C': 'G'}
    signs = []
    for x, y, ea, oa in zip(a.A1, a.A2, a.ea, a.oa):
        if (x, y) == (ea, oa):
            sg = 1
        elif (x, y) == (oa, ea):
            sg = -1
        elif (comp.get(x), comp.get(y)) == (ea, oa):
            sg = 1
        elif (comp.get(x), comp.get(y)) == (oa, ea):
            sg = -1
        else:
            sg = np.nan
        signs.append(sg)
    a['sign'] = signs
    a.loc[(a.status == 'ok') & a.sign.isna(), 'status'] = 'allele_mismatch'
    if 'chr' in a:
        bad = (a.Chr.astype(str) != a.chr.astype(str)) | (a.BP != a.bp)
        a.loc[(a.status == 'ok') & bad, 'status'] = 'coordinate_mismatch'
    a['by_aligned'] = a.beta * a.sign
    save(a, f'03_harmonization_{outcome}.csv')
    return (a[a.status == 'ok'].copy(), a)

def mr_est(g):
    x = g.b.to_numpy(float)
    y = g.by_aligned.to_numpy(float)
    sy = g.se.to_numpy(float)
    n = len(g)
    den = np.sum(x * x / sy ** 2)
    b = np.sum(x * y / sy ** 2) / den
    q = np.sum((y - b * x) ** 2 / sy ** 2)
    se = (max(1, q / (n - 1)) / den) ** 0.5 if n > 1 else (1 / den) ** 0.5
    p = 2 * stats.norm.sf(abs(b / se))
    pcol = 'p_exp' if 'p_exp' in g else 'p'
    row = {'Probe': g.Probe.iloc[0], 'Gene': g.Gene.iloc[0], 'Chr': g.Chr.iloc[0], 'lead_BP': int(g.sort_values(pcol).BP.iloc[0]), 'lead_SNP': g.sort_values(pcol).SNP.iloc[0], 'nsnp': n, 'method': 'Wald ratio' if n == 1 else 'IVW', 'beta': b, 'se': se, 'p_MR': p, 'OR': np.exp(b), 'OR_lower': np.exp(b - 1.95996398454 * se), 'OR_upper': np.exp(b + 1.95996398454 * se), 'Q': q if n > 1 else np.nan, 'Q_df': n - 1 if n > 1 else np.nan, 'Q_p': stats.chi2.sf(q, n - 1) if n > 1 else np.nan, 'F_min': g.F.min(), 'instruments': ';'.join(g.SNP)}
    if n >= 3 and np.ptp(abs(x)) > 0:
        yy = y * np.sign(x)
        xx = abs(x)
        w = 1 / sy ** 2
        X = np.column_stack([np.ones(n), xx])
        cov = np.linalg.inv(X.T @ (w[:, None] * X))
        co = cov @ (X.T @ (w * yy))
        qe = np.sum(w * (yy - X @ co) ** 2)
        ese = np.sqrt(np.diag(cov) * max(1, qe / (n - 2)))
        row.update(egger_intercept=co[0], egger_intercept_se=ese[0], egger_intercept_p=2 * stats.t.sf(abs(co[0] / ese[0]), n - 2), egger_beta=co[1], egger_se=ese[1], egger_p=2 * stats.t.sf(abs(co[1] / ese[1]), n - 2))
    return row

def analyse():
    path = OUT / 'tables' / '01_clumped_instruments.csv'
    iv = pd.read_csv(path, dtype={'Chr': str, 'Probe_Chr': str}) if path.exists() and '--rebuild' not in sys.argv else prepare()
    gwas = extract_finngen(iv)
    h, a = harmonize(iv, gwas, 'FinnGen_chronic')
    res = pd.DataFrame([mr_est(g) for _, g in h.groupby('Probe')])
    res['FDR'] = bh(res.p_MR)
    res['prespecified11'] = res.Gene.isin(CANDIDATES[:11])
    res['pathway_MAPK'] = res.Gene.isin(CANDIDATES[11:])
    res = res.sort_values('p_MR')
    save(res, '04_discovery_all_genes.csv')
    save(res[res.FDR < 0.05], '04_discovery_FDR_significant.csv')
    cand = []
    epi = pd.read_csv(ROOT / 'fibro.epi', sep='\t', header=None, names=['chr', 'Probe', 'gd', 'pos', 'Gene', 'strand'])
    q = pd.read_csv(ROOT / 'strong.txt', sep='\t')
    for gene in CANDIDATES:
        r = res[res.Gene == gene]
        entry = {'Gene': gene, 'candidate_group': 'Original 11 candidates' if gene in CANDIDATES[:11] else 'ERK pathway', 'in_lite_panel': bool((epi.Gene == gene).any()), 'n_strong': int((q.Gene == gene).sum()), 'n_clumped': int((iv.Gene == gene).sum()), 'n_harmonized': int((h.Gene == gene).sum())}
        if len(r):
            entry.update(r.iloc[0].to_dict())
            entry['reason'] = 'estimated'
        elif not entry['in_lite_panel']:
            entry['reason'] = 'not_in_local_lite_panel'
        elif not entry['n_strong']:
            entry['reason'] = 'no_eQTL_P_below_5e-8'
        elif not entry['n_clumped']:
            entry['reason'] = 'no_eligible_LD_reference_instrument'
        else:
            entry['reason'] = 'all_instruments_excluded_in_harmonization'
        cand.append(entry)
    save(pd.DataFrame(cand), '05_prespecified_candidates.csv')
    sig = set(res.loc[res.FDR < 0.05, 'Probe'])
    target = set(iv.loc[iv.Gene.isin(CANDIDATES), 'Probe']) | sig
    outcome_names = ['GLIDE_EUR_periodontitis_excl_HCHSSOL', 'GLIDE_EUR_periodontitis_incl_HCHSSOL', 'GLIDE_EAA_periodontitis', 'OGWAS_FinnGen_acute_periodontitis', 'OGWAS_UKB_Neale_bleeding_gums', 'OGWAS_UKB_Neale_painful_gums', 'UKB_EUR_loose_teeth']
    rows = []
    coverage = []
    hv = h[h.Probe.isin(target)].copy()
    keys = set(zip(hv.Probe, hv.SNP))
    ti = iv[[(p, s) in keys for p, s in zip(iv.Probe, iv.SNP)]]
    for name in outcome_names:
        gg = read_cache(name)
        hh, aa = harmonize(ti, gg, name)
        for probe, g in ti.groupby('Probe'):
            used = hh[hh.Probe == probe]
            record = {'outcome': name, 'Probe': probe, 'Gene': g.Gene.iloc[0], 'required_nsnp': len(g), 'available_nsnp': len(used), 'complete_instrument_set': len(g) == len(used), 'discovery_FDR_significant': probe in sig}
            coverage.append(record)
            if len(used):
                r = mr_est(used)
                r.update(record)
                r['same_direction'] = np.sign(r['beta']) == np.sign(res.set_index('Probe').loc[probe, 'beta'])
                rows.append(r)
    name = 'GLIDE_clinical_incl_HCHSSOL_partial_source'
    gg = read_partial_glide(ti)
    hh, aa = harmonize(ti, gg, name)
    for probe, g in ti.groupby('Probe'):
        used = hh[hh.Probe == probe]
        record = {'outcome': name, 'Probe': probe, 'Gene': g.Gene.iloc[0], 'required_nsnp': len(g), 'available_nsnp': len(used), 'complete_instrument_set': len(g) == len(used), 'discovery_FDR_significant': probe in sig}
        coverage.append(record)
        if len(used):
            r = mr_est(used)
            r.update(record)
            r['same_direction'] = np.sign(r['beta']) == np.sign(res.set_index('Probe').loc[probe, 'beta'])
            rows.append(r)
    follow = pd.DataFrame(rows)
    if follow.empty:
        follow = pd.DataFrame(columns=['outcome', 'Probe', 'Gene', 'p_MR', 'complete_instrument_set', 'discovery_FDR_significant', 'same_direction'])
    follow['FDR_replication'] = np.nan
    mask = (follow.outcome == 'GLIDE_EUR_periodontitis_excl_HCHSSOL') & follow.discovery_FDR_significant
    n_sig = len(sig)
    if n_sig:
        vals = []
        for p in sorted(sig):
            z = follow[mask & (follow.Probe == p) & follow.complete_instrument_set]
            vals.append(float(z.p_MR.iloc[0]) if len(z) else 1.0)
        fdr = dict(zip(sorted(sig), bh(vals)))
        follow.loc[mask, 'FDR_replication'] = follow.loc[mask, 'Probe'].map(fdr)
    save(follow, '06_local_followup_outcomes.csv')
    save(pd.DataFrame(coverage), '06_followup_coverage.csv')
    summary = {'tested_genes': len(res), 'discovery_FDR_significant': len(sig), 'nominal_P_lt_005': int((res.p_MR < 0.05).sum()), 'retained_instruments_discovery': len(h), 'replicated': int(((follow.FDR_replication < 0.05) & follow.same_direction & follow.complete_instrument_set).sum()), 'harmonization_status_pairs': a.status.value_counts().to_dict(), 'colocalization': 'NOT_ESTIMABLE: local GTEx V8 lite retains only SNPs P<1e-5; complete regional statistics absent', 'steiger': 'NOT_RUN: exposure frequency and sample-size metadata absent in local BESD; no imputed directionality result', 'phenome_safety': 'NOT_RUN: no complete local GeneAtlas/FinnGen-PheWAS/AZ rare-variant input', 'source_type': 'GTEx V8 cultured fibroblast eQTL; not gingival single-cell eQTL', 'effect_scale': 'per unit of the expression phenotype used by source eQTL; no independently verified SD rescaling'}
    (OUT / 'audit' / 'results_summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding='utf8')
    print(json.dumps(summary, indent=2, ensure_ascii=False), flush=True)
    print(pd.DataFrame(cand)[['Gene', 'n_strong', 'n_clumped', 'n_harmonized', 'reason']].to_string(index=False), flush=True)
if __name__ == '__main__':
    analyse()
    shutil.copy2(__file__, OUT / 'code' / Path(__file__).name)
    print('[DONE]', flush=True)
