source("C:/Temp/fibro_mr_20261020/TwoSampleMR_mr.R")
d <- read.csv("C:/Temp/fibro_mr_20261020/harmonized_for_R.csv", check.names=FALSE)
d <- d[d$status == "ok", ]
ans <- lapply(split(d,d$Probe), function(z) {
  f <- if(nrow(z)==1) mr_wald_ratio else mr_ivw
  a <- f(z$b,z$by_aligned,z$SE,z$se,default_parameters())
  e <- if(nrow(z)>=3) mr_egger_regression(z$b,z$by_aligned,z$SE,z$se,default_parameters()) else NULL
  data.frame(Probe=z$Probe[1],beta_R=a$b,se_R=a$se,p_R=a$pval,
             Q_R=if(is.null(a$Q)) NA_real_ else a$Q,
             egger_intercept_R=if(is.null(e)) NA_real_ else e$b_i,
             egger_intercept_p_R=if(is.null(e)) NA_real_ else e$pval_i)
})
x <- do.call(rbind,ans)
x$FDR_R <- p.adjust(x$p_R,method="BH")
write.csv(x,"C:/Temp/fibro_mr_20261020/TwoSampleMR_independent_check.csv",row.names=FALSE)
cat("Verified",nrow(x),"genes with the pinned TwoSampleMR source functions.\n")
