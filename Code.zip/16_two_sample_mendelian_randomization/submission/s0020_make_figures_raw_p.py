from pathlib import Path
import json, math, textwrap, shutil, hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib.backends.backend_pdf import PdfPages
from pypdf import PdfReader, PdfWriter
OUT = Path(__file__).resolve().parents[1]
SOURCE = OUT.parent
F = OUT / 'figures'
A = OUT / 'audit'
T = OUT / 'tables'
for d in [F, A, T]:
    d.mkdir(parents=True, exist_ok=True)
res = pd.read_csv(SOURCE / 'tables/04_discovery_all_genes.csv').sort_values(['p_MR', 'Probe'])
cand = pd.read_csv(SOURCE / 'tables/05_prespecified_candidates.csv')
sig = res[res.p_MR < 0.05].copy()
assert len(res) == 6718 and len(sig) == 383
assert sum(res.p_MR < 0.01) == 83
sig['rank_raw_p'] = np.arange(1, len(sig) + 1)
sig.to_csv(T / 'RawP_lt_0.05_all_383_genes.csv', index=False, encoding='utf-8-sig')
cand.to_csv(T / 'RawP_candidate_genes.csv', index=False, encoding='utf-8-sig')
plt.rcParams.update({'font.family': 'Arial', 'font.size': 11, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none', 'axes.linewidth': 1, 'savefig.facecolor': 'white', 'axes.spines.top': False, 'axes.spines.right': False})
BLUE = '#e9f1f4'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
originals = {str(p.relative_to(SOURCE)): sha(p) for p in (SOURCE / 'figures').glob('*')}
originals['\u6210\u7ea4\u7ef4\u7ec6\u80deMR_\u7ed3\u679c\u4e0e\u539f\u6587\u98ce\u683c\u56fe\u8868.pdf'] = sha(SOURCE / '\u6210\u7ea4\u7ef4\u7ec6\u80deMR_\u7ed3\u679c\u4e0e\u539f\u6587\u98ce\u683c\u56fe\u8868.pdf')

def note(fig, y, text, width=145, size=9):
    fig.text(0.035, y, textwrap.fill(text, width=width, break_long_words=False, break_on_hyphens=False), ha='left', va='top', fontsize=size, fontfamily='Times New Roman', linespacing=1.3)

def forest(ax, df, heading, fs=11):
    n = len(df)
    ax.set_xlim(0, 1)
    ax.set_ylim(n + 2, 0)
    ax.axis('off')
    cols = [0.018, 0.195, 0.305, 0.415, 0.51, 0.873]
    headers = ['Cell type', 'eGene', 'Method', 'Raw P', 'nSNP', 'OR (95% CI)']
    for x, s in zip(cols, headers):
        ax.text(x, 0.53, s, fontfamily='Times New Roman', weight='bold', fontsize=fs + 1, ha='left' if x == cols[0] else 'center', va='center')
    ax.text(0.018, 1.51, heading, fontfamily='Times New Roman', weight='bold', fontsize=fs + 1, va='center')
    for y in [0, 1.05, 2, n + 2]:
        ax.plot([0, 1], [y, y], color='black', lw=0.9, clip_on=False)
    for x in [0, 1]:
        ax.plot([x, x], [0, n + 2], color='black', lw=0.9, clip_on=False)
    valid = df[df.OR.notna()]
    lo = min(0.75, float(valid.OR_lower.min()) * 0.92)
    hi = max(1.25, float(valid.OR_upper.max()) * 1.04)
    left, right = (0.565, 0.756)
    trans = lambda z: left + (z - lo) / (hi - lo) * (right - left)
    ax.plot([trans(1)] * 2, [2, n + 2], ls=(0, (5, 4)), color='black', lw=0.8, zorder=1)
    for i, (_, r) in enumerate(df.iterrows()):
        y = i + 2.5
        if i % 2 == 0:
            ax.add_patch(Rectangle((0.001, i + 2), 0.998, 1, color=BLUE, zorder=0))
        ok = pd.notna(r.get('OR', np.nan))
        ax.text(cols[0], y, 'Fibroblast', fontsize=fs, fontfamily='Times New Roman', va='center')
        gene_fs = min(fs, fs * 12 / max(12, len(r.Gene)))
        ax.text(cols[1], y, r.Gene, fontsize=gene_fs, fontfamily='Times New Roman', ha='center', va='center')
        vals = [r.get('method', '-') if ok else '-', f'{r.p_MR:.3g}' if ok else '-', str(int(r.nsnp)) if ok else '-']
        for x, s in zip(cols[2:5], vals):
            ax.text(x, y, s, fontsize=fs - 0.2, fontfamily='Times New Roman', ha='center', va='center')
        if ok:
            ax.plot([trans(r.OR_lower), trans(r.OR_upper)], [y, y], color='black', lw=1.5, zorder=3)
            for x in [trans(r.OR_lower), trans(r.OR_upper)]:
                ax.plot([x, x], [y - 0.16, y + 0.16], color='black', lw=1.5, zorder=3)
            ax.plot(trans(r.OR), y, marker='D', markersize=5, color='black', zorder=4)
            ci = f'{r.OR:.4f} ({r.OR_lower:.4f}, {r.OR_upper:.4f})'
        else:
            code = {'not_in_local_lite_panel': '1', 'no_eQTL_P_below_5e-8': '2', 'all_instruments_excluded_in_harmonization': '3'}.get(r.get('reason'), '4')
            ci = f'Not estimable [{code}]'
        ax.text(cols[-1], y, ci, fontsize=fs - 0.2, fontfamily='Times New Roman', ha='center', va='center')
    return {'linear_OR_min': lo, 'linear_OR_max': hi}

def export(fig, name, pdf=True):
    if pdf:
        fig.savefig(A / f'{name}.pdf', bbox_inches='tight', pad_inches=0.12)
    fig.savefig(F / f'{name}.svg', bbox_inches='tight', pad_inches=0.12)
    fig.savefig(F / f'{name}.png', dpi=600, bbox_inches='tight', pad_inches=0.12)
    fig.savefig(A / f'{name}_preview.png', dpi=100, bbox_inches='tight', pad_inches=0.12)

def figure2():
    fig = plt.figure(figsize=(11.8, 9.3))
    fig.text(0.025, 0.965, 'A', fontsize=20, weight='bold')
    ax = fig.add_axes([0.09, 0.565, 0.88, 0.36])
    palette = ['#528ec6', '#f7a21c', '#8bbb35', '#6950a2', '#73c3b5', '#c0dd93', '#e11e23', '#eeea10', '#527d38', '#9c5faa', '#5bc5ed', '#ffd126', '#f99021', '#ef5041', '#5d56aa', '#58ae4e', '#9c75bb', '#645cab', '#ef3264', '#74c6e9', '#fdd22a', '#71b75f', '#8a8a8a']
    starts = {}
    ticks = []
    x = 0
    for c in range(1, 24):
        d = res[res.Chr.astype(str) == str(c)]
        size = max(float(d.lead_BP.max()) if len(d) else 0, 50000000.0)
        starts[c] = x
        if len(d):
            ax.scatter(x + d.lead_BP, -np.log10(d.p_MR), s=9, color=palette[c - 1], alpha=0.85, lw=0)
        ticks.append(x + size / 2)
        x += size + 12000000.0
    ax.axhline(-np.log10(0.05), color='#777777', ls=(0, (5, 5)), lw=1)
    ax.set_xlim(0, x)
    ax.set_ylim(0, 5)
    ax.set_xticks(ticks, [str(c) if c < 23 else 'X' for c in range(1, 24)])
    ax.tick_params(axis='x', labelsize=9, pad=2)
    ax.set_xlabel('Chr', weight='bold')
    ax.set_ylabel('$-\\log_{10}(\\mathrm{Raw}\\ P)$', fontsize=11)
    ax.text(x * 0.993, -np.log10(0.05) + 0.07, 'Raw P = 0.05', ha='right', fontsize=9, color='#555555')
    placements = {'MIPOL1': (0.73, 4.64), 'SLC25A21': (0.57, 4.36), 'RP11-132E11.2': (0.43, 4.1), 'LINC00346': (0.6, 3.76), 'ALPL': (0.1, 3.8), 'MAPK1': (0.88, 2.9)}
    for gene, (tx, ty) in placements.items():
        r = res[res.Gene == gene].iloc[0]
        xp = starts[int(r.Chr)] + r.lead_BP
        yp = -np.log10(r.p_MR)
        ax.annotate(gene, xy=(xp, yp), xytext=(x * tx, ty), fontsize=8, ha='center', bbox={'boxstyle': 'square,pad=.18', 'facecolor': 'white', 'edgecolor': '#777777', 'linewidth': 0.5}, arrowprops={'arrowstyle': '->', 'color': '#333333', 'lw': 0.7})
    fig.text(0.025, 0.485, 'B', fontsize=20, weight='bold')
    a = fig.add_axes([0.035, 0.115, 0.93, 0.365])
    forest(a, sig.head(10), 'Chronic periodontitis: 10 smallest raw P values among 383 nominal associations')
    note(fig, 0.08, 'Fig. 2. Unadjusted discovery MR. A: all 6,718 eGenes; the dashed line denotes raw P = 0.05. The five smallest-P genes and MAPK1 are labelled. B: the ten smallest raw P values are shown for readability; all 383 nominal associations are included in the companion paginated forest plots. Raw P values are not corrected for multiple testing.', 155)
    export(fig, 'Figure_2_RawP_discovery')
    plt.close(fig)

def figure3():
    fig = plt.figure(figsize=(11.8, 6.3))
    ax = fig.add_axes([0.03, 0.225, 0.94, 0.72])
    forest(ax, cand, 'Chronic periodontitis (FinnGen): candidate genes, unadjusted MR P values')
    note(fig, 0.18, 'Fig. 3. Candidate-gene MR using raw P values. MAPK1 is the only nominally associated gene (P < 0.05) among the 13 displayed candidates. Diamonds denote odds ratios with 95% confidence intervals; the dashed line denotes OR = 1. nSNP is the number of harmonized instrumental variants. This is an exploratory, unadjusted display.', 150)
    note(fig, 0.105, '[1] Gene absent from the local lite panel. [2] No cis-eQTL passed the unchanged instrument threshold P < 5e-8 (GDF15 minimum P = 2.02e-6). [3] The VDR A/T instrument lacked exposure allele frequency and was excluded. Estimates are per source-expression unit; AR is on chromosome X. These are cultured-fibroblast eQTLs, not gingival single-cell eQTLs.', 150)
    export(fig, 'Figure_3_RawP_candidate_genes')
    plt.close(fig)

def full_forest():
    pages = []
    size = 22
    path = OUT / 'RawP_383\u4e2a\u540d\u4e49\u5173\u8054\u57fa\u56e0_\u5b8c\u6574\u68ee\u6797\u56fe.pdf'
    with PdfPages(path) as pdf:
        for k, start in enumerate(range(0, len(sig), size), 1):
            sub = sig.iloc[start:start + size]
            height = max(4.8, (len(sub) + 2) * 0.24 + 1.25)
            fig = plt.figure(figsize=(11.8, height))
            fig.text(0.03, 0.965, f'Unadjusted MR | raw P < 0.05 | page {k}/{math.ceil(len(sig) / size)}', fontsize=11, weight='bold', va='top')
            ax = fig.add_axes([0.03, 0.17, 0.94, 0.745])
            limits = forest(ax, sub, f'Chronic periodontitis (FinnGen): ranks {start + 1}-{start + len(sub)} of 383', fs=10.8)
            note(fig, 0.125, 'Cultured-fibroblast eQTL MR. Results are ordered by increasing raw P; values are unadjusted for multiple testing. Diamonds and whiskers denote OR and 95% CI. The dashed line is OR = 1. Each page uses its own linear OR range; compare effect sizes using the printed estimates. These are nominal associations, not independently validated causal targets.', 150)
            pdf.savefig(fig, bbox_inches='tight', pad_inches=0.12)
            export(fig, f'Figure_4_RawP_all_genes_page_{k:02}', pdf=False)
            plt.close(fig)
            pages.append({'page': k, 'n_genes': len(sub), 'first_rank': start + 1, 'last_rank': start + len(sub), 'probes': sub.Probe.tolist(), **limits})
            print(f'FOREST {k}/{math.ceil(len(sig) / size)}', flush=True)
    return (path, pages)

def summary_page():
    fig = plt.figure(figsize=(8.27, 11.69))

    def tx(y, s, size=11, bold=False, color='#222222'):
        fig.text(0.08, y, s, fontfamily='Microsoft YaHei', fontsize=size, weight='bold' if bold else 'normal', color=color, va='top', linespacing=1.65)
    tx(0.95, '\u6210\u7ea4\u7ef4\u7ec6\u80de eQTL \u2192 \u7259\u5468\u708e MR', 19, True)
    tx(0.91, 'Raw P \u56fe\u7248\uff5c\u672a\u6821\u6b63 P \u503c\u5c55\u793a', 12, color='#555555')
    tx(0.85, '6,718 \u4e2a\u57fa\u56e0\u4e2d\uff0c383 \u4e2a Raw P\uff1c0.05\u3002', 14, True)
    tx(0.8, '\u5176\u4e2d 83 \u4e2a Raw P\uff1c0.01\u3002\u66fc\u54c8\u987f\u56fe\u6539\u4e3a -log10(Raw P)\uff0c\n\u9608\u503c\u7ebf\u8bbe\u4e3a P\uff1d0.05\uff1b\u68ee\u6797\u56fe\u5217\u51fa Raw P \u548c\u5de5\u5177 SNP \u6570\u3002')
    tx(0.72, '\u4e0e\u4f60\u8bfe\u9898\u76f8\u5173\u7684\u7ed3\u679c', 13, True)
    tx(0.68, 'MAPK1\uff1aOR 0.405\uff0895% CI 0.205-0.797\uff09\uff0cP\uff1d0.00895\u3002\n\u5728\u65e2\u5b9a 11 \u57fa\u56e0\u52a0 MAPK1/MAPK3 \u4e2d\uff0c\u4ec5 MAPK1 \u8fbe\u5230\u540d\u4e49\u663e\u8457\u3002\nMAPK3\uff1aP\uff1d0.192\uff1bPLAU\uff1aP\uff1d0.542\uff1bAR\uff1aP\uff1d0.380\u3002\nGDF15\uff1a\u6ca1\u6709\u8fbe\u5230 eQTL P\uff1c5e-8 \u95e8\u69db\u7684\u5de5\u5177\u53d8\u91cf\u3002\nVDR\uff1a\u6240\u9009\u56de\u6587 SNP \u7f3a\u5c11\u66b4\u9732\u9891\u7387\uff0c\u672c\u8f6e\u4e3b\u5206\u6790\u4e0d\u53ef\u4f30\u8ba1\u3002')
    tx(0.51, '\u672c\u6b21\u4fee\u6539\u8303\u56f4', 13, True)
    tx(0.47, '\u4f7f\u7528\u5df2\u6838\u9a8c\u7684 MR \u4f30\u8ba1\u66f4\u65b0\u56fe\u7248\uff0cOR\u3001\u7f6e\u4fe1\u533a\u95f4\u53ca\u539f\u59cb P \u503c\n\u5747\u6cbf\u7528\u5b9e\u8dd1\u7ed3\u679c\u3002\u5de5\u5177\u53d8\u91cf\u4ecd\u6309 eQTL P\uff1c5e-8\u3001LD r\xb2\uff1c0.001\u3001\n10 Mb \u548c F\u226510 \u7b5b\u9009\u3002\u539f FDR \u56fe\u7248\u53e6\u5b58\u4fdd\u7559\u3002')
    tx(0.36, '\u5982\u4f55\u9605\u8bfb', 13, True)
    tx(0.32, 'Raw P\uff1c0.05 \u8868\u793a\u672a\u4f5c\u591a\u91cd\u6821\u6b63\u7684\u540d\u4e49\u5173\u8054\u3002\n\u5168\u57fa\u56e0 FDR\uff1c0.05 \u4ecd\u4e3a 0\uff0cMAPK1 \u7684 FDR \u4e3a 0.755\u3002\n\u672c\u7248\u4e0d\u80fd\u7528\u4e8e\u5ba3\u79f0\u5df2\u786e\u8ba4\u56e0\u679c\u5173\u7cfb\u6216\u6cbb\u7597\u9776\u70b9\u3002')
    tx(0.22, '\u6587\u4ef6\u5185\u5bb9', 13, True)
    tx(0.18, '\u672c\u518c\uff1a\u5de5\u5177\u53d8\u91cf\u7b5b\u9009\u56fe\u3001Raw P \u66fc\u54c8\u987f\u56fe\u548c\u5019\u9009\u57fa\u56e0\u68ee\u6797\u56fe\u3002\n\u53e6\u518c\uff1a383 \u4e2a\u540d\u4e49\u5173\u8054\u57fa\u56e0\u7684\u5b8c\u6574\u5206\u9875\u68ee\u6797\u56fe\u3002\n\u540c\u65f6\u63d0\u4f9b\u77e2\u91cf SVG\u3001600 dpi PNG \u548c\u5168\u90e8\u5bf9\u5e94\u7ed3\u679c\u8868\u3002')
    tx(0.08, '\u6570\u636e\u4ecd\u4e3a GTEx \u57f9\u517b\u6210\u7ea4\u7ef4\u7ec6\u80de eQTL\uff0c\u5e76\u975e\u7259\u9f88\u5355\u7ec6\u80de eQTL\u3002\n\u72ec\u7acb\u590d\u73b0\u3001\u5171\u5b9a\u4f4d\u7b49\u6570\u636e\u9650\u5236\u4e0e\u524d\u4e00\u7248\u672c\u76f8\u540c\u3002', 9, color='#555555')
    p = A / 'RawP_summary_page.pdf'
    fig.savefig(p)
    plt.close(fig)
    return p
figure2()
figure3()
full, pages = full_forest()
writer = PdfWriter()
writer.append(str(summary_page()))
writer.append(str(SOURCE / 'figures/Figure_1_instrument_selection.pdf'))
for name in ['Figure_2_RawP_discovery', 'Figure_3_RawP_candidate_genes']:
    writer.append(str(A / f'{name}.pdf'))
report = OUT / '\u6210\u7ea4\u7ef4\u7ec6\u80deMR_RawP\u56fe\u7248\u4e0e\u7ed3\u679c.pdf'
with report.open('wb') as h:
    writer.write(h)
for ext in ['.svg', '.png']:
    shutil.copy2(SOURCE / 'figures' / f'Figure_1_instrument_selection{ext}', F / f'Figure_1_instrument_selection{ext}')
assert all((sha(SOURCE / p) == v for p, v in originals.items()))
assert len(PdfReader(report).pages) == 4
assert len(PdfReader(full).pages) == 18
flattened = [p for page in pages for p in page['probes']]
assert len(flattened) == 383 and len(set(flattened)) == 383 and (set(flattened) == set(sig.Probe))
(A / 'RawP_validation.json').write_text(json.dumps({'n_tested': len(res), 'raw_p_lt_005': len(sig), 'raw_p_lt_001': int(sum(res.p_MR < 0.01)), 'all_383_plotted_once': True, 'primary_report_pages': 4, 'full_forest_pages': len(pages), 'source_data_sha256': sha(SOURCE / 'tables/04_discovery_all_genes.csv'), 'original_figures_unchanged': True, 'threshold': 0.05, 'threshold_type': 'unadjusted MR P', 'eQTL_instrument_threshold_unchanged': 5e-08, 'pages': pages}, ensure_ascii=False, indent=2), encoding='utf8')
(OUT / 'RawP\u7248\u8bf4\u660e.md').write_text('# Raw P \u56fe\u7248\n\n\u4e3b\u518c4\u9875\uff1b\u5b8c\u6574\u68ee\u6797\u56fe18\u9875\uff0c383\u4e2a\u540d\u4e49\u5173\u8054\u57fa\u56e0\u5168\u90e8\u5c55\u793a\u4e00\u6b21\u3002\n\n\u6b64\u6b21\u4ec5\u4fee\u6539\u7ed3\u679c\u5c55\u793a\u7684\u663e\u8457\u6027\u4f9d\u636e\uff1aMR Raw P < 0.05\u3002\u6cbf\u7528\u539f\u59cb\u4f30\u8ba1\uff0c\u672a\u91cd\u7b97\u6216\u653e\u5bbd\u5de5\u5177\u53d8\u91cf\u7b5b\u9009\u3002\n\u66fc\u54c8\u987f\u56fe\u4f7f\u7528 -log10(Raw P)\uff1b\u4e3b\u56fe\u68ee\u6797\u8868\u5c55\u793a\u524d10\u4e2a\uff0c\u5b8c\u6574383\u4e2a\u5728\u53e6\u518c\u3002\u5019\u9009\u57fa\u56e0\u68ee\u6797\u8868\u4fdd\u7559\u5168\u90e813\u4e2a\u5019\u9009\u3002\n\u68ee\u6797\u56fe\u4ee5nSNP\u5217\u66ff\u4ee3FDR\u5217\uff1b\u6240\u6709\u56fe\u6ce8\u660e\u672a\u505a\u591a\u91cd\u6821\u6b63\u3002\u5168\u57fa\u56e0FDR\u4ecd\u65e0\u663e\u8457\u7ed3\u679c\u3002\n\u539fFDR\u56fe\u7248\u53ca\u5206\u6790\u7ed3\u679c\u4fdd\u6301\u539f\u6837\u3002\u56fe\u4f8b\u3001\u914d\u8272\u548c\u5b57\u4f53\u6cbf\u7528\u539f\u6587\u98ce\u683c\uff1b\u5de5\u5177\u53d8\u91cf\u56fe\u76f4\u63a5\u6cbf\u7528\u5df2\u6838\u9a8c\u7248\u672c\u3002\n\nfigures \u4e2d\u63d0\u4f9bSVG\u548c600 dpi PNG\uff1btables \u4e2d\u4fdd\u7559\u5168383\u4e2a\u7ed3\u679c\u53ca\u5019\u9009\u8868\uff08CSV\u542bFDR\u5217\u4fbf\u4e8e\u6838\u5bf9\uff09\u3002\n\u5b8c\u6574\u68ee\u6797\u56fe\u6bcf\u9875\u4f7f\u7528\u72ec\u7acb\u7ebf\u6027OR\u8303\u56f4\uff1b\u8de8\u9875\u6bd4\u8f83\u4ee5\u5370\u51fa\u7684OR\u4e0e95% CI\u4e3a\u51c6\u3002\n', encoding='utf8')
print(report, flush=True)
print(full, flush=True)
print('[RAW_P_FIGURES_DONE]', flush=True)
