from __future__ import annotations
import argparse
import json
import math
import re
from pathlib import Path
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pypdfium2 as pdfium
from matplotlib.patches import Arc, Circle, Rectangle, Wedge
from pypdf import PdfReader
PAGE_WIDTH = 1022.0
PAGE_HEIGHT = 705.0
CENTER = (262.72, 340.31)
R_INNER_HOLE = 43.3
R_RICH_OUTER = 100.4
R_BUBBLE = 111.5
R_TERM_INNER = 122.5
R_TERM_OUTER = 143.0
R_ONTOLOGY_INNER = 144.1
R_ONTOLOGY_OUTER = 172.0
R_TICK_INNER = 176.0
R_TICK_OUTER = 181.5
R_ID_TEXT = 158.2
R_TERM_TEXT = 132.8
R_COUNT_TEXT = 104.0
INK = '#26384D'
WHITE = '#FFFFFF'
RICH_BG = '#E3E5E8'
GREEN_FILL = '#BFE3B1'
GREEN_STROKE = '#9BC88D'
GREEN_TEXT = '#42683C'
PURPLE_FILL = '#B449D0'
PURPLE_STROKE = '#7B2F94'
ONTOLOGY_COLORS = {'BP': '#7E9FD0', 'CC': '#E8A2AE', 'MF': '#F1D98F'}
ONTOLOGY_ORDER = ('MF', 'BP', 'CC')
CORE_GENES = ('GDF15', 'PLAU')
DISPLAY_TERMS = {'BP': ['circulatory system process', 'ERK1 and ERK2 cascade', 'positive regulation of cell motility', 'leukocyte differentiation', 'positive regulation of cell migration'], 'CC': ['extracellular matrix', 'external encapsulating structure', 'MAP kinase activity', 'actin cytoskeleton', 'cell-cell junction'], 'MF': ['signaling receptor regulator activity', 'signaling receptor activator activity', 'receptor ligand activity', 'actin binding', 'DNA-binding transcription activator activity']}

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', required=True, type=Path)
    parser.add_argument('--threshold', required=True, choices=('0.5', '1'))
    return parser.parse_args()

def normalize_text(value: object) -> str:
    return re.sub('\\s+', ' ', str(value).strip()).casefold()

def setup_style() -> None:
    mpl.rcParams.update({'font.family': 'Arial', 'font.sans-serif': ['Arial', 'Liberation Sans', 'DejaVu Sans'], 'pdf.fonttype': 42, 'ps.fonttype': 42, 'axes.unicode_minus': False, 'text.color': INK, 'axes.labelcolor': INK, 'xtick.color': INK, 'ytick.color': INK})

def gene_set(value: object) -> set[str]:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return set()
    return {token.upper() for token in re.split('[/;,|\\s]+', str(value).strip()) if token}

def nice_scale_max(maximum: int) -> int:
    if maximum <= 10:
        step = 2
    elif maximum <= 30:
        step = 5
    elif maximum <= 60:
        step = 10
    else:
        step = 20
    return max(step, int(math.ceil(maximum / step) * step))

def build_display_id_map(all_go: pd.DataFrame) -> dict[str, str]:
    required = {'ID', 'Description'}
    missing = required - set(all_go.columns)
    if missing:
        raise ValueError(f'GO lookup is missing columns: {sorted(missing)}')
    result: dict[str, str] = {}
    for ontology, descriptions in DISPLAY_TERMS.items():
        for description in descriptions:
            key = normalize_text(description)
            matched = all_go.loc[all_go['Description'].map(normalize_text).eq(key), ['ID', 'Description']].drop_duplicates()
            if len(matched) != 1:
                raise ValueError(f'Expected one GO ID for {description!r}, found {len(matched)}.')
            result[key] = str(matched.iloc[0]['ID'])
    return result

def load_terms(root: Path, threshold: str) -> tuple[pd.DataFrame, Path]:
    data_dir = root / '01_\u6e90\u6570\u636e'
    lookup_path = data_dir / '07_GO_BP_CC_MF_all_results.csv'
    display_id_map = build_display_id_map(pd.read_csv(lookup_path))
    if threshold == '1':
        source_path = data_dir / '15_E_GO\u91cd\u9009_3\u81f34\u79cdGeneRatio_\u771f\u5b9e\u540d\u4e0e\u663e\u793a\u540d\u5bf9\u7167.csv'
        source = pd.read_csv(source_path)
        source['source_ID'] = source['ID'].astype(str)
        source['source_Description'] = source['Description_source'].astype(str)
        source['display_order'] = pd.to_numeric(source['display_order_top_to_bottom'], errors='raise').astype(int)
    else:
        source_path = data_dir / '08_E_GO_top5_GeneRatio_per_ontology.csv'
        source = pd.read_csv(source_path)
        source['source_ID'] = source['ID'].astype(str)
        source['source_Description'] = source['Description'].astype(str)
        source['display_order'] = source.groupby('ONTOLOGY', sort=False).cumcount() + 1
        source['Description_display'] = source.apply(lambda row: DISPLAY_TERMS[str(row['ONTOLOGY']).upper()][int(row['display_order']) - 1], axis=1)
    required = {'ONTOLOGY', 'source_ID', 'source_Description', 'Description_display', 'display_order', 'Count', 'RichFactor', 'geneID', 'GeneRatio', 'pvalue'}
    missing = required - set(source.columns)
    if missing:
        raise ValueError(f'Enrichment source is missing columns: {sorted(missing)}')
    source['ONTOLOGY'] = source['ONTOLOGY'].astype(str).str.upper()
    source['Count'] = pd.to_numeric(source['Count'], errors='raise').astype(int)
    source['RichFactor'] = pd.to_numeric(source['RichFactor'], errors='raise')
    source['pvalue'] = pd.to_numeric(source['pvalue'], errors='raise')
    source['display_ID'] = source['Description_display'].map(lambda value: display_id_map[normalize_text(value)])
    source['select_count'] = source['geneID'].map(lambda value: sum((gene in gene_set(value) for gene in CORE_GENES)))
    rank = {ontology: index for index, ontology in enumerate(ONTOLOGY_ORDER)}
    source['ontology_rank'] = source['ONTOLOGY'].map(rank)
    source = source.sort_values(['ontology_rank', 'display_order'], kind='stable').reset_index(drop=True)
    if len(source) != 15:
        raise ValueError(f'Expected 15 GO rows, found {len(source)}.')
    if source['display_ID'].nunique() != 15:
        raise ValueError('The 15 displayed GO IDs must be unique.')
    if not source['Count'].between(1, 99).all():
        raise ValueError('Count must remain below 100 for the requested ring scale.')
    return (source, source_path)

def polar_point(radius: float, angle_deg: float) -> tuple[float, float]:
    angle = math.radians(angle_deg)
    return (CENTER[0] + radius * math.cos(angle), CENTER[1] + radius * math.sin(angle))

def readable_tangent_rotation(angle_deg: float) -> float:
    rotation = angle_deg - 90.0
    while rotation <= -90.0:
        rotation += 180.0
    while rotation > 90.0:
        rotation -= 180.0
    return rotation

def add_annular_wedge(ax: plt.Axes, *, radius: float, width: float, clockwise_start: float, clockwise_end: float, facecolor: str, edgecolor: str, linewidth: float, zorder: float) -> None:
    ax.add_patch(Wedge(CENTER, radius, clockwise_end, clockwise_start, width=width, facecolor=facecolor, edgecolor=edgecolor, linewidth=linewidth, joinstyle='miter', zorder=zorder))

def draw_legend(ax: plt.Axes) -> None:
    x0 = 555.0
    label_x = 610.0
    ax.text(x0, 523, 'ONTOLOGY', fontsize=16.0, fontweight='bold', ha='left', va='center', color='#111111')
    for y, key, label in [(463, 'BP', 'Biological Process'), (407, 'CC', 'Cellular Component'), (351, 'MF', 'Molecular Function')]:
        ax.add_patch(Rectangle((x0, y - 14), 42, 28, facecolor=ONTOLOGY_COLORS[key], edgecolor='none'))
        ax.text(label_x, y, label, fontsize=13.3, ha='left', va='center', color=INK)
    ax.add_patch(Rectangle((x0, 267), 42, 22, facecolor=GREEN_FILL, edgecolor=GREEN_STROKE, linewidth=0.8))
    ax.text(label_x, 278, 'Number of Genes', fontsize=13.3, ha='left', va='center')
    ax.add_patch(Circle((x0 + 21, 222), 7.0, facecolor=PURPLE_FILL, edgecolor=PURPLE_STROKE, linewidth=0.8))
    ax.text(label_x, 222, 'Number of Select', fontsize=13.3, ha='left', va='center')
    ax.add_patch(Rectangle((x0, 153), 42, 22, facecolor=RICH_BG, edgecolor='#C2C6CB', linewidth=0.8))
    ax.text(label_x, 164, 'Rich Factor(0-1)', fontsize=13.3, ha='left', va='center')

def plot_ring(terms: pd.DataFrame, pdf_path: Path, png_path: Path) -> int:
    fig = plt.figure(figsize=(PAGE_WIDTH / 72.0, PAGE_HEIGHT / 72.0), dpi=72, facecolor='white')
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, PAGE_WIDTH)
    ax.set_ylim(0, PAGE_HEIGHT)
    ax.set_aspect('equal', adjustable='box')
    ax.axis('off')
    scale_max = nice_scale_max(int(terms['Count'].max()))
    tick_values = [0, scale_max / 2, scale_max]
    tick_labels = [f'{value:g}' for value in tick_values]
    sector_width = 360.0 / len(terms)
    tick_margin_deg = 5.5 * 360.0 / (2 * math.pi * R_TICK_INNER)
    for index, row in terms.iterrows():
        ontology = str(row['ONTOLOGY'])
        color = ONTOLOGY_COLORS[ontology]
        count = int(row['Count'])
        rich_factor = float(row['RichFactor'])
        select_count = int(row['select_count'])
        start_angle = 90.0 - index * sector_width
        end_angle = start_angle - sector_width
        mid_angle = (start_angle + end_angle) / 2.0
        rotation = readable_tangent_rotation(mid_angle)
        add_annular_wedge(ax, radius=R_RICH_OUTER, width=R_RICH_OUTER - R_INNER_HOLE, clockwise_start=start_angle, clockwise_end=end_angle, facecolor=RICH_BG, edgecolor=WHITE, linewidth=1.28, zorder=1)
        rich_outer = R_INNER_HOLE + np.clip(rich_factor, 0, 1) * (R_RICH_OUTER - R_INNER_HOLE)
        add_annular_wedge(ax, radius=rich_outer, width=max(rich_outer - R_INNER_HOLE, 0.01), clockwise_start=start_angle, clockwise_end=end_angle, facecolor=color, edgecolor=WHITE, linewidth=1.28, zorder=2)
        count_fraction = count / scale_max
        bar_end_angle = start_angle - tick_margin_deg - (sector_width - 2 * tick_margin_deg) * count_fraction
        add_annular_wedge(ax, radius=R_TERM_OUTER, width=R_TERM_OUTER - R_TERM_INNER, clockwise_start=start_angle, clockwise_end=bar_end_angle, facecolor=GREEN_FILL, edgecolor=GREEN_STROKE, linewidth=0.75, zorder=3)
        bar_mid_angle = (start_angle + bar_end_angle) / 2.0
        x, y = polar_point(R_TERM_TEXT, bar_mid_angle)
        ax.text(x, y, str(count), ha='center', va='center', rotation=readable_tangent_rotation(bar_mid_angle), rotation_mode='anchor', fontsize=6.2, fontweight='bold', color=GREEN_TEXT, zorder=6)
        bubble_radius = {0: 2.8, 1: 5.2, 2: 7.4}[select_count]
        bx, by = polar_point(R_BUBBLE, mid_angle)
        ax.add_patch(Circle((bx, by), bubble_radius, facecolor=PURPLE_FILL, edgecolor=PURPLE_STROKE, linewidth=0.65, zorder=5))
        cx, cy = polar_point(R_COUNT_TEXT, mid_angle)
        ax.text(cx, cy, str(select_count), ha='center', va='center', rotation=rotation, rotation_mode='anchor', fontsize=6.2, fontweight='bold', color=PURPLE_STROKE, zorder=6)
        add_annular_wedge(ax, radius=R_ONTOLOGY_OUTER, width=R_ONTOLOGY_OUTER - R_ONTOLOGY_INNER, clockwise_start=start_angle, clockwise_end=end_angle, facecolor=color, edgecolor=WHITE, linewidth=1.45, zorder=3)
        ix, iy = polar_point(R_ID_TEXT, mid_angle)
        ax.text(ix, iy, str(row['display_ID']), ha='center', va='center', rotation=rotation, rotation_mode='anchor', fontsize=8.2, color=INK, zorder=6)
        ax.add_patch(Arc(CENTER, 2 * R_TICK_INNER, 2 * R_TICK_INNER, theta1=end_angle + tick_margin_deg, theta2=start_angle - tick_margin_deg, edgecolor=INK, linewidth=0.65, zorder=4))
        for tick_value, tick_label in zip(tick_values, tick_labels):
            tick_fraction = tick_value / scale_max
            tick_angle = start_angle - tick_margin_deg - (sector_width - 2 * tick_margin_deg) * tick_fraction
            tx0, ty0 = polar_point(R_TICK_INNER, tick_angle)
            tx1, ty1 = polar_point(R_TICK_OUTER, tick_angle)
            ax.plot([tx0, tx1], [ty0, ty1], color=INK, linewidth=0.65, solid_capstyle='butt', zorder=4)
            lx, ly = polar_point(193.0, tick_angle)
            ax.text(lx, ly, tick_label, ha='center', va='center', rotation=readable_tangent_rotation(tick_angle), rotation_mode='anchor', fontsize=5.3, fontstyle='italic', color=INK, zorder=6)
    for fraction in (0.25, 0.5, 0.75, 1.0):
        radius = R_INNER_HOLE + fraction * (R_RICH_OUTER - R_INNER_HOLE)
        ax.add_patch(Circle(CENTER, radius, facecolor='none', edgecolor=WHITE, linewidth=0.64, zorder=4))
    ax.add_patch(Circle(CENTER, R_INNER_HOLE, facecolor=WHITE, edgecolor=WHITE, linewidth=0.8, zorder=5))
    draw_legend(ax)
    metadata = {'Creator': 'Matplotlib', 'Title': 'GO ring plot'}
    fig.savefig(pdf_path, facecolor='white', metadata=metadata)
    fig.savefig(png_path, facecolor='white', dpi=400)
    plt.close(fig)
    return scale_max

def main() -> None:
    args = parse_args()
    root = args.root.resolve()
    code_dir = root / '00_\u4ee3\u7801\u4e0e\u5ba1\u8ba1'
    data_dir = root / '01_\u6e90\u6570\u636e'
    render_dir = root / '02_QA_rendered'
    code_dir.mkdir(parents=True, exist_ok=True)
    data_dir.mkdir(parents=True, exist_ok=True)
    render_dir.mkdir(parents=True, exist_ok=True)
    terms, source_path = load_terms(root, args.threshold)
    suffix = f'FDR\u5c0f\u4e8e0.05_log2FC\u7edd\u5bf9\u503c\u5927\u4e8e\u7b49\u4e8e{args.threshold}'
    pdf_path = root / f'F.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0GO\u901a\u8def\u73af\u5f62\u56fe\uff08{suffix}\uff09.pdf'
    png_path = root / f'F.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0GO\u901a\u8def\u73af\u5f62\u56fe\uff08{suffix}\uff09.png'
    source_out = data_dir / '19_F_GO\u73af\u5f62\u56fe_\u6539\u540e\u7f16\u53f7\u4e0e\u6539\u524d\u6570\u636e\u5bf9\u7167.csv'
    preview_path = render_dir / 'F_GO\u73af\u5f62\u56fe_\u6700\u7ec8\u6838\u9a8c.png'
    setup_style()
    scale_max = plot_ring(terms, pdf_path, png_path)
    terms.to_csv(source_out, index=False, encoding='utf-8-sig')
    document = pdfium.PdfDocument(str(pdf_path))
    document[0].render(scale=1.8).to_pil().save(preview_path)
    reader = PdfReader(str(pdf_path))
    extracted = reader.pages[0].extract_text() or ''
    all_ids_present = all((display_id in extracted for display_id in terms['display_ID']))
    qa = {'overall': 'PASS', 'threshold': args.threshold, 'source_values_csv': str(source_path), 'outer_labels': 'GO IDs mapped from renamed Description_display values', 'numeric_values': 'pre-rename enrichment rows', 'number_of_genes_field': 'Count', 'count_min': int(terms['Count'].min()), 'count_max': int(terms['Count'].max()), 'axis_max': int(scale_max), 'all_counts_below_100': bool(terms['Count'].lt(100).all()), 'all_15_display_ids_unique': bool(terms['display_ID'].nunique() == 15), 'all_15_display_ids_extractable_from_pdf': bool(all_ids_present), 'rich_factor_within_0_and_1': bool(terms['RichFactor'].between(0, 1).all()), 'pdf_pages': len(reader.pages), 'pdf_bytes': pdf_path.stat().st_size, 'png_bytes': png_path.stat().st_size, 'output_pdf': str(pdf_path), 'output_png': str(png_path), 'preview_png': str(preview_path)}
    if not all([qa['all_counts_below_100'], qa['all_15_display_ids_unique'], qa['all_15_display_ids_extractable_from_pdf'], qa['rich_factor_within_0_and_1'], qa['pdf_pages'] == 1, qa['pdf_bytes'] > 5000, qa['png_bytes'] > 5000]):
        qa['overall'] = 'FAIL'
    with (code_dir / 'QA\u6c47\u603b_GO\u73af\u5f62\u56fe_\u6539\u540e\u7f16\u53f7\u6539\u524d\u6570\u636e.json').open('w', encoding='utf-8') as handle:
        json.dump(qa, handle, ensure_ascii=False, indent=2)
    if qa['overall'] != 'PASS':
        raise AssertionError(json.dumps(qa, ensure_ascii=False, indent=2))
    print(json.dumps(qa, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
