from __future__ import annotations
import argparse
import hashlib
import json
import math
import os
import shutil
import subprocess
import textwrap
from itertools import combinations
from pathlib import Path
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap, LogNorm
from matplotlib.ticker import FormatStrFormatter
from pypdf import PdfReader
ONTOLOGIES = ('BP', 'CC', 'MF')
ONTOLOGY_TITLES = {'BP': 'Biological Process', 'CC': 'Cellular Component', 'MF': 'Molecular Function'}
CMAP = LinearSegmentedColormap.from_list('low_p_red_high_p_blue', ['#E8645A', '#B57A91', '#2189B5'])
GRID = '#D9E2EA'
EDGE = '#435262'
mpl.rcParams.update({'font.family': 'Arial', 'font.size': 10.5, 'axes.titlesize': 12.0, 'axes.titleweight': 'bold', 'axes.labelsize': 10.5, 'xtick.labelsize': 9.5, 'ytick.labelsize': 9.5, 'axes.edgecolor': '#777777', 'axes.linewidth': 0.6, 'text.color': '#26374A', 'axes.labelcolor': '#26374A', 'xtick.color': '#26374A', 'ytick.color': '#26374A', 'pdf.fonttype': 42, 'ps.fonttype': 42})

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description='Select and plot GO terms with exactly three GeneRatio levels per ontology.')
    parser.add_argument('--root', required=True, type=Path)
    parser.add_argument('--threshold-tag', required=True, choices=('0.5', '1'))
    return parser.parse_args()

def md5sum(path: Path) -> str:
    digest = hashlib.md5()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def ratio_to_float(value: str) -> float:
    numerator, denominator = str(value).split('/', maxsplit=1)
    return float(numerator) / float(denominator)

def marker_prefix(gene_string: str) -> str:
    genes = {part.strip().upper() for part in str(gene_string).split('/') if part.strip()}
    has_gdf15 = 'GDF15' in genes
    has_plau = 'PLAU' in genes
    if has_gdf15 and has_plau:
        return '*+ '
    if has_gdf15:
        return '* '
    if has_plau:
        return '+ '
    return ''

def point_sizes(counts: np.ndarray, minimum: float=48, maximum: float=150) -> np.ndarray:
    counts = np.asarray(counts, dtype=float)
    low = float(np.nanmin(counts))
    high = float(np.nanmax(counts))
    if math.isclose(low, high):
        return np.full_like(counts, (minimum + maximum) / 2)
    return minimum + (counts - low) / (high - low) * (maximum - minimum)

def legend_count_values(counts: np.ndarray) -> list[int]:
    low = int(np.nanmin(counts))
    high = int(np.nanmax(counts))
    if low == high:
        return [low]
    return list(dict.fromkeys((int(round(value)) for value in np.linspace(low, high, 4))))

def pvalue_tick_label(value: float) -> str:
    if value < 0.001:
        return f'{value:.0e}'
    if value < 0.01:
        return f'{value:.4f}'.rstrip('0')
    return f'{value:.3f}'.rstrip('0')

def pvalue_norm(values: np.ndarray) -> LogNorm:
    positive = np.asarray(values, dtype=float)
    positive = positive[np.isfinite(positive) & (positive > 0)]
    if positive.size == 0:
        raise ValueError('No positive p-values are available for plotting.')
    vmin = float(np.min(positive))
    vmax = float(np.max(positive))
    if math.isclose(vmin, vmax):
        vmax = vmin * 1.01
    return LogNorm(vmin=vmin, vmax=vmax)

def apply_panel_style(ax: plt.Axes) -> None:
    ax.set_axisbelow(True)
    ax.grid(True, which='major', color=GRID, linewidth=0.65)
    for spine in ax.spines.values():
        spine.set_color('#777777')
        spine.set_linewidth(0.6)

def add_colorbar(fig: plt.Figure, cax: plt.Axes, norm: LogNorm) -> None:
    scalar = mpl.cm.ScalarMappable(norm=norm, cmap=CMAP)
    scalar.set_array([])
    colorbar = fig.colorbar(scalar, cax=cax)
    ticks = np.geomspace(norm.vmin, norm.vmax, 4)
    colorbar.set_ticks(ticks)
    colorbar.set_ticklabels([pvalue_tick_label(value) for value in ticks])
    colorbar.ax.invert_yaxis()
    colorbar.outline.set_visible(False)
    colorbar.ax.tick_params(length=2.5, width=0.6, labelsize=9)
    cax.set_title('pvalue', loc='left', fontsize=10.5, fontweight='bold', pad=7)

def add_count_legend(ax: plt.Axes, counts: np.ndarray) -> None:
    values = legend_count_values(counts)
    sizes = point_sizes(np.asarray(values, dtype=float))
    handles = [plt.scatter([], [], s=size, facecolor='black', edgecolor='black', linewidth=0.4) for size in sizes]
    legend = ax.legend(handles, [str(value) for value in values], title='Count', frameon=False, loc='center left', bbox_to_anchor=(1.12, 0.55), borderaxespad=0, labelspacing=0.75, handletextpad=0.9)
    plt.setp(legend.get_title(), fontweight='bold')
    ax.add_artist(legend)

def select_exact_three_ratio_levels(frame: pd.DataFrame) -> pd.DataFrame:
    selected_parts: list[pd.DataFrame] = []
    for ontology in ONTOLOGIES:
        part = frame.loc[frame['ONTOLOGY'].eq(ontology)].copy()
        part = part.loc[part['pvalue'].lt(0.05)].copy()
        part['GeneRatioNumeric'] = part['GeneRatio'].map(ratio_to_float)
        part = part.sort_values(['GeneRatioNumeric', 'pvalue', 'p.adjust', 'Description'], ascending=[False, True, True, True], kind='stable')
        all_ratio_levels = list(dict.fromkeys(part['GeneRatio'].astype(str)))
        if len(all_ratio_levels) < 3:
            raise ValueError(f'{ontology} has fewer than three significant GeneRatio levels.')
        ratio_levels: list[str] | None = None
        ratio_text = part['GeneRatio'].astype(str)
        for candidate in combinations(all_ratio_levels, 3):
            if int(ratio_text.isin(candidate).sum()) >= 5:
                ratio_levels = list(candidate)
                break
        if ratio_levels is None:
            raise ValueError(f'{ontology} cannot provide five pathways across exactly three GeneRatio levels.')
        seed_indices: list[int] = []
        for ratio in ratio_levels:
            seed_indices.append(part.index[part['GeneRatio'].astype(str).eq(ratio)][0])
        selected_indices = list(seed_indices)
        pool = part.loc[part['GeneRatio'].astype(str).isin(ratio_levels)]
        for row_index in pool.index:
            if row_index not in selected_indices:
                selected_indices.append(row_index)
            if len(selected_indices) == 5:
                break
        if len(selected_indices) != 5:
            raise ValueError(f'{ontology} cannot provide five pathways within three GeneRatio levels.')
        chosen = part.loc[selected_indices].copy()
        chosen['selection_reason'] = 'fill_within_top3_ratio_levels'
        chosen.loc[seed_indices, 'selection_reason'] = 'seed_one_per_ratio_level'
        chosen = chosen.sort_values(['GeneRatioNumeric', 'pvalue', 'p.adjust', 'Description'], ascending=[False, True, True, True], kind='stable')
        if chosen['GeneRatio'].nunique() != 3:
            raise AssertionError(f'{ontology} did not retain exactly three GeneRatio levels.')
        selected_parts.append(chosen)
    return pd.concat(selected_parts, ignore_index=True)

def plot_go(frame: pd.DataFrame, pdf_path: Path, png_path: Path) -> None:
    frame = frame.copy()
    frame['display_label'] = [marker_prefix(gene_ids) + str(description) for gene_ids, description in zip(frame['geneID'], frame['Description'])]
    norm = pvalue_norm(frame['pvalue'].to_numpy())
    counts = frame['Count'].to_numpy()
    fig = plt.figure(figsize=(13.1, 10.5), facecolor='white')
    grid = fig.add_gridspec(3, 1, left=0.36, right=0.78, bottom=0.08, top=0.88, hspace=0.43)
    axes: list[plt.Axes] = []
    for row_index, ontology in enumerate(ONTOLOGIES):
        ax = fig.add_subplot(grid[row_index, 0])
        axes.append(ax)
        part = frame.loc[frame['ONTOLOGY'].eq(ontology)].copy()
        part = part.sort_values(['GeneRatioNumeric', 'pvalue'], ascending=[True, False])
        y = np.arange(len(part))
        ax.scatter(part['GeneRatioNumeric'], y, s=point_sizes(part['Count'].to_numpy()), c=part['pvalue'], cmap=CMAP, norm=norm, edgecolor=EDGE, linewidth=0.75, alpha=0.96, zorder=3)
        ax.set_yticks(y)
        ax.set_yticklabels([textwrap.fill(str(label), width=48, break_long_words=False) for label in part['display_label']])
        ratio_ticks = sorted(part['GeneRatioNumeric'].unique())
        ax.set_xticks(ratio_ticks)
        ax.xaxis.set_major_formatter(FormatStrFormatter('%.3f'))
        ax.set_xlabel('Gene ratio')
        ax.set_title(ONTOLOGY_TITLES[ontology], loc='left', pad=8)
        apply_panel_style(ax)
        ax.margins(x=0.12, y=0.07)
    fig.suptitle('GO', x=0.36, y=0.955, ha='left', fontsize=16, fontweight='bold')
    color_ax = fig.add_axes([0.815, 0.72, 0.027, 0.17])
    add_colorbar(fig, color_ax, norm)
    add_count_legend(axes[1], counts)
    if any((label.startswith(('* ', '+ ', '*+ ')) for label in frame['display_label'])):
        axes[2].text(1.13, 0.2, 'Pathway label\n*  GDF15\n+  PLAU\n*+ both', transform=axes[2].transAxes, ha='left', va='top', fontsize=9.5, linespacing=1.35)
    fig.savefig(pdf_path, facecolor='white', metadata={'Title': 'GO'})
    fig.savefig(png_path, dpi=360, facecolor='white')
    plt.close(fig)

def render_pdf(pdf_path: Path, preview_path: Path) -> None:
    preview_path.parent.mkdir(parents=True, exist_ok=True)
    renderer = os.environ.get('PDFTOPPM_EXE') or shutil.which('pdftoppm.exe') or shutil.which('pdftoppm')
    if not renderer:
        raise RuntimeError('pdftoppm was not found.')
    subprocess.run([renderer, '-png', '-singlefile', '-r', '160', str(pdf_path), str(preview_path.with_suffix(''))], check=True, capture_output=True, text=True)

def main() -> None:
    args = parse_args()
    root = args.root.resolve()
    out_dir = root / 'GO\u56fe_\u6bcf\u7c7b\u6070\u597d3\u79cdGeneRatio_\u989d\u5916\u51fa\u7a3f_v1'
    code_dir = out_dir / '00_\u4ee3\u7801\u4e0e\u8d28\u63a7'
    data_dir = out_dir / '01_\u6e90\u6570\u636e'
    qa_render_dir = out_dir / '02_QA_rendered'
    code_dir.mkdir(parents=True, exist_ok=True)
    data_dir.mkdir(parents=True, exist_ok=True)
    qa_render_dir.mkdir(parents=True, exist_ok=True)
    source_csv = root / '01_\u6e90\u6570\u636e' / '07_GO_BP_CC_MF_all_results.csv'
    original_candidates = sorted(root.glob('E.*GO\u901a\u8def\u6c14\u6ce1\u56fe*.pdf'))
    if len(original_candidates) != 1:
        raise FileNotFoundError(f'Expected exactly one original GO PDF in {root}, found {len(original_candidates)}.')
    original_pdf = original_candidates[0]
    original_md5_before = md5sum(original_pdf)
    raw = pd.read_csv(source_csv)
    raw['pvalue'] = pd.to_numeric(raw['pvalue'], errors='coerce')
    raw['p.adjust'] = pd.to_numeric(raw['p.adjust'], errors='coerce')
    raw['Count'] = pd.to_numeric(raw['Count'], errors='coerce')
    selected = select_exact_three_ratio_levels(raw)
    selected_csv = data_dir / 'GO_BP_CC_MF_top5_each_exact3_GeneRatio.csv'
    selected.to_csv(selected_csv, index=False, encoding='utf-8-sig')
    stem = f'E.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0GO\u901a\u8def\u6c14\u6ce1\u56fe\uff08FDR\u5c0f\u4e8e0.05_log2FC\u7edd\u5bf9\u503c\u5927\u4e8e\u7b49\u4e8e{args.threshold_tag}_\u6bcf\u7c7b\u6070\u597d3\u79cdGeneRatio\uff09'
    pdf_path = out_dir / f'{stem}.pdf'
    png_path = out_dir / f'{stem}.png'
    if pdf_path.exists() or png_path.exists():
        raise FileExistsError(f'Refusing to overwrite an existing output: {pdf_path}')
    plot_go(selected, pdf_path, png_path)
    preview_path = qa_render_dir / 'E_GO_exact3_GeneRatio_preview.png'
    render_pdf(pdf_path, preview_path)
    original_md5_after = md5sum(original_pdf)
    reader = PdfReader(str(pdf_path))
    page = reader.pages[0]
    width_pt = float(page.mediabox.width)
    height_pt = float(page.mediabox.height)
    qa_rows: list[dict[str, object]] = []
    ratio_summary: dict[str, list[str]] = {}
    for ontology in ONTOLOGIES:
        part = selected.loc[selected['ONTOLOGY'].eq(ontology)]
        ratios = list(dict.fromkeys(part['GeneRatio'].astype(str)))
        ratio_summary[ontology] = ratios
        qa_rows.extend([{'check': f'{ontology}_pathway_count_is_5', 'observed': len(part), 'expected': 5, 'status': 'PASS' if len(part) == 5 else 'FAIL'}, {'check': f'{ontology}_distinct_GeneRatio_is_3', 'observed': len(ratios), 'expected': 3, 'status': 'PASS' if len(ratios) == 3 else 'FAIL'}, {'check': f'{ontology}_all_nominal_pvalue_lt_0.05', 'observed': bool(part['pvalue'].lt(0.05).all()), 'expected': True, 'status': 'PASS' if part['pvalue'].lt(0.05).all() else 'FAIL'}])
    qa_rows.extend([{'check': 'original_GO_pdf_unchanged', 'observed': original_md5_after, 'expected': original_md5_before, 'status': 'PASS' if original_md5_after == original_md5_before else 'FAIL'}, {'check': 'output_pdf_exists_and_nontrivial', 'observed': pdf_path.stat().st_size, 'expected': '>5000 bytes', 'status': 'PASS' if pdf_path.stat().st_size > 5000 else 'FAIL'}, {'check': 'output_pdf_page_count', 'observed': len(reader.pages), 'expected': 1, 'status': 'PASS' if len(reader.pages) == 1 else 'FAIL'}, {'check': 'output_pdf_page_size_points', 'observed': f'{width_pt:.1f} x {height_pt:.1f}', 'expected': '943.2 x 756.0', 'status': 'PASS' if math.isclose(width_pt, 943.2, abs_tol=0.2) and math.isclose(height_pt, 756.0, abs_tol=0.2) else 'FAIL'}, {'check': 'rendered_preview_exists', 'observed': preview_path.exists(), 'expected': True, 'status': 'PASS' if preview_path.exists() else 'FAIL'}])
    qa = pd.DataFrame(qa_rows)
    qa.to_csv(code_dir / 'QA\u68c0\u67e5\u6e05\u5355.csv', index=False, encoding='utf-8-sig')
    overall = 'PASS' if qa['status'].eq('PASS').all() else 'FAIL'
    summary = {'overall': overall, 'selection_rule': 'Within each of BP, CC and MF: nominal pvalue < 0.05; find the highest-ranked combination of three distinct GeneRatio levels that can jointly provide at least five pathways; take one best-p pathway from each level, then fill to five pathways from those same levels by GeneRatio descending and pvalue ascending.', 'threshold_tag': args.threshold_tag, 'source_csv': str(source_csv), 'selected_csv': str(selected_csv), 'output_pdf': str(pdf_path), 'output_png': str(png_path), 'preview_png': str(preview_path), 'original_pdf': str(original_pdf), 'original_md5_before': original_md5_before, 'original_md5_after': original_md5_after, 'ratio_summary': ratio_summary, 'pdf_page_count': len(reader.pages), 'pdf_page_size_points': [width_pt, height_pt]}
    with (code_dir / 'QA\u6c47\u603b.json').open('w', encoding='utf-8') as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    if overall != 'PASS':
        raise AssertionError('One or more QA checks failed.')
    print(json.dumps(summary, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
