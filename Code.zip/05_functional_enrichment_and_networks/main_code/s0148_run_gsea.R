args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 3L) {
  stop("Usage: run_gsea.R <DESeq2 all-genes CSV> <target-list CSV> <output dir>")
}

input_csv <- normalizePath(args[[1]], winslash = "/", mustWork = TRUE)
target_csv <- normalizePath(args[[2]], winslash = "/", mustWork = TRUE)
output_dir <- normalizePath(args[[3]], winslash = "/", mustWork = FALSE)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

lib_paths <- strsplit(Sys.getenv("TASK_R_LIBS"), ";", fixed = TRUE)[[1]]
lib_paths <- lib_paths[nzchar(lib_paths)]
.libPaths(c(lib_paths, .libPaths()))

suppressPackageStartupMessages({
  library(data.table)
  library(fgsea)
  library(clusterProfiler)
  library(org.Hs.eg.db)
  library(GO.db)
})

set.seed(20260812)

targets <- fread(target_csv, encoding = "UTF-8")
stopifnot(all(c("figure_set", "database_group", "pathway_label", "pathway_key") %in% names(targets)))
targets[, target_order := seq_len(.N)]

de <- fread(input_csv, encoding = "UTF-8")
needed <- c("gene_id", "gene_symbol", "stat", "log2FoldChange", "pvalue", "padj", "baseMean")
stopifnot(all(needed %in% names(de)))
de[, gene_symbol := trimws(as.character(gene_symbol))]
de <- de[!is.na(gene_symbol) & nzchar(gene_symbol) & is.finite(stat)]
de[, abs_stat__ := abs(stat)]
setorder(de, gene_symbol, -abs_stat__, pvalue, -baseMean, gene_id)
ranked <- de[, .SD[1L], by = gene_symbol]
ranked[, abs_stat__ := NULL]
setorder(ranked, -stat, gene_symbol)
stats <- ranked$stat
names(stats) <- ranked$gene_symbol
stopifnot(!anyDuplicated(names(stats)), all(is.finite(stats)), length(stats) > 1000L)

fwrite(
  ranked[, .(rank, gene_symbol, stat, log2FoldChange, pvalue, padj, baseMean, gene_id)][, rank := seq_len(.N)],
  file.path(output_dir, "GSE212728_DESeq2_Wald_ranked_genes.csv.gz")
)

gmt_dir <- Sys.getenv("GSEA_GMT_DIR", unset = dirname(target_csv))
gmt_dir <- normalizePath(gmt_dir, winslash = "/", mustWork = TRUE)
gmt_files <- c(
  Reactome = file.path(gmt_dir, "Reactome_Pathways_2024.gmt"),
  KEGG = file.path(gmt_dir, "KEGG_2026.gmt")
)

read_symbol_gmt <- function(path) {
  lines <- readLines(path, warn = FALSE, encoding = "UTF-8")
  parts <- strsplit(lines, "\t", fixed = TRUE)
  out <- lapply(parts, function(x) unique(x[seq.int(3L, length(x))][nzchar(x[seq.int(3L, length(x))])]))
  names(out) <- vapply(parts, `[[`, character(1), 1L)
  out[!duplicated(names(out))]
}

go_ids_by_group <- split(
  unique(targets[database_group %chin% c("GO-BP", "GO-CC", "GO-MF"), .(database_group, pathway_key)]),
  by = "database_group",
  keep.by = FALSE
)

build_go_pathways <- function(group) {
  ont <- sub("GO-", "", group, fixed = TRUE)
  go_data <- clusterProfiler:::get_GO_data(org.Hs.eg.db, ont, "SYMBOL")
  all_sets <- get("PATHID2EXTID", envir = go_data, inherits = FALSE)

  all_sets
}

pathway_sets <- list(
  `GO-BP` = build_go_pathways("GO-BP"),
  `GO-CC` = build_go_pathways("GO-CC"),
  `GO-MF` = build_go_pathways("GO-MF"),
  Reactome = read_symbol_gmt(gmt_files[["Reactome"]]),
  KEGG = read_symbol_gmt(gmt_files[["KEGG"]])
)

extract_es_profile <- function(stats, genes, gsea_param = 1) {
  genes <- intersect(unique(genes), names(stats))
  hits <- names(stats) %chin% genes
  n <- length(stats)
  nh <- sum(hits)
  if (nh == 0L || nh == n) stop("Invalid pathway overlap for ES profile")
  weights <- abs(stats)^gsea_param
  hit_norm <- sum(weights[hits])
  inc <- ifelse(hits, weights / hit_norm, -1 / (n - nh))
  running <- cumsum(inc)
  es <- if (max(running) >= -min(running)) max(running) else min(running)
  peak <- if (es >= 0) which.max(running) else which.min(running)
  leading_idx <- if (es >= 0) which(hits & seq_len(n) <= peak) else which(hits & seq_len(n) >= peak)
  list(
    ES_manual = es,
    peak_rank = peak,
    hit_ranks = which(hits),
    running_ES = running,
    leading_edge_genes_manual = names(stats)[leading_idx]
  )
}

all_results <- list()
all_profiles <- list()
overlap_rows <- list()

for (group in unique(targets$database_group)) {
  target_group <- targets[database_group == group]
  sets_all <- pathway_sets[[group]]
  set_lookup <- if (group %chin% c("GO-BP", "GO-CC", "GO-MF")) {
    setNames(target_group$pathway_key, target_group$pathway_key)
  } else {
    setNames(target_group$pathway_key, target_group$pathway_key)
  }
  missing_keys <- setdiff(unique(target_group$pathway_key), names(sets_all))
  if (length(missing_keys)) {
    stop("Missing gene set(s) in ", group, ": ", paste(missing_keys, collapse = "; "))
  }
  selected_sets <- sets_all[unique(target_group$pathway_key)]
  overlaps <- vapply(selected_sets, function(x) length(intersect(x, names(stats))), integer(1))
  if (any(overlaps < 5L)) {
    stop("Target pathway has fewer than five ranked genes: ", paste(names(overlaps)[overlaps < 5L], collapse = "; "))
  }

  family_sets <- sets_all
  family_overlap <- vapply(family_sets, function(x) length(intersect(x, names(stats))), integer(1))
  family_sets <- family_sets[family_overlap >= 10L & family_overlap <= 500L]
  fg <- fgseaMultilevel(
    pathways = family_sets,
    stats = stats,
    minSize = 10L,
    maxSize = 500L,
    scoreType = "std",
    eps = 0,
    gseaParam = 1,
    nproc = 1L
  )
  fg <- as.data.table(fg)
  fg[, pathway_key := pathway]
  fg[, pathway := NULL]
  fg[, leadingEdge := vapply(leadingEdge, paste, character(1), collapse = ";")]
  fg[, database_group := group]
  setcolorder(fg, c("database_group", "pathway_key"))
  fwrite(fg, file.path(output_dir, paste0("GSEA_complete_", gsub("-", "_", group), ".csv.gz")))

  target_stats <- merge(target_group, fg, by = c("database_group", "pathway_key"), all.x = TRUE, sort = FALSE)
  setorder(target_stats, target_order)
  if (any(!is.finite(target_stats$NES))) {
    bad <- target_stats[!is.finite(NES), pathway_key]
    stop("No GSEA statistic returned for target: ", paste(bad, collapse = "; "))
  }
  target_stats[, direction := fifelse(NES > 0, "Vitamin D3 high", "Ethanol control high")]
  target_stats[, rank_metric := "DESeq2 Wald statistic (Vitamin D3 vs ethanol control)"]
  target_stats[, FDR_scope := paste0("BH over all testable ", group, " gene sets (overlap 10-500)")]
  all_results[[group]] <- target_stats

  for (key in unique(target_group$pathway_key)) {
    profile <- extract_es_profile(stats, selected_sets[[key]], gsea_param = 1)
    result_row <- target_stats[pathway_key == key][1L]
    if (abs(profile$ES_manual - result_row$ES) > 1e-10) {
      stop("Manual ES does not match fgsea ES for ", key)
    }
    all_profiles[[paste(group, key, sep = "||")]] <- list(
      database_group = group,
      pathway_key = key,
      pathway_label = result_row$pathway_label,
      stats = stats,
      hit_ranks = profile$hit_ranks,
      running_ES = profile$running_ES,
      peak_rank = profile$peak_rank,
      ES = result_row$ES,
      NES = result_row$NES,
      pval = result_row$pval,
      padj = result_row$padj,
      size = result_row$size,
      log2err = result_row$log2err,
      leadingEdge = result_row$leadingEdge,
      direction = result_row$direction
    )
  }

  overlap_rows[[group]] <- data.table(
    database_group = group,
    pathway_key = names(selected_sets),
    gene_set_total = vapply(selected_sets, length, integer(1)),
    ranked_gene_overlap = overlaps,
    family_tested_sets = length(family_sets)
  )
}

target_results <- rbindlist(all_results, fill = TRUE)
setorder(target_results, target_order)
fwrite(target_results, file.path(output_dir, "GSEA_target_pathway_results.csv"))
fwrite(rbindlist(overlap_rows), file.path(output_dir, "GSEA_pathway_overlap_audit.csv"))
saveRDS(
  list(
    input_csv = input_csv,
    targets = targets,
    ranked = ranked,
    target_results = target_results,
    profiles = all_profiles,
    session_info = sessionInfo()
  ),
  file.path(output_dir, "GSEA_analysis_objects.rds"),
  compress = "xz"
)

capture.output(sessionInfo(), file = file.path(output_dir, "R_sessionInfo.txt"))
cat("GSEA complete. Ranked genes:", length(stats), " Target rows:", nrow(target_results), "\n")
