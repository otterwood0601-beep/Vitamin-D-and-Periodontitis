from __future__ import annotations
import importlib.util
import os
import shutil
from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260818_FDR\u5c0f\u4e8e0.05_log2FC\u7edd\u5bf9\u503c\u5927\u4e8e\u7b49\u4e8e1_\u91cd\u65b0\u8f93\u51fa_\u4e0d\u8986\u76d6\u539f\u56fe_v1')
CODE = ROOT / '00_\u4ee3\u7801\u4e0e\u5ba1\u8ba1'
DATA = ROOT / '01_\u6e90\u6570\u636e'
DESKTOP = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u6b63\u6587\u56fe\\\u6b63\u6587\u56fe3 SMR\u548cBulk-RNA')
TMP = ROOT / '02_QA_rendered' / '__tighten_tmp'
TMP.mkdir(parents=True, exist_ok=True)
for fp in ('C:\\Windows\\Fonts\\arial.ttf', 'C:\\Windows\\Fonts\\arialbd.ttf'):
    if os.path.exists(fp):
        fm.fontManager.addfont(fp)
spec = importlib.util.spec_from_file_location('reselect_module', str(CODE / '04_reselect_pathways_and_overwrite_EGH_v2.py'))
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.setup_style()
go = pd.read_csv(DATA / '15_E_GO\u91cd\u9009_3\u81f34\u79cdGeneRatio_\u771f\u5b9e\u540d\u4e0e\u663e\u793a\u540d\u5bf9\u7167.csv')
react = pd.read_csv(DATA / '16_G_Reactome_Count\u8c03\u6574_\u771f\u5b9e\u540d\u4e0e\u663e\u793a\u540d\u5bf9\u7167.csv')
kegg = pd.read_csv(DATA / '17_H_KEGG\u91cd\u9009_4\u79cdGeneRatio_\u771f\u5b9e\u540d\u4e0e\u663e\u793a\u540d\u5bf9\u7167.csv')
desktop_stems = {'E': 'E.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0GO\u901a\u8def\u6c14\u6ce1\u56fe', 'G': 'G.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0Reactome\u901a\u8def\u6c14\u6ce1\u56fe', 'H': 'H.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0KEGG\u901a\u8def\u6c14\u6ce1\u56fe'}
fdr_stems = module.FINAL_NAMES
module.plot_go(go, TMP / f"{fdr_stems['E']}.pdf", TMP / f"{fdr_stems['E']}.png")
module.plot_single_database(react, title='Reactome', pdf_path=TMP / f"{fdr_stems['G']}.pdf", png_path=TMP / f"{fdr_stems['G']}.png", label_width=58, annotate_counts=False)
module.plot_single_database(kegg, title='KEGG', pdf_path=TMP / f"{fdr_stems['H']}.pdf", png_path=TMP / f"{fdr_stems['H']}.png", label_width=54, annotate_counts=False)
for key in ('E', 'G', 'H'):
    stem = fdr_stems[key]
    for suffix in ('.pdf', '.png'):
        src = TMP / f'{stem}{suffix}'
        dst = ROOT / f'{stem}{suffix}'
        shutil.copy2(src, dst)
        print(f'updated 20260818: {dst.name}')
for key in ('E', 'G', 'H'):
    stem = desktop_stems[key]
    src = TMP / f'{fdr_stems[key]}.pdf'
    dst = DESKTOP / f'{stem}.pdf'
    shutil.copy2(src, dst)
    print(f'updated desktop: {dst.name}')
print('Tightened E/G/H regeneration complete.')
