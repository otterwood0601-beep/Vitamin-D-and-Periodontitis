from __future__ import annotations
import argparse
import hashlib
import math
import re
import textwrap
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
import numpy as np
import pandas as pd
plt.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Arial', 'Liberation Sans', 'DejaVu Sans'], 'axes.unicode_minus': False, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none', 'savefig.facecolor': 'white', 'figure.facecolor': 'white'})
FIGURE_SET_ORDER = ['Figure1_all_DEGs', 'Figure2_GDF15_terms']
GROUP_ORDER = ['GO-BP', 'GO-CC', 'GO-MF', 'Reactome', 'KEGG']
SET_DIR = {'Figure1_all_DEGs': '01_Figure1_all_DEGs_terms', 'Figure2_GDF15_terms': '02_Figure2_GDF15_terms'}
SET_FILE = {'Figure1_all_DEGs': 'Figure1_all_DEGs', 'Figure2_GDF15_terms': 'Figure2_GDF15_terms'}
SET_TITLE = {'Figure1_all_DEGs': 'Figure 1 pathway set (full-DEG enrichment figure)', 'Figure2_GDF15_terms': 'Figure 2 pathway set (GDF15 annotation figure)'}
GROUP_DIR = {'GO-BP': '01_GO_BP', 'GO-CC': '02_GO_CC', 'GO-MF': '03_GO_MF', 'Reactome': '04_Reactome', 'KEGG': '05_KEGG'}
GROUP_FILE = {'GO-BP': 'GO_BP', 'GO-CC': 'GO_CC', 'GO-MF': 'GO_MF', 'Reactome': 'Reactome', 'KEGG': 'KEGG'}
GROUP_TITLE = {'GO-BP': 'GO - Biological Process', 'GO-CC': 'GO - Cellular Component', 'GO-MF': 'GO - Molecular Function', 'Reactome': 'Reactome', 'KEGG': 'KEGG'}
POSITIVE = '#F28E2B'
NEGATIVE = '#142B74'
ES_GREEN = '#18B51B'
GRID = '#D8DEE8'
RANK_GREY = '#A9ADB4'
TEXT = '#1F2D3D'
GRADIENT = LinearSegmentedColormap.from_list('d3_control', ['#1D4ED8', '#F7F7F7', '#D62828'], N=256)

def p_text(value: float) -> str:
    if not math.isfinite(value):
        return 'NA'
    if value < 0.001:
        return f'{value:.2e}'
    return f'{value:.3f}'

def slugify(value: str, limit: int=78) -> str:
    value = re.sub('[^A-Za-z0-9]+', '_', value).strip('_')
    return (value or 'pathway')[:limit]

def wrap_label(value: str, width: int) -> str:
    return textwrap.fill(value, width=width, break_long_words=False, break_on_hyphens=False)

def make_bar_figure(rows: pd.DataFrame, figure_set: str, group: str) -> plt.Figure:
    data = rows.copy()
    data['abs_NES'] = data['NES'].abs()
    data = data.sort_values(['abs_NES', 'target_order'], ascending=[False, True])
    wrapped = [wrap_label(x, 53) for x in data['pathway_label']]
    line_count = sum((x.count('\n') + 1 for x in wrapped))
    height = max(7.2, min(15.0, 2.8 + 0.44 * line_count))
    fig, ax = plt.subplots(figsize=(13.5, height))
    y = np.arange(len(data))
    colors = np.where(data['NES'].to_numpy() > 0, POSITIVE, NEGATIVE)
    ax.barh(y, data['NES'], color=colors, height=0.72, edgecolor='none')
    ax.set_yticks(y, labels=wrapped)
    ax.invert_yaxis()
    max_abs = max(1.0, float(data['abs_NES'].max()))
    limit = math.ceil(max_abs * 1.28 * 10) / 10
    ax.set_xlim(-limit, limit)
    ax.axvline(0, color='#222222', linewidth=1.15, zorder=3)
    ax.xaxis.grid(True, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    ax.set_xlabel('Normalized enrichment score (NES)', fontsize=12, color=TEXT, labelpad=10)
    ax.tick_params(axis='x', labelsize=10, colors=TEXT)
    ax.tick_params(axis='y', labelsize=9.2 if len(data) <= 10 else 8.4, colors=TEXT, length=0, pad=7)
    for spine in ['top', 'right', 'left']:
        ax.spines[spine].set_visible(False)
    ax.spines['bottom'].set_color('#4B5563')
    for yi, nes in zip(y, data['NES']):
        offset = limit * 0.025
        ax.text(nes + (offset if nes >= 0 else -offset), yi, f'{nes:+.3f}', va='center', ha='left' if nes >= 0 else 'right', fontsize=8.5, color=TEXT)
    fig.suptitle(f'{SET_TITLE[figure_set]}\n{GROUP_TITLE[group]}', x=0.52, y=0.965, fontsize=16, fontweight='bold', color=TEXT)
    ax.set_title('Pre-specified pathways ordered by absolute NES', fontsize=10.5, color='#596579', pad=14)
    legend = [Patch(facecolor=POSITIVE, label='NES > 0: Vitamin D3 high'), Patch(facecolor=NEGATIVE, label='NES < 0: ethanol control high')]
    fig.legend(handles=legend, loc='lower center', bbox_to_anchor=(0.68, 0.057), frameon=False, ncol=2, fontsize=9.5)
    fig.text(0.5, 0.014, 'Ranking metric: DESeq2 Wald statistic (Vitamin D3 vs ethanol control).', ha='center', va='bottom', fontsize=8.5, color='#596579')
    left = 0.48 if group in {'Reactome', 'KEGG'} else 0.43
    fig.subplots_adjust(left=left, right=0.965, top=0.84, bottom=0.185)
    return fig

def make_enrichment_figure(row: pd.Series, profile: pd.DataFrame, ranked_stats: np.ndarray, figure_set: str, group: str) -> plt.Figure:
    ranks = profile['rank'].to_numpy(dtype=int)
    running = profile['running_ES'].to_numpy(dtype=float)
    hits = profile.loc[profile['hit'], 'rank'].to_numpy(dtype=int)
    n = len(ranks)
    peak_rank = int(np.argmax(running) + 1) if float(row['ES']) >= 0 else int(np.argmin(running) + 1)
    peak_es = float(running[peak_rank - 1])
    fig = plt.figure(figsize=(11.69, 8.27))
    outer = fig.add_gridspec(3, 1, height_ratios=[3.45, 0.8, 2.35], hspace=0.07, left=0.105, right=0.965, top=0.835, bottom=0.13)
    ax_es = fig.add_subplot(outer[0])
    ax_hit = fig.add_subplot(outer[1], sharex=ax_es)
    bottom = outer[2].subgridspec(2, 1, height_ratios=[0.34, 1.66], hspace=0.025)
    ax_grad = fig.add_subplot(bottom[0], sharex=ax_es)
    ax_rank = fig.add_subplot(bottom[1], sharex=ax_es)
    leading_start, leading_end = (1, peak_rank) if peak_es >= 0 else (peak_rank, n)
    ax_es.axvspan(leading_start, leading_end, color='#B7E4C7', alpha=0.28, lw=0)
    ax_es.plot(ranks, running, color=ES_GREEN, linewidth=2.15)
    ax_es.axhline(0, color='#6B7280', linewidth=0.8)
    ax_es.axvline(peak_rank, color='#789C7A', linestyle='--', linewidth=1.0)
    ax_es.scatter([peak_rank], [peak_es], s=30, color=ES_GREEN, zorder=4)
    ax_es.set_ylabel('Enrichment score (ES)', fontsize=10.5, color=TEXT)
    ax_es.tick_params(axis='x', labelbottom=False, length=0)
    ax_es.tick_params(axis='y', labelsize=9, colors=TEXT)
    ax_es.grid(True, axis='both', color=GRID, linewidth=0.65, linestyle='--', alpha=0.8)
    ax_es.set_axisbelow(True)
    ax_es.spines[['top', 'right']].set_visible(False)
    y_span = max(0.08, float(np.ptp(running)))
    if peak_es >= 0:
        xytext = (min(n * 0.9, peak_rank + n * 0.08), peak_es - y_span * 0.18)
    else:
        xytext = (max(n * 0.08, peak_rank - n * 0.18), peak_es + y_span * 0.18)
    ax_es.annotate('Leading edge', xy=(peak_rank, peak_es), xytext=xytext, fontsize=9, color='#2D6A4F', ha='center', arrowprops=dict(arrowstyle='->', color='#2D6A4F', lw=0.9))
    stat_box = f"NES = {float(row['NES']):+.3f}\nFDR q-value = {p_text(float(row['padj']))}\nNominal P = {p_text(float(row['pval']))}\nGene set size = {int(row['size'])}"
    ax_es.text(0.985, 0.96, stat_box, transform=ax_es.transAxes, va='top', ha='right', fontsize=9.2, color=TEXT, bbox=dict(boxstyle='round,pad=0.42', facecolor='white', edgecolor='#AAB2BF', alpha=0.94))
    ax_hit.vlines(hits, 0, 1, color='#111111', linewidth=0.55)
    ax_hit.set_ylim(0, 1)
    ax_hit.set_yticks([])
    ax_hit.set_ylabel('Hits', fontsize=9.5, color=TEXT, rotation=0, labelpad=26, va='center')
    ax_hit.tick_params(axis='x', labelbottom=False, length=0)
    ax_hit.spines[['top', 'right', 'left']].set_visible(False)
    ax_hit.spines['bottom'].set_color('#9CA3AF')
    gradient = np.linspace(1, -1, 512)[None, :]
    ax_grad.imshow(gradient, aspect='auto', cmap=GRADIENT, vmin=-1, vmax=1, extent=[1, n, 0, 1], interpolation='bilinear')
    ax_grad.set_yticks([])
    ax_grad.tick_params(axis='x', labelbottom=False, length=0)
    ax_grad.spines[:].set_visible(False)
    ax_grad.text(0.012, 0.5, 'Vitamin D3 high', transform=ax_grad.transAxes, ha='left', va='center', fontsize=8.5, fontweight='bold', color='#7F1D1D', bbox=dict(facecolor='white', edgecolor='none', alpha=0.68, pad=1.5))
    ax_grad.text(0.988, 0.5, 'Ethanol control high', transform=ax_grad.transAxes, ha='right', va='center', fontsize=8.5, fontweight='bold', color='#1E3A8A', bbox=dict(facecolor='white', edgecolor='none', alpha=0.68, pad=1.5))
    ax_rank.fill_between(ranks, ranked_stats, 0, color=RANK_GREY, linewidth=0, alpha=0.92)
    ax_rank.plot(ranks, ranked_stats, color='#858A91', linewidth=0.45)
    ax_rank.axhline(0, color='#6B7280', linewidth=0.65)
    zero_candidates = np.where(ranked_stats <= 0)[0]
    zero_rank = int(zero_candidates[0] + 1) if len(zero_candidates) else n
    ax_rank.axvline(zero_rank, color='#6B7280', linestyle='--', linewidth=0.8)
    ax_rank.text(zero_rank, ax_rank.get_ylim()[1] * 0.82, f'Zero cross at {zero_rank:,}', fontsize=8.2, color='#4B5563', ha='center', va='top', bbox=dict(facecolor='white', edgecolor='none', alpha=0.75, pad=1.5))
    ax_rank.set_ylabel('Ranking metric\n(Wald statistic)', fontsize=9.5, color=TEXT)
    ax_rank.set_xlabel('Rank in ordered dataset', fontsize=10.5, color=TEXT, labelpad=7)
    ax_rank.tick_params(axis='both', labelsize=8.8, colors=TEXT)
    ax_rank.spines[['top', 'right']].set_visible(False)
    ax_rank.grid(True, axis='x', color=GRID, linewidth=0.65, linestyle='--')
    ax_rank.set_axisbelow(True)
    ax_rank.set_xlim(1, n)
    title = wrap_label(str(row['pathway_label']), 88)
    fig.suptitle(f'Enrichment plot: {title}', fontsize=15.5, fontweight='bold', color=TEXT, y=0.965)
    fig.text(0.5, 0.895, f'{SET_TITLE[figure_set]} | {GROUP_TITLE[group]}', ha='center', va='center', fontsize=9.6, color='#596579')
    fig.legend(handles=[Line2D([0], [0], color=ES_GREEN, lw=2.1, label='Enrichment profile'), Line2D([0], [0], color='#111111', lw=1.0, label='Gene-set hits'), Patch(facecolor='#B7E4C7', alpha=0.45, label='Leading-edge region'), Patch(facecolor=RANK_GREY, label='Ranking metric')], loc='lower center', bbox_to_anchor=(0.5, 0.02), ncol=4, frameon=False, fontsize=8.8)
    return fig

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest().upper()

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('analysis_dir', type=Path)
    parser.add_argument('output_root', type=Path)
    args = parser.parse_args()
    analysis_dir = args.analysis_dir.resolve()
    output_root = args.output_root.resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    target = pd.read_csv(analysis_dir / 'GSEA_target_pathway_results.csv')
    metadata = pd.read_csv(analysis_dir / 'GSEA_profile_metadata.csv')
    points = pd.read_csv(analysis_dir / 'GSEA_profile_points.csv.gz')
    ranked = pd.read_csv(analysis_dir / 'GSE212728_DESeq2_Wald_ranked_genes.csv.gz')
    target['NES'] = pd.to_numeric(target['NES'], errors='raise')
    target['pval'] = pd.to_numeric(target['pval'], errors='raise')
    target['padj'] = pd.to_numeric(target['padj'], errors='raise')
    target['ES'] = pd.to_numeric(target['ES'], errors='raise')
    target['size'] = pd.to_numeric(target['size'], errors='raise').astype(int)
    target['target_order'] = pd.to_numeric(target['target_order'], errors='raise').astype(int)
    points['hit'] = points['hit'].astype(str).str.lower().eq('true')
    ranked_stats = ranked.sort_values('rank')['stat'].to_numpy(dtype=float)
    expected = {('Figure1_all_DEGs', 'GO-BP'): 5, ('Figure1_all_DEGs', 'GO-CC'): 5, ('Figure1_all_DEGs', 'GO-MF'): 5, ('Figure1_all_DEGs', 'Reactome'): 15, ('Figure1_all_DEGs', 'KEGG'): 16, ('Figure2_GDF15_terms', 'GO-BP'): 5, ('Figure2_GDF15_terms', 'GO-CC'): 5, ('Figure2_GDF15_terms', 'GO-MF'): 5, ('Figure2_GDF15_terms', 'Reactome'): 5, ('Figure2_GDF15_terms', 'KEGG'): 5}
    if len(target) != 71 or target[['figure_set', 'database_group', 'pathway_label']].duplicated().any():
        raise RuntimeError('Target pathway table is not the expected 71 unique display rows')
    if target[['NES', 'pval', 'padj', 'ES']].isna().any().any():
        raise RuntimeError('Missing GSEA statistics in target results')
    profile_map = {key: frame.sort_values('rank') for key, frame in points.groupby('profile_id', sort=False)}
    manifest_rows: list[dict[str, object]] = []
    figure_table_rows: list[pd.DataFrame] = []
    for figure_set in FIGURE_SET_ORDER:
        for group in GROUP_ORDER:
            rows = target[(target['figure_set'] == figure_set) & (target['database_group'] == group)].copy()
            rows = rows.sort_values('target_order')
            if len(rows) != expected[figure_set, group]:
                raise RuntimeError(f'Unexpected target count for {figure_set} / {group}: {len(rows)}')
            group_dir = output_root / SET_DIR[figure_set] / GROUP_DIR[group]
            pathway_dir = group_dir / 'single_pathway_enrichment_plots'
            pathway_dir.mkdir(parents=True, exist_ok=True)
            stem = f'{SET_FILE[figure_set]}_{GROUP_FILE[group]}'
            pdf_path = group_dir / f'{stem}_GSEA_collection.pdf'
            bar_png = group_dir / f'{stem}_NES_bar.png'
            bar_svg = group_dir / f'{stem}_NES_bar.svg'
            with PdfPages(pdf_path) as pdf:
                bar_fig = make_bar_figure(rows, figure_set, group)
                bar_fig.savefig(bar_png, dpi=400, bbox_inches='tight')
                bar_fig.savefig(bar_svg, bbox_inches='tight')
                pdf.savefig(bar_fig, bbox_inches='tight')
                plt.close(bar_fig)
                for local_order, (_, row) in enumerate(rows.iterrows(), start=1):
                    profile_id = f"{group}||{row['pathway_key']}"
                    if profile_id not in profile_map:
                        raise RuntimeError(f'Missing ES profile: {profile_id}')
                    profile = profile_map[profile_id]
                    if len(profile) != len(ranked_stats):
                        raise RuntimeError(f'Profile length mismatch: {profile_id}')
                    fig = make_enrichment_figure(row, profile, ranked_stats, figure_set, group)
                    file_stem = f"{local_order:02d}_{slugify(str(row['pathway_label']))}"
                    png_path = pathway_dir / f'{file_stem}.png'
                    svg_path = pathway_dir / f'{file_stem}.svg'
                    fig.savefig(png_path, dpi=400, bbox_inches='tight')
                    fig.savefig(svg_path, bbox_inches='tight')
                    pdf.savefig(fig, bbox_inches='tight')
                    plt.close(fig)
            manifest_rows.append({'figure_set': figure_set, 'database_group': group, 'pathway_count': len(rows), 'expected_pdf_pages': len(rows) + 1, 'collection_pdf': str(pdf_path), 'nes_bar_png': str(bar_png), 'nes_bar_svg': str(bar_svg), 'pdf_sha256': sha256(pdf_path)})
            table = rows.copy()
            table.insert(0, 'within_group_order', np.arange(1, len(table) + 1))
            table['NES_direction'] = np.where(table['NES'] > 0, 'Vitamin D3 high', 'Ethanol control high')
            table['collection_pdf'] = str(pdf_path)
            figure_table_rows.append(table)
    audit_dir = output_root / '03_results_and_reproducibility'
    audit_dir.mkdir(parents=True, exist_ok=True)
    manifest = pd.DataFrame(manifest_rows)
    manifest.to_csv(audit_dir / 'GSEA_render_manifest.csv', index=False, encoding='utf-8-sig')
    plot_table = pd.concat(figure_table_rows, ignore_index=True)
    plot_table.to_csv(audit_dir / 'GSEA_target_pathway_results_plot_ready.csv', index=False, encoding='utf-8-sig')
    print(f'Rendered {len(manifest)} independent collections and {len(plot_table)} pathway pages')
if __name__ == '__main__':
    main()
