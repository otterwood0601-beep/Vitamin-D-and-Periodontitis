options(stringsAsFactors = FALSE)

default_out_root <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260818_FDR\u5c0f\u4e8e0.05_log2FC\u7edd\u5bf9\u503c\u5927\u4e8e\u7b49\u4e8e1_\u91cd\u65b0\u8f93\u51fa_\u4e0d\u8986\u76d6\u539f\u56fe_v1"
out_root <- Sys.getenv("FIG3_REDO_OUT_ROOT", unset = default_out_root)
source_stage <- Sys.getenv("FIG3_REDO_SOURCE_STAGE", unset = "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/03_Bulk_RNA/12_GSE212728_\u539f\u59cbRNAseq_DESeq2_Figure3C-G")
de_path <- file.path(source_stage, "02_DESeq2_genome", "11_DESeq2_D3_vs_ethanol_all_genes.csv")
object_path <- file.path(source_stage, "05_QA_genome", "GSE212728_DESeq2_enrichment_object.rds")
reactome_gmt <- Sys.getenv(
  "FIG3_REDO_REACTOME_GMT",
  unset = "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/03_Bulk_RNA/12_GSE212728_\u539f\u59cbRNAseq_DESeq2_Figure3C-G/00_\u6570\u636e\u5ba1\u8ba1/Reactome_Pathways_2024.gmt"
)

code_dir <- Sys.getenv("FIG3_REDO_CODE_DIR", unset = file.path(out_root, "00_\u4ee3\u7801\u4e0e\u5ba1\u8ba1"))
data_dir <- Sys.getenv("FIG3_REDO_DATA_DIR", unset = file.path(out_root, "01_\u6e90\u6570\u636e"))
dir.create(code_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(data_dir, recursive = TRUE, showWarnings = FALSE)

.libPaths(c(
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_enrichment",
  "C:/Users/Lin/AppData/Local/R/win-library/4.5",
  .libPaths()
))

suppressPackageStartupMessages({
  library(DESeq2)
  library(SummarizedExperiment)
  library(AnnotationDbi)
  library(org.Hs.eg.db)
  library(clusterProfiler)
  library(ggplot2)
  library(ggrepel)
  library(pheatmap)
  library(grid)
  library(httr)
  library(jsonlite)
})

stopifnot(file.exists(de_path), file.exists(object_path), file.exists(reactome_gmt))

log2fc_cutoff <- 1
fdr_cutoff <- 0.05

de <- read.csv(de_path, check.names = FALSE)
analysis <- readRDS(object_path)
vsd_matrix <- assay(analysis$vsd)

required <- c("gene_id", "gene_symbol", "log2FoldChange", "pvalue", "padj")
if (!all(required %in% names(de))) {
  stop("The authoritative DESeq2 table is missing required columns.")
}

for (column in c("log2FoldChange", "pvalue", "padj", "baseMean")) {
  de[[column]] <- as.numeric(de[[column]])
}

de$new_DEG <- (
  !is.na(de$padj) &
    de$padj < fdr_cutoff &
    !is.na(de$log2FoldChange) &
    abs(de$log2FoldChange) >= log2fc_cutoff
)
de$new_direction <- ifelse(
  de$new_DEG,
  ifelse(de$log2FoldChange > 0, "Up", "Down"),
  "Not significant"
)

qualified_rows <- de[de$new_DEG, , drop = FALSE]
qualified_rows <- qualified_rows[
  order(qualified_rows$padj, qualified_rows$pvalue, -abs(qualified_rows$log2FoldChange)),
  ,
  drop = FALSE
]

qualified_symbols <- qualified_rows[
  !is.na(qualified_rows$gene_symbol) & nzchar(qualified_rows$gene_symbol),
  ,
  drop = FALSE
]
qualified_symbols <- qualified_symbols[!duplicated(qualified_symbols$gene_symbol), , drop = FALSE]

tested_symbols <- unique(de$gene_symbol[
  !is.na(de$pvalue) &
    !is.na(de$gene_symbol) &
    nzchar(de$gene_symbol)
])
deg_symbols <- unique(qualified_symbols$gene_symbol)

write.csv(
  de,
  file.path(data_dir, "01_DESeq2_all_genes_with_new_classification.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)
write.csv(
  qualified_rows,
  file.path(data_dir, "02_FDR005_absLog2FC1_DEGs.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)
writeLines(
  deg_symbols,
  file.path(data_dir, "03_enrichment_input_DEG_SYMBOLs.txt"),
  useBytes = TRUE
)

heat_rows <- qualified_symbols[
  qualified_symbols$gene_id %in% rownames(vsd_matrix),
  ,
  drop = FALSE
]
if (!nrow(heat_rows)) {
  stop("No uniquely named eligible genes are present in the VST matrix.")
}

sample_order <- c("Control_rep1", "Control_rep2", "D3_rep1", "D3_rep2", "D3_rep3")
if (!all(sample_order %in% colnames(vsd_matrix))) {
  stop("The expected five sample columns are missing from the VST matrix.")
}

heat_matrix <- vsd_matrix[heat_rows$gene_id, sample_order, drop = FALSE]
rownames(heat_matrix) <- make.unique(as.character(heat_rows$gene_symbol))
heat_z <- t(scale(t(heat_matrix)))
heat_z[!is.finite(heat_z)] <- 0
heat_z <- pmax(pmin(heat_z, 2.5), -2.5)

heat_annotation <- data.frame(
  Group = factor(
    c("Ethanol control", "Ethanol control", "Vitamin D3", "Vitamin D3", "Vitamin D3"),
    levels = c("Ethanol control", "Vitamin D3")
  ),
  row.names = sample_order
)
heat_colours <- list(
  Group = c("Ethanol control" = "#95A5A6", "Vitamin D3" = "#E76F51")
)

heatmap_object <- pheatmap(
  heat_z,
  cluster_rows = TRUE,
  cluster_cols = FALSE,
  show_rownames = TRUE,
  show_colnames = TRUE,
  annotation_col = heat_annotation,
  annotation_colors = heat_colours,
  color = colorRampPalette(c("#2166AC", "#F7F7F7", "#B2182B"))(101),
  breaks = seq(-2.5, 2.5, length.out = 102),
  border_color = NA,
  fontsize_row = 6.5,
  fontsize_col = 9,
  angle_col = 45,
  silent = TRUE
)

b_height <- max(9.2, 2.5 + 0.15 * nrow(heat_rows))
b_pdf <- file.path(out_root, "B_heatmap_all_FDR005_absLog2FC1.pdf")
b_png <- file.path(out_root, "B_heatmap_all_FDR005_absLog2FC1.png")
cairo_pdf(b_pdf, width = 7.8, height = b_height, family = "Arial", bg = "white")
grid.newpage()
grid.draw(heatmap_object$gtable)
dev.off()
png(b_png, width = 7.8, height = b_height, units = "in", res = 240, type = "cairo", bg = "white")
grid.newpage()
grid.draw(heatmap_object$gtable)
dev.off()

heat_export <- cbind(
  heatmap_rank = seq_len(nrow(heat_rows)),
  heat_rows[, c("gene_id", "gene_symbol", "baseMean", "log2FoldChange", "pvalue", "padj")],
  as.data.frame(heat_z, check.names = FALSE)
)
write.csv(
  heat_export,
  file.path(data_dir, "04_B_all_eligible_genes_row_zscores.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

volcano <- de[
  is.finite(de$log2FoldChange) & !is.na(de$pvalue) & is.finite(de$pvalue),
  ,
  drop = FALSE
]
volcano$display_fdr <- ifelse(is.na(volcano$padj), 1, volcano$padj)
volcano$minus_log10_fdr <- -log10(pmax(volcano$display_fdr, 1e-300))
volcano$plot_group <- factor(
  volcano$new_direction,
  levels = c("Down", "Not significant", "Up")
)

figure_c <- ggplot(volcano, aes(x = log2FoldChange, y = minus_log10_fdr)) +
  geom_point(aes(colour = plot_group), alpha = 0.62, size = 1.25) +
  geom_vline(
    xintercept = c(-log2fc_cutoff, log2fc_cutoff),
    linetype = "dashed",
    colour = "#666666",
    linewidth = 0.45
  ) +
  geom_hline(
    yintercept = -log10(fdr_cutoff),
    linetype = "dashed",
    colour = "#666666",
    linewidth = 0.45
  ) +
  scale_colour_manual(
    values = c("Down" = "#2C7BB6", "Not significant" = "#B9B9B9", "Up" = "#D7191C"),
    drop = FALSE
  ) +
  labs(
    x = "log2 fold change",
    y = "-log10(FDR)",
    colour = NULL
  ) +
  theme_bw(base_size = 11) +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(colour = "#ECECEC", linewidth = 0.3),
    panel.border = element_rect(colour = "#444444", linewidth = 0.5),
    axis.text = element_text(colour = "#333333"),
    axis.title = element_text(colour = "#111111"),
    legend.position = "top",
    legend.direction = "horizontal",
    plot.margin = margin(10, 14, 10, 10)
  )

c_pdf <- file.path(out_root, "C_volcano_FDR005_absLog2FC1.pdf")
c_png <- file.path(out_root, "C_volcano_FDR005_absLog2FC1.png")
ggsave(c_pdf, figure_c, width = 8.2, height = 6.2, device = cairo_pdf, bg = "white")
ggsave(c_png, figure_c, width = 8.2, height = 6.2, dpi = 360, bg = "white")

volcano_export <- volcano[, c(
  "gene_id", "gene_symbol", "baseMean", "log2FoldChange", "pvalue", "padj",
  "new_DEG", "new_direction", "minus_log10_fdr"
)]
write.csv(
  volcano_export,
  file.path(data_dir, "05_C_volcano_source_data.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

parse_ratio <- function(x) {
  parts <- strsplit(as.character(x), "/", fixed = TRUE)
  vapply(parts, function(value) as.numeric(value[1]) / as.numeric(value[2]), numeric(1))
}

select_by_gene_ratio <- function(frame, number) {
  if (!nrow(frame)) {
    return(frame)
  }
  frame$GeneRatioNumeric <- parse_ratio(frame$GeneRatio)
  nominal <- frame[!is.na(frame$pvalue) & frame$pvalue < 0.05, , drop = FALSE]
  if (nrow(nominal) < number) {
    nominal <- frame[order(frame$pvalue, frame$p.adjust), , drop = FALSE]
  }
  nominal <- nominal[
    order(-nominal$GeneRatioNumeric, nominal$pvalue, nominal$p.adjust, nominal$Description),
    ,
    drop = FALSE
  ]
  head(nominal, number)
}

universe_map <- bitr(
  tested_symbols,
  fromType = "SYMBOL",
  toType = "ENTREZID",
  OrgDb = org.Hs.eg.db
)
deg_map <- bitr(
  deg_symbols,
  fromType = "SYMBOL",
  toType = "ENTREZID",
  OrgDb = org.Hs.eg.db
)
universe_entrez <- unique(universe_map$ENTREZID)
deg_entrez <- unique(deg_map$ENTREZID)

write.csv(
  deg_map,
  file.path(data_dir, "06_DEG_SYMBOL_to_ENTREZID.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

go_parts <- list()
for (ontology in c("BP", "CC", "MF")) {
  result <- enrichGO(
    gene = deg_entrez,
    universe = universe_entrez,
    OrgDb = org.Hs.eg.db,
    keyType = "ENTREZID",
    ont = ontology,
    pAdjustMethod = "BH",
    pvalueCutoff = 1,
    qvalueCutoff = 1,
    minGSSize = 10,
    maxGSSize = 500,
    readable = TRUE
  )
  frame <- as.data.frame(result)
  if (nrow(frame)) {
    frame$ONTOLOGY <- ontology
    go_parts[[ontology]] <- frame
  }
}
go_all <- do.call(rbind, go_parts)
rownames(go_all) <- NULL
go_display <- do.call(rbind, lapply(c("BP", "CC", "MF"), function(ontology) {
  select_by_gene_ratio(go_all[go_all$ONTOLOGY == ontology, , drop = FALSE], 5L)
}))
rownames(go_display) <- NULL

write.csv(go_all, file.path(data_dir, "07_GO_BP_CC_MF_all_results.csv"), row.names = FALSE, fileEncoding = "UTF-8")
write.csv(go_display, file.path(data_dir, "08_E_GO_top5_GeneRatio_per_ontology.csv"), row.names = FALSE, fileEncoding = "UTF-8")

read_reactome_gmt <- function(path) {
  lines <- readLines(path, warn = FALSE, encoding = "UTF-8")
  parsed <- lapply(lines, function(line) {
    fields <- strsplit(line, "\t", fixed = TRUE)[[1]]
    if (length(fields) < 3L) {
      return(NULL)
    }
    term <- fields[1]
    description <- ifelse(nzchar(fields[2]), fields[2], fields[1])
    genes <- unique(toupper(fields[-c(1, 2)]))
    genes <- genes[nzchar(genes)]
    list(
      term2gene = data.frame(term = term, gene = genes, stringsAsFactors = FALSE),
      term2name = data.frame(term = term, name = description, stringsAsFactors = FALSE)
    )
  })
  parsed <- Filter(Negate(is.null), parsed)
  list(
    TERM2GENE = unique(do.call(rbind, lapply(parsed, `[[`, "term2gene"))),
    TERM2NAME = unique(do.call(rbind, lapply(parsed, `[[`, "term2name")))
  )
}

reactome_terms <- read_reactome_gmt(reactome_gmt)
reactome_result <- enricher(
  gene = deg_symbols,
  universe = tested_symbols,
  TERM2GENE = reactome_terms$TERM2GENE,
  TERM2NAME = reactome_terms$TERM2NAME,
  pvalueCutoff = 1,
  pAdjustMethod = "BH",
  qvalueCutoff = 1,
  minGSSize = 10,
  maxGSSize = 500
)
reactome_all <- as.data.frame(reactome_result)
reactome_display <- select_by_gene_ratio(reactome_all, 15L)
write.csv(reactome_all, file.path(data_dir, "09_Reactome_all_results.csv"), row.names = FALSE, fileEncoding = "UTF-8")
write.csv(reactome_display, file.path(data_dir, "10_G_Reactome_top15_GeneRatio.csv"), row.names = FALSE, fileEncoding = "UTF-8")

add_response <- POST(
  "https://maayanlab.cloud/Enrichr/addList",
  body = list(
    list = upload_file(
      file.path(data_dir, "03_enrichment_input_DEG_SYMBOLs.txt"),
      type = "text/plain"
    ),
    description = "GSE212728 FDR<0.05 and abs(log2FC)>=1"
  ),
  encode = "multipart",
  timeout(120)
)
stop_for_status(add_response)
user_list_id <- content(add_response, as = "parsed", type = "application/json")$userListId

kegg_response <- GET(
  "https://maayanlab.cloud/Enrichr/enrich",
  query = list(userListId = user_list_id, backgroundType = "KEGG_2026"),
  timeout(120)
)
stop_for_status(kegg_response)
kegg_raw <- content(kegg_response, as = "raw")
writeBin(kegg_raw, file.path(data_dir, "11_KEGG_2026_Enrichr_raw_response.json"))
kegg_parsed <- fromJSON(rawToChar(kegg_raw), simplifyVector = FALSE)[["KEGG_2026"]]

kegg_rows <- lapply(kegg_parsed, function(row) {
  overlap <- paste(unlist(row[[6]]), collapse = ";")
  overlap_count <- if (nzchar(overlap)) length(strsplit(overlap, ";", fixed = TRUE)[[1]]) else 0L
  data.frame(
    database = "KEGG",
    library = "KEGG_2026",
    rank = as.integer(row[[1]]),
    term = as.character(row[[2]]),
    p_value = as.numeric(row[[3]]),
    z_score = as.numeric(row[[4]]),
    combined_score = as.numeric(row[[5]]),
    overlap_genes = overlap,
    adjusted_p = as.numeric(row[[7]]),
    old_p = as.numeric(row[[8]]),
    old_adjusted_p = as.numeric(row[[9]]),
    overlap_count = overlap_count,
    query_size = length(deg_symbols),
    gene_ratio = overlap_count / length(deg_symbols),
    method = "Enrichr over-representation analysis",
    stringsAsFactors = FALSE
  )
})
kegg_all <- do.call(rbind, kegg_rows)
kegg_display <- kegg_all[kegg_all$p_value < 0.05, , drop = FALSE]
kegg_display <- kegg_display[
  order(-kegg_display$gene_ratio, kegg_display$p_value, kegg_display$adjusted_p, kegg_display$term),
  ,
  drop = FALSE
]
kegg_display <- head(kegg_display, 15L)

write.csv(kegg_all, file.path(data_dir, "12_KEGG_2026_all_results.csv"), row.names = FALSE, fileEncoding = "UTF-8")
write.csv(kegg_display, file.path(data_dir, "13_H_KEGG_top15_GeneRatio.csv"), row.names = FALSE, fileEncoding = "UTF-8")

target_status <- de[
  !is.na(de$gene_symbol) & de$gene_symbol %in% c("GDF15", "PLAU"),
  c("gene_id", "gene_symbol", "log2FoldChange", "pvalue", "padj", "new_DEG", "new_direction")
]
write.csv(target_status, file.path(data_dir, "14_GDF15_PLAU_new_threshold_status.csv"), row.names = FALSE, fileEncoding = "UTF-8")

summary <- list(
  dataset = "GSE212728",
  source_full_DE_table = de_path,
  source_VST_object = object_path,
  source_Reactome_GMT = reactome_gmt,
  samples = list(ethanol_control = 2L, vitamin_D3 = 3L),
  contrast = "Vitamin D3 versus ethanol control",
  threshold = "absolute log2 fold change >= 1 and BH FDR < 0.05",
  total_rows = nrow(de),
  qualifying_gene_rows = nrow(qualified_rows),
  qualifying_unique_symbols = length(deg_symbols),
  up = sum(qualified_rows$log2FoldChange > 0),
  down = sum(qualified_rows$log2FoldChange < 0),
  heatmap_display_rule = "top 40 eligible unique gene symbols ordered by BH FDR, then raw P",
  heatmap_rows = nrow(heat_rows),
  GO_input_mapped_ENTREZ = length(deg_entrez),
  GO_all_terms = nrow(go_all),
  GO_display_terms = nrow(go_display),
  Reactome_all_terms = nrow(reactome_all),
  Reactome_display_terms = nrow(reactome_display),
  KEGG_library = "Enrichr KEGG_2026",
  KEGG_all_terms = nrow(kegg_all),
  KEGG_display_terms = nrow(kegg_display),
  target_status = target_status,
  generated_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %z")
)
write_json(
  summary,
  file.path(code_dir, "analysis_and_filter_audit.json"),
  auto_unbox = TRUE,
  pretty = TRUE,
  digits = 12,
  na = "null"
)
writeLines(
  capture.output(sessionInfo()),
  file.path(code_dir, "R_sessionInfo.txt"),
  useBytes = TRUE
)

cat(
  sprintf(
    "DEG_ROWS=%d UNIQUE_SYMBOLS=%d UP=%d DOWN=%d GO_DISPLAY=%d REACTOME_DISPLAY=%d KEGG_DISPLAY=%d\n",
    nrow(qualified_rows), length(deg_symbols),
    sum(qualified_rows$log2FoldChange > 0), sum(qualified_rows$log2FoldChange < 0),
    nrow(go_display), nrow(reactome_display), nrow(kegg_display)
  )
)
