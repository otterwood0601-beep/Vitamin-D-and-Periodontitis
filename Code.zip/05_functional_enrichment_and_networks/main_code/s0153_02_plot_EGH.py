from __future__ import annotations
import math
import textwrap
from pathlib import Path
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap, LogNorm
OUT_ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260818_FDR\u5c0f\u4e8e0.05_log2FC\u7edd\u5bf9\u503c\u5927\u4e8e\u7b49\u4e8e1_\u5168\u5dee\u5f02\u57fa\u56e0\u70ed\u56fe_\u706b\u5c71\u56feX\u8f74\u6b63\u8d1f5_\u989d\u5916\u51fa\u7a3f_v1')
DATA_DIR = OUT_ROOT / '01_\u6e90\u6570\u636e'
B_ASCII_STEM = 'B_heatmap_all_FDR005_absLog2FC1'
C_ASCII_STEM = 'C_volcano_xlim5_FDR005_absLog2FC1'
B_FINAL_STEM = 'B.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5168\u90e8\u5dee\u5f02\u57fa\u56e0\u70ed\u56fe\uff08FDR\u5c0f\u4e8e0.05_log2FC\u7edd\u5bf9\u503c\u5927\u4e8e\u7b49\u4e8e1\uff09'
C_FINAL_STEM = 'C.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0\u706b\u5c71\u56fe\uff08FDR\u5c0f\u4e8e0.05_log2FC\u7edd\u5bf9\u503c\u5927\u4e8e\u7b49\u4e8e1_X\u8f74\u6b63\u8d1f5\uff09'
mpl.rcParams.update({'font.family': 'Arial', 'font.size': 10.5, 'axes.titlesize': 12.0, 'axes.titleweight': 'bold', 'axes.labelsize': 10.5, 'xtick.labelsize': 9.5, 'ytick.labelsize': 9.5, 'axes.edgecolor': '#777777', 'axes.linewidth': 0.6, 'text.color': '#26374A', 'axes.labelcolor': '#26374A', 'xtick.color': '#26374A', 'ytick.color': '#26374A', 'pdf.fonttype': 42, 'ps.fonttype': 42})
CMAP = LinearSegmentedColormap.from_list('low_p_red_high_p_blue', ['#E8645A', '#B57A91', '#2189B5'])
GRID = '#D9E2EA'
EDGE = '#435262'

def ratio_to_float(value: str) -> float:
    numerator, denominator = str(value).split('/', maxsplit=1)
    return float(numerator) / float(denominator)

def marker_prefix(gene_string: str) -> str:
    genes = {part.strip().upper() for part in str(gene_string).split('/') if part.strip()}
    has_gdf15 = 'GDF15' in genes
    has_plau = 'PLAU' in genes
    if has_gdf15 and has_plau:
        return '*+ '
    if has_gdf15:
        return '* '
    if has_plau:
        return '+ '
    return ''

def marker_prefix_semicolon(gene_string: str) -> str:
    genes = {part.strip().upper() for part in str(gene_string).split(';') if part.strip()}
    has_gdf15 = 'GDF15' in genes
    has_plau = 'PLAU' in genes
    if has_gdf15 and has_plau:
        return '*+ '
    if has_gdf15:
        return '* '
    if has_plau:
        return '+ '
    return ''

def point_sizes(counts: np.ndarray, minimum: float=48, maximum: float=150) -> np.ndarray:
    counts = np.asarray(counts, dtype=float)
    if counts.size == 0:
        return counts
    low = float(np.nanmin(counts))
    high = float(np.nanmax(counts))
    if math.isclose(low, high):
        return np.full_like(counts, (minimum + maximum) / 2)
    return minimum + (counts - low) / (high - low) * (maximum - minimum)

def legend_count_values(counts: np.ndarray) -> list[int]:
    low = int(np.nanmin(counts))
    high = int(np.nanmax(counts))
    if low == high:
        return [low]
    values = np.linspace(low, high, 4)
    rounded = [int(round(value)) for value in values]
    return list(dict.fromkeys(rounded))

def pvalue_tick_label(value: float) -> str:
    if value < 0.001:
        return f'{value:.0e}'
    if value < 0.01:
        return f'{value:.4f}'.rstrip('0')
    return f'{value:.3f}'.rstrip('0')

def pvalue_norm(values: np.ndarray) -> LogNorm:
    positive = np.asarray(values, dtype=float)
    positive = positive[np.isfinite(positive) & (positive > 0)]
    if positive.size == 0:
        raise ValueError('No positive p-values are available for plotting.')
    vmin = float(np.min(positive))
    vmax = float(np.max(positive))
    if math.isclose(vmin, vmax):
        vmax = vmin * 1.01
    return LogNorm(vmin=vmin, vmax=vmax)

def apply_panel_style(ax: plt.Axes) -> None:
    ax.set_axisbelow(True)
    ax.grid(True, which='major', color=GRID, linewidth=0.65)
    for spine in ax.spines.values():
        spine.set_color('#777777')
        spine.set_linewidth(0.6)

def add_colorbar(fig: plt.Figure, cax: plt.Axes, norm: LogNorm, title: str='pvalue') -> None:
    scalar = mpl.cm.ScalarMappable(norm=norm, cmap=CMAP)
    scalar.set_array([])
    colorbar = fig.colorbar(scalar, cax=cax)
    ticks = np.geomspace(norm.vmin, norm.vmax, 4)
    colorbar.set_ticks(ticks)
    colorbar.set_ticklabels([pvalue_tick_label(value) for value in ticks])
    colorbar.ax.invert_yaxis()
    colorbar.outline.set_visible(False)
    colorbar.ax.tick_params(length=2.5, width=0.6, labelsize=9)
    cax.set_title(title, loc='left', fontsize=10.5, fontweight='bold', pad=7)

def add_count_legend(ax: plt.Axes, counts: np.ndarray, anchor: tuple[float, float]=(1.14, 0.52)) -> None:
    values = legend_count_values(counts)
    sizes = point_sizes(np.asarray(values, dtype=float))
    handles = [plt.scatter([], [], s=size, facecolor='black', edgecolor='black', linewidth=0.4) for size in sizes]
    legend = ax.legend(handles, [str(value) for value in values], title='Count', frameon=False, loc='center left', bbox_to_anchor=anchor, borderaxespad=0, labelspacing=0.75, handletextpad=0.9)
    plt.setp(legend.get_title(), fontweight='bold')
    ax.add_artist(legend)

def plot_go() -> None:
    frame = pd.read_csv(DATA_DIR / '08_E_GO_top5_GeneRatio_per_ontology.csv')
    frame['gene_ratio'] = frame['GeneRatio'].map(ratio_to_float)
    frame['display_label'] = [marker_prefix(gene_ids) + str(description) for gene_ids, description in zip(frame['geneID'], frame['Description'])]
    frame['pvalue'] = pd.to_numeric(frame['pvalue'])
    frame['Count'] = pd.to_numeric(frame['Count'])
    norm = pvalue_norm(frame['pvalue'].to_numpy())
    counts = frame['Count'].to_numpy()
    fig = plt.figure(figsize=(13.1, 10.5), facecolor='white')
    grid = fig.add_gridspec(3, 1, left=0.36, right=0.78, bottom=0.08, top=0.88, hspace=0.43)
    titles = {'BP': 'Biological Process', 'CC': 'Cellular Component', 'MF': 'Molecular Function'}
    axes: list[plt.Axes] = []
    for row_index, ontology in enumerate(['BP', 'CC', 'MF']):
        ax = fig.add_subplot(grid[row_index, 0])
        axes.append(ax)
        part = frame.loc[frame['ONTOLOGY'].eq(ontology)].copy()
        part = part.sort_values(['gene_ratio', 'pvalue'], ascending=[True, False])
        y = np.arange(len(part))
        ax.scatter(part['gene_ratio'], y, s=point_sizes(part['Count'].to_numpy()), c=part['pvalue'], cmap=CMAP, norm=norm, edgecolor=EDGE, linewidth=0.75, alpha=0.96, zorder=3)
        ax.set_yticks(y)
        wrapped_labels = [textwrap.fill(str(label), width=48, break_long_words=False) for label in part['display_label']]
        ax.set_yticklabels(wrapped_labels)
        ax.set_xlabel('Gene ratio')
        ax.set_title(titles[ontology], loc='left', pad=8)
        apply_panel_style(ax)
        ax.margins(x=0.1, y=0.07)
    fig.suptitle('GO', x=0.36, y=0.955, ha='left', fontsize=16, fontweight='bold')
    color_ax = fig.add_axes([0.815, 0.72, 0.027, 0.17])
    add_colorbar(fig, color_ax, norm)
    add_count_legend(axes[1], counts, anchor=(1.12, 0.55))
    if any((label.startswith(('* ', '+ ', '*+ ')) for label in frame['display_label'])):
        axes[2].text(1.13, 0.2, 'Pathway label\n*  GDF15\n+  PLAU\n*+ both', transform=axes[2].transAxes, ha='left', va='top', fontsize=9.5, linespacing=1.35)
    pdf_path = OUT_ROOT / 'E.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0GO\u901a\u8def\u6c14\u6ce1\u56fe\uff08FDR\u5c0f\u4e8e0.05_log2FC\u7edd\u5bf9\u503c\u5927\u4e8e\u7b49\u4e8e1\uff09.pdf'
    png_path = pdf_path.with_suffix('.png')
    fig.savefig(pdf_path, facecolor='white', metadata={'Title': 'GO'})
    fig.savefig(png_path, dpi=360, facecolor='white')
    plt.close(fig)

def plot_single_database(frame: pd.DataFrame, title: str, pdf_name: str, figsize: tuple[float, float], label_width: int) -> None:
    frame = frame.copy()
    frame = frame.sort_values(['gene_ratio', 'pvalue'], ascending=[True, False])
    frame['wrapped_label'] = frame['display_label'].map(lambda value: '\n'.join(textwrap.wrap(str(value), width=label_width)))
    norm = pvalue_norm(frame['pvalue'].to_numpy())
    counts = frame['Count'].to_numpy()
    fig, ax = plt.subplots(figsize=figsize, facecolor='white')
    fig.subplots_adjust(left=0.43, right=0.79, bottom=0.12, top=0.88)
    y = np.arange(len(frame))
    ax.scatter(frame['gene_ratio'], y, s=point_sizes(counts), c=frame['pvalue'], cmap=CMAP, norm=norm, edgecolor=EDGE, linewidth=0.75, alpha=0.96, zorder=3)
    ax.set_yticks(y)
    ax.set_yticklabels(frame['wrapped_label'])
    ax.set_xlabel('Gene ratio')
    ax.set_title(title, loc='left', pad=10, fontsize=15)
    apply_panel_style(ax)
    ax.margins(x=0.1, y=0.045)
    color_ax = fig.add_axes([0.825, 0.7, 0.027, 0.2])
    add_colorbar(fig, color_ax, norm)
    add_count_legend(ax, counts, anchor=(1.12, 0.53))
    if any((label.startswith(('* ', '+ ', '*+ ')) for label in frame['display_label'])):
        ax.text(1.1, 0.22, 'Pathway label\n*  GDF15\n+  PLAU\n*+ both', transform=ax.transAxes, ha='left', va='top', fontsize=9.5, linespacing=1.35)
    pdf_path = OUT_ROOT / pdf_name
    fig.savefig(pdf_path, facecolor='white', metadata={'Title': title})
    fig.savefig(pdf_path.with_suffix('.png'), dpi=360, facecolor='white')
    plt.close(fig)

def plot_reactome() -> None:
    frame = pd.read_csv(DATA_DIR / '10_G_Reactome_top15_GeneRatio.csv')
    frame['gene_ratio'] = frame['GeneRatio'].map(ratio_to_float)
    frame['pvalue'] = pd.to_numeric(frame['pvalue'])
    frame['Count'] = pd.to_numeric(frame['Count'])
    frame['display_label'] = [marker_prefix(gene_ids) + str(description) for gene_ids, description in zip(frame['geneID'], frame['Description'])]
    plot_single_database(frame=frame, title='Reactome', pdf_name='G.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0Reactome\u901a\u8def\u6c14\u6ce1\u56fe\uff08FDR\u5c0f\u4e8e0.05_log2FC\u7edd\u5bf9\u503c\u5927\u4e8e\u7b49\u4e8e1\uff09.pdf', figsize=(13.2, 9.2), label_width=58)

def plot_kegg() -> None:
    frame = pd.read_csv(DATA_DIR / '13_H_KEGG_top15_GeneRatio.csv')
    frame = frame.rename(columns={'term': 'Description', 'p_value': 'pvalue', 'overlap_count': 'Count'})
    frame['pvalue'] = pd.to_numeric(frame['pvalue'])
    frame['Count'] = pd.to_numeric(frame['Count'])
    frame['gene_ratio'] = pd.to_numeric(frame['gene_ratio'])
    frame['display_label'] = [marker_prefix_semicolon(genes) + str(description).upper() for genes, description in zip(frame['overlap_genes'], frame['Description'])]
    plot_single_database(frame=frame, title='KEGG', pdf_name='H.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0KEGG\u901a\u8def\u6c14\u6ce1\u56fe\uff08FDR\u5c0f\u4e8e0.05_log2FC\u7edd\u5bf9\u503c\u5927\u4e8e\u7b49\u4e8e1\uff09.pdf', figsize=(13.2, 9.2), label_width=54)

def finalize_bc_names() -> None:
    for source_stem, final_stem in ((B_ASCII_STEM, B_FINAL_STEM), (C_ASCII_STEM, C_FINAL_STEM)):
        for suffix in ('.pdf', '.png'):
            source = OUT_ROOT / f'{source_stem}{suffix}'
            destination = OUT_ROOT / f'{final_stem}{suffix}'
            if not source.exists():
                if suffix == '.png':
                    continue
                raise FileNotFoundError(source)
            if destination.exists():
                raise FileExistsError(f'Refusing to overwrite an existing regenerated file: {destination}')
            source.rename(destination)
if __name__ == '__main__':
    finalize_bc_names()
    plot_go()
    plot_reactome()
    plot_kegg()
    print('E/G/H PDF and PNG files completed.')
