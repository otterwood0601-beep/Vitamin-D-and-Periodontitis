from __future__ import annotations
import argparse
import hashlib
import textwrap
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import numpy as np
import pandas as pd
plt.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Arial', 'Liberation Sans', 'DejaVu Sans'], 'axes.unicode_minus': False, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none', 'figure.facecolor': 'white', 'savefig.facecolor': 'white'})
POSITIVE = '#F28E2B'
NEGATIVE = '#142B74'
TEXT = '#1F2D3D'
GRID = '#D8DEE8'
GROUP_TEXT = '#4B5563'
GROUPS = ['GO-BP', 'GO-CC', 'GO-MF']
GROUP_SHORT = {'GO-BP': 'BP', 'GO-CC': 'CC', 'GO-MF': 'MF'}
FIGURES = ['Figure1_all_DEGs', 'Figure2_GDF15_terms']
FIGURE_LABEL = {'Figure1_all_DEGs': 'Figure 1', 'Figure2_GDF15_terms': 'Figure 2'}

def wrap_label(label: str, width: int=56) -> str:
    return textwrap.fill(label, width=width, break_long_words=False, break_on_hyphens=False)

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest().upper()

def build_plot(rows: pd.DataFrame, figure_set: str) -> plt.Figure:
    rows = rows.copy()
    rows['group_order'] = rows['database_group'].map({g: i for i, g in enumerate(GROUPS)})
    rows = rows.sort_values(['group_order', 'target_order'], kind='stable').reset_index(drop=True)
    if list(rows.groupby('database_group', sort=False).size()) != [5, 5, 5]:
        raise RuntimeError(f'Expected 5 BP, 5 CC and 5 MF rows for {figure_set}')
    labels = [wrap_label(value) for value in rows['pathway_label']]
    line_count = sum((label.count('\n') + 1 for label in labels))
    height = max(10.2, 6.0 + line_count * 0.31)
    fig, ax = plt.subplots(figsize=(14.2, height))
    y = np.arange(len(rows))
    nes = rows['NES'].to_numpy(dtype=float)
    colors = np.where(nes > 0, POSITIVE, NEGATIVE)
    ax.barh(y, nes, color=colors, height=0.66, edgecolor='none', zorder=3)
    ax.set_yticks(y, labels=labels)
    ax.invert_yaxis()
    x_limit = 2.35
    ax.set_xlim(-x_limit, x_limit)
    ax.set_xticks([-2, -1, 0, 1, 2])
    ax.axvline(0, color='#20262E', linewidth=1.15, zorder=4)
    ax.xaxis.grid(True, color=GRID, linewidth=0.8, zorder=0)
    ax.set_axisbelow(True)
    for boundary in (4.5, 9.5):
        ax.axhline(boundary, color='#6B7280', linewidth=1.05, linestyle=(0, (4, 4)), zorder=2)
    for center, label in zip((2, 7, 12), ('BP', 'CC', 'MF')):
        ax.text(1.012, center, label, transform=ax.get_yaxis_transform(), ha='left', va='center', fontsize=12.5, fontweight='bold', color=GROUP_TEXT, bbox=dict(boxstyle='round,pad=0.22', facecolor='#F3F4F6', edgecolor='#CBD5E1'), clip_on=False)
    for yi, value in zip(y, nes):
        offset = 0.055
        ax.text(value + (offset if value >= 0 else -offset), yi, f'{value:+.3f}', ha='left' if value >= 0 else 'right', va='center', fontsize=9.2, color=TEXT, zorder=5)
    ax.set_xlabel('Normalized enrichment score (NES)', fontsize=12.5, color=TEXT, labelpad=10)
    ax.tick_params(axis='x', labelsize=10.5, colors=TEXT)
    ax.tick_params(axis='y', labelsize=9.3, colors=TEXT, length=0, pad=8)
    for spine in ['top', 'right', 'left']:
        ax.spines[spine].set_visible(False)
    ax.spines['bottom'].set_color('#4B5563')
    fig.suptitle(f'{FIGURE_LABEL[figure_set]} - GO GSEA', x=0.545, y=0.972, fontsize=18, fontweight='bold', color=TEXT)
    ax.set_title('Biological Process, Cellular Component and Molecular Function in one NES coordinate system', fontsize=10.8, color='#596579', pad=16)
    fig.legend(handles=[Patch(facecolor=POSITIVE, label='NES > 0: Vitamin D3 high'), Patch(facecolor=NEGATIVE, label='NES < 0: ethanol control high')], loc='lower center', bbox_to_anchor=(0.61, 0.045), frameon=False, ncol=2, fontsize=10)
    fig.text(0.535, 0.013, 'Ranking metric: DESeq2 Wald statistic (Vitamin D3 vs ethanol control). Dashed lines separate BP, CC and MF.', ha='center', va='bottom', fontsize=9, color='#596579')
    fig.subplots_adjust(left=0.47, right=0.93, top=0.875, bottom=0.135)
    return fig

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('results_csv', type=Path)
    parser.add_argument('output_dir', type=Path)
    args = parser.parse_args()
    results_csv = args.results_csv.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=False)
    data = pd.read_csv(results_csv)
    data = data[data['database_group'].isin(GROUPS)].copy()
    data['NES'] = pd.to_numeric(data['NES'], errors='raise')
    data['target_order'] = pd.to_numeric(data['target_order'], errors='raise').astype(int)
    manifest_rows: list[dict[str, object]] = []
    plot_rows: list[pd.DataFrame] = []
    for figure_set in FIGURES:
        rows = data[data['figure_set'] == figure_set].copy()
        if len(rows) != 15:
            raise RuntimeError(f'Expected 15 GO rows for {figure_set}; found {len(rows)}')
        short = FIGURE_LABEL[figure_set].replace(' ', '')
        stem = f'{short}_GO_BP_CC_MF_combined_NES'
        pdf_path = output_dir / f'{stem}.pdf'
        png_path = output_dir / f'{stem}.png'
        svg_path = output_dir / f'{stem}.svg'
        fig = build_plot(rows, figure_set)
        fig.savefig(pdf_path, bbox_inches='tight')
        fig.savefig(png_path, dpi=400, bbox_inches='tight')
        fig.savefig(svg_path, bbox_inches='tight')
        plt.close(fig)
        rows['combined_plot_order'] = rows['database_group'].map({g: i for i, g in enumerate(GROUPS)}) * 5 + rows.groupby('database_group').cumcount() + 1
        plot_rows.append(rows.sort_values('combined_plot_order'))
        manifest_rows.append({'figure_set': figure_set, 'pathway_count': len(rows), 'pdf': str(pdf_path), 'png': str(png_path), 'svg': str(svg_path), 'pdf_sha256': sha256(pdf_path)})
    pd.concat(plot_rows, ignore_index=True).to_csv(output_dir / 'Figure1_Figure2_GO_BP_CC_MF_combined_plot_data.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(manifest_rows).to_csv(output_dir / 'combined_GO_render_manifest.csv', index=False, encoding='utf-8-sig')
    print(f'Created {len(manifest_rows)} combined GO plots in {output_dir}')
if __name__ == '__main__':
    main()
