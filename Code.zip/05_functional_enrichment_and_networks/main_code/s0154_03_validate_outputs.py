from __future__ import annotations
import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path
import pandas as pd
from pypdf import PdfReader
PARENT = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u6b63\u6587\u56fe\\\u6b63\u6587\u56fe3 SMR\u548cBulk-RNA')
OUT_ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260818_FDR\u5c0f\u4e8e0.05_log2FC\u7edd\u5bf9\u503c\u5927\u4e8e\u7b49\u4e8e1_\u5168\u5dee\u5f02\u57fa\u56e0\u70ed\u56fe_\u706b\u5c71\u56feX\u8f74\u6b63\u8d1f5_\u989d\u5916\u51fa\u7a3f_v1')
DATA_DIR = OUT_ROOT / '01_\u6e90\u6570\u636e'
QA_DIR = OUT_ROOT / '02_QA_rendered'
AUDIT_DIR = OUT_ROOT / '00_\u4ee3\u7801\u4e0e\u5ba1\u8ba1'
ORIGINAL_MD5 = {'B.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0\u70ed\u56fe.pdf': 'ED44A2FC84DA3A5DA647C8A0DF39B6D7', 'C.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0\u706b\u5c71\u56fe.pdf': 'FBC92B639FB7F78CF9A2EB544547DBE4', 'E.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0GO\u901a\u8def\u6c14\u6ce1\u56fe.pdf': '7846120C2039B64FCA2D6036B4F88DFF', 'G.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0Reactome\u901a\u8def\u6c14\u6ce1\u56fe.pdf': '169C49488E2ED166255E54BA7B601283', 'H.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0KEGG\u901a\u8def\u6c14\u6ce1\u56fe.pdf': '6C140D1333973EB35B40A8F824489FE7'}
OUTPUT_PDFS = {'B': OUT_ROOT / 'B.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5168\u90e8\u5dee\u5f02\u57fa\u56e0\u70ed\u56fe\uff08FDR\u5c0f\u4e8e0.05_log2FC\u7edd\u5bf9\u503c\u5927\u4e8e\u7b49\u4e8e1\uff09.pdf', 'C': OUT_ROOT / 'C.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0\u706b\u5c71\u56fe\uff08FDR\u5c0f\u4e8e0.05_log2FC\u7edd\u5bf9\u503c\u5927\u4e8e\u7b49\u4e8e1_X\u8f74\u6b63\u8d1f5\uff09.pdf', 'E': OUT_ROOT / 'E.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0GO\u901a\u8def\u6c14\u6ce1\u56fe\uff08FDR\u5c0f\u4e8e0.05_log2FC\u7edd\u5bf9\u503c\u5927\u4e8e\u7b49\u4e8e1\uff09.pdf', 'G': OUT_ROOT / 'G.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0Reactome\u901a\u8def\u6c14\u6ce1\u56fe\uff08FDR\u5c0f\u4e8e0.05_log2FC\u7edd\u5bf9\u503c\u5927\u4e8e\u7b49\u4e8e1\uff09.pdf', 'H': OUT_ROOT / 'H.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0KEGG\u901a\u8def\u6c14\u6ce1\u56fe\uff08FDR\u5c0f\u4e8e0.05_log2FC\u7edd\u5bf9\u503c\u5927\u4e8e\u7b49\u4e8e1\uff09.pdf'}
EXPECTED_POINTS = {'B': (561.6, 676.8), 'C': (590.4, 446.4), 'E': (943.2, 756.0), 'G': (950.4, 662.4), 'H': (950.4, 662.4)}

def md5(path: Path) -> str:
    digest = hashlib.md5()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest().upper()
checks: list[dict[str, object]] = []

def check(name: str, passed: bool, detail: str) -> None:
    checks.append({'check': name, 'passed': bool(passed), 'detail': detail})
    if not passed:
        raise AssertionError(f'{name}: {detail}')

def main() -> None:
    QA_DIR.mkdir(parents=True, exist_ok=True)
    for name, expected_hash in ORIGINAL_MD5.items():
        path = PARENT / name
        observed = md5(path)
        check(f'original_unchanged_{name}', observed == expected_hash, f'expected={expected_hash}; observed={observed}')
    degs = pd.read_csv(DATA_DIR / '02_FDR005_absLog2FC1_DEGs.csv')
    deg_rule = degs['padj'].lt(0.05) & degs['log2FoldChange'].abs().ge(1) & degs['new_DEG'].astype(bool)
    check('DEG_row_count', len(degs) == 51, f'rows={len(degs)}')
    check('DEG_threshold_exact', bool(deg_rule.all()), f'passing={int(deg_rule.sum())}/{len(degs)}')
    heat = pd.read_csv(DATA_DIR / '04_B_all_eligible_genes_row_zscores.csv')
    check('heatmap_all_unique_DEGs', len(heat) == 46, f'rows={len(heat)}')
    check('heatmap_only_eligible', bool((heat['padj'].lt(0.05) & heat['log2FoldChange'].abs().ge(1)).all()), 'all heatmap rows must meet both thresholds')
    volcano = pd.read_csv(DATA_DIR / '05_C_volcano_source_data.csv')
    volcano_sig = volcano['new_DEG'].astype(bool)
    check('volcano_coloured_DEG_count', int(volcano_sig.sum()) == 51, f'coloured={int(volcano_sig.sum())}')
    audit = json.loads((AUDIT_DIR / 'analysis_and_filter_audit.json').read_text(encoding='utf-8'))
    check('volcano_xlim_minus5_plus5', audit.get('volcano_xlim') == [-5, 5], str(audit.get('volcano_xlim')))
    plot_script = (AUDIT_DIR / '01_filter_enrich_and_plot_BC.R').read_text(encoding='utf-8')
    check('volcano_xlim_exact_no_expansion', 'coord_cartesian(xlim = c(-5, 5), expand = FALSE, clip = "on")' in plot_script, 'x-axis panel must end exactly at -5 and +5')
    target = pd.read_csv(DATA_DIR / '14_GDF15_PLAU_new_threshold_status.csv')
    check('GDF15_PLAU_not_misclassified', not target['new_DEG'].astype(bool).any(), target[['gene_symbol', 'log2FoldChange', 'padj', 'new_DEG']].to_json(orient='records'))
    go_display = pd.read_csv(DATA_DIR / '08_E_GO_top5_GeneRatio_per_ontology.csv')
    go_counts = go_display.groupby('ONTOLOGY').size().to_dict()
    check('GO_display_5_each', go_counts == {'BP': 5, 'CC': 5, 'MF': 5}, str(go_counts))
    reactome_display = pd.read_csv(DATA_DIR / '10_G_Reactome_top15_GeneRatio.csv')
    check('Reactome_display_15', len(reactome_display) == 15, f'rows={len(reactome_display)}')
    kegg_display = pd.read_csv(DATA_DIR / '13_H_KEGG_top15_GeneRatio.csv')
    check('KEGG_display_15', len(kegg_display) == 15, f'rows={len(kegg_display)}')
    pdf_rows: list[dict[str, object]] = []
    renderer = os.environ.get('PDFTOPPM_EXE') or shutil.which('pdftoppm') or shutil.which('pdftoppm.exe')
    check('pdftoppm_available', renderer is not None, f'renderer={renderer}')
    for panel, path in OUTPUT_PDFS.items():
        check(f'pdf_exists_{panel}', path.exists() and path.stat().st_size > 5000, str(path))
        reader = PdfReader(str(path))
        check(f'pdf_one_page_{panel}', len(reader.pages) == 1, f'pages={len(reader.pages)}')
        media = reader.pages[0].mediabox
        width = float(media.width)
        height = float(media.height)
        expected_width, expected_height = EXPECTED_POINTS[panel]
        check(f'pdf_size_{panel}', abs(width - expected_width) <= 1.0 and abs(height - expected_height) <= 1.0, f'observed={width:.2f}x{height:.2f}; expected={expected_width:.2f}x{expected_height:.2f}')
        preview_prefix = QA_DIR / f'{panel}_preview'
        subprocess.run([renderer, '-f', '1', '-singlefile', '-png', '-r', '160', str(path), str(preview_prefix)], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        preview_path = preview_prefix.with_suffix('.png')
        check(f'rendered_preview_{panel}', preview_path.exists() and preview_path.stat().st_size > 10000, str(preview_path))
        pdf_rows.append({'panel': panel, 'path': str(path), 'bytes': path.stat().st_size, 'md5': md5(path), 'pages': len(reader.pages), 'width_pt': width, 'height_pt': height, 'preview': str(preview_path)})
    pd.DataFrame(pdf_rows).to_csv(AUDIT_DIR / '\u65b0\u8f93\u51faPDF\u6e05\u5355\u4e0eMD5.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(checks).to_csv(AUDIT_DIR / 'QA\u68c0\u67e5\u6e05\u5355.csv', index=False, encoding='utf-8-sig')
    report = {'overall': 'PASS', 'checks': len(checks), 'failed': 0, 'DEG_rows': len(degs), 'DEG_up': int((degs['log2FoldChange'] > 0).sum()), 'DEG_down': int((degs['log2FoldChange'] < 0).sum()), 'heatmap_rows': len(heat), 'GO_display': len(go_display), 'Reactome_display': len(reactome_display), 'KEGG_display': len(kegg_display), 'original_files_unchanged': True}
    (AUDIT_DIR / 'QA\u6c47\u603b.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False))
if __name__ == '__main__':
    main()
