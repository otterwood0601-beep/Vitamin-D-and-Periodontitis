from __future__ import annotations
import argparse
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
from pathlib import Path
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import Arc, Circle, Rectangle, Wedge
from pypdf import PdfReader
PAGE_WIDTH = 1022.0
PAGE_HEIGHT = 705.0
CENTER = (262.72, 340.31)
R_INNER_HOLE = 43.3
R_RICH_OUTER = 100.4
R_BUBBLE = 111.5
R_TERM_INNER = 122.5
R_TERM_OUTER = 143.0
R_ONTOLOGY_INNER = 144.1
R_ONTOLOGY_OUTER = 172.0
R_TICK_INNER = 176.0
R_TICK_OUTER = 181.5
R_ID_TEXT = 158.2
R_TERM_TEXT = 132.8
R_COUNT_TEXT = 104.0
INK = '#26384D'
WHITE = '#FFFFFF'
RICH_BG = '#E3E5E8'
GREEN_FILL = '#BFE3B1'
GREEN_STROKE = '#9BC88D'
GREEN_TEXT = '#42683C'
PURPLE_FILL = '#B449D0'
PURPLE_STROKE = '#7B2F94'
ONTOLOGY_COLORS = {'BP': '#7E9FD0', 'CC': '#E8A2AE', 'MF': '#F1D98F'}
ONTOLOGY_ORDER = ('MF', 'BP', 'CC')
CORE_GENES = ('GDF15', 'PLAU')

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description='Create the paired GO ring plot from the exact 15 terms in the GO dot plot.')
    parser.add_argument('--root', required=True, type=Path)
    parser.add_argument('--threshold-tag', required=True, choices=('0.5', '1'))
    parser.add_argument('--reference-pdf', required=True, type=Path)
    return parser.parse_args()

def setup_style() -> None:
    mpl.rcParams.update({'font.family': 'Arial', 'font.sans-serif': ['Arial', 'Liberation Sans', 'DejaVu Sans'], 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none', 'axes.unicode_minus': False, 'text.color': INK, 'axes.labelcolor': INK, 'xtick.color': INK, 'ytick.color': INK})

def md5sum(path: Path) -> str:
    digest = hashlib.md5()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def ratio_numerator(value: object) -> int:
    text = str(value).strip()
    if '/' in text:
        text = text.split('/', 1)[0]
    return int(round(float(text)))

def ratio_to_float(value: object) -> float:
    numerator, denominator = str(value).strip().split('/', 1)
    return float(numerator) / float(denominator)

def gene_set(value: object) -> set[str]:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return set()
    return {token.upper() for token in re.split('[/;,|\\s]+', str(value).strip()) if token}

def prepare_terms(frame: pd.DataFrame) -> pd.DataFrame:
    required = {'ID', 'Description', 'GeneRatio', 'BgRatio', 'RichFactor', 'pvalue', 'geneID', 'Count', 'ONTOLOGY'}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f'Missing required input columns: {sorted(missing)}')
    terms = frame.copy()
    terms['ONTOLOGY'] = terms['ONTOLOGY'].astype(str).str.upper()
    terms['pvalue'] = pd.to_numeric(terms['pvalue'], errors='coerce')
    terms['RichFactor'] = pd.to_numeric(terms['RichFactor'], errors='coerce')
    terms['Count'] = pd.to_numeric(terms['Count'], errors='coerce').astype(int)
    terms['GeneRatioNumeric'] = terms['GeneRatio'].map(ratio_to_float)
    terms['term_size'] = terms['BgRatio'].map(ratio_numerator)
    terms['select_count'] = terms['geneID'].map(lambda value: sum((gene in gene_set(value) for gene in CORE_GENES)))
    ontology_rank = {ontology: index for index, ontology in enumerate(ONTOLOGY_ORDER)}
    terms['ontology_rank'] = terms['ONTOLOGY'].map(ontology_rank)
    terms = terms.sort_values(['ontology_rank', 'GeneRatioNumeric', 'pvalue', 'ID'], ascending=[True, False, True, True], kind='stable').reset_index(drop=True)
    return terms

def polar_point(radius: float, angle_deg: float) -> tuple[float, float]:
    angle = math.radians(angle_deg)
    return (CENTER[0] + radius * math.cos(angle), CENTER[1] + radius * math.sin(angle))

def readable_tangent_rotation(angle_deg: float) -> float:
    rotation = angle_deg - 90.0
    while rotation <= -90.0:
        rotation += 180.0
    while rotation > 90.0:
        rotation -= 180.0
    return rotation

def add_annular_wedge(ax: plt.Axes, *, radius: float, width: float, clockwise_start: float, clockwise_end: float, facecolor: str, edgecolor: str, linewidth: float, zorder: float) -> None:
    ax.add_patch(Wedge(CENTER, radius, clockwise_end, clockwise_start, width=width, facecolor=facecolor, edgecolor=edgecolor, linewidth=linewidth, joinstyle='miter', zorder=zorder))

def draw_ring_legend(ax: plt.Axes) -> None:
    x0 = 555.0
    label_x = 610.0
    ax.text(x0, 523, 'ONTOLOGY', fontsize=16.0, fontweight='bold', ha='left', va='center', color='#111111')
    ontology_rows = [(463, 'BP', 'Biological Process'), (407, 'CC', 'Cellular Component'), (351, 'MF', 'Molecular Function')]
    for y, key, label in ontology_rows:
        ax.add_patch(Rectangle((x0, y - 14), 42, 28, facecolor=ONTOLOGY_COLORS[key], edgecolor='none'))
        ax.text(label_x, y, label, fontsize=13.3, ha='left', va='center', color=INK)
    ax.add_patch(Rectangle((x0, 267), 42, 22, facecolor=GREEN_FILL, edgecolor=GREEN_STROKE, linewidth=0.8))
    ax.text(label_x, 278, 'Number of Genes', fontsize=13.3, ha='left', va='center', color=INK)
    ax.add_patch(Circle((x0 + 21, 222), 7.0, facecolor=PURPLE_FILL, edgecolor=PURPLE_STROKE, linewidth=0.8))
    ax.text(label_x, 222, 'Number of Select', fontsize=13.3, ha='left', va='center', color=INK)
    ax.add_patch(Rectangle((x0, 153), 42, 22, facecolor=RICH_BG, edgecolor='#C2C6CB', linewidth=0.8))
    ax.text(label_x, 164, 'Rich Factor(0-1)', fontsize=13.3, ha='left', va='center', color=INK)

def plot_go_ring(terms: pd.DataFrame, pdf_path: Path, png_path: Path) -> None:
    fig = plt.figure(figsize=(PAGE_WIDTH / 72.0, PAGE_HEIGHT / 72.0), dpi=72, facecolor='white')
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, PAGE_WIDTH)
    ax.set_ylim(0, PAGE_HEIGHT)
    ax.set_aspect('equal', adjustable='box')
    ax.axis('off')
    ax.set_facecolor('white')
    n_terms = len(terms)
    sector_width = 360.0 / n_terms
    max_term_size = int(terms['term_size'].max())
    scale_max = max(100, int(math.ceil(max_term_size / 100.0)) * 100)
    tick_values = [0, scale_max // 2, scale_max]
    tick_fractions = [value / scale_max for value in tick_values]
    tick_margin_deg = 5.5 * 360.0 / (2 * math.pi * R_TICK_INNER)
    for index, row in terms.iterrows():
        ontology = str(row['ONTOLOGY'])
        color = ONTOLOGY_COLORS[ontology]
        go_id = str(row['ID'])
        term_size = int(row['term_size'])
        rich_factor = float(row['RichFactor'])
        select_count = int(row['select_count'])
        start_angle = 90.0 - index * sector_width
        end_angle = start_angle - sector_width
        mid_angle = (start_angle + end_angle) / 2.0
        rotation = readable_tangent_rotation(mid_angle)
        add_annular_wedge(ax, radius=R_RICH_OUTER, width=R_RICH_OUTER - R_INNER_HOLE, clockwise_start=start_angle, clockwise_end=end_angle, facecolor=RICH_BG, edgecolor=WHITE, linewidth=1.28, zorder=1)
        rich_outer = R_INNER_HOLE + np.clip(rich_factor, 0, 1) * (R_RICH_OUTER - R_INNER_HOLE)
        add_annular_wedge(ax, radius=rich_outer, width=max(rich_outer - R_INNER_HOLE, 0.01), clockwise_start=start_angle, clockwise_end=end_angle, facecolor=color, edgecolor=WHITE, linewidth=1.28, zorder=2)
        term_fraction = term_size / scale_max
        bar_end_angle = start_angle - tick_margin_deg - (sector_width - 2 * tick_margin_deg) * term_fraction
        add_annular_wedge(ax, radius=R_TERM_OUTER, width=R_TERM_OUTER - R_TERM_INNER, clockwise_start=start_angle, clockwise_end=bar_end_angle, facecolor=GREEN_FILL, edgecolor=GREEN_STROKE, linewidth=0.75, zorder=3)
        bar_mid_angle = (start_angle + bar_end_angle) / 2.0
        x, y = polar_point(R_TERM_TEXT, bar_mid_angle)
        ax.text(x, y, f'{term_size}', ha='center', va='center', rotation=readable_tangent_rotation(bar_mid_angle), rotation_mode='anchor', fontsize=5.9, fontweight='bold', color=GREEN_TEXT, zorder=6)
        bubble_radius = {0: 2.8, 1: 5.2, 2: 7.4}[select_count]
        bx, by = polar_point(R_BUBBLE, mid_angle)
        ax.add_patch(Circle((bx, by), bubble_radius, facecolor=PURPLE_FILL, edgecolor=PURPLE_STROKE, linewidth=0.65, zorder=5))
        cx, cy = polar_point(R_COUNT_TEXT, mid_angle)
        ax.text(cx, cy, str(select_count), ha='center', va='center', rotation=rotation, rotation_mode='anchor', fontsize=6.2, fontweight='bold', color=PURPLE_STROKE, zorder=6)
        add_annular_wedge(ax, radius=R_ONTOLOGY_OUTER, width=R_ONTOLOGY_OUTER - R_ONTOLOGY_INNER, clockwise_start=start_angle, clockwise_end=end_angle, facecolor=color, edgecolor=WHITE, linewidth=1.45, zorder=3)
        ix, iy = polar_point(R_ID_TEXT, mid_angle)
        ax.text(ix, iy, go_id, ha='center', va='center', rotation=rotation, rotation_mode='anchor', fontsize=8.2, color=INK, zorder=6)
        ax.add_patch(Arc(CENTER, 2 * R_TICK_INNER, 2 * R_TICK_INNER, theta1=end_angle + tick_margin_deg, theta2=start_angle - tick_margin_deg, edgecolor=INK, linewidth=0.65, zorder=4))
        for tick_value, tick_fraction in zip(tick_values, tick_fractions):
            tick_angle = start_angle - tick_margin_deg - (sector_width - 2 * tick_margin_deg) * tick_fraction
            tx0, ty0 = polar_point(R_TICK_INNER, tick_angle)
            tx1, ty1 = polar_point(R_TICK_OUTER, tick_angle)
            ax.plot([tx0, tx1], [ty0, ty1], color=INK, linewidth=0.65, solid_capstyle='butt', zorder=4)
            lx, ly = polar_point(193.0, tick_angle)
            ax.text(lx, ly, str(tick_value), ha='center', va='center', rotation=readable_tangent_rotation(tick_angle), rotation_mode='anchor', fontsize=5.3, fontstyle='italic', color=INK, zorder=6)
    for fraction in (0.25, 0.5, 0.75, 1.0):
        radius = R_INNER_HOLE + fraction * (R_RICH_OUTER - R_INNER_HOLE)
        ax.add_patch(Circle(CENTER, radius, facecolor='none', edgecolor=WHITE, linewidth=0.64, zorder=4))
    ax.add_patch(Circle(CENTER, R_INNER_HOLE, facecolor=WHITE, edgecolor=WHITE, linewidth=0.8, zorder=5))
    draw_ring_legend(ax)
    metadata = {'Creator': 'Matplotlib', 'Title': 'GO Gene Ratio paired ring'}
    fig.savefig(pdf_path, facecolor='white', metadata=metadata)
    fig.savefig(png_path, facecolor='white', dpi=400)
    plt.close(fig)

def render_pdf(pdf_path: Path, preview_path: Path) -> None:
    renderer = os.environ.get('PDFTOPPM_EXE') or shutil.which('pdftoppm.exe') or shutil.which('pdftoppm')
    if not renderer:
        raise RuntimeError('pdftoppm was not found.')
    preview_path.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run([renderer, '-png', '-singlefile', '-r', '180', str(pdf_path), str(preview_path.with_suffix(''))], check=True, capture_output=True, text=True)

def main() -> None:
    args = parse_args()
    root = args.root.resolve()
    out_dir = root / 'GO\u56fe_\u6bcf\u7c7b\u6070\u597d3\u79cdGeneRatio_\u989d\u5916\u51fa\u7a3f_v1'
    code_dir = out_dir / '00_\u4ee3\u7801\u4e0e\u8d28\u63a7'
    data_dir = out_dir / '01_\u6e90\u6570\u636e'
    render_dir = out_dir / '02_QA_rendered'
    source_csv = data_dir / 'GO_BP_CC_MF_top5_each_exact3_GeneRatio.csv'
    paired_e_candidates = sorted(out_dir.glob('E.*\u6bcf\u7c7b\u6070\u597d3\u79cdGeneRatio*.pdf'))
    if len(paired_e_candidates) != 1:
        raise FileNotFoundError(f'Expected one paired E GO PDF, found {len(paired_e_candidates)}.')
    paired_e_pdf = paired_e_candidates[0]
    paired_e_md5_before = md5sum(paired_e_pdf)
    reference_md5_before = md5sum(args.reference_pdf)
    frame = pd.read_csv(source_csv)
    terms = prepare_terms(frame)
    if len(terms) != 15:
        raise ValueError(f'Expected 15 paired GO terms, found {len(terms)}.')
    ring_source = data_dir / 'GO_ring_15_terms_source.csv'
    terms.to_csv(ring_source, index=False, encoding='utf-8-sig')
    stem = f'F.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0GO\u901a\u8def\u73af\u5f62\u56fe\uff08FDR\u5c0f\u4e8e0.05_log2FC\u7edd\u5bf9\u503c\u5927\u4e8e\u7b49\u4e8e{args.threshold_tag}_\u6bcf\u7c7b\u6070\u597d3\u79cdGeneRatio\uff09'
    pdf_path = out_dir / f'{stem}.pdf'
    png_path = out_dir / f'{stem}.png'
    if pdf_path.exists() or png_path.exists():
        raise FileExistsError(f'Refusing to overwrite an existing output: {pdf_path}')
    setup_style()
    plot_go_ring(terms, pdf_path, png_path)
    preview_path = render_dir / 'F_GO_ring_preview.png'
    render_pdf(pdf_path, preview_path)
    paired_e_md5_after = md5sum(paired_e_pdf)
    reference_md5_after = md5sum(args.reference_pdf)
    reader = PdfReader(str(pdf_path))
    page = reader.pages[0]
    width_pt = float(page.mediabox.width)
    height_pt = float(page.mediabox.height)
    extracted_text = page.extract_text() or ''
    qa_rows: list[dict[str, object]] = []
    for ontology in ('BP', 'CC', 'MF'):
        part = terms.loc[terms['ONTOLOGY'].eq(ontology)]
        qa_rows.extend([{'check': f'{ontology}_term_count_is_5', 'observed': len(part), 'expected': 5, 'status': 'PASS' if len(part) == 5 else 'FAIL'}, {'check': f'{ontology}_distinct_GeneRatio_is_3', 'observed': part['GeneRatio'].nunique(), 'expected': 3, 'status': 'PASS' if part['GeneRatio'].nunique() == 3 else 'FAIL'}])
    all_go_ids_present = all((str(go_id) in extracted_text for go_id in terms['ID']))
    qa_rows.extend([{'check': 'all_15_terms_have_nominal_pvalue_lt_0.05', 'observed': bool(terms['pvalue'].lt(0.05).all()), 'expected': True, 'status': 'PASS' if terms['pvalue'].lt(0.05).all() else 'FAIL'}, {'check': 'RichFactor_within_0_and_1', 'observed': bool(terms['RichFactor'].between(0, 1).all()), 'expected': True, 'status': 'PASS' if terms['RichFactor'].between(0, 1).all() else 'FAIL'}, {'check': 'select_count_within_0_and_2', 'observed': f"{terms['select_count'].min()}-{terms['select_count'].max()}", 'expected': 'within 0-2', 'status': 'PASS' if terms['select_count'].between(0, 2).all() else 'FAIL'}, {'check': 'all_15_GO_IDs_extractable_from_pdf', 'observed': all_go_ids_present, 'expected': True, 'status': 'PASS' if all_go_ids_present else 'FAIL'}, {'check': 'paired_E_pdf_unchanged', 'observed': paired_e_md5_after, 'expected': paired_e_md5_before, 'status': 'PASS' if paired_e_md5_after == paired_e_md5_before else 'FAIL'}, {'check': 'reference_F_pdf_unchanged', 'observed': reference_md5_after, 'expected': reference_md5_before, 'status': 'PASS' if reference_md5_after == reference_md5_before else 'FAIL'}, {'check': 'output_pdf_exists_and_nontrivial', 'observed': pdf_path.stat().st_size, 'expected': '>5000 bytes', 'status': 'PASS' if pdf_path.stat().st_size > 5000 else 'FAIL'}, {'check': 'output_pdf_page_count', 'observed': len(reader.pages), 'expected': 1, 'status': 'PASS' if len(reader.pages) == 1 else 'FAIL'}, {'check': 'output_pdf_page_size_points', 'observed': f'{width_pt:.1f} x {height_pt:.1f}', 'expected': '1022.0 x 705.0', 'status': 'PASS' if math.isclose(width_pt, PAGE_WIDTH, abs_tol=0.2) and math.isclose(height_pt, PAGE_HEIGHT, abs_tol=0.2) else 'FAIL'}, {'check': 'rendered_preview_exists', 'observed': preview_path.exists(), 'expected': True, 'status': 'PASS' if preview_path.exists() else 'FAIL'}])
    qa = pd.DataFrame(qa_rows)
    qa_path = code_dir / 'QA\u68c0\u67e5\u6e05\u5355_\u73af\u5f62\u56fe.csv'
    qa.to_csv(qa_path, index=False, encoding='utf-8-sig')
    overall = 'PASS' if qa['status'].eq('PASS').all() else 'FAIL'
    summary = {'overall': overall, 'chart_contract': {'paired_terms': 15, 'ontology_order_clockwise': list(ONTOLOGY_ORDER), 'term_size': 'BgRatio numerator', 'number_of_select': 'Count of GDF15 and PLAU present in geneID', 'rich_factor': 'RichFactor constrained to 0-1'}, 'threshold_tag': args.threshold_tag, 'source_csv': str(source_csv), 'ring_source_csv': str(ring_source), 'output_pdf': str(pdf_path), 'output_png': str(png_path), 'preview_png': str(preview_path), 'paired_E_pdf': str(paired_e_pdf), 'paired_E_md5_before': paired_e_md5_before, 'paired_E_md5_after': paired_e_md5_after, 'reference_pdf': str(args.reference_pdf), 'reference_md5_before': reference_md5_before, 'reference_md5_after': reference_md5_after, 'ontology_counts': {ontology: int(terms['ONTOLOGY'].eq(ontology).sum()) for ontology in ('BP', 'CC', 'MF')}, 'select_count_distribution': {str(int(key)): int(value) for key, value in terms['select_count'].value_counts().sort_index().items()}, 'pdf_page_count': len(reader.pages), 'pdf_page_size_points': [width_pt, height_pt]}
    with (code_dir / 'QA\u6c47\u603b_\u73af\u5f62\u56fe.json').open('w', encoding='utf-8') as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    if overall != 'PASS':
        raise AssertionError('One or more ring-plot QA checks failed.')
    print(json.dumps(summary, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
