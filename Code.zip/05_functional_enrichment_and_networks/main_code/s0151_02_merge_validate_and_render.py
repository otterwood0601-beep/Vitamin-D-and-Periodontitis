from __future__ import annotations
import argparse
import hashlib
import math
import os
import re
import shutil
import textwrap
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import numpy as np
import pandas as pd
from pypdf import PdfReader
POSITIVE = '#F28E2B'
NEGATIVE = '#142B74'
TEXT = '#1F2D3D'
GRID = '#D8DEE8'
ZERO = '#20262E'
GROUP_TITLES = {'GO-BP': 'Biological Process', 'GO-CC': 'Cellular Component', 'GO-MF': 'Molecular Function'}
TARGET_NAMES = {'GO': 'Figure1_all_DEGs_GO_BP_CC_MF_3axes_15bars.pdf', 'KEGG': 'Figure1_all_DEGs_KEGG_GSEA_collection.pdf', 'Reactome': 'Figure1_all_DEGs_Reactome_GSEA_collection.pdf'}

def setup_style() -> None:
    plt.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Arial', 'Liberation Sans', 'DejaVu Sans'], 'axes.unicode_minus': False, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none', 'figure.facecolor': 'white', 'savefig.facecolor': 'white'})

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest().upper()

def normalize_text(value: str) -> str:
    return re.sub('\\s+', ' ', value).strip()

def load_complete_results(recalc_dir: Path) -> pd.DataFrame:
    parts = []
    for group in ['GO-BP', 'GO-CC', 'GO-MF', 'Reactome', 'KEGG']:
        file_group = group.replace('-', '_')
        frame = pd.read_csv(recalc_dir / f'GSEA_complete_{file_group}.csv.gz')
        frame['database_group'] = group
        parts.append(frame)
    return pd.concat(parts, ignore_index=True)

def build_final_table(audit: pd.DataFrame, existing: pd.DataFrame, recomputed: pd.DataFrame, complete: pd.DataFrame) -> pd.DataFrame:
    final_rows: list[dict[str, object]] = []
    numeric_cols = ['NES', 'ES', 'pval', 'padj', 'size']
    for item in audit.itertuples(index=False):
        source_table = existing if item.reusable_existing_gsea else recomputed
        hit = source_table.loc[source_table['database_group'].eq(item.database_group) & source_table['pathway_key'].eq(item.pathway_key)].copy()
        if hit.empty:
            raise RuntimeError(f'Missing chosen GSEA row for {item.database_group}/{item.pathway_key}')
        for column in numeric_cols:
            hit[column] = pd.to_numeric(hit[column], errors='raise')
        chosen = hit.iloc[0]
        check = complete.loc[complete['database_group'].eq(item.database_group) & complete['pathway_key'].eq(item.pathway_key)].copy()
        if len(check) != 1:
            raise RuntimeError(f'Expected one family-wide validation row for {item.database_group}/{item.pathway_key}; found {len(check)}')
        check_nes = float(check.iloc[0]['NES'])
        final_rows.append({'database_group': item.database_group, 'display_order_top_to_bottom': int(item.display_order_top_to_bottom), 'pathway_key': item.pathway_key, 'pathway_label_source_pre_rename': item.pathway_label_source, 'pathway_label_display_post_rename': item.pathway_label_display, 'bubble_GeneRatio_pre_rename': item.bubble_GeneRatio_pre_rename, 'bubble_Count_pre_rename': int(item.bubble_Count_pre_rename), 'NES': float(chosen['NES']), 'ES': float(chosen['ES']), 'pval': float(chosen['pval']), 'padj': float(chosen['padj']), 'size': int(chosen['size']), 'NES_origin': 'reused_existing_20260813' if item.reusable_existing_gsea else 'recomputed_20260819_same_method', 'NES_familywide_validation_20260819': check_nes, 'NES_validation_abs_delta': abs(float(chosen['NES']) - check_nes)})
    final = pd.DataFrame(final_rows).sort_values(['database_group', 'display_order_top_to_bottom'], kind='stable')
    expected = {'GO-BP': 5, 'GO-CC': 5, 'GO-MF': 5, 'Reactome': 15, 'KEGG': 16}
    found = final.groupby('database_group').size().to_dict()
    if found != expected:
        raise RuntimeError(f'Unexpected final pathway counts: {found}')
    if not np.isfinite(final[['NES', 'ES', 'pval', 'padj']].to_numpy(dtype=float)).all():
        raise RuntimeError('Final table contains non-finite GSEA statistics')
    for group, count in expected.items():
        orders = final.loc[final['database_group'].eq(group), 'display_order_top_to_bottom'].tolist()
        if orders != list(range(1, count + 1)):
            raise RuntimeError(f'Non-consecutive display order for {group}: {orders}')
    return final

def wrap_label(value: str, width: int) -> str:
    return textwrap.fill(str(value), width=width, break_long_words=False, break_on_hyphens=False)

def style_axis(ax: plt.Axes, panel: pd.DataFrame, *, x_limit: float, label_width: int, y_fontsize: float, bar_height: float=0.6) -> None:
    panel = panel.sort_values('display_order_top_to_bottom', kind='stable')
    y = np.arange(len(panel))
    values = panel['NES'].to_numpy(dtype=float)
    colors = np.where(values > 0, POSITIVE, NEGATIVE)
    labels = [wrap_label(x, label_width) for x in panel['pathway_label_display_post_rename']]
    ax.barh(y, values, color=colors, height=bar_height, edgecolor='none', zorder=3)
    ax.set_yticks(y, labels=labels)
    ax.invert_yaxis()
    ax.set_xlim(-x_limit, x_limit)
    ax.axvline(0, color=ZERO, linewidth=1.15, zorder=4)
    ax.xaxis.grid(True, color=GRID, linewidth=0.8, zorder=0)
    ax.set_axisbelow(True)
    ax.set_xlabel('Normalized enrichment score (NES)', fontsize=11.0, color=TEXT, labelpad=8)
    ax.tick_params(axis='x', labelsize=9.5, colors=TEXT)
    ax.tick_params(axis='y', labelsize=y_fontsize, colors=TEXT, length=0, pad=7)
    for spine in ['top', 'right', 'left']:
        ax.spines[spine].set_visible(False)
    ax.spines['bottom'].set_color('#4B5563')
    offset = x_limit * 0.025
    for yi, value in zip(y, values):
        ax.text(value + (offset if value >= 0 else -offset), yi, f'{value:+.3f}', ha='left' if value >= 0 else 'right', va='center', fontsize=8.6, color=TEXT, zorder=5)

def add_legend(fig: plt.Figure, y: float) -> None:
    fig.legend(handles=[Patch(facecolor=POSITIVE, label='NES > 0: Vitamin D3 high'), Patch(facecolor=NEGATIVE, label='NES < 0: ethanol control high')], loc='lower center', bbox_to_anchor=(0.57, y), frameon=False, ncol=2, fontsize=9.7)

def make_go(final: pd.DataFrame) -> plt.Figure:
    fig, axes = plt.subplots(3, 1, figsize=(15.8, 12.4), gridspec_kw={'hspace': 0.54})
    for ax, group in zip(axes, ['GO-BP', 'GO-CC', 'GO-MF']):
        panel = final.loc[final['database_group'].eq(group)].copy()
        style_axis(ax, panel, x_limit=2.35, label_width=58, y_fontsize=9.2, bar_height=0.6)
        ax.set_title(GROUP_TITLES[group], loc='left', fontsize=13.0, fontweight='bold', color=TEXT, pad=8)
        ax.set_xticks([-2, -1, 0, 1, 2])
    fig.suptitle('GO', x=0.565, y=0.985, fontsize=20, fontweight='bold', color=TEXT)
    add_legend(fig, 0.018)
    fig.subplots_adjust(left=0.43, right=0.94, top=0.925, bottom=0.105)
    return fig

def make_single(final: pd.DataFrame, group: str) -> plt.Figure:
    panel = final.loc[final['database_group'].eq(group)].copy()
    height = 7.45 if group == 'Reactome' else 7.65
    fig, ax = plt.subplots(figsize=(13.5, height))
    max_abs = float(panel['NES'].abs().max())
    x_limit = math.ceil(max_abs * 1.28 * 10) / 10
    style_axis(ax, panel, x_limit=x_limit, label_width=54 if group == 'Reactome' else 80, y_fontsize=8.15, bar_height=0.58)
    ax.set_title(group, loc='left', fontsize=16, fontweight='bold', color=TEXT, pad=10)
    add_legend(fig, 0.025)
    fig.subplots_adjust(left=0.47 if group == 'Reactome' else 0.48, right=0.965, top=0.905, bottom=0.17)
    return fig

def save_and_verify(fig: plt.Figure, target: Path, preview_dir: Path, expected_labels: list[str]) -> dict[str, object]:
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp_pdf = preview_dir / f'{target.stem}.tmp.pdf'
    preview_png = preview_dir / f'{target.stem}.png'
    preview_svg = preview_dir / f'{target.stem}.svg'
    fig.savefig(tmp_pdf, bbox_inches='tight')
    fig.savefig(preview_png, dpi=260, bbox_inches='tight')
    fig.savefig(preview_svg, bbox_inches='tight')
    plt.close(fig)
    reader = PdfReader(str(tmp_pdf))
    if len(reader.pages) != 1:
        raise RuntimeError(f'Expected one PDF page for {target.name}')
    text = normalize_text(reader.pages[0].extract_text() or '')
    missing_labels = [label for label in expected_labels if normalize_text(label) not in text]
    if missing_labels:
        raise RuntimeError(f'Labels missing from {target.name}: {missing_labels}')
    shutil.copy2(tmp_pdf, target)
    tmp_pdf.unlink()
    return {'target_pdf': str(target), 'preview_png': str(preview_png), 'preview_svg': str(preview_svg), 'page_count': 1, 'label_count': len(expected_labels), 'pdf_sha256': sha256(target)}

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--audit-csv', required=True, type=Path)
    parser.add_argument('--existing-gsea', required=True, type=Path)
    parser.add_argument('--recalc-dir', required=True, type=Path)
    parser.add_argument('--target-dir', required=True, type=Path)
    parser.add_argument('--work-dir', required=True, type=Path)
    args = parser.parse_args()
    setup_style()
    args.work_dir.mkdir(parents=True, exist_ok=True)
    preview_dir = args.work_dir / '02_\u6700\u7ec8\u7ed8\u56fe\u6570\u636e\u4e0e\u9884\u89c8'
    backup_dir = args.work_dir / '03_\u8986\u76d6\u524d\u5907\u4efd'
    preview_dir.mkdir(parents=True, exist_ok=True)
    backup_dir.mkdir(parents=True, exist_ok=True)
    audit = pd.read_csv(args.audit_csv)
    existing = pd.read_csv(args.existing_gsea)
    recomputed = pd.read_csv(args.recalc_dir / 'GSEA_target_pathway_results.csv')
    complete = load_complete_results(args.recalc_dir)
    final = build_final_table(audit, existing, recomputed, complete)
    final.to_csv(preview_dir / '\u6700\u7ec846\u6761_NES_\u6539\u540d\u524d\u771f\u5b9e\u901a\u8def_\u6539\u540d\u540e\u663e\u793a\u540d\u79f0_\u5b8c\u6574\u5ba1\u8ba1.csv', index=False, encoding='utf-8-sig')
    for filename in TARGET_NAMES.values():
        source = args.target_dir / filename
        if not source.exists():
            raise FileNotFoundError(source)
        shutil.copy2(source, backup_dir / f'{filename}.bak')
    requests = [('GO', make_go(final), final.loc[final['database_group'].str.startswith('GO-')].sort_values(['database_group', 'display_order_top_to_bottom'])['pathway_label_display_post_rename'].tolist()), ('KEGG', make_single(final, 'KEGG'), final.loc[final['database_group'].eq('KEGG')].sort_values('display_order_top_to_bottom')['pathway_label_display_post_rename'].tolist()), ('Reactome', make_single(final, 'Reactome'), final.loc[final['database_group'].eq('Reactome')].sort_values('display_order_top_to_bottom')['pathway_label_display_post_rename'].tolist())]
    manifest = []
    for key, figure, labels in requests:
        manifest.append(save_and_verify(figure, args.target_dir / TARGET_NAMES[key], preview_dir, labels))
    pd.DataFrame(manifest).to_csv(preview_dir / '\u8f93\u51fa\u6e05\u5355\u4e0e\u54c8\u5e0c.csv', index=False, encoding='utf-8-sig')
    validation = final.groupby(['database_group', 'NES_origin'], sort=False).agg(pathway_count=('pathway_key', 'size'), max_familywide_NES_abs_delta=('NES_validation_abs_delta', 'max')).reset_index()
    validation.to_csv(preview_dir / 'NES\u590d\u7528\u4e0e\u91cd\u7b97\u9a8c\u8bc1\u6c47\u603b.csv', index=False, encoding='utf-8-sig')
    print(validation.to_string(index=False))
    print(pd.DataFrame(manifest).to_string(index=False))
if __name__ == '__main__':
    main()
