from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import math
import os
import re
from pathlib import Path
import pandas as pd
from pypdf import PdfReader

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', required=True, type=Path)
    return parser.parse_args()

def md5sum(path: Path) -> str:
    digest = hashlib.md5()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def load_plot_module(script_path: Path):
    spec = importlib.util.spec_from_file_location('pathway_plot_module', script_path)
    if spec is None or spec.loader is None:
        raise ImportError(script_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def strip_pathway_prefix(value: object) -> str:
    return re.sub('^[*+]+\\s*', '', str(value)).strip()

def pdf_geometry(path: Path) -> tuple[int, float, float, str]:
    reader = PdfReader(str(path))
    page = reader.pages[0]
    return (len(reader.pages), float(page.mediabox.width), float(page.mediabox.height), page.extract_text() or '')

def main() -> None:
    args = parse_args()
    root = args.root.resolve()
    data_dir = root / '01_\u6e90\u6570\u636e'
    code_dir = root / '00_\u4ee3\u7801\u4e0e\u5ba1\u8ba1'
    render_dir = root / '02_QA_rendered' / 'EGH_\u901a\u8def\u91cd\u9009\u6700\u7ec8\u7248'
    module = load_plot_module(code_dir / '04_reselect_pathways_and_overwrite_EGH_v2.py')
    reactome_csv = data_dir / '16_G_Reactome_Count\u8c03\u6574_\u771f\u5b9e\u540d\u4e0e\u663e\u793a\u540d\u5bf9\u7167.csv'
    kegg_csv = data_dir / '17_H_KEGG\u91cd\u9009_4\u79cdGeneRatio_\u771f\u5b9e\u540d\u4e0e\u663e\u793a\u540d\u5bf9\u7167.csv'
    mapping_csv = data_dir / '18_EGH\u901a\u8def\u771f\u5b9e\u540d\u79f0\u4e0ePDF\u663e\u793a\u540d\u79f0\u603b\u5bf9\u7167.csv'
    reactome = pd.read_csv(reactome_csv)
    kegg = pd.read_csv(kegg_csv)
    mapping = pd.read_csv(mapping_csv)
    reactome_signature_before = reactome[['Description_source', 'GeneRatio', 'Count', 'pvalue']].copy()
    kegg_signature_before = kegg[['Description_source', 'GeneRatioNumeric', 'Count', 'pvalue']].copy()
    reactome['Description_display'] = reactome['Description_display'].map(strip_pathway_prefix)
    kegg['Description_display'] = kegg['Description_display'].map(strip_pathway_prefix)
    pathway_rows = mapping['database'].isin(['Reactome', 'KEGG'])
    mapping.loc[pathway_rows, 'Description_display'] = mapping.loc[pathway_rows, 'Description_display'].map(strip_pathway_prefix)
    reactome.to_csv(reactome_csv, index=False, encoding='utf-8-sig')
    kegg.to_csv(kegg_csv, index=False, encoding='utf-8-sig')
    mapping.to_csv(mapping_csv, index=False, encoding='utf-8-sig')
    g_stem = module.FINAL_NAMES['G']
    h_stem = module.FINAL_NAMES['H']
    g_pdf = root / f'{g_stem}.pdf'
    g_png = root / f'{g_stem}.png'
    h_pdf = root / f'{h_stem}.pdf'
    h_png = root / f'{h_stem}.png'
    old_hashes = {'G': md5sum(g_pdf), 'H': md5sum(h_pdf)}
    temporary = {'G_pdf': root / '.__tmp_G_clean.pdf', 'G_png': root / '.__tmp_G_clean.png', 'H_pdf': root / '.__tmp_H_clean.pdf', 'H_png': root / '.__tmp_H_clean.png'}
    module.setup_style()
    module.plot_single_database(reactome, title='Reactome', pdf_path=temporary['G_pdf'], png_path=temporary['G_png'], label_width=58, annotate_counts=False)
    module.plot_single_database(kegg, title='KEGG', pdf_path=temporary['H_pdf'], png_path=temporary['H_png'], label_width=54, annotate_counts=False)
    for source, destination in ((temporary['G_pdf'], g_pdf), (temporary['G_png'], g_png), (temporary['H_pdf'], h_pdf), (temporary['H_png'], h_png)):
        os.replace(source, destination)
    g_preview = render_dir / 'G_final_preview.png'
    h_preview = render_dir / 'H_final_preview.png'
    module.render_pdf(g_pdf, g_preview)
    module.render_pdf(h_pdf, h_preview)
    reactome_signature_after = reactome[['Description_source', 'GeneRatio', 'Count', 'pvalue']]
    kegg_signature_after = kegg[['Description_source', 'GeneRatioNumeric', 'Count', 'pvalue']]
    g_pages, g_width, g_height, g_text = pdf_geometry(g_pdf)
    h_pages, h_width, h_height, h_text = pdf_geometry(h_pdf)
    qa_rows = [{'check': 'Reactome_data_signature_unchanged', 'observed': reactome_signature_before.equals(reactome_signature_after), 'expected': True}, {'check': 'KEGG_data_signature_unchanged', 'observed': kegg_signature_before.equals(kegg_signature_after), 'expected': True}, {'check': 'Reactome_display_prefixes_removed', 'observed': not reactome['Description_display'].str.match('^[*+]').any(), 'expected': True}, {'check': 'KEGG_display_prefixes_removed', 'observed': not kegg['Description_display'].str.match('^[*+]').any(), 'expected': True}, {'check': 'Reactome_Pathway_label_block_removed', 'observed': 'Pathway label' not in g_text and 'GDF15' not in g_text and ('PLAU' not in g_text), 'expected': True}, {'check': 'KEGG_Pathway_label_block_removed', 'observed': 'Pathway label' not in h_text and 'GDF15' not in h_text and ('PLAU' not in h_text), 'expected': True}, {'check': 'Reactome_pdf_geometry', 'observed': f'{g_pages}; {g_width:.1f} x {g_height:.1f}', 'expected': '1; 950.4 x 662.4'}, {'check': 'KEGG_pdf_geometry', 'observed': f'{h_pages}; {h_width:.1f} x {h_height:.1f}', 'expected': '1; 950.4 x 662.4'}, {'check': 'Reactome_pdf_overwritten', 'observed': md5sum(g_pdf) != old_hashes['G'], 'expected': True}, {'check': 'KEGG_pdf_overwritten', 'observed': md5sum(h_pdf) != old_hashes['H'], 'expected': True}, {'check': 'rendered_previews_exist', 'observed': g_preview.exists() and h_preview.exists(), 'expected': True}]
    for row in qa_rows:
        if row['check'].endswith('_geometry'):
            row['status'] = 'PASS' if row['observed'] == row['expected'] else 'FAIL'
        else:
            row['status'] = 'PASS' if bool(row['observed']) is bool(row['expected']) else 'FAIL'
    qa = pd.DataFrame(qa_rows)
    qa.to_csv(code_dir / 'QA\u68c0\u67e5\u6e05\u5355_GH\u53bb\u6570\u5b57\u53bbPathwayLabel.csv', index=False, encoding='utf-8-sig')
    overall = 'PASS' if qa['status'].eq('PASS').all() else 'FAIL'
    summary = {'overall': overall, 'changes': ['Removed all direct Count numbers next to Reactome points.', 'Removed Pathway label/GDF15/PLAU legend block from Reactome and KEGG.', 'Removed leading * and + symbols from all Reactome and KEGG display labels.'], 'selection_and_statistics_unchanged': True, 'final_pdfs': {'G': str(g_pdf), 'H': str(h_pdf)}, 'old_md5': old_hashes, 'new_md5': {'G': md5sum(g_pdf), 'H': md5sum(h_pdf)}}
    with (code_dir / 'QA\u6c47\u603b_GH\u53bb\u6570\u5b57\u53bbPathwayLabel.json').open('w', encoding='utf-8') as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    if overall != 'PASS':
        raise AssertionError('One or more cleanup QA checks failed.')
    print(json.dumps(summary, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
