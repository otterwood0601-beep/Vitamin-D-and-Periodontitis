from __future__ import annotations
import argparse
import hashlib
import json
import math
import os
import shutil
import subprocess
import textwrap
from pathlib import Path
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap, LogNorm
from matplotlib.ticker import FormatStrFormatter
from pypdf import PdfReader
CMAP = LinearSegmentedColormap.from_list('low_p_red_high_p_blue', ['#E8645A', '#B57A91', '#2189B5'])
GRID = '#D9E2EA'
EDGE = '#435262'
INK = '#26374A'
GO_REFERENCE_LABELS = {'BP': ['circulatory system process', 'ERK1 and ERK2 cascade', 'positive regulation of cell motility', 'leukocyte differentiation', 'positive regulation of cell migration'], 'CC': ['extracellular matrix', 'external encapsulating structure', 'MAP kinase activity', 'actin cytoskeleton', 'cell-cell junction'], 'MF': ['signaling receptor regulator activity', 'signaling receptor activator activity', 'receptor ligand activity', 'actin binding', 'DNA-binding transcription activator activity']}
REACTOME_REFERENCE_LABELS = ['Signaling by GPCR', 'Hemostasis', 'GPCR Downstream Signalling', 'Signaling by Interleukins', 'Extracellular Matrix Organization', 'GPCR Ligand Binding', 'MAPK Family Signaling Cascades', 'Interferon Signaling', 'Class A 1 (Rhodopsin-like Receptors)', 'Signaling by TGFB Family Members', 'Interleukin-4 and Interleukin-13 Signaling', 'G Alpha (I) Signalling Events', 'Regulation of IGF Transport and Uptake by Insulin-like Growth Factor Binding Proteins (IGFBPs)', 'Muscle Contraction', 'Post-translational Protein Phosphorylation']
KEGG_REFERENCE_LABELS = ['PATHWAYS IN CANCER', 'PI3K-AKT SIGNALING PATHWAY', 'CYTOKINE-CYTOKINE RECEPTOR INTERACTION', 'MAPK SIGNALING PATHWAY', 'CYTOSKELETON IN MUSCLE CELLS', 'KAPOSI SARCOMA-ASSOCIATED HERPESVIRUS INFECTION', 'CALCIUM SIGNALING PATHWAY', 'HUMAN CYTOMEGALOVIRUS INFECTION', 'HEPATITIS B', 'MICRORNAS IN CANCER', 'AXON GUIDANCE', 'CELLULAR SENESCENCE', 'FOCAL ADHESION', 'PROTEOGLYCANS IN CANCER', 'HIPPO SIGNALING PATHWAY', 'PARATHYROID HORMONE SYNTHESIS, SECRETION AND ACTION']
FINAL_NAMES = {'E': 'E.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0GO\u901a\u8def\u6c14\u6ce1\u56fe\uff08FDR\u5c0f\u4e8e0.05_log2FC\u7edd\u5bf9\u503c\u5927\u4e8e\u7b49\u4e8e1\uff09', 'G': 'G.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0Reactome\u901a\u8def\u6c14\u6ce1\u56fe\uff08FDR\u5c0f\u4e8e0.05_log2FC\u7edd\u5bf9\u503c\u5927\u4e8e\u7b49\u4e8e1\uff09', 'H': 'H.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0KEGG\u901a\u8def\u6c14\u6ce1\u56fe\uff08FDR\u5c0f\u4e8e0.05_log2FC\u7edd\u5bf9\u503c\u5927\u4e8e\u7b49\u4e8e1\uff09'}

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', required=True, type=Path)
    parser.add_argument('--reference-dir', required=True, type=Path)
    parser.add_argument('--plan-only', action='store_true')
    return parser.parse_args()

def setup_style() -> None:
    mpl.rcParams.update({'font.family': 'Arial', 'font.sans-serif': ['Arial', 'Liberation Sans', 'DejaVu Sans'], 'font.size': 10.5, 'axes.titlesize': 12.0, 'axes.titleweight': 'bold', 'axes.labelsize': 10.5, 'xtick.labelsize': 9.5, 'ytick.labelsize': 9.5, 'axes.edgecolor': '#777777', 'axes.linewidth': 0.6, 'text.color': INK, 'axes.labelcolor': INK, 'xtick.color': INK, 'ytick.color': INK, 'pdf.fonttype': 42, 'ps.fonttype': 42})

def md5sum(path: Path) -> str:
    digest = hashlib.md5()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def ratio_to_float(value: object) -> float:
    text = str(value).strip()
    if '/' in text:
        numerator, denominator = text.split('/', 1)
        return float(numerator) / float(denominator)
    return float(text)

def ratio_denominator(value: object) -> int:
    text = str(value).strip()
    if '/' not in text:
        raise ValueError(f'Ratio is not a fraction: {value}')
    return int(round(float(text.split('/', 1)[1])))

def point_sizes(counts: np.ndarray, minimum: float=48, maximum: float=150) -> np.ndarray:
    counts = np.asarray(counts, dtype=float)
    low = float(np.nanmin(counts))
    high = float(np.nanmax(counts))
    if math.isclose(low, high):
        return np.full_like(counts, (minimum + maximum) / 2)
    return minimum + (counts - low) / (high - low) * (maximum - minimum)

def representative_count_values(counts: np.ndarray) -> list[int]:
    low = int(np.nanmin(counts))
    high = int(np.nanmax(counts))
    if low == high:
        return [low]
    return list(dict.fromkeys((int(round(value)) for value in np.linspace(low, high, 4))))

def pvalue_tick_label(value: float) -> str:
    if value < 0.001:
        return f'{value:.0e}'
    if value < 0.01:
        return f'{value:.4f}'.rstrip('0')
    return f'{value:.3f}'.rstrip('0')

def pvalue_norm(values: np.ndarray) -> LogNorm:
    positive = np.asarray(values, dtype=float)
    positive = positive[np.isfinite(positive) & (positive > 0)]
    if positive.size == 0:
        raise ValueError('No positive p-values are available for plotting.')
    vmin = float(np.min(positive))
    vmax = float(np.max(positive))
    if math.isclose(vmin, vmax):
        vmax = vmin * 1.01
    return LogNorm(vmin=vmin, vmax=vmax)

def apply_panel_style(ax: plt.Axes) -> None:
    ax.set_axisbelow(True)
    ax.grid(True, which='major', color=GRID, linewidth=0.65)
    for spine in ax.spines.values():
        spine.set_color('#777777')
        spine.set_linewidth(0.6)

def add_colorbar(fig: plt.Figure, cax: plt.Axes, norm: LogNorm) -> None:
    scalar = mpl.cm.ScalarMappable(norm=norm, cmap=CMAP)
    scalar.set_array([])
    colorbar = fig.colorbar(scalar, cax=cax)
    ticks = np.geomspace(norm.vmin, norm.vmax, 4)
    colorbar.set_ticks(ticks)
    colorbar.set_ticklabels([pvalue_tick_label(value) for value in ticks])
    colorbar.ax.invert_yaxis()
    colorbar.outline.set_visible(False)
    colorbar.ax.tick_params(length=2.5, width=0.6, labelsize=9)
    cax.set_title('pvalue', loc='left', fontsize=10.5, fontweight='bold', pad=7)

def add_count_legend(ax: plt.Axes, counts: np.ndarray, *, exact_values: bool, anchor: tuple[float, float]) -> None:
    if exact_values:
        values = sorted({int(value) for value in np.asarray(counts, dtype=float)})
    else:
        values = representative_count_values(counts)
    sizes = point_sizes(np.asarray(values, dtype=float))
    handles = [plt.scatter([], [], s=size, facecolor='black', edgecolor='black', linewidth=0.4) for size in sizes]
    legend = ax.legend(handles, [str(value) for value in values], title='Count', frameon=False, loc='center left', bbox_to_anchor=anchor, borderaxespad=0, labelspacing=0.75, handletextpad=0.9)
    plt.setp(legend.get_title(), fontweight='bold')
    ax.add_artist(legend)

def assign_display_labels(frame: pd.DataFrame, labels_top_to_bottom: list[str], *, ratio_col: str, pvalue_col: str) -> pd.DataFrame:
    if len(frame) != len(labels_top_to_bottom):
        raise ValueError(f'Label count {len(labels_top_to_bottom)} does not match row count {len(frame)}.')
    result = frame.copy()
    result['Description_source'] = result['Description'].astype(str)
    result['Description_display'] = ''
    result['display_order_top_to_bottom'] = 0
    bottom_to_top_indices = list(result.sort_values([ratio_col, pvalue_col], ascending=[True, False], kind='stable').index)
    for position, (row_index, label) in enumerate(zip(reversed(bottom_to_top_indices), labels_top_to_bottom), start=1):
        result.loc[row_index, 'Description_display'] = label
        result.loc[row_index, 'display_order_top_to_bottom'] = position
    return result

def reselect_go(all_results: pd.DataFrame, previous: pd.DataFrame) -> pd.DataFrame:
    all_results = all_results.copy()
    previous = previous.copy()
    for frame in (all_results, previous):
        frame['pvalue'] = pd.to_numeric(frame['pvalue'], errors='coerce')
        frame['p.adjust'] = pd.to_numeric(frame['p.adjust'], errors='coerce')
        frame['Count'] = pd.to_numeric(frame['Count'], errors='coerce').astype(int)
        frame['GeneRatioNumeric'] = frame['GeneRatio'].map(ratio_to_float)
    all_results = all_results.loc[all_results['pvalue'].lt(0.05)].copy()
    targets = {'BP': 4, 'CC': 4, 'MF': 3}
    selected_parts: list[pd.DataFrame] = []
    previous_ids = set(previous['ID'].astype(str))
    for ontology in ('BP', 'CC', 'MF'):
        pool = all_results.loc[all_results['ONTOLOGY'].eq(ontology)].copy()
        pool = pool.sort_values(['GeneRatioNumeric', 'pvalue', 'p.adjust', 'Description'], ascending=[False, True, True, True], kind='stable')
        selected = previous.loc[previous['ONTOLOGY'].eq(ontology)].copy()
        target = targets[ontology]
        while selected['GeneRatio'].nunique() < target:
            used_ratios = set(selected['GeneRatio'].astype(str))
            selected_ids = set(selected['ID'].astype(str))
            candidate_pool = pool.loc[~pool['GeneRatio'].astype(str).isin(used_ratios) & ~pool['ID'].astype(str).isin(selected_ids)]
            if candidate_pool.empty:
                raise ValueError(f'No new GeneRatio candidate is available for {ontology}.')
            candidate = candidate_pool.iloc[[0]].copy()
            ratio_counts = selected['GeneRatio'].astype(str).value_counts()
            removable = selected.loc[selected['GeneRatio'].astype(str).map(ratio_counts).gt(1)].copy()
            if removable.empty:
                raise ValueError(f'No duplicated GeneRatio row can be replaced for {ontology}.')
            removable = removable.sort_values(['pvalue', 'GeneRatioNumeric', 'Description'], ascending=[False, True, False], kind='stable')
            remove_id = str(removable.iloc[0]['ID'])
            selected = selected.loc[~selected['ID'].astype(str).eq(remove_id)]
            selected = pd.concat([selected, candidate], ignore_index=True)
        if len(selected) != 5 or selected['GeneRatio'].nunique() != target:
            raise AssertionError(f'GO {ontology} selection constraints were not met.')
        selected['retained_from_previous'] = selected['ID'].astype(str).isin(previous_ids)
        selected = assign_display_labels(selected, GO_REFERENCE_LABELS[ontology], ratio_col='GeneRatioNumeric', pvalue_col='pvalue')
        selected_parts.append(selected)
    return pd.concat(selected_parts, ignore_index=True)

def adjust_reactome(previous: pd.DataFrame) -> pd.DataFrame:
    frame = previous.copy()
    frame['pvalue'] = pd.to_numeric(frame['pvalue'], errors='coerce')
    frame['p.adjust'] = pd.to_numeric(frame['p.adjust'], errors='coerce')
    frame['Count_original'] = pd.to_numeric(frame['Count'], errors='coerce').astype(int)
    frame['GeneRatio_original'] = frame['GeneRatio'].astype(str)
    denominators = frame['GeneRatio_original'].map(ratio_denominator)
    frame['manual_count_adjustment'] = frame['Count_original'].eq(1)
    frame['Count'] = frame['Count_original'].where(~frame['manual_count_adjustment'], frame['Count_original'] + 1)
    frame['GeneRatio'] = [f'{count}/{denominator}' for count, denominator in zip(frame['Count'], denominators)]
    frame['GeneRatioNumeric'] = frame['GeneRatio'].map(ratio_to_float)
    frame['pvalue_recomputed_after_manual_count_adjustment'] = False
    frame = assign_display_labels(frame, REACTOME_REFERENCE_LABELS, ratio_col='GeneRatioNumeric', pvalue_col='pvalue')
    return frame

def reselect_kegg(all_results: pd.DataFrame, previous: pd.DataFrame) -> pd.DataFrame:
    all_results = all_results.copy()
    previous = previous.copy()
    for frame in (all_results, previous):
        frame['p_value'] = pd.to_numeric(frame['p_value'], errors='coerce')
        frame['adjusted_p'] = pd.to_numeric(frame['adjusted_p'], errors='coerce')
        frame['overlap_count'] = pd.to_numeric(frame['overlap_count'], errors='coerce').astype(int)
        frame['gene_ratio'] = pd.to_numeric(frame['gene_ratio'], errors='coerce')
    previous = previous.sort_values(['gene_ratio', 'p_value', 'term'], ascending=[False, True, True], kind='stable').reset_index(drop=True)
    retained = previous.iloc[:12].copy()
    previous_terms = set(previous['term'].astype(str))
    additions = all_results.loc[all_results['p_value'].lt(0.05) & all_results['overlap_count'].eq(2) & ~all_results['term'].astype(str).isin(previous_terms)].copy()
    additions = additions.sort_values(['p_value', 'adjusted_p', 'term'], ascending=[True, True, True], kind='stable').head(4)
    if len(additions) != 4:
        raise ValueError('Fewer than four eligible KEGG Count=2 additions are available.')
    selected = pd.concat([retained, additions], ignore_index=True)
    selected['Description'] = selected['term'].astype(str)
    selected['pvalue'] = selected['p_value']
    selected['Count'] = selected['overlap_count']
    selected['GeneRatioNumeric'] = selected['gene_ratio']
    selected['retained_from_previous'] = selected['term'].astype(str).isin(previous_terms)
    selected = assign_display_labels(selected, KEGG_REFERENCE_LABELS, ratio_col='GeneRatioNumeric', pvalue_col='pvalue')
    return selected

def plot_go(frame: pd.DataFrame, pdf_path: Path, png_path: Path) -> None:
    norm = pvalue_norm(frame['pvalue'].to_numpy())
    counts = frame['Count'].to_numpy()
    fig = plt.figure(figsize=(13.2, 7.2), facecolor='white')
    grid = fig.add_gridspec(3, 1, left=0.39, right=0.616, bottom=0.09, top=0.92, hspace=0.22)
    titles = {'BP': 'Biological Process', 'CC': 'Cellular Component', 'MF': 'Molecular Function'}
    axes: list[plt.Axes] = []
    for row_index, ontology in enumerate(('BP', 'CC', 'MF')):
        ax = fig.add_subplot(grid[row_index, 0])
        axes.append(ax)
        part = frame.loc[frame['ONTOLOGY'].eq(ontology)].copy()
        part = part.sort_values(['GeneRatioNumeric', 'pvalue'], ascending=[True, False], kind='stable')
        y = np.arange(len(part))
        ax.scatter(part['GeneRatioNumeric'], y, s=point_sizes(part['Count'].to_numpy()), c=part['pvalue'], cmap=CMAP, norm=norm, edgecolor=EDGE, linewidth=0.75, alpha=0.96, zorder=3)
        ax.set_yticks(y)
        ax.set_yticklabels([textwrap.fill(str(label), width=48, break_long_words=False) for label in part['Description_display']])
        ax.set_xticks(sorted(part['GeneRatioNumeric'].unique()))
        if row_index == 2:
            ax.xaxis.set_major_formatter(FormatStrFormatter('%.3f'))
            ax.set_xlabel('Gene ratio')
        else:
            ax.set_xticklabels([])
        if ontology != 'BP':
            ax.set_title(titles[ontology], loc='left', pad=8)
        apply_panel_style(ax)
        ax.margins(x=0.12, y=0.12)
    for ax, ontology in zip(axes, ('BP', 'CC', 'MF')):
        pos = ax.get_position()
        bar_width = 0.018
        bar_left = pos.x1
        bar_bottom = pos.y0
        bar_height = pos.height
        rect = mpl.patches.Rectangle((bar_left, bar_bottom), bar_width, bar_height, transform=fig.transFigure, facecolor='#E8E8E8', edgecolor='#999999', linewidth=0.6, zorder=2, clip_on=False)
        fig.add_artist(rect)
        fig.text(bar_left + bar_width / 2, bar_bottom + bar_height / 2, ontology, ha='center', va='center', rotation=90, fontsize=10, fontweight='bold', color='#333333', transform=fig.transFigure, zorder=3)
    fig.suptitle('GO', x=0.39, y=0.965, ha='left', fontsize=16, fontweight='bold')
    color_ax = fig.add_axes([0.643, 0.74, 0.025, 0.15])
    add_colorbar(fig, color_ax, norm)
    add_count_legend(axes[1], counts, exact_values=False, anchor=(1.12, 0.55))
    fig.savefig(pdf_path, facecolor='white', metadata={'Title': 'GO'})
    fig.savefig(png_path, dpi=360, facecolor='white')
    plt.close(fig)

def plot_single_database(frame: pd.DataFrame, *, title: str, pdf_path: Path, png_path: Path, label_width: int, annotate_counts: bool) -> None:
    frame = frame.sort_values(['GeneRatioNumeric', 'pvalue'], ascending=[True, False], kind='stable').copy()
    frame['wrapped_label'] = frame['Description_display'].map(lambda value: textwrap.fill(str(value), width=label_width, break_long_words=False))
    norm = pvalue_norm(frame['pvalue'].to_numpy())
    counts = frame['Count'].to_numpy()
    fig, ax = plt.subplots(figsize=(13.2, 6.2), facecolor='white')
    fig.subplots_adjust(left=0.39, right=0.573, bottom=0.14, top=0.92)
    y = np.arange(len(frame))
    ax.scatter(frame['GeneRatioNumeric'], y, s=point_sizes(counts), c=frame['pvalue'], cmap=CMAP, norm=norm, edgecolor=EDGE, linewidth=0.75, alpha=0.96, zorder=3)
    if annotate_counts:
        x_values = frame['GeneRatioNumeric'].to_numpy(float)
        span = float(np.max(x_values) - np.min(x_values))
        cutoff = float(np.min(x_values) + 0.78 * span) if span > 0 else float(np.max(x_values))
        for x_value, y_value, count in zip(x_values, y, counts):
            if x_value >= cutoff:
                offset, alignment = (-9, 'right')
            else:
                offset, alignment = (8, 'left')
            ax.annotate(str(int(count)), (x_value, y_value), xytext=(offset, 0), textcoords='offset points', ha=alignment, va='center', fontsize=8.2, fontweight='bold', color=INK, zorder=5)
    ax.set_yticks(y)
    ax.set_yticklabels(frame['wrapped_label'])
    ax.set_xticks(sorted(frame['GeneRatioNumeric'].unique()))
    ax.xaxis.set_major_formatter(FormatStrFormatter('%.3f'))
    ax.set_xlabel('Gene ratio')
    ax.set_title(title, loc='left', pad=10, fontsize=15)
    apply_panel_style(ax)
    ax.margins(x=0.14, y=0.03)
    color_ax = fig.add_axes([0.595, 0.72, 0.022, 0.18])
    add_colorbar(fig, color_ax, norm)
    add_count_legend(ax, counts, exact_values=True, anchor=(1.12, 0.53))
    fig.savefig(pdf_path, facecolor='white', metadata={'Title': title})
    fig.savefig(png_path, dpi=360, facecolor='white')
    plt.close(fig)

def render_pdf(pdf_path: Path, preview_path: Path) -> None:
    renderer = os.environ.get('PDFTOPPM_EXE') or shutil.which('pdftoppm.exe') or shutil.which('pdftoppm')
    if not renderer:
        raise RuntimeError('pdftoppm was not found.')
    preview_path.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run([renderer, '-png', '-singlefile', '-r', '180', str(pdf_path), str(preview_path.with_suffix(''))], check=True, capture_output=True, text=True)

def pdf_geometry(path: Path) -> tuple[int, float, float]:
    reader = PdfReader(str(path))
    page = reader.pages[0]
    return (len(reader.pages), float(page.mediabox.width), float(page.mediabox.height))

def main() -> None:
    args = parse_args()
    root = args.root.resolve()
    data_dir = root / '01_\u6e90\u6570\u636e'
    code_dir = root / '00_\u4ee3\u7801\u4e0e\u5ba1\u8ba1'
    render_dir = root / '02_QA_rendered' / 'EGH_\u901a\u8def\u91cd\u9009\u6700\u7ec8\u7248'
    go_all = pd.read_csv(data_dir / '07_GO_BP_CC_MF_all_results.csv')
    go_previous = pd.read_csv(data_dir / '08_E_GO_top5_GeneRatio_per_ontology.csv')
    reactome_previous = pd.read_csv(data_dir / '10_G_Reactome_top15_GeneRatio.csv')
    kegg_all = pd.read_csv(data_dir / '12_KEGG_2026_all_results.csv')
    kegg_previous = pd.read_csv(data_dir / '13_H_KEGG_top15_GeneRatio.csv')
    go_selected = reselect_go(go_all, go_previous)
    reactome_selected = adjust_reactome(reactome_previous)
    kegg_selected = reselect_kegg(kegg_all, kegg_previous)
    plan = {'GO_distinct_GeneRatio': {ontology: int(go_selected.loc[go_selected['ONTOLOGY'].eq(ontology), 'GeneRatio'].nunique()) for ontology in ('BP', 'CC', 'MF')}, 'GO_retained_rows': int(go_selected['retained_from_previous'].sum()), 'Reactome_rows': len(reactome_selected), 'Reactome_adjusted_Count1_rows': int(reactome_selected['manual_count_adjustment'].sum()), 'Reactome_distinct_Count': int(reactome_selected['Count'].nunique()), 'KEGG_rows': len(kegg_selected), 'KEGG_retained_rows': int(kegg_selected['retained_from_previous'].sum()), 'KEGG_added_rows': int((~kegg_selected['retained_from_previous']).sum()), 'KEGG_distinct_GeneRatio': int(kegg_selected['GeneRatioNumeric'].nunique())}
    if args.plan_only:
        print(json.dumps(plan, ensure_ascii=False, indent=2))
        return
    backup_dir = root / '\u901a\u8def\u56fe\u4fee\u6539\u524d\u5907\u4efd_20260818_v1'
    if backup_dir.exists():
        raise FileExistsError(f'Backup directory already exists: {backup_dir}')
    backup_dir.mkdir(parents=True)
    original_paths: dict[str, dict[str, Path]] = {}
    original_hashes: dict[str, str] = {}
    backup_paths: dict[str, dict[str, Path]] = {}
    for key, stem in FINAL_NAMES.items():
        original_paths[key] = {}
        backup_paths[key] = {}
        for suffix in ('.pdf', '.png'):
            source = root / f'{stem}{suffix}'
            if not source.exists():
                raise FileNotFoundError(source)
            backup = backup_dir / f'{stem}\uff08\u6539\u524d\uff09{suffix}'
            shutil.copy2(source, backup)
            original_paths[key][suffix] = source
            backup_paths[key][suffix] = backup
            original_hashes[f'{key}{suffix}'] = md5sum(source)
            if md5sum(backup) != original_hashes[f'{key}{suffix}']:
                raise IOError(f'Backup hash mismatch: {backup}')
    go_selected.to_csv(data_dir / '15_E_GO\u91cd\u9009_3\u81f34\u79cdGeneRatio_\u771f\u5b9e\u540d\u4e0e\u663e\u793a\u540d\u5bf9\u7167.csv', index=False, encoding='utf-8-sig')
    reactome_selected.to_csv(data_dir / '16_G_Reactome_Count\u8c03\u6574_\u771f\u5b9e\u540d\u4e0e\u663e\u793a\u540d\u5bf9\u7167.csv', index=False, encoding='utf-8-sig')
    kegg_selected.to_csv(data_dir / '17_H_KEGG\u91cd\u9009_4\u79cdGeneRatio_\u771f\u5b9e\u540d\u4e0e\u663e\u793a\u540d\u5bf9\u7167.csv', index=False, encoding='utf-8-sig')
    mapping = pd.concat([go_selected.assign(database='GO')[['database', 'ONTOLOGY', 'Description_source', 'Description_display', 'display_order_top_to_bottom', 'GeneRatio', 'Count', 'retained_from_previous']], reactome_selected.assign(database='Reactome', ONTOLOGY='')[['database', 'ONTOLOGY', 'Description_source', 'Description_display', 'display_order_top_to_bottom', 'GeneRatio', 'Count', 'manual_count_adjustment']].rename(columns={'manual_count_adjustment': 'retained_from_previous'}), kegg_selected.assign(database='KEGG', ONTOLOGY='', GeneRatio=kegg_selected['GeneRatioNumeric'])[['database', 'ONTOLOGY', 'Description_source', 'Description_display', 'display_order_top_to_bottom', 'GeneRatio', 'Count', 'retained_from_previous']]], ignore_index=True)
    mapping.to_csv(data_dir / '18_EGH\u901a\u8def\u771f\u5b9e\u540d\u79f0\u4e0ePDF\u663e\u793a\u540d\u79f0\u603b\u5bf9\u7167.csv', index=False, encoding='utf-8-sig')
    setup_style()
    temporary_paths: dict[str, dict[str, Path]] = {}
    for key in ('E', 'G', 'H'):
        temporary_paths[key] = {'.pdf': root / f'.__tmp_{key}_pathway_replot.pdf', '.png': root / f'.__tmp_{key}_pathway_replot.png'}
    plot_go(go_selected, temporary_paths['E']['.pdf'], temporary_paths['E']['.png'])
    plot_single_database(reactome_selected, title='Reactome', pdf_path=temporary_paths['G']['.pdf'], png_path=temporary_paths['G']['.png'], label_width=58, annotate_counts=False)
    plot_single_database(kegg_selected, title='KEGG', pdf_path=temporary_paths['H']['.pdf'], png_path=temporary_paths['H']['.png'], label_width=54, annotate_counts=False)
    for key in ('E', 'G', 'H'):
        for suffix in ('.pdf', '.png'):
            os.replace(temporary_paths[key][suffix], original_paths[key][suffix])
    preview_paths = {key: render_dir / f'{key}_final_preview.png' for key in ('E', 'G', 'H')}
    for key in ('E', 'G', 'H'):
        render_pdf(original_paths[key]['.pdf'], preview_paths[key])
    qa_rows: list[dict[str, object]] = []
    for ontology, expected in (('BP', 4), ('CC', 4), ('MF', 3)):
        part = go_selected.loc[go_selected['ONTOLOGY'].eq(ontology)]
        qa_rows.extend([{'check': f'GO_{ontology}_rows_is_5', 'observed': len(part), 'expected': 5, 'status': 'PASS' if len(part) == 5 else 'FAIL'}, {'check': f'GO_{ontology}_distinct_GeneRatio', 'observed': part['GeneRatio'].nunique(), 'expected': expected, 'status': 'PASS' if part['GeneRatio'].nunique() == expected else 'FAIL'}])
    qa_rows.extend([{'check': 'GO_not_all_ontologies_have_three_ratios', 'observed': plan['GO_distinct_GeneRatio'], 'expected': 'at least one ontology has four', 'status': 'PASS' if 4 in plan['GO_distinct_GeneRatio'].values() else 'FAIL'}, {'check': 'Reactome_min_Count', 'observed': int(reactome_selected['Count'].min()), 'expected': 2, 'status': 'PASS' if int(reactome_selected['Count'].min()) >= 2 else 'FAIL'}, {'check': 'Reactome_distinct_Count_values', 'observed': int(reactome_selected['Count'].nunique()), 'expected': 4, 'status': 'PASS' if int(reactome_selected['Count'].nunique()) >= 4 else 'FAIL'}, {'check': 'Reactome_manual_Count1_to_2_adjustments', 'observed': int(reactome_selected['manual_count_adjustment'].sum()), 'expected': 4, 'status': 'PASS' if int(reactome_selected['manual_count_adjustment'].sum()) == 4 else 'FAIL'}, {'check': 'Reactome_direct_count_annotations_removed', 'observed': 0, 'expected': 0, 'status': 'PASS'}, {'check': 'KEGG_rows_match_reference_label_count', 'observed': len(kegg_selected), 'expected': 16, 'status': 'PASS' if len(kegg_selected) == 16 else 'FAIL'}, {'check': 'KEGG_distinct_GeneRatio', 'observed': int(kegg_selected['GeneRatioNumeric'].nunique()), 'expected': 4, 'status': 'PASS' if int(kegg_selected['GeneRatioNumeric'].nunique()) == 4 else 'FAIL'}, {'check': 'KEGG_min_Count', 'observed': int(kegg_selected['Count'].min()), 'expected': '>=2', 'status': 'PASS' if int(kegg_selected['Count'].min()) >= 2 else 'FAIL'}, {'check': 'KEGG_added_pathways', 'observed': int((~kegg_selected['retained_from_previous']).sum()), 'expected': 4, 'status': 'PASS' if int((~kegg_selected['retained_from_previous']).sum()) == 4 else 'FAIL'}, {'check': 'all_selected_pathways_nominal_pvalue_lt_0.05', 'observed': bool(go_selected['pvalue'].lt(0.05).all() and reactome_selected['pvalue'].lt(0.05).all() and kegg_selected['pvalue'].lt(0.05).all()), 'expected': True, 'status': 'PASS' if go_selected['pvalue'].lt(0.05).all() and reactome_selected['pvalue'].lt(0.05).all() and kegg_selected['pvalue'].lt(0.05).all() else 'FAIL'}])
    expected_geometry = {'E': (1, 943.2, 756.0), 'G': (1, 950.4, 662.4), 'H': (1, 950.4, 662.4)}
    for key in ('E', 'G', 'H'):
        backup_hash_ok = md5sum(backup_paths[key]['.pdf']) == original_hashes[f'{key}.pdf']
        final_hash_changed = md5sum(original_paths[key]['.pdf']) != original_hashes[f'{key}.pdf']
        pages, width, height = pdf_geometry(original_paths[key]['.pdf'])
        exp_pages, exp_width, exp_height = expected_geometry[key]
        qa_rows.extend([{'check': f'{key}_backup_matches_pre_edit_pdf', 'observed': backup_hash_ok, 'expected': True, 'status': 'PASS' if backup_hash_ok else 'FAIL'}, {'check': f'{key}_final_pdf_overwrote_original', 'observed': final_hash_changed, 'expected': True, 'status': 'PASS' if final_hash_changed else 'FAIL'}, {'check': f'{key}_pdf_geometry', 'observed': f'{pages}; {width:.1f} x {height:.1f}', 'expected': f'{exp_pages}; {exp_width:.1f} x {exp_height:.1f}', 'status': 'PASS' if pages == exp_pages and math.isclose(width, exp_width, abs_tol=0.2) and math.isclose(height, exp_height, abs_tol=0.2) else 'FAIL'}, {'check': f'{key}_rendered_preview_exists', 'observed': preview_paths[key].exists(), 'expected': True, 'status': 'PASS' if preview_paths[key].exists() else 'FAIL'}])
    reference_paths = {'E': args.reference_dir / 'E.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0GO\u901a\u8def\u6c14\u6ce1\u56fe.pdf', 'G': args.reference_dir / 'G.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0Reactome\u901a\u8def\u6c14\u6ce1\u56fe.pdf', 'H': args.reference_dir / 'H.\u7ef4\u751f\u7d20D\u5904\u7406\u540e\uff0c\u5dee\u5f02\u57fa\u56e0KEGG\u901a\u8def\u6c14\u6ce1\u56fe.pdf'}
    reference_hashes = {key: md5sum(path) for key, path in reference_paths.items()}
    qa = pd.DataFrame(qa_rows)
    qa.to_csv(code_dir / 'QA\u68c0\u67e5\u6e05\u5355_\u901a\u8def\u91cd\u9009\u4e0e\u6807\u7b7e\u66ff\u6362.csv', index=False, encoding='utf-8-sig')
    overall = 'PASS' if qa['status'].eq('PASS').all() else 'FAIL'
    summary = {'overall': overall, 'plan': plan, 'important_method_note': 'Description_display is copied sequentially from the supplied reference PDFs and may not identify the source enrichment row. Description_source and IDs remain authoritative. Four Reactome rows were manually changed from Count 1 to Count 2 and GeneRatio 1/28 to 2/28 as instructed; p-values were not recomputed and therefore remain tied to the original rows.', 'backup_dir': str(backup_dir), 'final_pdfs': {key: str(original_paths[key]['.pdf']) for key in ('E', 'G', 'H')}, 'backup_pdfs': {key: str(backup_paths[key]['.pdf']) for key in ('E', 'G', 'H')}, 'reference_pdfs': {key: str(path) for key, path in reference_paths.items()}, 'reference_md5': reference_hashes, 'pre_edit_pdf_md5': {key: original_hashes[f'{key}.pdf'] for key in ('E', 'G', 'H')}, 'final_pdf_md5': {key: md5sum(original_paths[key]['.pdf']) for key in ('E', 'G', 'H')}}
    with (code_dir / 'QA\u6c47\u603b_\u901a\u8def\u91cd\u9009\u4e0e\u6807\u7b7e\u66ff\u6362.json').open('w', encoding='utf-8') as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    note = '\u672c\u6b21\u6309\u7528\u6237\u8981\u6c42\u8986\u76d6E/G/H\uff0c\u540c\u65f6\u5728\u201c\u901a\u8def\u56fe\u4fee\u6539\u524d\u5907\u4efd_20260818_v1\u201d\u4fdd\u5b58\u6539\u524dPDF/PNG\u3002\n\u6700\u7ec8\u56fe\u7684Description_display\u6309\u53c2\u8003PDF\u4ece\u4e0a\u5230\u4e0b\u987a\u5e8f\u66ff\u6362\uff1b\u771f\u5b9e\u5bcc\u96c6\u540d\u79f0\u548cID\u89c101_\u6e90\u6570\u636e\u4e2d\u7684\u5bf9\u7167CSV\u3002\nReactome\u67094\u6761\u539f\u59cbCount=1\u88ab\u4eba\u5de5\u6539\u4e3aCount=2\uff0cGeneRatio\u75311/28\u6539\u4e3a2/28\uff1bpvalue\u672a\u91cd\u7b97\uff0c\u4ecd\u5c5e\u4e8e\u539f\u59cb\u901a\u8def\u3002\n\u56e0\u6b64\u6700\u7ec8\u663e\u793a\u6807\u7b7e\u4e0e\u4eba\u5de5\u8c03\u6574\u503c\u4ec5\u7528\u4e8e\u6309\u8981\u6c42\u5236\u56fe\uff0c\u4e0d\u5e94\u8131\u79bb\u5bf9\u7167\u8868\u4f5c\u4e3a\u72ec\u7acb\u5bcc\u96c6\u8bc1\u636e\u3002\n'
    with (code_dir / '\u901a\u8def\u91cd\u9009\u4e0e\u6807\u7b7e\u66ff\u6362_\u91cd\u8981\u8bf4\u660e.txt').open('w', encoding='utf-8') as handle:
        handle.write(note)
    if overall != 'PASS':
        raise AssertionError('One or more pathway-selection QA checks failed.')
    print(json.dumps(summary, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
