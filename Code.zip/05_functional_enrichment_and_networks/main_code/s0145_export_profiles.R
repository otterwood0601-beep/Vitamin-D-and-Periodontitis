args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 2L) {
  stop("Usage: export_profiles.R <GSEA_analysis_objects.rds> <output dir>")
}

lib_paths <- strsplit(Sys.getenv("TASK_R_LIBS"), ";", fixed = TRUE)[[1]]
lib_paths <- lib_paths[nzchar(lib_paths)]
.libPaths(c(lib_paths, .libPaths()))

suppressPackageStartupMessages(library(data.table))

rds_path <- normalizePath(args[[1]], winslash = "/", mustWork = TRUE)
output_dir <- normalizePath(args[[2]], winslash = "/", mustWork = TRUE)
obj <- readRDS(rds_path)

metadata <- list()
points <- list()

for (profile_id in names(obj$profiles)) {
  p <- obj$profiles[[profile_id]]
  n <- length(p$running_ES)
  hit <- rep(FALSE, n)
  hit[p$hit_ranks] <- TRUE
  metadata[[profile_id]] <- data.table(
    profile_id = profile_id,
    database_group = p$database_group,
    pathway_key = p$pathway_key,
    pathway_label = p$pathway_label,
    peak_rank = p$peak_rank,
    ES = p$ES,
    NES = p$NES,
    pval = p$pval,
    padj = p$padj,
    size = p$size,
    direction = p$direction,
    leadingEdge = p$leadingEdge
  )
  points[[profile_id]] <- data.table(
    profile_id = profile_id,
    rank = seq_len(n),
    running_ES = p$running_ES,
    hit = hit
  )
}

fwrite(rbindlist(metadata), file.path(output_dir, "GSEA_profile_metadata.csv"))
fwrite(rbindlist(points), file.path(output_dir, "GSEA_profile_points.csv.gz"))
cat("Exported profiles:", length(obj$profiles), "\n")
