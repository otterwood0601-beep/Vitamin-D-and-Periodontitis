from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--mapping', required=True, type=Path)
    parser.add_argument('--go-results', required=True, type=Path)
    parser.add_argument('--existing-gsea', required=True, type=Path)
    parser.add_argument('--output-dir', required=True, type=Path)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    mapping = pd.read_csv(args.mapping)
    go = pd.read_csv(args.go_results)
    existing = pd.read_csv(args.existing_gsea)
    mapping['display_order_top_to_bottom'] = pd.to_numeric(mapping['display_order_top_to_bottom'], errors='raise').astype(int)
    rows: list[dict[str, object]] = []
    for item in mapping.itertuples(index=False):
        group = f'GO-{item.ONTOLOGY}' if item.database == 'GO' else item.database
        if item.database == 'GO':
            hit = go.loc[go['ONTOLOGY'].eq(item.ONTOLOGY) & go['Description'].eq(item.Description_source), 'ID'].drop_duplicates()
            if len(hit) != 1:
                raise RuntimeError(f'Expected one GO ID for {item.ONTOLOGY}/{item.Description_source}; found {len(hit)}')
            pathway_key = str(hit.iloc[0])
        else:
            pathway_key = str(item.Description_source)
        old = existing.loc[existing['database_group'].eq(group) & existing['pathway_key'].eq(pathway_key)].copy()
        reusable = not old.empty
        if reusable and old['NES'].astype(float).round(12).nunique() != 1:
            raise RuntimeError(f'Conflicting stored NES values for {group}/{pathway_key}')
        rows.append({'figure_set': 'Figure1_all_DEGs_EGH_source_terms', 'database_group': group, 'pathway_key': pathway_key, 'pathway_label_source': item.Description_source, 'pathway_label_display': item.Description_display, 'display_order_top_to_bottom': int(item.display_order_top_to_bottom), 'bubble_GeneRatio_pre_rename': item.GeneRatio, 'bubble_Count_pre_rename': int(item.Count), 'reusable_existing_gsea': reusable, 'existing_NES': float(old.iloc[0]['NES']) if reusable else pd.NA, 'existing_pval': float(old.iloc[0]['pval']) if reusable else pd.NA, 'existing_padj': float(old.iloc[0]['padj']) if reusable else pd.NA, 'existing_ES': float(old.iloc[0]['ES']) if reusable else pd.NA, 'existing_size': int(old.iloc[0]['size']) if reusable else pd.NA})
    audit = pd.DataFrame(rows).sort_values(['database_group', 'display_order_top_to_bottom'], kind='stable')
    if len(audit) != 46:
        raise RuntimeError(f'Expected 46 mapping rows; found {len(audit)}')
    if audit[['database_group', 'pathway_key']].duplicated().any():
        raise RuntimeError('Duplicate database/pathway keys in the requested mapping')
    missing = audit.loc[~audit['reusable_existing_gsea']].copy()
    targets = missing.rename(columns={'pathway_label_source': 'pathway_label'})[['figure_set', 'database_group', 'pathway_label', 'pathway_key']]
    audit.to_csv(args.output_dir / '01_\u5168\u90e846\u6761_\u590d\u7528\u4e0e\u91cd\u7b97\u5224\u5b9a.csv', index=False, encoding='utf-8-sig')
    targets.to_csv(args.output_dir / '02_\u4ec5\u7f3a\u5931\u6761\u76ee_GSEA\u91cd\u7b97\u76ee\u6807.csv', index=False, encoding='utf-8-sig')
    summary = audit.groupby('database_group', sort=False)['reusable_existing_gsea'].agg(total='size', reused='sum').reset_index()
    summary['recomputed'] = summary['total'] - summary['reused']
    summary.to_csv(args.output_dir / '03_\u590d\u7528\u4e0e\u91cd\u7b97\u6570\u91cf\u6c47\u603b.csv', index=False, encoding='utf-8-sig')
    print(summary.to_string(index=False))
if __name__ == '__main__':
    main()
