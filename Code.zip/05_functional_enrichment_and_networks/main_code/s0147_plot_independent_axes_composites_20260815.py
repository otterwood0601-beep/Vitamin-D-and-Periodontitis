from __future__ import annotations
import argparse
import hashlib
import textwrap
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import numpy as np
import pandas as pd
plt.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Arial', 'Liberation Sans', 'DejaVu Sans'], 'axes.unicode_minus': False, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none', 'figure.facecolor': 'white', 'savefig.facecolor': 'white'})
POSITIVE = '#F28E2B'
NEGATIVE = '#142B74'
TEXT = '#1F2D3D'
SUBTEXT = '#596579'
GRID = '#D8DEE8'
ZERO = '#20262E'
GROUPS_FIGURE2 = ['GO-BP', 'GO-CC', 'GO-MF', 'Reactome', 'KEGG']
GROUPS_FIGURE1 = ['GO-BP', 'GO-CC', 'GO-MF']
GROUP_TITLE = {'GO-BP': 'GO - Biological Process', 'GO-CC': 'GO - Cellular Component', 'GO-MF': 'GO - Molecular Function', 'Reactome': 'Reactome', 'KEGG': 'KEGG'}

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest().upper()

def wrap_label(label: str, width: int=58) -> str:
    return textwrap.fill(str(label), width=width, break_long_words=False, break_on_hyphens=False)

def ordered_panel_rows(rows: pd.DataFrame, figure_set: str, group: str) -> pd.DataFrame:
    panel = rows.loc[rows['figure_set'].eq(figure_set) & rows['database_group'].eq(group)].copy()
    if len(panel) != 5:
        raise RuntimeError(f'Expected 5 rows for {figure_set}/{group}; found {len(panel)}')
    if figure_set == 'Figure2_GDF15_terms' and group in {'Reactome', 'KEGG'}:
        panel['abs_NES'] = panel['NES'].abs()
        panel = panel.sort_values(['abs_NES', 'target_order'], ascending=[False, True], kind='stable')
    else:
        panel = panel.sort_values('target_order', kind='stable')
    return panel.reset_index(drop=True)

def style_axis(ax: plt.Axes, panel: pd.DataFrame, group: str) -> None:
    y = np.arange(len(panel))
    values = panel['NES'].to_numpy(dtype=float)
    colors = np.where(values > 0, POSITIVE, NEGATIVE)
    labels = [wrap_label(value) for value in panel['pathway_label']]
    ax.barh(y, values, color=colors, height=0.66, edgecolor='none', zorder=3)
    ax.set_yticks(y, labels=labels)
    ax.invert_yaxis()
    x_limit = 2.35
    ax.set_xlim(-x_limit, x_limit)
    ax.set_xticks([-2, -1, 0, 1, 2])
    ax.axvline(0, color=ZERO, linewidth=1.15, zorder=4)
    ax.xaxis.grid(True, color=GRID, linewidth=0.8, zorder=0)
    ax.set_axisbelow(True)
    for yi, value in zip(y, values):
        offset = 0.055
        ax.text(value + (offset if value >= 0 else -offset), yi, f'{value:+.3f}', ha='left' if value >= 0 else 'right', va='center', fontsize=9.0, color=TEXT, zorder=5)
    ax.set_title(GROUP_TITLE[group], loc='left', fontsize=13.0, fontweight='bold', color=TEXT, pad=9)
    ax.set_xlabel('Normalized enrichment score (NES)', fontsize=10.5, color=TEXT, labelpad=7)
    ax.tick_params(axis='x', labelsize=9.5, colors=TEXT)
    ax.tick_params(axis='y', labelsize=9.3, colors=TEXT, length=0, pad=8)
    for spine in ['top', 'right', 'left']:
        ax.spines[spine].set_visible(False)
    ax.spines['bottom'].set_color('#4B5563')

def build_figure(rows: pd.DataFrame, figure_set: str, groups: list[str]) -> tuple[plt.Figure, pd.DataFrame]:
    if figure_set == 'Figure2_GDF15_terms':
        figsize = (15.8, 24.5)
        main_title = 'Figure 2 pathway set (GDF15 annotation figure)'
        subtitle = 'GO, Reactome and KEGG in five independent NES coordinate systems'
        top = 0.938
        bottom = 0.077
        hspace = 0.74
    elif figure_set == 'Figure1_all_DEGs':
        figsize = (15.8, 15.8)
        main_title = 'Figure 1 - GO GSEA'
        subtitle = 'Biological Process, Cellular Component and Molecular Function in three independent NES coordinate systems'
        top = 0.91
        bottom = 0.115
        hspace = 0.78
    else:
        raise ValueError(f'Unsupported figure set: {figure_set}')
    fig, axes = plt.subplots(nrows=len(groups), ncols=1, figsize=figsize, sharex=False, gridspec_kw={'hspace': hspace})
    if len(groups) == 1:
        axes = np.asarray([axes])
    plotted_rows: list[pd.DataFrame] = []
    for panel_order, (axis, group) in enumerate(zip(axes, groups), start=1):
        panel = ordered_panel_rows(rows, figure_set, group)
        panel['panel_order'] = panel_order
        panel['within_panel_display_order'] = np.arange(1, 6)
        plotted_rows.append(panel)
        style_axis(axis, panel, group)
    fig.suptitle(main_title, x=0.565, y=0.985, fontsize=20, fontweight='bold', color=TEXT)
    fig.text(0.565, 0.957 if figure_set == 'Figure2_GDF15_terms' else 0.946, subtitle, ha='center', va='top', fontsize=11.5, color=SUBTEXT)
    fig.legend(handles=[Patch(facecolor=POSITIVE, label='NES > 0: Vitamin D3 high'), Patch(facecolor=NEGATIVE, label='NES < 0: ethanol control high')], loc='lower center', bbox_to_anchor=(0.565, 0.031 if figure_set == 'Figure2_GDF15_terms' else 0.05), frameon=False, ncol=2, fontsize=10.5)
    fig.text(0.565, 0.012 if figure_set == 'Figure2_GDF15_terms' else 0.02, 'Ranking metric: DESeq2 Wald statistic (Vitamin D3 vs ethanol control).', ha='center', va='bottom', fontsize=9.3, color=SUBTEXT)
    fig.subplots_adjust(left=0.43, right=0.94, top=top, bottom=bottom)
    return (fig, pd.concat(plotted_rows, ignore_index=True))

def save_triplet(fig: plt.Figure, stem: Path) -> dict[str, object]:
    paths = {'pdf': stem.with_suffix('.pdf'), 'png': stem.with_suffix('.png'), 'svg': stem.with_suffix('.svg')}
    fig.savefig(paths['pdf'], bbox_inches='tight')
    fig.savefig(paths['png'], dpi=400, bbox_inches='tight')
    fig.savefig(paths['svg'], bbox_inches='tight')
    return {'pdf': str(paths['pdf']), 'png': str(paths['png']), 'svg': str(paths['svg']), 'pdf_sha256': sha256(paths['pdf'])}

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('results_csv', type=Path)
    parser.add_argument('output_dir', type=Path)
    args = parser.parse_args()
    results_csv = args.results_csv.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=False)
    rows = pd.read_csv(results_csv)
    rows['NES'] = pd.to_numeric(rows['NES'], errors='raise')
    rows['target_order'] = pd.to_numeric(rows['target_order'], errors='raise').astype(int)
    requests = [('Figure2_GDF15_terms', GROUPS_FIGURE2, 'Figure2_GDF15_GO_BP_CC_MF_Reactome_KEGG_5axes_25bars'), ('Figure1_all_DEGs', GROUPS_FIGURE1, 'Figure1_all_DEGs_GO_BP_CC_MF_3axes_15bars')]
    manifest: list[dict[str, object]] = []
    plot_tables: list[pd.DataFrame] = []
    for figure_set, groups, stem_name in requests:
        figure, plotted = build_figure(rows, figure_set, groups)
        paths = save_triplet(figure, output_dir / stem_name)
        plt.close(figure)
        plotted.insert(0, 'output_figure', stem_name)
        plot_tables.append(plotted)
        manifest.append({'figure_set': figure_set, 'axis_count': len(groups), 'bar_count': len(plotted), 'source_csv': str(results_csv), 'source_csv_sha256': sha256(results_csv), **paths})
    pd.concat(plot_tables, ignore_index=True).to_csv(output_dir / 'independent_axes_plot_data.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(manifest).to_csv(output_dir / 'independent_axes_render_manifest.csv', index=False, encoding='utf-8-sig')
    print(pd.DataFrame(manifest).to_string(index=False))
if __name__ == '__main__':
    main()
