from __future__ import annotations
import argparse
import json
import hashlib
from datetime import datetime, timezone, timedelta
from pathlib import Path
import pandas as pd
import requests
ENRICHR_LIBRARIES = ('GO_Biological_Process_2025', 'GO_Cellular_Component_2025', 'GO_Molecular_Function_2025', 'KEGG_2021_Human')

def enrichr(genes: list[str], outdir: Path) -> None:
    payload = '\n'.join(genes)
    added = requests.post('https://maayanlab.cloud/Enrichr/addList', files={'list': (None, payload), 'description': (None, 'vitamin D gingiva overlap')}, timeout=60)
    added.raise_for_status()
    uid = added.json()['userListId']
    for library in ENRICHR_LIBRARIES:
        response = requests.get('https://maayanlab.cloud/Enrichr/enrich', params={'userListId': uid, 'backgroundType': library}, timeout=60)
        response.raise_for_status()
        rows = response.json().get(library, [])
        frame = pd.DataFrame(rows, columns=['rank', 'term', 'p_value', 'z_score', 'combined_score', 'overlap_genes', 'adjusted_p', 'old_p_value', 'old_adjusted_p'])
        if not frame.empty:
            frame['overlap_genes'] = frame['overlap_genes'].apply(lambda x: ';'.join(x))
            frame['count'] = frame['overlap_genes'].str.split(';').str.len()
            frame['gene_ratio'] = frame['count'] / len(genes)
        frame.to_csv(outdir / f'10_enrichr_{library}.csv', index=False)

def string_network(genes: list[str], outdir: Path, required_score: int=400) -> None:
    response = requests.get('https://string-db.org/api/tsv/network', params={'identifiers': '\r'.join(genes), 'species': 9606, 'required_score': required_score, 'network_type': 'functional', 'caller_identity': 'vitd-periodontitis-bioorgchem-adaptation'}, timeout=60)
    response.raise_for_status()
    (outdir / '11_STRING_functional_network.tsv').write_text(response.text, encoding='utf-8')
    (outdir / '22_STRING_request_audit.json').write_text(json.dumps({'queried_at': datetime.now(timezone(timedelta(hours=8))).isoformat(), 'url': response.url, 'species': 9606, 'network_type': 'functional', 'required_score': required_score, 'threshold_returned_scale': required_score / 1000, 'genes': genes, 'added_nodes': 0, 'tsv_sha256': hashlib.sha256((outdir / '11_STRING_functional_network.tsv').read_bytes()).hexdigest()}, ensure_ascii=False, indent=2), encoding='utf-8')

def pubchem(outdir: Path) -> None:
    prop_url = 'https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/calcifediol/property/Title,CanonicalSMILES,IsomericSMILES,InChIKey/JSON'
    prop_response = requests.get(prop_url, timeout=60)
    prop_response.raise_for_status()
    (outdir / '12_PubChem_calcifediol_properties.json').write_text(json.dumps(prop_response.json(), indent=2), encoding='utf-8')
    image_response = requests.get('https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/calcifediol/PNG', timeout=60)
    image_response.raise_for_status()
    (outdir / '12_PubChem_calcifediol_2D.png').write_bytes(image_response.content)

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--genes', required=True)
    parser.add_argument('--out', required=True)
    parser.add_argument('--required-score', type=int, default=400)
    parser.add_argument('--string-only', action='store_true')
    args = parser.parse_args()
    outdir = Path(args.out)
    outdir.mkdir(parents=True, exist_ok=True)
    genes = [g.strip() for g in Path(args.genes).read_text(encoding='utf-8').splitlines() if g.strip()]
    if not genes:
        raise SystemExit('No genes supplied')
    if not 0 <= args.required_score <= 1000:
        raise SystemExit('STRING score must be in [0, 1000]')
    if not args.string_only:
        enrichr(genes, outdir)
    string_network(genes, outdir, args.required_score)
    if not args.string_only:
        pubchem(outdir)
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
