suppressPackageStartupMessages({library(data.table); library(jsonlite)})
ROOT <- 'C:/wb_links/williams_vd47_full_20261008'
SD <- file.path(ROOT,'source_data')
options(timeout = 120)
de <- fread(file.path(SD,'08_paired_pseudobulk_high_vs_low_DE.csv.gz'))
universe <- de[in_VD47_signature == FALSE,gene]
foreground <- unique(readLines(file.path(SD,'09_enrichment_input_genes.txt')))
stopifnot(all(foreground %in% universe))
kegg <- file.path(SD,'KEGG_2021_Human.gmt')
kegg_url <- 'https://maayanlab.cloud/Enrichr/geneSetLibrary?mode=text&libraryName=KEGG_2021_Human'
if (!file.exists(kegg)) download.file(kegg_url,kegg,method = 'libcurl',mode = 'wb')
files <- c(GO_Biological_Process_2025 = 'C:/wb_links/genesets/GO_Biological_Process_2025.gmt',
           KEGG_2021_Human = kegg)
for (db in names(files)) {
  sets <- lapply(readLines(files[[db]],warn = FALSE),function(ln) {
    z <- strsplit(ln,'\t',fixed = TRUE)[[1]]
    list(Term = z[1], genes = intersect(unique(z[-c(1,2)]),universe))
  })
  sets <- Filter(function(z) length(z$genes) >= 5 && length(z$genes) <= 500,sets)
  result <- rbindlist(lapply(sets,function(z) {
    ov <- intersect(foreground,z$genes)
    data.table(Term = z$Term,Count = length(ov),Overlap = paste0(length(ov),'/',length(z$genes)),
      P.value = if (!length(foreground)) 1 else phyper(length(ov)-1,length(z$genes),
                      length(universe)-length(z$genes),length(foreground),lower.tail = FALSE),
      Genes = paste(ov,collapse = ';'),term_background_genes = length(z$genes),
      input_gene_count = length(foreground),universe_count = length(universe))
  }))
  result[, Adjusted.P.value := p.adjust(P.value,'BH')]
  setorder(result,Adjusted.P.value,P.value)
  fwrite(result,file.path(SD,paste0('15_VD47_high_',db,'.csv')))
  cat(db,'tested',nrow(result),'significant',sum(result$Adjusted.P.value < .05),'\n')
  print(result[Count > 0,.(Term,Count,Adjusted.P.value)][1:8])
}
write_json(list(method = 'one-sided hypergeometric ORA with BH correction',
  foreground = 'paired pseudobulk high-score-upregulated DEGs; FDR<0.05, logFC>0.25; signature excluded',
  universe = 'genes tested in paired pseudobulk, excluding all signature candidates',
  universe_n = length(universe),foreground_n = length(foreground),
  sizes = '5 to 500 background-measured genes per term',
  databases = files,KEGG_download_url = kegg_url,plot_only_FDR_lt_005 = TRUE,
  difference_from_legacy = 'explicit measured-gene background instead of Enrichr default background'),
  file.path(SD,'25_enrichment_manifest.json'),auto_unbox = TRUE,pretty = TRUE)
