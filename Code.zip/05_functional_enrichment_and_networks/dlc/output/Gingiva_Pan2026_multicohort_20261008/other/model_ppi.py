import io, json, math, sys
import pandas as pd
import networkx as nx
import requests
from fetch_candidate_inputs import ROOT
sys.stdout.reconfigure(encoding='utf-8')
genes = pd.read_csv(ROOT / '12_VD_disease_module_overlap.csv').gene.tolist()
r = requests.post('https://string-db.org/api/tsv/get_string_ids', data={'identifiers': '\r'.join(genes), 'species': 9606, 'echo_query': 1, 'limit': 1, 'caller_identity': 'gingiva-Pan-figure3-reproduction'}, timeout=90)
r.raise_for_status()
mapping = pd.read_csv(io.StringIO(r.text), sep='\t')
mapping['exact_symbol_match'] = mapping.queryItem.eq(mapping.preferredName)
mapping.to_csv(ROOT / '15_STRING_identifier_audit.csv', index=False)
valid = mapping[mapping.exact_symbol_match].drop_duplicates('stringId')
r = requests.post('https://string-db.org/api/tsv/network', data={'identifiers': '\r'.join(valid.stringId), 'species': 9606, 'required_score': 400, 'add_nodes': 0, 'network_type': 'functional', 'caller_identity': 'gingiva-Pan-figure3-reproduction'}, timeout=90)
r.raise_for_status()
edges = pd.read_csv(io.StringIO(r.text), sep='\t')
edges = edges[edges.score.gt(0.4)]
edges.to_csv(ROOT / '15_STRING_functional_edges.csv', index=False)
graph = nx.Graph()
for row in edges.itertuples():
    graph.add_edge(row.preferredName_A, row.preferredName_B, score=row.score)
scores = {g: 0 for g in graph.nodes}
for clique in nx.find_cliques(graph):
    if len(clique) < 2:
        continue
    contribution = math.factorial(len(clique) - 1)
    for g in clique:
        scores[g] += contribution
rank = pd.DataFrame([dict(gene=g, MCC=scores[g], degree=graph.degree(g)) for g in graph])
rank = rank.sort_values(['MCC', 'degree', 'gene'], ascending=[False, False, True])
rank.to_csv(ROOT / '15_PPI_MCC_all_genes.csv', index=False)
rank.head(20).to_csv(ROOT / '15_ML_PPI_candidate_genes.csv', index=False)
status = {'VD_module_overlap': len(genes), 'STRING_exact_mapped': len(valid), 'connected_genes': len(graph), 'edges': len(edges), 'ML_candidate_genes': min(20, len(rank)), 'unmapped': sorted(set(genes) - set(valid.queryItem)), 'manually_added_genes': 0, 'network': 'STRING functional associations, not physical binding or gingiva-specific activity', 'MCC': 'Sum of factorial(|clique|-1) over maximal cliques containing node; isolated nodes hidden', 'model_grid': '78 visually verified Fig3A combinations; not claiming all 113 stated in\u6b63\u6587', 'candidate_genes': rank.head(20).gene.tolist()}
(ROOT / '15_PPI_model_status.json').write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(status, ensure_ascii=False, indent=2), flush=True)
