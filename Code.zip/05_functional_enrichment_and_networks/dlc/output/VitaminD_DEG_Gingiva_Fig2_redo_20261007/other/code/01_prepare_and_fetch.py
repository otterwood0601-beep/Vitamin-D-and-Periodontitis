from __future__ import annotations
import hashlib
import importlib.util
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
import pandas as pd
import requests
ROOT = Path(__file__).resolve().parents[2]
SD = ROOT / '\u5176\u4ed6' / 'source_data'
SD.mkdir(parents=True, exist_ok=True)
SERUM = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u539f\u59cb\u6570\u636e\\06_\u6700\u7ec8\u6295\u7a3f\u51fa\u56fe\u6e90\u8868\\03_\u6b63\u6587\u56fe3_SMR\u4e0eBulkRNA\\BulkRNA')
VD = SERUM / '02_DESeq2_genome' / '12_DESeq2_P005_FC12_DEGs.csv'
VD_ALL = SERUM / '02_DESeq2_genome' / '11_DESeq2_D3_vs_ethanol_all_genes.csv'
HEAT = SERUM / '07_revised_heatmap_rawP005' / 'Figure3B_full_rawP005_heatmap_source_data.csv'
OLD = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\BioorganicChemistry2026_\u5e72\u5b9e\u9a8c\u8fc1\u79fb_20260924')
DISEASE = OLD / 'source_data' / '02_bulk_differential_expression.csv.gz'
OLD_PDF = OLD / 'figures' / 'Fig2_VitaminD_gingiva_targets_enrichment_STRING_BioorgChem_style.pdf'

def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()
vd = pd.read_csv(VD)
all_vd = pd.read_csv(VD_ALL)
dis = pd.read_csv(DISEASE)
assert ((vd.pvalue < 0.05) & (vd.absolute_fold_change >= 1.2)).all()
assert not dis.gene.duplicated().any()
vd = vd.loc[vd.gene_symbol.notna() & vd.gene_symbol.str.strip().ne('')].copy()
vd['gene_symbol'] = vd.gene_symbol.str.strip()
unique_vd = vd.sort_values(['pvalue', 'gene_id']).drop_duplicates('gene_symbol')
genes = set(unique_vd.gene_symbol)
disease_genes = set(dis.loc[dis['adj.P.Val'] < 0.05, 'gene'])
overlap = sorted(genes & disease_genes)
assert len(overlap) > 0
merged = unique_vd.rename(columns={'gene_symbol': 'gene', 'log2FoldChange': 'vitD_log2FC', 'pvalue': 'vitD_raw_p', 'padj': 'vitD_FDR'})
merged = merged.merge(dis[['gene', 'logFC', 'adj.P.Val']].rename(columns={'logFC': 'disease_log2FC', 'adj.P.Val': 'disease_FDR'}), on='gene', how='left', validate='one_to_one')
merged['in_disease_FDR05'] = merged.gene.isin(disease_genes)
merged.to_csv(SD / '08_vitaminD_DEG_gene_set_audit.csv', index=False)
merged.loc[merged.gene.isin(overlap)].sort_values('gene').to_csv(SD / '09_vitaminD_gingiva_overlap_genes.csv', index=False)
(SD / '09_vitaminD_gingiva_overlap_genes.txt').write_text('\n'.join(overlap) + '\n', encoding='utf-8')
for src, name in [(VD, '00_input_vitaminD_DEGs_rawP005_FC12.csv'), (VD_ALL, '00_input_vitaminD_all_genes.csv'), (DISEASE, '00_input_gingival_disease_DE.csv.gz')]:
    dst = SD / name
    if dst.exists():
        assert sha(dst) == sha(src), f'Input conflict: {dst}'
    else:
        shutil.copy2(src, dst)
manifest = {'created_at': datetime.now(timezone.utc).isoformat(), 'vitaminD_source': str(VD), 'vitaminD_source_sha256': sha(VD), 'heatmap_source': str(HEAT), 'heatmap_source_sha256': sha(HEAT), 'disease_source': str(DISEASE), 'disease_source_sha256': sha(DISEASE), 'original_pdf': str(OLD_PDF), 'original_pdf_sha256': sha(OLD_PDF), 'vitaminD_original_DE_rows': len(pd.read_csv(VD)), 'vitaminD_DEG_symbols_n': len(genes), 'gingival_disease_FDR05_n': len(disease_genes), 'overlap_n': len(overlap), 'overlap_genes': overlap, 'vitaminD_definition': 'GSE212728 gingival fibroblasts, D3 vs ethanol; raw P < 0.05 and absolute fold change >= 1.2; deduplicated gene symbols. This is NOT a VDR-binding target set.', 'disease_definition': 'GSE223924 + GSE173078 human gingiva; 22 healthy and 22 periodontitis; unchanged ComBat/limma output, BH FDR < 0.05.', 'enrichment': 'Original Enrichr libraries and default human/genome background retained; exploratory ORA, not a custom measured-gene background analysis.', 'limitations': ['Vitamin D list uses raw P, not FDR significance; GDF15 vitaminD FDR is 0.417374003482893.', 'Whole gingival disease tissue is not fibroblast-specific.', 'Overlap ignores directions; does not establish disease reversal or causality.', 'STRING functional associations are not measured interactions in gingival fibroblasts.'], 'GDF15': all_vd.loc[all_vd.gene_symbol.eq('GDF15'), ['gene_symbol', 'log2FoldChange', 'pvalue', 'padj']].to_dict('records')}
(SD / '00_input_provenance.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'INPUT: vitaminD={len(genes)}, disease={len(disease_genes)}, overlap={len(overlap)}', flush=True)
module_path = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\code\\bioorgchem2026\\02_fetch_enrichment_string.py')
spec = importlib.util.spec_from_file_location('legacy_fig2_fetch', module_path)
legacy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(legacy)
if not all(((SD / f'10_enrichr_{lib}.csv').exists() for lib in legacy.ENRICHR_LIBRARIES)):
    print('Fetching fresh GO/KEGG enrichment for new overlap...', flush=True)
    legacy.enrichr(overlap, SD)
if not (SD / '11_STRING_functional_network.tsv').exists():
    print('Fetching fresh STRING functional network...', flush=True)
    legacy.string_network(overlap, SD)
if not (SD / '11_STRING_identifier_mapping.tsv').exists():
    response = requests.post('https://string-db.org/api/tsv/get_string_ids', data={'identifiers': '\r'.join(overlap), 'species': 9606, 'limit': 1, 'echo_query': 1, 'caller_identity': 'vitd-gingiva-redo'}, timeout=60)
    response.raise_for_status()
    (SD / '11_STRING_identifier_mapping.tsv').write_text(response.text, encoding='utf-8')
print('All input and public resource tables saved.', flush=True)
