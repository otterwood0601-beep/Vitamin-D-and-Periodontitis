options(stringsAsFactors=FALSE, scipen=999)
set.seed(20260924)
.libPaths(c("C:/Users/Lin/AppData/Local/R/win-library/4.5", .libPaths()))
suppressPackageStartupMessages({
  library(data.table); library(ggplot2); library(patchwork); library(ggforce)
  library(igraph); library(ggraph); library(cowplot); library(scales); library(jsonlite)
})
ROOT <- "C:/wb_links/vitd_deg_fig2_20261007"
SD <- file.path(ROOT,"other","source_data")
FD <- file.path(ROOT,"figures")
dir.create(FD,recursive=TRUE,showWarnings=FALSE)
meta <- read_json(file.path(SD,"00_input_provenance.json"),simplifyVector=TRUE)
vd <- fread(file.path(SD,"08_vitaminD_DEG_gene_set_audit.csv"))
de <- fread(file.path(SD,"00_input_gingival_disease_DE.csv.gz"))
target_genes <- sort(unique(vd$gene))
disease_genes <- sort(unique(de[adj.P.Val<0.05,gene]))
overlap <- sort(intersect(target_genes,disease_genes))
stopifnot(length(target_genes)==meta$vitaminD_DEG_symbols_n,length(overlap)==meta$overlap_n)
read_enrich <- function(lib,category) {
  z<-fread(file.path(SD,paste0("10_enrichr_",lib,".csv")))
  z[,category:=category]
  z[,`:=`(neglog10=-log10(pmax(adjusted_p,1e-300)),term_short=stringr::str_wrap(gsub(" \\([^)]*\\)$","",term),width=35))]
  z
}
go<-rbindlist(list(read_enrich("GO_Biological_Process_2025","BP"),read_enrich("GO_Cellular_Component_2025","CC"),read_enrich("GO_Molecular_Function_2025","MF")),fill=TRUE)
kegg<-read_enrich("KEGG_2021_Human","KEGG")
fwrite(go,file.path(SD,"13_overlap_GO_enrichment_combined.csv"))
fwrite(kegg,file.path(SD,"14_overlap_KEGG_enrichment.csv"))
edges<-fread(file.path(SD,"11_STRING_functional_network.tsv"))
idmap<-fread(file.path(SD,"11_STRING_identifier_mapping.tsv"))
idmap<-idmap[order(queryIndex)]
idmap<-unique(idmap,by="stringId")
lookup<-setNames(idmap$queryItem,idmap$stringId)
ed<-edges[,.(from=unname(lookup[stringId_A]),to=unname(lookup[stringId_B]),score)]
unmapped_edge_n<-nrow(ed[is.na(from)|is.na(to)])
if(unmapped_edge_n>0) stop("STRING edges have unmapped IDs; inspect mapping")
stopifnot(all(ed$from %in% overlap),all(ed$to %in% overlap))
ed<-unique(ed[from!=to])
g<-graph_from_data_frame(ed,directed=FALSE,vertices=data.table(name=overlap))
g<-simplify(g,remove.multiple=TRUE,remove.loops=TRUE,edge.attr.comb=list(score="max"))
clqs<-max_cliques(g,min=2)
mcc<-setNames(rep(0,vcount(g)),V(g)$name)
for(cl in clqs) { contribution<-factorial(max(1,length(cl)-1)); mcc[names(cl)]<-mcc[names(cl)]+contribution }
stopifnot(all(is.finite(mcc)))
hub<-data.table(gene=V(g)$name,MCC=as.numeric(mcc[V(g)$name]),Degree=as.numeric(degree(g)))
hub<-hub[order(-MCC,-Degree,gene)]
hub[,rank:=.I]
fwrite(hub,file.path(SD,"15_STRING_MCC_degree_hubs.csv"))
fwrite(ed,file.path(SD,"11_STRING_gene_symbol_edges.csv"))
saveRDS(g,file.path(SD,"11_STRING_graph.rds"))
message("STRING: ",vcount(g)," nodes, ",ecount(g)," edges; exact MCC calculated.")

legacy <- parse("C:/wb_links/bioorgchem2026_code/02_fig2_vitd_targets.R")
reuse <- function(name) {
  hit<-Filter(function(x) is.call(x) && identical(x[[1]],as.name("<-")) && identical(x[[2]],as.name(name)),as.list(legacy))
  stopifnot(length(hit)==1L)
  eval(hit[[1]],envir=.GlobalEnv)
}
reuse("paper_theme")
reuse("venn_dt")
venn_dt$set<-c("Gingival disease\n(FDR < 0.05)","Vitamin D3 DEGs\n(raw P < 0.05; FC >= 1.2)")
reuse("pB")
pB<-pB+annotate("text",x=0.52,y=0.12,label="D3: raw P < 0.05, FC >= 1.2; gingiva: FDR < 0.05",size=2.1,family="Arial")
reuse("go_dot")
go_dot[,term_short:=stringr::str_wrap(gsub(" \\([^)]*\\)$","",term),width=43)]
go_dot[,term_short:=factor(term_short,levels=rev(unique(term_short)))]
reuse("pD")
reuse("kegg_dot")
reuse("pE")

pD<-pD+guides(colour=guide_colourbar(title="FDR"))
pE<-pE+guides(colour=guide_colourbar(title="FDR"))
fwrite(go_dot,file.path(SD,"17_GO_displayed_terms.csv"))
fwrite(kegg_dot,file.path(SD,"18_KEGG_displayed_terms.csv"))

top_hub<-hub[1:min(20,.N)]
V(g)$degree<-degree(g)
label_genes<-unique(c(top_hub$gene,"GDF15"))
V(g)$display_label<-ifelse(V(g)$name %in% label_genes,V(g)$name,"")
pF<-ggraph(g,layout="fr")+
  geom_edge_link(aes(alpha=score),colour="#6B6B6B",show.legend=FALSE)+
  geom_node_point(aes(size=degree,fill=degree),shape=21,colour="#666666",stroke=.3)+
  geom_node_text(aes(label=display_label),size=2.2,repel=TRUE,max.overlaps=Inf,seed=20260924,
    box.padding=.65,point.padding=.5,force=10,max.time=4,max.iter=50000,min.segment.length=0,family="Arial")+
  scale_fill_gradient(low="#DDF4D5",high="#F4A3A3")+
  scale_size(range=c(4,10),guide="none")+theme_void()+theme(legend.position="none")
reuse("g_hub")
V(g_hub)$MCC<-top_hub$MCC[match(V(g_hub)$name,top_hub$gene)]
reuse("pG")
reuse("hub_plot")
hub_plot[,gene:=factor(gene,levels=rev(gene))]
reuse("scale_factor")
reuse("pH")

WIDTH<-10.8
old_rows<-13.3*c(.82,1.15,1.05,1.05)/sum(c(.82,1.15,1.05,1.05))
rows<-old_rows*c(1,1.2,1,1)
HEIGHT<-sum(rows)
boxes<-data.table(new_label=c("A","B","C","D","E","F"),old_label=c("B","D","E","F","G","H"),
  x_in=c(WIDTH/3,0,WIDTH*4/9,0,WIDTH*5/9,WIDTH*5/9),
  y_in=c(sum(rows[2:4]),sum(rows[3:4]),sum(rows[3:4]),0,rows[4],0),
  width_in=c(WIDTH/3,WIDTH*4/9,WIDTH*5/9,WIDTH*5/9,WIDTH*4/9,WIDTH*4/9),
  height_in=c(rows[1],rows[2],rows[2],sum(rows[3:4]),rows[3],rows[4]),
  height_scale_vs_old=c(1,1.2,1.2,1,1,1))
fwrite(boxes,file.path(SD,"19_panel_geometry_inches.csv"))
plots<-list(pB,pD,pE,pF,pG,pH)

draw_figure<-function(){
  grid::grid.newpage()
  for(i in seq_along(plots)) {
    b<-boxes[i]
    grid::pushViewport(grid::viewport(x=grid::unit(b$x_in,"in"),y=grid::unit(b$y_in,"in"),
      width=grid::unit(b$width_in,"in"),height=grid::unit(b$height_in,"in"),just=c("left","bottom")))
    grid::grid.draw(ggplotGrob(plots[[i]]))
    grid::grid.text(b$new_label,x=grid::unit(3,"pt"),y=grid::unit(1,"npc")-grid::unit(3,"pt"),
      just=c("left","top"),gp=grid::gpar(fontfamily="Arial",fontsize=15,fontface="plain"))
    grid::popViewport()
  }
}
pdf_path<-file.path(FD,"Fig2_VitaminD_DEG_Gingiva_overlap_GO_KEGG_STRING_20261007.pdf")
if(file.exists(pdf_path) && !"--rerender" %in% commandArgs(TRUE)) stop("Refusing to overwrite output without explicit rerender flag")
grDevices::cairo_pdf(pdf_path,width=WIDTH,height=HEIGHT,family="Arial",bg="white"); draw_figure(); dev.off()
grDevices::png(file.path(FD,"Fig2_VitaminD_DEG_Gingiva_overlap_GO_KEGG_STRING_20261007.png"),width=WIDTH,height=HEIGHT,units="in",res=600,type="cairo",bg="white"); draw_figure(); dev.off()
grDevices::png(file.path(ROOT,"other","renders","Fig2_review.png"),width=WIDTH,height=HEIGHT,units="in",res=160,type="cairo",bg="white"); draw_figure(); dev.off()
meta$created_at<-format(Sys.time(),"%Y-%m-%d %H:%M:%S %z")
meta$network_nodes<-vcount(g);meta$network_edges<-ecount(g);meta$network_isolates<-sum(degree(g)==0)
meta$STRING_mapped_unique_ids<-nrow(idmap);meta$maximal_clique_n<-length(clqs)
meta$top_hubs<-as.data.frame(top_hub)
meta$GDF15_network<-as.data.frame(hub[gene=="GDF15"])
meta$GDF15_overlap<-as.data.frame(fread(file.path(SD,"09_vitaminD_gingiva_overlap_genes.csv"))[gene=="GDF15"])
meta$GO_significant_terms<-as.data.frame(go[adjusted_p<.05,.N,by=category])
meta$KEGG_significant_terms<-nrow(kegg[adjusted_p<.05])
meta$panel_mapping<-as.data.frame(boxes)
meta$full_network_label_policy<-"All 352 input nodes retained; only top 20 MCC hubs and GDF15 labelled. Isolated nodes are not discarded."
meta$pdf_dimensions_inches<-c(WIDTH,HEIGHT)
meta$old_A_and_C_removed<-TRUE
meta$VDR_curated_or_GO_input_used<-FALSE
write_json(meta,file.path(SD,"16_Fig2_manifest.json"),auto_unbox=TRUE,pretty=TRUE,digits=12)
message("Finished: ",pdf_path)
print(hub[1:5]); print(meta$GDF15_overlap)
