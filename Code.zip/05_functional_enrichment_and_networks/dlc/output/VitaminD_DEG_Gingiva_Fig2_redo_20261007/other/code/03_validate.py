import hashlib
import json
from pathlib import Path
import fitz
import pandas as pd
from PIL import Image
root = Path(__file__).resolve().parents[2]
sd = root / '\u5176\u4ed6' / 'source_data'
meta = json.loads((sd / '16_Fig2_manifest.json').read_text(encoding='utf-8'))
vd = pd.read_csv(sd / '00_input_vitaminD_DEGs_rawP005_FC12.csv')
dis = pd.read_csv(sd / '00_input_gingival_disease_DE.csv.gz')
expected = set(vd.loc[vd.gene_symbol.notna(), 'gene_symbol']) & set(dis.loc[dis['adj.P.Val'] < 0.05, 'gene'])
result = pd.read_csv(sd / '09_vitaminD_gingiva_overlap_genes.csv')
assert set(result.gene) == expected
assert len(result) == len(expected) == 352
assert result.gene.is_unique
assert (result.vitD_raw_p < 0.05).all() and (result.absolute_fold_change >= 1.2).all()
assert (result.disease_FDR < 0.05).all()
assert set(result.gene) == set(pd.read_csv(sd / '15_STRING_MCC_degree_hubs.csv').gene)
geometry = pd.read_csv(sd / '19_panel_geometry_inches.csv')
assert list(geometry.new_label) == list('ABCDEF')
assert list(geometry.old_label) == ['B', 'D', 'E', 'F', 'G', 'H']
assert list(geometry.height_scale_vs_old) == [1.0, 1.2, 1.2, 1.0, 1.0, 1.0]
with Path(meta['original_pdf']).open('rb') as stream:
    old_hash = hashlib.file_digest(stream, 'sha256').hexdigest()
assert old_hash == meta['original_pdf_sha256']
pdf = root / '\u56fe' / 'Fig2_VitaminD_DEG_Gingiva_overlap_GO_KEGG_STRING_20261007.pdf'
doc = fitz.open(pdf)
assert len(doc) == 1
page = doc[0]
fonts = sorted({x[3] for x in page.get_fonts()})
assert all(('Arial' in font for font in fonts)), fonts
text = page.get_text()
for tag in list('ABCDEF'):
    assert tag in text.splitlines()
assert '5285' not in text and '4950' in text and ('352' in text) and ('680' in text)
assert '25(OH)D3' not in text
assert text.count('FDR') >= 3
assert 'p value' not in text
assert 'GDF15' in text
width, height = meta['pdf_dimensions_inches']
assert abs(page.rect.width / 72 - width) < 0.01 and abs(page.rect.height / 72 - height) < 0.01
page.get_pixmap(matrix=fitz.Matrix(1.8, 1.8)).save(root / '\u5176\u4ed6' / 'renders' / 'Fig2_PDF_actual_review.png')
with Image.open(root / '\u56fe' / pdf.with_suffix('.png').name) as png:
    raster_dimensions = list(png.size)
    raster_dpi = png.info.get('dpi')
    assert abs(png.width / width - 600) < 1 and abs(png.height / height - 600) < 1
go = pd.read_csv(sd / '13_overlap_GO_enrichment_combined.csv')
kegg = pd.read_csv(sd / '14_overlap_KEGG_enrichment.csv')
hubs = pd.read_csv(sd / '15_STRING_MCC_degree_hubs.csv')
report = {'input_membership_reconciled': True, 'original_pdf_unchanged': True, 'old_panels_A_C_removed': True, 'new_labels': list('ABCDEF'), 'GO_KEGG_outer_panel_height_ratio': 1.2, 'fonts': fonts, 'pdf_page_count': len(doc), 'pdf_inches': [width, height], 'png_pixels': raster_dimensions, 'png_dpi': raster_dpi, 'GO_significant_terms': go.loc[go.adjusted_p.lt(0.05)].groupby('category').size().to_dict(), 'KEGG_significant_terms': int(kegg.adjusted_p.lt(0.05).sum()), 'GDF15_network': hubs.loc[hubs.gene.eq('GDF15')].to_dict('records'), 'GDF15_input_result': result.loc[result.gene.eq('GDF15'), ['gene', 'vitD_log2FC', 'vitD_raw_p', 'vitD_FDR', 'disease_log2FC', 'disease_FDR']].to_dict('records'), 'PDF_visual_review': 'See 21_visual_review.json; its SHA256 must match this PDF. Repeat visual review after future rerender.'}
(sd / '20_validation_report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(report, ensure_ascii=False, indent=2))
print('TOP_GO_BP', go.loc[go.category.eq('BP'), ['term', 'adjusted_p']].head(4).to_string(index=False))
print('TOP_KEGG', kegg[['term', 'adjusted_p']].head(8).to_string(index=False))
