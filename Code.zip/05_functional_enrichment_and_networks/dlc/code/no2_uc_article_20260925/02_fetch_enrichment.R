options(stringsAsFactors = FALSE, scipen = 999)
suppressPackageStartupMessages({
  library(enrichR)
  library(data.table)
})

OUT <- "C:/wb_links/jhazmat2026_no2uc_20260925/source_data"
genes <- unique(trimws(readLines(file.path(OUT, "09_enrichment_input_genes.txt"))))
genes <- genes[nzchar(genes)]
if (!length(genes)) stop("No enrichment genes supplied")

dbs <- c("GO_Biological_Process_2025", "KEGG_2021_Human")
res <- enrichr(genes, dbs)
for (db in dbs) {
  z <- as.data.table(res[[db]])
  if (nrow(z)) {
    setnames(z, make.names(names(z)))
    z[, input_gene_count := length(genes)]
  }
  fwrite(z, file.path(OUT, paste0("15_VD17_high_", db, ".csv")))
}

cat("Enrichment completed for", length(genes), "genes\n")
