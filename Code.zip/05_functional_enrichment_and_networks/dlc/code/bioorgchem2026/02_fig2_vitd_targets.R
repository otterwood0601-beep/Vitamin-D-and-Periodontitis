options(stringsAsFactors = FALSE, scipen = 999)
set.seed(20260924)

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(patchwork)
  library(ggforce)
  library(igraph)
  library(ggraph)
  library(cowplot)
  library(png)
  library(scales)
})

OUT <- "C:/wb_links/bioorgchem2026_20260924"
SD <- file.path(OUT, "source_data")
FD <- file.path(OUT, "figures")

read_gmt <- function(path) {
  lines <- readLines(path, warn = FALSE)
  rows <- lapply(lines, function(x) {
    p <- strsplit(x, "\t", fixed = TRUE)[[1]]
    if (length(p) < 3) return(NULL)
    data.table(set = p[1], description = p[2], gene = p[-c(1, 2)])
  })
  rbindlist(rows, fill = TRUE)
}

message("[1/5] Build a transparent vitamin D/VDR gene set")
curated <- read_gmt("C:/wb_links/dlc_data/outputs/curated_gene_sets_v1.gmt")
curated <- curated[set == "VDR_target_signature"]
curated[, source := "Project curated VDR target signature"]

go_bp <- read_gmt("C:/wb_links/genesets/GO_Biological_Process_2025.gmt")
vitd_go <- go_bp[grepl("vitamin d|vdr", set, ignore.case = TRUE)]
vitd_go[, source := paste0("GO: ", set)]
target_sources <- unique(rbindlist(list(
  curated[, .(gene, source)],
  vitd_go[, .(gene, source)]
)))
target_genes <- sort(unique(target_sources$gene))

de <- fread(file.path(SD, "02_bulk_differential_expression.csv.gz"))
disease_genes <- de[adj.P.Val < 0.05, gene]
overlap <- sort(intersect(target_genes, disease_genes))
if (length(overlap) < 5) stop("Too few vitamin D/gingiva overlap genes for Fig. 2")

target_audit <- data.table(gene = target_genes)
target_audit[, disease_FDR := de$adj.P.Val[match(gene, de$gene)]]
target_audit[, disease_logFC := de$logFC[match(gene, de$gene)]]
target_audit[, in_disease_FDR05 := gene %in% disease_genes]
target_audit[, sources := vapply(gene, function(g) {
  paste(unique(target_sources[gene == g, source]), collapse = " | ")
}, character(1))]
fwrite(target_audit, file.path(SD, "08_vitaminD_VDR_gene_set_audit.csv"))
fwrite(data.table(gene = overlap,
                  logFC = de$logFC[match(overlap, de$gene)],
                  FDR = de$adj.P.Val[match(overlap, de$gene)]),
       file.path(SD, "09_vitaminD_gingiva_overlap_genes.csv"))
writeLines(overlap, file.path(SD, "09_vitaminD_gingiva_overlap_genes.txt"))

message("[2/5] Query cached public enrichment, STRING, and PubChem resources")
resource_files <- c(
  file.path(SD, "10_enrichr_GO_Biological_Process_2025.csv"),
  file.path(SD, "10_enrichr_GO_Cellular_Component_2025.csv"),
  file.path(SD, "10_enrichr_GO_Molecular_Function_2025.csv"),
  file.path(SD, "10_enrichr_KEGG_2021_Human.csv"),
  file.path(SD, "11_STRING_functional_network.tsv"),
  file.path(SD, "12_PubChem_calcifediol_2D.png")
)
if (!all(file.exists(resource_files))) {
  status <- system2(
    "python",
    c("C:/wb_links/bioorgchem2026_code/02_fetch_enrichment_string.py",
      "--genes", file.path(SD, "09_vitaminD_gingiva_overlap_genes.txt"),
      "--out", SD),
    stdout = file.path(OUT, "logs", "02_fetch_enrichment_string.log"),
    stderr = file.path(OUT, "logs", "02_fetch_enrichment_string.log")
  )
  if (!identical(status, 0L)) stop("Public resource query failed; see log")
}

read_enrich <- function(lib, category) {
  z <- fread(file.path(SD, paste0("10_enrichr_", lib, ".csv")))
  if (!nrow(z)) return(z)
  z[, category := category]
  z[, `:=`(
    adjusted_p = pmax(adjusted_p, 1e-300),
    neglog10 = -log10(pmax(adjusted_p, 1e-300)),
    term_short = stringr::str_wrap(gsub(" \\([^)]*\\)$", "", term), width = 35)
  )]
  z
}

go <- rbindlist(list(
  read_enrich("GO_Biological_Process_2025", "BP"),
  read_enrich("GO_Cellular_Component_2025", "CC"),
  read_enrich("GO_Molecular_Function_2025", "MF")
), fill = TRUE)
kegg <- read_enrich("KEGG_2021_Human", "KEGG")
fwrite(go, file.path(SD, "13_overlap_GO_enrichment_combined.csv"))
fwrite(kegg, file.path(SD, "14_overlap_KEGG_enrichment.csv"))

message("[3/5] Build STRING graph and MCC hub ranking")
edges <- fread(file.path(SD, "11_STRING_functional_network.tsv"))
if (nrow(edges)) {
  ed <- unique(edges[, .(from = preferredName_A, to = preferredName_B, score)])
} else {
  ed <- data.table(from = character(), to = character(), score = numeric())
}
g <- graph_from_data_frame(ed, directed = FALSE, vertices = data.table(name = overlap))
g <- simplify(g, remove.multiple = TRUE, remove.loops = TRUE,
              edge.attr.comb = list(score = "max"))

clqs <- max_cliques(g, min = 2)
mcc <- setNames(rep(0, vcount(g)), V(g)$name)
if (length(clqs)) {
  for (cl in clqs) {
    n <- length(cl)
    contribution <- factorial(max(1, n - 1))
    mcc[names(cl)] <- mcc[names(cl)] + contribution
  }
}
hub <- data.table(gene = V(g)$name,
                  MCC = as.numeric(mcc[V(g)$name]),
                  Degree = degree(g, V(g)$name))
hub <- hub[order(-MCC, -Degree, gene)]
fwrite(hub, file.path(SD, "15_STRING_MCC_degree_hubs.csv"))

paper_theme <- theme_bw(base_size = 8, base_family = "Arial") +
  theme(
    panel.grid.major = element_line(colour = "#E7E7E7", linewidth = 0.25),
    panel.grid.minor = element_blank(),
    plot.title = element_text(hjust = 0.5, size = 9),
    axis.title = element_text(size = 8),
    axis.text = element_text(size = 6.4, colour = "black"),
    legend.title = element_text(size = 7),
    legend.text = element_text(size = 6.3),
    plot.margin = margin(3, 3, 3, 3)
  )
cat_cols <- c(BP = "#E9544D", CC = "#4C91D7", MF = "#37B66B")

message("[4/5] Recreate the Bioorganic Chemistry Fig. 2 layout")
calc_img <- readPNG(file.path(SD, "12_PubChem_calcifediol_2D.png"))
pA <- ggdraw() +
  draw_image(calc_img, x = 0.02, y = 0.10, width = 0.96, height = 0.84) +
  draw_label("25(OH)D3", x = 0.5, y = 0.04, fontfamily = "Arial", size = 9)

venn_dt <- data.table(
  x0 = c(0.42, 0.62), y0 = 0.52, r = 0.30,
  set = c("Gingival disease\n(FDR < 0.05)", "Vitamin D/VDR\ncurated set"),
  fill = c("#D888F5", "#F2EF69")
)
pB <- ggplot() +
  geom_circle(data = venn_dt, aes(x0 = x0, y0 = y0, r = r, fill = set),
              alpha = 0.65, colour = NA) +
  annotate("text", x = 0.25, y = 0.52,
           label = length(setdiff(disease_genes, target_genes)), size = 3.1,
           family = "Arial") +
  annotate("text", x = 0.52, y = 0.52, label = length(overlap), size = 3.1,
           family = "Arial") +
  annotate("text", x = 0.79, y = 0.52,
           label = length(setdiff(target_genes, disease_genes)), size = 3.1,
           family = "Arial") +
  annotate("text", x = 0.30, y = 0.93, label = "Gingiva", size = 3,
           family = "Arial") +
  annotate("text", x = 0.73, y = 0.93, label = "Vitamin D", size = 3,
           family = "Arial") +
  scale_fill_manual(values = setNames(venn_dt$fill, venn_dt$set), guide = "none") +
  coord_fixed(xlim = c(0, 1), ylim = c(0.1, 1), clip = "off") + theme_void()

go_circle <- go[order(adjusted_p), head(.SD, 4), by = category]
go_circle[, idx := .I]
go_circle[, label := stringr::str_trunc(gsub(" \\([^)]*\\)$", "", term), 22)]
go_circle[, text_angle := 90 - 360 * (idx - 0.5) / .N]
pC <- ggplot(go_circle, aes(idx, neglog10, fill = category)) +
  geom_col(width = 0.86, colour = "white", linewidth = 0.20) +
  geom_text(aes(y = neglog10 + 0.22, label = label, angle = text_angle), size = 1.65,
            hjust = 0,
            family = "Arial") +
  scale_fill_manual(values = cat_cols, name = NULL) +
  coord_polar(start = -pi / 2, clip = "off") +
  ylim(0, max(go_circle$neglog10, na.rm = TRUE) + 3.8) +
  theme_void(base_family = "Arial") +
  theme(legend.position = "bottom", legend.text = element_text(size = 6)) +
  labs(fill = NULL)

go_dot <- go[order(adjusted_p), head(.SD, 7), by = category]
go_dot[, term_short := factor(term_short, levels = rev(unique(term_short)))]
pD <- ggplot(go_dot, aes(gene_ratio, term_short, size = count, colour = adjusted_p)) +
  geom_point() +
  facet_grid(category ~ ., scales = "free_y", space = "free_y") +
  scale_colour_gradient(low = "#E85A64", high = "#477DB3", trans = "reverse",
                        name = "p value") +
  scale_size(range = c(1.8, 5), name = "Count") +
  labs(x = "GeneRatio", y = NULL) + paper_theme +
  theme(strip.text.y = element_text(size = 6.5),
        legend.position = "left", axis.text.y = element_text(size = 5.8))

kegg_dot <- kegg[order(adjusted_p)][1:min(25, .N)]
kegg_dot[, term_short := factor(stringr::str_wrap(term, 32),
                                levels = rev(stringr::str_wrap(term, 32)))]
pE <- ggplot(kegg_dot, aes(gene_ratio, term_short, size = count, colour = adjusted_p)) +
  geom_point() +
  scale_colour_gradient(low = "#E85A64", high = "#477DB3", trans = "reverse",
                        name = "p value") +
  scale_size(range = c(1.8, 5), name = "Count") +
  labs(x = "GeneRatio", y = NULL) + paper_theme +
  theme(axis.text.y = element_text(size = 5.7))

V(g)$degree <- degree(g)
pF <- ggraph(g, layout = "fr") +
  geom_edge_link(aes(alpha = score), colour = "#6B6B6B", show.legend = FALSE) +
  geom_node_point(aes(size = degree, fill = degree), shape = 21,
                  colour = "#666666", stroke = 0.3) +
  geom_node_text(aes(label = name), size = 2.2, repel = TRUE,
                 family = "Arial") +
  scale_fill_gradient(low = "#DDF4D5", high = "#F4A3A3") +
  scale_size(range = c(4, 10), guide = "none") +
  theme_void() + theme(legend.position = "none")

top_hub <- hub[1:min(20, .N)]
g_hub <- induced_subgraph(g, vids = top_hub$gene)
V(g_hub)$MCC <- top_hub$MCC[match(V(g_hub)$name, top_hub$gene)]
pG <- ggraph(g_hub, layout = "circle") +
  geom_edge_link(colour = "black", linewidth = 0.28, alpha = 0.75) +
  geom_node_label(aes(label = name, fill = MCC), colour = "black",
                  size = 2.1, label.size = 0, family = "Arial") +
  scale_fill_gradient(low = "#F2E51B", high = "#FF3B1F") +
  theme_void() + theme(legend.position = "none")

hub_plot <- copy(top_hub)
hub_plot[, gene := factor(gene, levels = rev(gene))]
scale_factor <- if (max(hub_plot$Degree) > 0) max(hub_plot$MCC, 1) / max(hub_plot$Degree) else 1
pH <- ggplot(hub_plot, aes(gene)) +
  geom_col(aes(y = MCC), fill = "#F47A1F", width = 0.70) +
  geom_line(aes(y = Degree * scale_factor, group = 1), colour = "black", linewidth = 0.35) +
  geom_point(aes(y = Degree * scale_factor), colour = "black", size = 0.9) +
  scale_y_continuous(name = "CytoHubba MCC score",
                     sec.axis = sec_axis(~ . / scale_factor, name = "Degree")) +
  coord_flip() + labs(title = "Top hubs", x = NULL) + paper_theme +
  theme(axis.text.y = element_text(size = 6), legend.position = "none")

layout_design <- "
AAABBBCCC
DDDDEEEEE
FFFFFGGGG
FFFFFHHHH
"
fig2 <- pA + pB + pC + pD + pE + pF + pG + pH +
  plot_layout(design = layout_design, heights = c(0.82, 1.15, 1.05, 1.05)) +
  plot_annotation(tag_levels = "A", theme = theme(
    plot.tag = element_text(family = "Arial", size = 15, face = "plain")
  ))

ggsave(file.path(FD, "Fig2_VitaminD_gingiva_targets_enrichment_STRING_BioorgChem_style.pdf"),
       fig2, width = 10.8, height = 13.3, units = "in", device = cairo_pdf)

manifest <- list(
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  vitaminD_VDR_gene_set_n = length(target_genes),
  gingival_disease_FDR05_n = length(disease_genes),
  overlap_n = length(overlap),
  overlap_genes = overlap,
  target_definition = paste(
    "Union of the project's curated VDR target signature and GO gene sets whose names explicitly contain vitamin D or VDR."
  ),
  disease_definition = "FDR < 0.05 in the 44-sample two-cohort human gingiva analysis",
  caveat = paste(
    "GO-derived genes contribute to the vitamin D set, so GO enrichment is descriptive and not independent validation.",
    "The STRING network is functional association, not gingiva-specific physical binding evidence."
  )
)
jsonlite::write_json(manifest, file.path(SD, "16_Fig2_manifest.json"),
                     auto_unbox = TRUE, pretty = TRUE)

message("[5/5] Completed Fig. 2")
cat("vitaminD_set=", length(target_genes), "\n", sep = "")
cat("gingiva_FDR05=", length(disease_genes), "\n", sep = "")
cat("overlap=", length(overlap), " [", paste(overlap, collapse = ", "), "]\n", sep = "")
