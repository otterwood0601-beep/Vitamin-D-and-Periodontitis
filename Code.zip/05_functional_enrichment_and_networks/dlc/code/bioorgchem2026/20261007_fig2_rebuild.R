options(stringsAsFactors=FALSE, scipen=999)
set.seed(20260924)
.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(ggplot2);library(patchwork);library(ggforce);library(igraph);library(ggraph);library(cowplot);library(scales)})
args <- commandArgs(trailingOnly=TRUE)
OUT <- if(length(args)>=1) args[1] else 'C:/wb_links/vitd_overlap_20261007'
pdf_name <- if(length(args)>=2) args[2] else 'Fig2_VitaminD_DEG_FDR005_plus_GDF15_6panels_20261007.pdf'
compact_network200 <- length(args)>=4 && args[4] %in% c('network200_compact','network100_compact')
network_score <- if(length(args)>=4 && args[4]=='network100_compact') 100 else 200
D_prune_spread <- length(args)>=5 && args[5]=='D_prune_spread'
C_width150 <- length(args)>=6 && args[6]=='C_width150'
B_width150 <- length(args)>=7 && args[7]=='B_width150'
ecm_quota <- length(args)>=3 && args[3]=='ecm_quota25'
square_compact_B <- length(args)>=3 && args[3]=='facet5_BC_compact_Bsquare'
compact_BC <- length(args)>=3 && args[3] %in% c('facet5_BC_compact_largefont','facet5_BC_compact_Bsquare')
same_height_C_ECM <- length(args)>=3 && args[3] %in% c('facet5_equalheight_C_ECMred','facet5_BC_compact_largefont','facet5_BC_compact_Bsquare')
actual_square_red <- length(args)>=3 && args[3] %in% c('facet5_panel_square_red','facet5_equalheight_C_ECMred','facet5_BC_compact_largefont','facet5_BC_compact_Bsquare')
facet_clean <- length(args)>=3 && args[3] %in% c('facet5_clean','facet5_panel_square_red','facet5_equalheight_C_ECMred','facet5_BC_compact_largefont','facet5_BC_compact_Bsquare')
ecm_square <- length(args)>=3 && args[3] %in% c('ecm_square','ecm_quota25','facet5_clean','facet5_panel_square_red','facet5_equalheight_C_ECMred','facet5_BC_compact_largefont','facet5_BC_compact_Bsquare')
SD <- file.path(OUT,'source_data')
FD <- file.path(OUT,'figures')
manifest <- jsonlite::read_json(file.path(SD,'16_Fig2_manifest.json'),simplifyVector=FALSE)
baseline_layout <- manifest$layout
baseline_square_geometry <- if(is.null(baseline_layout$actual_square_plotting_panels)) baseline_layout$BC_previous_geometry else baseline_layout$actual_square_plotting_panels
disease_lfc_cutoff <- if(is.null(manifest$disease_abs_log2FC_threshold)) 0 else manifest$disease_abs_log2FC_threshold
vitd_lfc_cutoff <- if(is.null(manifest$vitaminD_abs_log2FC_threshold)) 0 else manifest$vitaminD_abs_log2FC_threshold
audit <- fread(file.path(SD,'08_vitaminD_DEG_gene_set_audit.csv'))
target_genes <- sort(audit$gene)
local_disease <- file.path(SD,'02_bulk_differential_expression.csv.gz')
de <- fread(if(file.exists(local_disease)) local_disease else 'C:/wb_links/bioorgchem2026_20260924/source_data/02_bulk_differential_expression.csv.gz')
disease_genes <- de[adj.P.Val < .05 & abs(logFC)>=disease_lfc_cutoff,gene]
overlap <- sort(audit[in_overlap==TRUE,gene])
stopifnot(length(target_genes)==manifest$vitaminD_total_with_exception_n,length(overlap)==manifest$overlap_n,length(disease_genes)==manifest$disease_FDR_n)

original <- parse('C:/wb_links/bioorgchem2026_code/02_fig2_vitd_targets.R')
heads <- vapply(original,function(e) paste(deparse(e),collapse='\n'),character(1))
eval_range <- function(first,last) {
  a <- which(startsWith(heads,first)); b <- which(startsWith(heads,last))
  stopifnot(length(a)==1L,length(b)==1L,a<=b)
  for(i in seq(a,b)) eval(original[[i]],envir=.GlobalEnv)
}
eval_range('read_enrich <-','fwrite(kegg,')
edges <- fread(file.path(SD,'11_STRING_functional_network.tsv'))
unmatched <- setdiff(unique(c(edges$preferredName_A,edges$preferredName_B)),overlap)
if(length(unmatched)) stop('STRING preferred symbols require explicit mapping: ',paste(unmatched,collapse=', '))
eval_range('edges <-','fwrite(hub,')
mapping <- fread(file.path(SD,'11_STRING_exact_mapping.csv'))
unmapped <- setdiff(overlap,mapping[exact_symbol_match==TRUE,queryItem])
hub[, mapping_verified := !gene %in% unmapped]
hub[mapping_verified==FALSE, `:=`(MCC=NA_real_,Degree=NA_real_)]
hub <- hub[order(-MCC,-Degree,gene,na.last=TRUE)]
fwrite(hub,file.path(SD,'15_STRING_MCC_degree_hubs.csv'))
eval_range('paper_theme <-','cat_cols <-')
eval_range('venn_dt <-','pB <-')
pB <- pB +
  annotate('text',x=.5,y=.13,label=if(disease_lfc_cutoff>0) sprintf('Both: FDR < 0.05, |log2FC| >= %.0f; vitamin D + GDF15 (added)',vitd_lfc_cutoff) else sprintf('Gingiva: FDR < 0.05; vitamin D: FDR < 0.05, |log2FC| >= %.0f + GDF15',vitd_lfc_cutoff),size=1.8,family='Arial') +
  annotate('text',x=.5,y=.07,label='GDF15 vitamin D FDR = 0.417 (not significant)',size=1.9,family='Arial') +
  coord_fixed(xlim=c(0,1),ylim=c(0,1),clip='off')
if(facet_clean) {
  
  eval_range('venn_dt <-','pB <-')
}
eval_range('go_dot <-','pE <-')

pD <- pD + labs(colour='FDR')
pE <- pE + labs(colour='FDR')
col_scale_D <- pD$scales$get_scales('colour')
col_scale_D$name <- 'FDR'
col_scale_E <- pE$scales$get_scales('colour')
col_scale_E$name <- 'FDR'
go_no_sig <- c('BP','CC','MF')[!c('BP','CC','MF') %in% unique(go[adjusted_p < .05,category])]
go_caption <- paste0('Top terms shown; significance threshold: FDR < 0.05.',
                     if(length(go_no_sig)) paste0('\nNo significant terms in ',paste(go_no_sig,collapse=', '),'.') else '')
pD <- pD + labs(caption=go_caption) + theme(plot.caption=element_text(family='Arial',size=5.8,hjust=0))
pE <- pE + labs(caption='Top terms shown, including non-significant terms; FDR < 0.05 required.') +
  theme(plot.caption=element_text(family='Arial',size=5.8,hjust=0))
if(ecm_square) {
  
  ecm_pattern <- 'extracellular matrix|collagen|integrin|cell adhesion|cell-cell adhesion|focal adhesion|tissue remodeling|wound healing|cell junction|cell-cell junction|proteoglycan|TGF.beta|actin cytoskeleton|adherens junction'
  go_dot <- copy(go[grepl(ecm_pattern,term,ignore.case=TRUE)])
  kegg_dot <- copy(kegg[grepl(ecm_pattern,term,ignore.case=TRUE)])
  stopifnot(nrow(go_dot)>0,nrow(kegg_dot)>0)
  if(ecm_quota) {
    
    go_seed_terms <- c('Collagen-Containing Extracellular Matrix (GO:0062023)',
                       'Focal Adhesion (GO:0005925)',
                       'Wound Healing (GO:0042060)',
                       'Regulation of Tissue Remodeling (GO:0034103)',
                       'Positive Regulation of Wound Healing (GO:0090303)')
    go_ecm <- copy(go[term %in% go_seed_terms])
    stopifnot(nrow(go_ecm)==5)
    go_other <- copy(go[!grepl(ecm_pattern,term,ignore.case=TRUE)])
    setorder(go_other,adjusted_p,term)
    
    go_other <- go_other[,head(.SD,5),by=category]
    stopifnot(nrow(go_other)==15)
    go_dot <- rbindlist(list(go_ecm,go_other),use.names=TRUE)
    go_dot[, ECM_related := grepl(ecm_pattern,term,ignore.case=TRUE)]
    kegg_ecm <- copy(kegg_dot)
    setorder(kegg_ecm,adjusted_p,term)
    kegg_other <- copy(kegg[!grepl(ecm_pattern,term,ignore.case=TRUE)])
    setorder(kegg_other,adjusted_p,term)
    kegg_total <- min(25,4*nrow(kegg_ecm))
    kegg_ecm <- head(kegg_ecm,ceiling(kegg_total*.25))
    kegg_dot <- rbindlist(list(kegg_ecm,head(kegg_other,kegg_total-nrow(kegg_ecm))),use.names=TRUE)
    kegg_dot[, ECM_related := grepl(ecm_pattern,term,ignore.case=TRUE)]
    stopifnot(nrow(go_dot)==20,mean(go_dot$ECM_related)>=.25,
              mean(kegg_dot$ECM_related)>=.25,any(!go_dot$ECM_related),any(!kegg_dot$ECM_related))
  }
  if(facet_clean) {
    go_facet_seeds <- list(
      BP=c('Wound Healing (GO:0042060)','Regulation of Tissue Remodeling (GO:0034103)'),
      CC=c('Collagen-Containing Extracellular Matrix (GO:0062023)','Focal Adhesion (GO:0005925)'),
      MF=c('N-acyltransferase Activity (GO:0016410)'))
    go_dot <- rbindlist(lapply(names(go_facet_seeds),function(cat) {
      seeds <- go[category==cat & term %in% go_facet_seeds[[cat]]]
      stopifnot(nrow(seeds)==length(go_facet_seeds[[cat]]))
      rest <- copy(go[category==cat & !term %in% go_facet_seeds[[cat]] & !grepl(ecm_pattern,term,ignore.case=TRUE)])
      setorder(rest,adjusted_p,term)
      rbindlist(list(seeds,head(rest,5-nrow(seeds))))
    }),use.names=TRUE)
    go_dot[, ECM_related := term %in% unlist(go_facet_seeds)]
    go_dot[, ECM_relation_type := ifelse(!ECM_related,'not selected as ECM-related',
      ifelse(category=='MF','indirect: TGM2 protein cross-linking; term itself is not ECM-specific',
      ifelse(category=='BP','related tissue repair / remodeling','ECM localization / adhesion structure')))]
    go_dot[, ECM_relation_evidence := ifelse(category=='MF' & ECM_related,'https://www.uniprot.org/uniprotkb/P21980-2/entry','term definition / topic relevance')]
    stopifnot(go_dot[,.N,by=category][,all(N==5)],go_dot[,sum(ECM_related),by=category][,all(V1>=1 & V1<=2)])
    kegg_dot <- copy(kegg[order(adjusted_p,term)][1:15])
    if(same_height_C_ECM) {
      kegg_seed_terms <- c('Proteoglycans in cancer','Cell adhesion molecules')
      kegg_seeds <- copy(kegg[term %in% kegg_seed_terms])
      stopifnot(nrow(kegg_seeds)==2)
      kegg_others <- copy(kegg[!grepl(ecm_pattern,term,ignore.case=TRUE)])
      setorder(kegg_others,adjusted_p,term)
      kegg_dot <- rbindlist(list(kegg_seeds,head(kegg_others,13)),use.names=TRUE)
      kegg_dot[, ECM_related := term %in% kegg_seed_terms]
      kegg_dot[, ECM_relation_type := ifelse(ECM_related,'ECM proteoglycan / adhesion related; not a significant enrichment','not selected as ECM-related')]
    }
  }
  setorder(go_dot,-gene_ratio,adjusted_p,term)
  setorder(kegg_dot,-gene_ratio,adjusted_p,term)
  go_dot[, display_rank := .I]
  kegg_dot[, display_rank := .I]
  go_wrap_width <- if(ecm_quota) 60 else 45
  go_dot[, term_short := factor(paste0(category,' | ',stringr::str_wrap(gsub(' \\([^)]*\\)$','',term),go_wrap_width)),
                               levels=rev(paste0(category,' | ',stringr::str_wrap(gsub(' \\([^)]*\\)$','',term),go_wrap_width))))]
  kegg_dot[, term_short := factor(stringr::str_wrap(term,40),levels=rev(stringr::str_wrap(term,40)))]
  pD <- ggplot(go_dot,aes(gene_ratio,term_short,size=count,colour=adjusted_p)) +
    geom_point() + scale_colour_gradient(low='#E85A64',high='#477DB3',trans='reverse',name='FDR') +
    scale_size(range=c(1.8,5),name='Count') + labs(x='GeneRatio',y=NULL,
      caption='ECM / adhesion / repair-focused selection; original full-library FDR retained.\nIncludes non-significant terms; FDR < 0.05 defines significance.') +
    paper_theme + theme(legend.position='left',axis.text.y=element_text(size=5.8),
                       plot.caption=element_text(family='Arial',size=5.8,hjust=0))
  pE <- ggplot(kegg_dot,aes(gene_ratio,term_short,size=count,colour=adjusted_p)) +
    geom_point() + scale_colour_gradient(low='#E85A64',high='#477DB3',trans='reverse',name='FDR') +
    scale_size(range=c(1.8,5),name='Count') + labs(x='GeneRatio',y=NULL,
      caption='ECM-related terms returned by KEGG; none meet FDR < 0.05.\nNo ECM-receptor interaction term returned; cancer term is database context only.') +
    paper_theme + theme(axis.text.y=element_text(size=5.7),
                       plot.caption=element_text(family='Arial',size=5.8,hjust=0))
  if(ecm_quota) {
    pD <- pD + labs(caption=sprintf('Mixed GO display: %d/%d ECM / adhesion / repair-related terms.\nUser-requested display quota; full-library FDR retained, including non-significant terms.',sum(go_dot$ECM_related),nrow(go_dot)))
    pE <- pE + labs(caption=sprintf('Mixed KEGG display: %d/%d ECM-related terms; both non-significant.\nFull-library FDR retained; cancer term denotes database context, not gingival cancer.',sum(kegg_dot$ECM_related),nrow(kegg_dot)))
  }
  if(facet_clean) {
    go_dot[, category := factor(category,levels=c('BP','CC','MF'))]
    setorder(go_dot,category,-gene_ratio,adjusted_p,term)
    go_dot[, display_rank := seq_len(.N),by=category]
    go_dot[, term_short := factor(stringr::str_wrap(gsub(' \\([^)]*\\)$','',term),60),
                                 levels=rev(stringr::str_wrap(gsub(' \\([^)]*\\)$','',term),60)))]
    pD <- ggplot(go_dot,aes(gene_ratio,term_short,size=count,colour=adjusted_p)) +
      geom_point() + facet_grid(category ~ .,scales='free_y',space='free_y') +
      scale_colour_gradient(low='#E85A64',high='#477DB3',trans='reverse',name='FDR') +
      scale_size(range=c(1.8,5),name='Count') + labs(x='GeneRatio',y=NULL) + paper_theme +
      theme(strip.text.y=element_text(size=6.5),legend.position='left',axis.text.y=element_text(size=5.8))
    pE <- pE + labs(caption=NULL)
  }
}
fwrite(go_dot,file.path(SD,'17_GO_displayed_terms.csv'))
fwrite(kegg_dot,file.path(SD,'18_KEGG_displayed_terms.csv'))
eval_range('V(g)$degree <-','pH <-')

V(g)$display_label <- ifelse(V(g)$name %in% c(hub$gene[1:20],'GDF15',unmapped),
                            ifelse(V(g)$name=='GDF15','GDF15 [added]',ifelse(V(g)$name %in% unmapped,paste0(V(g)$name,' [unmapped]'),V(g)$name)),'')
pF <- ggraph(g,layout='fr') +
  geom_edge_link(aes(alpha=score),colour='#6B6B6B',show.legend=FALSE) +
  geom_node_point(aes(size=degree,fill=degree),shape=21,colour='#666666',stroke=.3) +
  geom_node_text(aes(filter=display_label!='',label=display_label),size=2.2,repel=TRUE,family='Arial',max.overlaps=Inf,force=12,force_pull=.1,box.padding=.55,point.padding=.2,max.iter=100000,max.time=5,seed=20261007) +
  scale_fill_gradient(low='#DDF4D5',high='#F4A3A3') +
  scale_size(range=c(4,10),guide='none') +
  labs(caption=sprintf('All %d overlap genes retained; %d STRING mappings verified.\nGDF15 added despite vitamin D FDR = 0.417.',length(overlap),length(overlap)-length(unmapped))) +
  theme_void() + theme(legend.position='none',plot.caption=element_text(family='Arial',size=5.8,hjust=0),plot.margin=margin(8,8,8,8))
if(compact_network200) {
  
  V(g)$display_label <- ifelse(V(g)$name %in% c(hub$gene[1:20],'GDF15',unmapped),
                              ifelse(V(g)$name %in% unmapped,paste0(V(g)$name,' [unmapped]'),V(g)$name),'')
  set.seed(20261008)
  xy <- layout_with_fr(g,niter=2000)
  xy <- sweep(xy,2,colMeans(xy),'-')
  xy <- xy/max(abs(xy))*.8
  pF <- ggraph(g,layout='manual',x=xy[,1],y=xy[,2]) +
    geom_edge_link(aes(alpha=score),colour='#6B6B6B',show.legend=FALSE) +
    geom_node_point(aes(size=degree,fill=degree),shape=21,colour='#666666',stroke=.3) +
    geom_node_text(aes(filter=display_label!='',label=display_label),size=2.2,repel=TRUE,family='Arial',max.overlaps=Inf,force=6,force_pull=.5,box.padding=.35,point.padding=.15,max.iter=100000,max.time=5,seed=20261008) +
    scale_fill_gradient(low='#DDF4D5',high='#F4A3A3') + scale_size(range=c(4,10),guide='none') +
    coord_equal(xlim=c(-1.05,1.05),ylim=c(-1.05,1.05),expand=FALSE,clip='off') +
    theme_void() + theme(legend.position='none',plot.margin=margin(8,8,8,8))
  exy <- layout_in_circle(g_hub)*.8
  pG <- ggraph(g_hub,layout='manual',x=exy[,1],y=exy[,2]) +
    geom_edge_link(colour='black',linewidth=.28,alpha=.75) +
    geom_node_label(aes(label=name,fill=MCC),colour='black',size=2.1,family='Arial') +
    scale_fill_gradient(low='#F2E51B',high='#FF3B1F') +
    coord_equal(xlim=c(-1.05,1.05),ylim=c(-1.05,1.05),expand=FALSE,clip='off') +
    theme_void() + theme(legend.position='none')
  fwrite(data.table(gene=V(g)$name,x=xy[,1],y=xy[,2],panel='D'),file.path(SD,'23_D_network_layout.csv'))
  fwrite(data.table(gene=V(g_hub)$name,x=exy[,1],y=exy[,2],panel='E'),file.path(SD,'24_E_network_layout.csv'))
}
if(D_prune_spread) {
  D_hidden <- c('APBB1IP','CITED4','FMO1','ROM1','GDPD5')
  gd <- induced_subgraph(g,vids=setdiff(V(g)$name,D_hidden))
  
  D_positions <- data.table(gene=c('PTGS2','GDF15','GDNF','CLDN1','CYP24A1','CYP26B1','CBLN2','ENPEP','DIO2','SYT7','ITPR1','TGM2','IL7R','CXCL2','IL1RN','MAPK13'),
    x=c(0,-.35,.45,.38,.78,.60,.94,-.90,-.65,-.95,-.65,-.30,-.30,.15,.32,.70),
    y=c(0,.40,.55,.05,.10,.80,.94,.40,.70,-.30,-.35,-.25,-.80,-.75,-.37,-.45))
  D_positions <- D_positions[match(V(gd)$name,gene)]
  stopifnot(!anyNA(D_positions$gene),vcount(gd)==16,ecount(gd)==39)
  D_positions[, `:=`(label_x=x,label_y=y+.15,panel='D')]
  pF <- ggraph(gd,layout='manual',x=D_positions$x,y=D_positions$y) +
    geom_edge_link(aes(alpha=score),colour='#6B6B6B',show.legend=FALSE) +
    geom_node_point(aes(size=degree,fill=degree),shape=21,colour='#666666',stroke=.3) +
    geom_node_text(aes(label=name),nudge_y=.15,size=2.2,family='Arial') +
    scale_fill_gradient(low='#DDF4D5',high='#F4A3A3',limits=range(V(g)$degree)) +
    scale_size(range=c(4,10),limits=range(V(g)$degree),guide='none') +
    coord_equal(xlim=c(-1.15,1.15),ylim=c(-1.15,1.15),expand=FALSE,clip='off') +
    theme_void() + theme(legend.position='none',plot.margin=margin(8,8,8,8))
  fwrite(D_positions,file.path(SD,'23_D_network_layout.csv'))
  fwrite(as_data_frame(gd,what='edges'),file.path(SD,'26_D_displayed_edges.csv'))
  fwrite(hub[gene %in% D_hidden],file.path(SD,'27_D_hidden_nodes_user_requested.csv'))
}
if(facet_clean) {
  pF <- pF + labs(caption=NULL)
  pG <- pG + labs(caption=NULL)
  pH <- pH + labs(caption=NULL)
}

old_heights <- 13.3*c(.82,1.15,1.05,1.05)/sum(c(.82,1.15,1.05,1.05))
new_heights <- c(old_heights[1],old_heights[2]*1.2,sum(old_heights[3:4]))
canvas_width <- 10.8
tag_theme <- theme(plot.tag=element_text(family='Arial',size=15,face='plain',hjust=0,vjust=1),plot.tag.position=c(.01,.99),plot.margin=margin(10,8,8,10))
tag <- function(p,l) p + labs(tag=l) + tag_theme
top <- plot_grid(NULL,tag(pB,'A'),NULL,nrow=1,rel_widths=c(1,1,1))
middle <- plot_grid(tag(pD,'B'),tag(pE,'C'),nrow=1,rel_widths=c(4,5),align='h',axis='tb')
right <- plot_grid(tag(pG,'E'),tag(pH,'F'),ncol=1,rel_heights=c(1,1))
bottom <- plot_grid(tag(pF,'D'),right,nrow=1,rel_widths=c(5,4))
fig <- plot_grid(top,middle,bottom,ncol=1,rel_heights=new_heights)
if(ecm_square) {
  canvas_width <- 16.2
  square_side <- canvas_width/3
  new_heights <- c(old_heights[1],old_heights[2]*1.2,square_side)
  total_height <- sum(new_heights)
  
  fig <- ggdraw() +
    draw_plot(tag(pB,'A'),x=(canvas_width-3.6)/2/canvas_width,y=sum(new_heights[2:3])/total_height,
              width=3.6/canvas_width,height=new_heights[1]/total_height) +
    draw_plot(tag(pD,'B'),x=0,y=square_side/total_height,width=.5,height=new_heights[2]/total_height) +
    draw_plot(tag(pE,'C'),x=.5,y=square_side/total_height,width=.5,height=new_heights[2]/total_height) +
    draw_plot(tag(pF,'D'),x=0,y=0,width=1/3,height=square_side/total_height) +
    draw_plot(tag(pG,'E'),x=1/3,y=0,width=1/3,height=square_side/total_height) +
    draw_plot(tag(pH,'F'),x=2/3,y=0,width=1/3,height=square_side/total_height)
}
if(actual_square_red) {
  
  b_panel_side <- 3.2
  c_panel_side <- 4.8
  if(same_height_C_ECM) canvas_width <- 21
  middle_height <- 10.4
  if(compact_BC) {
    canvas_width <- 18.2
    middle_height <- 4.1
    label_size <- 8.5
    prior_span <- unlist(baseline_square_geometry$C)[1]
    facet_gap <- (prior_span-3*b_panel_side)/2/3
    bc_theme <- theme(axis.text=element_text(family='Arial',size=label_size),
      axis.title=element_text(family='Arial',size=10),
      legend.text=element_text(family='Arial',size=9),legend.title=element_text(family='Arial',size=10),
      strip.text.y=element_text(family='Arial',size=10),panel.spacing.y=grid::unit(facet_gap,'in'))
    pD <- pD + bc_theme + theme(axis.text.y=element_text(size=label_size))
    pE <- pE + bc_theme + theme(axis.text.y=element_text(size=label_size))
    if(square_compact_B) {
      pD <- pD + scale_x_continuous(breaks=c(.05,.15,.25),expand=expansion(mult=c(.12,.15)))
      pE <- pE + scale_x_continuous(breaks=c(.05,.10,.15,.20),expand=expansion(mult=c(.12,.15)))
    }
  }
  new_heights <- c(old_heights[1],middle_height,square_side)
  total_height <- sum(new_heights)
  cairo_pdf(file.path(OUT,'logs','layout_metrics.pdf'),width=canvas_width,height=total_height,family='Arial')
  square_panel_gtable <- function(p,side,panel_width=side) {
    gt <- ggplotGrob(p)
    panels <- gt$layout[grepl('^panel',gt$layout$name),]
    stopifnot(all(panels$l==panels$r),all(panels$t==panels$b))
    gt$widths[unique(panels$l)] <- grid::unit(panel_width,'in')
    gt$heights[unique(panels$t)] <- grid::unit(side,'in')
    gt
  }
  red_go_labels <- as.character(go_dot[ECM_related==TRUE,term_short])
  red_kegg_labels <- as.character(kegg_dot[grepl(ecm_pattern,term,ignore.case=TRUE),term_short])
  red_label_count <- 0L
  colour_labels <- function(gr,targets) {
    if(inherits(gr,'text') && !is.null(gr$label)) {
      labs <- as.character(gr$label)
      if(any(labs %in% targets)) {
        gr$gp$col <- ifelse(labs %in% targets,'#D73027','black')
        red_label_count <<- red_label_count + sum(labs %in% targets)
      }
    }
    if(!is.null(gr$children)) for(i in seq_along(gr$children)) gr$children[[i]] <- colour_labels(gr$children[[i]],targets)
    if(!is.null(gr$grobs)) for(i in seq_along(gr$grobs)) gr$grobs[[i]] <- colour_labels(gr$grobs[[i]],targets)
    gr
  }
  bc_width <- if(square_compact_B) b_panel_side/3 else b_panel_side
  B_actual_width <- bc_width * if(B_width150) 1.5 else 1
  gb <- colour_labels(square_panel_gtable(if(compact_BC) tag(pD,'B')+theme(plot.tag=element_text(size=18)) else tag(pD,'B'),if(compact_BC) b_panel_side/3 else b_panel_side,panel_width=B_actual_width),red_go_labels)
  if(compact_BC) for(i in which(gb$layout$name=='tag')) gb$grobs[[i]] <- grid::nullGrob()
  if(same_height_C_ECM) {
    bp_rows <- gb$layout[grepl('^panel',gb$layout$name),]
    b_first <- min(bp_rows$t); b_last <- max(bp_rows$b)
    c_panel_side <- grid::convertHeight(sum(gb$heights[b_first:b_last]),'in',valueOnly=TRUE)
  }
  C_actual_width <- (if(compact_BC) bc_width else c_panel_side) * if(C_width150) 1.5 else 1
  gc <- colour_labels(square_panel_gtable(pE,c_panel_side,panel_width=C_actual_width),red_kegg_labels)
  if(same_height_C_ECM) {
    cp_rows <- gc$layout[grepl('^panel',gc$layout$name),]
    c_first <- min(cp_rows$t); c_last <- max(cp_rows$b)
    before <- function(gt,first) grid::convertHeight(sum(gt$heights[seq_len(first-1)]),'in',valueOnly=TRUE)
    after <- function(gt,last) grid::convertHeight(sum(gt$heights[seq.int(last+1,length(gt$heights))]),'in',valueOnly=TRUE)
    gc$heights[1] <- gc$heights[1] + grid::unit(before(gb,b_first)-before(gc,c_first),'in')
    gc$heights[length(gc$heights)] <- gc$heights[length(gc$heights)] + grid::unit(after(gb,b_last)-after(gc,c_last),'in')
    stopifnot(abs(before(gb,b_first)-before(gc,c_first))<1e-9,
              abs(after(gb,b_last)-after(gc,c_last))<1e-9)
  }
  stopifnot(red_label_count==length(red_go_labels)+length(red_kegg_labels))
  panel_gtable_metrics <- list(B=list(width_in=grid::convertWidth(sum(gb$widths),'in',valueOnly=TRUE),height_in=grid::convertHeight(sum(gb$heights),'in',valueOnly=TRUE)),
                               C=list(width_in=grid::convertWidth(sum(gc$widths),'in',valueOnly=TRUE),height_in=grid::convertHeight(sum(gc$heights),'in',valueOnly=TRUE)))
  dev.off()
  fig <- ggdraw() +
    draw_plot(tag(pB,'A'),x=(canvas_width-3.6)/2/canvas_width,y=sum(new_heights[2:3])/total_height,width=3.6/canvas_width,height=new_heights[1]/total_height) +
    draw_plot(gb,x=0,y=square_side/total_height,width=.5,height=middle_height/total_height) +
    draw_plot(gc,x=.5,y=(square_side+middle_height-6)/total_height,width=.5,height=6/total_height) +
    draw_label('C',x=.51,y=(square_side+middle_height-.05)/total_height,hjust=0,vjust=1,fontfamily='Arial',size=15) +
    draw_plot(tag(pF,'D'),x=0,y=0,width=1/3,height=square_side/total_height) +
    draw_plot(tag(pG,'E'),x=1/3,y=0,width=1/3,height=square_side/total_height) +
    draw_plot(tag(pH,'F'),x=2/3,y=0,width=1/3,height=square_side/total_height)
  if(same_height_C_ECM) {
    left_width <- if(compact_BC) 9.5 else 8.1
    bottom_left <- (canvas_width-3*square_side)/2
    fig <- ggdraw() +
      draw_plot(tag(pB,'A'),x=(canvas_width-3.6)/2/canvas_width,y=sum(new_heights[2:3])/total_height,width=3.6/canvas_width,height=new_heights[1]/total_height) +
      draw_plot(gb,x=0,y=square_side/total_height,width=left_width/canvas_width,height=middle_height/total_height) +
      {if(compact_BC) draw_label('B',x=.8/canvas_width,y=(square_side+middle_height-.05)/total_height,hjust=0,vjust=1,fontfamily='Arial',size=18) else NULL} +
      draw_plot(gc,x=left_width/canvas_width,y=square_side/total_height,width=(canvas_width-left_width)/canvas_width,height=middle_height/total_height) +
      draw_label('C',x=(left_width+.1)/canvas_width,y=(square_side+middle_height-.05)/total_height,hjust=0,vjust=1,fontfamily='Arial',size=if(compact_BC) 18 else 15) +
      draw_plot(tag(pF,'D'),x=bottom_left/canvas_width,y=0,width=square_side/canvas_width,height=square_side/total_height) +
      draw_plot(tag(pG,'E'),x=(bottom_left+square_side)/canvas_width,y=0,width=square_side/canvas_width,height=square_side/total_height) +
      draw_plot(tag(pH,'F'),x=(bottom_left+2*square_side)/canvas_width,y=0,width=square_side/canvas_width,height=square_side/total_height)
  }
}
pdf_path <- file.path(FD,pdf_name)
if(file.exists(pdf_path)) message('Re-exporting only this task new figure; original figure untouched')
ggsave(pdf_path,fig,width=canvas_width,height=sum(new_heights),units='in',device=cairo_pdf,bg='white',limitsize=FALSE)

manifest <- jsonlite::read_json(file.path(SD,'16_Fig2_manifest.json'),simplifyVector=FALSE)
manifest$network <- list(nodes=vcount(g),edges=ecount(g),verified_nodes=length(overlap)-length(unmapped),verified_unconnected=sum(degree(g)[!V(g)$name %in% unmapped]==0),unmapped_genes=unmapped,GDF15_hub=as.list(hub[gene=='GDF15']),label_rule='top 20 MCC hubs plus GDF15 and unmapped gene labels; all nodes retained',node_size_range=c(4,10))
if(compact_network200) {
  manifest$STRING <- sprintf('human 9606 functional association network, required score %d (%s), no added interactors; not gingiva-specific physical interactions',network_score,network_score/1000)
  manifest$network$required_score <- network_score
  manifest$network$GDF15_display_label <- 'GDF15'
  manifest$network$compact_coordinates <- list(scale=.8,fixed_limits=c(-1.05,1.05),note='Only physical node layout compressed, all selected edges retained')
  manifest$network$E_nodes <- vcount(g_hub)
  manifest$network$E_edges <- ecount(g_hub)
  manifest$caveats <- unique(c(unlist(manifest$caveats),sprintf('STRING threshold lowered to %s at user request; newly admitted lower-confidence associations are exploratory, not experimental binding or causal evidence. GDF15 label simplified only; manual inclusion exception and nonsignificant vitamin D FDR unchanged.',network_score/1000)))
}
if(D_prune_spread) {
  manifest$network$D_display <- list(nodes=vcount(gd),edges=ecount(gd),hidden_nodes=D_hidden,
    rule='User-marked five nodes removed from D visualization only; full graph and E/F hub statistics unchanged',label_offset_y=.15,limits=c(-1.15,1.15))
}
manifest$layout <- list(width_in=canvas_width,height_in=sum(new_heights),old_row_heights_in=old_heights,new_row_heights_in=new_heights,GO_KEGG_ratio=new_heights[2]/old_heights[2],font='Arial',palette='original BioorganicChemistry Fig2')
if(actual_square_red) {
  manifest$layout$actual_square_plotting_panels <- list(B_BP=c(b_panel_side,b_panel_side),B_CC=c(b_panel_side,b_panel_side),B_MF=c(b_panel_side,b_panel_side),C=c(c_panel_side,c_panel_side))
  if(compact_BC) {
    manifest$layout$actual_square_plotting_panels <- NULL
    manifest$layout$actual_rectangular_plotting_panels <- list(B_BP=c(B_actual_width,b_panel_side/3),B_CC=c(B_actual_width,b_panel_side/3),B_MF=c(B_actual_width,b_panel_side/3),C=c(C_actual_width,c_panel_side))
    if(C_width150) manifest$layout$C_width_multiplier <- 1.5
    manifest$layout$BC_label_font_pt <- label_size
    manifest$layout$BC_row_spacing_multiplier <- 1/3
    manifest$layout$BC_previous_geometry <- baseline_square_geometry
    manifest$layout$BC_latest_width_spacing_supersedes_square <- TRUE
    if(square_compact_B) {
      manifest$layout$B_three_stacked_square_facets <- TRUE
      manifest$layout$BC_latest_width_spacing_supersedes_square <- FALSE
    }
  }
  manifest$layout$panel_gtable_metrics <- panel_gtable_metrics
  manifest$layout$ECM_label_colour <- '#D73027'
  manifest$layout$ECM_red_label_count <- red_label_count
  if(same_height_C_ECM) {
    manifest$layout$BC_equal_overall_height <- TRUE
    manifest$layout$C_panel_height_equals_B_three_facet_span <- TRUE
  }
  manifest$layout$previous_height_multiplier_superseded <- 'User requested square actual plotting areas; increase middle-row height to fit three stacked square facets'
  if(compact_BC) manifest$layout$previous_height_multiplier_superseded <- 'Latest request: C plotting width equals B facet plotting width; B/C row spacing is one third of prior equal-height figure; enlarged font supersedes earlier square facet geometry'
  if(square_compact_B) manifest$layout$previous_height_multiplier_superseded <- 'B keeps three actual square facets by shrinking width and height together to one third; C same width, total height aligned to the B stack; enlarged labels retained'
  if(B_width150) {
    manifest$layout$B_width_multiplier <- 1.5
    manifest$layout$B_three_stacked_square_facets <- FALSE
    manifest$layout$BC_latest_width_spacing_supersedes_square <- TRUE
    manifest$layout$previous_height_multiplier_superseded <- 'Latest request: B facet plotting width increased 1.5x, height unchanged; C prior width and height preserved'
  }
  manifest$GO_KEGG_height_multiplier <- manifest$layout$GO_KEGG_ratio
}
if(ecm_square) {
  
  manifest$layout$square_DEF <- list(D=c(square_side,square_side),E=c(square_side,square_side),F=c(square_side,square_side))
  manifest$display_selection <- list(focus='ECM and related adhesion/repair; topic-selected, not an unbiased top enrichment list',
    keyword_rule=ecm_pattern,sort='GeneRatio descending top to bottom; ties: original full-library FDR ascending, term alphabetical',
    GO_n=nrow(go_dot),KEGG_n=nrow(kegg_dot),GO_selected_significant_n=sum(go_dot$adjusted_p<.05),KEGG_selected_significant_n=sum(kegg_dot$adjusted_p<.05),
    direct_ECM_receptor_KEGG_available=any(grepl('ECM-receptor',kegg$term,ignore.case=TRUE)))
  if(ecm_quota) {
    manifest$display_selection$mode <- 'mixed_ECM_quota25'
    manifest$display_selection$focus <- 'mixed enrichment terms with at least 25% ECM / adhesion / repair-related display quota'
    manifest$display_selection$GO_seed_terms <- go_seed_terms
    manifest$display_selection$other_selection <- 'GO: five lowest full-library FDR non-ECM terms per BP/CC/MF category; KEGG: lowest full-library FDR non-ECM terms'
    manifest$display_selection$GO_ECM_n <- sum(go_dot$ECM_related)
    manifest$display_selection$KEGG_ECM_n <- sum(kegg_dot$ECM_related)
    manifest$display_selection$GO_ECM_fraction <- mean(go_dot$ECM_related)
    manifest$display_selection$KEGG_ECM_fraction <- mean(kegg_dot$ECM_related)
    manifest$display_selection$minimum_ECM_fraction <- .25
    manifest$display_selection$KEGG_count_reason <- 'Only two returned ECM-related terms; eight total terms retain other pathways and satisfy 25% without fabricating terms'
  }
  if(facet_clean) {
    manifest$display_selection$mode <- 'facet5_clean'
    manifest$display_selection$focus <- 'BP/CC/MF separated, five real returned terms each, two/two/one ECM-related selections respectively; MF selection is indirect via TGM2, not an ECM-specific term'
    manifest$display_selection$GO_facet_seed_terms <- go_facet_seeds
    manifest$display_selection$sort <- 'Within each GO facet, GeneRatio descending top to bottom; KEGG GeneRatio descending. Ties: full-library FDR ascending then name'
    manifest$display_selection$KEGG_selection <- '15 lowest full-library FDR terms, no ECM display quota'
    if(same_height_C_ECM) {
      manifest$display_selection$KEGG_selection <- 'Two returned ECM / adhesion terms plus 13 lowest full-library FDR non-ECM terms; retain original FDR and sort by GeneRatio'
      manifest$display_selection$KEGG_seed_terms <- kegg_seed_terms
      manifest$display_selection$KEGG_ECM_n <- sum(kegg_dot$ECM_related)
      manifest$caveats <- unique(c(unlist(manifest$caveats),'Two KEGG ECM / adhesion selections are not FDR significant; red text indicates topic relevance, not significance. Proteoglycans in cancer is a library pathway name, not evidence of gingival cancer.'))
    }
    manifest$display_selection$GO_facet_counts <- as.list(setNames(go_dot[,.N,by=category]$N,go_dot[,.N,by=category]$category))
    manifest$display_selection$GO_facet_ECM_counts <- as.list(setNames(go_dot[,sum(ECM_related),by=category]$V1,go_dot[,sum(ECM_related),by=category]$category))
    manifest$display_selection$MF_relation <- 'N-acyltransferase Activity (GO:0016410), hit TGM2; indirectly ECM-related by TGM2 cross-linking, not a direct ECM-specific MF term'
    manifest$display_selection$MF_evidence_url <- 'https://www.uniprot.org/uniprotkb/P21980-2/entry'
    manifest$display_selection$bottom_small_text_removed <- TRUE
    if(actual_square_red) manifest$display_selection$ECM_label_colour <- '#D73027'
    manifest$caveats <- unique(c(unlist(manifest$caveats),'Explanatory small print omitted from figure at user request; all limitations retained in source tables and accompanying notes.',manifest$display_selection$MF_relation))
  }
}
jsonlite::write_json(manifest,file.path(SD,'16_Fig2_manifest.json'),auto_unbox=TRUE,pretty=TRUE,digits=NA)
cat('DONE: ',pdf_path,'\n')
print(hub[1:6])
print(hub[gene=='GDF15'])
writeLines(capture.output(print(warnings())),file.path(OUT,'logs','R_render_warnings.txt'))
