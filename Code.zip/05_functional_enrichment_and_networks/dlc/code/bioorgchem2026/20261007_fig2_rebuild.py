from pathlib import Path
import importlib.util
import hashlib
import json
from datetime import datetime
import pandas as pd
import requests
import io
import argparse
PROJECT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
OUT = PROJECT / 'output' / 'VitaminD_DEG_overlap_FDR005_plus_GDF15_20261007'
SD = OUT / 'source_data'
VD = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u539f\u59cb\u6570\u636e\\06_\u6700\u7ec8\u6295\u7a3f\u51fa\u56fe\u6e90\u8868\\03_\u6b63\u6587\u56fe3_SMR\u4e0eBulkRNA\\BulkRNA\\02_DESeq2_genome\\11_DESeq2_D3_vs_ethanol_all_genes.csv')
DISEASE = PROJECT / 'output' / 'BioorganicChemistry2026_\u5e72\u5b9e\u9a8c\u8fc1\u79fb_20260924' / 'source_data' / '02_bulk_differential_expression.csv.gz'

def main():
    global OUT, SD
    parser = argparse.ArgumentParser()
    parser.add_argument('--out-name', default=OUT.name)
    parser.add_argument('--min-abs-logfc', type=float, default=0)
    parser.add_argument('--disease-min-abs-logfc', type=float, default=0)
    parser.add_argument('--disease-input', default=str(DISEASE))
    parser.add_argument('--disease-description', default='GSE223924 (20) + GSE173078 (24), whole human gingiva')
    args = parser.parse_args()
    OUT = PROJECT / 'output' / args.out_name
    SD = OUT / 'source_data'
    for sub in ('source_data', 'figures', 'renders', 'logs'):
        (OUT / sub).mkdir(parents=True, exist_ok=True)
    vd = pd.read_csv(VD)
    disease_input = Path(args.disease_input)
    dis = pd.read_csv(disease_input)
    vd = vd.dropna(subset=['gene_symbol']).copy()
    vd['gene_symbol'] = vd.gene_symbol.str.strip()
    vd = vd[vd.gene_symbol.ne('')].sort_values(['padj', 'gene_id'], na_position='last').drop_duplicates('gene_symbol')
    strict = set(vd.loc[vd.padj.lt(0.05) & vd.log2FoldChange.abs().ge(args.min_abs_logfc), 'gene_symbol'])
    target = strict | {'GDF15'}
    disease = set(dis.loc[dis['adj.P.Val'].lt(0.05) & dis.logFC.abs().ge(args.disease_min_abs_logfc), 'gene'])
    overlap = sorted(target & disease)
    assert 'GDF15' not in strict
    audit = vd[vd.gene_symbol.isin(target)].rename(columns={'gene_symbol': 'gene', 'padj': 'vitaminD_FDR', 'log2FoldChange': 'vitaminD_log2FC', 'pvalue': 'vitaminD_raw_p'})
    audit['inclusion_rule'] = audit.gene.map(lambda g: 'user_requested_exception_NOT_FDR_significant' if g == 'GDF15' else f'FDR_lt_0.05_AND_abs_log2FC_ge_{args.min_abs_logfc:g}')
    audit['vitaminD_FDR_significant'] = audit.vitaminD_FDR.lt(0.05)
    audit = audit.merge(dis[['gene', 'logFC', 'adj.P.Val']].rename(columns={'logFC': 'disease_log2FC', 'adj.P.Val': 'disease_FDR'}), on='gene', how='left', validate='one_to_one')
    audit['in_overlap'] = audit.gene.isin(overlap)
    audit.to_csv(SD / '08_vitaminD_DEG_gene_set_audit.csv', index=False)
    audit[audit.in_overlap].to_csv(SD / '09_vitaminD_gingiva_overlap_genes.csv', index=False)
    (SD / '09_vitaminD_gingiva_overlap_genes.txt').write_text('\n'.join(overlap) + '\n', encoding='utf-8')
    strict_overlap = sorted(strict & disease)
    (SD / '09_strict_FDR_overlap_without_GDF15.txt').write_text('\n'.join(strict_overlap) + '\n', encoding='utf-8')
    manifest = {'created_at': datetime.now().astimezone().isoformat(), 'vitaminD_input': str(VD), 'vitaminD_sha256': hashlib.sha256(VD.read_bytes()).hexdigest(), 'disease_input': str(disease_input), 'disease_sha256': hashlib.sha256(disease_input.read_bytes()).hexdigest(), 'vitaminD_definition': f'unique nonempty gene symbols with DESeq2 padj < 0.05 AND abs(log2FC) >= {args.min_abs_logfc:g} UNION user-specified GDF15', 'vitaminD_abs_log2FC_threshold': args.min_abs_logfc, 'disease_abs_log2FC_threshold': args.disease_min_abs_logfc, 'vitaminD_strict_FDR_n': len(strict), 'vitaminD_total_with_exception_n': len(target), 'disease_definition': 'FDR < 0.05' + (f' AND abs(log2FC) >= {args.disease_min_abs_logfc:g}' if args.disease_min_abs_logfc > 0 else '') + '; ' + args.disease_description + '; no manually added disease gene', 'disease_FDR_n': len(disease), 'overlap_n': len(overlap), 'strict_overlap_without_GDF15_n': len(strict_overlap), 'GDF15': audit[audit.gene.eq('GDF15')][['vitaminD_log2FC', 'vitaminD_raw_p', 'vitaminD_FDR', 'disease_log2FC', 'disease_FDR', 'inclusion_rule']].iloc[0].to_dict(), 'enrichment': 'Same Enrichr GO 2025 and KEGG 2021 libraries/default background as original figure; descriptive analysis of the requested augmented set', 'STRING': 'human 9606 functional association network, required score 400, no added interactors; not gingiva-specific physical interactions', 'caveats': ['GDF15 is not significant after vitamin D multiple-testing correction; manually included at user request.', 'Vitamin D-treated cultured gingival fibroblasts and periodontitis whole-gingiva cohorts are distinct inputs; no cell-type-specific or causal claim.', 'Union of changes is not necessarily opposite-direction reversal.', 'RNA expression is not phospho-ERK or MMP enzyme activity.'], 'panel_mapping': {'old_B': 'A', 'old_D': 'B', 'old_E': 'C', 'old_F': 'D', 'old_G': 'E', 'old_H': 'F'}, 'deleted_panels': ['old_A', 'old_C'], 'GO_KEGG_height_multiplier': 1.2, 'old_files_preserved': True}
    (SD / '16_Fig2_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'vitd': len(target), 'disease': len(disease), 'overlap': len(overlap)}, ensure_ascii=False), flush=True)
    helper_path = PROJECT / 'code' / 'bioorgchem2026' / '02_fetch_enrichment_string.py'
    spec = importlib.util.spec_from_file_location('original_fetch', helper_path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    if not all(((SD / f'10_enrichr_{lib}.csv').exists() for lib in helper.ENRICHR_LIBRARIES)):
        print(f'Querying Enrichr for new {len(overlap)}-gene input', flush=True)
        helper.enrichr(overlap, SD)
    if not (SD / '11_STRING_exact_mapping.csv').exists():
        print('Validating exact STRING gene-symbol mappings', flush=True)
        response = requests.post('https://string-db.org/api/tsv/get_string_ids', data={'identifiers': '\r'.join(overlap), 'species': 9606, 'echo_query': 1, 'caller_identity': 'vitd-overlap-audit'}, timeout=60)
        response.raise_for_status()
        mapping = pd.read_csv(io.StringIO(response.text), sep='\t')
        mapping['exact_symbol_match'] = mapping.queryItem.eq(mapping.preferredName)
        mapping.to_csv(SD / '11_STRING_exact_mapping.csv', index=False)
        exact = mapping[mapping.exact_symbol_match]
        rejected = mapping[~mapping.exact_symbol_match]
        if (SD / '11_STRING_functional_network.tsv').exists():
            (SD / '11_STRING_initial_unvalidated_network.tsv').write_bytes((SD / '11_STRING_functional_network.tsv').read_bytes())
        print('Querying STRING with validated protein IDs only', flush=True)
        helper.string_network(exact.stringId.tolist(), SD)
        manifest['STRING_mapping'] = {'validated_n': len(exact), 'not_verified_genes': sorted(set(overlap) - set(exact.queryItem)), 'rejected_automatic_mappings': rejected[['queryItem', 'preferredName', 'stringId']].to_dict(orient='records'), 'note': 'Unverified genes remain in the overlap; displayed separately as unmapped. Their missing edges are not evidence of no biological interactions.'}
        (SD / '16_Fig2_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    else:
        mapping = pd.read_csv(SD / '11_STRING_exact_mapping.csv')
        exact = mapping[mapping.exact_symbol_match]
        rejected = mapping[~mapping.exact_symbol_match]
        manifest['STRING_mapping'] = {'validated_n': len(exact), 'not_verified_genes': sorted(set(overlap) - set(exact.queryItem)), 'rejected_automatic_mappings': rejected[['queryItem', 'preferredName', 'stringId']].to_dict(orient='records'), 'note': 'Unverified genes remain in the overlap; missing edges are not evidence of no biological interactions.'}
        (SD / '16_Fig2_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Inputs and public results ready', flush=True)
if __name__ == '__main__':
    main()
