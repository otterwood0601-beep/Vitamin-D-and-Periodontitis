from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd
import requests

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--genes', required=True)
    parser.add_argument('--out', required=True)
    parser.add_argument('--prefix', required=True)
    args = parser.parse_args()
    genes = [x.strip() for x in Path(args.genes).read_text(encoding='utf-8').splitlines() if x.strip()]
    if not genes:
        raise SystemExit('No genes supplied')
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    added = requests.post('https://maayanlab.cloud/Enrichr/addList', files={'list': (None, '\n'.join(genes)), 'description': (None, args.prefix)}, timeout=60)
    added.raise_for_status()
    uid = added.json()['userListId']
    libraries = ('GO_Biological_Process_2025', 'KEGG_2021_Human')
    for library in libraries:
        response = requests.get('https://maayanlab.cloud/Enrichr/enrich', params={'userListId': uid, 'backgroundType': library}, timeout=60)
        response.raise_for_status()
        rows = response.json().get(library, [])
        frame = pd.DataFrame(rows, columns=['rank', 'term', 'p_value', 'z_score', 'combined_score', 'overlap_genes', 'adjusted_p', 'old_p_value', 'old_adjusted_p'])
        if not frame.empty:
            frame['overlap_genes'] = frame['overlap_genes'].apply(lambda x: ';'.join(x))
            frame['count'] = frame['overlap_genes'].str.split(';').str.len()
            frame['gene_ratio'] = frame['count'] / len(genes)
        frame.to_csv(out / f'{args.prefix}_{library}.csv', index=False)
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
