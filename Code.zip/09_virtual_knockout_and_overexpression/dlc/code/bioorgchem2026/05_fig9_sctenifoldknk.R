options(stringsAsFactors = FALSE, scipen = 999)
set.seed(20260924)

suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
  library(data.table)
  library(scTenifoldKnk)
  library(ggplot2)
  library(patchwork)
  library(cowplot)
  library(ggrepel)
})

OUT <- "C:/wb_links/bioorgchem2026_20260924"
SD <- file.path(OUT, "source_data")
FD <- file.path(OUT, "figures")
FB <- "C:/wb_links/dlc_data/outputs/fb_seurat_annotated.rds"

message("[1/6] Load Williams gingival fibroblasts")
fb <- readRDS(FB)
fb <- subset(fb, subset = Study == "Williams")
DefaultAssay(fb) <- "RNA"

states <- c("Vascular", "Immune")
state_ids <- c(Vascular = "Vascular", Immune = "Immune")
results <- list()
audit <- list()

message("[2/6] Run GDF15 virtual knockout in two prespecified Williams states")
for (state in states) {
  sid <- state_ids[[state]]
  cache <- file.path(SD, paste0("26_scTenifoldKnk_GDF15_", sid, ".rds"))
  sub <- fb[, fb$fibroblast_short == state]
  sub <- FindVariableFeatures(sub, selection.method = "vst", nfeatures = 3000, verbose = FALSE)
  hvg <- VariableFeatures(sub)
  rank_gdf15 <- match("GDF15", hvg)
  top500 <- hvg[seq_len(min(500, length(hvg)))]
  forced <- !"GDF15" %in% top500
  genes <- if (forced) unique(c(head(top500, 499), "GDF15")) else top500
  counts <- GetAssayData(sub, assay = "RNA", layer = "counts")[genes, , drop = FALSE]
  detection <- mean(counts["GDF15", ] > 0)
  audit[[state]] <- data.table(
    state = state,
    n_cells = ncol(counts),
    n_genes = nrow(counts),
    GDF15_detection_fraction = detection,
    GDF15_HVG_rank = rank_gdf15,
    GDF15_forced_into_500 = forced,
    input_rule = if (forced) "Top 499 HVGs plus GDF15 sensitivity analysis" else "Top 500 HVGs; GDF15 naturally retained"
  )
  fwrite(data.table(rank = seq_along(genes), gene = genes,
                    GDF15_forced = genes == "GDF15" & forced),
         file.path(SD, paste0("26_scTenifoldKnk_input_genes_", sid, ".csv")))

  if (file.exists(cache)) {
    knk <- readRDS(cache)
  } else {
    set.seed(1)
    knk <- scTenifoldKnk(
      countMatrix = counts,
      gKO = "GDF15",
      transcriptomeWide = FALSE,
      qc = FALSE,
      nc_lambda = 0,
      nc_nNet = 10,
      nc_nCells = 300,
      nc_nComp = 3,
      nc_scaleScores = TRUE,
      nc_symmetric = FALSE,
      nc_q = 0.9,
      td_K = 3,
      td_maxIter = 1000,
      td_maxError = 1e-5,
      td_nDecimal = 3,
      ma_nDim = 2,
      dr_empiricalNull = FALSE,
      nCores = 2
    )
    saveRDS(knk, cache)
  }
  dr <- as.data.table(knk$diffRegulation)
  dr[, `:=`(
    Z = as.numeric(Z),
    log2_perturbation_FC = log2(pmax(as.numeric(FC), 1e-12)),
    p.value = as.numeric(p.value),
    p.adj = as.numeric(p.adj)
  )]
  dr[, significant := p.value < 0.05 & abs(log2_perturbation_FC) > 1]
  dr[, state := state]
  fwrite(dr, file.path(SD, paste0("27_scTenifoldKnk_GDF15_", sid,
                                  "_differential_regulation.csv")))
  results[[state]] <- dr
}
audit_dt <- rbindlist(audit)
fwrite(audit_dt, file.path(SD, "26_scTenifoldKnk_input_audit.csv"))

message("[3/6] Enrichment of paper-threshold differential-regulation genes")
enrich_results <- list()
for (state in states) {
  sid <- state_ids[[state]]
  dr <- results[[state]]
  genes <- dr[significant == TRUE & gene != "GDF15", gene]
  selection_rule <- "P < 0.05 and absolute log2 perturbation FC > 1"
  if (length(genes) < 5) {
    genes <- dr[gene != "GDF15"][order(p.value)][1:min(50, .N), gene]
    selection_rule <- paste0("Sensitivity fallback: top ", length(genes),
                             " genes by scTenifoldKnk P value because <5 met the paper threshold")
  }
  writeLines(genes, file.path(SD, paste0("28_", sid, "_enrichment_genes.txt")))
  prefix <- paste0("28_", sid, "_GDF15_KO")
  go_file <- file.path(SD, paste0(prefix, "_GO_Biological_Process_2025.csv"))
  kegg_file <- file.path(SD, paste0(prefix, "_KEGG_2021_Human.csv"))
  if (!file.exists(go_file) || !file.exists(kegg_file)) {
    status <- system2(
      "python",
      c("C:/wb_links/bioorgchem2026_code/05_fetch_enrichr.py",
        "--genes", file.path(SD, paste0("28_", sid, "_enrichment_genes.txt")),
        "--out", SD, "--prefix", prefix),
      stdout = file.path(OUT, "logs", paste0("05_enrichr_", sid, ".log")),
      stderr = file.path(OUT, "logs", paste0("05_enrichr_", sid, ".log"))
    )
    if (!identical(status, 0L)) stop("Enrichr query failed for ", state)
  }
  enrich_results[[state]] <- list(
    GO = fread(go_file),
    KEGG = fread(kegg_file),
    genes = genes,
    selection_rule = selection_rule
  )
}

paper_theme <- theme_bw(base_size = 8, base_family = "Arial") +
  theme(
    panel.grid.major = element_line(colour = "#E7E7E7", linewidth = 0.25),
    panel.grid.minor = element_blank(),
    axis.title = element_text(size = 8),
    axis.text = element_text(size = 6.3, colour = "black"),
    plot.title = element_text(hjust = 0.5, size = 9),
    legend.title = element_text(size = 7),
    legend.text = element_text(size = 6.3),
    plot.margin = ggplot2::margin(3, 3, 3, 3)
  )

top_and_volcano <- function(dr, state) {
  dr <- copy(dr)
  state_short <- if (state == "Vascular") "Vasc." else "Imm."
  dr[, display_fc := pmax(-10, pmin(10, log2_perturbation_FC))]
  dr[, display_y := pmin(12, -log10(pmax(p.value, 1e-300)))]
  top_up <- dr[log2_perturbation_FC >= 0][order(p.value)][1:min(10, .N)]
  top_down <- dr[log2_perturbation_FC < 0][order(p.value)][1:min(10, .N)]
  top <- rbind(top_down, top_up, fill = TRUE)
  top[, gene := factor(gene, levels = gene[order(log2_perturbation_FC)])]
  pbar <- ggplot(top, aes(display_fc, gene,
                          fill = log2_perturbation_FC >= 0)) +
    geom_col(width = 0.82) +
    scale_fill_manual(values = c(`FALSE` = "#6A8BE8", `TRUE` = "#F04A50"), guide = "none") +
    scale_x_continuous(limits = c(-10, 10), breaks = 0) +
    labs(title = state_short,
         x = "log2 FC", y = "Gene", caption = "FC clipped at +/-10") + paper_theme +
    theme(axis.text.y = element_text(size = 5.2), axis.text.x = element_text(size = 4.8),
          axis.title.x = element_text(size = 6.5), plot.caption = element_text(size = 5.5))

  lab <- dr[order(p.value)][1:min(8, .N)]
  pvol <- ggplot(dr, aes(display_fc, display_y,
                         colour = significant)) +
    geom_point(size = 0.75, alpha = 0.80) +
    geom_vline(xintercept = c(-1, 1), linetype = 3, linewidth = 0.30) +
    geom_hline(yintercept = -log10(0.05), linetype = 3, linewidth = 0.30) +
    geom_text_repel(data = lab, aes(label = gene), size = 1.8, colour = "black",
                    family = "Arial", max.overlaps = 20) +
    scale_colour_manual(values = c(`FALSE` = "#BDBDBD", `TRUE` = "#F04A50"),
                        labels = c(`FALSE` = "Not significant", `TRUE` = "Significant"),
                        name = "Significance") +
    scale_x_continuous(limits = c(-10, 10), breaks = c(-10, 10)) +
    scale_y_continuous(limits = c(0, 12), breaks = c(0, 4, 8, 12)) +
    labs(title = NULL, x = "log2 FC", y = "-log10(p), capped at 12") +
    paper_theme + theme(legend.position = "none", axis.text.x = element_text(size = 4.8),
                        axis.title.x = element_text(size = 6.5))
  plot_grid(pbar, pvol, nrow = 1, rel_widths = c(0.82, 1.18), align = "hv")
}

go_panel <- function(en, state) {
  z <- copy(en$GO)
  if (!nrow(z)) return(ggplot() + theme_void() + ggtitle(paste("GO in", state)))
  z <- z[order(adjusted_p)][1:min(12, .N)]
  z[, `:=`(adjusted_p = pmax(adjusted_p, 1e-300),
           term_short = stringr::str_wrap(gsub(" \\([^)]*\\)$", "", term), 35))]
  z[, term_short := factor(term_short, levels = rev(term_short))]
  sens <- if (grepl("fallback", en$selection_rule, ignore.case = TRUE)) "Top-50 sensitivity set" else NULL
  ggplot(z, aes(gene_ratio, term_short, size = count, colour = adjusted_p)) +
    geom_point() +
    scale_colour_gradient(low = "#CC6677", high = "#4477AA", trans = "reverse",
                          name = "p.adjust") +
    scale_size(range = c(2, 5), name = "Count") +
    labs(title = paste0(state, ": GO enrichment"), subtitle = sens,
         x = "GeneRatio", y = NULL) + paper_theme +
    theme(axis.text.y = element_text(size = 5.5),
          plot.subtitle = element_text(hjust = 0.5, size = 6.2))
}

kegg_panel <- function(en, state) {
  z <- copy(en$KEGG)
  if (!nrow(z)) return(ggplot() + theme_void() + ggtitle(paste("KEGG in", state)))
  z <- z[order(adjusted_p)][1:min(20, .N)]
  z[, `:=`(adjusted_p = pmax(adjusted_p, 1e-300),
           neglog10 = -log10(adjusted_p),
           term_short = stringr::str_wrap(term, 32))]
  z[, term_short := factor(term_short, levels = rev(term_short))]
  sens <- if (grepl("fallback", en$selection_rule, ignore.case = TRUE)) "Top-50 sensitivity set" else NULL
  ggplot(z, aes(neglog10, term_short, fill = neglog10)) +
    geom_col(width = 0.82) +
    scale_fill_gradient(low = "#F1F27A", high = "#C6193C",
                        name = expression(-log[10](p.adjust))) +
    labs(title = paste0(state, ": KEGG enrichment"), subtitle = sens,
         x = expression(-log[10](Adj.~p~value)), y = NULL) + paper_theme +
    theme(axis.text.y = element_text(size = 5.2), legend.position = "left",
          plot.subtitle = element_text(hjust = 0.5, size = 6.2))
}

message("[4/6] Build Bioorganic Chemistry Fig. 9 style panels")
pA <- top_and_volcano(results[["Vascular"]], "Vascular")
pB <- top_and_volcano(results[["Immune"]], "Immune")
pC <- go_panel(enrich_results[["Vascular"]], "Vascular")
pD <- go_panel(enrich_results[["Immune"]], "Immune")
pE <- kegg_panel(enrich_results[["Vascular"]], "Vascular")
pF <- kegg_panel(enrich_results[["Immune"]], "Immune")

layout_design <- "
AAAABBBBEEEE
AAAABBBBEEEE
CCCCDDDDFFFF
CCCCDDDDFFFF
"
fig9 <- pA + pB + pC + pD + pE + pF +
  plot_layout(design = layout_design) +
  plot_annotation(tag_levels = "A", theme = theme(
    plot.tag = element_text(family = "Arial", size = 15, face = "plain")
  ))
ggsave(file.path(FD, "Fig9_Williams_GDF15_virtual_KO_scTenifoldKnk_BioorgChem_style.pdf"),
       fig9, width = 10.8, height = 13.3, units = "in", device = cairo_pdf)

message("[5/6] Save audit manifest")
manifest <- list(
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  method = "scTenifoldKnk 1.1",
  tissue = "Williams human gingiva fibroblasts only",
  target = "GDF15",
  states = lapply(states, function(s) {
    a <- audit_dt[state == s]
    list(
      state = s,
      n_cells = a$n_cells,
      GDF15_detection_fraction = a$GDF15_detection_fraction,
      GDF15_HVG_rank = a$GDF15_HVG_rank,
      GDF15_forced_into_500 = a$GDF15_forced_into_500,
      significant_paper_threshold_n = results[[s]][significant == TRUE, .N],
      enrichment_rule = enrich_results[[s]]$selection_rule
    )
  }),
  network_parameters = list(n_networks = 10, cells_per_network = 300,
                            components = 3, edge_quantile = 0.9, tensor_rank = 3),
  qc_note = paste(
    "Seurat-preprocessed Williams cells were used and scTenifoldKnk internal QC was disabled",
    "because its default 5% detection filter would remove the sparse prespecified GDF15 target."
  ),
  interpretation_boundary = paste(
    "scTenifoldKnk predicts differential regulation after a network-edge knockout.",
    "Its perturbation FC is not observed differential expression and does not establish causal biology."
  )
)
jsonlite::write_json(manifest, file.path(SD, "29_Fig9_scTenifoldKnk_manifest.json"),
                     auto_unbox = TRUE, pretty = TRUE)

message("[6/6] Completed Fig. 9")
print(audit_dt)
for (s in states) cat(s, "paper-threshold genes:", results[[s]][significant == TRUE, .N], "\n")
