import os, sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats as st
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from style_npj import set_npj_style, save_npj, NPJ_CASE, NPJ_CTRL, MM
set_npj_style()
BASE = 'C:\\wb_links\\serum_vit\\\u539f\u59cb\u6570\u636e\\06_\u6700\u7ec8\u6295\u7a3f\u51fa\u56fe\u6e90\u8868\\05_\u6b63\u6587\u56fe5_\u865a\u62df\u6572\u9664\\Geneformer'
DER = 'C:\\wb_links\\dlc_derived'
OUTDIR = 'C:\\wb_links\\dlc_out\\\u7b2c8\u9879_\u865a\u62df\u6270\u52a8\u7a33\u5065\u6027'
os.makedirs(OUTDIR, exist_ok=True)
scr = {}
for co in ['Williams', 'Caetano']:
    scr[co] = pd.read_csv(os.path.join(BASE, '03_\u5168\u57fa\u56e0\u865a\u62df\u6572\u9664', co, 'all_gene_contextual_one_pass_screen.csv'))
gdf = {}
for co in ['Williams', 'Caetano']:
    d = {}
    p = os.path.join(BASE, '04_GDF15\u5b9a\u5411\u6270\u52a8', co)
    for fn, tag in [('GDF15_exact_delete_cell_level.csv', 'delete'), ('GDF15_overexpression_sensitivity_cell_level.csv', 'overexpress')]:
        fp = os.path.join(p, fn)
        if os.path.exists(fp):
            d[tag] = pd.read_csv(fp)
    gdf[co] = d
rows = []
for co in ['Williams', 'Caetano']:
    null = scr[co]['Desirability_score'].dropna()
    for tag, df in gdf[co].items():
        cell = df['Desirability_score'].dropna()
        mean_d = cell.mean()
        pct = (null < mean_d).mean() * 100
        emp_p = min((null >= mean_d).mean(), (null <= mean_d).mean()) * 2
        donors = df.groupby('donor_id')['Desirability_score'].mean()
        conc = (donors > 0).mean() if mean_d > 0 else (donors < 0).mean()
        rows.append({'cohort': co, 'perturbation': tag, 'n_cells': len(df), 'n_donors': donors.size, 'mean_desirability': mean_d, 'null_percentile': pct, 'empirical_p_two_sided': emp_p, 'donor_direction_concordance': conc, 'donors_detail': ';'.join((f"{k.split('_')[-1]}:{v:+.5f}" for k, v in donors.items()))})
sens = pd.DataFrame(rows)
sens.to_csv(os.path.join(DER, 'C8_GDF15_perturbation_sensitivity.csv'), index=False)
print(sens[['cohort', 'perturbation', 'n_cells', 'n_donors', 'mean_desirability', 'null_percentile', 'empirical_p_two_sided', 'donor_direction_concordance']].to_string())
sp = pd.read_csv(os.path.join(BASE, '02_\u72b6\u6001\u5206\u7c7b\u5668', 'Williams', 'data_splits.csv'))
tr = set(sp[sp.split == 'train'].donor_id)
te = set(sp[sp.split == 'test'].donor_id)
va = set(sp[sp.split == 'validation'].donor_id)
split_check = {'train_donors': len(tr), 'val_donors': len(va), 'test_donors': len(te), 'train_test_overlap': len(tr & te), 'train_val_overlap': len(tr & va), 'val_test_overlap': len(va & te)}
print(split_check)
pd.DataFrame([split_check]).to_csv(os.path.join(DER, 'C8_donor_split_check.csv'), index=False)
fig = plt.figure(figsize=(180 * MM, 95 * MM))
gs = fig.add_gridspec(1, 3, width_ratios=[1.0, 0.9, 1.1], wspace=0.32, left=0.07, right=0.97, top=0.84, bottom=0.17)
axA = fig.add_subplot(gs[0, 0])
null = scr['Williams']['Desirability_score'].dropna()
axA.hist(null, bins=120, color='#BFBFBF', lw=0)
for tag, c in [('delete', NPJ_CTRL), ('overexpress', NPJ_CASE)]:
    if tag in gdf['Williams']:
        v = gdf['Williams'][tag]['Desirability_score'].mean()
        axA.axvline(v, color=c, lw=1.2)
        pct = (null < v).mean() * 100
        axA.annotate(f'GDF15 {tag}\n(pct {pct:.0f}%)', (v, axA.get_ylim()[1] * 0.9), textcoords='offset points', xytext=(-58, -6), fontsize=6.5, color=c)
axA.set_xlabel('Desirability score (all-gene null, Williams)')
axA.set_ylabel('Genes')
axA.set_title('Empirical null vs GDF15', fontsize=8, fontweight='bold', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=0.35'))
fig.text(0.045, 0.92, 'A', fontsize=12, fontweight='bold')
axB = fig.add_subplot(gs[0, 1])
for row_y, tag, c in [(1, 'delete', NPJ_CTRL), (0, 'overexpress', NPJ_CASE)]:
    if tag not in gdf['Williams']:
        continue
    donors = gdf['Williams'][tag].groupby('donor_id')['Desirability_score'].mean().sort_values()
    rng = np.random.default_rng(7)
    y = row_y + rng.uniform(-0.18, 0.18, len(donors))
    axB.scatter(donors.values, y, s=26, c=c, ec='black', lw=0.4, zorder=3, label=f'GDF15 {tag}')
    axB.text(0.98, row_y + 0.22, f'{len(donors)} donors', transform=axB.get_yaxis_transform(), ha='right', va='bottom', fontsize=6)
axB.axvline(0, c='black', lw=0.5)
axB.set_yticks([0, 1])
axB.set_yticklabels(['overexpress', 'delete'], fontsize=7)
axB.set_ylim(-0.6, 1.6)
axB.set_xlabel('Donor-mean desirability score')
axB.legend(fontsize=6, frameon=False, loc='lower left')
axB.set_title('Per-donor consistency (Williams)', fontsize=8, fontweight='bold', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=0.35'))
fig.text(0.4, 0.92, 'B', fontsize=12, fontweight='bold')
axC = fig.add_subplot(gs[0, 2])
ctx = pd.read_csv(os.path.join(BASE, '04_GDF15\u5b9a\u5411\u6270\u52a8', 'GDF15_all_contexts_summary.csv'))
ctx = ctx.reset_index(drop=True)
ylabels = []
for i, r in ctx.iterrows():
    y = len(ctx) - i
    v, lo, hi = (r['Shift_to_goal_end'], r['Shift_to_goal_CI95_low'], r['Shift_to_goal_CI95_high'])
    c = NPJ_CASE if lo > 0 or hi < 0 else '#7F7F7F'
    axC.plot([lo, hi], [y, y], lw=1.0, c=c)
    axC.scatter([v], [y], s=22, c=c, ec='black', lw=0.4, zorder=3)
    ctx_short = 'ECM' if 'ECM' in r['context'] else 'FB'
    ylabels.append(f"{r['cohort'][0]} {ctx_short} {r['perturbation'][:3]} n={r['N_cells']}")
axC.axvline(0, c='black', lw=0.5)
axC.set_yticks(range(1, len(ctx) + 1))
axC.set_yticklabels(ylabels[::-1], fontsize=5.5)
axC.set_xlabel('Shift-to-goal (95% CI)')
axC.set_title('GDF15 perturbation contexts', fontsize=8, fontweight='bold', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=0.35'))
fig.text(0.68, 0.92, 'C', fontsize=12, fontweight='bold')
save_npj(fig, os.path.join(OUTDIR, '\u7b2c8\u9879_\u865a\u62df\u6270\u52a8\u7a33\u5065\u6027\u6838\u67e5_20260914'), width_mm=180, height_mm=95, dpi=600)
print('FIG SAVED')
