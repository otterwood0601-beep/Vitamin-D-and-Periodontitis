from pathlib import Path
import json, hashlib
import numpy as np
import pandas as pd
from scipy.stats import fisher_exact
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
R = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
O = R / 'output/GDF15_KO_all5_20261009'
S = O / 'source_data'
F = O / 'figures'
F.mkdir(exist_ok=True)
status = pd.read_csv(O / 'status.csv').fillna('')
assert len(status) == 5 and set(status.status).issubset({'reused', 'complete'}), status.to_dict('records')
audit = pd.read_csv(S / 'input_audit.csv').drop_duplicates()
assert audit.state.nunique() == 5 and len(audit) == 5
audit.to_csv(S / 'input_audit.csv', index=False)
ora = pd.read_csv(S / 'five_state_module_Fisher_RAWP.csv')
tested = pd.read_csv(S / 'tested_gene_RAWP_selection.csv')
assert len(ora) == 65 and 'GDF15' not in set(tested.gene)
assert (tested.selected == tested.raw_P.lt(0.05)).all()
for r in ora.itertuples():
    k, K, M, N = (r.overlap, r.KO_significant, r.module_tested, r.background)
    p = fisher_exact([[k, K - k], [M - k, N - M - K + k]], alternative='greater').pvalue
    assert np.isclose(p, r.p, rtol=1e-10, atol=1e-15)
    assert K == tested.loc[tested.state.eq(r.state), 'selected'].sum()
old = pd.read_csv(R / 'P3_WGCNA_Williams_20261008_RAWP/\u5176\u4ed6/source_data/12_D_Williams_KO_module_Fisher_RAWP.csv')
cmp = old.merge(ora, on=['state', 'module'], suffixes=('_old', '_new'))
assert len(cmp) == 26 and np.allclose(cmp.p_old, cmp.p_new, rtol=1e-12)
modules = ['brown', 'red', 'tan', 'black', 'greenyellow', 'magenta', 'salmon', 'yellow', 'pink', 'purple', 'turquoise', 'green', 'blue']
states = ['Immune', 'ECM remodeling', 'Vascular', 'Pre-ECM', 'Matrix homeostasis']
plt.rcParams.update({'font.family': 'Arial', 'font.size': 11, 'pdf.fonttype': 42})
fig, axes = plt.subplots(1, 5, figsize=(17, 6.4), sharex=True, sharey=True)
fig.subplots_adjust(left=0.09, right=0.9, top=0.79, bottom=0.19, wspace=0.1)
xmax = max(1.45, (-np.log10(ora.p.clip(lower=1e-300))).max() * 1.13)
for ax, state in zip(axes, states):
    z = ora[ora.state.eq(state)].set_index('module').loc[modules]
    colors = plt.cm.viridis(np.minimum(z.OR.fillna(0), 10) / 10)
    ax.barh(np.arange(13), -np.log10(z.p.clip(lower=1e-300)), height=0.62, color=colors, edgecolor='black', linewidth=0.7)
    ax.axvline(-np.log10(0.05), ls=(0, (5, 5)), color='#666666', lw=1)
    ax.set_xlim(0, xmax)
    ax.set_ylim(12.65, -0.65)
    ax.set_yticks(range(13), modules)
    ax.tick_params(axis='y', length=0)
    ax.tick_params(axis='x', labelsize=10)
    ax.set_title(state, fontsize=12, pad=10, bbox={'boxstyle': 'square,pad=0.45', 'facecolor': 'white', 'edgecolor': 'black'})
    ax.spines[['top', 'right']].set_visible(False)
    a = audit[audit.state.eq(state)].iloc[0]
    ax.text(0.5, -0.14, f'GDF15+ cells: {int(a.GDF15_positive_cells)}/{int(a.n_cells)}', transform=ax.transAxes, ha='center', fontsize=9)
    if z.p.eq(1).all():
        ax.text(0.5, 0.5, 'No enriched modules\n(all raw P = 1)', transform=ax.transAxes, ha='center', fontsize=9, color='#555555')
cb = fig.colorbar(ScalarMappable(norm=Normalize(0, 10), cmap='viridis'), cax=fig.add_axes([0.923, 0.27, 0.013, 0.4]))
cb.set_label('Odds ratio (capped at 10)', fontsize=11)
fig.text(0.02, 0.96, 'E', fontsize=21, fontweight='bold', va='top')
fig.text(0.1, 0.95, 'GDF15 virtual-KO affected genes vs WGCNA modules', fontsize=17, fontweight='bold', va='top')
fig.text(0.1, 0.895, 'Williams gingival fibroblasts | All five states | Gene raw P < 0.05 | GDF15 excluded from overlap', fontsize=11)
fig.text(0.48, 0.07, '-log10 Fisher raw P', ha='center', fontsize=13)
forced = ', '.join(audit.loc[audit.GDF15_forced_into_500, 'state'])
fig.text(0.09, 0.018, 'Target manually retained (sensitivity analysis): ' + forced + '. Dashed line: raw P = 0.05.', fontsize=9)
base = 'GDF15_KO_all5_WGCNA_RAWP_20261009'
fig.savefig(F / f'{base}.pdf')
fig.savefig(F / f'{base}_600dpi.png', dpi=600)
fig.savefig(F / f'{base}_preview.png', dpi=110)
qa = {'all_states_complete': True, 'fisher_checks': 65, 'prior_two_state_p_values_unchanged': True, 'input_audit': audit.to_dict('records'), 'nominal_modules': ora.loc[ora.p.lt(0.05)].to_dict('records'), 'visual_review': 'pending'}
(O / 'validation.json').write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding='utf-8')
print(audit[['state', 'n_cells', 'GDF15_positive_cells', 'GDF15_forced_into_500']].to_string(index=False))
print(ora.loc[ora.p.lt(0.05), ['state', 'module', 'overlap', 'KO_significant', 'p']].to_string(index=False))
print('Validated all 65 tests; old results unchanged.')
