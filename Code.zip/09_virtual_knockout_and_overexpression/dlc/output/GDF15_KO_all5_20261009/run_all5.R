options(stringsAsFactors=FALSE,scipen=999)
.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5','C:/Users/Lin/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(Seurat);library(Matrix);library(data.table);library(scTenifoldKnk);library(jsonlite)})
OUT <- 'C:/wb_links/ko_all5_20261009'
OLD <- 'C:/wb_links/williams_ko_20260924'
SD <- file.path(OUT,'source_data');dir.create(SD,showWarnings=FALSE)
states <- c('Immune','ECM remodeling','Vascular','Pre-ECM','Matrix homeostasis')
ids <- c('Immune','ECM_remodeling','Vascular','Pre_ECM','Matrix_homeostasis')
status <- data.table(state=states,status='pending',error='')
save_status <- function(){fwrite(status,file.path(OUT,'status.csv'))}
save_status()
cat('Loading original Williams fibroblast object\n');flush.console()
fb <- readRDS('C:/wb_links/dlc_data/outputs/fb_seurat_annotated.rds')
fb <- subset(fb,subset=Study=='Williams');DefaultAssay(fb)<-'RNA'
stopifnot(ncol(fb)==14302)
audit <- list();results <- list()
oldaudit <- fread(file.path(OLD,'26_scTenifoldKnk_input_audit.csv'))
for(i in seq_along(states)){
 state<-states[i];sid<-ids[i]
 cat('\nSTATE',state,format(Sys.time()),'\n');flush.console()
 if(state %in% c('Immune','Vascular')){
   oldfile<-file.path(OLD,paste0('27_scTenifoldKnk_GDF15_',sid,'_differential_regulation.csv'))
   results[[state]]<-fread(oldfile)
   a<-copy(oldaudit)[which(oldaudit[['state']]==states[i])];a[,source:='reused original result']
   audit[[state]]<-a;status[i,status:='reused'];save_status();next
 }
 status[i,status:='preparing'];save_status()
 sub<-fb[,fb$fibroblast_short==state]
 sub<-FindVariableFeatures(sub,selection.method='vst',nfeatures=3000,verbose=FALSE)
 hvg<-VariableFeatures(sub);top500<-head(hvg,500);forced<-!'GDF15'%in%top500
 genes<-if(forced)unique(c(head(top500,499),'GDF15')) else top500
 counts<-GetAssayData(sub,assay='RNA',layer='counts')[genes,,drop=FALSE]
 detection<-mean(counts['GDF15',]>0)
 a<-data.table(state=state,n_cells=ncol(counts),n_genes=nrow(counts),GDF15_detection_fraction=detection,
  GDF15_positive_cells=sum(counts['GDF15',]>0),GDF15_HVG_rank=match('GDF15',hvg),GDF15_forced_into_500=forced,
  input_rule=if(forced)'Top 499 HVGs plus GDF15 sensitivity analysis' else 'Top 500 HVGs; GDF15 naturally retained',source='new run, identical original parameters')
 audit[[state]]<-a;fwrite(rbindlist(audit,fill=TRUE),file.path(SD,'input_audit.csv'))
 fwrite(data.table(rank=seq_along(genes),gene=genes),file.path(SD,paste0(sid,'_input_genes.csv')))
 cat('Input:',ncol(counts),'cells;',a$GDF15_positive_cells,'GDF15-positive; forced:',forced,'\n');flush.console()
 if(detection==0 || ncol(counts)<300){status[i,`:=`(status='not_estimable',error='Target absent or fewer than 300 cells')];save_status();next}
 cache<-file.path(SD,paste0(sid,'_scTenifoldKnk.rds'))
 status[i,status:='computing'];save_status()
 res<-tryCatch({
  if(file.exists(cache))knk<-readRDS(cache) else{
   set.seed(1)
   knk<-scTenifoldKnk(countMatrix=counts,gKO='GDF15',transcriptomeWide=FALSE,qc=FALSE,
    nc_lambda=0,nc_nNet=10,nc_nCells=300,nc_nComp=3,nc_scaleScores=TRUE,nc_symmetric=FALSE,nc_q=.9,
    td_K=3,td_maxIter=1000,td_maxError=1e-5,td_nDecimal=3,ma_nDim=2,dr_empiricalNull=FALSE,nCores=2)
   saveRDS(knk,cache)
  }
  dr<-as.data.table(knk$diffRegulation);dr[,state:=state]
  fwrite(dr,file.path(SD,paste0(sid,'_differential_regulation.csv')))
  dr
 },error=function(e){status[i,`:=`(status='failed',error=conditionMessage(e))];save_status();NULL})
 if(!is.null(res)){results[[state]]<-res;status[i,status:='complete'];save_status()}
 rm(sub,counts);gc()
}
audit_dt<-rbindlist(audit,fill=TRUE)
audit_dt[is.na(GDF15_positive_cells),GDF15_positive_cells:=round(n_cells*GDF15_detection_fraction)]
fwrite(audit_dt,file.path(SD,'input_audit.csv'))
member<-fread('C:/wb_links/p3_wgcna_20261008/data/05_WGCNA_gene_membership.csv')
modules<-setdiff(sort(unique(member$module)),'grey')
ora<-list();selected<-list()
for(state in names(results)){
 ko<-results[[state]];universe<-intersect(setdiff(ko$gene,'GDF15'),member$gene)
 sig<-intersect(ko[is.finite(p.value)&p.value<.05]$gene,universe)
 selected[[state]]<-ko[gene%in%universe,.(state=state,gene,raw_P=p.value,selected=p.value<.05)]
 ora[[state]]<-rbindlist(lapply(modules,function(m){
  g<-intersect(member[module==m]$gene,universe);N<-length(universe);M<-length(g);K<-length(sig);k<-length(intersect(g,sig))
  ft<-fisher.test(matrix(c(k,K-k,M-k,N-M-K+k),nrow=2),alternative='greater')
  data.table(state=state,module=m,background=N,module_tested=M,KO_significant=K,overlap=k,
   overlap_genes=paste(intersect(g,sig),collapse=';'),OR=unname(ft$estimate),p=ft$p.value)
 }))
}
ora<-rbindlist(ora);ora[,nominal_significant:=p<.05]
fwrite(ora,file.path(SD,'five_state_module_Fisher_RAWP.csv'))
fwrite(rbindlist(selected),file.path(SD,'tested_gene_RAWP_selection.csv'))
write_json(list(states=status,method='scTenifoldKnk',target='GDF15',seed=1,
 parameters=list(nc_nNet=10,nc_nCells=300,nc_nComp=3,nc_q=.9,td_K=3,td_maxIter=1000,nCores=2),
 gene_rule='Original top500 HVGs, forced GDF15 replaces rank500 when required; sensitivity analysis',
 module_rule='13 Williams pseudobulk WGCNA modules; background=KO-tested intersection with membership, target excluded',
 p_rule='Gene raw P<0.05; one-sided Fisher raw P; no top-N fallback',
 caveats='Sparse GDF15 detection; forced target inputs labelled sensitivity analysis; computational network perturbation'),
 file.path(OUT,'manifest.json'),pretty=TRUE,auto_unbox=TRUE)
print(audit_dt);print(ora[p<.05]);cat('[DONE]\n');flush.console()
