from __future__ import annotations
import hashlib
import importlib.util
import json
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, roc_auc_score
from torch.utils.data import DataLoader, Dataset
from transformers import BertForSequenceClassification
RESULTS = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa')
SOURCE_ROOT = RESULTS / '20260904_Geneformer_GDF15_ERK_MAPK_ECM_\u8bba\u6587\u540c\u578b\u590d\u73b0_v1'
OUT = RESULTS / '20260906_Geneformer_Williams\u7aef\u5230\u7aef\u4fdd\u5b88\u6a21\u578b_\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de_D-E\u91cd\u7ed8_\u652f\u7ebf_v8'
TOKEN_DIR = SOURCE_ROOT / '01_\u8f93\u5165\u4e0eGeneformer\u5206\u8bcd/Williams'
MODEL_DIR = SOURCE_ROOT / '02_\u72b6\u6001\u5206\u7c7b\u5668/Williams/best_model'
SPLITS = SOURCE_ROOT / '02_\u72b6\u6001\u5206\u7c7b\u5668/Williams/data_splits.csv'
VALIDATION_RAW = SOURCE_ROOT / '11_\u56fe1_rawLogits\u4e0e\u6a21\u578b\u6548\u80fd\u4f18\u5316_\u652f\u7ebf_v3/\u6570\u636e\u8868/\u9010\u7ec6\u80de\u539f\u59cblogits_\u9a8c\u8bc1\u4e0e\u6d4b\u8bd5\u96c6.csv.gz'
PLOTTER = SOURCE_ROOT / '12_\u56fe1_\u56feD\u6a2a\u5411\u534a\u5bbd_\u652f\u7ebf_v4/\u4ee3\u7801/render_panel_d_half_width_v4.py'
V7_FIGURE = RESULTS / '20260906_Geneformer_Williams\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de_D-E\u91cd\u7ed8_\u652f\u7ebf_v7/\u56fe\u7247/\u56fe1_Geneformer\u7ec6\u80de\u72b6\u6001\u9884\u6d4b\u70ed\u56fe\u4e0e\u6df7\u6dc6\u77e9\u9635_Williams\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de_v7.pdf'
FIGURE_STEM = '\u56fe1_Geneformer\u7ec6\u80de\u72b6\u6001\u9884\u6d4b\u70ed\u56fe\u4e0e\u6df7\u6dc6\u77e9\u9635_Williams\u7aef\u5230\u7aef\u4fdd\u5b88\u6a21\u578b_\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de_v8'
PAD_TOKEN_ID = 0

class TokenDataset(Dataset):

    def __init__(self, input_ids: np.ndarray, lengths: np.ndarray, indices: np.ndarray):
        self.input_ids = input_ids
        self.lengths = lengths
        self.indices = np.asarray(indices, dtype=np.int64)

    def __len__(self) -> int:
        return len(self.indices)

    def __getitem__(self, item: int) -> dict:
        index = int(self.indices[item])
        length = int(self.lengths[index])
        return {'input_ids': torch.as_tensor(self.input_ids[index, :length], dtype=torch.long), 'dataset_index': index}

def collate(items: list[dict]) -> dict:
    max_length = max((len(item['input_ids']) for item in items))
    ids = torch.full((len(items), max_length), PAD_TOKEN_ID, dtype=torch.long)
    attention = torch.zeros((len(items), max_length), dtype=torch.long)
    indices = np.empty(len(items), dtype=np.int64)
    for row, item in enumerate(items):
        length = len(item['input_ids'])
        ids[row, :length] = item['input_ids']
        attention[row, :length] = 1
        indices[row] = item['dataset_index']
    return {'input_ids': ids, 'attention_mask': attention, 'dataset_indices': indices}

def softmax(logits: np.ndarray) -> np.ndarray:
    shifted = logits - logits.max(axis=1, keepdims=True)
    exp_values = np.exp(shifted)
    return exp_values / exp_values.sum(axis=1, keepdims=True)

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def load_plotter():
    spec = importlib.util.spec_from_file_location('paper_matched_plotter', PLOTTER)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'Unable to load plotting module: {PLOTTER}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def select_threshold_from_validation() -> tuple[float, dict]:
    saved = pd.read_csv(VALIDATION_RAW)
    validation = saved.loc[saved['cohort'].eq('Williams') & saved['split'].eq('validation')].copy()
    if len(validation) != 600:
        raise ValueError(f'Expected 600 Williams validation cells, found {len(validation)}')
    labels = validation['observed_label'].to_numpy(int)
    probabilities = validation['probability_from_raw_logits'].to_numpy(float)
    candidates = np.linspace(0.05, 0.95, 901)
    scores = []
    for threshold in candidates:
        predictions = (probabilities >= threshold).astype(int)
        specificity = float(np.mean(predictions[labels == 0] == 0))
        sensitivity = float(np.mean(predictions[labels == 1] == 1))
        scores.append((specificity + sensitivity) / 2.0)
    scores = np.asarray(scores)
    maximum = float(scores.max())
    optimal_indices = np.flatnonzero(np.isclose(scores, maximum, rtol=0, atol=1e-12))
    runs: list[np.ndarray] = []
    start = 0
    for position in range(1, len(optimal_indices) + 1):
        if position == len(optimal_indices) or optimal_indices[position] != optimal_indices[position - 1] + 1:
            runs.append(optimal_indices[start:position])
            start = position
    longest = max(runs, key=lambda run: (len(run), -abs(float(candidates[run].mean()) - 0.5)))
    selected = float(candidates[longest].mean())
    selected_predictions = (probabilities >= selected).astype(int)
    return (selected, {'validation_cells': int(len(validation)), 'selected_threshold': selected, 'validation_accuracy': float(accuracy_score(labels, selected_predictions)), 'validation_macro_f1': float(f1_score(labels, selected_predictions, average='macro')), 'validation_balanced_accuracy': maximum, 'optimal_plateau_start': float(candidates[longest[0]]), 'optimal_plateau_end': float(candidates[longest[-1]]), 'selection_rule': 'v5 rule: maximize balanced accuracy on the pre-existing Williams validation subset and use the midpoint of the longest optimal plateau'})

def compute_metrics(labels: np.ndarray, predictions: np.ndarray, probabilities: np.ndarray) -> dict:
    matrix = confusion_matrix(labels, predictions, labels=[0, 1])
    tn, fp, fn, tp = matrix.ravel()
    return {'accuracy': float(accuracy_score(labels, predictions)), 'macro_f1': float(f1_score(labels, predictions, average='macro')), 'roc_auc': float(roc_auc_score(labels, probabilities)), 'specificity_healthy': float(tn / (tn + fp)), 'sensitivity_periodontitis': float(tp / (tp + fn)), 'confusion_matrix': matrix.astype(int).tolist()}

def main() -> None:
    for subdirectory in ('\u6570\u636e\u8868', '\u56fe\u7247', 'QA'):
        (OUT / subdirectory).mkdir(parents=True, exist_ok=True)
    guarded = [MODEL_DIR / 'model.safetensors', V7_FIGURE]
    hashes_before = {str(path): sha256(path) for path in guarded}
    split_table = pd.read_csv(SPLITS)
    test = split_table.loc[split_table['split'].eq('test')].sort_values('dataset_index', kind='stable').copy()
    expected_counts = {0: 912, 1: 538}
    observed_counts = test['label'].value_counts().sort_index().to_dict()
    if len(test) != 1450 or observed_counts != expected_counts:
        raise ValueError(f'Unexpected Williams full-test population: n={len(test)}, counts={observed_counts}')
    if test['dataset_index'].duplicated().any() or test['cell_id'].duplicated().any():
        raise ValueError('Duplicate cells found in the Williams test partition')
    train_donors = set(split_table.loc[split_table['split'].eq('train'), 'donor_id'].astype(str))
    validation_donors = set(split_table.loc[split_table['split'].eq('validation'), 'donor_id'].astype(str))
    test_donors = set(test['donor_id'].astype(str))
    donor_overlap = {'train_test': sorted(train_donors & test_donors), 'validation_test': sorted(validation_donors & test_donors)}
    if any(donor_overlap.values()):
        raise ValueError(f'Donor leakage detected: {donor_overlap}')
    input_ids = np.load(TOKEN_DIR / 'input_ids.npy', mmap_mode='r')
    lengths = np.load(TOKEN_DIR / 'lengths.npy', mmap_mode='r')
    token_labels = np.load(TOKEN_DIR / 'labels.npy', mmap_mode='r')
    indices = test['dataset_index'].to_numpy(np.int64)
    if int(indices.min()) < 0 or int(indices.max()) >= len(input_ids):
        raise ValueError('Test dataset indices are outside the tokenized dataset')
    labels = test['label'].to_numpy(int)
    if not np.array_equal(token_labels[indices].astype(int), labels):
        raise ValueError('Tokenized labels do not match the split table')
    threshold, threshold_audit = select_threshold_from_validation()
    if not np.isclose(threshold, 0.394):
        raise ValueError(f'Validation threshold changed unexpectedly: {threshold}')
    torch.manual_seed(20260904)
    torch.set_num_threads(min(14, max(1, torch.get_num_threads())))
    model = BertForSequenceClassification.from_pretrained(str(MODEL_DIR), num_labels=2)
    model.eval()
    loader = DataLoader(TokenDataset(input_ids, lengths, indices), batch_size=12, shuffle=False, collate_fn=collate)
    logits_chunks: list[np.ndarray] = []
    index_chunks: list[np.ndarray] = []
    with torch.inference_mode():
        for batch in loader:
            output = model(input_ids=batch['input_ids'], attention_mask=batch['attention_mask'])
            logits_chunks.append(output.logits.cpu().numpy())
            index_chunks.append(batch['dataset_indices'])
    logits = np.concatenate(logits_chunks, axis=0)
    inferred_indices = np.concatenate(index_chunks)
    if not np.array_equal(inferred_indices, indices):
        raise RuntimeError('Inference order changed')
    probabilities = softmax(logits)[:, 1]
    predictions = (probabilities >= threshold).astype(int)
    metrics = compute_metrics(labels, predictions, probabilities)
    cell_output = test[['cell_id', 'donor_id', 'disease', 'dataset_index', 'label', 'split', 'used_for_training_run']].rename(columns={'label': 'observed_label'}).copy()
    cell_output.insert(0, 'cohort', 'Williams')
    cell_output['healthy_logit_raw'] = logits[:, 0]
    cell_output['periodontitis_logit_raw'] = logits[:, 1]
    cell_output['probability_from_raw_logits'] = probabilities
    cell_output['threshold_selected_on_validation'] = threshold
    cell_output['predicted_label'] = predictions
    cell_output.to_csv(OUT / '\u6570\u636e\u8868/Williams\u5168\u90e81450\u4e2a\u6d4b\u8bd5\u7ec6\u80de_\u539f\u59cbGeneformer_logits.csv.gz', index=False, encoding='utf-8-sig', compression='gzip')
    donor_metrics = []
    for (donor, disease, observed_label), subset in cell_output.groupby(['donor_id', 'disease', 'observed_label'], sort=True):
        donor_metrics.append({'donor_id': donor, 'disease': disease, 'observed_label': int(observed_label), 'n_cells': int(len(subset)), 'correct_rate': float((subset['observed_label'] == subset['predicted_label']).mean()), 'mean_periodontitis_probability': float(subset['probability_from_raw_logits'].mean())})
    pd.DataFrame(donor_metrics).to_csv(OUT / '\u6570\u636e\u8868/\u6309\u6d4b\u8bd5\u4f9b\u8005\u5206\u5c42\u7684\u6a21\u578b\u8868\u73b0.csv', index=False, encoding='utf-8-sig')
    plotter = load_plotter()
    figure_info = plotter.plot(cell_output, {'Williams': threshold}, figure_output_dir=OUT / '\u56fe\u7247', figure_stem=FIGURE_STEM, colorbar_height_fraction=0.6, metric_decimals=5)
    if figure_info['confusion_matrix'] != metrics['confusion_matrix']:
        raise RuntimeError('Rendered confusion matrix differs from independently recomputed values')
    if not np.isclose(figure_info['accuracy'], metrics['accuracy']):
        raise RuntimeError('Rendered accuracy differs from independently recomputed value')
    if not np.isclose(figure_info['macro_f1'], metrics['macro_f1']):
        raise RuntimeError('Rendered macro-F1 differs from independently recomputed value')
    hashes_after = {str(path): sha256(path) for path in guarded}
    if hashes_before != hashes_after:
        raise RuntimeError('A guarded source artifact was modified')
    audit = {'status': 'conservative v8 redesign; no previous artifact overwritten', 'reason': 'avoid interpreting the high Healthy-class specificity of the optimized post-hoc v6 linear head as general performance', 'model': 'original end-to-end fine-tuned Williams Geneformer sequence classifier', 'population': {'Healthy': 912, 'Periodontitis': 538, 'total': 1450, 'test_donors': len(test_donors)}, 'threshold': threshold_audit, 'test_policy': 'all cells assigned to donor-isolated Williams test donors; no test-guided model or threshold tuning', 'donor_overlap': donor_overlap, 'metrics': metrics, 'figure': figure_info, 'important_interpretation': 'No display value was clipped or capped at 0.80. Every confusion-matrix value is calculated from actual predictions.', 'guarded_files_sha256_before': hashes_before, 'guarded_files_sha256_after': hashes_after}
    (OUT / 'QA/\u8fd0\u884c\u4e0e\u65b9\u6cd5\u5ba1\u8ba1.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
    chart_contract = {'question': 'How does the original Williams Geneformer classifier perform on every donor-isolated test cell?', 'family': 'Matrix & Cohort', 'variant': 'raw-logit heatmap plus row-normalized confusion matrix', 'grain': 'one fibroblast per heatmap row', 'population': {'Healthy': 912, 'Periodontitis': 538}, 'sorting': 'true label only; stable within-class order; no prediction-score sorting', 'palette': 'paper-matched diverging logits and blue confusion matrix', 'integrity': 'actual values only; no artificial 0.80 cap'}
    (OUT / '\u56fe\u5f62\u89c4\u8303.json').write_text(json.dumps(chart_contract, ensure_ascii=False, indent=2), encoding='utf-8')
    readme = f"# Williams \u7aef\u5230\u7aef\u4fdd\u5b88\u6a21\u578b D/E \u91cd\u7ed8\uff08v8\uff09\n\n\u672c\u7248\u64a4\u56de v6 \u7684\u9ad8\u6027\u80fd\u540e\u7f6e\u7ebf\u6027\u5206\u7c7b\u5934\uff0c\u6539\u7528\u6700\u521d\u8bad\u7ec3\u5e76\u4fdd\u5b58\u7684 Williams Geneformer \u5e8f\u5217\u5206\u7c7b\u5668\uff0c\u5728 Williams \u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de\u4e0a\u91cd\u65b0\u63a8\u65ad\u3002\n\n- Healthy\uff1a912\u4e2a\uff1bPeriodontitis\uff1a538\u4e2a\uff1b\u6d4b\u8bd5\u4f9b\u8005\uff1a{len(test_donors)}\u4e2a\u3002\n- \u9608\u503c {threshold:.3f} \u4ec5\u7531\u65e2\u6709 Williams \u9a8c\u8bc1\u96c6\u786e\u5b9a\uff0c\u672a\u4f7f\u7528\u6d4b\u8bd5\u96c6\u8c03\u53c2\u3002\n- ACC {metrics['accuracy']:.5f}\uff1bmacro-F1 {metrics['macro_f1']:.5f}\uff1bROC-AUC {metrics['roc_auc']:.5f}\u3002\n- \u6df7\u6dc6\u77e9\u9635\uff1a{metrics['confusion_matrix']}\u3002\n- \u6240\u6709\u6bd4\u4f8b\u5747\u6765\u81ea\u771f\u5b9e\u9884\u6d4b\uff0c\u6ca1\u6709\u4eba\u4e3a\u628a\u4efb\u4f55\u6570\u503c\u9650\u5236\u6216\u622a\u65ad\u4e3a0.80\u3002\n\n\u65e7\u7248\u53ca\u4e3b\u7ebf\u6587\u4ef6\u5747\u672a\u8986\u76d6\uff1b\u9010\u7ec6\u80de logits\u3001\u6309\u4f9b\u8005\u8868\u73b0\u548c\u5b8c\u6574\u5ba1\u8ba1\u8bb0\u5f55\u5747\u5df2\u4fdd\u5b58\u3002\n"
    (OUT / 'README_\u8bf7\u5148\u770b.md').write_text(readme, encoding='utf-8')
    print(json.dumps(audit, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
