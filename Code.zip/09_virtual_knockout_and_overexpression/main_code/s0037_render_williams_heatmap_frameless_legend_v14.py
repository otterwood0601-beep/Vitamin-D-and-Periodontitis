from __future__ import annotations
import hashlib
import importlib.util
import json
from pathlib import Path
import matplotlib.figure
OUT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260907_Williams\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de\u70ed\u56fe_\u4ec5D\u56fe_\u65e0\u56fe\u4f8b\u6846_\u652f\u7ebf_v14')
SOURCE_SCRIPT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260907_Williams\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de\u70ed\u56fe_\u4ec5D\u56fe_Predicted\u6807\u7b7e\u4e0a\u79fb_\u652f\u7ebf_v13\\\u4ee3\u7801\\render_williams_heatmap_d_only_v13.py')
SOURCE_PDF = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260907_Williams\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de\u70ed\u56fe_\u4ec5D\u56fe_Predicted\u6807\u7b7e\u4e0a\u79fb_\u652f\u7ebf_v13\\\u56fe\u7247\\\u56fe1D_Geneformer\u7ec6\u80de\u72b6\u6001\u9884\u6d4b\u70ed\u56fe_Williams\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de_Predicted\u6807\u7b7e\u4e0a\u79fb_v13.pdf')
STEM = '\u56fe1D_Geneformer\u7ec6\u80de\u72b6\u6001\u9884\u6d4b\u70ed\u56fe_Williams\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de_\u65e0Cell-states\u5916\u6846_v14'

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def load_v13_module():
    spec = importlib.util.spec_from_file_location('williams_heatmap_v13', SOURCE_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'Cannot load source plotting script: {SOURCE_SCRIPT}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def main() -> None:
    for directory in ('\u56fe\u7247', 'QA'):
        (OUT / directory).mkdir(parents=True, exist_ok=True)
    source_hash_before = sha256(SOURCE_PDF)
    module = load_v13_module()
    module.OUT = OUT
    module.STEM = STEM
    original_legend = matplotlib.figure.Figure.legend

    def frameless_legend(figure, *args, **kwargs):
        kwargs['frameon'] = False
        kwargs.pop('edgecolor', None)
        kwargs.pop('facecolor', None)
        return original_legend(figure, *args, **kwargs)
    matplotlib.figure.Figure.legend = frameless_legend
    try:
        _, labels, scores = module.load_plot_data()
        figure_info = module.draw(labels, scores)
    finally:
        matplotlib.figure.Figure.legend = original_legend
    source_hash_after = sha256(SOURCE_PDF)
    if source_hash_before != source_hash_after:
        raise RuntimeError('v13 source PDF was modified')
    audit = {'status': 'legend-frame-only revision; v13 not overwritten', 'source_v13_pdf': str(SOURCE_PDF), 'source_sha256_before': source_hash_before, 'source_sha256_after': source_hash_after, 'change': 'removed the gray frame/background around Cell states; retained title, color keys and labels', 'figure': figure_info, 'vector_contract': 'all visible objects are native PDF vectors; no embedded raster image'}
    (OUT / 'QA' / '\u8fd0\u884c\u4e0e\u77e2\u91cf\u5ba1\u8ba1_v14.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(audit, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
