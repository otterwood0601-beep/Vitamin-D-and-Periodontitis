from __future__ import annotations
import hashlib
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib.colors import TwoSlopeNorm
from matplotlib.patches import Patch, Rectangle
OUT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260907_Williams\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de\u70ed\u56fe_\u4ec5D\u56fe_Predicted\u6807\u7b7e\u4e0a\u79fb_\u652f\u7ebf_v13')
SOURCE_DATA = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260906_Geneformer_Williams\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de_D-E\u91cd\u7ed8_\u652f\u7ebf_v7\\\u6570\u636e\u8868\\Williams\u5168\u90e81450\u4e2a\u6d4b\u8bd5\u7ec6\u80de_\u9010\u7ec6\u80de\u539f\u59cb\u51b3\u7b56\u5206\u6570.csv.gz')
SOURCE_FIGURE = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u6b63\u6587\u56fe\\\u4e0a\u9762\u56fe_\u4ec5D.pdf')
STEM = '\u56fe1D_Geneformer\u7ec6\u80de\u72b6\u6001\u9884\u6d4b\u70ed\u56fe_Williams\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de_Predicted\u6807\u7b7e\u4e0a\u79fb_v13'
CLASS_NAMES = ('Healthy', 'Periodontitis')
STATE_COLORS = ('#392448', '#DCE6C3')

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def load_plot_data() -> tuple[pd.DataFrame, np.ndarray, np.ndarray]:
    data = pd.read_csv(SOURCE_DATA)
    required = {'cell_id', 'observed_label', 'healthy_head_score_raw', 'periodontitis_head_score_raw'}
    if not required.issubset(data.columns):
        raise ValueError(f'Missing columns: {sorted(required - set(data.columns))}')
    if len(data) != 1450 or data['cell_id'].duplicated().any():
        raise ValueError('Williams test-cell population is incomplete or duplicated')
    counts = data['observed_label'].value_counts().sort_index().to_dict()
    if counts != {0: 912, 1: 538}:
        raise ValueError(f'Unexpected state counts: {counts}')
    ordered = data.sort_values('observed_label', kind='stable').reset_index(drop=True)
    labels = ordered['observed_label'].to_numpy(dtype=int)
    scores = ordered[['healthy_head_score_raw', 'periodontitis_head_score_raw']].to_numpy(dtype=float)
    if not np.isclose(float(scores.min()), -1.6387814548878794):
        raise ValueError('Minimum raw score changed')
    if not np.isclose(float(scores.max()), 1.6387814548878794):
        raise ValueError('Maximum raw score changed')
    return (ordered, labels, scores)

def draw(labels: np.ndarray, scores: np.ndarray) -> dict[str, object]:
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 7.5, 'axes.labelsize': 8, 'xtick.labelsize': 6.5, 'ytick.labelsize': 6.5, 'axes.linewidth': 0.55, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none'})
    fig = plt.figure(figsize=(3.25, 3.55), facecolor='white')
    heat_position = [0.34, 0.07, 0.58, 0.71]
    ax_heat = fig.add_axes(heat_position)
    ax_true = fig.add_axes([0.285, 0.07, 0.022, 0.71])
    ax_pred = fig.add_axes([0.34, 0.792, 0.58, 0.022])
    ax_cbar = fig.add_axes([0.065, 0.25, 0.045, 0.42])
    raw_min = float(scores.min())
    raw_max = float(scores.max())
    norm = TwoSlopeNorm(vmin=raw_min, vcenter=0.0, vmax=raw_max)
    cmap = sns.color_palette('vlag', as_cmap=True)
    ax_heat.pcolormesh(np.arange(3), np.arange(len(scores) + 1), scores, cmap=cmap, norm=norm, shading='flat', linewidth=0, antialiased=False, rasterized=False)
    ax_heat.set_xlim(0, 2)
    ax_heat.set_ylim(len(scores), 0)
    ax_heat.set_xticks([])
    ax_heat.set_yticks([])
    for spine in ax_heat.spines.values():
        spine.set_visible(False)
    healthy_rows = int((labels == 0).sum())
    ax_true.add_patch(Rectangle((0, 0), 1, healthy_rows, facecolor=STATE_COLORS[0], edgecolor='none'))
    ax_true.add_patch(Rectangle((0, healthy_rows), 1, len(labels) - healthy_rows, facecolor=STATE_COLORS[1], edgecolor='none'))
    ax_true.set_xlim(0, 1)
    ax_true.set_ylim(len(labels), 0)
    ax_true.set_xticks([])
    ax_true.set_yticks([])
    for spine in ax_true.spines.values():
        spine.set_visible(False)
    ax_pred.add_patch(Rectangle((0, 0), 1, 1, facecolor=STATE_COLORS[0], edgecolor='none'))
    ax_pred.add_patch(Rectangle((1, 0), 1, 1, facecolor=STATE_COLORS[1], edgecolor='none'))
    ax_pred.set_xlim(0, 2)
    ax_pred.set_ylim(0, 1)
    ax_pred.set_xticks([])
    ax_pred.set_yticks([])
    for spine in ax_pred.spines.values():
        spine.set_visible(False)
    fig.text(0.63, 0.827, 'Predicted', ha='center', va='bottom', fontsize=7.5)
    fig.text(0.245, 0.425, 'True', rotation=90, ha='center', va='center', fontsize=7.5)
    steps = 512
    for step in range(steps):
        fraction = step / steps
        value = raw_min + fraction * (raw_max - raw_min)
        ax_cbar.add_patch(Rectangle((0, fraction), 1, 1 / steps, facecolor=cmap(norm(value)), edgecolor='none', linewidth=0))
    ax_cbar.set_xlim(0, 1)
    ax_cbar.set_ylim(0, 1)
    ax_cbar.set_xticks([])
    ax_cbar.set_yticks([0, 0.5, 1], [f'{raw_min:.2f}', '0', f'{raw_max:.2f}'])
    ax_cbar.yaxis.tick_left()
    ax_cbar.tick_params(axis='y', labelsize=6, length=2, pad=1)
    for spine in ax_cbar.spines.values():
        spine.set_linewidth(0.5)
    handles = [Patch(facecolor=STATE_COLORS[i], edgecolor='none', label=CLASS_NAMES[i]) for i in range(2)]
    fig.legend(handles=handles, title='Cell states', frameon=True, edgecolor='#D9D9D9', facecolor='white', ncol=2, loc='upper center', bbox_to_anchor=(0.63, 0.995), fontsize=7, title_fontsize=8, handlelength=1.35, borderpad=0.35, columnspacing=1.15)
    image_dir = OUT / '\u56fe\u7247'
    image_dir.mkdir(parents=True, exist_ok=True)
    paths = {suffix: image_dir / f'{STEM}.{suffix}' for suffix in ('pdf', 'svg', 'png')}
    fig.savefig(paths['pdf'], facecolor='white', bbox_inches='tight', pad_inches=0.03)
    fig.savefig(paths['svg'], facecolor='white', bbox_inches='tight', pad_inches=0.03)
    fig.savefig(paths['png'], dpi=600, facecolor='white', bbox_inches='tight', pad_inches=0.03)
    plt.close(fig)
    return {'outputs': {kind: str(path) for kind, path in paths.items()}, 'panel_letter_D_removed': True, 'predicted_label_position': 'centered immediately above predicted-state strip', 'rows': int(len(scores)), 'sorting': 'true state only; stable within-state order', 'raw_score_range': [raw_min, raw_max]}

def main() -> None:
    for directory in ('\u56fe\u7247', '\u6570\u636e\u8868', 'QA'):
        (OUT / directory).mkdir(parents=True, exist_ok=True)
    source_hash_before = sha256(SOURCE_FIGURE)
    ordered, labels, scores = load_plot_data()
    figure = draw(labels, scores)
    source_hash_after = sha256(SOURCE_FIGURE)
    if source_hash_before != source_hash_after:
        raise RuntimeError('The supplied old D panel was modified')
    ordered[['cell_id', 'donor_id', 'disease', 'observed_label', 'healthy_head_score_raw', 'periodontitis_head_score_raw']].to_csv(OUT / '\u6570\u636e\u8868' / 'Williams\u5168\u90e81450\u4e2a\u6d4b\u8bd5\u7ec6\u80de_D\u70ed\u56fe\u7ed8\u56fe\u6570\u636e_v13.csv.gz', index=False, encoding='utf-8-sig', compression='gzip')
    audit = {'status': 'D-only layout revision; source not overwritten', 'source_figure': str(SOURCE_FIGURE), 'source_data': str(SOURCE_DATA), 'source_sha256_before': source_hash_before, 'source_sha256_after': source_hash_after, 'population': {'Healthy': 912, 'Periodontitis': 538, 'total': 1450}, 'figure': figure, 'vector_contract': 'heatmap cells, strips, colorbar, legend and labels are native PDF vector objects'}
    (OUT / 'QA' / '\u8fd0\u884c\u4e0e\u77e2\u91cf\u5ba1\u8ba1_v13.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(audit, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
