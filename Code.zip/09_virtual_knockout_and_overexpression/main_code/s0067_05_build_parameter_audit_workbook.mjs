import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const root = path.resolve(process.argv[2] ?? ".");
const auditDir = path.join(root, "05_parameter_audit");
const previewDir = path.resolve(process.argv[3] ?? "C:/Users/Lin/Desktop/\u8840\u6e05\u7ef4\u751f\u7d20/\u8f93\u51fa\u7ed3\u679c/_\u4e34\u65f6\u8fd0\u884c\u533a/gdf15_vko_workbook_build/previews");
const displayRoot = process.argv[4] ?? root;
const outputPath = path.join(auditDir, "GDF15_virtual_KO_parameter_audit.xlsx");

await fs.mkdir(auditDir, { recursive: true });
await fs.mkdir(previewDir, { recursive: true });

const workbook = Workbook.create();
const summary = workbook.worksheets.add("Summary");
summary.showGridLines = false;

const colors = {
  navy: "#244D78",
  teal: "#0F766E",
  paleBlue: "#EAF2F8",
  paleTeal: "#E7F3F1",
  amber: "#FFF2CC",
  amberDark: "#8A5A00",
  red: "#FCE4D6",
  redDark: "#9C3A24",
  green: "#E2F0D9",
  greenDark: "#2F6B3B",
  ink: "#17223B",
  muted: "#5C677D",
  grid: "#D9E0EA",
  white: "#FFFFFF",
};

function styleSection(range, fill = colors.paleBlue, fontColor = colors.navy) {
  range.format = {
    fill,
    font: { name: "Arial", bold: true, color: fontColor, size: 12 },
    horizontalAlignment: "left",
    verticalAlignment: "center",
    borders: { preset: "outside", style: "thin", color: "#B8C6D8" },
  };
}

function styleMergedBox(range, fill, fontColor, fontSize = 10) {
  range.format = {
    fill,
    font: { name: "Arial", color: fontColor, size: fontSize },
    wrapText: true,
    verticalAlignment: "center",
    borders: { preset: "outside", style: "thin", color: "#B8C6D8" },
  };
}

summary.getRange("A1:H2").merge();
summary.getRange("A1").values = [["GDF15 \u865a\u62df\u6572\u9664\uff08scTenifoldKnk\uff09\u9996\u7248\uff1a\u7ed3\u679c\u4e0e\u53c2\u6570\u5ba1\u8ba1"]];
summary.getRange("A1:H2").format = {
  fill: colors.navy,
  font: { name: "Arial", bold: true, color: colors.white, size: 18 },
  horizontalAlignment: "center",
  verticalAlignment: "center",
};

summary.getRange("A4:H4").merge();
summary.getRange("A4").values = [["\u7ed3\u8bba\u5148\u884c"]];
styleSection(summary.getRange("A4:H4"));
summary.getRange("A5:H7").merge();
summary.getRange("A5").values = [[
  "\u5df2\u5728\u56db\u961f\u5217\u6574\u5408\u7684\u7259\u9f88\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e2d\u5b8c\u6210 GDF15 \u865a\u62df\u6572\u9664\u9996\u7248\u3002\u4e25\u683c\u8d28\u63a7\u540e\u5171 14,188 \u4e2a\u7ec6\u80de\uff0cGDF15 \u4ec5\u5728 90 \u4e2a\u7ec6\u80de\u4e2d\u68c0\u51fa\uff080.634%\uff09\uff0c\u56e0\u6b64\u672c\u7248\u5b9a\u4f4d\u4e3a\u63a2\u7d22\u6027\u3002\u6392\u9664\u9776\u57fa\u56e0\u81ea\u8eab\u540e\uff0c\u53d7\u6270\u52a8\u6392\u540d\u524d\u4e94\u7684\u57fa\u56e0\u4e3a SOD2\u3001AHNAK\u3001FOSB\u3001PIK3R1 \u548c SLIT3\u3002"
]];
styleMergedBox(summary.getRange("A5:H7"), "#F5F8FC", colors.ink, 11);

const kpiHeaders = [
  ["A9:B9", "\u8fd0\u884c\u72b6\u6001"],
  ["C9:D9", "\u4e25\u683c\u8d28\u63a7\u7ec6\u80de"],
  ["E9:F9", "GDF15 \u68c0\u51fa\u7ec6\u80de"],
  ["G9:H9", "GDF15 \u68c0\u51fa\u7387"],
];
const kpiValues = [
  ["A10:B12", "PASS WITH WARNINGS", colors.amber, colors.amberDark],
  ["C10:D12", 14188, colors.paleBlue, colors.navy],
  ["E10:F12", 90, colors.paleBlue, colors.navy],
  ["G10:H12", 0.00634338877925007, colors.red, colors.redDark],
];
for (const [address, label] of kpiHeaders) {
  const range = summary.getRange(address);
  range.merge();
  summary.getRange(address.split(":")[0]).values = [[label]];
  range.format = {
    font: { name: "Arial", bold: true, color: colors.muted, size: 9 },
    horizontalAlignment: "center",
    verticalAlignment: "center",
  };
}
for (const [address, value, fill, fontColor] of kpiValues) {
  const range = summary.getRange(address);
  range.merge();
  const topLeft = summary.getRange(address.split(":")[0]);
  topLeft.values = [[value]];
  range.format = {
    fill,
    font: { name: "Arial", bold: true, color: fontColor, size: 16 },
    horizontalAlignment: "center",
    verticalAlignment: "center",
    borders: { preset: "outside", style: "medium", color: "#7DA6C8" },
  };
}
summary.getRange("G10").format.numberFormat = "0.000%";
summary.getRange("C10").format.numberFormat = "#,##0";
summary.getRange("E10").format.numberFormat = "#,##0";

summary.getRange("A14:H14").merge();
summary.getRange("A14").values = [["\u5173\u952e\u7ed3\u679c"]];
styleSection(summary.getRange("A14:H14"), colors.paleTeal, colors.teal);
summary.getRange("A15:H18").merge();
summary.getRange("A15").values = [[
  "\u9776\u57fa\u56e0 GDF15 \u672c\u8eab\u7684\u6270\u52a8\u5206\u6570\u6700\u9ad8\uff08\u6309\u7b97\u6cd5\u5b9a\u4e49\u5c5e\u9884\u671f\u7ed3\u679c\uff09\uff0c\u4e0b\u6e38\u5c55\u793a\u65f6\u5df2\u6392\u9664\u3002\u5168\u90e8 1,001 \u4e2a\u7f51\u7edc\u57fa\u56e0\u4e2d\u5171\u6709 41 \u4e2a FDR<0.05\uff0c\u5176\u4e2d 40 \u4e2a\u975e\u9776\u57fa\u56e0\u8fdb\u5165\u5bcc\u96c6\u5019\u9009\u3002Panel F \u9009\u62e9 15 \u4e2a\u6392\u540d\u9760\u524d\u6761\u76ee\uff0c\u4f46 15/15 \u5747\u672a\u8fbe\u5230 BH-FDR<0.05\uff1b\u5b83\u4eec\u53ea\u80fd\u4f5c\u4e3a\u63a2\u7d22\u6027\u529f\u80fd\u7ebf\u7d22\uff0c\u4e0d\u80fd\u5199\u6210\u663e\u8457\u5bcc\u96c6\u3002"
]];
styleMergedBox(summary.getRange("A15:H18"), "#F3FAF8", colors.ink, 10);

summary.getRange("A20:H20").merge();
summary.getRange("A20").values = [["\u5fc5\u987b\u4fdd\u7559\u7684\u89e3\u91ca\u8fb9\u754c"]];
styleSection(summary.getRange("A20:H20"), colors.red, colors.redDark);
summary.getRange("A21:H25").merge();
summary.getRange("A21").values = [[
  "1) GDF15 \u7684\u5355\u7ec6\u80de\u68c0\u51fa\u7387\u5f88\u4f4e\uff0c\u7f51\u7edc\u63a8\u65ad\u5bf9\u62bd\u6837\u4e0e\u5f52\u4e00\u5316\u65b9\u6848\u53ef\u80fd\u654f\u611f\u3002\n2) scTenifoldKnk \u7684 FC \u662f\u865a\u62df\u6572\u9664\u524d\u540e\u8c03\u63a7\u4f4d\u79fb\u7684\u76f8\u5bf9\u5f3a\u5ea6\uff0c\u4e0d\u662f\u8868\u8fbe fold change\uff0c\u4e5f\u4e0d\u63d0\u4f9b\u4e0a\u8c03/\u4e0b\u8c03\u65b9\u5411\u3002\n3) \u9996\u7248\u4e3a\u63a7\u5236\u8fd0\u884c\u65f6\u95f4\u4f7f\u7528 1,000 \u4e2a HVG + GDF15\uff1b\u6b63\u5f0f\u7248\u5e94\u505a\u66f4\u591a\u57fa\u56e0\u3001\u79cd\u5b50\u3001\u961f\u5217\u548c\u7259\u5468\u708e\u9650\u5b9a\u5b50\u96c6\u7684\u654f\u611f\u6027\u5206\u6790\u3002\n4) \u5bcc\u96c6\u56fe\u663e\u793a\u7684\u662f\u5019\u9009\u901a\u8def\u6392\u5e8f\uff1b\u5f53\u524d\u6ca1\u6709 FDR \u663e\u8457\u6761\u76ee\u3002"
]];
styleMergedBox(summary.getRange("A21:H25"), "#FFF7F2", colors.redDark, 10);

summary.getRange("A27:H27").merge();
summary.getRange("A27").values = [["\u53c2\u6570\u5ba1\u8ba1\u8bf4\u660e"]];
styleSection(summary.getRange("A27:H27"), colors.amber, colors.amberDark);
summary.getRange("A28:H31").merge();
summary.getRange("A28").values = [[
  "\u672c\u5de5\u4f5c\u7c3f\u5171\u8bb0\u5f55 48 \u4e2a\u5206\u6790\u53c2\u6570\uff0c\u5176\u4e2d 21 \u4e2a\u4e3a\u5206\u6790\u8005\u5728\u53c2\u8003\u8bba\u6587\u672a\u660e\u786e\u3001\u6216\u56e0\u672c\u5730\u6570\u636e/\u7b97\u529b\u6761\u4ef6\u9700\u8981\u9002\u914d\u65f6\u81ea\u884c\u8bbe\u5b9a\u3002\u8bf7\u4f18\u5148\u67e5\u770b\u201cSelf-set parameters\u201d\u5de5\u4f5c\u8868\uff1b\u6bcf\u4e2a\u53c2\u6570\u5747\u5217\u51fa\u8bbe\u5b9a\u7406\u7531\u3001\u5bf9\u7ed3\u679c\u7684\u5f71\u54cd\u548c\u6b63\u5f0f\u7248\u590d\u6838\u52a8\u4f5c\u3002\u6d45\u9ec4\u8272\u8868\u793a\u5206\u6790\u8005\u81ea\u884c\u8bbe\u5b9a\u3002"
]];
styleMergedBox(summary.getRange("A28:H31"), "#FFFDF3", colors.amberDark, 10);

summary.getRange("A33:H33").merge();
summary.getRange("A33").values = [["\u4e3b\u8981\u8f93\u51fa\u4f4d\u7f6e"]];
styleSection(summary.getRange("A33:H33"));
const outputRows = [
  ["\u5408\u5e76\u77e2\u91cf\u56fe", path.join(displayRoot, "04_figures", "Panels_EF_GDF15_virtual_KO_reference_style.pdf")],
  ["\u5168\u91cf\u6270\u52a8\u7ed3\u679c", path.join(displayRoot, "02_virtual_ko", "GDF15_differential_regulation_all_genes.csv")],
  ["\u53c2\u6570\u5ba1\u8ba1\u5de5\u4f5c\u7c3f", path.join(displayRoot, "05_parameter_audit", "GDF15_virtual_KO_parameter_audit.xlsx")],
  ["\u53ef\u590d\u73b0\u811a\u672c", path.join(displayRoot, "scripts")],
];
for (let i = 0; i < outputRows.length; i += 1) {
  const row = 34 + i;
  summary.getRange(`A${row}:B${row}`).merge();
  summary.getRange(`A${row}`).values = [[outputRows[i][0]]];
  summary.getRange(`C${row}:H${row}`).merge();
  summary.getRange(`C${row}`).values = [[outputRows[i][1]]];
}
summary.getRange("A34:H37").format = {
  font: { name: "Arial", color: colors.ink, size: 9 },
  wrapText: true,
  verticalAlignment: "center",
  borders: { preset: "all", style: "thin", color: colors.grid },
};
summary.getRange("A34:B37").format = {
  fill: "#F5F8FC",
  font: { name: "Arial", bold: true, color: colors.navy, size: 9 },
  verticalAlignment: "center",
  borders: { preset: "all", style: "thin", color: colors.grid },
};

const imports = [
  ["Self-set parameters", path.join(auditDir, "analyst_defined_parameters_only.csv")],
  ["All parameters", path.join(auditDir, "all_parameters.csv")],
  ["QA checks", path.join(root, "06_qa", "QA_checks.csv")],
  ["Cohort QC", path.join(root, "01_input_qc", "cohort_and_GDF15_detection_summary.csv")],
  ["Top20 genes", path.join(root, "04_figures", "Panel_E_top20_differentially_regulated_genes_source.csv")],
  ["Panel F terms", path.join(root, "04_figures", "Panel_F_functional_enrichment_source.csv")],
  ["Software versions", path.join(auditDir, "software_versions.csv")],
  ["References", path.join(auditDir, "reference_sources.csv")],
];

for (const [sheetName, filePath] of imports) {
  const csvText = await fs.readFile(filePath, "utf8");
  const imported = await Workbook.fromCSV(csvText, { sheetName });
  const sourceSheet = imported.worksheets.getItem(sheetName);
  const sourceRange = sourceSheet.getUsedRange();
  const values = sourceRange.values;
  const destination = workbook.worksheets.add(sheetName);
  if (values.length > 0 && (values[0]?.length ?? 0) > 0) {
    destination.getRangeByIndexes(0, 0, values.length, values[0].length).values = values;
  }
}

function columnName(indexOneBased) {
  let n = indexOneBased;
  let out = "";
  while (n > 0) {
    n -= 1;
    out = String.fromCharCode(65 + (n % 26)) + out;
    n = Math.floor(n / 26);
  }
  return out;
}

const importedNames = imports.map(([name]) => name);
for (let sheetIndex = 0; sheetIndex < importedNames.length; sheetIndex += 1) {
  const sheetName = importedNames[sheetIndex];
  const sheet = workbook.worksheets.getItem(sheetName);
  sheet.showGridLines = false;
  sheet.freezePanes.freezeRows(1);
  const used = sheet.getUsedRange();
  used.format = {
    font: { name: "Arial", size: 9, color: colors.ink },
    verticalAlignment: "top",
    wrapText: true,
    borders: { preset: "all", style: "thin", color: colors.grid },
  };
  const header = sheet.getRangeByIndexes(0, 0, 1, used.columnCount);
  header.format = {
    fill: colors.navy,
    font: { name: "Arial", size: 9, bold: true, color: colors.white },
    verticalAlignment: "center",
    horizontalAlignment: "left",
    wrapText: true,
    borders: { preset: "all", style: "thin", color: "#B8C6D8" },
  };
  header.format.rowHeight = 34;
  used.format.autofitColumns();
  used.format.autofitRows();
  for (let c = 0; c < used.columnCount; c += 1) {
    const column = sheet.getRangeByIndexes(0, c, used.rowCount, 1);
    const values = column.values;
    let longest = 0;
    for (const row of values.slice(0, Math.min(values.length, 100))) {
      const value = row[0] == null ? "" : String(row[0]);
      longest = Math.max(longest, value.length);
    }
    if (longest > 80) column.format.columnWidth = 42;
    else if (longest > 45) column.format.columnWidth = 34;
    else if (longest > 24) column.format.columnWidth = 25;
    else if (longest < 8) column.format.columnWidth = 11;
  }
  used.format.autofitRows();

  const tableRange = `A1:${columnName(used.columnCount)}${used.rowCount}`;
  const table = sheet.tables.add(tableRange, true, `AuditTable${String(sheetIndex + 1).padStart(2, "0")}`);
  table.style = "TableStyleMedium2";
  table.showBandedColumns = false;
  table.showFilterButton = true;
}

for (const sheetName of ["Self-set parameters", "All parameters"]) {
  const sheet = workbook.worksheets.getItem(sheetName);
  const used = sheet.getUsedRange();
  sheet.getRangeByIndexes(1, 4, Math.max(used.rowCount - 1, 1), 1).format = {
    fill: colors.amber,
    font: { name: "Arial", bold: true, color: colors.amberDark, size: 9 },
    horizontalAlignment: "center",
    verticalAlignment: "top",
    borders: { preset: "all", style: "thin", color: colors.grid },
  };
  sheet.getRange(`A1:A${used.rowCount}`).format.columnWidth = 18;
  sheet.getRange(`B1:B${used.rowCount}`).format.columnWidth = 34;
  sheet.getRange(`C1:C${used.rowCount}`).format.columnWidth = 34;
  sheet.getRange(`D1:D${used.rowCount}`).format.columnWidth = 30;
  sheet.getRange(`E1:E${used.rowCount}`).format.columnWidth = 12;
  sheet.getRange(`F1:H${used.rowCount}`).format.columnWidth = 45;
  sheet.getRange(`F2:H${used.rowCount}`).format.rowHeight = 54;
}

const qaSheet = workbook.worksheets.getItem("QA checks");
const qaUsed = qaSheet.getUsedRange();
const qaValues = qaUsed.values;
for (let r = 1; r < qaValues.length; r += 1) {
  const passed = String(qaValues[r][4]).toUpperCase() === "TRUE";
  const severity = String(qaValues[r][5]).toLowerCase();
  const rowRange = qaSheet.getRangeByIndexes(r, 0, 1, qaUsed.columnCount);
  if (!passed && severity === "warning") {
    rowRange.format.fill = colors.amber;
    rowRange.format.font = { name: "Arial", color: colors.amberDark, bold: true, size: 9 };
  } else if (!passed) {
    rowRange.format.fill = colors.red;
    rowRange.format.font = { name: "Arial", color: colors.redDark, bold: true, size: 9 };
  } else {
    qaSheet.getRangeByIndexes(r, 4, 1, 1).format = {
      fill: colors.green,
      font: { name: "Arial", color: colors.greenDark, bold: true, size: 9 },
      horizontalAlignment: "center",
    };
  }
}
qaSheet.getRange(`A1:A${qaUsed.rowCount}`).format.columnWidth = 11;
qaSheet.getRange(`B1:B${qaUsed.rowCount}`).format.columnWidth = 34;
qaSheet.getRange(`C1:D${qaUsed.rowCount}`).format.columnWidth = 24;
qaSheet.getRange(`E1:F${qaUsed.rowCount}`).format.columnWidth = 13;
qaSheet.getRange(`G1:H${qaUsed.rowCount}`).format.columnWidth = 38;

const cohortSheet = workbook.worksheets.getItem("Cohort QC");
cohortSheet.getRange("C2:D100").format.numberFormat = "#,##0";
cohortSheet.getRange("E2:E100").format.numberFormat = "0.000";
cohortSheet.getRange("F2:F100").format.numberFormat = "#,##0";

const top20Sheet = workbook.worksheets.getItem("Top20 genes");
top20Sheet.getRange("B2:D100").format.numberFormat = "0.000";
top20Sheet.getRange("E2:F100").format.numberFormat = "0.00E+00";
top20Sheet.getRange("G2:G100").format.numberFormat = "0";
top20Sheet.getRange("I2:I100").format.numberFormat = "0.000";

const panelFSheet = workbook.worksheets.getItem("Panel F terms");
panelFSheet.getRange("E2:G100").format.numberFormat = "0.000";
panelFSheet.getRange("H2:J100").format.numberFormat = "0.00E+00";
panelFSheet.getRange("L2:L100").format.numberFormat = "0";
panelFSheet.getRange("O2:O100").format.numberFormat = "0.000";
panelFSheet.getRange("Q2:R100").format.columnWidth = 48;

summary.freezePanes.freezeRows(2);
summary.getRange("A1:H37").format.columnWidth = 17;
summary.getRange("A5:H7").format.rowHeight = 26;
summary.getRange("A15:H18").format.rowHeight = 24;
summary.getRange("A21:H25").format.rowHeight = 24;
summary.getRange("A28:H31").format.rowHeight = 24;
summary.getRange("A34:H37").format.rowHeight = 24;

const summaryInspect = await workbook.inspect({
  kind: "table",
  range: "Summary!A1:H37",
  include: "values,formulas",
  tableMaxRows: 40,
  tableMaxCols: 8,
});
const errorInspect = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "formula error scan before export",
});

const previewSpecs = [
  ["Summary", "A1:H37"],
  ["Self-set parameters", "A1:H22"],
  ["All parameters", "A1:H25"],
  ["QA checks", "A1:H15"],
  ["Cohort QC", "A1:F12"],
  ["Top20 genes", "A1:J21"],
  ["Panel F terms", "A1:R16"],
  ["Software versions", "A1:C15"],
  ["References", "A1:C8"],
];

const previews = [];
for (const [sheetName, range] of previewSpecs) {
  const blob = await workbook.render({ sheetName, range, scale: 1.05, format: "png" });
  const bytes = new Uint8Array(await blob.arrayBuffer());
  const previewPath = path.join(previewDir, `${sheetName.replaceAll(" ", "_")}.png`);
  await fs.writeFile(previewPath, bytes);
  previews.push({ sheetName, range, previewPath, bytes: bytes.length });
}

const output = await SpreadsheetFile.exportXlsx(workbook);
await output.save(outputPath);

const importedFinal = await SpreadsheetFile.importXlsx(await FileBlob.load(outputPath));
const finalSheetInspect = await importedFinal.inspect({ kind: "sheet", include: "id,name" });
const finalErrorInspect = await importedFinal.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "formula error scan after re-import",
});

console.log(JSON.stringify({
  outputPath,
  sheets: ["Summary", ...importedNames],
  previews,
  summaryInspect: summaryInspect.ndjson,
  preExportFormulaErrors: errorInspect.ndjson,
  finalSheetInspect: finalSheetInspect.ndjson,
  postImportFormulaErrors: finalErrorInspect.ndjson,
}, null, 2));
