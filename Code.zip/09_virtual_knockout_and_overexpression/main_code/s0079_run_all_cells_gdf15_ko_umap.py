from __future__ import annotations
import argparse
import hashlib
import json
import math
import os
import platform
import random
import sys
import time
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sklearn
import torch
import transformers
import umap
from transformers import BertForSequenceClassification
SEED = 20260904
PAD_TOKEN_ID = 0
GDF15_TOKEN_ID = 6248
PROJECT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260904_Geneformer_GDF15_ERK_MAPK_ECM_\u8bba\u6587\u540c\u578b\u590d\u73b0_v1')
OUT = PROJECT / '14_GDF15\u5168\u7ec6\u80de\u6572\u9664\u654f\u611f\u6027UMAP_\u652f\u7ebf_v1'
INPUT_DIR = PROJECT / '01_\u8f93\u5165\u4e0eGeneformer\u5206\u8bcd' / 'Williams'
MODEL_DIR = PROJECT / '02_\u72b6\u6001\u5206\u7c7b\u5668' / 'Williams' / 'best_model'
OLD_TABLE = PROJECT / '08_\u6269\u5c55\u56fe\u8868_PLOS_Frontiers\u540c\u578b' / '\u6570\u636e\u8868' / 'Williams_GDF15_KO_OE_sensitivity_UMAP.csv'
FIG_DIR = OUT / '\u56fe\u7247'
TABLE_DIR = OUT / '\u6570\u636e\u8868'
QA_DIR = OUT / 'QA'
CHUNK_DIR = QA_DIR / '\u539f\u59cb\u5d4c\u5165\u5206\u5757'
TABLE_PATH = TABLE_DIR / 'Williams_GDF15_KO_sensitivity_UMAP_\u5168\u90e813257\u7ec6\u80de.csv.gz'
EMBED_PATH = TABLE_DIR / 'Williams_Geneformer_\u5168\u90e813257\u7ec6\u80de\u539f\u59cb\u5d4c\u5165.npz'
STEM = '\u56fe2B_GDF15\u6572\u9664\u654f\u611f\u6027UMAP_\u5168\u90e8\u7ec6\u80de_\u652f\u7ebfv1'

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument('--batch-size', type=int, default=8)
    parser.add_argument('--chunk-size', type=int, default=256)
    parser.add_argument('--plot-only', action='store_true')
    return parser.parse_args()

def ensure_dirs() -> None:
    for path in (FIG_DIR, TABLE_DIR, QA_DIR, CHUNK_DIR):
        path.mkdir(parents=True, exist_ok=True)

def set_deterministic() -> None:
    os.environ.setdefault('PYTHONHASHSEED', str(SEED))
    random.seed(SEED)
    np.random.seed(SEED)
    torch.manual_seed(SEED)
    torch.use_deterministic_algorithms(False)
    torch.set_num_threads(min(14, os.cpu_count() or 1))

def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def load_inputs() -> tuple[np.ndarray, np.ndarray, pd.DataFrame]:
    input_ids = np.load(INPUT_DIR / 'input_ids.npy', mmap_mode='r')
    lengths = np.load(INPUT_DIR / 'lengths.npy', mmap_mode='r')
    metadata = pd.read_csv(INPUT_DIR / 'cell_metadata.csv')
    n_cells = len(metadata)
    if input_ids.shape[0] != n_cells or len(lengths) != n_cells:
        raise ValueError('Token arrays and metadata do not have the same cell count')
    expected = np.arange(n_cells, dtype=int)
    observed = metadata['dataset_index'].to_numpy(dtype=int)
    if not np.array_equal(observed, expected):
        raise ValueError('dataset_index is not a complete 0..n-1 row key')
    if metadata['dataset_index'].duplicated().any():
        raise ValueError('dataset_index contains duplicates')
    return (input_ids, lengths, metadata)

def mean_pool(last_hidden: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
    weights = attention_mask.unsqueeze(-1).to(last_hidden.dtype)
    return (last_hidden * weights).sum(dim=1) / weights.sum(dim=1).clamp_min(1.0)

def infer_sequences(model: BertForSequenceClassification, sequences: list[np.ndarray], batch_size: int) -> np.ndarray:
    outputs: list[np.ndarray] = []
    model.eval()
    with torch.inference_mode():
        for start in range(0, len(sequences), batch_size):
            chunk = sequences[start:start + batch_size]
            max_len = max((len(sequence) for sequence in chunk))
            ids = torch.full((len(chunk), max_len), PAD_TOKEN_ID, dtype=torch.long)
            mask = torch.zeros((len(chunk), max_len), dtype=torch.long)
            for row, sequence in enumerate(chunk):
                length = len(sequence)
                ids[row, :length] = torch.as_tensor(sequence, dtype=torch.long)
                mask[row, :length] = 1
            hidden = model.bert(input_ids=ids, attention_mask=mask, return_dict=True).last_hidden_state
            outputs.append(mean_pool(hidden, mask).cpu().numpy().astype(np.float32))
    return np.concatenate(outputs, axis=0)

def infer_rows(model: BertForSequenceClassification, input_ids: np.ndarray, lengths: np.ndarray, indices: np.ndarray, batch_size: int) -> np.ndarray:
    outputs: list[np.ndarray] = []
    model.eval()
    with torch.inference_mode():
        for start in range(0, len(indices), batch_size):
            batch_indices = indices[start:start + batch_size]
            batch_lengths = np.asarray(lengths[batch_indices], dtype=int)
            max_len = int(batch_lengths.max())
            ids = torch.as_tensor(np.asarray(input_ids[batch_indices, :max_len]), dtype=torch.long)
            positions = torch.arange(max_len).unsqueeze(0)
            mask = (positions < torch.as_tensor(batch_lengths).unsqueeze(1)).long()
            hidden = model.bert(input_ids=ids, attention_mask=mask, return_dict=True).last_hidden_state
            outputs.append(mean_pool(hidden, mask).cpu().numpy().astype(np.float32))
    return np.concatenate(outputs, axis=0)

def all_original_embeddings(model: BertForSequenceClassification, input_ids: np.ndarray, lengths: np.ndarray, batch_size: int, chunk_size: int) -> np.ndarray:
    n_cells = input_ids.shape[0]
    chunks: list[np.ndarray] = []
    started = time.time()
    for start in range(0, n_cells, chunk_size):
        stop = min(start + chunk_size, n_cells)
        path = CHUNK_DIR / f'embedding_{start:05d}_{stop:05d}.npy'
        expected_shape = (stop - start, int(model.config.hidden_size))
        if path.exists():
            embedding = np.load(path)
            if embedding.shape != expected_shape:
                raise ValueError(f'Checkpoint shape mismatch: {path} {embedding.shape} != {expected_shape}')
        else:
            indices = np.arange(start, stop, dtype=int)
            embedding = infer_rows(model, input_ids, lengths, indices, batch_size)
            np.save(path, embedding)
        chunks.append(embedding)
        elapsed = (time.time() - started) / 60.0
        print(f'Original embeddings: {stop}/{n_cells} cells ({elapsed:.1f} min)', flush=True)
    result = np.concatenate(chunks, axis=0)
    if result.shape != (n_cells, int(model.config.hidden_size)):
        raise ValueError(f'Unexpected full embedding shape: {result.shape}')
    return result

def paired_cosine_distance(original: np.ndarray, perturbed: np.ndarray) -> np.ndarray:
    numerator = np.einsum('ij,ij->i', original, perturbed)
    denominator = np.linalg.norm(original, axis=1) * np.linalg.norm(perturbed, axis=1)
    similarity = numerator / np.clip(denominator, 1e-12, None)
    return np.clip(1.0 - similarity, 0.0, None)

def compute_table(batch_size: int, chunk_size: int) -> pd.DataFrame:
    input_ids, lengths, metadata = load_inputs()
    model = BertForSequenceClassification.from_pretrained(str(MODEL_DIR), num_labels=2)
    embeddings = all_original_embeddings(model, input_ids, lengths, batch_size, chunk_size)
    executable = metadata['GDF15_token_present'].astype(bool).to_numpy()
    executable_indices = np.flatnonzero(executable)
    perturbed_sequences: list[np.ndarray] = []
    for index in executable_indices:
        sequence = np.asarray(input_ids[index, :int(lengths[index])], dtype=np.int64).copy()
        positions = np.flatnonzero(sequence == GDF15_TOKEN_ID)
        if len(positions) == 0:
            raise ValueError(f'Metadata/token disagreement at dataset_index={index}')
        perturbed_sequences.append(np.delete(sequence, int(positions[0])))
    perturbed_embeddings = infer_sequences(model, perturbed_sequences, batch_size)
    ko_values = np.full(len(metadata), np.nan, dtype=float)
    ko_values[executable_indices] = paired_cosine_distance(embeddings[executable_indices], perturbed_embeddings)
    print(f'GDF15 knockout executed for {len(executable_indices)}/{len(metadata)} cells', flush=True)
    reducer = umap.UMAP(n_neighbors=15, min_dist=0.3, metric='cosine', random_state=SEED, n_jobs=1)
    coordinates = reducer.fit_transform(embeddings)
    print('UMAP complete', flush=True)
    columns = ['dataset_index', 'cell_id', 'donor_id', 'disease', 'label', 'GDF15_token_present']
    table = metadata[columns].copy()
    table['UMAP_1'] = coordinates[:, 0]
    table['UMAP_2'] = coordinates[:, 1]
    table['GDF15_KO_cosine_shift'] = ko_values
    table.to_csv(TABLE_PATH, index=False, encoding='utf-8-sig', compression='gzip')
    np.savez_compressed(EMBED_PATH, dataset_indices=metadata['dataset_index'].to_numpy(dtype=int), original_embeddings=embeddings)
    return table

def plot_figure(table: pd.DataFrame) -> None:
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 7.5, 'axes.titlesize': 9, 'axes.labelsize': 8, 'xtick.labelsize': 7, 'ytick.labelsize': 7, 'axes.linewidth': 0.7, 'pdf.fonttype': 42, 'ps.fonttype': 42})
    values = table['GDF15_KO_cosine_shift'].to_numpy(dtype=float) * 1000.0
    executable = np.isfinite(values)
    positive = values[executable & (values > 0)]
    vmax = float(np.quantile(positive, 0.99)) if len(positive) else 1.0
    vmax = max(vmax, 1e-06)
    fig, ax = plt.subplots(figsize=(5.6, 5.2), facecolor='white')
    ax.scatter(table['UMAP_1'], table['UMAP_2'], s=1.9, c='#E6E6E6', edgecolors='none', rasterized=True)
    positions = np.flatnonzero(executable)
    positions = positions[np.argsort(values[positions])]
    scatter = ax.scatter(table.iloc[positions]['UMAP_1'], table.iloc[positions]['UMAP_2'], c=values[positions], s=4.2, cmap='Reds', vmin=0, vmax=vmax, edgecolors='none', rasterized=True)
    ax.set_title('GDF15 knockout sensitivity', fontsize=9, fontweight='bold', pad=7)
    ax.set_xlabel('UMAP 1')
    ax.set_ylabel('UMAP 2')
    ax.grid(False)
    ax.set_facecolor('white')
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_color('black')
        spine.set_linewidth(0.7)
    colorbar = fig.colorbar(scatter, ax=ax, fraction=0.046, pad=0.03)
    colorbar.ax.set_title('Cosine shift\n(x10^3)', fontsize=6.5, pad=4)
    colorbar.ax.tick_params(labelsize=6)
    colorbar.outline.set_linewidth(0.45)
    ax.text(-0.13, 1.08, 'B', transform=ax.transAxes, fontsize=15, fontweight='normal', va='top')
    fig.subplots_adjust(left=0.13, right=0.88, bottom=0.12, top=0.88)
    fig.savefig(FIG_DIR / f'{STEM}.pdf', dpi=300, facecolor='white', bbox_inches='tight')
    fig.savefig(FIG_DIR / f'{STEM}.svg', facecolor='white', bbox_inches='tight')
    fig.savefig(FIG_DIR / f'{STEM}.png', dpi=600, facecolor='white', bbox_inches='tight')
    plt.close(fig)

def write_qa(table: pd.DataFrame, elapsed_seconds: float) -> None:
    old = pd.read_csv(OLD_TABLE)
    old_counts = old.groupby('disease', observed=True).size().to_dict()
    new_counts = table.groupby('disease', observed=True).size().to_dict()
    executable_counts = table.loc[table['GDF15_token_present'].astype(bool)].groupby('disease', observed=True).size().to_dict()
    comparison = pd.DataFrame([{'version': '\u539f\u56fe\u8f93\u5165', 'total_cells': len(old), 'normal_cells': int(old_counts.get('normal', 0)), 'periodontitis_cells': int(old_counts.get('periodontitis', 0)), 'GDF15_KO_executable_cells': int(old['GDF15_token_present'].astype(bool).sum())}, {'version': '\u672c\u652f\u7ebf\u5168\u90e8\u7ec6\u80de\u8f93\u5165', 'total_cells': len(table), 'normal_cells': int(new_counts.get('normal', 0)), 'periodontitis_cells': int(new_counts.get('periodontitis', 0)), 'GDF15_KO_executable_cells': int(table['GDF15_token_present'].astype(bool).sum())}])
    comparison.to_csv(TABLE_DIR / '\u8f93\u5165\u7ec6\u80de\u8986\u76d6\u5bf9\u6bd4.csv', index=False, encoding='utf-8-sig')
    qa = {'status': 'PASS', 'population': 'All tokenized Williams fibroblasts: normal + periodontitis', 'total_cells': int(len(table)), 'normal_cells': int(new_counts.get('normal', 0)), 'periodontitis_cells': int(new_counts.get('periodontitis', 0)), 'unique_dataset_indices': int(table['dataset_index'].nunique()), 'duplicate_dataset_indices': int(table['dataset_index'].duplicated().sum()), 'GDF15_KO_executable_cells': int(table['GDF15_token_present'].astype(bool).sum()), 'GDF15_KO_executable_normal': int(executable_counts.get('normal', 0)), 'GDF15_KO_executable_periodontitis': int(executable_counts.get('periodontitis', 0)), 'GDF15_KO_nonexecutable_cells': int((~table['GDF15_token_present'].astype(bool)).sum()), 'nonexecutable_shift_is_NA': bool(table.loc[~table['GDF15_token_present'].astype(bool), 'GDF15_KO_cosine_shift'].isna().all()), 'old_plot_input_cells': int(len(old)), 'removed_annotation': 'Gray: GDF15 token absent; KO not executable', 'removed_annotation_present_in_new_code': False, 'model': str(MODEL_DIR), 'model_sha256': file_sha256(MODEL_DIR / 'model.safetensors'), 'seed': SEED, 'umap': {'n_neighbors': 15, 'min_dist': 0.3, 'metric': 'cosine', 'random_state': SEED}, 'software': {'python': sys.version, 'platform': platform.platform(), 'torch': torch.__version__, 'transformers': transformers.__version__, 'numpy': np.__version__, 'pandas': pd.__version__, 'scikit_learn': sklearn.__version__, 'umap_learn': umap.__version__, 'matplotlib': matplotlib.__version__}, 'elapsed_minutes': elapsed_seconds / 60.0, 'outputs': {'pdf': str(FIG_DIR / f'{STEM}.pdf'), 'png': str(FIG_DIR / f'{STEM}.png'), 'svg': str(FIG_DIR / f'{STEM}.svg'), 'table': str(TABLE_PATH)}}
    (QA_DIR / '\u5168\u7ec6\u80deGDF15\u6572\u9664\u654f\u611f\u6027_\u8fd0\u884c\u4e0e\u6570\u636e\u5ba1\u8ba1.json').write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding='utf-8')

def main() -> None:
    args = parse_args()
    ensure_dirs()
    set_deterministic()
    started = time.time()
    if args.plot_only:
        if not TABLE_PATH.exists():
            raise FileNotFoundError(TABLE_PATH)
        table = pd.read_csv(TABLE_PATH)
    else:
        table = compute_table(args.batch_size, args.chunk_size)
    plot_figure(table)
    write_qa(table, time.time() - started)
    print(FIG_DIR / f'{STEM}.pdf', flush=True)
if __name__ == '__main__':
    main()
