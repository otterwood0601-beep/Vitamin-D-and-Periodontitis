import fs from "node:fs/promises";
import path from "node:path";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const root = "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260904_Geneformer_GDF15_ERK_MAPK_ECM_\u8bba\u6587\u540c\u578b\u590d\u73b0_v1";
const dataDir = `${root}/08_\u6269\u5c55\u56fe\u8868_PLOS_Frontiers\u540c\u578b/\u6570\u636e\u8868`;
const qaDir = `${root}/08_\u6269\u5c55\u56fe\u8868_PLOS_Frontiers\u540c\u578b/QA/XLSX\u6e32\u67d3`;
const outputPath = `${dataDir}/GDF15_Geneformer\u65b9\u5411\u6270\u52a8\u4e0e\u5206\u7c7b\u7ed3\u679c.xlsx`;

const pooledCsv = `${dataDir}/GDF15_directional_perturbation_pooled_summary.csv`;
const cohortCsv = `${dataDir}/GDF15_directional_perturbation_cohort_summary.csv`;
const modelDir = `${root}/02_\u72b6\u6001\u5206\u7c7b\u5668`;

function parseCsv(text) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  const source = text.replace(/^\uFEFF/, "");
  for (let i = 0; i < source.length; i += 1) {
    const char = source[i];
    if (quoted) {
      if (char === '"' && source[i + 1] === '"') {
        field += '"';
        i += 1;
      } else if (char === '"') {
        quoted = false;
      } else {
        field += char;
      }
    } else if (char === '"') {
      quoted = true;
    } else if (char === ",") {
      row.push(field);
      field = "";
    } else if (char === "\n") {
      row.push(field.replace(/\r$/, ""));
      if (row.some((value) => value !== "")) rows.push(row);
      row = [];
      field = "";
    } else {
      field += char;
    }
  }
  if (field !== "" || row.length) {
    row.push(field.replace(/\r$/, ""));
    rows.push(row);
  }
  const headers = rows.shift();
  return rows.map((values) => Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ""])));
}

async function readCsv(filePath) {
  return parseCsv(await fs.readFile(filePath, "utf8"));
}

function num(value) {
  if (value === "" || value === null || value === undefined) return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function boolText(value) {
  return String(value).toLowerCase() === "true" ? "Yes" : "No";
}

function columnName(index) {
  let value = index + 1;
  let result = "";
  while (value > 0) {
    const remainder = (value - 1) % 26;
    result = String.fromCharCode(65 + remainder) + result;
    value = Math.floor((value - 1) / 26);
  }
  return result;
}

function styleDataSheet(sheet, title, subtitle, headers, rows, tableName, tabColor, widths) {
  const lastColumn = columnName(headers.length - 1);
  const headerRow = 4;
  const lastRow = headerRow + rows.length;
  sheet.showGridLines = false;
  sheet.tabColor = tabColor;
  sheet.mergeCells(`A1:${lastColumn}1`);
  sheet.getRange("A1").values = [[title]];
  sheet.getRange(`A1:${lastColumn}1`).format = {
    fill: "#17365D",
    font: { name: "Aptos", size: 14, bold: true, color: "#FFFFFF" },
    verticalAlignment: "center",
  };
  sheet.getRange(`A1:${lastColumn}1`).format.rowHeight = 27;
  sheet.mergeCells(`A2:${lastColumn}2`);
  sheet.getRange("A2").values = [[subtitle]];
  sheet.getRange(`A2:${lastColumn}2`).format = {
    fill: "#DCE6F1",
    font: { name: "Aptos", size: 9, italic: true, color: "#404040" },
    wrapText: true,
    verticalAlignment: "center",
  };
  sheet.getRange(`A2:${lastColumn}2`).format.rowHeight = 36;
  sheet.getRange(`A${headerRow}:${lastColumn}${headerRow}`).values = [headers];
  if (rows.length) sheet.getRange(`A${headerRow + 1}:${lastColumn}${lastRow}`).values = rows;
  const used = sheet.getRange(`A${headerRow}:${lastColumn}${lastRow}`);
  used.format.font = { name: "Aptos", size: 9 };
  used.format.verticalAlignment = "center";
  used.format.borders = { preset: "all", style: "thin", color: "#D9E2F3" };
  sheet.getRange(`A${headerRow}:${lastColumn}${headerRow}`).format = {
    fill: "#4472C4",
    font: { name: "Aptos", size: 9, bold: true, color: "#FFFFFF" },
    wrapText: true,
    verticalAlignment: "center",
  };
  sheet.getRange(`A${headerRow}:${lastColumn}${headerRow}`).format.rowHeight = 32;
  const table = sheet.tables.add(`A${headerRow}:${lastColumn}${lastRow}`, true, tableName);
  table.style = "TableStyleMedium2";
  sheet.freezePanes.freezeRows(headerRow);
  widths.forEach((width, index) => {
    sheet.getRange(`${columnName(index)}1:${columnName(index)}${lastRow}`).format.columnWidth = width;
  });
  sheet.getRange(`A${headerRow + 1}:E${lastRow}`).format.wrapText = true;
  return { lastRow, lastColumn };
}

function classificationMetrics(rows) {
  const test = rows.filter((row) => row.split === "test");
  const cm = [[0, 0], [0, 0]];
  for (const row of test) cm[Number(row.observed_label)][Number(row.predicted_label)] += 1;
  const accuracy = (cm[0][0] + cm[1][1]) / test.length;
  const f1s = [0, 1].map((label) => {
    const tp = cm[label][label];
    const fp = cm[1 - label][label];
    const fn = cm[label][1 - label];
    const precision = tp / Math.max(tp + fp, 1);
    const recall = tp / Math.max(tp + fn, 1);
    return (2 * precision * recall) / Math.max(precision + recall, 1e-12);
  });
  return {
    n: test.length,
    cm,
    accuracy,
    macroF1: (f1s[0] + f1s[1]) / 2,
  };
}

const pooled = await readCsv(pooledCsv);
const cohort = await readCsv(cohortCsv);
const williamsPredictions = await readCsv(`${modelDir}/Williams/validation_and_test_predictions.csv`);
const caetanoPredictions = await readCsv(`${modelDir}/Caetano/validation_and_test_predictions.csv`);
const combinedPredictions = [...williamsPredictions, ...caetanoPredictions];

const workbook = Workbook.create();
const summarySheet = workbook.worksheets.add("\u4e3b\u8981\u7ed3\u679c");
const cohortSheet = workbook.worksheets.add("\u961f\u5217\u660e\u7ec6");
const performanceSheet = workbook.worksheets.add("\u5206\u7c7b\u6027\u80fd");
const notesSheet = workbook.worksheets.add("\u8bf4\u660e\u4e0e\u6765\u6e90");

const directionHeaders = [
  "\u5206\u6790\u65b9\u5411", "\u8d77\u59cb\u72b6\u6001", "\u6270\u52a8", "\u76ee\u6807\u72b6\u6001", "Gene", "N cells", "N donors",
  "Shift to target", "95% CI low", "95% CI high", "Shift away source",
  "Mean cosine shift", "Raw P", "BH-FDR", "\u540c\u65f6\u5411\u76ee\u6807\u4e14\u8fdc\u79bb\u8d77\u70b9",
];

const pooledRows = pooled
  .sort((a, b) => (a.Perturbation === "GDF15 knockout" ? -1 : 1) - (b.Perturbation === "GDF15 knockout" ? -1 : 1))
  .map((row) => [
    row.Scenario,
    row.Start_state,
    row.Perturbation,
    row.Target_state,
    row.Gene,
    num(row.N_cells),
    num(row.N_donors),
    num(row.Shift_to_target),
    num(row.Shift_to_target_CI95_low),
    num(row.Shift_to_target_CI95_high),
    num(row.Shift_away_source),
    num(row.Mean_cosine_shift),
    num(row.Raw_P_one_sided),
    num(row.BH_FDR_two_pooled_tests),
    boolText(row.Desired_direction),
  ]);

const summaryLayout = styleDataSheet(
  summarySheet,
  "GDF15 Geneformer \u5b9a\u5411\u6270\u52a8\u4e3b\u8981\u7ed3\u679c",
  "\u5408\u5e76 Williams \u4e0e Caetano \u7ec6\u80de\uff1bRaw P \u4e3a\u5355\u4fa7 Wilcoxon \u7b26\u53f7\u79e9\u68c0\u9a8c\uff0cBH-FDR \u5728\u4e24\u4e2a\u5408\u5e76\u65b9\u5411\u68c0\u9a8c\u5185\u6821\u6b63\u3002",
  directionHeaders,
  pooledRows,
  "PooledDirectionResults",
  "#4472C4",
  [34, 15, 23, 15, 10, 10, 10, 15, 15, 15, 17, 17, 13, 13, 19],
);
summarySheet.getRange(`F5:G${summaryLayout.lastRow}`).format.numberFormat = "0";
summarySheet.getRange(`H5:L${summaryLayout.lastRow}`).format.numberFormat = "0.000E+00";
summarySheet.getRange(`M5:N${summaryLayout.lastRow}`).format.numberFormat = "0.0000";
summarySheet.getRange(`M5:N${summaryLayout.lastRow}`).conditionalFormats.add("cellIs", {
  operator: "lessThan",
  formula: 0.05,
  format: { fill: "#E2F0D9", font: { bold: true, color: "#006100" } },
});

const cohortHeaders = ["\u961f\u5217", ...directionHeaders];
const cohortRows = cohort.map((row) => [
  row.Scope,
  row.Scenario,
  row.Start_state,
  row.Perturbation,
  row.Target_state,
  row.Gene,
  num(row.N_cells),
  num(row.N_donors),
  num(row.Shift_to_target),
  num(row.Shift_to_target_CI95_low),
  num(row.Shift_to_target_CI95_high),
  num(row.Shift_away_source),
  num(row.Mean_cosine_shift),
  num(row.Raw_P_one_sided),
  num(row.BH_FDR_four_cohort_tests),
  boolText(row.Desired_direction),
]);
const cohortLayout = styleDataSheet(
  cohortSheet,
  "GDF15 Geneformer \u5b9a\u5411\u6270\u52a8\u961f\u5217\u660e\u7ec6",
  "Williams \u4e0e Caetano \u5206\u5f00\u62a5\u544a\uff1bBH-FDR \u5728 2 \u4e2a\u961f\u5217 \xd7 2 \u4e2a\u6270\u52a8\u65b9\u5411\u7684\u56db\u4e2a\u4e3b\u68c0\u9a8c\u5185\u6821\u6b63\u3002",
  cohortHeaders,
  cohortRows,
  "CohortDirectionResults",
  "#70AD47",
  [13, 34, 15, 23, 15, 10, 10, 10, 15, 15, 15, 17, 17, 13, 13, 19],
);
cohortSheet.getRange(`G5:H${cohortLayout.lastRow}`).format.numberFormat = "0";
cohortSheet.getRange(`I5:M${cohortLayout.lastRow}`).format.numberFormat = "0.000E+00";
cohortSheet.getRange(`N5:O${cohortLayout.lastRow}`).format.numberFormat = "0.0000";
cohortSheet.getRange(`N5:O${cohortLayout.lastRow}`).conditionalFormats.add("cellIs", {
  operator: "lessThan",
  formula: 0.05,
  format: { fill: "#E2F0D9", font: { bold: true, color: "#006100" } },
});

const performanceHeaders = [
  "\u961f\u5217", "Test cells", "\u771f\u5b9e Healthy", "\u771f\u5b9e Periodontitis", "Healthy\u2192Healthy",
  "Healthy\u2192Periodontitis", "Periodontitis\u2192Healthy", "Periodontitis\u2192Periodontitis", "Accuracy", "Macro-F1",
];
const performanceInputs = [
  ["Williams", classificationMetrics(williamsPredictions)],
  ["Caetano", classificationMetrics(caetanoPredictions)],
  ["Pooled", classificationMetrics(combinedPredictions)],
];
const performanceRows = performanceInputs.map(([name, metrics]) => [
  name,
  metrics.n,
  metrics.cm[0][0] + metrics.cm[0][1],
  metrics.cm[1][0] + metrics.cm[1][1],
  metrics.cm[0][0],
  metrics.cm[0][1],
  metrics.cm[1][0],
  metrics.cm[1][1],
  metrics.accuracy,
  metrics.macroF1,
]);
const performanceLayout = styleDataSheet(
  performanceSheet,
  "Geneformer \u5065\u5eb7/\u7259\u5468\u708e\u5206\u7c7b\u6027\u80fd",
  "\u4ec5\u4f7f\u7528\u672c\u6b21\u4e24\u4e2a\u5355\u7ec6\u80de\u961f\u5217\u7684\u72ec\u7acb test split\uff1b\u6df7\u6dc6\u77e9\u9635\u4e3a\u8ba1\u6570\uff0c\u56fe\u4e2d\u53e6\u663e\u793a\u884c\u5f52\u4e00\u5316\u6bd4\u4f8b\u3002",
  performanceHeaders,
  performanceRows,
  "ClassifierPerformance",
  "#ED7D31",
  [13, 12, 14, 18, 17, 21, 21, 25, 13, 13],
);
performanceSheet.getRange(`B5:H${performanceLayout.lastRow}`).format.numberFormat = "0";
performanceSheet.getRange(`I5:J${performanceLayout.lastRow}`).format.numberFormat = "0.000";

notesSheet.showGridLines = false;
notesSheet.tabColor = "#A5A5A5";
notesSheet.mergeCells("A1:C1");
notesSheet.getRange("A1").values = [["\u53e3\u5f84\u3001\u89e3\u91ca\u4e0e\u53c2\u8003\u6765\u6e90"]];
notesSheet.getRange("A1:C1").format = {
  fill: "#17365D",
  font: { name: "Aptos", size: 14, bold: true, color: "#FFFFFF" },
  verticalAlignment: "center",
};
notesSheet.getRange("A1:C1").format.rowHeight = 27;
const notesRows = [
  ["\u9879\u76ee", "\u8bf4\u660e", "\u503c/\u6765\u6e90"],
  ["KO \u4e3b\u5206\u6790", "\u7259\u5468\u708e\u7ec6\u80de\u4e2d\u5220\u9664\u53ef\u68c0\u6d4b\u5230\u7684 GDF15 token\uff0c\u76ee\u6807\u72b6\u6001\u4e3a Healthy\u3002", "Williams n=28\uff1bCaetano n=2"],
  ["OE \u4e3b\u5206\u6790", "\u5065\u5eb7\u7ec6\u80de\u4e2d\u628a GDF15 token \u79fb\u5230\u79e9\u5e8f\u5217\u9996\u4f4d\uff0c\u76ee\u6807\u72b6\u6001\u4e3a Periodontitis\u3002", "\u6bcf\u4e2a\u961f\u5217\u6309 donor \u5206\u5c42\u62bd\u53d6 n=128"],
  ["Shift to target", "\u6270\u52a8\u540e\u5d4c\u5165\u4e0e\u76ee\u6807\u72b6\u6001\u8d28\u5fc3\u7684\u4f59\u5f26\u76f8\u4f3c\u5ea6\u53d8\u5316\uff1b\u6b63\u503c\u4ee3\u8868\u66f4\u9760\u8fd1\u76ee\u6807\u3002", "\u6570\u503c\u5217\u4fdd\u6301\u539f\u59cb\u7cbe\u5ea6"],
  ["Shift away source", "\u6270\u52a8\u540e\u5d4c\u5165\u4e0e\u8d77\u59cb\u72b6\u6001\u8d28\u5fc3\u7684\u4f59\u5f26\u76f8\u4f3c\u5ea6\u53d8\u5316\uff1b\u8d1f\u503c\u4ee3\u8868\u8fdc\u79bb\u8d77\u59cb\u72b6\u6001\u3002", "\u4e0e Shift to target \u914d\u5bf9\u89e3\u91ca"],
  ["Raw P", "\u5bf9\u5355\u7ec6\u80de Shift to target \u505a\u5355\u4fa7 Wilcoxon \u7b26\u53f7\u79e9\u68c0\u9a8c\uff08\u5907\u62e9\uff1a\u5747\u5927\u4e8e 0\uff09\u3002", "P < 0.05 \u9ad8\u4eae"],
  ["FDR", "\u4e3b\u8981\u7ed3\u679c\u6309\u4e24\u4e2a pooled \u65b9\u5411\u6821\u6b63\uff1b\u961f\u5217\u660e\u7ec6\u6309\u56db\u4e2a\u961f\u5217\xd7\u65b9\u5411\u4e3b\u68c0\u9a8c\u6821\u6b63\u3002", "Benjamini\u2013Hochberg"],
  ["\u5206\u7c7b\u56fe\u6570\u636e", "\u4ec5\u4f7f\u7528\u672c\u6b21 Geneformer \u5206\u7c7b\u5668 test split\u3002", "Williams 600 + Caetano 90 = 690"],
  ["UMAP KO \u96f6\u503c", "\u539f\u5e8f\u5217\u4e2d\u6ca1\u6709 GDF15 token \u7684\u7ec6\u80de\u65e0\u6cd5\u6267\u884c\u5220\u9664\uff0c\u654f\u611f\u6027\u6309\u7ed3\u6784\u6027 0 \u663e\u793a\u3002", "Williams \u540c\u4e00 UMAP \u5750\u6807\uff0c\u5171 1,251 \u4e2a\u7ec6\u80de"],
  ["PLOS \u683c\u5f0f\u53c2\u8003", "Prediction likelihood heatmap \u4e0e confusion matrix\uff0cFigure 2D\u2013E\u3002", "https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0344084"],
  ["Frontiers \u683c\u5f0f\u53c2\u8003", "KO/OE sensitivity UMAP \u4e0e circular evidence\uff0cFigure 5B\u2013E\u3002", "https://www.frontiersin.org/journals/immunology/articles/10.3389/fimmu.2026.1859310/full"],
  ["\u652f\u6491\u6570\u636e", "\u7ec6\u80de\u7ea7\u65b9\u5411\u6270\u52a8\u3001UMAP \u654f\u611f\u6027\u4e0e\u4e0b\u6e38 token \u8bc1\u636e\u5747\u4fdd\u5b58\u5728\u540c\u76ee\u5f55 CSV/CSV.GZ\u3002", dataDir],
];
notesSheet.getRange(`A3:C${2 + notesRows.length}`).values = notesRows;
notesSheet.getRange(`A3:C${2 + notesRows.length}`).format = {
  font: { name: "Aptos", size: 9 },
  verticalAlignment: "center",
  wrapText: true,
  borders: { preset: "all", style: "thin", color: "#D9E2F3" },
};
notesSheet.getRange("A3:C3").format = {
  fill: "#4472C4",
  font: { name: "Aptos", size: 9, bold: true, color: "#FFFFFF" },
  verticalAlignment: "center",
};
notesSheet.getRange(`A3:A${2 + notesRows.length}`).format.columnWidth = 18;
notesSheet.getRange(`B3:B${2 + notesRows.length}`).format.columnWidth = 66;
notesSheet.getRange(`C3:C${2 + notesRows.length}`).format.columnWidth = 80;
notesSheet.getRange(`A4:C${2 + notesRows.length}`).format.rowHeight = 34;
notesSheet.freezePanes.freezeRows(3);

await fs.mkdir(dataDir, { recursive: true });
await fs.mkdir(qaDir, { recursive: true });

const sheetNames = ["\u4e3b\u8981\u7ed3\u679c", "\u961f\u5217\u660e\u7ec6", "\u5206\u7c7b\u6027\u80fd", "\u8bf4\u660e\u4e0e\u6765\u6e90"];
for (const sheetName of sheetNames) {
  const preview = await workbook.render({ sheetName, autoCrop: "all", scale: 1, format: "png" });
  const previewBytes = new Uint8Array(await preview.arrayBuffer());
  await fs.writeFile(path.join(qaDir, `${sheetName}.png`), previewBytes);
}

const overview = await workbook.inspect({
  kind: "workbook,sheet,table",
  maxChars: 6000,
  tableMaxRows: 8,
  tableMaxCols: 16,
  tableMaxCellChars: 100,
});
const summaryInspection = await workbook.inspect({
  kind: "region",
  sheetId: "\u4e3b\u8981\u7ed3\u679c",
  range: "A1:O6",
  maxChars: 5000,
});
const formulaErrors = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 100 },
  maxChars: 3000,
});

await fs.writeFile(
  `${root}/08_\u6269\u5c55\u56fe\u8868_PLOS_Frontiers\u540c\u578b/QA/workbook_inspection.ndjson`,
  `${overview.ndjson}\n${summaryInspection.ndjson}\n${formulaErrors.ndjson}\n`,
  "utf8",
);

const xlsx = await SpreadsheetFile.exportXlsx(workbook);
await xlsx.save(outputPath);
console.log(JSON.stringify({ outputPath, sheetNames, formulaErrorScan: formulaErrors.ndjson }, null, 2));
