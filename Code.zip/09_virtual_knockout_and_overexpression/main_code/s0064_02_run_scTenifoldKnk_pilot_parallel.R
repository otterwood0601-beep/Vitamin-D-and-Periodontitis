options(stringsAsFactors = FALSE, warn = 1, future.globals.maxSize = 8 * 1024^3)

local_lib <- Sys.getenv("VITDKO_R_LIB", unset = "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_enrichment")
.libPaths(c(local_lib, .libPaths()))

suppressPackageStartupMessages({
  library(Matrix)
  library(scTenifoldKnk)
  library(scTenifoldNet)
  library(parallel)
})

out_root <- Sys.getenv("VITDKO_OUT_ROOT", unset = "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260821_GDF15\u865a\u62df\u6572\u9664_scTenifoldKnk_\u9996\u7248")
input_file <- file.path(
  out_root, "01_input_qc",
  "network_input_log1p_CP10K_1500HVG_plus_GDF15.rds"
)
dir.create(file.path(out_root, "02_virtual_ko"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(out_root, "06_qa"), recursive = TRUE, showWarnings = FALSE)

log_file <- file.path(out_root, "06_qa", "02_scTenifoldKnk_pilot_parallel_run.log")
sink(log_file, split = TRUE)
on.exit(sink(), add = TRUE)

stopifnot(file.exists(input_file))
network_input_all <- readRDS(input_file)
stopifnot(inherits(network_input_all, "dgCMatrix"))
stopifnot("GDF15" %in% rownames(network_input_all))
stopifnot(nrow(network_input_all) == 1501L, ncol(network_input_all) == 14188L)

pilot_hvg_n <- 1000L
hvg_rows <- setdiff(rownames(network_input_all), "GDF15")
network_input <- rbind(
  network_input_all[head(hvg_rows, pilot_hvg_n), , drop = FALSE],
  network_input_all["GDF15", , drop = FALSE]
)
network_input <- as(network_input, "dgCMatrix")
rm(network_input_all)
invisible(gc())

stopifnot(nrow(network_input) == 1001L, ncol(network_input) == 14188L)
stopifnot(all(is.finite(network_input@x)), all(network_input@x >= 0))
stopifnot(Matrix::nnzero(network_input["GDF15", ]) > 0)

run_parameters <- list(
  target = "GDF15",
  pilot_hvg_n = pilot_hvg_n,
  network_gene_nodes = nrow(network_input),
  random_seed = 20260821L,
  RNG_kind = "L'Ecuyer-CMRG with one deterministic stream per subnetwork",
  execution_strategy = "outer-network PSOCK parallelization; official algorithms unchanged",
  qc = FALSE,
  nc_lambda = 0,
  nc_nNet = 10L,
  nc_nCells = 500L,
  nc_nComp = 3L,
  nc_scaleScores = TRUE,
  nc_symmetric = FALSE,
  nc_q = 0.90,
  td_K = 3L,
  td_maxIter = 1000L,
  td_maxError = 1e-5,
  td_nDecimal = 3L,
  ma_nDim = 2L,
  nCores = 8L
)

started_at <- Sys.time()
cat("Started parallel pilot:", format(started_at, "%Y-%m-%d %H:%M:%S %z"), "\n")
cat("Input:", nrow(network_input), "genes x", ncol(network_input), "cells\n")
cat("Target GDF15 nonzero cells:", Matrix::nnzero(network_input["GDF15", ]), "\n")
print(run_parameters)

RNGkind("L'Ecuyer-CMRG")
set.seed(run_parameters$random_seed)
network_seeds <- vector("list", run_parameters$nc_nNet)
network_seeds[[1L]] <- .Random.seed
if (run_parameters$nc_nNet > 1L) {
  for (i in 2:run_parameters$nc_nNet) {
    network_seeds[[i]] <- parallel::nextRNGStream(network_seeds[[i - 1L]])
  }
}

workers <- min(run_parameters$nCores, run_parameters$nc_nNet)
cluster <- parallel::makePSOCKcluster(workers, outfile = "")
on.exit(try(parallel::stopCluster(cluster), silent = TRUE), add = TRUE)
parallel::clusterExport(
  cluster,
  varlist = c("network_input", "network_seeds", "run_parameters", "local_lib"),
  envir = environment()
)
parallel::clusterEvalQ(cluster, {
  .libPaths(c(local_lib, .libPaths()))
  suppressPackageStartupMessages(library(Matrix))
  suppressPackageStartupMessages(library(scTenifoldNet))
  NULL
})

network_started <- Sys.time()
network_checkpoint <- file.path(
  out_root, "02_virtual_ko",
  "checkpoint_network_list_1000HVG_10nets.rds"
)
if (file.exists(network_checkpoint)) {
  cat("Loading existing network checkpoint:", network_checkpoint, "\n")
  WT_list <- readRDS(network_checkpoint)
} else {
  cat("Constructing", run_parameters$nc_nNet, "networks on", workers, "workers\n")
  WT_list <- parallel::parLapply(
    cluster,
    seq_len(run_parameters$nc_nNet),
    function(i) {
      assign(".Random.seed", network_seeds[[i]], envir = .GlobalEnv)
      scTenifoldNet::makeNetworks(
        X = network_input,
        q = run_parameters$nc_q,
        nNet = 1L,
        nCells = run_parameters$nc_nCells,
        scaleScores = run_parameters$nc_scaleScores,
        symmetric = run_parameters$nc_symmetric,
        nComp = run_parameters$nc_nComp,
        nCores = 1L,
        label = paste0("parallel-network-", i)
      )[[1L]]
    }
  )
  saveRDS(WT_list, network_checkpoint, compress = "gzip")
  cat("Saved network checkpoint:", network_checkpoint, "\n")
}
parallel::stopCluster(cluster)
cluster <- NULL
cat(sprintf(
  "Network construction complete in %.3f minutes\n",
  as.numeric(difftime(Sys.time(), network_started, units = "mins"))
))

tensor_started <- Sys.time()
tensor_checkpoint <- file.path(
  out_root, "02_virtual_ko",
  "checkpoint_tensor_result_1000HVG_10nets_K3.rds"
)
if (file.exists(tensor_checkpoint)) {
  cat("Loading existing tensor checkpoint:", tensor_checkpoint, "\n")
  tensor_result <- readRDS(tensor_checkpoint)
} else {
  tensor_result <- scTenifoldNet::tensorDecomposition(
    xList = WT_list,
    K = run_parameters$td_K,
    maxError = run_parameters$td_maxError,
    maxIter = run_parameters$td_maxIter,
    nDecimal = run_parameters$td_nDecimal
  )
  saveRDS(tensor_result, tensor_checkpoint, compress = "gzip")
  cat("Saved tensor checkpoint:", tensor_checkpoint, "\n")
}
cat(sprintf(
  "Tensor decomposition complete in %.3f minutes\n",
  as.numeric(difftime(Sys.time(), tensor_started, units = "mins"))
))

WT <- tensor_result$X
strict_direction <- getFromNamespace("strictDirection", "scTenifoldKnk")
manifold_alignment <- getFromNamespace("manifoldAlignment", "scTenifoldNet")
d_regulation <- getFromNamespace("dRegulation", "scTenifoldKnk")

WT <- strict_direction(WT, lambda = run_parameters$nc_lambda)
WT <- as.matrix(WT)
diag(WT) <- 0
WT <- t(WT)
KO <- WT
KO[run_parameters$target, ] <- 0

MA <- manifold_alignment(
  WT,
  KO,
  d = run_parameters$ma_nDim,
  nCores = run_parameters$nCores
)
DR <- d_regulation(MA, run_parameters$target)

result <- list(
  tensorNetworks = list(WT = Matrix::Matrix(WT), KO = Matrix::Matrix(KO)),
  manifoldAlignment = MA,
  diffRegulation = DR,
  execution = list(
    strategy = run_parameters$execution_strategy,
    network_seeds = network_seeds,
    tensor_metadata = tensor_result[setdiff(names(tensor_result), "X")]
  )
)

finished_at <- Sys.time()
runtime_minutes <- as.numeric(difftime(finished_at, started_at, units = "mins"))
cat("Finished parallel pilot:", format(finished_at, "%Y-%m-%d %H:%M:%S %z"), "\n")
cat(sprintf("Runtime: %.3f minutes\n", runtime_minutes))

stopifnot(all(result$tensorNetworks$KO["GDF15", ] == 0))
saveRDS(
  result,
  file.path(out_root, "02_virtual_ko", "scTenifoldKnk_GDF15_full_result.rds"),
  compress = "gzip"
)

diff_reg <- as.data.frame(result$diffRegulation, stringsAsFactors = FALSE)
expected_columns <- c("gene", "distance", "Z", "FC", "p.value", "p.adj")
stopifnot(all(expected_columns %in% colnames(diff_reg)))
diff_reg <- diff_reg[order(diff_reg$p.adj, -diff_reg$FC, diff_reg$gene), , drop = FALSE]
diff_reg$rank_by_FDR_then_FC <- seq_len(nrow(diff_reg))
diff_reg$FDR_lt_0_05 <- diff_reg$p.adj < 0.05
diff_reg$log10_FC_plus_1 <- log10(diff_reg$FC + 1)
write.csv(
  diff_reg,
  file.path(out_root, "02_virtual_ko", "GDF15_differential_regulation_all_genes.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

run_manifest <- data.frame(
  metric = c(
    "started_at", "finished_at", "runtime_minutes", "R_version",
    "scTenifoldKnk_version", "scTenifoldNet_version", "execution_strategy",
    "prepared_HVGs", "pilot_HVGs", "input_genes", "input_cells",
    "target_nonzero_cells", "result_genes", "FDR_lt_0_05_genes",
    "WT_network_nonzero_edges", "KO_network_nonzero_edges"
  ),
  value = c(
    format(started_at, "%Y-%m-%d %H:%M:%S %z"),
    format(finished_at, "%Y-%m-%d %H:%M:%S %z"),
    sprintf("%.6f", runtime_minutes),
    R.version.string,
    as.character(packageVersion("scTenifoldKnk")),
    as.character(packageVersion("scTenifoldNet")),
    run_parameters$execution_strategy,
    1500L, pilot_hvg_n, nrow(network_input), ncol(network_input),
    Matrix::nnzero(network_input["GDF15", ]),
    nrow(diff_reg), sum(diff_reg$FDR_lt_0_05, na.rm = TRUE),
    Matrix::nnzero(result$tensorNetworks$WT),
    Matrix::nnzero(result$tensorNetworks$KO)
  ),
  stringsAsFactors = FALSE
)
write.csv(
  run_manifest,
  file.path(out_root, "02_virtual_ko", "run_manifest.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)
saveRDS(
  list(parameters = run_parameters, manifest = run_manifest),
  file.path(out_root, "02_virtual_ko", "run_parameters_and_manifest.rds")
)
writeLines(
  capture.output(sessionInfo()),
  file.path(out_root, "06_qa", "R_sessionInfo.txt"),
  useBytes = TRUE
)

rm(network_input, WT_list, WT, KO, MA, DR)
invisible(gc())
