from pathlib import Path
from PIL import Image, ImageDraw, ImageOps
preview_dir = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\_\u4e34\u65f6\u8fd0\u884c\u533a\\gdf15_vko_workbook_build\\previews')
files = sorted((path for path in preview_dir.glob('*.png') if path.name != '_contact_sheet.png'))
cell_width, cell_height = (620, 500)
columns = 3
rows = (len(files) + columns - 1) // columns
canvas = Image.new('RGB', (cell_width * columns, cell_height * rows), 'white')
draw = ImageDraw.Draw(canvas)
for index, image_path in enumerate(files):
    with Image.open(image_path) as source:
        thumbnail = ImageOps.contain(source.convert('RGB'), (cell_width - 20, cell_height - 50))
    x0 = index % columns * cell_width
    y0 = index // columns * cell_height
    draw.text((x0 + 10, y0 + 10), image_path.stem, fill='black')
    canvas.paste(thumbnail, (x0 + (cell_width - thumbnail.width) // 2, y0 + 35))
output = preview_dir / '_contact_sheet.png'
canvas.save(output)
print(output)
