from __future__ import annotations
import argparse
import json
import math
import pickle
import sys
import time
from collections import Counter
from pathlib import Path
import anndata as ad
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from scipy import stats
ROOT = Path('/work')
DATA_ROOT = Path('/data')
CODE_DIR = ROOT / 'code'
sys.path.insert(0, str(CODE_DIR))
from geneformer_core import ECM_PRIORITY, GDF15_TOKEN_ID, MAPK_PRIORITY, MAX_LENGTH, MODEL_DIR, SEED, batch_embeddings, bh_fdr, embed_variable_sequences, load_classifier, set_deterministic, state_shift, stratified_sample_indices
from run_geneformer_pipeline import load_token_reference, load_tokenized
OUT = ROOT / '10_\u539f\u6587Figure5-6\u4e0eExtendedData9-10\u65b0\u589e\u5e72\u5b9e\u9a8c_v1'
TABLE_OUT = OUT / '\u6570\u636e\u8868'
QA_OUT = OUT / 'QA'
H5AD_PATH = DATA_ROOT / '\u539f\u59cb\u6570\u636e/05_\u5355\u7ec6\u80deRNA/01_scRNA-seq/CELLxGENE_Integrated_Periodontitis_Atlas/processed/Integrated_Human_Periodontitis_Atlas_105918cells.h5ad'
COHORTS = ['Williams', 'Caetano']
TOKENS = {'GDF15': 6248, 'MAPK1': 2163, 'MAPK3': 2711}
COMBINATIONS: dict[str, tuple[int, ...]] = {'GDF15': (TOKENS['GDF15'],), 'MAPK1': (TOKENS['MAPK1'],), 'MAPK3': (TOKENS['MAPK3'],), 'GDF15+MAPK1': (TOKENS['GDF15'], TOKENS['MAPK1']), 'GDF15+MAPK3': (TOKENS['GDF15'], TOKENS['MAPK3']), 'MAPK1+MAPK3': (TOKENS['MAPK1'], TOKENS['MAPK3']), 'GDF15+MAPK1+MAPK3': (TOKENS['GDF15'], TOKENS['MAPK1'], TOKENS['MAPK3'])}
HOUSEKEEPING = {'ACTB', 'GAPDH', 'B2M', 'HPRT1', 'PPIA', 'RPL3', 'RPL4', 'RPL5', 'RPL7', 'RPL8', 'RPL9', 'RPL10', 'RPL11', 'RPL13', 'RPL18', 'RPS3', 'RPS4X', 'RPS5', 'RPS6', 'RPS8', 'RPS9', 'RPS11', 'RPS14', 'RPS18', 'RPS19', 'RPS27A', 'EEF1A1', 'TUBB', 'UBC'}

def ensure_dirs() -> None:
    TABLE_OUT.mkdir(parents=True, exist_ok=True)
    QA_OUT.mkdir(parents=True, exist_ok=True)

def write_json(path: Path, payload: dict | list) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')

def activate_tokens(sequence: np.ndarray, tokens: tuple[int, ...]) -> np.ndarray:
    token_set = set((int(x) for x in tokens))
    remaining = np.asarray([int(x) for x in sequence if int(x) not in token_set], dtype=np.int64)
    return np.concatenate([np.asarray(tokens, dtype=np.int64), remaining])[:MAX_LENGTH]

def activate_at_rank(sequence: np.ndarray, token: int, rank: int) -> np.ndarray:
    remaining = sequence[sequence != int(token)].astype(np.int64)
    insert_at = min(max(int(rank) - 1, 0), len(remaining))
    changed = np.insert(remaining, insert_at, int(token)).astype(np.int64)
    return changed[:MAX_LENGTH]

def paired_cosine_distance(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    ta = torch.as_tensor(a, dtype=torch.float32)
    tb = torch.as_tensor(b, dtype=torch.float32)
    return (1.0 - F.cosine_similarity(ta, tb, dim=-1)).cpu().numpy()

def encode_hidden(model, sequences: list[np.ndarray]) -> list[np.ndarray]:
    max_len = max((len(x) for x in sequences))
    ids = torch.zeros((len(sequences), max_len), dtype=torch.long)
    mask = torch.zeros_like(ids)
    for i, sequence in enumerate(sequences):
        ids[i, :len(sequence)] = torch.as_tensor(sequence, dtype=torch.long)
        mask[i, :len(sequence)] = 1
    with torch.inference_mode():
        hidden = model.bert(input_ids=ids, attention_mask=mask, return_dict=True).last_hidden_state.cpu().numpy()
    return [hidden[i, :len(sequence), :].astype(np.float32) for i, sequence in enumerate(sequences)]

def condition_target_effects(original_sequence: np.ndarray, changed_sequence: np.ndarray, original_hidden: np.ndarray, changed_hidden: np.ndarray, target_tokens: dict[int, str], excluded_tokens: set[int]) -> list[tuple[int, str, float]]:
    original_positions = {int(token): i for i, token in enumerate(original_sequence.tolist())}
    changed_positions = {int(token): i for i, token in enumerate(changed_sequence.tolist())}
    records: list[tuple[int, str, float]] = []
    for token, group in target_tokens.items():
        if token in excluded_tokens or token not in original_positions or token not in changed_positions:
            continue
        shift = paired_cosine_distance(original_hidden[original_positions[token]][None, :], changed_hidden[changed_positions[token]][None, :])[0]
        records.append((int(token), group, float(shift)))
    return records

def run_combination_activation() -> None:
    ensure_dirs()
    set_deterministic()
    _, token_to_gene, token_to_ensembl = load_token_reference()
    target_tokens: dict[int, str] = {}
    for token, gene in token_to_gene.items():
        if gene in ECM_PRIORITY:
            target_tokens[int(token)] = 'ECM-remodeling targets'
        elif gene in HOUSEKEEPING:
            target_tokens[int(token)] = 'Housekeeping controls'
    all_cell_records: list[dict] = []
    all_target_records: list[dict] = []
    manifests: list[dict] = []
    out_dir = TABLE_OUT / '02_GDF15_MAPK\u7ec4\u5408\u6fc0\u6d3b'
    out_dir.mkdir(parents=True, exist_ok=True)
    for cohort in COHORTS:
        started = time.time()
        input_ids, lengths, labels, metadata = load_tokenized(cohort)
        disease_meta = metadata.loc[metadata['label'] == 1]
        indices = stratified_sample_indices(disease_meta, min(64, len(disease_meta)), ['donor_id'], SEED + 701)
        pd.DataFrame({'dataset_index': indices}).merge(metadata[['dataset_index', 'cell_id', 'donor_id', 'disease']].reset_index(drop=True), on='dataset_index', how='left').to_csv(out_dir / f'{cohort}_combination_screen_cells.csv', index=False, encoding='utf-8-sig')
        model = load_classifier(ROOT / '02_\u72b6\u6001\u5206\u7c7b\u5668' / cohort / 'best_model')
        centroids = np.load(ROOT / '02_\u72b6\u6001\u5206\u7c7b\u5668' / cohort / 'state_centroids.npz')
        checkpoint_path = out_dir / f'{cohort}_combination_checkpoint.pkl'
        if checkpoint_path.exists():
            with checkpoint_path.open('rb') as handle:
                checkpoint = pickle.load(handle)
            if checkpoint.get('indices') == indices.tolist():
                cell_records = checkpoint.get('cell_records', [])
                target_records = checkpoint.get('target_records', [])
                completed = set(checkpoint.get('completed', []))
            else:
                cell_records, target_records, completed = ([], [], set())
        else:
            cell_records, target_records, completed = ([], [], set())
        for counter, idx in enumerate(indices, start=1):
            idx = int(idx)
            if idx in completed:
                continue
            length = int(lengths[idx])
            original_sequence = input_ids[idx, :length].astype(np.int64)
            condition_names = list(COMBINATIONS)
            changed_sequences = [activate_tokens(original_sequence, COMBINATIONS[name]) for name in condition_names]
            hidden_states = encode_hidden(model, [original_sequence] + changed_sequences)
            original_hidden = hidden_states[0]
            original_embedding = original_hidden.mean(axis=0, keepdims=True)
            changed_embeddings = np.vstack([x.mean(axis=0) for x in hidden_states[1:]])
            original_repeated = np.repeat(original_embedding, len(changed_embeddings), axis=0)
            shift_goal, shift_start = state_shift(original_repeated, changed_embeddings, centroids['normal'], centroids['periodontitis'])
            cell_meta = metadata.loc[idx]
            for j, name in enumerate(condition_names):
                excluded = set(COMBINATIONS[name])
                effects = condition_target_effects(original_sequence, changed_sequences[j], original_hidden, hidden_states[j + 1], target_tokens, excluded)
                ecm_values = [v for _, group, v in effects if group == 'ECM-remodeling targets']
                hk_values = [v for _, group, v in effects if group == 'Housekeeping controls']
                cosine_shift = paired_cosine_distance(original_embedding, changed_embeddings[j][None, :])[0]
                cell_records.append({'cohort': cohort, 'dataset_index': idx, 'cell_id': cell_meta['cell_id'], 'donor_id': cell_meta['donor_id'], 'disease': cell_meta['disease'], 'condition': name, 'n_activated_genes': len(COMBINATIONS[name]), 'Shift_to_Healthy': float(shift_goal[j]), 'Shift_away_Periodontitis': float(shift_start[j]), 'Desirability_score': float(shift_goal[j] - shift_start[j]), 'Cell_cosine_shift': float(cosine_shift), 'N_ECM_targets': len(ecm_values), 'Mean_ECM_target_shift': float(np.mean(ecm_values)) if ecm_values else np.nan, 'N_housekeeping': len(hk_values), 'Mean_housekeeping_shift': float(np.mean(hk_values)) if hk_values else np.nan})
                for token, group, value in effects:
                    target_records.append({'cohort': cohort, 'dataset_index': idx, 'cell_id': cell_meta['cell_id'], 'donor_id': cell_meta['donor_id'], 'condition': name, 'target_group': group, 'Gene': token, 'Gene_name': token_to_gene.get(token, str(token)), 'Ensembl_ID': token_to_ensembl.get(token, ''), 'Token_cosine_shift': value})
            completed.add(idx)
            if counter % 4 == 0 or counter == len(indices):
                with checkpoint_path.open('wb') as handle:
                    pickle.dump({'indices': indices.tolist(), 'completed': sorted(completed), 'cell_records': cell_records, 'target_records': target_records}, handle)
                print(f'[{cohort}] combination activation {len(completed)}/{len(indices)}', flush=True)
        all_cell_records.extend(cell_records)
        all_target_records.extend(target_records)
        manifests.append({'cohort': cohort, 'input_state': 'Periodontitis fibroblasts', 'target_state': 'Healthy fibroblasts', 'cells': int(len(indices)), 'conditions': list(COMBINATIONS), 'operation': 'move/insert activated genes to the front of the rank-value encoding', 'elapsed_minutes': (time.time() - started) / 60.0})
        del model
    pd.DataFrame(all_cell_records).to_csv(out_dir / 'GDF15_MAPK_combination_activation_cell_level.csv.gz', index=False, compression='gzip', encoding='utf-8-sig')
    pd.DataFrame(all_target_records).to_csv(out_dir / 'GDF15_MAPK_combination_target_gene_cell_level.csv.gz', index=False, compression='gzip', encoding='utf-8-sig')
    write_json(out_dir / 'combination_activation_manifest.json', manifests)

def run_gdf15_rank_dose() -> None:
    ensure_dirs()
    set_deterministic()
    ranks = [1, 10, 25, 50, 100]
    out_dir = TABLE_OUT / '05_GDF15\u8fc7\u8868\u8fbeRank\u5242\u91cf\u626b\u63cf'
    out_dir.mkdir(parents=True, exist_ok=True)
    records: list[dict] = []
    manifests: list[dict] = []
    for cohort in COHORTS:
        started = time.time()
        input_ids, lengths, labels, metadata = load_tokenized(cohort)
        healthy_meta = metadata.loc[metadata['label'] == 0]
        indices = stratified_sample_indices(healthy_meta, min(64, len(healthy_meta)), ['donor_id'], SEED + 801)
        model = load_classifier(ROOT / '02_\u72b6\u6001\u5206\u7c7b\u5668' / cohort / 'best_model')
        centroids = np.load(ROOT / '02_\u72b6\u6001\u5206\u7c7b\u5668' / cohort / 'state_centroids.npz')
        original_embeddings = batch_embeddings(model, input_ids, lengths, indices, batch_size=8)
        for counter, (idx, original_embedding) in enumerate(zip(indices, original_embeddings), start=1):
            idx = int(idx)
            length = int(lengths[idx])
            sequence = input_ids[idx, :length].astype(np.int64)
            original_positions = np.flatnonzero(sequence == GDF15_TOKEN_ID)
            original_rank = int(original_positions[0] + 1) if len(original_positions) else np.nan
            changed = [activate_at_rank(sequence, GDF15_TOKEN_ID, rank) for rank in ranks]
            changed_embeddings = embed_variable_sequences(model, changed, batch_size=5)
            original = np.repeat(original_embedding[None, :], len(ranks), axis=0)
            x, y = state_shift(original, changed_embeddings, centroids['periodontitis'], centroids['normal'])
            cosine = paired_cosine_distance(original, changed_embeddings)
            cell_meta = metadata.loc[idx]
            for rank, xv, yv, cv in zip(ranks, x, y, cosine):
                records.append({'cohort': cohort, 'dataset_index': idx, 'cell_id': cell_meta['cell_id'], 'donor_id': cell_meta['donor_id'], 'disease': cell_meta['disease'], 'Original_GDF15_rank': original_rank, 'Perturbed_GDF15_rank': rank, 'Shift_to_Periodontitis': float(xv), 'Shift_away_Healthy': float(yv), 'Desirability_score': float(xv - yv), 'Cell_cosine_shift': float(cv)})
            if counter % 16 == 0 or counter == len(indices):
                print(f'[{cohort}] GDF15 rank-dose {counter}/{len(indices)}', flush=True)
        manifests.append({'cohort': cohort, 'input_state': 'Healthy fibroblasts', 'target_state': 'Periodontitis fibroblasts', 'cells': int(len(indices)), 'tested_ranks': ranks, 'elapsed_minutes': (time.time() - started) / 60.0})
        del model
    pd.DataFrame(records).to_csv(out_dir / 'GDF15_rank_dose_cell_level.csv.gz', index=False, compression='gzip', encoding='utf-8-sig')
    write_json(out_dir / 'GDF15_rank_dose_manifest.json', manifests)

def predict_probabilities(model, input_ids, lengths, indices: np.ndarray, batch_size: int=8) -> np.ndarray:
    probabilities: list[np.ndarray] = []
    model.eval()
    with torch.inference_mode():
        for start in range(0, len(indices), batch_size):
            batch_indices = indices[start:start + batch_size].astype(int)
            batch_lengths = lengths[batch_indices].astype(int)
            max_len = int(batch_lengths.max())
            ids = torch.as_tensor(input_ids[batch_indices, :max_len], dtype=torch.long)
            positions = torch.arange(max_len).unsqueeze(0)
            mask = (positions < torch.as_tensor(batch_lengths).unsqueeze(1)).long()
            logits = model(input_ids=ids, attention_mask=mask, return_dict=True).logits
            probabilities.append(torch.softmax(logits, dim=1)[:, 1].cpu().numpy())
            if (start // batch_size + 1) % 20 == 0:
                print(f'cross-cohort inference {min(start + batch_size, len(indices))}/{len(indices)}', flush=True)
    return np.concatenate(probabilities)

def balanced_indices(metadata: pd.DataFrame, per_class: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    selected: list[int] = []
    for label in [0, 1]:
        group = metadata.loc[metadata['label'] == label]
        take = min(per_class, len(group))
        picked = stratified_sample_indices(group, take, ['donor_id'], seed + label)
        selected.extend(picked.tolist())
    selected = np.asarray(selected, dtype=int)
    rng.shuffle(selected)
    return selected

def run_cross_cohort_validation() -> None:
    ensure_dirs()
    set_deterministic()
    out_dir = TABLE_OUT / '03_\u4f9b\u4f53\u4e0e\u8de8\u961f\u5217\u7a33\u5065\u6027'
    out_dir.mkdir(parents=True, exist_ok=True)
    records: list[pd.DataFrame] = []
    manifest: list[dict] = []
    tasks = [('Williams', 'Caetano', None), ('Caetano', 'Williams', 345)]
    for model_cohort, test_cohort, per_class in tasks:
        started = time.time()
        input_ids, lengths, labels, metadata = load_tokenized(test_cohort)
        if per_class is None:
            indices = metadata.index.to_numpy(dtype=int)
        else:
            indices = balanced_indices(metadata, per_class, SEED + 901)
        model = load_classifier(ROOT / '02_\u72b6\u6001\u5206\u7c7b\u5668' / model_cohort / 'best_model')
        probs = predict_probabilities(model, input_ids, lengths, indices, batch_size=8)
        frame = metadata.loc[indices, ['dataset_index', 'cell_id', 'donor_id', 'disease', 'label']].copy().reset_index(drop=True)
        frame.insert(0, 'model_cohort', model_cohort)
        frame.insert(1, 'test_cohort', test_cohort)
        frame['periodontitis_probability'] = probs
        frame['predicted_label'] = (probs >= 0.5).astype(int)
        records.append(frame)
        manifest.append({'model_cohort': model_cohort, 'test_cohort': test_cohort, 'n_test': int(len(frame)), 'healthy': int((frame['label'] == 0).sum()), 'periodontitis': int((frame['label'] == 1).sum()), 'elapsed_minutes': (time.time() - started) / 60.0})
        del model
    pd.concat(records, ignore_index=True).to_csv(out_dir / 'cross_cohort_predictions.csv.gz', index=False, compression='gzip', encoding='utf-8-sig')
    write_json(out_dir / 'cross_cohort_manifest.json', manifest)

def run_attention_analysis() -> None:
    ensure_dirs()
    set_deterministic()
    out_dir = TABLE_OUT / '10_\u6ce8\u610f\u529b\u4e0e\u7f51\u7edc\u5c42\u7ea7'
    out_dir.mkdir(parents=True, exist_ok=True)
    input_ids, lengths, labels, metadata = load_tokenized('Williams')
    candidates = metadata.loc[(metadata['label'] == 1) & metadata['GDF15_token_present'].astype(bool) & (metadata['GDF15_token_rank'] <= 512) & (metadata['geneformer_length'] >= 512)].sort_values(['donor_id', 'GDF15_token_rank'])
    indices = candidates.index.to_numpy(dtype=int)
    _, token_to_gene, token_to_ensembl = load_token_reference()
    model = load_classifier(MODEL_DIR)
    model.config.output_attentions = True
    if hasattr(model.config, '_attn_implementation'):
        model.config._attn_implementation = 'eager'
    model.eval()
    records: list[dict] = []
    started = time.time()
    with torch.inference_mode():
        for counter, idx in enumerate(indices, start=1):
            sequence = input_ids[int(idx), :512].astype(np.int64)
            ids = torch.as_tensor(sequence, dtype=torch.long).unsqueeze(0)
            mask = torch.ones_like(ids)
            outputs = model.bert(input_ids=ids, attention_mask=mask, output_attentions=True, return_dict=True)
            attention = torch.stack(outputs.attentions).cpu().numpy()[:, 0, :, :, :]
            received = attention.mean(axis=2)
            cell_meta = metadata.loc[int(idx)]
            for layer in range(received.shape[0]):
                for head in range(received.shape[1]):
                    values = received[layer, head]
                    order = stats.rankdata(values, method='average') / len(values)
                    for position, token in enumerate(sequence.tolist()):
                        gene = token_to_gene.get(int(token), str(token))
                        if gene == 'GDF15':
                            group = 'GDF15'
                        elif gene in MAPK_PRIORITY:
                            group = 'MAPK-response'
                        elif gene in ECM_PRIORITY:
                            group = 'ECM-remodeling'
                        else:
                            group = 'Other'
                        records.append({'dataset_index': int(idx), 'cell_id': cell_meta['cell_id'], 'donor_id': cell_meta['donor_id'], 'layer': layer + 1, 'head': head + 1, 'rank': position + 1, 'Gene': int(token), 'Gene_name': gene, 'Ensembl_ID': token_to_ensembl.get(int(token), ''), 'network_group': group, 'attention_received': float(values[position]), 'within_cell_attention_percentile': float(order[position])})
            print(f'attention cell {counter}/{len(indices)}', flush=True)
    pd.DataFrame(records).to_csv(out_dir / 'pretrained_attention_512token_cell_level.csv.gz', index=False, compression='gzip', encoding='utf-8-sig')
    write_json(out_dir / 'attention_manifest.json', {'cohort': 'Williams', 'state': 'Periodontitis fibroblasts with GDF15 within the first 512 tokens', 'n_cells': int(len(indices)), 'sequence_length': 512, 'model': 'Geneformer V1 pretrained model', 'metric': 'mean attention received across all query positions', 'elapsed_minutes': (time.time() - started) / 60.0})

def run_pseudobulk_de() -> None:
    ensure_dirs()
    out_dir = TABLE_OUT / '08_\u75be\u75c5\u5dee\u5f02\u8868\u8fbe\u91cd\u53e0'
    out_dir.mkdir(parents=True, exist_ok=True)
    _, _, _, metadata = load_tokenized('Williams')
    ordered = metadata.sort_values('h5ad_row_python').copy()
    h5ad_rows = ordered['h5ad_row_python'].astype(int).to_numpy()
    started = time.time()
    atlas = ad.read_h5ad(H5AD_PATH, backed='r')
    matrix = atlas.X[h5ad_rows, :]
    donors = ordered['donor_id'].astype(str).to_numpy()
    diseases = ordered['disease'].astype(str).to_numpy()
    donor_names = sorted(set(donors))
    donor_counts: list[np.ndarray] = []
    donor_rows: list[dict] = []
    for donor in donor_names:
        positions = np.flatnonzero(donors == donor)
        summed = np.asarray(matrix[positions, :].sum(axis=0)).ravel().astype(np.float64)
        donor_counts.append(summed)
        donor_rows.append({'donor_id': donor, 'disease': str(diseases[positions[0]]), 'n_cells': int(len(positions)), 'library_size': float(summed.sum())})
    counts = np.vstack(donor_counts)
    library = counts.sum(axis=1, keepdims=True)
    cpm = counts / np.maximum(library, 1.0) * 1000000.0
    log_cpm = np.log2(cpm + 1.0)
    donor_table = pd.DataFrame(donor_rows)
    disease_mask = donor_table['disease'].eq('periodontitis').to_numpy()
    healthy_mask = donor_table['disease'].eq('normal').to_numpy()
    test = stats.ttest_ind(log_cpm[disease_mask, :], log_cpm[healthy_mask, :], axis=0, equal_var=False, nan_policy='omit')
    pvalues = np.nan_to_num(test.pvalue, nan=1.0, posinf=1.0, neginf=1.0)
    log2fc = log_cpm[disease_mask, :].mean(axis=0) - log_cpm[healthy_mask, :].mean(axis=0)
    result = pd.DataFrame({'Ensembl_ID': atlas.var_names.astype(str), 'Gene_name': atlas.var['feature_name'].astype(str).to_numpy(), 'Mean_log2CPM_periodontitis': log_cpm[disease_mask, :].mean(axis=0), 'Mean_log2CPM_healthy': log_cpm[healthy_mask, :].mean(axis=0), 'log2FC_periodontitis_vs_healthy': log2fc, 'raw_p': pvalues, 'BH_FDR': bh_fdr(pvalues), 'N_donors_CPM_gt_1': (cpm > 1.0).sum(axis=0)})
    result['DE_FDR_0.05_abs_log2FC_0.25'] = (result['BH_FDR'] < 0.05) & (result['log2FC_periodontitis_vs_healthy'].abs() >= 0.25)
    result.sort_values(['BH_FDR', 'raw_p']).to_csv(out_dir / 'Williams_fibroblast_donor_pseudobulk_DE.csv.gz', index=False, compression='gzip', encoding='utf-8-sig')
    donor_table.to_csv(out_dir / 'Williams_pseudobulk_donor_manifest.csv', index=False, encoding='utf-8-sig')
    write_json(out_dir / 'pseudobulk_DE_manifest.json', {'cohort': 'Williams', 'cells': int(len(ordered)), 'healthy_donors': int(healthy_mask.sum()), 'periodontitis_donors': int(disease_mask.sum()), 'normalization': 'donor-summed raw counts; CPM; log2(CPM+1)', 'test': 'two-sided Welch t-test across donor log2(CPM+1)', 'DE_definition': 'BH-FDR < 0.05 and |log2FC| >= 0.25', 'elapsed_minutes': (time.time() - started) / 60.0})
    atlas.file.close()

def run_expanded_overexpression() -> None:
    ensure_dirs()
    set_deterministic()
    out_root = TABLE_OUT / '07_\u53cc\u5411\u6269\u5c55\u7b5b\u9009'
    out_root.mkdir(parents=True, exist_ok=True)
    reference, token_to_gene, token_to_ensembl = load_token_reference()
    del reference
    for cohort in COHORTS:
        started = time.time()
        cohort_out = out_root / cohort
        cohort_out.mkdir(parents=True, exist_ok=True)
        input_ids, lengths, labels, metadata = load_tokenized(cohort)
        model = load_classifier(ROOT / '02_\u72b6\u6001\u5206\u7c7b\u5668' / cohort / 'best_model')
        centroids = np.load(ROOT / '02_\u72b6\u6001\u5206\u7c7b\u5668' / cohort / 'state_centroids.npz')
        candidates = pd.read_csv(ROOT / '03_\u5168\u57fa\u56e0\u865a\u62df\u6572\u9664' / cohort / 'exact_delete_candidates.csv')
        tokens = list(dict.fromkeys(candidates['Gene'].astype(int).tolist()))
        if GDF15_TOKEN_ID not in tokens:
            tokens[-1] = GDF15_TOKEN_ID
        candidate_table = pd.DataFrame({'Gene': tokens, 'Gene_name': [token_to_gene.get(t, str(t)) for t in tokens], 'Ensembl_ID': [token_to_ensembl.get(t, '') for t in tokens]})
        candidate_table['Priority_class'] = np.where(candidate_table['Gene_name'].isin(MAPK_PRIORITY), 'MAPK-response', np.where(candidate_table['Gene_name'].isin(ECM_PRIORITY), 'ECM-remodeling', 'Other'))
        candidate_table.to_csv(cohort_out / 'expanded_OE_candidates_430.csv', index=False, encoding='utf-8-sig')
        healthy = metadata.loc[metadata['label'] == 0]
        indices = stratified_sample_indices(healthy, min(24, len(healthy)), ['donor_id'], SEED + 404)
        original_embeddings = batch_embeddings(model, input_ids, lengths, indices, batch_size=8)
        baseline_detection = Counter()
        for idx in indices:
            baseline_detection.update(set((int(x) for x in input_ids[int(idx), :int(lengths[int(idx)])])))
        checkpoint_path = cohort_out / 'expanded_OE_checkpoint.pkl'
        if checkpoint_path.exists():
            with checkpoint_path.open('rb') as handle:
                checkpoint = pickle.load(handle)
            if checkpoint.get('tokens') == tokens and checkpoint.get('indices') == indices.tolist():
                records = checkpoint.get('records', [])
                completed = set(checkpoint.get('completed', []))
            else:
                records, completed = ([], set())
        else:
            records, completed = ([], set())
        for counter, (idx, original_embedding) in enumerate(zip(indices, original_embeddings), start=1):
            idx = int(idx)
            if idx in completed:
                continue
            sequence = input_ids[idx, :int(lengths[idx])].astype(np.int64)
            changed = [activate_tokens(sequence, (token,)) for token in tokens]
            perturbed = embed_variable_sequences(model, changed, batch_size=16)
            original = np.repeat(original_embedding[None, :], len(tokens), axis=0)
            x, y = state_shift(original, perturbed, centroids['periodontitis'], centroids['normal'])
            cell_meta = metadata.loc[idx]
            for token, xv, yv in zip(tokens, x, y):
                records.append({'cohort': cohort, 'dataset_index': idx, 'cell_id': cell_meta['cell_id'], 'donor_id': cell_meta['donor_id'], 'disease': cell_meta['disease'], 'Gene': int(token), 'Shift_to_goal_end': float(xv), 'Shift_away_start_end': float(yv)})
            completed.add(idx)
            with checkpoint_path.open('wb') as handle:
                pickle.dump({'tokens': tokens, 'indices': indices.tolist(), 'completed': sorted(completed), 'records': records}, handle)
            print(f'[{cohort}] expanded OE {len(completed)}/{len(indices)}; {len(records)}', flush=True)
        cell_level = pd.DataFrame(records).merge(candidate_table, on='Gene', how='left')
        cell_level.to_csv(cohort_out / 'expanded_OE_cell_level.csv.gz', index=False, compression='gzip', encoding='utf-8-sig')
        pooled_x = cell_level['Shift_to_goal_end'].to_numpy(dtype=float)
        pooled_y = cell_level['Shift_away_start_end'].to_numpy(dtype=float)
        summaries: list[dict] = []
        for token, group in cell_level.groupby('Gene', sort=False):
            x = group['Shift_to_goal_end'].to_numpy(dtype=float)
            y = group['Shift_away_start_end'].to_numpy(dtype=float)
            summaries.append({'Gene': int(token), 'Gene_name': group['Gene_name'].iloc[0], 'Ensembl_ID': group['Ensembl_ID'].iloc[0], 'Priority_class': group['Priority_class'].iloc[0], 'N_Perturbed_cells': int(len(group)), 'N_Baseline_detected_cells': int(baseline_detection[int(token)]), 'Shift_to_goal_end': float(x.mean()), 'Shift_away_start_end': float(y.mean()), 'Goal_end_vs_random_pval': float(stats.ranksums(pooled_x, x).pvalue), 'Start_end_vs_random_pval': float(stats.ranksums(pooled_y, y).pvalue), 'Desirability_score': float((x - y).mean()), 'Desired_quadrant': bool(x.mean() > 0 and y.mean() < 0)})
        summary = pd.DataFrame(summaries)
        summary['Goal_end_FDR'] = bh_fdr(summary['Goal_end_vs_random_pval'])
        summary['Start_end_FDR'] = bh_fdr(summary['Start_end_vs_random_pval'])
        summary.sort_values(['Desired_quadrant', 'Desirability_score'], ascending=[False, False]).to_csv(cohort_out / 'expanded_OE_gene_summary.csv', index=False, encoding='utf-8-sig')
        write_json(cohort_out / 'expanded_OE_manifest.json', {'cohort': cohort, 'input_state': 'Healthy fibroblasts', 'target_state': 'Periodontitis fibroblasts', 'candidate_genes': int(len(tokens)), 'screen_cells': int(len(indices)), 'perturbations': int(len(cell_level)), 'elapsed_minutes': (time.time() - started) / 60.0})
        del model

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', choices=['combination', 'dose', 'cross', 'attention', 'de', 'expanded_oe', 'all'])
    args = parser.parse_args()
    ensure_dirs()
    stages = ['combination', 'dose', 'cross', 'attention', 'de', 'expanded_oe'] if args.stage == 'all' else [args.stage]
    functions = {'combination': run_combination_activation, 'dose': run_gdf15_rank_dose, 'cross': run_cross_cohort_validation, 'attention': run_attention_analysis, 'de': run_pseudobulk_de, 'expanded_oe': run_expanded_overexpression}
    for stage in stages:
        print(f'=== {stage} ===', flush=True)
        functions[stage]()
if __name__ == '__main__':
    main()
