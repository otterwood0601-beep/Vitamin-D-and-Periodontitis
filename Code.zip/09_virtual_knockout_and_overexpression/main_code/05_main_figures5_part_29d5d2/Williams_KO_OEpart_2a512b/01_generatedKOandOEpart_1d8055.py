from __future__ import annotations
import importlib.util
import json
import sys
from pathlib import Path
import pandas as pd
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260907_Geneformer_GDF15_Williams_ECM_KO\u4e0eOE\u7edf\u4e00\u5750\u6807\u8f74_v2')
SOURCE_SCRIPT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260907_Geneformer_GDF15_Williams_ECM\u5206\u72b6\u6001_\u6b63\u5f0f\u5750\u6807_\u539f\u59cb\u4e0e\u7ebf\u6027\u5e73\u6ed1_v1\\\u4ee3\u7801\\01_\u751f\u6210Williams_ECM\u5206\u72b6\u6001_\u6b63\u5f0f\u5750\u6807_\u539f\u59cb\u4e0e\u7ebf\u6027\u5e73\u6ed1.py')
OLD_FIG_DIR = SOURCE_SCRIPT.parents[1] / '\u56fe\u7247'
OLD_KO_RAW = OLD_FIG_DIR / '\u56fe2B_GDF15\u6572\u9664\u654f\u611f\u6027UMAP_Williams\u7259\u5468\u708e\u5168\u90e8ECM-remodeling\u7ec6\u80de_\u6b63\u5f0f\u5750\u6807_\u539f\u59cb\u503c.pdf'
OLD_KO_SMOOTHED = OLD_FIG_DIR / '\u56fe2B_GDF15\u6572\u9664\u654f\u611f\u6027UMAP_Williams\u7259\u5468\u708e\u5168\u90e8ECM-remodeling\u7ec6\u80de_\u6b63\u5f0f\u5750\u6807_\u90bb\u57df\u7ebf\u6027\u5e73\u6ed1\u5c55\u793a\u7248.pdf'
RAW_STEM = '\u56fe2B_GDF15\u6572\u9664\u654f\u611f\u6027UMAP_Williams\u7259\u5468\u708e\u5168\u90e8ECM-remodeling\u7ec6\u80de_\u4e0eOE\u5b8c\u5168\u76f8\u540c\u5750\u6807\u8f74_\u539f\u59cb\u503c'
SMOOTHED_STEM = '\u56fe2B_GDF15\u6572\u9664\u654f\u611f\u6027UMAP_Williams\u7259\u5468\u708e\u5168\u90e8ECM-remodeling\u7ec6\u80de_\u4e0eOE\u5b8c\u5168\u76f8\u540c\u5750\u6807\u8f74_\u90bb\u57df\u7ebf\u6027\u5e73\u6ed1\u5c55\u793a\u7248'

def load_plot_module():
    spec = importlib.util.spec_from_file_location('williams_ecm_plot_base', SOURCE_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError('Unable to load the source plotting script')
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module

def main() -> None:
    module = load_plot_module()
    old_hashes_before = {'KO_raw': module.sha256(OLD_KO_RAW), 'KO_smoothed': module.sha256(OLD_KO_SMOOTHED)}
    module.ROOT = ROOT
    module.FIG_DIR = ROOT / '\u56fe\u7247'
    module.TABLE_DIR = ROOT / '\u6570\u636e\u8868'
    module.QA_DIR = ROOT / 'QA'
    module.configure_style()
    periodontitis, healthy = module.load_and_validate()
    smoothed = module.make_linear_smoothed_ko(periodontitis)
    oe_xlim, oe_ylim = module.tight_limits(healthy)

    def oe_axis_limits(_frame: pd.DataFrame):
        return (oe_xlim, oe_ylim)
    module.tight_limits = oe_axis_limits
    panels = {'periodontitis_KO_raw_same_axes_as_OE': module.draw_single_panel(periodontitis, 'GDF15_KO_cosine_shift', 'GDF15_KO_cosine_shift', 'GDF15 knockout sensitivity', 'Reds', 'B', RAW_STEM), 'periodontitis_KO_smoothed_same_axes_as_OE': module.draw_single_panel(smoothed, 'GDF15_KO_cosine_shift_smoothed_display', 'GDF15_KO_cosine_shift', 'GDF15 knockout sensitivity', 'Reds', 'B', SMOOTHED_STEM)}
    for panel in panels.values():
        if panel['xlim'] != list(oe_xlim) or panel['ylim'] != list(oe_ylim):
            raise ValueError('KO axes do not exactly match the OE axes')
    module.TABLE_DIR.mkdir(parents=True, exist_ok=True)
    periodontitis.to_csv(module.TABLE_DIR / 'Williams\u7259\u5468\u708e552\u4e2aECM-remodeling\u7ec6\u80de_KO\u539f\u59cb\u503c.csv.gz', index=False, encoding='utf-8-sig', compression='gzip')
    smoothed.to_csv(module.TABLE_DIR / 'Williams\u7259\u5468\u708e552\u4e2aECM-remodeling\u7ec6\u80de_KO\u90bb\u57df\u7ebf\u6027\u5e73\u6ed1.csv.gz', index=False, encoding='utf-8-sig', compression='gzip')
    old_hashes_after = {'KO_raw': module.sha256(OLD_KO_RAW), 'KO_smoothed': module.sha256(OLD_KO_SMOOTHED)}
    if old_hashes_before != old_hashes_after:
        raise ValueError('An original KO PDF was modified')
    qa = {'status': 'PASS', 'request': 'Set both KO variants to exactly the same UMAP axes as the healthy OE panel without overwriting originals.', 'shared_axes': {'xlim': list(oe_xlim), 'ylim': list(oe_ylim), 'aspect': 'equal', 'tick_locator': 'MaxNLocator(nbins=6), identical to OE'}, 'input': {'population': 'Williams periodontitis ECM remodeling fibroblasts', 'cells': int(len(periodontitis)), 'exact_formal_coordinates': int(periodontitis['coordinate_source'].eq('exact_formal_PDF').sum())}, 'raw_KO_colored_cells': int(periodontitis['GDF15_KO_cosine_shift'].notna().sum()), 'smoothed_KO_colored_cells': int(smoothed['smoothed_display_colored'].sum()), 'smoothed_KO_colored_fraction': float(smoothed['smoothed_display_colored'].mean()), 'canvas_text_rule': 'Version descriptors occur only in filenames and QA; neither raw-value nor smoothing-version text is drawn on the canvas.', 'originals_unchanged': old_hashes_before == old_hashes_after, 'original_sha256': old_hashes_after, 'panels': panels}
    module.QA_DIR.mkdir(parents=True, exist_ok=True)
    (module.QA_DIR / 'KO\u4e0eOE\u7edf\u4e00\u5750\u6807\u8f74_\u5ba1\u8ba1.json').write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding='utf-8')
    (ROOT / 'README_\u8bf7\u5148\u770b.md').write_text('# KO \u4e0e OE \u7edf\u4e00\u5750\u6807\u8f74\u7248\u672c\n\n- \u4e24\u5f20 KO \u56fe\u7684 UMAP 1\u3001UMAP 2 \u8303\u56f4\u3001\u523b\u5ea6\u903b\u8f91\u3001\u7b49\u6bd4\u4f8b\u8bbe\u7f6e\u548c\u753b\u5e03\u8ba1\u7b97\u5747\u4e0e\u5065\u5eb7 OE \u56fe\u4e00\u81f4\u3002\n- \u539f\u59cb KO \u56fe\u548c\u5e73\u6ed1 KO \u56fe\u5747\u4e3a\u65b0\u6587\u4ef6\uff1b\u4e0a\u4e00\u76ee\u5f55\u4e2d\u7684\u539f\u56fe\u54c8\u5e0c\u524d\u540e\u4e00\u81f4\uff0c\u672a\u88ab\u8986\u76d6\u3002\n- \u6587\u4ef6\u540d\u4e2d\u7684\u539f\u59cb\u503c/\u90bb\u57df\u7ebf\u6027\u5e73\u6ed1\u5c55\u793a\u7248\u5b57\u6837\u672a\u653e\u5165\u56fe\u9762\u3002\n', encoding='utf-8')
    print(json.dumps(qa, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
