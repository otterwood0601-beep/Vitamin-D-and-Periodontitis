from __future__ import annotations
import importlib.util
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd
from matplotlib.ticker import FuncFormatter
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260908_Geneformer_GDF15_\u65b0\u56fe2\u6295\u7a3f\u7248_\u70b9\u5f84\u7edf\u4e00_\u53bbBC_v1')
BASE_SCRIPT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260907_Geneformer_GDF15_Williams_ECM\u5206\u72b6\u6001_\u6b63\u5f0f\u5750\u6807_\u539f\u59cb\u4e0e\u7ebf\u6027\u5e73\u6ed1_v1\\\u4ee3\u7801\\01_\u751f\u6210Williams_ECM\u5206\u72b6\u6001_\u6b63\u5f0f\u5750\u6807_\u539f\u59cb\u4e0e\u7ebf\u6027\u5e73\u6ed1.py')
PREVIOUS_DIR = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260907_Geneformer_GDF15_KO_OE_UMAP1\u53cc\u9608\u503c_\u53bb\u8868\u5934_v1\\\u56fe\u7247')
ARCHIVE_FIG_DIR = ROOT / '\u56fe\u7247' / '\u539f\u56fe\u8303\u56f4\u5b58\u6863'
SUBMISSION_FIG_DIR = ROOT / '\u56fe\u7247' / '\u65b0\u56fe2\u6295\u7a3f\u7248'
TABLE_DIR = ROOT / '\u6570\u636e\u8868'
QA_DIR = ROOT / 'QA'
SOURCE_PDFS = {key: PREVIOUS_DIR / f'{key}.pdf' for key in ('\u539f\u56fe_KO_\u539f\u59cb', '\u539f\u56fe_KO_\u5e73\u6ed1', '\u539f\u56fe_OE', '\u65b0\u56fe2_KO_\u539f\u59cb', '\u65b0\u56fe2_KO_\u5e73\u6ed1', '\u65b0\u56fe2_OE')}
POINT_SIZE = 3.8
ORIGINAL_XLIM = (-4.485280178207397, 6.833683480252695)
ORIGINAL_YLIM = (-4.8033357042048435, 4.012724355384307)
SUBMISSION_XLIM = (0.0, ORIGINAL_XLIM[1])

def load_base_module():
    spec = importlib.util.spec_from_file_location('williams_ecm_submission', BASE_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError('Unable to load the source plotting script')
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module

def select_in_axes(frame: pd.DataFrame, xlim: tuple[float, float], ylim: tuple[float, float]) -> pd.DataFrame:
    keep = frame['UMAP_1'].between(*xlim) & frame['UMAP_2'].between(*ylim)
    return frame.loc[keep].copy().reset_index(drop=True)

def draw_panel(base, output_dir: Path, frame: pd.DataFrame, value_column: str, raw_reference_column: str, cmap_name: str, xlim: tuple[float, float], ylim: tuple[float, float], vmax: float, gray_base: bool, stem: str) -> dict[str, object]:
    x = frame['UMAP_1'].to_numpy(float)
    y = frame['UMAP_2'].to_numpy(float)
    values = pd.to_numeric(frame[value_column], errors='coerce').to_numpy(float) * 1000.0
    raw_reference = pd.to_numeric(frame[raw_reference_column], errors='coerce').to_numpy(float) * 1000.0
    colored_mask = np.isfinite(values)
    data_ratio = (xlim[1] - xlim[0]) / (ylim[1] - ylim[0])
    figure_height = 5.1
    figure_width = min(7.0, max(4.15, 1.05 + 4.25 * data_ratio))
    fig, ax = base.plt.subplots(figsize=(figure_width, figure_height), layout='constrained')
    if gray_base:
        ax.scatter(x, y, s=POINT_SIZE, c='#DDDDDD', alpha=0.78, edgecolors='none', linewidths=0, zorder=1)
    order = np.flatnonzero(colored_mask)
    order = order[np.argsort(values[order], kind='stable')]
    cmap = base.truncated_colormap(cmap_name, low=0.1)
    norm = base.Normalize(vmin=0.0, vmax=vmax, clip=True)
    colored = ax.scatter(x[order], y[order], s=POINT_SIZE, c=values[order], cmap=cmap, norm=norm, alpha=0.95, edgecolors='none', linewidths=0, zorder=2)
    ax.set_xlim(*xlim)
    ax.set_ylim(*ylim)
    ax.set_aspect('equal', adjustable='box')
    ax.set_xlabel('UMAP 1')
    ax.set_ylabel('UMAP 2')
    ax.grid(False)
    ax.set_facecolor('white')
    ax.margins(0)
    ax.tick_params(direction='out', length=3.2, width=0.7, color='#222222')
    if np.isclose(xlim[0], 0.0):
        ax.set_xticks([0.0, 2.0, 4.0, 6.0])
        ax.xaxis.set_major_formatter(FuncFormatter(lambda value, _pos: f'{value:g}'))
    else:
        ax.xaxis.set_major_locator(base.MaxNLocator(nbins=6))
    ax.yaxis.set_major_locator(base.MaxNLocator(nbins=6))
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_color('#222222')
    ax.spines['bottom'].set_color('#222222')
    ax.spines['left'].set_linewidth(0.75)
    ax.spines['bottom'].set_linewidth(0.75)
    colorbar = fig.colorbar(colored, ax=ax, fraction=0.052, pad=0.025)
    if colorbar.solids is not None:
        colorbar.solids.remove()
    color_edges = np.linspace(0.0, vmax, 513)
    for lower, upper in zip(color_edges[:-1], color_edges[1:]):
        midpoint = 0.5 * (lower + upper)
        colorbar.ax.add_patch(base.Rectangle((0.0, lower), 1.0, upper - lower, facecolor=cmap(norm(midpoint)), edgecolor=cmap(norm(midpoint)), linewidth=0.0, zorder=0))
    colorbar.ax.set_title('Cosine shift\n(x10^3)', fontsize=9.0, pad=5)
    colorbar.ax.yaxis.set_major_locator(base.MaxNLocator(nbins=5))
    colorbar.ax.tick_params(labelsize=8, length=3, width=0.65)
    colorbar.outline.set_linewidth(0.65)
    output_dir.mkdir(parents=True, exist_ok=True)
    outputs: dict[str, str] = {}
    for suffix, kwargs in (('pdf', {}), ('svg', {}), ('png', {'dpi': 600})):
        output = output_dir / f'{stem}.{suffix}'
        fig.savefig(output, bbox_inches='tight', pad_inches=0.035, facecolor='white', **kwargs)
        outputs[suffix] = str(output)
    base.plt.close(fig)
    return {'plotted_cells': int(len(frame)), 'colored_cells': int(colored_mask.sum()), 'raw_observed_cells': int(np.isfinite(raw_reference).sum()), 'point_size_all_marks': POINT_SIZE, 'xlim': list(xlim), 'ylim': list(ylim), 'title_removed': True, 'panel_letter_removed': True, 'outputs': outputs}

def main() -> None:
    for directory in (ARCHIVE_FIG_DIR, SUBMISSION_FIG_DIR, TABLE_DIR, QA_DIR, QA_DIR / 'PDF\u6e32\u67d3\u68c0\u67e5'):
        directory.mkdir(parents=True, exist_ok=True)
    base = load_base_module()
    base.configure_style()
    source_hashes_before = {key: base.sha256(path) for key, path in SOURCE_PDFS.items()}
    periodontitis, healthy = base.load_and_validate()
    smoothed = base.make_linear_smoothed_ko(periodontitis)
    ko_raw_x1e3 = pd.to_numeric(periodontitis['GDF15_KO_cosine_shift'], errors='coerce').dropna().to_numpy(float) * 1000.0
    oe_x1e3 = pd.to_numeric(healthy['GDF15_OE_cosine_shift'], errors='coerce').dropna().to_numpy(float) * 1000.0
    ko_vmax = float(np.quantile(ko_raw_x1e3, 0.99))
    oe_vmax = float(np.quantile(oe_x1e3, 0.99))
    specs = {'\u539f\u56fe\u8303\u56f4\u5b58\u6863': (ARCHIVE_FIG_DIR, ORIGINAL_XLIM, ORIGINAL_YLIM), '\u65b0\u56fe2\u6295\u7a3f\u7248': (SUBMISSION_FIG_DIR, SUBMISSION_XLIM, ORIGINAL_YLIM)}
    results: dict[str, dict[str, object]] = {}
    count_rows: list[dict[str, object]] = []
    for group, (output_dir, xlim, ylim) in specs.items():
        ko_raw_visible = select_in_axes(periodontitis, xlim, ylim)
        ko_smoothed_visible = select_in_axes(smoothed, xlim, ylim)
        oe_visible = select_in_axes(healthy, xlim, ylim)
        prefix = '\u539f\u56fe' if group == '\u539f\u56fe\u8303\u56f4\u5b58\u6863' else '\u6295\u7a3f\u7248'
        results[f'{group}_KO\u539f\u59cb'] = draw_panel(base, output_dir, ko_raw_visible, 'GDF15_KO_cosine_shift', 'GDF15_KO_cosine_shift', 'Reds', xlim, ylim, ko_vmax, True, f'{prefix}_KO_\u539f\u59cb')
        results[f'{group}_KO\u5e73\u6ed1'] = draw_panel(base, output_dir, ko_smoothed_visible, 'GDF15_KO_cosine_shift_smoothed_display', 'GDF15_KO_cosine_shift', 'Reds', xlim, ylim, ko_vmax, True, f'{prefix}_KO_\u5e73\u6ed1')
        results[f'{group}_OE'] = draw_panel(base, output_dir, oe_visible, 'GDF15_OE_cosine_shift', 'GDF15_OE_cosine_shift', 'Blues', xlim, ylim, oe_vmax, False, f'{prefix}_OE')
        count_rows.extend([{'group': group, 'population': 'Periodontitis ECM remodeling', 'input_cells': int(len(periodontitis)), 'plotted_cells': int(len(ko_raw_visible)), 'cropped_cells': int(len(periodontitis) - len(ko_raw_visible))}, {'group': group, 'population': 'Healthy ECM remodeling', 'input_cells': int(len(healthy)), 'plotted_cells': int(len(oe_visible)), 'cropped_cells': int(len(healthy) - len(oe_visible))}])
    expected_counts = {('\u539f\u56fe\u8303\u56f4\u5b58\u6863', 'Periodontitis ECM remodeling'): (542, 10), ('\u539f\u56fe\u8303\u56f4\u5b58\u6863', 'Healthy ECM remodeling'): (1884, 0), ('\u65b0\u56fe2\u6295\u7a3f\u7248', 'Periodontitis ECM remodeling'): (542, 10), ('\u65b0\u56fe2\u6295\u7a3f\u7248', 'Healthy ECM remodeling'): (1852, 32)}
    for row in count_rows:
        actual = (row['plotted_cells'], row['cropped_cells'])
        expected = expected_counts[row['group'], row['population']]
        if actual != expected:
            raise ValueError(f'Unexpected count for {row}: expected {expected}')
    pd.DataFrame(count_rows).to_csv(TABLE_DIR / '\u539f\u56fe\u4e0e\u6295\u7a3f\u7248\u7ec6\u80de\u88c1\u526a\u8ba1\u6570.csv', index=False, encoding='utf-8-sig')
    smoothed.to_csv(TABLE_DIR / 'Williams\u7259\u5468\u708eECM_KO\u539f\u59cb\u53ca\u5e73\u6ed1\u6570\u636e.csv.gz', index=False, encoding='utf-8-sig', compression='gzip')
    healthy.to_csv(TABLE_DIR / 'Williams\u5065\u5eb7ECM_OE\u6570\u636e.csv.gz', index=False, encoding='utf-8-sig', compression='gzip')
    source_hashes_after = {key: base.sha256(path) for key, path in SOURCE_PDFS.items()}
    if source_hashes_before != source_hashes_after:
        raise ValueError('A prior PDF was modified')
    qa = {'status': 'PASS', 'point_size': {'KO_gray': POINT_SIZE, 'KO_colored': POINT_SIZE, 'OE_colored': POINT_SIZE, 'all_equal': True}, 'canvas': {'title_removed': True, 'B_and_C_removed': True}, 'axes': {'archived_original_range': {'xlim': list(ORIGINAL_XLIM), 'ylim': list(ORIGINAL_YLIM)}, 'submission_new_figure_2': {'xlim': list(SUBMISSION_XLIM), 'ylim': list(ORIGINAL_YLIM)}}, 'cell_counts': count_rows, 'prior_PDFs_unchanged': source_hashes_before == source_hashes_after, 'prior_PDF_sha256': source_hashes_after, 'results': results}
    (QA_DIR / '\u6295\u7a3f\u7248_\u70b9\u5f84\u7edf\u4e00_\u53bbBC_\u5ba1\u8ba1.json').write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding='utf-8')
    (ROOT / 'README_\u8bf7\u5148\u770b.md').write_text('# \u65b0\u56fe2\u6295\u7a3f\u7248\uff1a\u70b9\u5f84\u7edf\u4e00\u3001\u53bbB/C\n\n- KO\u539f\u59cb\u3001KO\u5e73\u6ed1\u548cOE\u7684\u5168\u90e8\u70b9\u5747\u4f7f\u7528\u540c\u4e00\u70b9\u9762\u79ef3.8 pt^2\uff1bKO\u6709\u8272\u70b9\u4e0d\u518d\u653e\u5927\u3002\n- \u6240\u6709\u56fe\u5747\u53bb\u9664\u9876\u90e8\u6807\u9898\u548c\u5de6\u4e0a\u89d2B/C\u3002\n- \u65b0\u56fe2\u6295\u7a3f\u7248UMAP1\u8303\u56f4\u4e3a0\u81f36.8336834803\uff0cUMAP2\u4fdd\u6301\u4e0a\u4e00\u6ee1\u610f\u7248\u672c\u3002\n- \u539f\u56fe\u8303\u56f4\u4e09\u5f20\u4fee\u6539\u7248\u4ec5\u5b58\u6863\u4e8eE\u76d8\uff1b\u6295\u7a3f\u7248\u4e09\u5f20\u7528\u4e8e\u590d\u5236\u81f3\u684c\u9762\u6b63\u6587\u56fe\u76ee\u5f55\u3002\n- \u65e2\u6709\u6587\u4ef6\u54c8\u5e0c\u672a\u6539\u53d8\uff0c\u672a\u8986\u76d6\u4efb\u4f55\u4e0a\u4e00\u7248\u3002\n', encoding='utf-8')
    print(json.dumps(qa, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
