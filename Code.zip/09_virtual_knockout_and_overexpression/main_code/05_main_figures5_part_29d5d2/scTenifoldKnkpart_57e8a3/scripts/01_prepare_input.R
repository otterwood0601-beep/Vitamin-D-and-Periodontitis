options(stringsAsFactors = FALSE, warn = 1)

local_lib <- Sys.getenv("VITDKO_R_LIB", unset = "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_enrichment")
.libPaths(c(local_lib, .libPaths()))

suppressPackageStartupMessages({
  library(Matrix)
})

input_rds <- Sys.getenv(
  "VITDKO_INPUT_RDS",
  unset = "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/05_\u5355\u7ec6\u80deRNA/\u6d3e\u751f\u8f93\u5165/GDF15_Figure1/input_fb/all_conditions_allStudies_CELLxGENE_direct_fibroblast_counts_only.rds"
)
out_root <- Sys.getenv("VITDKO_OUT_ROOT", unset = "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260821_GDF15\u865a\u62df\u6572\u9664_scTenifoldKnk_\u9996\u7248")

dir.create(file.path(out_root, "01_input_qc"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(out_root, "05_parameter_audit"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(out_root, "06_qa"), recursive = TRUE, showWarnings = FALSE)

log_file <- file.path(out_root, "06_qa", "01_prepare_input.log")
sink(log_file, split = TRUE)
on.exit(sink(), add = TRUE)

cat("Started input preparation:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")
cat("Input:", input_rds, "\n")
stopifnot(file.exists(input_rds))

obj <- readRDS(input_rds)
assays <- attr(obj, "assays")
stopifnot("RNA" %in% names(assays))
counts <- attr(assays[["RNA"]], "counts")
meta <- attr(obj, "meta.data")
stopifnot(inherits(counts, "dgCMatrix"), ncol(counts) == nrow(meta))
stopifnot(identical(colnames(counts), rownames(meta)))
stopifnot("GDF15" %in% rownames(counts))

input_dimensions <- c(genes = nrow(counts), cells = ncol(counts), nonzero = length(counts@x))
cat("Unfiltered object:", paste(names(input_dimensions), input_dimensions, collapse = "; "), "\n")

required_qc <- c("nFeature_RNA", "percent.mt", "nCount_RNA")
stopifnot(all(required_qc %in% colnames(meta)))
strict_keep <- with(
  meta,
  nFeature_RNA > 200 & nFeature_RNA < 5000 &
    percent.mt < 10 &
    nCount_RNA > 1000 & nCount_RNA < 25000
)
stopifnot(!anyNA(strict_keep), sum(strict_keep) == 14188L)

counts <- counts[, strict_keep, drop = FALSE]
meta <- meta[strict_keep, , drop = FALSE]
rm(obj, assays, strict_keep)
invisible(gc())

target_raw <- as.numeric(counts["GDF15", ])
cat(
  "Strict-QC cells:", ncol(counts),
  "GDF15 detected:", sum(target_raw > 0),
  sprintf("(%.4f%%)", 100 * mean(target_raw > 0)),
  "total UMI:", sum(target_raw), "\n"
)

summarize_group <- function(group, group_type, target_values) {
  idx <- split(seq_along(group), as.character(group), drop = TRUE)
  do.call(rbind, lapply(names(idx), function(level) {
    ii <- idx[[level]]
    data.frame(
      group_type = group_type,
      group = level,
      n_cells = length(ii),
      gdf15_detected_cells = sum(target_values[ii] > 0),
      gdf15_detection_pct = 100 * mean(target_values[ii] > 0),
      gdf15_total_umi = sum(target_values[ii]),
      stringsAsFactors = FALSE
    )
  }))
}

cohort_qc <- do.call(rbind, c(
  list(data.frame(
    group_type = "overall",
    group = "all_strict_qc_fibroblasts",
    n_cells = ncol(counts),
    gdf15_detected_cells = sum(target_raw > 0),
    gdf15_detection_pct = 100 * mean(target_raw > 0),
    gdf15_total_umi = sum(target_raw),
    stringsAsFactors = FALSE
  )),
  lapply(intersect(c("disease", "Study", "donor_id"), colnames(meta)), function(v) {
    summarize_group(meta[[v]], v, target_raw)
  })
))
write.csv(
  cohort_qc,
  file.path(out_root, "01_input_qc", "cohort_and_GDF15_detection_summary.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

cell_qc_summary <- data.frame(
  metric = c(
    "input_cells", "strict_qc_cells", "strict_qc_removed_cells",
    "strict_qc_donors", "strict_qc_studies", "strict_qc_disease_states",
    "GDF15_detected_cells", "GDF15_detection_pct", "GDF15_total_UMI"
  ),
  value = c(
    input_dimensions[["cells"]], ncol(counts), input_dimensions[["cells"]] - ncol(counts),
    length(unique(meta[["donor_id"]])), length(unique(meta[["Study"]])),
    length(unique(meta[["disease"]])), sum(target_raw > 0),
    100 * mean(target_raw > 0), sum(target_raw)
  )
)
write.csv(
  cell_qc_summary,
  file.path(out_root, "01_input_qc", "cell_QC_summary.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

write.csv(
  cbind(cell_id = rownames(meta), meta),
  file.path(out_root, "01_input_qc", "strict_QC_cell_metadata.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

detection_n <- Matrix::rowSums(counts != 0)
detection_pct <- 100 * detection_n / ncol(counts)
is_mito <- grepl("^MT-", rownames(counts), ignore.case = FALSE)
eligible <- detection_pct >= 5 & !is_mito
eligible[match("GDF15", rownames(counts))] <- FALSE
eligible_genes <- rownames(counts)[eligible]
stopifnot(length(eligible_genes) >= 1500L)

library_size <- Matrix::colSums(counts)
stopifnot(all(library_size > 0))
lognorm_eligible <- counts[eligible_genes, , drop = FALSE]
column_index <- rep.int(seq_len(ncol(lognorm_eligible)), diff(lognorm_eligible@p))
lognorm_eligible@x <- log1p(lognorm_eligible@x / library_size[column_index] * 10000)

n_cells <- ncol(lognorm_eligible)
gene_mean <- Matrix::rowMeans(lognorm_eligible)
sq <- lognorm_eligible
sq@x <- sq@x^2
gene_var <- (n_cells / (n_cells - 1)) * (Matrix::rowMeans(sq) - gene_mean^2)
gene_var[gene_var < 0 & abs(gene_var) < 1e-12] <- 0
log_mean <- log10(gene_mean + 1e-8)
log_var <- log10(gene_var + 1e-8)

loess_fit <- try(
  loess(
    log_var ~ log_mean,
    span = 0.30,
    degree = 2,
    family = "symmetric",
    control = loess.control(surface = "interpolate", statistics = "approximate")
  ),
  silent = TRUE
)
if (inherits(loess_fit, "try-error")) {
  warning("Loess HVG fit failed; using log-variance as the ranking score.")
  expected_log_var <- rep(median(log_var, na.rm = TRUE), length(log_var))
  hvg_method <- "fallback_log_variance"
} else {
  expected_log_var <- as.numeric(predict(loess_fit, newdata = data.frame(log_mean = log_mean)))
  missing_prediction <- !is.finite(expected_log_var)
  expected_log_var[missing_prediction] <- median(log_var, na.rm = TRUE)
  hvg_method <- "loess_residual_log_variance"
}
hvg_score <- log_var - expected_log_var
hvg_score[!is.finite(hvg_score)] <- -Inf
hvg_order <- order(hvg_score, decreasing = TRUE, na.last = TRUE)
hvg_n <- 1500L
hvg_genes <- eligible_genes[hvg_order[seq_len(hvg_n)]]
selected_genes <- c(hvg_genes, "GDF15")
stopifnot(length(unique(selected_genes)) == hvg_n + 1L)

target_log <- counts["GDF15", , drop = FALSE]
target_col_index <- rep.int(seq_len(ncol(target_log)), diff(target_log@p))
target_log@x <- log1p(target_log@x / library_size[target_col_index] * 10000)
network_input <- rbind(lognorm_eligible[hvg_genes, , drop = FALSE], target_log)
network_input <- as(network_input, "dgCMatrix")
rownames(network_input)[nrow(network_input)] <- "GDF15"
stopifnot(identical(rownames(network_input), selected_genes))

raw_selected <- counts[selected_genes, , drop = FALSE]
saveRDS(network_input, file.path(out_root, "01_input_qc", "network_input_log1p_CP10K_1500HVG_plus_GDF15.rds"), compress = "gzip")
saveRDS(raw_selected, file.path(out_root, "01_input_qc", "raw_counts_1500HVG_plus_GDF15.rds"), compress = "gzip")

gene_metrics <- data.frame(
  gene = rownames(counts),
  detection_n = detection_n,
  detection_pct = detection_pct,
  mitochondrial = is_mito,
  eligible_ge5pct_nonMT = eligible,
  lognorm_mean = NA_real_,
  lognorm_variance = NA_real_,
  hvg_score = NA_real_,
  hvg_rank = NA_integer_,
  selected_HVG = FALSE,
  forced_target = rownames(counts) == "GDF15",
  selected_for_network = rownames(counts) %in% selected_genes,
  stringsAsFactors = FALSE
)
eligible_index <- match(eligible_genes, gene_metrics$gene)
gene_metrics$lognorm_mean[eligible_index] <- gene_mean
gene_metrics$lognorm_variance[eligible_index] <- gene_var
gene_metrics$hvg_score[eligible_index] <- hvg_score
gene_metrics$hvg_rank[eligible_index[hvg_order]] <- seq_along(hvg_order)
gene_metrics$selected_HVG[match(hvg_genes, gene_metrics$gene)] <- TRUE
write.csv(
  gene_metrics,
  file.path(out_root, "01_input_qc", "gene_selection_metrics_all_genes.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

gene_selection_summary <- data.frame(
  metric = c(
    "strict_qc_genes_total", "genes_detected_ge_5pct", "mitochondrial_genes_excluded",
    "eligible_nonMT_genes", "HVGs_selected", "forced_targets", "network_genes_total",
    "network_cells_total", "HVG_method", "HVG_loess_span", "normalization"
  ),
  value = c(
    nrow(counts), sum(detection_pct >= 5), sum(detection_pct >= 5 & is_mito),
    length(eligible_genes), length(hvg_genes), 1, nrow(network_input), ncol(network_input),
    hvg_method, "0.30", "log1p(count / library_size * 10000)"
  ),
  stringsAsFactors = FALSE
)
write.csv(
  gene_selection_summary,
  file.path(out_root, "01_input_qc", "gene_selection_summary.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

input_manifest <- list(
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"),
  input_rds = input_rds,
  input_dimensions = input_dimensions,
  strict_qc_cells = ncol(counts),
  target = "GDF15",
  target_detection_n = sum(target_raw > 0),
  target_detection_pct = 100 * mean(target_raw > 0),
  population = "all four-study strict-QC gingival fibroblasts",
  normalization = "log1p(CP10K)",
  hvg_method = hvg_method,
  hvg_n = hvg_n,
  forced_target = TRUE,
  network_dimensions = dim(network_input)
)
saveRDS(input_manifest, file.path(out_root, "01_input_qc", "input_manifest.rds"))

cat("Prepared network input:", nrow(network_input), "genes x", ncol(network_input), "cells\n")
cat("Finished:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")

rm(counts, lognorm_eligible, sq, network_input, raw_selected)
invisible(gc())
