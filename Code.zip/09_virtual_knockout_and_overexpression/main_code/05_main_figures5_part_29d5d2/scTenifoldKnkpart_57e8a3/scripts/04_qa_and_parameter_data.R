options(stringsAsFactors = FALSE, warn = 1, encoding = "UTF-8")

local_lib <- Sys.getenv("VITDKO_R_LIB", unset = "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_enrichment")
.libPaths(c(local_lib, .libPaths()))

suppressPackageStartupMessages({
  library(Matrix)
})

out_root <- Sys.getenv("VITDKO_OUT_ROOT", unset = "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260821_GDF15\u865a\u62df\u6572\u9664_scTenifoldKnk_\u9996\u7248")
dir.create(file.path(out_root, "05_parameter_audit"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(out_root, "06_qa"), recursive = TRUE, showWarnings = FALSE)

mark_utf8 <- function(x) {
  for (j in seq_along(x)) {
    if (is.character(x[[j]])) Encoding(x[[j]]) <- "UTF-8"
  }
  x
}

write_csv_utf8_binary <- function(x, path) {
  escape_field <- function(value) {
    value <- as.character(value)
    value[is.na(value)] <- ""
    value <- gsub('"', '""', value, fixed = TRUE)
    paste0('"', value, '"')
  }

  header <- paste(vapply(names(x), escape_field, character(1)), collapse = ",")
  rows <- vapply(seq_len(nrow(x)), function(i) {
    paste(vapply(x, function(column) escape_field(column[[i]]), character(1)), collapse = ",")
  }, character(1))
  payload <- paste0(paste(c(header, rows), collapse = "\r\n"), "\r\n")

  con <- file(path, open = "wb")
  on.exit(close(con), add = TRUE)
  writeBin(charToRaw(enc2utf8(payload)), con)
  invisible(path)
}

input_manifest <- readRDS(file.path(out_root, "01_input_qc", "input_manifest.rds"))
run_info <- readRDS(file.path(out_root, "02_virtual_ko", "run_parameters_and_manifest.rds"))
result <- readRDS(file.path(out_root, "02_virtual_ko", "scTenifoldKnk_GDF15_full_result.rds"))
diff_reg <- read.csv(
  file.path(out_root, "02_virtual_ko", "GDF15_differential_regulation_all_genes.csv"),
  stringsAsFactors = FALSE,
  check.names = FALSE
)
cohort_qc <- read.csv(
  file.path(out_root, "01_input_qc", "cohort_and_GDF15_detection_summary.csv"),
  stringsAsFactors = FALSE,
  check.names = FALSE
)
gene_selection <- read.csv(
  file.path(out_root, "01_input_qc", "gene_selection_summary.csv"),
  stringsAsFactors = FALSE,
  check.names = FALSE
)
top20 <- read.csv(
  file.path(out_root, "04_figures", "Panel_E_top20_differentially_regulated_genes_source.csv"),
  stringsAsFactors = FALSE,
  check.names = FALSE
)
panel_f <- read.csv(
  file.path(out_root, "04_figures", "Panel_F_functional_enrichment_source.csv"),
  stringsAsFactors = FALSE,
  check.names = FALSE
)
figure_manifest <- read.csv(
  file.path(out_root, "04_figures", "figure_manifest.csv"),
  stringsAsFactors = FALSE,
  check.names = FALSE
)

rp <- run_info$parameters
parameter_rows <- list()
add_parameter <- function(
    stage, parameter, value_used, source_type, analyst_set,
    rationale_zh, later_review_action, effect_on_result) {
  parameter_rows[[length(parameter_rows) + 1L]] <<- data.frame(
    stage = stage,
    parameter = parameter,
    value_used = as.character(value_used),
    source_type = source_type,
    analyst_set = analyst_set,
    rationale_zh = rationale_zh,
    later_review_action = later_review_action,
    effect_on_result = effect_on_result,
    stringsAsFactors = FALSE
  )
}

add_parameter(
  "data", "target_gene", "GDF15", "user_specified", "No",
  "\u7531\u7528\u6237\u8bfe\u9898\u6307\u5b9a\uff0c\u4e0d\u662f\u5206\u6790\u8005\u81ea\u884c\u9009\u62e9\u3002",
  "\u65e0\u9700\u66f4\u6539\uff1b\u5982\u7814\u7a76\u5176\u4ed6\u9776\u70b9\u9700\u5355\u72ec\u91cd\u8dd1\u3002", "\u51b3\u5b9a\u88ab\u865a\u62df\u6572\u9664\u7684\u7f51\u7edc\u8282\u70b9\u3002"
)
add_parameter(
  "data", "analysis_population", "all four-study strict-QC gingival fibroblasts",
  "analyst_defined_adaptation", "Yes",
  "GDF15\u5728\u4e25\u683c\u8d28\u63a7\u7ec6\u80de\u4e2d\u7684\u68c0\u51fa\u7387\u4ec50.634%\uff0c\u4f7f\u7528\u5168\u90e8\u6210\u7ea4\u7ef4\u7ec6\u80de\u4ee5\u4fdd\u7559\u6700\u591a\u7684\u9776\u57fa\u56e0\u4fe1\u53f7\uff1b\u56e0\u6b64\u9996\u7248\u660e\u786e\u4e3a\u63a2\u7d22\u6027\u3002",
  "\u6b63\u5f0f\u7248\u5efa\u8bae\u53e6\u505a\u7259\u5468\u708e\u7ec6\u80de\u9650\u5b9a\u548c\u4e3b\u8981\u961f\u5217\u9650\u5b9a\u654f\u611f\u6027\u5206\u6790\u3002",
  "\u6539\u53d8\u53c2\u4e0e\u7f51\u7edc\u5b66\u4e60\u7684\u7ec6\u80de\u7ec4\u6210\uff0c\u53ef\u80fd\u6539\u53d8\u4e0b\u6e38\u57fa\u56e0\u6392\u540d\u3002"
)
add_parameter(
  "cell_QC", "nFeature_RNA_lower_exclusive", 200, "inherited_upstream_rule", "No",
  "\u5b8c\u5168\u590d\u7528\u56db\u7814\u7a76\u6574\u5408\u811a\u672c\u7684\u4e25\u683c\u8d28\u63a7\u9608\u503c\u3002", "\u4fdd\u6301\u4e0d\u53d8\u3002", "\u53bb\u9664\u6781\u4f4e\u590d\u6742\u5ea6\u7ec6\u80de\u3002"
)
add_parameter(
  "cell_QC", "nFeature_RNA_upper_exclusive", 5000, "inherited_upstream_rule", "No",
  "\u5b8c\u5168\u590d\u7528\u56db\u7814\u7a76\u6574\u5408\u811a\u672c\u7684\u4e25\u683c\u8d28\u63a7\u9608\u503c\u3002", "\u4fdd\u6301\u4e0d\u53d8\u3002", "\u964d\u4f4e\u53cc\u7ec6\u80de\u6216\u9ad8\u590d\u6742\u5ea6\u5f02\u5e38\u7ec6\u80de\u5f71\u54cd\u3002"
)
add_parameter(
  "cell_QC", "percent_mt_upper_exclusive", 10, "inherited_upstream_rule", "No",
  "\u5b8c\u5168\u590d\u7528\u56db\u7814\u7a76\u6574\u5408\u811a\u672c\u7684\u4e25\u683c\u8d28\u63a7\u9608\u503c\u3002", "\u4fdd\u6301\u4e0d\u53d8\u3002", "\u964d\u4f4e\u4f4e\u8d28\u91cf\u6216\u53d7\u635f\u7ec6\u80de\u5f71\u54cd\u3002"
)
add_parameter(
  "cell_QC", "nCount_RNA_lower_exclusive", 1000, "inherited_upstream_rule", "No",
  "\u5b8c\u5168\u590d\u7528\u56db\u7814\u7a76\u6574\u5408\u811a\u672c\u7684\u4e25\u683c\u8d28\u63a7\u9608\u503c\u3002", "\u4fdd\u6301\u4e0d\u53d8\u3002", "\u53bb\u9664\u4f4e\u6587\u5e93\u91cf\u7ec6\u80de\u3002"
)
add_parameter(
  "cell_QC", "nCount_RNA_upper_exclusive", 25000, "inherited_upstream_rule", "No",
  "\u5b8c\u5168\u590d\u7528\u56db\u7814\u7a76\u6574\u5408\u811a\u672c\u7684\u4e25\u683c\u8d28\u63a7\u9608\u503c\u3002", "\u4fdd\u6301\u4e0d\u53d8\u3002", "\u964d\u4f4e\u53cc\u7ec6\u80de\u6216\u5f02\u5e38\u9ad8\u6587\u5e93\u91cf\u5f71\u54cd\u3002"
)
add_parameter(
  "data", "strict_QC_cell_count", input_manifest$strict_qc_cells,
  "data_derived", "No", "\u7531\u65e2\u5b9a\u8d28\u63a7\u89c4\u5219\u8ba1\u7b97\u5f97\u5230\u3002", "\u6838\u5bf9\u4e0a\u6e38\u5bf9\u8c61\u53d8\u5316\u65f6\u5e94\u91cd\u65b0\u8ba1\u7b97\u3002",
  "\u51b3\u5b9a\u53ef\u7528\u4e8e\u7f51\u7edc\u6784\u5efa\u7684\u603b\u7ec6\u80de\u91cf\u3002"
)
add_parameter(
  "quality_flag", "minimum_preferred_GDF15_detection_pct", 5,
  "analyst_defined_QA_threshold", "Yes",
  "\u4f5c\u4e3a\u9776\u57fa\u56e0\u662f\u5426\u5177\u6709\u8db3\u591f\u5355\u7ec6\u80de\u68c0\u51fa\u7387\u7684\u9884\u8b66\u9608\u503c\uff0c\u4e0d\u7528\u4e8e\u4eba\u4e3a\u5220\u9664\u7ed3\u679c\uff1b\u672c\u6570\u636e\u672a\u8fbe\u5230\u3002",
  "\u6b63\u5f0f\u89e3\u91ca\u65f6\u5fc5\u987b\u4fdd\u7559\u4f4e\u68c0\u51fa\u7387\u9650\u5236\uff0c\u5e76\u8fdb\u884c\u5b50\u96c6/\u79cd\u5b50\u654f\u611f\u6027\u5206\u6790\u3002",
  "\u4e0d\u6539\u53d8\u8ba1\u7b97\uff0c\u53ea\u6539\u53d8\u8bc1\u636e\u5f3a\u5ea6\u8bc4\u7ea7\u3002"
)
add_parameter(
  "normalization", "normalization_formula", "log1p(count / library_size * 10000)",
  "analyst_defined_operationalization", "Yes",
  "\u53c2\u8003\u8bba\u6587\u53ea\u5199normalized single-cell expression data\uff0c\u672a\u7ed9\u51fa\u5177\u4f53\u516c\u5f0f\uff1b\u6b64\u5904\u91c7\u7528\u5e38\u7528CP10K\u52a0log1p\u5b9e\u73b0\u3002",
  "\u5efa\u8bae\u4e0e\u539f\u59cb\u8ba1\u6570\u8f93\u5165\u3001SCTransform\u6216\u5176\u4ed6\u5f52\u4e00\u5316\u65b9\u6848\u6bd4\u8f83\u7a33\u5b9a\u6027\u3002",
  "\u6539\u53d8\u57fa\u56e0\u95f4\u53ca\u7ec6\u80de\u95f4\u534f\u65b9\u5dee\u7ed3\u6784\uff0c\u53ef\u80fd\u5f71\u54cd\u7f51\u7edc\u8fb9\u3002"
)
add_parameter(
  "normalization", "CP_scale_factor", 10000,
  "analyst_defined", "Yes",
  "\u5355\u7ec6\u80de\u5e38\u7528\u7684\u6bcf\u4e07\u8ba1\u6570\u5c3a\u5ea6\uff0c\u53c2\u8003\u8bba\u6587\u672a\u7ed9\u51fa\u3002",
  "\u901a\u5e38\u4fdd\u6301\uff1b\u5982\u9700\u654f\u611f\u6027\u5206\u6790\u53ef\u6bd4\u8f831e6 CPM\uff0c\u4f46log\u540e\u4ec5\u6709\u5c3a\u5ea6\u5dee\u5f02\u3002",
  "\u5f71\u54cd\u5f52\u4e00\u5316\u6570\u503c\u5c3a\u5ea6\u3002"
)
add_parameter(
  "gene_filter", "minimum_gene_detection_pct", 5,
  "analyst_defined", "Yes",
  "\u51cf\u5c11\u6781\u7a00\u758f\u57fa\u56e0\u5bfc\u81f4\u7684\u4e0d\u7a33\u5b9a\u7f51\u7edc\u4f30\u8ba1\u3002",
  "\u5efa\u8bae\u6bd4\u8f831%\u30012%\u548c10%\u9608\u503c\u3002",
  "\u76f4\u63a5\u51b3\u5b9a\u53ef\u8fdb\u5165HVG\u5019\u9009\u96c6\u7684\u57fa\u56e0\u3002"
)
add_parameter(
  "gene_filter", "exclude_mitochondrial_genes", TRUE,
  "analyst_defined", "Yes",
  "\u907f\u514d\u7ec6\u80de\u8d28\u91cf/\u5e94\u6fc0\u6280\u672f\u4fe1\u53f7\u4e3b\u5bfc\u8c03\u63a7\u7f51\u7edc\u3002",
  "\u53ef\u505a\u5305\u542bMT\u57fa\u56e0\u7684\u654f\u611f\u6027\u5206\u6790\u3002",
  "\u6539\u53d8HVG\u5019\u9009\u96c6\u548c\u7f51\u7edc\u8282\u70b9\u3002"
)
add_parameter(
  "HVG", "HVG_method", input_manifest$hvg_method,
  "analyst_defined", "Yes",
  "\u4f7f\u7528log\u5747\u503c-\u65b9\u5deeloess\u8d8b\u52bf\u7684\u6b8b\u5dee\u6392\u5e8f\uff0c\u907f\u514d\u989d\u5916\u4f9d\u8d56Seurat\u7248\u672c\u3002",
  "\u5efa\u8bae\u4e0eSeurat vst\u6216scran modelGeneVar\u6bd4\u8f83\u3002",
  "\u51b3\u5b9a\u8fdb\u5165\u7f51\u7edc\u7684\u9ad8\u53d8\u57fa\u56e0\u3002"
)
add_parameter(
  "HVG", "loess_span", 0.30,
  "analyst_defined", "Yes",
  "\u63a7\u5236\u5747\u503c-\u65b9\u5dee\u8d8b\u52bf\u5e73\u6ed1\u7a0b\u5ea6\u3002",
  "\u5efa\u8bae\u6bd4\u8f830.2\u30010.3\u30010.5\u3002",
  "\u53ef\u80fd\u6539\u53d8\u9ad8\u53d8\u57fa\u56e0\u8fb9\u754c\u6392\u540d\u3002"
)
add_parameter(
  "HVG", "prepared_HVG_pool", 1500,
  "analyst_defined_resource_constraint", "Yes",
  "\u9884\u5904\u7406\u9636\u6bb5\u4fdd\u75591500\u4e2aHVG\uff0c\u4f5c\u4e3a\u540e\u7eed\u6269\u5927\u8282\u70b9\u6570\u65f6\u53ef\u76f4\u63a5\u590d\u7528\u7684\u5019\u9009\u6c60\u3002",
  "\u6b63\u5f0f\u7248\u53ef\u76f4\u63a5\u4f7f\u7528\u5b8c\u65741500\u6216\u6269\u81f33000\u91cd\u65b0\u9884\u5904\u7406\u3002",
  "\u4e0d\u76f4\u63a5\u7b49\u4e8e\u672c\u6b21\u9996\u7248\u5b9e\u9645\u8fd0\u884c\u8282\u70b9\u6570\u3002"
)
add_parameter(
  "HVG", "number_of_HVGs_used_in_pilot", rp$pilot_hvg_n,
  "analyst_defined_resource_constraint", "Yes",
  "1500\u4e2aHVG\u7684\u5b98\u65b9\u987a\u5e8f\u5b9e\u73b0\u5b9e\u6d4b\u9996\u4e2a\u7f51\u7edc\u7ea621\u5206\u949f\u3001\u603b\u9884\u8ba1\u7ea63\u5c0f\u65f6\uff1b\u9996\u7248\u6539\u4e3a1000\u4e2aHVG\u4ee5\u5728\u672c\u8f6e\u5b8c\u6210\u3002",
  "\u6b63\u5f0f\u7248\u5fc5\u987b\u6bd4\u8f831500\u30012000\u548c3000\u4e2aHVG\uff0c\u62a5\u544a\u6392\u540d\u4e00\u81f4\u6027\u3002",
  "\u76f4\u63a5\u9650\u5236\u7f51\u7edc\u7ef4\u5ea6\u548c\u53ef\u88ab\u53d1\u73b0\u7684\u4e0b\u6e38\u57fa\u56e0\u3002"
)
add_parameter(
  "HVG", "force_include_GDF15", TRUE,
  "analyst_defined_necessary_step", "Yes",
  "GDF15\u4f4e\u4e8e5%\u68c0\u51fa\u9608\u503c\u4f46\u5fc5\u987b\u4f5c\u4e3a\u6572\u9664\u76ee\u6807\uff0c\u56e0\u6b64\u5f3a\u5236\u4fdd\u7559\u3002",
  "\u4fdd\u6301\uff1b\u5426\u5219\u65e0\u6cd5\u8fd0\u884cGDF15\u6572\u9664\u3002",
  "\u4f7f\u4f4e\u4e30\u5ea6\u9776\u57fa\u56e0\u8fdb\u5165\u7f51\u7edc\uff0c\u4f46\u4e5f\u589e\u52a0\u4f30\u8ba1\u4e0d\u7a33\u5b9a\u98ce\u9669\u3002"
)
add_parameter(
  "scTenifoldKnk", "software_version", "1.0.3",
  "pinned_official_release", "No",
  "\u56fa\u5b9a\u5b98\u65b9CRAN/GitHub v1.0.3\u4ee5\u4fbf\u590d\u73b0\u3002",
  "\u7248\u672c\u5347\u7ea7\u65f6\u9700\u72ec\u7acb\u590d\u8dd1\uff0c\u4e0d\u5e94\u6df7\u7528\u7ed3\u679c\u3002",
  "\u8f6f\u4ef6\u5b9e\u73b0\u53d8\u5316\u53ef\u80fd\u6539\u53d8\u7f51\u7edc\u548c\u7edf\u8ba1\u91cf\u3002"
)
add_parameter(
  "scTenifoldKnk", "random_seed", rp$random_seed,
  "analyst_defined", "Yes",
  "\u56fa\u5b9a\u968f\u673a\u62bd\u6837\u7f51\u7edc\uff0c\u4fdd\u8bc1\u9996\u7248\u53ef\u91cd\u590d\u3002",
  "\u5fc5\u987b\u81f3\u5c11\u589e\u52a04\u4e2a\u4e0d\u540c\u968f\u673a\u79cd\u5b50\u505a\u7a33\u5b9a\u6027\u5206\u6790\u3002",
  "\u5f71\u54cd\u6bcf\u4e2a\u5b50\u7f51\u7edc\u62bd\u53d6\u7684\u7ec6\u80de\u53ca\u6700\u7ec8\u57fa\u56e0\u6392\u540d\u3002"
)
add_parameter(
  "scTenifoldKnk", "RNG_strategy", rp$RNG_kind,
  "analyst_defined", "Yes",
  "\u4e3a\u6bcf\u4e2a\u5b50\u7f51\u7edc\u751f\u6210\u56fa\u5b9a\u4e14\u76f8\u4e92\u72ec\u7acb\u7684L'Ecuyer-CMRG\u968f\u673a\u6d41\uff0c\u907f\u514d\u7ed3\u679c\u4f9d\u8d56\u5de5\u4f5c\u8fdb\u7a0b\u8c03\u5ea6\u3002",
  "\u4fdd\u6301\uff1b\u65b0\u589e\u79cd\u5b50\u654f\u611f\u6027\u5206\u6790\u65f6\u66f4\u6362\u4e3b\u79cd\u5b50\u3002",
  "\u51b3\u5b9a\u6bcf\u4e2a\u5b50\u7f51\u7edc\u62bd\u53d6\u54ea\u4e9b\u7ec6\u80de\u3002"
)
add_parameter(
  "scTenifoldKnk", "execution_strategy", rp$execution_strategy,
  "analyst_defined_runtime_optimization", "Yes",
  "\u5b98\u65b9\u7b97\u6cd5\u548c10\u4e2a\u7f51\u7edc\u53c2\u6570\u4e0d\u53d8\uff0c\u4ec5\u628a\u5916\u5c42\u5b50\u7f51\u7edc\u6784\u5efa\u6539\u4e3aPSOCK\u5e76\u884c\uff1b\u4fee\u590d\u987a\u5e8f\u5b9e\u73b0\u7ea63\u5c0f\u65f6\u7684\u8fd0\u884c\u74f6\u9888\u3002",
  "\u5982\u6295\u7a3f\u8981\u6c42\u5b8c\u5168\u4f7f\u7528\u5c01\u88c5\u51fd\u6570\uff0c\u53ef\u5728\u957f\u8fd0\u884c\u7a97\u53e3\u7528\u5b98\u65b9\u987a\u5e8f\u5c01\u88c5\u590d\u6838\u3002",
  "\u7406\u8bba\u4e0a\u53ea\u5f71\u54cd\u8fd0\u884c\u65f6\u95f4\uff1b\u968f\u673a\u6d41\u56fa\u5b9a\u540e\u7ed3\u679c\u53ef\u590d\u73b0\u3002"
)
add_parameter(
  "scTenifoldKnk", "qc", rp$qc,
  "analyst_defined_workflow_choice", "Yes",
  "\u5df2\u5728\u4e0a\u6e38\u663e\u5f0f\u6267\u884c\u4e25\u683c\u7ec6\u80deQC\u548c\u57fa\u56e0\u8fc7\u6ee4\uff0c\u56e0\u6b64\u5173\u95ed\u5305\u5185QC\u907f\u514d\u91cd\u590d\u8fc7\u6ee4\u3002",
  "\u4fdd\u6301\uff1b\u82e5\u6539\u4e3a\u5305\u5185QC\u9700\u8bb0\u5f55\u5176\u9608\u503c\u5e76\u91cd\u65b0\u6bd4\u8f83\u3002",
  "\u9632\u6b62\u91cd\u590d\u8d28\u63a7\u9020\u6210\u4e0d\u53ef\u63a7\u7684\u6837\u672c\u53d8\u5316\u3002"
)

official_defaults <- list(
  nc_lambda = rp$nc_lambda,
  nc_nNet = rp$nc_nNet,
  nc_nCells = rp$nc_nCells,
  nc_nComp = rp$nc_nComp,
  nc_scaleScores = rp$nc_scaleScores,
  nc_symmetric = rp$nc_symmetric,
  nc_q = rp$nc_q,
  td_K = rp$td_K,
  td_maxIter = rp$td_maxIter,
  td_maxError = rp$td_maxError,
  td_nDecimal = rp$td_nDecimal,
  ma_nDim = rp$ma_nDim
)
for (nm in names(official_defaults)) {
  add_parameter(
    "scTenifoldKnk", nm, official_defaults[[nm]],
    "official_v1.0.3_default", "No",
    "\u4fdd\u6301scTenifoldKnk v1.0.3\u51fd\u6570\u9ed8\u8ba4\u503c\u3002",
    "\u6b63\u5f0f\u7248\u4f18\u5148\u4fdd\u6301\uff1b\u4ec5\u5728\u9884\u6ce8\u518c\u654f\u611f\u6027\u5206\u6790\u4e2d\u6539\u53d8\u3002",
    "\u63a7\u5236\u7f51\u7edc\u7a00\u758f\u5316\u3001\u5b50\u7f51\u7edc\u6570\u3001\u5f20\u91cf\u5206\u89e3\u6216\u6d41\u5f62\u5bf9\u9f50\u3002"
  )
}
add_parameter(
  "scTenifoldKnk", "nCores", rp$nCores,
  "analyst_defined_resource_constraint", "Yes",
  "\u673a\u5668\u4e3a8\u4e2a\u7269\u7406\u6838\u5fc3\uff1b\u57284\u8fdb\u7a0b\u5b9e\u6d4b\u4ecd\u6709\u7ea66GB\u53ef\u7528\u5185\u5b58\u540e\uff0c\u9996\u7248\u91c7\u75288\u4e2a\u5916\u5c42\u5e76\u884c\u5de5\u4f5c\u8fdb\u7a0b\u3002",
  "\u5728\u66f4\u9ad8\u5185\u5b58\u73af\u5883\u53ef\u589e\u52a0\uff0c\u4f46\u5e94\u786e\u8ba4\u6570\u503c\u7ed3\u679c\u4e0d\u53d8\u3002",
  "\u4e3b\u8981\u5f71\u54cd\u8fd0\u884c\u65f6\u95f4\uff0c\u67d0\u4e9b\u5e76\u884c\u5b9e\u73b0\u4e5f\u53ef\u80fd\u5f71\u54cd\u53ef\u590d\u73b0\u6027\u3002"
)
add_parameter(
  "downstream", "exclude_GDF15_from_downstream_ranking", TRUE,
  "analyst_defined", "Yes",
  "\u907f\u514d\u6572\u9664\u9776\u57fa\u56e0\u672c\u8eab\u5360\u636e\u4e0b\u6e38\u6270\u52a8\u57fa\u56e0\u6392\u540d\u3002",
  "\u4fdd\u6301\uff1b\u540c\u65f6\u5728\u5168\u7ed3\u679c\u8868\u4e2d\u4fdd\u7559GDF15\u539f\u59cb\u884c\u3002",
  "\u5f71\u54cdTop20\u548c\u5bcc\u96c6\u8f93\u5165\u3002"
)
add_parameter(
  "Panel_E", "number_of_top_genes", 20,
  "reference_figure_defined", "No",
  "\u53c2\u8003\u8bba\u6587Figure 8E\u660e\u786e\u663e\u793aTop 20\u3002",
  "\u4fdd\u6301\u4ee5\u4fbf\u540c\u6b3e\u6bd4\u8f83\u3002",
  "\u4ec5\u5f71\u54cd\u5c55\u793a\uff0c\u4e0d\u6539\u53d8\u5168\u7ed3\u679c\u3002"
)
add_parameter(
  "Panel_E", "ranking_metric", "descending scTenifoldKnk FC",
  "reference_method_interpretation", "No",
  "FC\u4e3a\u7f51\u7edc\u4f4d\u79fb\u5e73\u65b9\u76f8\u5bf9\u5747\u503c\uff0c\u4e0d\u662f\u8868\u8fbefold change\uff0c\u4e5f\u6ca1\u6709\u4e0a\u4e0b\u8c03\u65b9\u5411\u3002",
  "\u6b63\u6587\u5fc5\u987b\u4f7f\u7528regulatory displacement/\u8c03\u63a7\u4f4d\u79fb\u63aa\u8f9e\u3002",
  "\u51b3\u5b9aTop20\u5c55\u793a\u987a\u5e8f\u3002"
)
add_parameter(
  "enrichment", "input_rule", "top 200 FC among FDR < 0.05",
  "analyst_defined", "Yes",
  "\u53c2\u8003\u8bba\u6587\u672a\u62a5\u544a\u5bcc\u96c6\u8f93\u5165\u6570\u91cf\uff1b\u7528\u663e\u8457\u6270\u52a8\u57fa\u56e0\u4e2d\u7684\u6700\u5927200\u4e2a\u805a\u7126largest regulatory shifts\u3002",
  "\u5efa\u8bae\u6bd4\u8f83Top100\u3001Top300\u548c\u5168\u90e8FDR\u663e\u8457\u57fa\u56e0\u3002",
  "\u76f4\u63a5\u5f71\u54cdGO/KEGG\u5bcc\u96c6\u6761\u76ee\u3002"
)
add_parameter(
  "enrichment", "multiple_testing", "Benjamini-Hochberg FDR",
  "analyst_defined", "Yes",
  "\u5bf9\u6bcf\u4e2a\u5bcc\u96c6\u6570\u636e\u5e93\u5185\u6761\u76ee\u8fdb\u884cBH\u6821\u6b63\u3002",
  "\u4fdd\u6301\uff1b\u53ef\u540c\u65f6\u62a5\u544a\u539f\u59cbP\u4f46\u4e0d\u7528\u4e8e\u4e3b\u8981\u7ed3\u8bba\u3002",
  "\u51b3\u5b9a\u5bcc\u96c6\u6761\u76ee\u7684\u7edf\u8ba1\u8bc1\u636e\u3002"
)
add_parameter(
  "enrichment", "gene_universe", "all mapped genes tested by scTenifoldKnk",
  "analyst_defined_best_practice", "Yes",
  "\u4f7f\u7528\u5b9e\u9645\u53ef\u88ab\u7f51\u7edc\u68c0\u6d4b\u7684\u57fa\u56e0\u4f5c\u4e3a\u80cc\u666f\uff0c\u907f\u514d\u5168\u57fa\u56e0\u7ec4\u80cc\u666f\u504f\u501a\u3002",
  "\u4fdd\u6301\uff1b\u4e0d\u5efa\u8bae\u6539\u4e3a\u5168\u57fa\u56e0\u7ec4\u3002",
  "\u5f71\u54cd\u5bcc\u96c6\u6bd4\u503c\u548cP\u503c\u3002"
)
add_parameter(
  "enrichment", "min_gene_set_size", 10,
  "clusterProfiler_default", "No",
  "\u4fdd\u6301clusterProfiler\u5e38\u7528\u9ed8\u8ba4\u503c\u3002",
  "\u6b63\u5f0f\u7248\u4e00\u822c\u4fdd\u6301\u3002",
  "\u6392\u9664\u8fc7\u5c0f\u3001\u6613\u4e0d\u7a33\u5b9a\u7684\u57fa\u56e0\u96c6\u3002"
)
add_parameter(
  "enrichment", "max_gene_set_size", 500,
  "clusterProfiler_default", "No",
  "\u4fdd\u6301clusterProfiler\u5e38\u7528\u9ed8\u8ba4\u503c\u3002",
  "\u6b63\u5f0f\u7248\u4e00\u822c\u4fdd\u6301\u3002",
  "\u6392\u9664\u8fc7\u4e8e\u5bbd\u6cdb\u7684\u57fa\u56e0\u96c6\u3002"
)
add_parameter(
  "Panel_F", "term_quota", "BP=2; CC=5; MF=4; KEGG=4",
  "reference_figure_inferred", "No",
  "\u6309\u53c2\u8003Figure 8F\u53ef\u89c1\u768415\u6761\u5206\u7c7b\u6570\u91cf\u590d\u523b\u3002",
  "\u4fdd\u6301\u7528\u4e8e\u540c\u6b3e\u56fe\uff1b\u53e6\u63d0\u4f9b\u6240\u6709\u6761\u76ee\u8868\u3002",
  "\u53ea\u5f71\u54cd\u9762\u677f\u5c55\u793a\uff0c\u4e0d\u6539\u53d8\u5b8c\u6574\u5bcc\u96c6\u7ed3\u679c\u3002"
)
add_parameter(
  "Panel_F", "term_selection", "smallest adjusted P within each category",
  "analyst_defined", "Yes",
  "\u53c2\u8003\u8bba\u6587\u672a\u62a5\u544a\u5177\u4f53\u9009\u6761\u89c4\u5219\uff1b\u9996\u7248\u6309\u6bcf\u7c7bBH\u6821\u6b63P\u6392\u5e8f\u3002",
  "\u540e\u671f\u53ef\u6839\u636e\u9884\u5148\u5b9a\u4e49\u7684\u7259\u5468\u708e/GDF15\u673a\u5236\u6761\u76ee\u505a\u72ec\u7acb\u76ee\u6807\u56fe\uff0c\u4f46\u4e0d\u5f97\u66ff\u6362\u7edf\u8ba1\u7ed3\u679c\u56fe\u3002",
  "\u5f71\u54cd\u56fe\u4e2d\u5c55\u793a\u54ea\u4e9b\u901a\u8def\u3002"
)
add_parameter(
  "figure", "Panel_E_x_axis", "log10(FC + 1)",
  "reference_figure_defined", "No",
  "\u5b8c\u5168\u590d\u523b\u53c2\u8003Figure 8E\u6a2a\u8f74\u3002",
  "\u4fdd\u6301\u3002",
  "\u4ec5\u6539\u53d8\u53ef\u89c6\u5316\u5c3a\u5ea6\u3002"
)
add_parameter(
  "figure", "Panel_F_x_axis", "-log10(adjusted P)",
  "reference_figure_defined", "No",
  "\u5b8c\u5168\u590d\u523b\u53c2\u8003Figure 8F\u6a2a\u8f74\u3002",
  "\u4fdd\u6301\u3002",
  "\u4ec5\u6539\u53d8\u5bcc\u96c6\u8bc1\u636e\u7684\u53ef\u89c6\u5316\u5c3a\u5ea6\u3002"
)

all_parameters <- do.call(rbind, parameter_rows)
all_parameters <- mark_utf8(all_parameters)
all_parameters$analyst_set <- factor(all_parameters$analyst_set, levels = c("Yes", "No"))
self_set <- all_parameters[all_parameters$analyst_set == "Yes", , drop = FALSE]

write_csv_utf8_binary(
  all_parameters,
  file.path(out_root, "05_parameter_audit", "all_parameters.csv")
)
write_csv_utf8_binary(
  self_set,
  file.path(out_root, "05_parameter_audit", "analyst_defined_parameters_only.csv")
)

software_packages <- c(
  "Matrix", "scTenifoldKnk", "scTenifoldNet", "AnnotationDbi",
  "org.Hs.eg.db", "clusterProfiler", "ggplot2", "patchwork", "svglite"
)
software_versions <- data.frame(
  software = c("R", software_packages),
  version = c(
    R.version.string,
    vapply(software_packages, function(p) {
      if (requireNamespace(p, quietly = TRUE)) as.character(packageVersion(p)) else NA_character_
    }, character(1))
  ),
  source = c(
    "C:/Program Files/R/R-4.5.3",
    rep("R package library; paths recorded in R_sessionInfo.txt", length(software_packages))
  ),
  stringsAsFactors = FALSE
)
software_versions <- mark_utf8(software_versions)
write_csv_utf8_binary(
  software_versions,
  file.path(out_root, "05_parameter_audit", "software_versions.csv")
)

reference_sources <- data.frame(
  source = c(
    "Reference article PDF",
    "Reference article official page",
    "scTenifoldKnk official release",
    "scTenifoldKnk original methods paper",
    "Upstream four-study QC script"
  ),
  location = c(
    "C:/Users/Lin/Downloads/fimmu-17-1827555.pdf",
    "https://www.frontiersin.org/journals/immunology/articles/10.3389/fimmu.2026.1827555/full",
    "https://github.com/cailab-tamu/scTenifoldKnk/releases/tag/v.1.0.3",
    "https://pubmed.ncbi.nlm.nih.gov/35510185/",
    "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u53c2\u8003\u811a\u672c/\u5355\u7ec6\u80de/02_\u8ba1\u7b97_\u56db\u7814\u7a76\u5168\u90e8\u4eba\u7fa4.R"
  ),
  use = c(
    "Figure 8E/F layout and method wording",
    "Method and figure caption verification",
    "Pinned software version",
    "Algorithm interpretation",
    "Inherited strict cell-QC thresholds"
  ),
  stringsAsFactors = FALSE
)
reference_sources <- mark_utf8(reference_sources)
write_csv_utf8_binary(
  reference_sources,
  file.path(out_root, "05_parameter_audit", "reference_sources.csv")
)

qa_rows <- list()
add_qa <- function(check_id, check_name, expected, observed, pass, severity, note) {
  qa_rows[[length(qa_rows) + 1L]] <<- data.frame(
    check_id = check_id,
    check_name = check_name,
    expected = as.character(expected),
    observed = as.character(observed),
    pass = as.logical(pass),
    severity = severity,
    note = note,
    stringsAsFactors = FALSE
  )
}

add_qa("Q01", "Strict-QC cell count", 14188, input_manifest$strict_qc_cells,
       input_manifest$strict_qc_cells == 14188L, "critical", "Must match upstream audit script.")
overall_qc <- cohort_qc[cohort_qc$group_type == "overall", , drop = FALSE]
add_qa("Q02", "GDF15 detected cells", 90, overall_qc$gdf15_detected_cells,
       overall_qc$gdf15_detected_cells == 90, "critical", "Raw-count detection after strict QC.")
add_qa("Q03", "Preferred GDF15 detection rate", ">=5%",
       sprintf("%.3f%%", overall_qc$gdf15_detection_pct),
       overall_qc$gdf15_detection_pct >= 5, "warning",
       "Expected warning: target is rare; result remains exploratory.")
add_qa("Q04", "Network input dimensions", "1501 x 14188",
       paste(input_manifest$network_dimensions, collapse = " x "),
       identical(as.integer(input_manifest$network_dimensions), c(1501L, 14188L)),
       "critical", "Prepared pool: 1500 HVGs plus GDF15.")
add_qa("Q05", "Differential-regulation gene count", rp$network_gene_nodes, nrow(diff_reg),
       nrow(diff_reg) == rp$network_gene_nodes, "critical", "One row per actual pilot network gene.")
add_qa("Q06", "Unique differential-regulation genes", rp$network_gene_nodes, length(unique(diff_reg$gene)),
       length(unique(diff_reg$gene)) == rp$network_gene_nodes, "critical", "No duplicated genes.")
add_qa("Q07", "Finite distance and FC", "all finite",
       sum(!is.finite(diff_reg$distance) | !is.finite(diff_reg$FC)),
       all(is.finite(diff_reg$distance)) && all(is.finite(diff_reg$FC)),
       "critical", "No NA/NaN/Inf in primary statistics.")
add_qa("Q08", "Nonnegative FC", "all >=0", min(diff_reg$FC, na.rm = TRUE),
       all(diff_reg$FC >= 0, na.rm = TRUE), "critical",
       "scTenifoldKnk FC is a non-directional displacement statistic.")
add_qa("Q09", "P values in [0,1]", "all within range",
       sprintf("p=%s..%s; FDR=%s..%s",
               signif(min(diff_reg$p.value), 3), signif(max(diff_reg$p.value), 3),
               signif(min(diff_reg$p.adj), 3), signif(max(diff_reg$p.adj), 3)),
       all(diff_reg$p.value >= 0 & diff_reg$p.value <= 1) &&
         all(diff_reg$p.adj >= 0 & diff_reg$p.adj <= 1),
       "critical", "Probability bounds.")
add_qa("Q10", "KO target row is zero", TRUE,
       all(result$tensorNetworks$KO["GDF15", ] == 0),
       all(result$tensorNetworks$KO["GDF15", ] == 0),
       "critical", "Core virtual-knockout implementation check.")
delta <- result$tensorNetworks$WT - result$tensorNetworks$KO
target_row <- match("GDF15", rownames(delta))
changed_index <- which(as.matrix(delta) != 0, arr.ind = TRUE)
changed_rows <- if (nrow(changed_index) == 0L) integer() else unique(changed_index[, 1L])
add_qa("Q11", "Only GDF15 outgoing row altered", target_row,
       paste(changed_rows, collapse = ","),
       length(changed_rows) == 1L && identical(changed_rows, target_row),
       "critical", "KO should zero only the GDF15 row before manifold alignment.")
add_qa("Q12", "Panel E has 20 genes and excludes GDF15", "20; no GDF15",
       paste(nrow(top20), "rows; GDF15=", "GDF15" %in% top20$gene),
       nrow(top20) == 20L && !"GDF15" %in% top20$gene,
       "critical", "Reference-style panel requirement.")
add_qa("Q13", "Panel F has 15 terms", 15, nrow(panel_f),
       nrow(panel_f) == 15L, "warning",
       "May be fewer if KEGG annotation retrieval fails or a category has no terms.")

figure_files <- c(
  "Panel_E_GDF15_virtual_KO_top20_reference_style.pdf",
  "Panel_E_GDF15_virtual_KO_top20_reference_style.svg",
  "Panel_E_GDF15_virtual_KO_top20_reference_style.png",
  "Panel_F_GDF15_virtual_KO_enrichment_reference_style.pdf",
  "Panel_F_GDF15_virtual_KO_enrichment_reference_style.svg",
  "Panel_F_GDF15_virtual_KO_enrichment_reference_style.png",
  "Panels_EF_GDF15_virtual_KO_reference_style.pdf",
  "Panels_EF_GDF15_virtual_KO_reference_style.svg",
  "Panels_EF_GDF15_virtual_KO_reference_style.png"
)
figure_paths <- file.path(out_root, "04_figures", figure_files)
figure_sizes <- ifelse(file.exists(figure_paths), file.info(figure_paths)$size, 0)
add_qa("Q14", "All PDF/SVG/PNG outputs exist and are nonempty",
       paste(length(figure_files), "files > 10 KB"),
       paste(sum(figure_sizes > 10000), "files > 10 KB"),
       all(figure_sizes > 10000), "critical", "Ensures all requested export formats were written.")

qa <- do.call(rbind, qa_rows)
qa <- mark_utf8(qa)
overall_status <- if (any(!qa$pass & qa$severity == "critical")) {
  "FAIL"
} else if (any(!qa$pass & qa$severity == "warning")) {
  "PASS_WITH_WARNINGS"
} else {
  "PASS"
}
qa$overall_run_status <- overall_status
write_csv_utf8_binary(
  qa,
  file.path(out_root, "06_qa", "QA_checks.csv")
)

analysis_summary <- data.frame(
  item = c(
    "run_status", "analysis_label", "strict_QC_cells", "GDF15_detected_cells",
    "GDF15_detection_pct", "network_genes", "FDR_lt_0.05_genes",
    "top5_perturbed_genes", "Panel_F_terms", "critical_QA_failures", "QA_warnings"
  ),
  value = c(
    overall_status,
    "Exploratory first pass due to low GDF15 detection",
    input_manifest$strict_qc_cells,
    overall_qc$gdf15_detected_cells,
    sprintf("%.4f", overall_qc$gdf15_detection_pct),
    nrow(diff_reg),
    sum(diff_reg$p.adj < 0.05, na.rm = TRUE),
    paste(head(top20$gene, 5), collapse = ", "),
    nrow(panel_f),
    sum(!qa$pass & qa$severity == "critical"),
    sum(!qa$pass & qa$severity == "warning")
  ),
  stringsAsFactors = FALSE
)
analysis_summary <- mark_utf8(analysis_summary)
write_csv_utf8_binary(
  analysis_summary,
  file.path(out_root, "05_parameter_audit", "analysis_summary.csv")
)

cat("QA status:", overall_status, "\n")
cat("Self-defined parameters:", nrow(self_set), "of", nrow(all_parameters), "\n")
cat("Critical failures:", sum(!qa$pass & qa$severity == "critical"), "\n")
cat("Warnings:", sum(!qa$pass & qa$severity == "warning"), "\n")
