options(stringsAsFactors = FALSE, warn = 1, future.globals.maxSize = 8 * 1024^3)

local_lib <- Sys.getenv("VITDKO_R_LIB", unset = "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_enrichment")
.libPaths(c(local_lib, .libPaths()))

suppressPackageStartupMessages({
  library(Matrix)
  library(scTenifoldKnk)
})

out_root <- Sys.getenv("VITDKO_OUT_ROOT", unset = "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260821_GDF15\u865a\u62df\u6572\u9664_scTenifoldKnk_\u9996\u7248")
input_file <- file.path(
  out_root, "01_input_qc",
  "network_input_log1p_CP10K_1500HVG_plus_GDF15.rds"
)
dir.create(file.path(out_root, "02_virtual_ko"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(out_root, "06_qa"), recursive = TRUE, showWarnings = FALSE)

log_file <- file.path(out_root, "06_qa", "02_scTenifoldKnk_run.log")
sink(log_file, split = TRUE)
on.exit(sink(), add = TRUE)

stopifnot(file.exists(input_file))
network_input <- readRDS(input_file)
stopifnot(inherits(network_input, "dgCMatrix"))
stopifnot("GDF15" %in% rownames(network_input))
stopifnot(nrow(network_input) == 1501L, ncol(network_input) == 14188L)
stopifnot(all(is.finite(network_input@x)), all(network_input@x >= 0))
stopifnot(Matrix::nnzero(network_input["GDF15", ]) > 0)

run_parameters <- list(
  target = "GDF15",
  random_seed = 20260821L,
  qc = FALSE,
  nc_lambda = 0,
  nc_nNet = 10L,
  nc_nCells = 500L,
  nc_nComp = 3L,
  nc_scaleScores = TRUE,
  nc_symmetric = FALSE,
  nc_q = 0.90,
  td_K = 3L,
  td_maxIter = 1000L,
  td_maxError = 1e-5,
  td_nDecimal = 3L,
  ma_nDim = 2L,
  nCores = 4L
)

set.seed(run_parameters$random_seed)
started_at <- Sys.time()
cat("Started scTenifoldKnk:", format(started_at, "%Y-%m-%d %H:%M:%S %z"), "\n")
cat("Input:", nrow(network_input), "genes x", ncol(network_input), "cells\n")
cat("Target GDF15 nonzero cells:", Matrix::nnzero(network_input["GDF15", ]), "\n")
print(run_parameters)

result <- scTenifoldKnk::scTenifoldKnk(
  countMatrix = network_input,
  qc = run_parameters$qc,
  gKO = run_parameters$target,
  nc_lambda = run_parameters$nc_lambda,
  nc_nNet = run_parameters$nc_nNet,
  nc_nCells = run_parameters$nc_nCells,
  nc_nComp = run_parameters$nc_nComp,
  nc_scaleScores = run_parameters$nc_scaleScores,
  nc_symmetric = run_parameters$nc_symmetric,
  nc_q = run_parameters$nc_q,
  td_K = run_parameters$td_K,
  td_maxIter = run_parameters$td_maxIter,
  td_maxError = run_parameters$td_maxError,
  td_nDecimal = run_parameters$td_nDecimal,
  ma_nDim = run_parameters$ma_nDim,
  nCores = run_parameters$nCores
)

finished_at <- Sys.time()
runtime_minutes <- as.numeric(difftime(finished_at, started_at, units = "mins"))
cat("Finished scTenifoldKnk:", format(finished_at, "%Y-%m-%d %H:%M:%S %z"), "\n")
cat(sprintf("Runtime: %.3f minutes\n", runtime_minutes))

stopifnot(all(c("tensorNetworks", "manifoldAlignment", "diffRegulation") %in% names(result)))
stopifnot(all(c("WT", "KO") %in% names(result$tensorNetworks)))
stopifnot(identical(rownames(result$tensorNetworks$WT), rownames(result$tensorNetworks$KO)))
stopifnot(all(result$tensorNetworks$KO["GDF15", ] == 0))

saveRDS(
  result,
  file.path(out_root, "02_virtual_ko", "scTenifoldKnk_GDF15_full_result.rds"),
  compress = "gzip"
)

diff_reg <- as.data.frame(result$diffRegulation, stringsAsFactors = FALSE)
expected_columns <- c("gene", "distance", "Z", "FC", "p.value", "p.adj")
stopifnot(all(expected_columns %in% colnames(diff_reg)))
diff_reg <- diff_reg[order(diff_reg$p.adj, -diff_reg$FC, diff_reg$gene), , drop = FALSE]
diff_reg$rank_by_FDR_then_FC <- seq_len(nrow(diff_reg))
diff_reg$FDR_lt_0_05 <- diff_reg$p.adj < 0.05
diff_reg$log10_FC_plus_1 <- log10(diff_reg$FC + 1)
write.csv(
  diff_reg,
  file.path(out_root, "02_virtual_ko", "GDF15_differential_regulation_all_genes.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

run_manifest <- data.frame(
  metric = c(
    "started_at", "finished_at", "runtime_minutes", "R_version",
    "scTenifoldKnk_version", "scTenifoldNet_version", "input_genes", "input_cells",
    "target_nonzero_cells", "result_genes", "FDR_lt_0_05_genes",
    "WT_network_nonzero_edges", "KO_network_nonzero_edges"
  ),
  value = c(
    format(started_at, "%Y-%m-%d %H:%M:%S %z"),
    format(finished_at, "%Y-%m-%d %H:%M:%S %z"),
    sprintf("%.6f", runtime_minutes),
    R.version.string,
    as.character(packageVersion("scTenifoldKnk")),
    as.character(packageVersion("scTenifoldNet")),
    nrow(network_input), ncol(network_input),
    Matrix::nnzero(network_input["GDF15", ]),
    nrow(diff_reg), sum(diff_reg$FDR_lt_0_05, na.rm = TRUE),
    Matrix::nnzero(result$tensorNetworks$WT),
    Matrix::nnzero(result$tensorNetworks$KO)
  ),
  stringsAsFactors = FALSE
)
write.csv(
  run_manifest,
  file.path(out_root, "02_virtual_ko", "run_manifest.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

saveRDS(
  list(parameters = run_parameters, manifest = run_manifest),
  file.path(out_root, "02_virtual_ko", "run_parameters_and_manifest.rds")
)

writeLines(
  capture.output(sessionInfo()),
  file.path(out_root, "06_qa", "R_sessionInfo.txt"),
  useBytes = TRUE
)

rm(network_input)
invisible(gc())
