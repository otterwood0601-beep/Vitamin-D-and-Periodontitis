from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
import os
import pickle
import platform
import shutil
import sys
import time
from collections import defaultdict
from pathlib import Path
import h5py
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
import seaborn as sns
import sklearn
import torch
import umap
from scipy.stats import ranksums
from sklearn.model_selection import train_test_split
from torch.optim import AdamW
from torch.utils.data import DataLoader
from transformers import get_linear_schedule_with_warmup
from geneformer_core import AXIS_PRIORITY, DICT_DIR, ECM_PRIORITY, GDF15_ENSEMBL, GDF15_TOKEN_ID, MAPK_PRIORITY, MAX_LENGTH, MODEL_DIR, SEED, TokenArrayDataset, batch_embeddings, bh_fdr, bootstrap_mean_ci, classifier_metrics, collate_tokens, cosine_to_centroid, embed_variable_sequences, freeze_lower_layers, load_classifier, mean_pool, priority_class, set_deterministic, state_shift, stratified_sample_indices, write_json
ROOT = Path('/work')
DATA_ROOT = Path('/data')
H5AD_PATH = DATA_ROOT / '\u539f\u59cb\u6570\u636e/05_\u5355\u7ec6\u80deRNA/01_scRNA-seq/CELLxGENE_Integrated_Periodontitis_Atlas/processed/Integrated_Human_Periodontitis_Atlas_105918cells.h5ad'
STRICT_META = DATA_ROOT / '\u8f93\u51fa\u7ed3\u679c/20260821_GDF15\u865a\u62df\u6572\u9664_scTenifoldKnk_\u9996\u7248/01_input_qc/strict_QC_cell_metadata.csv'
ECM_META = DATA_ROOT / '\u8f93\u51fa\u7ed3\u679c/20260904_CellOracle_GDF15_ERK_MAPK_ECM\u4e3b\u7ebf\u4e0eGDF15\u652f\u7ebf_v1/01_input_qc/08_prepared_cell_metadata.csv'
TOKEN_DIR = ROOT / '01_\u8f93\u5165\u4e0eGeneformer\u5206\u8bcd'
MODEL_OUT = ROOT / '02_\u72b6\u6001\u5206\u7c7b\u5668'
SCREEN_OUT = ROOT / '03_\u5168\u57fa\u56e0\u865a\u62df\u6572\u9664'
GDF_OUT = ROOT / '04_GDF15\u5b9a\u5411\u6270\u52a8'
FIG_OUT = ROOT / '05_\u8bba\u6587\u540c\u578b\u56fe'
NOTEBOOK_OUT = ROOT / '06_\u53ef\u590d\u73b0\u7b14\u8bb0\u672c'
QA_OUT = ROOT / '07_QA'
COHORTS = ['Williams', 'Caetano']
LABEL_TO_INT = {'normal': 0, 'periodontitis': 1}
INT_TO_LABEL = {0: 'normal', 1: 'periodontitis'}

def decode_strings(dataset) -> np.ndarray:
    values = dataset[:]
    if values.dtype.kind in {'S', 'O'}:
        return np.asarray([x.decode('utf-8') if isinstance(x, (bytes, bytearray)) else str(x) for x in values])
    return values.astype(str)

def file_sha256(path: Path, chunk_size: int=1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()

def load_dictionaries() -> tuple[dict, dict, dict, dict, dict]:
    with (DICT_DIR / 'ensembl_mapping_dict_gc30M.pkl').open('rb') as handle:
        mapping = pickle.load(handle)
    with (DICT_DIR / 'gene_median_dictionary_gc30M.pkl').open('rb') as handle:
        medians = pickle.load(handle)
    with (DICT_DIR / 'token_dictionary_gc30M.pkl').open('rb') as handle:
        token_dict = pickle.load(handle)
    with (DICT_DIR / 'gene_name_id_dict_gc30M.pkl').open('rb') as handle:
        symbol_to_ensembl = pickle.load(handle)
    ensembl_to_symbol: dict[str, str] = {}
    for symbol, ensembl in symbol_to_ensembl.items():
        ensembl_to_symbol.setdefault(ensembl, symbol)
    return (mapping, medians, token_dict, symbol_to_ensembl, ensembl_to_symbol)

def tokenize_cohort(cohort: str, metadata: pd.DataFrame, h5: h5py.File, var_ensembl: np.ndarray, mapping: dict, medians: dict, token_dict: dict) -> dict:
    cohort_dir = TOKEN_DIR / cohort
    cohort_dir.mkdir(parents=True, exist_ok=True)
    metadata = metadata.copy().sort_values(['h5ad_row', 'cell_id']).reset_index(drop=True)
    metadata['h5ad_row_python'] = metadata['h5ad_row'].astype(int) - 1
    metadata['dataset_index'] = np.arange(len(metadata), dtype=int)
    metadata['label'] = metadata['disease'].map(LABEL_TO_INT).astype(int)
    canonical = np.asarray([mapping.get(str(g).split('.')[0], str(g).split('.')[0]) for g in var_ensembl], dtype=object)
    var_tokens = np.asarray([token_dict.get(g, -1) for g in canonical], dtype=np.int32)
    var_medians = np.asarray([medians.get(g, np.nan) for g in canonical], dtype=np.float64)
    x_group = h5['raw/X']
    indptr = x_group['indptr'][:]
    indices_dataset = x_group['indices']
    data_dataset = x_group['data']
    obs_names = decode_strings(h5['obs/_index'])
    input_ids = np.zeros((len(metadata), MAX_LENGTH), dtype=np.int32)
    lengths = np.zeros(len(metadata), dtype=np.int16)
    mapped_gene_counts = np.zeros(len(metadata), dtype=np.int16)
    raw_gene_counts = np.zeros(len(metadata), dtype=np.int16)
    library_sizes = np.zeros(len(metadata), dtype=np.int32)
    gdf_ranks = np.full(len(metadata), -1, dtype=np.int16)
    mismatched_ids: list[dict] = []
    started = time.time()
    for i, row in metadata.iterrows():
        h5ad_row = int(row['h5ad_row_python'])
        observed_id = str(obs_names[h5ad_row])
        if observed_id != str(row['cell_id']):
            mismatched_ids.append({'dataset_index': i, 'h5ad_row_original_1_based': int(row['h5ad_row']), 'h5ad_row_python_0_based': h5ad_row, 'metadata_cell_id': row['cell_id'], 'h5ad_cell_id': observed_id})
        start = int(indptr[h5ad_row])
        end = int(indptr[h5ad_row + 1])
        feature_indices = indices_dataset[start:end]
        counts = data_dataset[start:end].astype(np.float64)
        raw_gene_counts[i] = min(len(counts), np.iinfo(np.int16).max)
        library_size = int(round(float(counts.sum())))
        library_sizes[i] = library_size
        valid = (var_tokens[feature_indices] >= 0) & np.isfinite(var_medians[feature_indices]) & (var_medians[feature_indices] > 0) & (counts > 0)
        if library_size <= 0 or not valid.any():
            continue
        feature_indices = feature_indices[valid]
        counts = counts[valid]
        tokens = var_tokens[feature_indices]
        gene_medians = var_medians[feature_indices]
        unique_tokens, inverse = np.unique(tokens, return_inverse=True)
        collapsed_counts = np.bincount(inverse, weights=counts)
        if len(unique_tokens) != len(tokens):
            median_by_token = {}
            for tok, med in zip(tokens.tolist(), gene_medians.tolist()):
                median_by_token.setdefault(int(tok), float(med))
            collapsed_medians = np.asarray([median_by_token[int(tok)] for tok in unique_tokens], dtype=float)
        else:
            collapsed_medians = gene_medians
        rank_scores = collapsed_counts / library_size * 10000.0 / collapsed_medians
        order = np.argsort(-rank_scores, kind='mergesort')
        ranked_tokens = unique_tokens[order][:MAX_LENGTH]
        length = len(ranked_tokens)
        input_ids[i, :length] = ranked_tokens
        lengths[i] = length
        mapped_gene_counts[i] = min(len(unique_tokens), np.iinfo(np.int16).max)
        where_gdf = np.flatnonzero(ranked_tokens == GDF15_TOKEN_ID)
        if len(where_gdf):
            gdf_ranks[i] = int(where_gdf[0] + 1)
        if (i + 1) % 1000 == 0:
            print(f'[{cohort}] tokenized {i + 1}/{len(metadata)} cells in {(time.time() - started) / 60:.1f} min', flush=True)
    metadata['geneformer_length'] = lengths
    metadata['raw_detected_genes'] = raw_gene_counts
    metadata['mapped_geneformer_genes'] = mapped_gene_counts
    metadata['raw_library_size_recomputed'] = library_sizes
    metadata['GDF15_token_rank'] = gdf_ranks
    metadata['GDF15_token_present'] = gdf_ranks > 0
    np.save(cohort_dir / 'input_ids.npy', input_ids)
    np.save(cohort_dir / 'lengths.npy', lengths)
    np.save(cohort_dir / 'labels.npy', metadata['label'].to_numpy(dtype=np.int8))
    metadata.to_csv(cohort_dir / 'cell_metadata.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(mismatched_ids).to_csv(cohort_dir / 'cell_id_mismatches.csv', index=False, encoding='utf-8-sig')
    summary = {'cohort': cohort, 'cells': int(len(metadata)), 'normal_cells': int((metadata['disease'] == 'normal').sum()), 'periodontitis_cells': int((metadata['disease'] == 'periodontitis').sum()), 'median_token_length': float(np.median(lengths)), 'max_token_length': int(lengths.max()), 'GDF15_token_positive_all': int(metadata['GDF15_token_present'].sum()), 'GDF15_token_positive_periodontitis': int((metadata['GDF15_token_present'] & (metadata['disease'] == 'periodontitis')).sum()), 'cell_id_mismatches': int(len(mismatched_ids)), 'elapsed_minutes': float((time.time() - started) / 60)}
    write_json(cohort_dir / 'tokenization_summary.json', summary)
    return summary

def stage_tokenize() -> None:
    set_deterministic()
    TOKEN_DIR.mkdir(parents=True, exist_ok=True)
    metadata = pd.read_csv(STRICT_META)
    metadata = metadata.loc[metadata['Study'].isin(COHORTS) & metadata['disease'].isin(LABEL_TO_INT)].copy()
    metadata['h5ad_row'] = metadata['h5ad_row'].astype(int)
    mapping, medians, token_dict, symbol_to_ensembl, ensembl_to_symbol = load_dictionaries()
    with h5py.File(H5AD_PATH, 'r') as h5:
        var_ensembl = decode_strings(h5['raw/var/_index'])
        summaries = []
        for cohort in COHORTS:
            summaries.append(tokenize_cohort(cohort, metadata.loc[metadata['Study'] == cohort], h5, var_ensembl, mapping, medians, token_dict))
    token_to_ensembl = {int(token): ensembl for ensembl, token in token_dict.items() if isinstance(token, (int, np.integer)) and (not ensembl.startswith('<'))}
    token_reference = pd.DataFrame([{'token_id': token, 'Ensembl_ID': ensembl, 'Gene_name': ensembl_to_symbol.get(ensembl, ensembl), 'median': medians.get(ensembl)} for token, ensembl in sorted(token_to_ensembl.items())])
    token_reference.to_csv(TOKEN_DIR / 'Geneformer_V1_token_reference.csv', index=False, encoding='utf-8-sig')
    ecm_meta = pd.read_csv(ECM_META)
    williams_meta = pd.read_csv(TOKEN_DIR / 'Williams/cell_metadata.csv')
    ecm_map = williams_meta[['cell_id', 'dataset_index', 'GDF15_token_present', 'GDF15_token_rank']].merge(ecm_meta[['cell_id', 'fibroblast_state', 'fibroblast_type', 'Pseudotime', 'disease', 'donor_id']], on='cell_id', how='inner', validate='one_to_one')
    ecm_map.to_csv(TOKEN_DIR / 'Williams_ECM_lineage_dataset_indices.csv', index=False, encoding='utf-8-sig')
    manifest = {'source_h5ad': str(H5AD_PATH), 'source_h5ad_size_bytes': H5AD_PATH.stat().st_size, 'source_h5ad_sha256': file_sha256(H5AD_PATH), 'strict_metadata': str(STRICT_META), 'strict_metadata_sha256': file_sha256(STRICT_META), 'model': 'Geneformer V1 / Geneformer-V1-10M (30M-cell pretraining corpus)', 'model_path': str(MODEL_DIR), 'model_safetensors_sha256': file_sha256(MODEL_DIR / 'model.safetensors'), 'max_length': MAX_LENGTH, 'normalization': 'raw counts / total counts * 10000 / V1 gene median; descending rank', 'random_seed': SEED, 'cohorts': summaries}
    write_json(TOKEN_DIR / 'input_manifest.json', manifest)
    print(json.dumps(manifest, ensure_ascii=False, indent=2), flush=True)

def load_tokenized(cohort: str) -> tuple[np.ndarray, np.ndarray, np.ndarray, pd.DataFrame]:
    cohort_dir = TOKEN_DIR / cohort
    input_ids = np.load(cohort_dir / 'input_ids.npy', mmap_mode='r')
    lengths = np.load(cohort_dir / 'lengths.npy', mmap_mode='r')
    labels = np.load(cohort_dir / 'labels.npy', mmap_mode='r')
    metadata = pd.read_csv(cohort_dir / 'cell_metadata.csv')
    metadata.index = metadata['dataset_index'].astype(int)
    return (input_ids, lengths, labels, metadata)

def split_williams(metadata: pd.DataFrame) -> pd.Series:
    rng = np.random.default_rng(SEED)
    split = pd.Series(index=metadata.index, dtype=object)
    for label in [0, 1]:
        donors = sorted(metadata.loc[metadata['label'] == label, 'donor_id'].astype(str).unique().tolist())
        donors = list(rng.permutation(donors))
        n_test = max(1, int(round(len(donors) * 0.2)))
        n_val = max(1, int(round(len(donors) * 0.15)))
        test_donors = set(donors[:n_test])
        val_donors = set(donors[n_test:n_test + n_val])
        train_donors = set(donors[n_test + n_val:])
        label_rows = metadata['label'] == label
        split.loc[label_rows & metadata['donor_id'].astype(str).isin(train_donors)] = 'train'
        split.loc[label_rows & metadata['donor_id'].astype(str).isin(val_donors)] = 'validation'
        split.loc[label_rows & metadata['donor_id'].astype(str).isin(test_donors)] = 'test'
    return split

def split_caetano(metadata: pd.DataFrame) -> pd.Series:
    train_idx, temp_idx = train_test_split(metadata.index.to_numpy(), test_size=0.3, random_state=SEED, stratify=metadata['label'].to_numpy())
    val_idx, test_idx = train_test_split(temp_idx, test_size=0.5, random_state=SEED + 1, stratify=metadata.loc[temp_idx, 'label'].to_numpy())
    split = pd.Series(index=metadata.index, dtype=object)
    split.loc[train_idx] = 'train'
    split.loc[val_idx] = 'validation'
    split.loc[test_idx] = 'test'
    return split

def balanced_limit(metadata: pd.DataFrame, split_name: str, max_per_class: int, seed_offset: int) -> np.ndarray:
    rng = np.random.default_rng(SEED + seed_offset)
    selected: list[int] = []
    subset = metadata.loc[metadata['split'] == split_name]
    class_counts = subset['label'].value_counts()
    per_class = int(min(max_per_class, class_counts.min()))
    for label in [0, 1]:
        candidates = subset.index[subset['label'] == label].to_numpy(dtype=int)
        selected.extend(rng.choice(candidates, size=per_class, replace=False).tolist())
    rng.shuffle(selected)
    return np.asarray(selected, dtype=int)

def evaluate_model(model, input_ids, lengths, labels, indices, batch_size: int=8) -> tuple[dict, pd.DataFrame]:
    dataset = TokenArrayDataset(input_ids, lengths, labels, indices)
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False, collate_fn=collate_tokens)
    model.eval()
    probabilities: list[np.ndarray] = []
    observed: list[np.ndarray] = []
    dataset_indices: list[np.ndarray] = []
    losses: list[float] = []
    with torch.inference_mode():
        for batch in loader:
            outputs = model(input_ids=batch['input_ids'], attention_mask=batch['attention_mask'], labels=batch['labels'])
            probabilities.append(torch.softmax(outputs.logits, dim=1)[:, 1].cpu().numpy())
            observed.append(batch['labels'].cpu().numpy())
            dataset_indices.append(batch['dataset_index'])
            losses.append(float(outputs.loss.item()))
    probs = np.concatenate(probabilities)
    obs = np.concatenate(observed)
    idx = np.concatenate(dataset_indices)
    metrics = classifier_metrics(obs, probs)
    metrics['loss'] = float(np.mean(losses))
    predictions = pd.DataFrame({'dataset_index': idx, 'observed_label': obs, 'periodontitis_probability': probs, 'predicted_label': (probs >= 0.5).astype(int)})
    return (metrics, predictions)

def train_one_cohort(cohort: str) -> None:
    input_ids, lengths, labels, metadata = load_tokenized(cohort)
    cohort_dir = MODEL_OUT / cohort
    cohort_dir.mkdir(parents=True, exist_ok=True)
    metadata = metadata.copy()
    metadata['split'] = split_williams(metadata) if cohort == 'Williams' else split_caetano(metadata)
    if metadata['split'].isna().any():
        raise RuntimeError(f'Unassigned split rows in {cohort}')
    if cohort == 'Williams':
        train_idx = balanced_limit(metadata, 'train', 1000, 10)
        val_idx = balanced_limit(metadata, 'validation', 300, 11)
        test_idx = balanced_limit(metadata, 'test', 300, 12)
        epochs = 3
        split_strategy = 'donor-disjoint within each disease class'
    else:
        train_idx = balanced_limit(metadata, 'train', 10000, 20)
        val_idx = balanced_limit(metadata, 'validation', 10000, 21)
        test_idx = balanced_limit(metadata, 'test', 10000, 22)
        epochs = 6
        split_strategy = 'stratified cell split; only two donors per class, so donor-disjoint three-way split is impossible'
    metadata['used_for_training_run'] = metadata.index.isin(np.concatenate([train_idx, val_idx, test_idx]))
    metadata.to_csv(cohort_dir / 'data_splits.csv', index=False, encoding='utf-8-sig')
    best_dir = cohort_dir / 'best_model'
    manifest_path = cohort_dir / 'classifier_run_manifest.json'
    if best_dir.exists() and (not manifest_path.exists()):
        print(f'[{cohort}] recovering completed model from {best_dir}', flush=True)
        started = time.time()
        best_model = load_classifier(best_dir)
        val_metrics, val_predictions = evaluate_model(best_model, input_ids, lengths, labels, val_idx)
        test_metrics, test_predictions = evaluate_model(best_model, input_ids, lengths, labels, test_idx)
        val_predictions['split'] = 'validation'
        test_predictions['split'] = 'test'
        metadata_for_merge = metadata[['cell_id', 'donor_id', 'disease', 'dataset_index']].reset_index(drop=True)
        predictions = pd.concat([val_predictions, test_predictions], ignore_index=True).merge(metadata_for_merge, on='dataset_index', how='left')
        predictions.to_csv(cohort_dir / 'validation_and_test_predictions.csv', index=False, encoding='utf-8-sig')
        recovered_manifest = {'cohort': cohort, 'model_base': str(MODEL_DIR), 'model_version': 'Geneformer V1 / 6-layer / max 2048 token', 'split_strategy': split_strategy, 'seed': SEED, 'epochs': epochs, 'learning_rate': 5e-05, 'weight_decay': 0.001, 'warmup_fraction': 0.1, 'batch_size': 2, 'gradient_accumulation': 8, 'freeze_layers': 5, 'sample_counts': {'train': int(len(train_idx)), 'validation': int(len(val_idx)), 'test': int(len(test_idx))}, 'checkpoint_recovered_after_prediction_table_merge_error': True, 'validation_metrics': val_metrics, 'test_metrics': test_metrics, 'recovery_elapsed_minutes': (time.time() - started) / 60}
        write_json(manifest_path, recovered_manifest)
        print(json.dumps(recovered_manifest, ensure_ascii=False, indent=2), flush=True)
        return
    model = load_classifier(MODEL_DIR, trainable=True)
    freeze_info = freeze_lower_layers(model, freeze_layers=5)
    model.train()
    train_dataset = TokenArrayDataset(input_ids, lengths, labels, train_idx)
    train_loader = DataLoader(train_dataset, batch_size=2, shuffle=True, collate_fn=collate_tokens, generator=torch.Generator().manual_seed(SEED))
    optimizer = AdamW([p for p in model.parameters() if p.requires_grad], lr=5e-05, weight_decay=0.001)
    gradient_accumulation = 8
    update_steps_per_epoch = math.ceil(len(train_loader) / gradient_accumulation)
    total_updates = update_steps_per_epoch * epochs
    scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=max(1, int(0.1 * total_updates)), num_training_steps=total_updates)
    history: list[dict] = []
    best_val_loss = math.inf
    started = time.time()
    for epoch in range(1, epochs + 1):
        model.train()
        optimizer.zero_grad(set_to_none=True)
        running_losses: list[float] = []
        for step, batch in enumerate(train_loader, start=1):
            outputs = model(input_ids=batch['input_ids'], attention_mask=batch['attention_mask'], labels=batch['labels'])
            loss = outputs.loss / gradient_accumulation
            loss.backward()
            running_losses.append(float(outputs.loss.item()))
            if step % gradient_accumulation == 0 or step == len(train_loader):
                torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad], 1.0)
                optimizer.step()
                scheduler.step()
                optimizer.zero_grad(set_to_none=True)
            if step % 100 == 0:
                print(f'[{cohort}] epoch {epoch}/{epochs}, step {step}/{len(train_loader)}, mean loss {np.mean(running_losses[-100:]):.4f}', flush=True)
        val_metrics, _ = evaluate_model(model, input_ids, lengths, labels, val_idx)
        row = {'epoch': epoch, 'train_loss': float(np.mean(running_losses)), **{f'validation_{k}': v for k, v in val_metrics.items() if k != 'confusion_matrix'}}
        history.append(row)
        print(f'[{cohort}] epoch {epoch} complete: {row}', flush=True)
        if val_metrics['loss'] < best_val_loss:
            best_val_loss = val_metrics['loss']
            if best_dir.exists():
                shutil.rmtree(best_dir)
            model.save_pretrained(best_dir, safe_serialization=True)
    best_model = load_classifier(best_dir)
    val_metrics, val_predictions = evaluate_model(best_model, input_ids, lengths, labels, val_idx)
    test_metrics, test_predictions = evaluate_model(best_model, input_ids, lengths, labels, test_idx)
    val_predictions['split'] = 'validation'
    test_predictions['split'] = 'test'
    metadata_for_merge = metadata[['cell_id', 'donor_id', 'disease', 'dataset_index']].reset_index(drop=True)
    predictions = pd.concat([val_predictions, test_predictions], ignore_index=True).merge(metadata_for_merge, on='dataset_index', how='left')
    predictions.to_csv(cohort_dir / 'validation_and_test_predictions.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(history).to_csv(cohort_dir / 'training_history.csv', index=False, encoding='utf-8-sig')
    run_manifest = {'cohort': cohort, 'model_base': str(MODEL_DIR), 'model_version': 'Geneformer V1 / 6-layer / max 2048 token', 'split_strategy': split_strategy, 'seed': SEED, 'epochs': epochs, 'learning_rate': 5e-05, 'weight_decay': 0.001, 'warmup_fraction': 0.1, 'batch_size': 2, 'gradient_accumulation': gradient_accumulation, 'freeze_layers': 5, 'sample_counts': {'train': int(len(train_idx)), 'validation': int(len(val_idx)), 'test': int(len(test_idx))}, 'freeze_info': freeze_info, 'validation_metrics': val_metrics, 'test_metrics': test_metrics, 'elapsed_minutes': (time.time() - started) / 60}
    write_json(cohort_dir / 'classifier_run_manifest.json', run_manifest)
    print(json.dumps(run_manifest, ensure_ascii=False, indent=2), flush=True)

def stage_train() -> None:
    set_deterministic()
    MODEL_OUT.mkdir(parents=True, exist_ok=True)
    for cohort in COHORTS:
        train_one_cohort(cohort)

def select_embedding_sample(metadata: pd.DataFrame, max_per_class: int) -> np.ndarray:
    selected: list[int] = []
    for label in [0, 1]:
        group = metadata.loc[metadata['label'] == label]
        take = min(max_per_class, len(group))
        selected.extend(stratified_sample_indices(group, take, ['donor_id'], SEED + label).tolist())
    return np.asarray(selected, dtype=int)

def extract_embeddings_one_cohort(cohort: str) -> None:
    input_ids, lengths, labels, metadata = load_tokenized(cohort)
    cohort_dir = MODEL_OUT / cohort
    if (cohort_dir / 'embedding_manifest.json').exists() and (cohort_dir / 'state_centroids.npz').exists():
        print(f'[{cohort}] embedding outputs already complete; skipping', flush=True)
        return
    sample_indices = select_embedding_sample(metadata, 600 if cohort == 'Williams' else 10000)
    pretrained_model = load_classifier(MODEL_DIR)
    finetuned_model = load_classifier(cohort_dir / 'best_model')
    started = time.time()
    pretrained_emb = batch_embeddings(pretrained_model, input_ids, lengths, sample_indices, batch_size=8)
    print(f'[{cohort}] pretrained embeddings complete', flush=True)
    finetuned_emb = batch_embeddings(finetuned_model, input_ids, lengths, sample_indices, batch_size=8)
    print(f'[{cohort}] finetuned embeddings complete', flush=True)
    sample_meta = metadata.loc[sample_indices].copy().reset_index(drop=True)
    reducer_pre = umap.UMAP(n_neighbors=15, min_dist=0.3, metric='cosine', random_state=SEED, n_jobs=1)
    reducer_post = umap.UMAP(n_neighbors=15, min_dist=0.3, metric='cosine', random_state=SEED, n_jobs=1)
    pre_umap = reducer_pre.fit_transform(pretrained_emb)
    post_umap = reducer_post.fit_transform(finetuned_emb)
    sample_meta['UMAP1_pretrained'] = pre_umap[:, 0]
    sample_meta['UMAP2_pretrained'] = pre_umap[:, 1]
    sample_meta['UMAP1_finetuned'] = post_umap[:, 0]
    sample_meta['UMAP2_finetuned'] = post_umap[:, 1]
    sample_meta.to_csv(cohort_dir / 'embedding_umap_coordinates.csv', index=False, encoding='utf-8-sig')
    np.savez_compressed(cohort_dir / 'embedding_samples.npz', dataset_indices=sample_indices, pretrained_embeddings=pretrained_emb, finetuned_embeddings=finetuned_emb, labels=labels[sample_indices])
    centroids = {}
    for name, label in LABEL_TO_INT.items():
        centroids[name] = finetuned_emb[labels[sample_indices] == label].mean(axis=0).astype(np.float32)
    np.savez_compressed(cohort_dir / 'state_centroids.npz', **centroids)
    write_json(cohort_dir / 'embedding_manifest.json', {'cohort': cohort, 'sample_cells': int(len(sample_indices)), 'sample_normal': int((labels[sample_indices] == 0).sum()), 'sample_periodontitis': int((labels[sample_indices] == 1).sum()), 'embedding_layer': 'last transformer layer (emb_layer=0 in Geneformer convention)', 'cell_embedding': 'attention-mask mean pooling', 'UMAP': {'n_neighbors': 15, 'min_dist': 0.3, 'metric': 'cosine', 'random_state': SEED}, 'elapsed_minutes': (time.time() - started) / 60})

def stage_embed() -> None:
    set_deterministic()
    for cohort in COHORTS:
        extract_embeddings_one_cohort(cohort)

def load_token_reference() -> tuple[pd.DataFrame, dict[int, str], dict[int, str]]:
    reference = pd.read_csv(TOKEN_DIR / 'Geneformer_V1_token_reference.csv')
    reference['token_id'] = reference['token_id'].astype(int)
    token_to_gene = dict(zip(reference['token_id'], reference['Gene_name'].astype(str)))
    token_to_ensembl = dict(zip(reference['token_id'], reference['Ensembl_ID'].astype(str)))
    return (reference, token_to_gene, token_to_ensembl)

def contextual_one_pass_screen(model, input_ids: np.ndarray, lengths: np.ndarray, metadata: pd.DataFrame, screen_indices: np.ndarray, goal_centroid: np.ndarray, start_centroid: np.ndarray, token_to_gene: dict[int, str], token_to_ensembl: dict[int, str]) -> tuple[pd.DataFrame, dict[int, np.ndarray]]:
    goal = torch.as_tensor(goal_centroid, dtype=torch.float32).reshape(1, -1)
    start = torch.as_tensor(start_centroid, dtype=torch.float32).reshape(1, -1)
    records: dict[int, dict[str, list[float]]] = defaultdict(lambda: {'goal': [], 'start': []})
    original_embeddings: dict[int, np.ndarray] = {}
    model.eval()
    with torch.inference_mode():
        for count, idx in enumerate(screen_indices, start=1):
            length = int(lengths[idx])
            ids = torch.as_tensor(input_ids[idx, :length], dtype=torch.long).unsqueeze(0)
            mask = torch.ones_like(ids)
            hidden = model.bert(input_ids=ids, attention_mask=mask, return_dict=True).last_hidden_state[0]
            original = hidden.mean(dim=0, keepdim=True)
            original_embeddings[int(idx)] = original.cpu().numpy()[0].astype(np.float32)
            if length <= 1:
                continue
            approximate_deleted = (hidden.sum(dim=0, keepdim=True) - hidden) / float(length - 1)
            original_goal = torch.nn.functional.cosine_similarity(original, goal, dim=1)[0]
            original_start = torch.nn.functional.cosine_similarity(original, start, dim=1)[0]
            goal_shift = torch.nn.functional.cosine_similarity(approximate_deleted, goal.expand(length, -1), dim=1) - original_goal
            start_shift = torch.nn.functional.cosine_similarity(approximate_deleted, start.expand(length, -1), dim=1) - original_start
            tokens = input_ids[idx, :length].astype(int)
            for token, shift_goal, shift_start in zip(tokens.tolist(), goal_shift.cpu().tolist(), start_shift.cpu().tolist()):
                records[int(token)]['goal'].append(float(shift_goal))
                records[int(token)]['start'].append(float(shift_start))
            if count % 8 == 0 or count == len(screen_indices):
                print(f'one-pass screen: {count}/{len(screen_indices)} cells', flush=True)
    rows = []
    for token, values in records.items():
        goal_values = np.asarray(values['goal'], dtype=float)
        start_values = np.asarray(values['start'], dtype=float)
        rows.append({'Gene': token, 'Gene_name': token_to_gene.get(token, str(token)), 'Ensembl_ID': token_to_ensembl.get(token, ''), 'N_Detections': len(goal_values), 'Shift_to_goal_end': float(goal_values.mean()), 'Shift_away_start_end': float(start_values.mean()), 'Desirability_score': float(goal_values.mean() - start_values.mean()), 'Approx_abs_effect': float(np.hypot(goal_values.mean(), start_values.mean()))})
    result = pd.DataFrame(rows)
    result['Priority_class'] = result['Gene_name'].map(priority_class)
    result = result.sort_values(['Desirability_score', 'N_Detections'], ascending=[False, False]).reset_index(drop=True)
    return (result, original_embeddings)

def choose_exact_candidates(approximate: pd.DataFrame, target_count: int=430) -> pd.DataFrame:
    eligible = approximate.loc[approximate['N_Detections'] >= 2].copy()
    selected_tokens: list[int] = []

    def add_tokens(frame: pd.DataFrame, n: int | None=None) -> None:
        values = frame['Gene'].astype(int).tolist() if n is None else frame.head(n)['Gene'].astype(int).tolist()
        for token in values:
            if token not in selected_tokens:
                selected_tokens.append(token)
    add_tokens(eligible.loc[eligible['Priority_class'] != 'Other'].sort_values('Approx_abs_effect', ascending=False))
    add_tokens(eligible.sort_values('Desirability_score', ascending=False), 180)
    add_tokens(eligible.sort_values('Desirability_score', ascending=True), 100)
    add_tokens(eligible.sort_values('Approx_abs_effect', ascending=False), 100)
    fill = eligible.sort_values(['N_Detections', 'Approx_abs_effect'], ascending=[False, False])
    add_tokens(fill, target_count * 2)
    selected_tokens = selected_tokens[:target_count]
    selected = approximate.loc[approximate['Gene'].isin(selected_tokens)].copy()
    selected['Exact_screen_selected'] = True
    selected['Exact_selection_order'] = selected['Gene'].map({token: i + 1 for i, token in enumerate(selected_tokens)})
    return selected.sort_values('Exact_selection_order')

def exact_delete_screen(cohort: str, model, input_ids: np.ndarray, lengths: np.ndarray, metadata: pd.DataFrame, screen_indices: np.ndarray, candidates: pd.DataFrame, original_embeddings: dict[int, np.ndarray], goal_centroid: np.ndarray, start_centroid: np.ndarray) -> tuple[pd.DataFrame, pd.DataFrame]:
    cohort_dir = SCREEN_OUT / cohort
    candidate_tokens = set(candidates['Gene'].astype(int).tolist())
    checkpoint_path = cohort_dir / 'exact_delete_cell_level_checkpoint.pkl'
    if checkpoint_path.exists():
        with checkpoint_path.open('rb') as handle:
            checkpoint = pickle.load(handle)
        records = checkpoint.get('records', [])
        completed = set(checkpoint.get('completed_indices', []))
        print(f'[{cohort}] resumed exact deletion from {len(completed)} completed cells', flush=True)
    else:
        records = []
        completed = set()
    for cell_number, idx in enumerate(screen_indices, start=1):
        idx = int(idx)
        if idx in completed:
            continue
        length = int(lengths[idx])
        sequence = input_ids[idx, :length].astype(np.int64)
        positions = [position for position, token in enumerate(sequence.tolist()) if int(token) in candidate_tokens]
        if positions:
            perturbed_sequences = [np.delete(sequence, position) for position in positions]
            perturbed_embeddings = embed_variable_sequences(model, perturbed_sequences, batch_size=8)
            original = np.repeat(original_embeddings[idx][None, :], len(positions), axis=0)
            shift_goal, shift_start = state_shift(original, perturbed_embeddings, goal_centroid, start_centroid)
            row_meta = metadata.loc[idx]
            for position, x_shift, y_shift in zip(positions, shift_goal.tolist(), shift_start.tolist()):
                records.append({'cohort': cohort, 'dataset_index': idx, 'cell_id': row_meta['cell_id'], 'donor_id': row_meta['donor_id'], 'disease': row_meta['disease'], 'Gene': int(sequence[position]), 'Shift_to_goal_end': float(x_shift), 'Shift_away_start_end': float(y_shift)})
        completed.add(idx)
        if cell_number % 4 == 0 or cell_number == len(screen_indices):
            with checkpoint_path.open('wb') as handle:
                pickle.dump({'records': records, 'completed_indices': sorted(completed)}, handle)
            print(f'[{cohort}] exact deletion {len(completed)}/{len(screen_indices)} cells; {len(records)} perturbations', flush=True)
    cell_level = pd.DataFrame(records)
    cell_level = cell_level.merge(candidates[['Gene', 'Gene_name', 'Ensembl_ID', 'Priority_class']], on='Gene', how='left')
    pooled_goal = cell_level['Shift_to_goal_end'].to_numpy(dtype=float)
    pooled_start = cell_level['Shift_away_start_end'].to_numpy(dtype=float)
    if len(pooled_goal) > 100000:
        rng = np.random.default_rng(SEED)
        pooled_goal = rng.choice(pooled_goal, size=100000, replace=False)
        pooled_start = rng.choice(pooled_start, size=100000, replace=False)
    summaries = []
    for token, group in cell_level.groupby('Gene', sort=False):
        x_values = group['Shift_to_goal_end'].to_numpy(dtype=float)
        y_values = group['Shift_away_start_end'].to_numpy(dtype=float)
        summaries.append({'Gene': int(token), 'Gene_name': group['Gene_name'].iloc[0], 'Ensembl_ID': group['Ensembl_ID'].iloc[0], 'Priority_class': group['Priority_class'].iloc[0], 'N_Detections': int(len(group)), 'Shift_to_goal_end': float(x_values.mean()), 'Shift_away_start_end': float(y_values.mean()), 'Goal_end_vs_random_pval': float(ranksums(pooled_goal, x_values).pvalue), 'Start_end_vs_random_pval': float(ranksums(pooled_start, y_values).pvalue), 'Desirability_score': float(x_values.mean() - y_values.mean())})
    summary = pd.DataFrame(summaries)
    summary['Goal_end_FDR'] = bh_fdr(summary['Goal_end_vs_random_pval'])
    summary['Start_end_FDR'] = bh_fdr(summary['Start_end_vs_random_pval'])
    summary['Sig_goal_FDR_0.05'] = summary['Goal_end_FDR'] < 0.05
    summary['Desired_quadrant'] = (summary['Shift_to_goal_end'] > 0) & (summary['Shift_away_start_end'] < 0)
    summary = summary.sort_values(['Desired_quadrant', 'Desirability_score'], ascending=[False, False]).reset_index(drop=True)
    return (cell_level, summary)

def exact_single_gene_effect(model, input_ids: np.ndarray, lengths: np.ndarray, metadata: pd.DataFrame, indices: np.ndarray, token_id: int, goal_centroid: np.ndarray, start_centroid: np.ndarray, mode: str) -> pd.DataFrame:
    original_sequences: list[np.ndarray] = []
    perturbed_sequences: list[np.ndarray] = []
    retained_indices: list[int] = []
    for idx in indices:
        idx = int(idx)
        length = int(lengths[idx])
        sequence = input_ids[idx, :length].astype(np.int64)
        if mode == 'delete':
            positions = np.flatnonzero(sequence == token_id)
            if len(positions) == 0:
                continue
            perturbed = np.delete(sequence, int(positions[0]))
        elif mode == 'overexpress':
            if token_id in sequence:
                sequence_without = sequence[sequence != token_id]
            else:
                sequence_without = sequence
            perturbed = np.concatenate([np.asarray([token_id], dtype=np.int64), sequence_without])[:MAX_LENGTH]
        else:
            raise ValueError(mode)
        original_sequences.append(sequence)
        perturbed_sequences.append(perturbed)
        retained_indices.append(idx)
    if not retained_indices:
        return pd.DataFrame()
    original_embeddings = embed_variable_sequences(model, original_sequences, batch_size=8)
    perturbed_embeddings = embed_variable_sequences(model, perturbed_sequences, batch_size=8)
    shift_goal, shift_start = state_shift(original_embeddings, perturbed_embeddings, goal_centroid, start_centroid)
    result = metadata.loc[retained_indices, ['cell_id', 'donor_id', 'disease', 'dataset_index']].copy().reset_index(drop=True)
    result['perturbation'] = mode
    result['Gene'] = token_id
    result['Gene_name'] = 'GDF15'
    result['Ensembl_ID'] = GDF15_ENSEMBL
    result['Shift_to_goal_end'] = shift_goal
    result['Shift_away_start_end'] = shift_start
    result['Desirability_score'] = shift_goal - shift_start
    return result

def summarize_gdf_effect(cohort: str, context: str, mode: str, cell_level: pd.DataFrame) -> dict:
    if cell_level.empty:
        return {'cohort': cohort, 'context': context, 'perturbation': mode, 'N_cells': 0, 'N_donors': 0, 'Shift_to_goal_end': None, 'Shift_away_start_end': None, 'Desired_quadrant': None}
    x = cell_level['Shift_to_goal_end'].to_numpy(dtype=float)
    y = cell_level['Shift_away_start_end'].to_numpy(dtype=float)
    x_low, x_high = bootstrap_mean_ci(x, SEED)
    y_low, y_high = bootstrap_mean_ci(y, SEED + 1)
    return {'cohort': cohort, 'context': context, 'perturbation': mode, 'N_cells': int(len(cell_level)), 'N_donors': int(cell_level['donor_id'].nunique()), 'Shift_to_goal_end': float(x.mean()), 'Shift_to_goal_CI95_low': x_low, 'Shift_to_goal_CI95_high': x_high, 'Shift_away_start_end': float(y.mean()), 'Shift_away_start_CI95_low': y_low, 'Shift_away_start_CI95_high': y_high, 'Desirability_score': float((x - y).mean()), 'Desired_quadrant': bool(x.mean() > 0 and y.mean() < 0)}

def perturb_one_cohort(cohort: str) -> None:
    input_ids, lengths, labels, metadata = load_tokenized(cohort)
    model = load_classifier(MODEL_OUT / cohort / 'best_model')
    centroids = np.load(MODEL_OUT / cohort / 'state_centroids.npz')
    goal_centroid = centroids['normal']
    start_centroid = centroids['periodontitis']
    _, token_to_gene, token_to_ensembl = load_token_reference()
    cohort_dir = SCREEN_OUT / cohort
    cohort_dir.mkdir(parents=True, exist_ok=True)
    disease_meta = metadata.loc[metadata['label'] == 1]
    screen_indices = stratified_sample_indices(disease_meta, min(48, len(disease_meta)), ['donor_id'], SEED)
    screen_metadata = metadata[['dataset_index', 'cell_id', 'donor_id', 'disease']].reset_index(drop=True)
    pd.DataFrame({'dataset_index': screen_indices}).merge(screen_metadata, on='dataset_index', how='left').to_csv(cohort_dir / 'screen_cells.csv', index=False, encoding='utf-8-sig')
    started = time.time()
    approximate, original_embeddings = contextual_one_pass_screen(model, input_ids, lengths, metadata, screen_indices, goal_centroid, start_centroid, token_to_gene, token_to_ensembl)
    approximate.to_csv(cohort_dir / 'all_gene_contextual_one_pass_screen.csv', index=False, encoding='utf-8-sig')
    candidates = choose_exact_candidates(approximate, target_count=430)
    candidates.to_csv(cohort_dir / 'exact_delete_candidates.csv', index=False, encoding='utf-8-sig')
    cell_level, exact_summary = exact_delete_screen(cohort, model, input_ids, lengths, metadata, screen_indices, candidates, original_embeddings, goal_centroid, start_centroid)
    cell_level.to_csv(cohort_dir / 'exact_delete_cell_level.csv.gz', index=False, compression='gzip', encoding='utf-8-sig')
    exact_summary.to_csv(cohort_dir / 'exact_delete_gene_summary.csv', index=False, encoding='utf-8-sig')
    gdf_positive = metadata.index[(metadata['label'] == 1) & metadata['GDF15_token_present'].astype(bool)].to_numpy(dtype=int)
    gdf_delete = exact_single_gene_effect(model, input_ids, lengths, metadata, gdf_positive, GDF15_TOKEN_ID, goal_centroid, start_centroid, 'delete')
    gdf_dir = GDF_OUT / cohort
    gdf_dir.mkdir(parents=True, exist_ok=True)
    gdf_delete.to_csv(gdf_dir / 'GDF15_exact_delete_cell_level.csv', index=False, encoding='utf-8-sig')
    gdf_negative_meta = metadata.loc[(metadata['label'] == 1) & ~metadata['GDF15_token_present'].astype(bool)]
    overexpress_indices = stratified_sample_indices(gdf_negative_meta, min(128, len(gdf_negative_meta)), ['donor_id'], SEED + 55)
    gdf_overexpress = exact_single_gene_effect(model, input_ids, lengths, metadata, overexpress_indices, GDF15_TOKEN_ID, goal_centroid, start_centroid, 'overexpress')
    gdf_overexpress.to_csv(gdf_dir / 'GDF15_overexpression_sensitivity_cell_level.csv', index=False, encoding='utf-8-sig')
    summaries = [summarize_gdf_effect(cohort, 'all fibroblasts / periodontitis', 'delete', gdf_delete), summarize_gdf_effect(cohort, 'all fibroblasts / periodontitis / GDF15-token-negative', 'overexpress', gdf_overexpress)]
    if cohort == 'Williams':
        ecm_map = pd.read_csv(TOKEN_DIR / 'Williams_ECM_lineage_dataset_indices.csv')
        ecm_indices = ecm_map.loc[(ecm_map['disease'] == 'periodontitis') & ecm_map['GDF15_token_present'].astype(bool), 'dataset_index'].to_numpy(dtype=int)
        ecm_delete = exact_single_gene_effect(model, input_ids, lengths, metadata, ecm_indices, GDF15_TOKEN_ID, goal_centroid, start_centroid, 'delete')
        if not ecm_delete.empty:
            ecm_delete = ecm_delete.merge(ecm_map[['dataset_index', 'fibroblast_state', 'fibroblast_type', 'Pseudotime']], on='dataset_index', how='left')
        ecm_delete.to_csv(gdf_dir / 'GDF15_exact_delete_ECM_lineage_cell_level.csv', index=False, encoding='utf-8-sig')
        summaries.append(summarize_gdf_effect(cohort, 'ECM lineage / periodontitis', 'delete', ecm_delete))
    pd.DataFrame(summaries).to_csv(gdf_dir / 'GDF15_perturbation_summary.csv', index=False, encoding='utf-8-sig')
    write_json(cohort_dir / 'perturbation_manifest.json', {'cohort': cohort, 'screen_cells': int(len(screen_indices)), 'all_gene_stage': 'one-pass contextual deletion approximation', 'exact_delete_candidate_genes': int(len(candidates)), 'exact_delete_perturbations': int(len(cell_level)), 'GDF15_exact_delete_cells': int(len(gdf_delete)), 'GDF15_overexpression_cells': int(len(gdf_overexpress)), 'state_metrics': {'x': 'delta cosine similarity to normal centroid (Shift_to_goal_end)', 'y': 'delta cosine similarity to periodontitis centroid; negative means away from start (Shift_away_start_end)'}, 'elapsed_minutes': (time.time() - started) / 60})

def stage_perturb() -> None:
    set_deterministic()
    SCREEN_OUT.mkdir(parents=True, exist_ok=True)
    GDF_OUT.mkdir(parents=True, exist_ok=True)
    for cohort in COHORTS:
        perturb_one_cohort(cohort)

def paper_plot_data(cohort: str) -> pd.DataFrame:
    frame = pd.read_csv(SCREEN_OUT / cohort / 'exact_delete_gene_summary.csv')
    gdf_summary = pd.read_csv(GDF_OUT / cohort / 'GDF15_perturbation_summary.csv')
    gdf_row = gdf_summary.loc[(gdf_summary['perturbation'] == 'delete') & (gdf_summary['context'] == 'all fibroblasts / periodontitis')]
    if not gdf_row.empty and int(gdf_row.iloc[0]['N_cells']) > 0:
        row = {'Gene': GDF15_TOKEN_ID, 'Gene_name': 'GDF15', 'Ensembl_ID': GDF15_ENSEMBL, 'Priority_class': 'GDF15', 'N_Detections': int(gdf_row.iloc[0]['N_cells']), 'Shift_to_goal_end': float(gdf_row.iloc[0]['Shift_to_goal_end']), 'Shift_away_start_end': float(gdf_row.iloc[0]['Shift_away_start_end']), 'Desirability_score': float(gdf_row.iloc[0]['Desirability_score']), 'Desired_quadrant': bool(float(gdf_row.iloc[0]['Shift_to_goal_end']) > 0 and float(gdf_row.iloc[0]['Shift_away_start_end']) < 0), 'direct_GDF15_result': True}
        frame = frame.loc[frame['Gene_name'] != 'GDF15'].copy()
        frame['direct_GDF15_result'] = False
        frame = pd.concat([frame, pd.DataFrame([row])], ignore_index=True)
    else:
        frame['direct_GDF15_result'] = False
    return frame

def choose_shared_labels(frames: dict[str, pd.DataFrame], n_labels: int=9) -> list[str]:
    common = set(frames[COHORTS[0]]['Gene_name']) & set(frames[COHORTS[1]]['Gene_name'])
    labels: list[str] = ['GDF15'] if 'GDF15' in common else []
    combined_rows = []
    for gene in common:
        rows = [frames[cohort].loc[frames[cohort]['Gene_name'] == gene].iloc[0] for cohort in COHORTS]
        combined_rows.append({'Gene_name': gene, 'priority': 0 if gene in AXIS_PRIORITY else 1, 'combined_effect': float(sum((np.hypot(row['Shift_to_goal_end'], row['Shift_away_start_end']) for row in rows))), 'both_desired': bool(all((row['Shift_to_goal_end'] > 0 and row['Shift_away_start_end'] < 0 for row in rows)))})
    ranked = pd.DataFrame(combined_rows).sort_values(['priority', 'both_desired', 'combined_effect'], ascending=[True, False, False])
    for gene in ranked['Gene_name'].tolist():
        if gene not in labels:
            labels.append(gene)
        if len(labels) >= n_labels:
            break
    return labels

def draw_cell_cluster(ax, center_x: float, center_y: float, color: str, edge: str, n: int, seed: int) -> None:
    rng = np.random.default_rng(seed)
    offsets = rng.normal(0, 0.13, size=(n, 2))
    ax.scatter(center_x + offsets[:, 0], center_y + offsets[:, 1], s=110, c=color, edgecolors=edge, linewidths=0.7, zorder=3)
    circle = plt.Circle((center_x, center_y), 0.55, facecolor=color, alpha=0.12, edgecolor=edge, linewidth=1.0)
    ax.add_patch(circle)

def draw_panel_a(ax) -> None:
    ax.set_xlim(-2.2, 2.2)
    ax.set_ylim(-1.5, 1.6)
    ax.axis('off')
    draw_cell_cluster(ax, -1.05, 0.0, '#bdbdbd', '#8a8a8a', 11, SEED)
    draw_cell_cluster(ax, 1.15, 0.0, '#72c95a', '#3e9f3e', 9, SEED + 1)
    ax.annotate('', xy=(0.68, 0.0), xytext=(-0.45, 0.0), arrowprops=dict(arrowstyle='-|>', lw=1.6, color='#5c5c5c'))
    ax.text(0.1, 0.15, 'Shift to goal', ha='center', va='bottom', fontsize=8)
    for angle in np.linspace(0, 2 * np.pi, 6, endpoint=False):
        x0 = -1.05 + 0.65 * np.cos(angle)
        y0 = 0.0 + 0.65 * np.sin(angle)
        x1 = -1.05 + 0.95 * np.cos(angle)
        y1 = 0.0 + 0.95 * np.sin(angle)
        ax.annotate('', xy=(x1, y1), xytext=(x0, y0), arrowprops=dict(arrowstyle='-|>', lw=1.2, color='#62bd4d'))
    ax.text(-1.55, 0.75, 'Shift away start', ha='center', va='bottom', fontsize=8)
    ax.text(-1.05, -0.9, 'Periodontitis', ha='center', va='top', fontsize=9)
    ax.text(1.15, -0.9, 'Normal', ha='center', va='top', fontsize=9)
    ax.text(0.0, 1.18, 'GDF15 virtual knockout', ha='center', va='center', fontsize=9, fontweight='bold')
    ax.text(-2.1, 1.47, 'A', fontsize=13, fontfamily='serif')

def scatter_panel(ax, data: pd.DataFrame, cohort: str, color: str, panel_letter: str, labels: list[str]) -> None:
    ax.scatter(data['Shift_to_goal_end'], data['Shift_away_start_end'], s=10, c=color, alpha=0.85, edgecolors='none', rasterized=False)
    gdf = data.loc[data['Gene_name'] == 'GDF15']
    if not gdf.empty:
        ax.scatter(gdf['Shift_to_goal_end'], gdf['Shift_away_start_end'], s=46, c='#d7191c', marker='*', edgecolors='black', linewidths=0.4, zorder=5)
    texts = []
    for gene in labels:
        row = data.loc[data['Gene_name'] == gene]
        if row.empty:
            continue
        r = row.iloc[0]
        texts.append(ax.text(r['Shift_to_goal_end'], r['Shift_away_start_end'], gene, color='#e53935', fontsize=6.5, ha='left', va='bottom'))
    try:
        from adjustText import adjust_text
        adjust_text(texts, ax=ax, arrowprops=dict(arrowstyle='-', color='#e53935', lw=0.35), expand=(1.05, 1.12), force_text=(0.15, 0.15))
    except Exception:
        pass
    ax.set_xlabel('Shift_to_goal_end (Normal)', fontsize=8)
    ax.set_ylabel('Shift_away_start_end (Periodontitis)', fontsize=8)
    ax.tick_params(axis='both', labelsize=7, length=2.5, width=0.7)
    for spine in ax.spines.values():
        spine.set_linewidth(0.7)
        spine.set_color('#555555')
    ax.set_title(cohort, fontsize=9, pad=3)
    ax.text(-0.15, 1.05, panel_letter, transform=ax.transAxes, fontsize=13, fontfamily='serif')

def make_main_figure() -> None:
    sns.set_theme(style='white', font='DejaVu Sans')
    frames = {cohort: paper_plot_data(cohort) for cohort in COHORTS}
    labels = choose_shared_labels(frames, 9)
    cross_rows = []
    for gene in sorted(set(frames['Williams']['Gene_name']) & set(frames['Caetano']['Gene_name'])):
        row = {'Gene_name': gene, 'Label_in_main_figure': gene in labels}
        for cohort in COHORTS:
            r = frames[cohort].loc[frames[cohort]['Gene_name'] == gene].iloc[0]
            row[f'{cohort}_Shift_to_goal_end'] = r['Shift_to_goal_end']
            row[f'{cohort}_Shift_away_start_end'] = r['Shift_away_start_end']
            row[f'{cohort}_Desired_quadrant'] = bool(r['Shift_to_goal_end'] > 0 and r['Shift_away_start_end'] < 0)
        cross_rows.append(row)
    pd.DataFrame(cross_rows).to_csv(SCREEN_OUT / 'cross_cohort_exact_delete_intersection.csv', index=False, encoding='utf-8-sig')
    fig = plt.figure(figsize=(11.4, 3.35), facecolor='white')
    grid = fig.add_gridspec(1, 3, width_ratios=[1.05, 1.28, 1.28], wspace=0.42)
    ax_a = fig.add_subplot(grid[0, 0])
    ax_b = fig.add_subplot(grid[0, 1])
    ax_c = fig.add_subplot(grid[0, 2])
    draw_panel_a(ax_a)
    scatter_panel(ax_b, frames['Williams'], 'Williams', '#66cde3', 'B', labels)
    scatter_panel(ax_c, frames['Caetano'], 'Caetano', '#f6d84a', 'C', labels)
    fig.subplots_adjust(left=0.025, right=0.985, top=0.93, bottom=0.2)
    base = FIG_OUT / 'Figure3_GDF15_Geneformer_virtual_KO_paper_matched'
    fig.savefig(base.with_suffix('.pdf'), dpi=300, facecolor='white')
    fig.savefig(base.with_suffix('.png'), dpi=600, facecolor='white')
    fig.savefig(base.with_suffix('.svg'), facecolor='white')
    plt.close(fig)
    write_json(FIG_OUT / 'main_figure_labels.json', {'shared_red_labels': labels, 'point_colors': {'Williams': '#66cde3', 'Caetano': '#f6d84a', 'GDF15': '#d7191c'}})

def plot_umap_axis(ax, frame: pd.DataFrame, x: str, y: str, title: str, letter: str) -> None:
    palette = {'normal': '#e58a4f', 'periodontitis': '#5b83b4'}
    for disease in ['normal', 'periodontitis']:
        part = frame.loc[frame['disease'] == disease]
        ax.scatter(part[x], part[y], s=3.0, c=palette[disease], alpha=0.65, edgecolors='none', label=disease)
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_xlabel('')
    ax.set_ylabel('')
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.set_title(title, fontsize=8, pad=2)
    ax.text(-0.08, 1.02, letter, transform=ax.transAxes, fontsize=13, fontfamily='serif')

def plot_umap_categories(ax, frame: pd.DataFrame, x: str, y: str, category: str, title: str, legend_title: str) -> None:
    values = sorted(frame[category].fillna('unknown').astype(str).unique().tolist())
    colors = sns.color_palette('husl', n_colors=max(1, len(values)))
    for value, color in zip(values, colors):
        part = frame.loc[frame[category].fillna('unknown').astype(str) == value]
        ax.scatter(part[x], part[y], s=3.0, c=[color], alpha=0.65, edgecolors='none', label=value)
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_xlabel('')
    ax.set_ylabel('')
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.set_title(title, fontsize=8, pad=2)
    ax.legend(title=legend_title, loc='center left', bbox_to_anchor=(1.01, 0.5), frameon=False, fontsize=5.4, title_fontsize=6.2, markerscale=1.8, labelspacing=0.25, handletextpad=0.35, borderaxespad=0.0)

def make_supplementary_figure() -> None:
    frames = {cohort: pd.read_csv(MODEL_OUT / cohort / 'embedding_umap_coordinates.csv') for cohort in COHORTS}
    ecm_meta = pd.read_csv(TOKEN_DIR / 'Williams_ECM_lineage_dataset_indices.csv')
    ecm_frame = frames['Williams'].merge(ecm_meta[['cell_id', 'fibroblast_state']], on='cell_id', how='inner', validate='one_to_one')
    fig = plt.figure(figsize=(10.4, 10.6), facecolor='white')
    gs = fig.add_gridspec(4, 6, height_ratios=[0.92, 1.0, 1.0, 1.0], width_ratios=[1, 1, 1, 1, 1, 0.62], hspace=0.2, wspace=0.22)
    top_axes = [fig.add_subplot(gs[0, 0:2]), fig.add_subplot(gs[0, 2:4]), fig.add_subplot(gs[0, 4:6])]
    top_panels = [(frames['Williams'], 'Williams - before fine-tuning', 'A'), (frames['Caetano'], 'Caetano - before fine-tuning', 'B'), (ecm_frame, 'ECM lineage - before fine-tuning', 'C')]
    for ax, (frame, title, letter) in zip(top_axes, top_panels):
        plot_umap_axis(ax, frame, 'UMAP1_pretrained', 'UMAP2_pretrained', title, letter)
    paired = [('D', frames['Williams'], 'Williams', 'sample_id', 'sample'), ('E', frames['Caetano'], 'Caetano', 'sample_id', 'sample'), ('F', ecm_frame, 'ECM lineage', 'fibroblast_state', 'fibroblast state')]
    state_axes = []
    for row_index, (letter, frame, title, category, legend_title) in enumerate(paired, start=1):
        state_ax = fig.add_subplot(gs[row_index, 0:3])
        type_ax = fig.add_subplot(gs[row_index, 3:5])
        plot_umap_axis(state_ax, frame, 'UMAP1_finetuned', 'UMAP2_finetuned', f'{title} - after fine-tuning (state)', letter)
        plot_umap_categories(type_ax, frame, 'UMAP1_finetuned', 'UMAP2_finetuned', category, f'{title} - annotation', legend_title)
        state_axes.append(state_ax)
    handles, labels = state_axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='upper right', bbox_to_anchor=(0.985, 0.985), frameon=False, fontsize=6.2, markerscale=2.0)
    fig.subplots_adjust(left=0.045, right=0.985, top=0.975, bottom=0.035)
    base = FIG_OUT / 'SupplementaryFigure3_Geneformer_finetuning_UMAP_paper_matched'
    fig.savefig(base.with_suffix('.pdf'), dpi=300, facecolor='white')
    fig.savefig(base.with_suffix('.png'), dpi=600, facecolor='white')
    fig.savefig(base.with_suffix('.svg'), facecolor='white')
    plt.close(fig)

def write_results_summary() -> None:
    gdf_frames = []
    classifier_rows = []
    for cohort in COHORTS:
        gdf = pd.read_csv(GDF_OUT / cohort / 'GDF15_perturbation_summary.csv')
        gdf_frames.append(gdf)
        manifest = json.loads((MODEL_OUT / cohort / 'classifier_run_manifest.json').read_text(encoding='utf-8'))
        classifier_rows.append({'cohort': cohort, **manifest['test_metrics']})
    gdf_all = pd.concat(gdf_frames, ignore_index=True)
    gdf_all.to_csv(GDF_OUT / 'GDF15_all_contexts_summary.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(classifier_rows).to_csv(MODEL_OUT / 'classifier_test_metrics.csv', index=False, encoding='utf-8-sig')
    lines = ['# Geneformer - GDF15 \u865a\u62df\u6572\u9664\u7ed3\u679c\u6458\u8981', '']
    for cohort in COHORTS:
        row = gdf_all.loc[(gdf_all['cohort'] == cohort) & (gdf_all['context'] == 'all fibroblasts / periodontitis') & (gdf_all['perturbation'] == 'delete')].iloc[0]
        if int(row['N_cells']) == 0:
            lines.append(f'- {cohort}\uff1a\u6ca1\u6709\u53ef\u6267\u884c GDF15 \u5220\u9664\u7684 token \u9633\u6027\u7259\u5468\u708e\u7ec6\u80de\u3002')
            continue
        desired_quadrant = bool(float(row['Shift_to_goal_end']) > 0 and float(row['Shift_away_start_end']) < 0)
        direction = '\u4f4d\u4e8e\u8bba\u6587\u5b9a\u4e49\u7684\u53f3\u4e0b\u5019\u9009\u8c61\u9650' if desired_quadrant else '\u672a\u4f4d\u4e8e\u8bba\u6587\u5b9a\u4e49\u7684\u53f3\u4e0b\u5019\u9009\u8c61\u9650'
        lines.append(f"- {cohort}\uff1aGDF15 \u7cbe\u786e KO \u7eb3\u5165 {int(row['N_cells'])} \u4e2a\u7ec6\u80de\u3001{int(row['N_donors'])} \u4e2a\u4f9b\u4f53\uff1bShift_to_goal_end={row['Shift_to_goal_end']:.6f}\uff0cShift_away_start_end={row['Shift_away_start_end']:.6f}\uff0c{direction}\u3002")
    lines.extend(['', '## \u5224\u8bfb\u89c4\u5219', '', '- \u53f3\u4e0b\u8c61\u9650\uff08x>0\u3001y<0\uff09\uff1aKO \u540e\u5411 normal \u79fb\u52a8\u4e14\u8fdc\u79bb periodontitis\uff0c\u63d0\u793a GDF15 \u53ef\u80fd\u7ef4\u6301\u75c5\u7406\u72b6\u6001\uff0c\u4e0e\u4fdd\u62a4\u6027\u5047\u8bbe\u76f8\u53cd\u3002', '- \u975e\u53f3\u4e0b\u8c61\u9650\uff1aKO \u672a\u628a\u7ec6\u80de\u63a8\u5411 normal/\u8fdc\u79bb periodontitis\uff0c\u66f4\u7b26\u5408\u6216\u81f3\u5c11\u4e0d\u53cd\u5bf9 GDF15 \u7684\u4fdd\u62a4\u6027\u4f5c\u7528\u3002', '- Geneformer \u53cd\u6620\u8f6c\u5f55\u72b6\u6001\u5d4c\u5165\u4f4d\u79fb\uff0c\u4e0d\u76f4\u63a5\u6d4b\u91cf ERK1/2 \u78f7\u9178\u5316\uff1bMAPK-ECM \u8f74\u4ecd\u9700\u7ed3\u5408\u8868\u8fbe\u3001\u7f51\u7edc\u548c\u5b9e\u9a8c\u9a8c\u8bc1\u3002'])
    (ROOT / 'Geneformer\u5206\u6790\u7ed3\u8bba_\u8bf7\u5148\u770b.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')

def stage_plot() -> None:
    set_deterministic()
    FIG_OUT.mkdir(parents=True, exist_ok=True)
    make_main_figure()
    make_supplementary_figure()
    write_results_summary()

def stage_notebook() -> None:
    import nbformat as nbf
    NOTEBOOK_OUT.mkdir(parents=True, exist_ok=True)
    notebook_path = NOTEBOOK_OUT / 'Geneformer_GDF15_\u8bba\u6587\u540c\u578b\u590d\u73b0_\u5ba1\u9605.ipynb'
    nb = nbf.v4.new_notebook()
    nb['metadata']['kernelspec'] = {'display_name': 'Python 3', 'language': 'python', 'name': 'python3'}
    nb['metadata']['language_info'] = {'name': 'python', 'version': platform.python_version()}
    nb['cells'] = [nbf.v4.new_markdown_cell('# Geneformer GDF15 virtual knockout - review notebook\n\n## tl;dr\n\nThis notebook loads the executed Geneformer outputs, classifier metrics, exact GDF15 perturbation summaries, and paper-matched figures.'), nbf.v4.new_markdown_cell('## Context & Methods\n\nGeneformer V1 tokenization used raw counts, CP10K normalization divided by the V1 gene median, rank encoding, and a 2048-token crop. Normal fibroblasts are the goal state; periodontitis fibroblasts are the start state.'), nbf.v4.new_code_cell("from pathlib import Path\nimport pandas as pd\nfrom IPython.display import display, Image, Markdown\nROOT = Path('/work')"), nbf.v4.new_markdown_cell('## Data'), nbf.v4.new_code_cell("for cohort in ['Williams','Caetano']:\n    meta = pd.read_csv(ROOT/'01_\u8f93\u5165\u4e0eGeneformer\u5206\u8bcd'/cohort/'cell_metadata.csv')\n    print(cohort, meta.groupby(['disease','GDF15_token_present']).size())"), nbf.v4.new_markdown_cell('## Results'), nbf.v4.new_code_cell("metrics = pd.read_csv(ROOT/'02_\u72b6\u6001\u5206\u7c7b\u5668'/'classifier_test_metrics.csv')\ngdf = pd.read_csv(ROOT/'04_GDF15\u5b9a\u5411\u6270\u52a8'/'GDF15_all_contexts_summary.csv')\ndisplay(metrics)\ndisplay(gdf)"), nbf.v4.new_code_cell("display(Image(filename=str(ROOT/'05_\u8bba\u6587\u540c\u578b\u56fe'/'Figure3_GDF15_Geneformer_virtual_KO_paper_matched.png'), width=1100))"), nbf.v4.new_code_cell("display(Image(filename=str(ROOT/'05_\u8bba\u6587\u540c\u578b\u56fe'/'SupplementaryFigure3_Geneformer_finetuning_UMAP_paper_matched.png'), width=1100))"), nbf.v4.new_markdown_cell('## Takeaways\n\nThe final direction is read directly from `GDF15_all_contexts_summary.csv`: x > 0 and y < 0 indicates a shift toward normal and away from periodontitis after GDF15 deletion. Small GDF15-token-positive cell counts are retained explicitly in the output.')]
    nbf.write(nb, notebook_path)
    print(notebook_path)

def stage_qa() -> None:
    QA_OUT.mkdir(parents=True, exist_ok=True)
    checks = []
    for cohort in COHORTS:
        summary = json.loads((TOKEN_DIR / cohort / 'tokenization_summary.json').read_text(encoding='utf-8'))
        checks.extend([{'check': f'{cohort}_cell_id_match', 'pass': summary['cell_id_mismatches'] == 0, 'value': summary['cell_id_mismatches']}, {'check': f'{cohort}_token_length', 'pass': summary['max_token_length'] <= MAX_LENGTH, 'value': summary['max_token_length']}, {'check': f'{cohort}_classifier_model', 'pass': (MODEL_OUT / cohort / 'best_model/model.safetensors').exists(), 'value': str(MODEL_OUT / cohort / 'best_model/model.safetensors')}, {'check': f'{cohort}_exact_screen', 'pass': (SCREEN_OUT / cohort / 'exact_delete_gene_summary.csv').exists(), 'value': str(SCREEN_OUT / cohort / 'exact_delete_gene_summary.csv')}])
    from pypdf import PdfReader
    for name in ['Figure3_GDF15_Geneformer_virtual_KO_paper_matched.pdf', 'SupplementaryFigure3_Geneformer_finetuning_UMAP_paper_matched.pdf']:
        path = FIG_OUT / name
        ok = path.exists() and path.stat().st_size > 1000
        pages = len(PdfReader(path).pages) if ok else 0
        checks.append({'check': f'pdf_{name}', 'pass': bool(ok and pages == 1), 'value': f'size={(path.stat().st_size if path.exists() else 0)}; pages={pages}'})
    check_frame = pd.DataFrame(checks)
    check_frame.to_csv(QA_OUT / 'validation_checks.csv', index=False, encoding='utf-8-sig')
    overall = bool(check_frame['pass'].all())
    write_json(QA_OUT / 'software_versions.json', {'python': platform.python_version(), 'platform': platform.platform(), 'torch': torch.__version__, 'numpy': np.__version__, 'pandas': pd.__version__, 'scipy': scipy.__version__, 'scikit_learn': sklearn.__version__, 'umap': umap.__version__, 'model': 'Geneformer-V1-10M', 'model_sha256': file_sha256(MODEL_DIR / 'model.safetensors'), 'seed': SEED})
    report = ['# Validation Report', '', f"## Overall Assessment: {('Ready to share' if overall else 'Needs revision')}", '', '## Methodology Review', '', '\u8f93\u5165\u6765\u81ea\u539f\u59cb UMI counts\uff0cV1 \u5206\u8bcd\u89c4\u5219\u3001\u72b6\u6001\u5b9a\u4e49\u3001\u6a21\u578b\u6743\u91cd\u3001\u968f\u673a\u79cd\u5b50\u548c\u4e24\u9636\u6bb5 KO \u5747\u5df2\u7559\u75d5\u3002Williams \u4f7f\u7528\u4f9b\u4f53\u4e92\u65a5\u5212\u5206\uff1bCaetano \u56e0\u6bcf\u7c7b\u4ec5\u4e24\u4e2a\u4f9b\u4f53\u91c7\u7528\u5206\u5c42\u7ec6\u80de\u5212\u5206\u3002', '', '## Issues Found', '', '1. Caetano \u7684 GDF15 token \u9633\u6027\u7259\u5468\u708e\u7ec6\u80de\u6781\u5c11\uff0c\u72ec\u7acb\u961f\u5217 GDF15 \u5b9a\u5411\u7ed3\u679c\u53ea\u80fd\u4f5c\u4e3a\u654f\u611f\u6027\u8bc1\u636e\u3002', '2. \u5168\u57fa\u56e0\u9636\u6bb5\u5148\u505a\u4e00\u6b21\u524d\u5411\u7684\u4e0a\u4e0b\u6587\u5220\u9664\u8fd1\u4f3c\uff0c\u518d\u5bf9\u7ea6 430 \u4e2a\u5019\u9009\u505a\u771f\u5b9e delete \u91cd\u65b0\u524d\u5411\uff1b\u6700\u7ec8\u6563\u70b9\u56fe\u53ea\u4f7f\u7528\u7cbe\u786e\u91cd\u65b0\u524d\u5411\u7684\u7ed3\u679c\u3002', '3. Geneformer \u4e0d\u80fd\u76f4\u63a5\u89c2\u6d4b ERK1/2 \u78f7\u9178\u5316\uff0c\u56e0\u6b64\u4e0d\u80fd\u5355\u72ec\u8bc1\u660e GDF15-ERK1/2-MAPK \u7684\u751f\u5316\u56e0\u679c\u94fe\u3002', '', '## Calculation Spot-Checks', '']
    for _, row in check_frame.iterrows():
        report.append(f"- {row['check']}: {('Verified' if row['pass'] else 'Failed')} - {row['value']}")
    report.extend(['', '## Visualization Review', '', '\u4e3b\u56fe\u91c7\u7528\u539f\u6587 Figure 3A-C \u7684\u793a\u610f\u56fe\u52a0\u4e24\u961f\u5217\u4f4d\u79fb\u6563\u70b9\u56fe\uff1b\u8865\u5145\u56fe\u91c7\u7528\u5fae\u8c03\u524d/\u540e UMAP \u7684 A-F \u9762\u677f\u7ed3\u6784\u3002PDF \u5747\u91cd\u65b0\u6253\u5f00\u5e76\u68c0\u67e5\u9875\u6570\u3002'])
    (QA_OUT / 'validation_report.md').write_text('\n'.join(report) + '\n', encoding='utf-8')
    if not overall:
        raise RuntimeError('One or more QA checks failed')

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', choices=['tokenize', 'train', 'embed', 'perturb', 'plot', 'notebook', 'qa', 'all'])
    return parser.parse_args()

def main() -> None:
    args = parse_args()
    stages = ['tokenize', 'train', 'embed', 'perturb', 'plot', 'notebook', 'qa'] if args.stage == 'all' else [args.stage]
    functions = {'tokenize': stage_tokenize, 'train': stage_train, 'embed': stage_embed, 'perturb': stage_perturb, 'plot': stage_plot, 'notebook': stage_notebook, 'qa': stage_qa}
    for stage in stages:
        print(f'=== START {stage} ===', flush=True)
        started = time.time()
        functions[stage]()
        print(f'=== END {stage}: {(time.time() - started) / 60:.2f} min ===', flush=True)
if __name__ == '__main__':
    main()
