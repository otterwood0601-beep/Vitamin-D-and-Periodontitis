from __future__ import annotations
import json
import math
import shutil
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.colors as mcolors
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib.gridspec import GridSpec
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
from geneformer_core import AXIS_PRIORITY, GDF15_ENSEMBL, GDF15_TOKEN_ID, SEED
ROOT = Path('/work')
EXT_OLD = ROOT / '08_\u6269\u5c55\u56fe\u8868_PLOS_Frontiers\u540c\u578b'
OUT = ROOT / '09_\u8bba\u6587\u539f\u56fe\u4e25\u683c\u590d\u6838\u4e0eGDF15\u8fc7\u8868\u8fbe\u8865\u5145_v2'
FIG_OUT = OUT / '\u56fe\u7247'
TABLE_OUT = OUT / '\u6570\u636e\u8868'
QA_OUT = OUT / 'QA'
ORIGINAL_OUT = OUT / '\u539f\u56fe_\u672a\u91cd\u7b97'
BENCH_OUT = TABLE_OUT / '\u6269\u5c55\u56fe7\u578b\u5206\u7c7b\u5668\u57fa\u51c6'
OE_OUT = TABLE_OUT / '\u5168\u57fa\u56e0\u8fc7\u8868\u8fbe\u7b5b\u9009'
SOURCE_TABLES = EXT_OLD / '\u6570\u636e\u8868'
COHORTS = ['Williams', 'Caetano']

def ensure_dirs() -> None:
    for path in [FIG_OUT, TABLE_OUT, QA_OUT, ORIGINAL_OUT]:
        path.mkdir(parents=True, exist_ok=True)

def style() -> None:
    sns.set_theme(style='white', context='paper')
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 7.5, 'axes.titlesize': 8.5, 'axes.labelsize': 8, 'xtick.labelsize': 7, 'ytick.labelsize': 7, 'axes.linewidth': 0.75, 'pdf.fonttype': 42, 'ps.fonttype': 42})

def save_all(fig: plt.Figure, stem: str) -> None:
    fig.savefig(FIG_OUT / f'{stem}.pdf', dpi=300, facecolor='white', bbox_inches='tight')
    fig.savefig(FIG_OUT / f'{stem}.svg', facecolor='white', bbox_inches='tight')
    fig.savefig(FIG_OUT / f'{stem}.png', dpi=600, facecolor='white', bbox_inches='tight')
    plt.close(fig)

def load_test_predictions() -> pd.DataFrame:
    frames = []
    for cohort in COHORTS:
        frame = pd.read_csv(ROOT / '02_\u72b6\u6001\u5206\u7c7b\u5668' / cohort / 'validation_and_test_predictions.csv')
        frame = frame.loc[frame['split'] == 'test'].copy()
        frame.insert(0, 'cohort', cohort)
        frames.append(frame)
    data = pd.concat(frames, ignore_index=True)
    data = data.sort_values(['observed_label', 'predicted_label', 'periodontitis_probability'], ascending=[True, True, True]).reset_index(drop=True)
    return data

def plot_prediction_heatmap_confusion() -> None:
    data = load_test_predictions()
    labels = data['observed_label'].to_numpy(dtype=int)
    predicted = data['predicted_label'].to_numpy(dtype=int)
    probabilities = data['periodontitis_probability'].to_numpy(dtype=float)
    scores = np.column_stack([1.0 - probabilities, probabilities])
    scores = (scores - scores.mean(axis=0, keepdims=True)) / np.clip(scores.std(axis=0, keepdims=True), 1e-08, None)
    scores = np.clip(scores, -2.5, 2.5)
    state_colors = ['#392448', '#DCE6C3']
    state_cmap = mcolors.ListedColormap(state_colors)
    score_cmap = mcolors.LinearSegmentedColormap.from_list('score', ['#2166AC', '#F7F7F7', '#C33D4A'])
    fig = plt.figure(figsize=(6.2, 7.3), facecolor='white')
    outer = GridSpec(2, 1, figure=fig, height_ratios=[2.6, 1.55], hspace=0.43)
    top = outer[0].subgridspec(3, 3, width_ratios=[0.12, 0.075, 1.0], height_ratios=[0.095, 1.0, 0.09], wspace=0.035, hspace=0.02)
    ax_cbar = fig.add_subplot(top[1, 0])
    ax_true = fig.add_subplot(top[1, 1])
    ax_pred = fig.add_subplot(top[0, 2])
    ax_heat = fig.add_subplot(top[1, 2])
    heat = ax_heat.pcolormesh(np.arange(3), np.arange(len(scores) + 1), scores, cmap=score_cmap, vmin=-2.5, vmax=2.5, shading='flat', linewidth=0)
    ax_heat.set_xlim(0, 2)
    ax_heat.set_ylim(len(scores), 0)
    ax_heat.set_xticks([0.5, 1.5], ['Healthy', 'Periodontitis'])
    ax_heat.set_yticks([])
    ax_heat.tick_params(length=0)
    for spine in ax_heat.spines.values():
        spine.set_visible(False)
    ax_true.pcolormesh([0, 1], np.arange(len(labels) + 1), labels[:, None], cmap=state_cmap, vmin=0, vmax=1, shading='flat', linewidth=0)
    ax_true.set_xlim(0, 1)
    ax_true.set_ylim(len(labels), 0)
    ax_true.set_xticks([])
    ax_true.set_yticks([])
    for spine in ax_true.spines.values():
        spine.set_visible(False)
    ax_true.text(-1.15, 0.5, 'True', transform=ax_true.transAxes, rotation=90, ha='center', va='center', fontsize=8)
    ax_pred.pcolormesh([0, 1, 2], [0, 1], np.asarray([[0, 1]]), cmap=state_cmap, vmin=0, vmax=1, shading='flat', linewidth=0)
    ax_pred.set_xlim(0, 2)
    ax_pred.set_ylim(0, 1)
    ax_pred.set_xticks([])
    ax_pred.set_yticks([])
    for spine in ax_pred.spines.values():
        spine.set_visible(False)
    ax_pred.text(1.035, 0.5, 'Predicted', transform=ax_pred.transAxes, ha='left', va='center', fontsize=8)
    cbar = fig.colorbar(heat, cax=ax_cbar, orientation='vertical')
    cbar.set_ticks([-2.5, 0, 2.5])
    cbar.ax.yaxis.set_ticks_position('left')
    cbar.ax.tick_params(labelsize=6, length=2, pad=1)
    cbar.outline.set_linewidth(0.5)
    handles = [Patch(facecolor=state_colors[0], label='Healthy'), Patch(facecolor=state_colors[1], label='Periodontitis')]
    ax_pred.legend(handles=handles, title='Cell states', frameon=True, edgecolor='#D9D9D9', facecolor='white', ncol=2, loc='lower center', bbox_to_anchor=(0.5, 1.45), fontsize=7, title_fontsize=8, handlelength=1.4)
    ax_heat.text(-0.33, 1.14, 'D', transform=ax_heat.transAxes, fontsize=14, fontweight='normal', va='top')
    bottom = outer[1].subgridspec(1, 3, width_ratios=[0.52, 1.0, 0.33])
    ax_cm = fig.add_subplot(bottom[0, 1])
    cm = confusion_matrix(labels, predicted, labels=[0, 1]).astype(float)
    cm_norm = cm / np.clip(cm.sum(axis=1, keepdims=True), 1, None)
    im = ax_cm.pcolormesh([0, 1, 2], [0, 1, 2], cm_norm, cmap='Blues', vmin=0, vmax=1, shading='flat', edgecolors='white', linewidth=0.45)
    for row in range(2):
        for column in range(2):
            color = 'white' if cm_norm[row, column] >= 0.55 else 'black'
            ax_cm.text(column + 0.5, row + 0.5, f'{cm_norm[row, column]:.2f}', ha='center', va='center', fontsize=10, color=color)
    true_n = cm.sum(axis=1).astype(int)
    predicted_n = cm.sum(axis=0).astype(int)
    ax_cm.set_xlim(0, 2)
    ax_cm.set_ylim(2, 0)
    ax_cm.set_aspect('equal')
    ax_cm.set_xticks([0.5, 1.5], [f'Healthy\nn={predicted_n[0]}', f'Periodontitis\nn={predicted_n[1]}'])
    ax_cm.set_yticks([0.5, 1.5], [f'Healthy\nn={true_n[0]}', f'Periodontitis\nn={true_n[1]}'])
    ax_cm.set_xlabel('Predicted label')
    ax_cm.set_ylabel('True label')
    ax_cm.tick_params(length=0)
    for spine in ax_cm.spines.values():
        spine.set_color('#B0B0B0')
        spine.set_linewidth(0.6)
    cbar_cm = fig.colorbar(im, ax=ax_cm, fraction=0.045, pad=0.04)
    cbar_cm.set_ticks([0.2, 0.4, 0.6, 0.8])
    cbar_cm.ax.tick_params(labelsize=6)
    accuracy = accuracy_score(labels, predicted)
    macro_f1 = f1_score(labels, predicted, average='macro')
    ax_cm.text(0.5, -0.38, f'Accuracy: {accuracy:.3f}\nF1 score: {macro_f1:.3f}', transform=ax_cm.transAxes, ha='center', va='top', fontsize=8.5)
    ax_cm.text(-0.52, 1.18, 'E', transform=ax_cm.transAxes, fontsize=14, fontweight='normal', va='top')
    fig.subplots_adjust(left=0.12, right=0.95, top=0.9, bottom=0.09)
    save_all(fig, '\u56fe1_Geneformer\u7ec6\u80de\u72b6\u6001\u9884\u6d4b\u70ed\u56fe\u4e0e\u6df7\u6dc6\u77e9\u9635_PLOS\u4e25\u683c\u540c\u578b_v2')

def draw_confusion(ax: plt.Axes, matrix: np.ndarray, title: str, large: bool=False) -> None:
    ax.pcolormesh([0, 1, 2], [0, 1, 2], matrix, cmap='Blues', vmin=0, vmax=1, shading='flat', edgecolors='white', linewidth=0.35)
    fontsize = 11 if large else 7.2
    for row in range(2):
        for column in range(2):
            color = 'white' if matrix[row, column] >= 0.54 else 'black'
            ax.text(column + 0.5, row + 0.5, f'{matrix[row, column]:.2f}', ha='center', va='center', color=color, fontsize=fontsize)
    ax.set_xlim(0, 2)
    ax.set_ylim(2, 0)
    ax.set_aspect('equal')
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_title(title, fontsize=9 if large else 7.5, fontweight='bold', pad=3)
    for spine in ax.spines.values():
        spine.set_visible(False)

def plot_extended_data7_benchmark() -> None:
    predictions = pd.read_csv(BENCH_OUT / 'benchmark_test_predictions.csv.gz')
    metrics = pd.read_csv(BENCH_OUT / 'benchmark_metrics.csv')
    order = ['GF', 'SVM-r', 'RF-r', 'LR-r', 'SVM-c', 'RF-c', 'LR-c']
    matrices = {}
    for model in order:
        group = predictions.loc[predictions['model'] == model]
        cm = confusion_matrix(group['true_label'], group['predicted_label'], labels=[0, 1]).astype(float)
        matrices[model] = cm / np.clip(cm.sum(axis=1, keepdims=True), 1, None)
    fig = plt.figure(figsize=(11.8, 3.15), facecolor='white')
    outer = GridSpec(1, 3, figure=fig, width_ratios=[1.05, 1.8, 1.02], wspace=0.18)
    ax_gf = fig.add_subplot(outer[0, 0])
    draw_confusion(ax_gf, matrices['GF'], 'Geneformer (GF)', large=True)
    ax_gf.set_xticks([0.5, 1.5], ['Healthy', 'Periodontitis'])
    ax_gf.set_yticks([0.5, 1.5], ['Healthy', 'Periodontitis'])
    ax_gf.set_xlabel('Predicted', fontsize=8)
    ax_gf.set_ylabel('True', fontsize=8)
    ax_gf.tick_params(length=0, labelsize=7)
    cax = ax_gf.inset_axes([-0.52, 0.05, 0.045, 0.34])
    scalar = plt.cm.ScalarMappable(norm=mcolors.Normalize(0, 1), cmap='Blues')
    cbar = fig.colorbar(scalar, cax=cax)
    cbar.set_ticks([0, 1])
    cbar.set_ticklabels(['Min', 'Max'])
    cbar.ax.tick_params(labelsize=6, length=0, pad=1)
    cbar.outline.set_linewidth(0.4)
    grid = outer[0, 1].subgridspec(2, 3, wspace=0.16, hspace=0.3)
    for position, model in enumerate(order[1:]):
        ax = fig.add_subplot(grid[position // 3, position % 3])
        draw_confusion(ax, matrices[model], model)
    ax_bar = fig.add_subplot(outer[0, 2])
    metric_index = metrics.set_index('model')
    f1_values = [float(metric_index.at[model, 'macro_f1']) for model in order]
    colors = ['#D35445', '#F29E57', '#F1D38A', '#F3EDB7', '#D9ECF2', '#94C0D3', '#5D86B5']
    y = np.arange(len(order))
    ax_bar.barh(y, f1_values, color=colors, edgecolor='#555555', linewidth=0.35, height=0.78)
    ax_bar.set_yticks(y, order)
    ax_bar.invert_yaxis()
    ax_bar.set_xlabel('F1 score')
    lower = max(0.0, min(f1_values) - 0.06)
    ax_bar.set_xlim(lower, min(1.0, max(f1_values) + 0.03))
    ax_bar.grid(False)
    ax_bar.spines['top'].set_visible(False)
    ax_bar.spines['right'].set_visible(False)
    ax_bar.tick_params(axis='y', length=0)
    for ypos, value in zip(y, f1_values):
        ax_bar.text(value + 0.005, ypos, f'{value:.2f}', va='center', fontsize=6.5)
    ax_gf.text(-0.42, 1.15, 'a', transform=ax_gf.transAxes, fontsize=14, fontweight='bold', va='top')
    fig.text(0.5, 0.015, 'Pooled held-out fibroblasts (Williams + Caetano), n=690', ha='center', fontsize=6.5)
    fig.subplots_adjust(left=0.06, right=0.985, top=0.9, bottom=0.18)
    save_all(fig, '\u6269\u5c55\u56fe1_Geneformer\u4e0e\u4f20\u7edf\u6a21\u578b\u5206\u7c7b\u57fa\u51c6_ExtendedDataFigure7\u540c\u578b_v2')

def plot_umap_sensitivity() -> None:
    data = pd.read_csv(SOURCE_TABLES / 'Williams_GDF15_KO_OE_sensitivity_UMAP.csv')
    fig, axes = plt.subplots(1, 2, figsize=(9.8, 4.65), sharex=True, sharey=True)
    definitions = [('GDF15_KO_cosine_shift', 'GDF15 knockout sensitivity', 'Reds', 'B'), ('GDF15_OE_cosine_shift', 'GDF15 overexpression sensitivity', 'Blues', 'C')]
    for ax, (column, title, cmap, letter) in zip(axes, definitions):
        values = data[column].to_numpy(dtype=float) * 1000.0
        ax.scatter(data['UMAP_1'], data['UMAP_2'], s=3.2, c='#E6E6E6', edgecolors='none', rasterized=True)
        if column.endswith('KO_cosine_shift'):
            eligible = data['GDF15_token_present'].astype(str).str.lower().eq('true').to_numpy()
        else:
            eligible = np.isfinite(values)
        positive = values[eligible & (values > 0)]
        vmax = float(np.quantile(positive, 0.99)) if len(positive) else 1.0
        vmax = max(vmax, 1e-06)
        order = np.argsort(values[eligible])
        positions = np.flatnonzero(eligible)[order]
        scatter = ax.scatter(data.loc[positions, 'UMAP_1'], data.loc[positions, 'UMAP_2'], c=values[positions], s=4.2, cmap=cmap, vmin=0, vmax=vmax, edgecolors='none', rasterized=True)
        ax.set_title(title, fontsize=9, fontweight='bold', pad=7)
        ax.set_xlabel('UMAP 1')
        ax.set_ylabel('UMAP 2')
        ax.grid(False)
        for spine in ax.spines.values():
            spine.set_visible(True)
            spine.set_color('black')
            spine.set_linewidth(0.7)
        cbar = fig.colorbar(scatter, ax=ax, fraction=0.046, pad=0.03)
        cbar.ax.set_title('Cosine shift\n(x10^3)', fontsize=6.5, pad=4)
        cbar.ax.tick_params(labelsize=6)
        cbar.outline.set_linewidth(0.45)
        ax.text(-0.13, 1.08, letter, transform=ax.transAxes, fontsize=15, fontweight='normal', va='top')
    axes[0].text(0.02, 0.02, 'Gray: GDF15 token absent; KO not executable', transform=axes[0].transAxes, fontsize=5.8, ha='left', va='bottom', color='#666666')
    fig.subplots_adjust(left=0.07, right=0.95, bottom=0.12, top=0.88, wspace=0.28)
    save_all(fig, '\u56fe2_GDF15\u6572\u9664\u4e0e\u8fc7\u8868\u8fbe\u654f\u611f\u6027UMAP_Frontiers\u4e25\u683c\u540c\u578b_v2')

def circle_selected(summary: pd.DataFrame, scenario: str, n_total: int=32) -> pd.DataFrame:
    pooled = summary.loc[(summary['scenario'] == scenario) & (summary['cohort'] == 'Pooled')].copy()
    pooled = pooled.sort_values('Mean_token_cosine_shift', ascending=False)
    axis = pooled.loc[pooled['Priority_class'] != 'Other'].head(24)
    other = pooled.loc[pooled['Priority_class'] == 'Other'].head(max(0, n_total - len(axis)))
    selected = pd.concat([axis, other], ignore_index=True).drop_duplicates('Gene')
    class_order = {'MAPK-response': 0, 'ECM-remodeling': 1, 'Other': 2}
    selected['class_order'] = selected['Priority_class'].map(class_order).fillna(2)
    return selected.sort_values(['class_order', 'Mean_token_cosine_shift'], ascending=[True, False]).reset_index(drop=True)

def circle_positions(classes: list[str]) -> tuple[np.ndarray, float, list[int]]:
    start = math.radians(18)
    span = math.radians(326)
    positions = []
    boundaries = []
    cursor = 0.0
    previous = None
    for index, category in enumerate(classes):
        if previous is not None and category != previous:
            cursor += 1.6
            boundaries.append(index)
        positions.append(cursor)
        cursor += 1.0
        previous = category
    theta = start + np.asarray(positions) / cursor * span
    return (theta, span / cursor * 0.92, boundaries)

def draw_box(ax: plt.Axes, data: pd.DataFrame, color: str, title: str) -> None:
    values = []
    rng = np.random.default_rng(SEED + (0 if title.endswith('KO') else 1))
    for position, cohort in enumerate(COHORTS, start=1):
        array = data.loc[data['cohort'] == cohort, 'Cosine_shift'].to_numpy(dtype=float) * 1000.0
        values.append(array)
        ax.scatter(rng.normal(position, 0.045, len(array)), array, s=7, color=color, alpha=0.55, edgecolors='none')
    box = ax.boxplot(values, positions=[1, 2], widths=0.42, patch_artist=True, showfliers=False, medianprops={'color': 'black', 'linewidth': 0.9}, whiskerprops={'color': color, 'linewidth': 0.7}, capprops={'color': color, 'linewidth': 0.7}, boxprops={'edgecolor': color, 'linewidth': 0.8})
    for patch in box['boxes']:
        patch.set_facecolor('white')
    ax.set_xticks([1, 2], [f'Williams\n(n={len(values[0])})', f'Caetano\n(n={len(values[1])})'])
    ax.set_ylabel('Cosine shift (x10^3)')
    ax.set_title(title, fontsize=8, pad=3)
    ax.grid(False)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.tick_params(axis='x', length=0, labelsize=6.5)

def draw_circle(ax: plt.Axes, summary: pd.DataFrame, scenario: str, cmap_name: str, outer_color: str) -> None:
    selected = circle_selected(summary, scenario)
    genes = selected['Gene'].astype(int).tolist()
    classes = selected['Priority_class'].astype(str).tolist()
    theta, width, boundaries = circle_positions(classes)
    subset = summary.loc[(summary['scenario'] == scenario) & summary['Gene'].isin(genes)].copy()
    values_all = subset['Mean_token_cosine_shift'].to_numpy(dtype=float) * 1000.0
    vmax = float(np.quantile(values_all[np.isfinite(values_all)], 0.98)) if np.isfinite(values_all).any() else 1.0
    vmax = max(vmax, 1e-06)
    norm = mcolors.Normalize(0, vmax)
    cmap = plt.get_cmap(cmap_name)
    tracks = [('Caetano', 1.05), ('Williams', 1.77), ('Pooled', 2.49)]
    for cohort, bottom in tracks:
        indexed = subset.loc[subset['cohort'] == cohort].set_index('Gene')
        values = np.asarray([indexed.at[gene, 'Mean_token_cosine_shift'] * 1000.0 if gene in indexed.index else np.nan for gene in genes])
        colors = [cmap(norm(value)) if np.isfinite(value) else '#F2F2F2' for value in values]
        ax.bar(theta, np.repeat(0.6, len(theta)), bottom=bottom, width=width, color=colors, edgecolor='white', linewidth=0.25)
    pooled = subset.loc[subset['cohort'] == 'Pooled'].set_index('Gene')
    strong = np.asarray([pooled.at[gene, 'N_strong_hits'] if gene in pooled.index else 0 for gene in genes], dtype=float)
    ax.bar(theta, strong * 0.22, bottom=3.24, width=width, color=outer_color, edgecolor='white', linewidth=0.2)
    for boundary in boundaries:
        angle = theta[boundary] - width
        ax.plot([angle, angle], [0.92, 3.92], color='#777777', lw=0.45, linestyle=(0, (2, 2)))
    radius = 3.9
    for angle, gene_name in zip(theta, selected['Gene_name'].astype(str)):
        degree = math.degrees(angle) % 360
        rotation = degree - 90
        align = 'left'
        if 90 < degree < 270:
            rotation += 180
            align = 'right'
        ax.text(angle, radius, gene_name, rotation=rotation, rotation_mode='anchor', ha=align, va='center', fontsize=4.7)
    ax.set_ylim(0, 4.28)
    ax.set_axis_off()
    cax = ax.inset_axes([0.36, -0.005, 0.34, 0.025], transform=ax.transAxes)
    cbar = plt.colorbar(plt.cm.ScalarMappable(norm=norm, cmap=cmap), cax=cax, orientation='horizontal')
    cbar.set_ticks([0, vmax])
    cbar.set_ticklabels(['Low', 'High'])
    cbar.ax.tick_params(labelsize=5, length=0)
    cbar.outline.set_linewidth(0.4)

def plot_circular_evidence() -> None:
    cell = pd.read_csv(SOURCE_TABLES / 'GDF15_directional_perturbation_cell_level.csv')
    summary = pd.read_csv(SOURCE_TABLES / 'GDF15_downstream_gene_evidence_summary.csv')
    scenarios = [('Periodontitis_GDF15_KO_to_Healthy', 'GDF15 KO', 'Reds', '#C58B2B', '#D95F5F', 'D'), ('Healthy_GDF15_OE_to_Periodontitis', 'GDF15 OE', 'Blues', '#355C9A', '#4C78A8', 'E')]
    fig = plt.figure(figsize=(12.8, 6.4), facecolor='white')
    outer = GridSpec(1, 2, figure=fig, wspace=0.08)
    for index, (scenario, title, cmap, outer_color, point_color, letter) in enumerate(scenarios):
        inner = outer[index].subgridspec(2, 2, width_ratios=[0.72, 2.25], height_ratios=[1.15, 0.85], wspace=0.02, hspace=0.08)
        ax_box = fig.add_subplot(inner[0, 0])
        ax_note = fig.add_subplot(inner[1, 0])
        ax_circle = fig.add_subplot(inner[:, 1], projection='polar')
        draw_box(ax_box, cell.loc[cell['scenario'] == scenario], point_color, title)
        draw_circle(ax_circle, summary, scenario, cmap, outer_color)
        ax_note.axis('off')
        ax_note.legend(handles=[Patch(facecolor=plt.get_cmap(cmap)(0.78), label='Pooled'), Patch(facecolor=plt.get_cmap(cmap)(0.55), label='Williams'), Patch(facecolor=plt.get_cmap(cmap)(0.34), label='Caetano'), Patch(facecolor=outer_color, label='N strong hits')], loc='upper left', frameon=False, title='Tracks', fontsize=6.5, title_fontsize=7, borderaxespad=0)
        ax_box.text(-0.3, 1.22, letter, transform=ax_box.transAxes, fontsize=15, fontweight='normal', va='top')
    fig.subplots_adjust(left=0.04, right=0.985, top=0.95, bottom=0.06)
    save_all(fig, '\u56fe3_GDF15\u6572\u9664\u4e0e\u8fc7\u8868\u8fbe\u5706\u5f62\u57fa\u56e0\u8bc1\u636e\u56fe_Frontiers\u4e25\u683c\u540c\u578b_v2')

def direct_summary(cohort: str, scenario: str) -> pd.Series:
    summary = pd.read_csv(SOURCE_TABLES / 'GDF15_directional_perturbation_cohort_summary.csv')
    return summary.loc[(summary['Scope'] == cohort) & (summary['Scenario'] == scenario)].iloc[0]

def ko_frame(cohort: str) -> pd.DataFrame:
    frame = pd.read_csv(ROOT / '03_\u5168\u57fa\u56e0\u865a\u62df\u6572\u9664' / cohort / 'exact_delete_gene_summary.csv')
    direct = direct_summary(cohort, 'Periodontitis_GDF15_KO_to_Healthy')
    frame = frame.loc[frame['Gene_name'] != 'GDF15'].copy()
    row = {'Gene': GDF15_TOKEN_ID, 'Gene_name': 'GDF15', 'Ensembl_ID': GDF15_ENSEMBL, 'Priority_class': 'GDF15', 'N_Detections': int(direct['N_cells']), 'Shift_to_goal_end': float(direct['Shift_to_target']), 'Shift_away_start_end': float(direct['Shift_away_source']), 'Desirability_score': float(direct['Shift_to_target'] - direct['Shift_away_source']), 'Desired_quadrant': bool(direct['Shift_to_target'] > 0 and direct['Shift_away_source'] < 0), 'direct_GDF15_result': True}
    frame['direct_GDF15_result'] = False
    return pd.concat([frame, pd.DataFrame([row])], ignore_index=True)

def oe_frame(cohort: str) -> pd.DataFrame:
    frame = pd.read_csv(OE_OUT / cohort / 'exact_overexpression_gene_summary.csv')
    frame = frame.rename(columns={'N_Perturbed_cells': 'N_Detections'})
    direct = direct_summary(cohort, 'Healthy_GDF15_OE_to_Periodontitis')
    frame = frame.loc[frame['Gene_name'] != 'GDF15'].copy()
    row = {'Gene': GDF15_TOKEN_ID, 'Gene_name': 'GDF15', 'Ensembl_ID': GDF15_ENSEMBL, 'Priority_class': 'GDF15', 'N_Detections': int(direct['N_cells']), 'Shift_to_goal_end': float(direct['Shift_to_target']), 'Shift_away_start_end': float(direct['Shift_away_source']), 'Desirability_score': float(direct['Shift_to_target'] - direct['Shift_away_source']), 'Desired_quadrant': bool(direct['Shift_to_target'] > 0 and direct['Shift_away_source'] < 0), 'direct_GDF15_result': True}
    frame['direct_GDF15_result'] = False
    return pd.concat([frame, pd.DataFrame([row])], ignore_index=True)

def label_candidates(data: pd.DataFrame, n_labels: int=12) -> list[str]:
    data = data.copy()
    sx = max(float(data['Shift_to_goal_end'].std()), 1e-09)
    sy = max(float(data['Shift_away_start_end'].std()), 1e-09)
    data['distance'] = np.hypot(data['Shift_to_goal_end'] / sx, data['Shift_away_start_end'] / sy)
    labels = ['GDF15']
    narrative = data.loc[data['Gene_name'].isin(AXIS_PRIORITY)].sort_values('distance', ascending=False)
    for gene in narrative['Gene_name']:
        if gene not in labels:
            labels.append(str(gene))
        if len(labels) >= min(7, n_labels):
            break
    for gene in data.sort_values('distance', ascending=False)['Gene_name']:
        if gene not in labels:
            labels.append(str(gene))
        if len(labels) >= n_labels:
            break
    return labels

def bubble_figure(data: pd.DataFrame, title: str, x_target: str, y_state: str, color: str, stem: str) -> None:
    x = data['Shift_to_goal_end'].to_numpy(dtype=float)
    y = data['Shift_away_start_end'].to_numpy(dtype=float)
    n = data['N_Detections'].fillna(0).to_numpy(dtype=float)
    size = 10 + 90 * np.sqrt(n / max(float(n.max()), 1.0))
    fig, ax = plt.subplots(figsize=(5.45, 5.15), facecolor='white')
    ax.scatter(x, y, s=size, color=color, alpha=0.82, edgecolors='white', linewidths=0.35)
    ax.axvline(0, color='#E53935', lw=0.8, linestyle=(0, (2, 2)))
    ax.axhline(0, color='#E53935', lw=0.8, linestyle=(0, (2, 2)))
    x_span = max(float(x.max() - x.min()), 1e-06)
    y_span = max(float(y.max() - y.min()), 1e-06)
    x_limits = (float(x.min()) - 0.06 * x_span, float(x.max()) + 0.06 * x_span)
    y_limits = (float(y.min()) - 0.08 * y_span, float(y.max()) + 0.08 * y_span)
    diagonal_low = max(x_limits[0], y_limits[0])
    diagonal_high = min(x_limits[1], y_limits[1])
    if diagonal_high > diagonal_low:
        diagonal = np.linspace(diagonal_low, diagonal_high, 100)
        ax.plot(diagonal, diagonal, color='#888888', lw=0.7, linestyle=(0, (5, 3)), zorder=0)
    ax.set_xlim(*x_limits)
    ax.set_ylim(*y_limits)
    labels = label_candidates(data, 13)
    texts = []
    for gene in labels:
        row = data.loc[data['Gene_name'] == gene]
        if row.empty:
            continue
        item = row.iloc[0]
        is_gdf = gene == 'GDF15'
        texts.append(ax.text(item['Shift_to_goal_end'], item['Shift_away_start_end'], gene, fontsize=6.2 if is_gdf else 5.7, fontweight='bold' if is_gdf else 'normal', ha='left', va='bottom', bbox=dict(boxstyle='square,pad=0.12', facecolor='white', edgecolor='black' if is_gdf else 'none', linewidth=0.55 if is_gdf else 0, alpha=0.9)))
    try:
        from adjustText import adjust_text
        adjust_text(texts, ax=ax, arrowprops=dict(arrowstyle='-', color='#777777', lw=0.3), expand=(1.04, 1.08))
    except Exception:
        pass
    ax.set_xlabel(f'Shift to goal state ({x_target})')
    ax.set_ylabel(f'Shift to alternate state ({y_state})')
    ax.set_title(title, loc='left', fontsize=7.4, fontweight='normal', pad=6)
    ax.grid(False)
    for spine in ax.spines.values():
        spine.set_color('#444444')
        spine.set_linewidth(0.65)
    legend_values = sorted(set((int(round(value)) for value in np.quantile(n, [0.25, 0.5, 0.75, 1.0]))))
    handles = [Line2D([0], [0], marker='o', linestyle='', color='none', markerfacecolor=color, markeredgecolor='white', markersize=math.sqrt(10 + 90 * math.sqrt(value / max(float(n.max()), 1.0))) / 1.25, label=str(value)) for value in legend_values]
    ax.legend(handles=handles, title='Number of cells', frameon=False, loc='upper left', fontsize=6, title_fontsize=6.5)
    ax.text(-0.15, 1.11, 'b', transform=ax.transAxes, fontsize=13, fontweight='bold', va='top')
    fig.subplots_adjust(left=0.17, right=0.97, bottom=0.14, top=0.87)
    save_all(fig, stem)

def shared_labels(frames: dict[str, pd.DataFrame], n_labels: int=9) -> list[str]:
    common = set(frames[COHORTS[0]]['Gene_name']) & set(frames[COHORTS[1]]['Gene_name'])
    combined = []
    for gene in common:
        rows = [frames[cohort].loc[frames[cohort]['Gene_name'] == gene].iloc[0] for cohort in COHORTS]
        combined.append({'Gene_name': gene, 'priority': 0 if gene == 'GDF15' else 1 if gene in AXIS_PRIORITY else 2, 'effect': float(sum((np.hypot(row['Shift_to_goal_end'], row['Shift_away_start_end']) for row in rows)))})
    ranked = pd.DataFrame(combined).sort_values(['priority', 'effect'], ascending=[True, False])
    return ranked.head(n_labels)['Gene_name'].astype(str).tolist()

def cluster(ax: plt.Axes, x: float, y: float, color: str, edge: str, seed: int) -> None:
    rng = np.random.default_rng(seed)
    points = rng.normal([x, y], [0.12, 0.12], size=(10, 2))
    ax.scatter(points[:, 0], points[:, 1], s=80, color=color, edgecolors=edge, linewidths=0.6, zorder=3)
    ax.add_patch(plt.Circle((x, y), 0.5, facecolor=color, edgecolor=edge, alpha=0.13, linewidth=0.8))

def oe_schematic(ax: plt.Axes) -> None:
    ax.set_xlim(-2.1, 2.1)
    ax.set_ylim(-1.4, 1.5)
    ax.axis('off')
    cluster(ax, -1.05, 0.0, '#8ACB6A', '#4B9E3D', SEED + 30)
    cluster(ax, 1.1, 0.0, '#C6C6C6', '#8A8A8A', SEED + 31)
    ax.annotate('', xy=(0.62, 0.0), xytext=(-0.47, 0.0), arrowprops=dict(arrowstyle='-|>', lw=1.4, color='#555555'))
    ax.text(0.08, 0.14, 'Shift to goal', ha='center', fontsize=7.5)
    for angle in np.linspace(0, 2 * np.pi, 6, endpoint=False):
        x0 = -1.05 + 0.58 * np.cos(angle)
        y0 = 0.0 + 0.58 * np.sin(angle)
        x1 = -1.05 + 0.86 * np.cos(angle)
        y1 = 0.0 + 0.86 * np.sin(angle)
        ax.annotate('', xy=(x1, y1), xytext=(x0, y0), arrowprops=dict(arrowstyle='-|>', lw=1.0, color='#E07B39'))
    ax.text(-1.48, 0.68, 'Shift away start', ha='center', fontsize=7.5)
    ax.text(-1.05, -0.78, 'Healthy', ha='center', va='top', fontsize=8)
    ax.text(1.1, -0.78, 'Periodontitis', ha='center', va='top', fontsize=8)
    ax.text(0.0, 1.05, 'GDF15 virtual overexpression', ha='center', fontsize=9, fontweight='bold')
    ax.text(-2.02, 1.42, 'A', fontsize=13, fontfamily='serif')

def oe_scatter(ax: plt.Axes, data: pd.DataFrame, cohort: str, color: str, letter: str, labels: list[str]) -> None:
    ax.scatter(data['Shift_to_goal_end'], data['Shift_away_start_end'], s=10, color=color, alpha=0.85, edgecolors='none')
    gdf = data.loc[data['Gene_name'] == 'GDF15']
    ax.scatter(gdf['Shift_to_goal_end'], gdf['Shift_away_start_end'], s=48, color='#D7191C', marker='*', edgecolors='black', linewidths=0.35, zorder=5)
    texts = []
    for gene in labels:
        row = data.loc[data['Gene_name'] == gene]
        if row.empty:
            continue
        item = row.iloc[0]
        texts.append(ax.text(item['Shift_to_goal_end'], item['Shift_away_start_end'], gene, color='#E53935', fontsize=6.2, ha='left', va='bottom'))
    try:
        from adjustText import adjust_text
        adjust_text(texts, ax=ax, arrowprops=dict(arrowstyle='-', color='#E53935', lw=0.3), expand=(1.04, 1.1))
    except Exception:
        pass
    ax.set_xlabel('Shift_to_goal_end (Periodontitis)')
    ax.set_ylabel('Shift_away_start_end (Healthy)')
    ax.set_title(cohort, fontsize=9, pad=3)
    ax.tick_params(length=2.5, width=0.65)
    for spine in ax.spines.values():
        spine.set_color('#555555')
        spine.set_linewidth(0.65)
    ax.text(-0.15, 1.05, letter, transform=ax.transAxes, fontsize=13, fontfamily='serif')

def plot_oe_figure3() -> None:
    frames = {cohort: oe_frame(cohort) for cohort in COHORTS}
    labels = shared_labels(frames, 9)
    fig = plt.figure(figsize=(11.4, 3.35), facecolor='white')
    grid = fig.add_gridspec(1, 3, width_ratios=[1.05, 1.28, 1.28], wspace=0.42)
    ax_a = fig.add_subplot(grid[0, 0])
    ax_b = fig.add_subplot(grid[0, 1])
    ax_c = fig.add_subplot(grid[0, 2])
    oe_schematic(ax_a)
    oe_scatter(ax_b, frames['Williams'], 'Williams', '#66CDE3', 'B', labels)
    oe_scatter(ax_c, frames['Caetano'], 'Caetano', '#F6D84A', 'C', labels)
    fig.subplots_adjust(left=0.025, right=0.985, top=0.93, bottom=0.2)
    save_all(fig, 'Figure3_GDF15_Geneformer_virtual_OE_paper_matched_v2')
    (QA_OUT / 'Figure3_OE_labels.json').write_text(json.dumps({'shared_red_labels': labels}, ensure_ascii=False, indent=2), encoding='utf-8')

def copy_originals() -> None:
    sources = [ROOT / '05_\u8bba\u6587\u540c\u578b\u56fe' / 'Figure3_GDF15_Geneformer_virtual_KO_paper_matched.pdf', EXT_OLD / '\u56fe\u7247' / '\u56fe1_Geneformer\u5206\u7c7b\u9884\u6d4b\u70ed\u56fe\u4e0e\u6df7\u6dc6\u77e9\u9635_PLOS\u56fe2D-E\u540c\u578b.pdf', EXT_OLD / '\u56fe\u7247' / '\u56fe2_GDF15\u6572\u9664\u4e0e\u8fc7\u8868\u8fbe\u654f\u611f\u6027UMAP_Frontiers\u56fe5B-C\u540c\u578b.pdf', EXT_OLD / '\u56fe\u7247' / '\u56fe3_GDF15\u6572\u9664\u4e0e\u8fc7\u8868\u8fbe\u5706\u5f62\u57fa\u56e0\u8bc1\u636e\u56fe_Frontiers\u56fe5D-E\u540c\u578b.pdf', EXT_OLD / '\u56fe\u7247' / '\u56fe4_GDF15\u865a\u62df\u6572\u9664\u5019\u9009\u6cbb\u7597\u9776\u70b9\u6c14\u6ce1\u56fe_Geneformer\u56fe2b\u540c\u578b.pdf']
    for source in sources:
        shutil.copy2(source, ORIGINAL_OUT / f'\u539f\u56fe_{source.name}')

def main() -> None:
    ensure_dirs()
    style()
    plot_prediction_heatmap_confusion()
    plot_extended_data7_benchmark()
    plot_umap_sensitivity()
    plot_circular_evidence()
    bubble_figure(ko_frame('Williams'), 'Candidate therapeutic targets whose in silico deletion in periodontitis fibroblasts\nshifts toward Healthy, away from Periodontitis', 'Healthy', 'Periodontitis', '#E94B35', '\u56fe4_GDF15\u865a\u62df\u6572\u9664\u5019\u9009\u6cbb\u7597\u9776\u70b9\u6c14\u6ce1\u56fe_Geneformer\u4e25\u683c\u540c\u578b_v2')
    bubble_figure(oe_frame('Williams'), 'Candidate genes whose in silico activation in healthy fibroblasts\nshifts toward Periodontitis, away from Healthy', 'Periodontitis', 'Healthy', '#2D6DA3', '\u56fe5_GDF15\u8fc7\u8868\u8fbe\u5065\u5eb7\u5411\u7259\u5468\u708e\u5019\u9009\u57fa\u56e0\u6c14\u6ce1\u56fe_Geneformer\u4e25\u683c\u540c\u578b_v2')
    plot_oe_figure3()
    copy_originals()
    print('Seven v2 figures written in PDF/SVG/PNG; originals copied without recalculation', flush=True)
if __name__ == '__main__':
    main()
