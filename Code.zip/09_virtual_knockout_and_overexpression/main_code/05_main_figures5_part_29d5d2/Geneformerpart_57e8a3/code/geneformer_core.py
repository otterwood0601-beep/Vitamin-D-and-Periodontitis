from __future__ import annotations
import json
import math
import os
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from sklearn.metrics import accuracy_score, balanced_accuracy_score, confusion_matrix, f1_score, roc_auc_score
from torch.utils.data import Dataset
from transformers import BertForSequenceClassification
SEED = 20260904
MODEL_DIR = Path('/opt/Geneformer_official/Geneformer-V1-10M')
DICT_DIR = Path('/opt/Geneformer_official/geneformer/gene_dictionaries_30m')
PAD_TOKEN_ID = 0
GDF15_ENSEMBL = 'ENSG00000130513'
GDF15_TOKEN_ID = 6248
MAX_LENGTH = 2048
MAPK_PRIORITY = {'MAPK1', 'MAPK3', 'DUSP1', 'DUSP2', 'DUSP5', 'DUSP6', 'FOS', 'FOSB', 'JUN', 'JUNB', 'JUND', 'EGR1', 'EGR2', 'ATF3', 'NR4A1', 'ELK1', 'STAT3', 'PIK3R1', 'SPRY1', 'SPRY2', 'RASA1', 'RAF1', 'BRAF'}
ECM_PRIORITY = {'COL1A1', 'COL1A2', 'COL3A1', 'COL4A1', 'COL4A2', 'COL5A1', 'COL5A2', 'COL6A1', 'COL6A2', 'COL6A3', 'COL12A1', 'FN1', 'POSTN', 'SPARC', 'MMP1', 'MMP2', 'MMP3', 'MMP9', 'MMP14', 'TIMP1', 'TIMP2', 'TIMP3', 'AEBP1', 'FBLN1', 'FBLN2', 'FBLN5', 'EFEMP1', 'SFRP1', 'SFRP2', 'SLIT3', 'ITGBL1', 'THBS1', 'THBS2', 'LOX', 'LOXL1', 'LOXL2', 'TGFB1', 'TGFBR1', 'TGFBR2', 'CTGF', 'SERPINE1', 'VCAN', 'DCN', 'LUM', 'BGN', 'C1S', 'C1R', 'A2M'}
AXIS_PRIORITY = MAPK_PRIORITY | ECM_PRIORITY | {'GDF15'}

def set_deterministic(seed: int=SEED) -> None:
    os.environ.setdefault('PYTHONHASHSEED', str(seed))
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.use_deterministic_algorithms(False)
    torch.set_num_threads(min(14, os.cpu_count() or 1))

def write_json(path: Path, payload: dict | list) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')

def bh_fdr(p_values: Sequence[float]) -> np.ndarray:
    p = np.asarray(p_values, dtype=float)
    out = np.full(p.shape, np.nan, dtype=float)
    valid = np.isfinite(p)
    if not valid.any():
        return out
    pv = p[valid]
    order = np.argsort(pv)
    ranked = pv[order]
    q = ranked * len(ranked) / np.arange(1, len(ranked) + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    q = np.clip(q, 0, 1)
    restored = np.empty_like(q)
    restored[order] = q
    out[valid] = restored
    return out

class TokenArrayDataset(Dataset):

    def __init__(self, input_ids: np.ndarray, lengths: np.ndarray, labels: np.ndarray, indices: Sequence[int]):
        self.input_ids = input_ids
        self.lengths = lengths
        self.labels = labels
        self.indices = np.asarray(indices, dtype=np.int64)

    def __len__(self) -> int:
        return len(self.indices)

    def __getitem__(self, item: int) -> dict:
        idx = int(self.indices[item])
        length = int(self.lengths[idx])
        return {'input_ids': torch.as_tensor(self.input_ids[idx, :length], dtype=torch.long), 'labels': torch.tensor(int(self.labels[idx]), dtype=torch.long), 'dataset_index': idx}

def collate_tokens(items: list[dict]) -> dict:
    max_len = max((int(x['input_ids'].shape[0]) for x in items))
    batch = torch.full((len(items), max_len), PAD_TOKEN_ID, dtype=torch.long)
    mask = torch.zeros((len(items), max_len), dtype=torch.long)
    labels = torch.empty(len(items), dtype=torch.long)
    indices = np.empty(len(items), dtype=np.int64)
    for i, item in enumerate(items):
        length = int(item['input_ids'].shape[0])
        batch[i, :length] = item['input_ids']
        mask[i, :length] = 1
        labels[i] = item['labels']
        indices[i] = int(item['dataset_index'])
    return {'input_ids': batch, 'attention_mask': mask, 'labels': labels, 'dataset_index': indices}

def load_classifier(model_path: Path | str, trainable: bool=False) -> BertForSequenceClassification:
    model = BertForSequenceClassification.from_pretrained(str(model_path), num_labels=2, ignore_mismatched_sizes=True)
    if not trainable:
        model.eval()
    return model

def freeze_lower_layers(model: BertForSequenceClassification, freeze_layers: int=5) -> dict:
    for parameter in model.bert.embeddings.parameters():
        parameter.requires_grad = False
    for layer_index, layer in enumerate(model.bert.encoder.layer):
        requires_grad = layer_index >= freeze_layers
        for parameter in layer.parameters():
            parameter.requires_grad = requires_grad
    trainable = sum((p.numel() for p in model.parameters() if p.requires_grad))
    total = sum((p.numel() for p in model.parameters()))
    return {'total_parameters': total, 'trainable_parameters': trainable, 'trainable_fraction': trainable / total}

def mean_pool(last_hidden: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
    weights = attention_mask.unsqueeze(-1).to(last_hidden.dtype)
    summed = (last_hidden * weights).sum(dim=1)
    denom = weights.sum(dim=1).clamp_min(1.0)
    return summed / denom

def batch_embeddings(model: BertForSequenceClassification, input_ids: np.ndarray, lengths: np.ndarray, indices: Sequence[int], batch_size: int=8) -> np.ndarray:
    model.eval()
    embeddings: list[np.ndarray] = []
    with torch.inference_mode():
        for start in range(0, len(indices), batch_size):
            batch_indices = np.asarray(indices[start:start + batch_size], dtype=int)
            batch_lengths = lengths[batch_indices].astype(int)
            max_len = int(batch_lengths.max())
            ids = torch.as_tensor(input_ids[batch_indices, :max_len], dtype=torch.long)
            positions = torch.arange(max_len).unsqueeze(0)
            mask = (positions < torch.as_tensor(batch_lengths).unsqueeze(1)).long()
            outputs = model.bert(input_ids=ids, attention_mask=mask, return_dict=True)
            pooled = mean_pool(outputs.last_hidden_state, mask)
            embeddings.append(pooled.cpu().numpy().astype(np.float32))
    return np.concatenate(embeddings, axis=0)

def embed_variable_sequences(model: BertForSequenceClassification, sequences: Sequence[np.ndarray], batch_size: int=8) -> np.ndarray:
    model.eval()
    result: list[np.ndarray] = []
    with torch.inference_mode():
        for start in range(0, len(sequences), batch_size):
            chunk = sequences[start:start + batch_size]
            max_len = max((len(x) for x in chunk))
            ids = torch.full((len(chunk), max_len), PAD_TOKEN_ID, dtype=torch.long)
            mask = torch.zeros((len(chunk), max_len), dtype=torch.long)
            for i, seq in enumerate(chunk):
                length = len(seq)
                ids[i, :length] = torch.as_tensor(seq, dtype=torch.long)
                mask[i, :length] = 1
            outputs = model.bert(input_ids=ids, attention_mask=mask, return_dict=True)
            result.append(mean_pool(outputs.last_hidden_state, mask).cpu().numpy().astype(np.float32))
    return np.concatenate(result, axis=0) if result else np.empty((0, model.config.hidden_size), dtype=np.float32)

def cosine_to_centroid(embeddings: np.ndarray, centroid: np.ndarray) -> np.ndarray:
    emb = torch.as_tensor(embeddings, dtype=torch.float32)
    cen = torch.as_tensor(centroid, dtype=torch.float32).reshape(1, -1)
    return F.cosine_similarity(emb, cen, dim=1).cpu().numpy()

def state_shift(original: np.ndarray, perturbed: np.ndarray, goal_centroid: np.ndarray, start_centroid: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    shift_goal = cosine_to_centroid(perturbed, goal_centroid) - cosine_to_centroid(original, goal_centroid)
    shift_start = cosine_to_centroid(perturbed, start_centroid) - cosine_to_centroid(original, start_centroid)
    return (shift_goal, shift_start)

def classifier_metrics(labels: np.ndarray, probabilities: np.ndarray) -> dict:
    predicted = (probabilities >= 0.5).astype(int)
    metrics = {'accuracy': float(accuracy_score(labels, predicted)), 'balanced_accuracy': float(balanced_accuracy_score(labels, predicted)), 'macro_f1': float(f1_score(labels, predicted, average='macro')), 'confusion_matrix': confusion_matrix(labels, predicted, labels=[0, 1]).tolist()}
    try:
        metrics['roc_auc'] = float(roc_auc_score(labels, probabilities))
    except ValueError:
        metrics['roc_auc'] = None
    return metrics

def stratified_sample_indices(metadata: pd.DataFrame, n_total: int, group_columns: Sequence[str], seed: int=SEED) -> np.ndarray:
    if len(metadata) <= n_total:
        return metadata.index.to_numpy(dtype=int)
    rng = np.random.default_rng(seed)
    groups = list(metadata.groupby(list(group_columns), sort=True, observed=True))
    allocations = {key: max(1, int(round(n_total * len(group) / len(metadata)))) for key, group in groups}
    while sum(allocations.values()) > n_total:
        key = max(allocations, key=lambda k: allocations[k])
        if allocations[key] > 1:
            allocations[key] -= 1
        else:
            break
    while sum(allocations.values()) < n_total:
        key = max(groups, key=lambda item: len(item[1]) - allocations[item[0]])[0]
        allocations[key] += 1
    selected: list[int] = []
    for key, group in groups:
        take = min(allocations[key], len(group))
        selected.extend(rng.choice(group.index.to_numpy(dtype=int), size=take, replace=False).tolist())
    return np.asarray(selected[:n_total], dtype=int)

def bootstrap_mean_ci(values: Sequence[float], seed: int=SEED, n_boot: int=2000) -> tuple[float, float]:
    arr = np.asarray(values, dtype=float)
    arr = arr[np.isfinite(arr)]
    if len(arr) == 0:
        return (math.nan, math.nan)
    if len(arr) == 1:
        return (float(arr[0]), float(arr[0]))
    rng = np.random.default_rng(seed)
    means = np.empty(n_boot, dtype=float)
    for i in range(n_boot):
        means[i] = rng.choice(arr, size=len(arr), replace=True).mean()
    return (float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975)))

def priority_class(gene_symbol: str) -> str:
    if gene_symbol == 'GDF15':
        return 'GDF15'
    if gene_symbol in MAPK_PRIORITY:
        return 'MAPK-response'
    if gene_symbol in ECM_PRIORITY:
        return 'ECM-remodeling'
    return 'Other'
