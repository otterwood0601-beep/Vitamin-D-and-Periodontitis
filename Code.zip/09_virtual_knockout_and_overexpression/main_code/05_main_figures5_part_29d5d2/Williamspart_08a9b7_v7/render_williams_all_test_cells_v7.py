from __future__ import annotations
import hashlib
import importlib.util
import json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from scipy.special import expit
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, roc_auc_score
RESULTS = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa')
SOURCE_ROOT = RESULTS / '20260904_Geneformer_GDF15_ERK_MAPK_ECM_\u8bba\u6587\u540c\u578b\u590d\u73b0_v1'
V6 = RESULTS / '20260906_Geneformer_Williams\u51bb\u7ed3\u7f16\u7801\u5668\u5206\u7c7b\u5934\u4f18\u5316_\u652f\u7ebf_v6'
OUT = RESULTS / '20260906_Geneformer_Williams\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de_D-E\u91cd\u7ed8_\u652f\u7ebf_v7'
SPLITS = SOURCE_ROOT / '02_\u72b6\u6001\u5206\u7c7b\u5668/Williams/data_splits.csv'
EMBEDDINGS = SOURCE_ROOT / '14_GDF15\u5168\u7ec6\u80de\u6572\u9664\u654f\u611f\u6027UMAP_\u652f\u7ebf_v1/\u6570\u636e\u8868/Williams_Geneformer_\u5168\u90e813257\u7ec6\u80de\u539f\u59cb\u5d4c\u5165.npz'
MODEL = V6 / '\u6a21\u578b/Williams_Geneformer\u51bb\u7ed3\u7f16\u7801\u5668_\u4f18\u5316\u7ebf\u6027\u5206\u7c7b\u5934.joblib'
V6_AUDIT = V6 / 'QA/\u8fd0\u884c\u4e0e\u65b9\u6cd5\u5ba1\u8ba1.json'
V6_FIGURE = V6 / '\u56fe\u7247/\u56fe1_Geneformer\u7ec6\u80de\u72b6\u6001\u9884\u6d4b\u70ed\u56fe\u4e0e\u6df7\u6dc6\u77e9\u9635_Williams\u51bb\u7ed3\u7f16\u7801\u5668\u5206\u7c7b\u5934\u4f18\u5316_v6.pdf'
PLOTTER = SOURCE_ROOT / '12_\u56fe1_\u56feD\u6a2a\u5411\u534a\u5bbd_\u652f\u7ebf_v4/\u4ee3\u7801/render_panel_d_half_width_v4.py'
FIGURE_STEM = '\u56fe1_Geneformer\u7ec6\u80de\u72b6\u6001\u9884\u6d4b\u70ed\u56fe\u4e0e\u6df7\u6dc6\u77e9\u9635_Williams\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de_v7'

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def load_plotter():
    spec = importlib.util.spec_from_file_location('paper_matched_plotter', PLOTTER)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'Unable to load plotting module: {PLOTTER}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def compute_metrics(labels: np.ndarray, predictions: np.ndarray, scores: np.ndarray) -> dict:
    matrix = confusion_matrix(labels, predictions, labels=[0, 1])
    tn, fp, fn, tp = matrix.ravel()
    return {'accuracy': float(accuracy_score(labels, predictions)), 'macro_f1': float(f1_score(labels, predictions, average='macro')), 'roc_auc': float(roc_auc_score(labels, scores)), 'sensitivity_periodontitis': float(tp / (tp + fn)), 'specificity_healthy': float(tn / (tn + fp)), 'confusion_matrix': matrix.astype(int).tolist()}

def main() -> None:
    for subdirectory in ('\u4ee3\u7801', '\u6570\u636e\u8868', '\u56fe\u7247', 'QA'):
        (OUT / subdirectory).mkdir(parents=True, exist_ok=True)
    guards = [MODEL, V6_AUDIT, V6_FIGURE]
    hashes_before = {str(path): sha256(path) for path in guards}
    splits = pd.read_csv(SPLITS)
    test = splits.loc[splits['split'].eq('test')].sort_values('dataset_index', kind='stable').copy()
    if len(test) != 1450:
        raise ValueError(f'Expected 1450 Williams test cells, found {len(test)}')
    counts = test['label'].value_counts().sort_index().to_dict()
    if counts != {0: 912, 1: 538}:
        raise ValueError(f'Unexpected class counts: {counts}')
    if test['dataset_index'].duplicated().any() or test['cell_id'].duplicated().any():
        raise ValueError('Duplicate test-cell identifiers detected')
    if test[['dataset_index', 'label', 'donor_id', 'cell_id']].isna().any().any():
        raise ValueError('Missing required values in the full Williams test population')
    train_donors = set(splits.loc[splits['split'].eq('train'), 'donor_id'].astype(str))
    validation_donors = set(splits.loc[splits['split'].eq('validation'), 'donor_id'].astype(str))
    test_donors = set(test['donor_id'].astype(str))
    donor_overlap = {'train_test': sorted(train_donors & test_donors), 'validation_test': sorted(validation_donors & test_donors)}
    if any(donor_overlap.values()):
        raise ValueError(f'Donor leakage detected: {donor_overlap}')
    bundle = np.load(EMBEDDINGS)
    embedding_indices = bundle['dataset_indices'].astype(int)
    embedding_matrix = bundle['original_embeddings'].astype(np.float32)
    if len(np.unique(embedding_indices)) != len(embedding_indices):
        raise ValueError('Embedding indices are not unique')
    lookup = pd.Series(np.arange(len(embedding_indices)), index=embedding_indices)
    if not test['dataset_index'].isin(lookup.index).all():
        raise ValueError('Some full-test cells lack saved Geneformer embeddings')
    x_test = embedding_matrix[lookup.loc[test['dataset_index'].astype(int)].to_numpy(int)]
    labels = test['label'].to_numpy(int)
    saved = joblib.load(MODEL)
    model = saved['pipeline']
    threshold = float(saved['selected_threshold_raw_decision_score'])
    scores = np.asarray(model.decision_function(x_test), dtype=float).reshape(-1)
    predictions = (scores >= threshold).astype(int)
    metrics = compute_metrics(labels, predictions, scores)
    output = test[['cell_id', 'donor_id', 'disease', 'dataset_index', 'label', 'split', 'used_for_training_run']].rename(columns={'label': 'observed_label'}).copy()
    output['cohort'] = 'Williams'
    output['decision_score_raw'] = scores
    output['healthy_head_score_raw'] = -0.5 * scores
    output['periodontitis_head_score_raw'] = 0.5 * scores
    output['display_probability_from_decision_score'] = expit(scores)
    output['threshold_raw_decision_score_selected_on_v6_validation'] = threshold
    output['predicted_label'] = predictions
    output.to_csv(OUT / '\u6570\u636e\u8868/Williams\u5168\u90e81450\u4e2a\u6d4b\u8bd5\u7ec6\u80de_\u9010\u7ec6\u80de\u539f\u59cb\u51b3\u7b56\u5206\u6570.csv.gz', index=False, encoding='utf-8-sig', compression='gzip')
    plot_data = pd.DataFrame({'cohort': 'Williams', 'observed_label': labels, 'healthy_logit_raw': -0.5 * scores, 'periodontitis_logit_raw': 0.5 * scores, 'probability_from_raw_logits': expit(scores)})
    plotter = load_plotter()
    figure_info = plotter.plot(plot_data, {'Williams': float(expit(threshold))}, figure_output_dir=OUT / '\u56fe\u7247', figure_stem=FIGURE_STEM, colorbar_height_fraction=0.6, metric_decimals=5)
    if figure_info['confusion_matrix'] != metrics['confusion_matrix']:
        raise RuntimeError('Rendered confusion matrix does not match independently recomputed values')
    if not np.isclose(figure_info['accuracy'], metrics['accuracy']):
        raise RuntimeError('Rendered accuracy does not match independently recomputed value')
    if not np.isclose(figure_info['macro_f1'], metrics['macro_f1']):
        raise RuntimeError('Rendered macro-F1 does not match independently recomputed value')
    v6_audit = json.loads(V6_AUDIT.read_text(encoding='utf-8'))
    comparison = pd.DataFrame([{'evaluation_population': 'fixed balanced Williams test subset', 'healthy_n': 300, 'periodontitis_n': 300, 'total_n': 600, **{key: v6_audit['test_v6'][key] for key in ('accuracy', 'macro_f1', 'roc_auc', 'sensitivity_periodontitis', 'specificity_healthy')}, 'confusion_matrix': json.dumps(v6_audit['test_v6']['confusion_matrix'])}, {'evaluation_population': 'all Williams test cells', 'healthy_n': 912, 'periodontitis_n': 538, 'total_n': 1450, **{key: metrics[key] for key in ('accuracy', 'macro_f1', 'roc_auc', 'sensitivity_periodontitis', 'specificity_healthy')}, 'confusion_matrix': json.dumps(metrics['confusion_matrix'])}])
    comparison.to_csv(OUT / '\u6570\u636e\u8868/v6\u56fa\u5b9a600\u7ec6\u80de\u4e0ev7\u5168\u90e81450\u6d4b\u8bd5\u7ec6\u80de_\u6548\u80fd\u5bf9\u6bd4.csv', index=False, encoding='utf-8-sig')
    hashes_after = {str(path): sha256(path) for path in guards}
    if hashes_before != hashes_after:
        raise RuntimeError('A guarded v6 source artifact changed unexpectedly')
    chart_contract = {'question': 'How does the frozen Williams Geneformer classifier perform across every cell assigned to the donor-isolated test partition?', 'takeaway': 'Panels D and E show all 1,450 held-out Williams test cells without class balancing or test-guided retuning.', 'family': 'Matrix & Cohort', 'variant': 'two-column raw-score heatmap plus row-normalized confusion matrix', 'grain': 'one Williams fibroblast per heatmap row; one true/predicted class intersection per confusion-matrix cell', 'population': {'Healthy': 912, 'Periodontitis': 538, 'total': 1450}, 'sorting': 'stable grouping by true class only; no score-based within-group sorting', 'palette': 'paper-matched purple/light-green state strips, diverging raw-score heatmap, blue confusion matrix', 'surface': 'standalone static PDF with PNG/SVG companions', 'qa_surface': str(OUT / 'QA/\u56fe1_v7_Poppler.png')}
    (OUT / '\u56fe\u5f62\u89c4\u8303.json').write_text(json.dumps(chart_contract, ensure_ascii=False, indent=2), encoding='utf-8')
    audit = {'status': 'one-time side-task v7; v6 and all earlier artifacts unchanged', 'scope': 'all cells assigned to the Williams donor-isolated test partition', 'population': {'Healthy': 912, 'Periodontitis': 538, 'total': 1450}, 'model': 'unchanged v6 frozen Geneformer encoder plus optimized LinearSVC head', 'threshold': {'raw_decision_score': threshold, 'source': 'v6 Williams validation set only; not re-estimated on the 1450 test cells'}, 'donor_overlap': donor_overlap, 'data_quality': {'duplicate_dataset_index': int(test['dataset_index'].duplicated().sum()), 'duplicate_cell_id': int(test['cell_id'].duplicated().sum()), 'missing_required_values': int(test[['dataset_index', 'label', 'donor_id', 'cell_id']].isna().sum().sum()), 'embedding_coverage': float(test['dataset_index'].isin(lookup.index).mean())}, 'metrics': metrics, 'figure': figure_info, 'guarded_v6_files_sha256_before': hashes_before, 'guarded_v6_files_sha256_after': hashes_after, 'sources': {'split_table': str(SPLITS), 'embeddings': str(EMBEDDINGS), 'frozen_model': str(MODEL)}}
    (OUT / 'QA/\u8fd0\u884c\u4e0e\u6570\u636e\u8d28\u91cf\u5ba1\u8ba1.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
    readme = f"# Williams \u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de D/E \u91cd\u7ed8\uff08v7\uff09\n\n\u672c\u7248\u4f7f\u7528 Williams \u6d4b\u8bd5\u5206\u533a\u7684\u5168\u90e8 1,450 \u4e2a\u7ec6\u80de\uff1aHealthy 912\u3001Periodontitis 538\u3002\n\n- \u6a21\u578b\u6cbf\u7528\u5df2\u51bb\u7ed3\u7684 v6 Geneformer \u7f16\u7801\u5668\u4e0e LinearSVC \u5206\u7c7b\u5934\u3002\n- \u5224\u5b9a\u9608\u503c\u6cbf\u7528 v6 \u9a8c\u8bc1\u96c6\u786e\u5b9a\u7684 {threshold:.8f}\uff0c\u672a\u4f7f\u7528\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de\u91cd\u65b0\u8c03\u53c2\u3002\n- \u56fe D \u7684\u6bcf\u4e00\u884c\u4ee3\u8868\u4e00\u4e2a\u6d4b\u8bd5\u7ec6\u80de\uff0c\u4ec5\u6309\u771f\u5b9e\u7c7b\u522b\u5206\u7ec4\uff0c\u7ec4\u5185\u4e0d\u6309\u9884\u6d4b\u5206\u6570\u6392\u5e8f\u3002\n- \u56fe E \u6309\u6bcf\u4e2a\u771f\u5b9e\u7c7b\u522b\u5f52\u4e00\u5316\uff0c\u56e0\u6b64\u7eb5\u8f74\u6837\u672c\u91cf\u5206\u522b\u663e\u793a n=912 \u548c n=538\u3002\n\n\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de\u7ed3\u679c\uff1aACC {metrics['accuracy']:.5f}\uff0cmacro-F1 {metrics['macro_f1']:.5f}\uff0cROC-AUC {metrics['roc_auc']:.5f}\uff1b\u6df7\u6dc6\u77e9\u9635\u4e3a {metrics['confusion_matrix']}\u3002\n\n\u672c\u76ee\u5f55\u672a\u8986\u76d6 v6 \u6216\u66f4\u65e9\u7248\u672c\u3002\u9010\u7ec6\u80de\u5206\u6570\u3001600\u7ec6\u80de\u4e0e1,450\u7ec6\u80de\u5bf9\u6bd4\u53ca\u5ba1\u8ba1\u8bb0\u5f55\u5747\u5df2\u7559\u5b58\u3002\n"
    (OUT / 'README_\u8bf7\u5148\u770b.md').write_text(readme, encoding='utf-8')
    print(json.dumps(audit, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
