from __future__ import annotations
import importlib.util
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd
from matplotlib.ticker import FuncFormatter
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260907_Geneformer_GDF15_KO_OE_UMAP1\u53cc\u9608\u503c_\u53bb\u8868\u5934_v1')
BASE_SCRIPT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260907_Geneformer_GDF15_Williams_ECM\u5206\u72b6\u6001_\u6b63\u5f0f\u5750\u6807_\u539f\u59cb\u4e0e\u7ebf\u6027\u5e73\u6ed1_v1\\\u4ee3\u7801\\01_\u751f\u6210Williams_ECM\u5206\u72b6\u6001_\u6b63\u5f0f\u5750\u6807_\u539f\u59cb\u4e0e\u7ebf\u6027\u5e73\u6ed1.py')
SOURCE_KO_DIR = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260907_Geneformer_GDF15_Williams_ECM_KO\u4e0eOE\u7edf\u4e00\u5750\u6807\u8f74_v2\\\u56fe\u7247')
SOURCE_OE_DIR = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260907_Geneformer_GDF15_Williams_ECM\u5206\u72b6\u6001_\u6b63\u5f0f\u5750\u6807_\u539f\u59cb\u4e0e\u7ebf\u6027\u5e73\u6ed1_v1\\\u56fe\u7247')
SOURCE_PDFS = {'KO_raw': SOURCE_KO_DIR / '\u56fe2B_GDF15\u6572\u9664\u654f\u611f\u6027UMAP_Williams\u7259\u5468\u708e\u5168\u90e8ECM-remodeling\u7ec6\u80de_\u4e0eOE\u5b8c\u5168\u76f8\u540c\u5750\u6807\u8f74_\u539f\u59cb\u503c.pdf', 'KO_smoothed': SOURCE_KO_DIR / '\u56fe2B_GDF15\u6572\u9664\u654f\u611f\u6027UMAP_Williams\u7259\u5468\u708e\u5168\u90e8ECM-remodeling\u7ec6\u80de_\u4e0eOE\u5b8c\u5168\u76f8\u540c\u5750\u6807\u8f74_\u90bb\u57df\u7ebf\u6027\u5e73\u6ed1\u5c55\u793a\u7248.pdf', 'OE': SOURCE_OE_DIR / '\u56fe2C_GDF15\u8fc7\u8868\u8fbe\u654f\u611f\u6027UMAP_Williams\u5065\u5eb7\u5168\u90e8ECM-remodeling\u7ec6\u80de_\u6b63\u5f0f\u5750\u6807_\u539f\u59cb\u503c.pdf'}
FIG_DIR = ROOT / '\u56fe\u7247'
TABLE_DIR = ROOT / '\u6570\u636e\u8868'
QA_DIR = ROOT / 'QA'

def load_base_module():
    spec = importlib.util.spec_from_file_location('williams_ecm_headerless', BASE_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError('Unable to load the source plotting script')
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module

def select_in_axes(frame: pd.DataFrame, xlim: tuple[float, float], ylim: tuple[float, float]) -> pd.DataFrame:
    keep = frame['UMAP_1'].between(*xlim) & frame['UMAP_2'].between(*ylim)
    return frame.loc[keep].copy().reset_index(drop=True)

def draw_panel(base, frame: pd.DataFrame, value_column: str, raw_reference_column: str, cmap_name: str, panel_letter: str, xlim: tuple[float, float], ylim: tuple[float, float], vmax: float, gray_base: bool, stem: str) -> dict[str, object]:
    x = frame['UMAP_1'].to_numpy(float)
    y = frame['UMAP_2'].to_numpy(float)
    values = pd.to_numeric(frame[value_column], errors='coerce').to_numpy(float) * 1000.0
    raw_reference = pd.to_numeric(frame[raw_reference_column], errors='coerce').to_numpy(float) * 1000.0
    colored_mask = np.isfinite(values)
    data_ratio = (xlim[1] - xlim[0]) / (ylim[1] - ylim[0])
    figure_height = 5.1
    figure_width = min(7.0, max(4.15, 1.05 + 4.25 * data_ratio))
    fig, ax = base.plt.subplots(figsize=(figure_width, figure_height), layout='constrained')
    base_size = 5.0 if len(frame) < 800 else 2.8
    color_size = 8.2 if len(frame) < 800 else 3.8
    if gray_base:
        ax.scatter(x, y, s=base_size, c='#DDDDDD', alpha=0.78, edgecolors='none', linewidths=0, zorder=1)
    order = np.flatnonzero(colored_mask)
    order = order[np.argsort(values[order], kind='stable')]
    cmap = base.truncated_colormap(cmap_name, low=0.1)
    norm = base.Normalize(vmin=0.0, vmax=vmax, clip=True)
    colored = ax.scatter(x[order], y[order], s=color_size, c=values[order], cmap=cmap, norm=norm, alpha=0.95, edgecolors='none', linewidths=0, zorder=2)
    ax.set_xlim(*xlim)
    ax.set_ylim(*ylim)
    ax.set_aspect('equal', adjustable='box')
    ax.set_xlabel('UMAP 1')
    ax.set_ylabel('UMAP 2')
    ax.grid(False)
    ax.set_facecolor('white')
    ax.margins(0)
    ax.tick_params(direction='out', length=3.2, width=0.7, color='#222222')
    if np.isclose(xlim[0], 0.5):
        ax.set_xticks([0.5, 2.0, 4.0, 6.0])
        ax.xaxis.set_major_formatter(FuncFormatter(lambda value, _pos: f'{value:g}'))
    elif np.isclose(xlim[0], 0.0):
        ax.set_xticks([0.0, 2.0, 4.0, 6.0])
        ax.xaxis.set_major_formatter(FuncFormatter(lambda value, _pos: f'{value:g}'))
    else:
        ax.xaxis.set_major_locator(base.MaxNLocator(nbins=6))
    ax.yaxis.set_major_locator(base.MaxNLocator(nbins=6))
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_color('#222222')
    ax.spines['bottom'].set_color('#222222')
    ax.spines['left'].set_linewidth(0.75)
    ax.spines['bottom'].set_linewidth(0.75)
    ax.text(0.015, 0.985, panel_letter, transform=ax.transAxes, fontsize=17, va='top', ha='left')
    colorbar = fig.colorbar(colored, ax=ax, fraction=0.052, pad=0.025)
    if colorbar.solids is not None:
        colorbar.solids.remove()
    color_edges = np.linspace(0.0, vmax, 513)
    for lower, upper in zip(color_edges[:-1], color_edges[1:]):
        midpoint = 0.5 * (lower + upper)
        colorbar.ax.add_patch(base.Rectangle((0.0, lower), 1.0, upper - lower, facecolor=cmap(norm(midpoint)), edgecolor=cmap(norm(midpoint)), linewidth=0.0, zorder=0))
    colorbar.ax.set_title('Cosine shift\n(x10^3)', fontsize=9.0, pad=5)
    colorbar.ax.yaxis.set_major_locator(base.MaxNLocator(nbins=5))
    colorbar.ax.tick_params(labelsize=8, length=3, width=0.65)
    colorbar.outline.set_linewidth(0.65)
    outputs: dict[str, str] = {}
    for suffix, kwargs in (('pdf', {}), ('svg', {}), ('png', {'dpi': 600})):
        output = FIG_DIR / f'{stem}.{suffix}'
        fig.savefig(output, bbox_inches='tight', pad_inches=0.035, facecolor='white', **kwargs)
        outputs[suffix] = str(output)
    base.plt.close(fig)
    return {'plotted_cells': int(len(frame)), 'colored_cells': int(colored_mask.sum()), 'raw_observed_cells': int(np.isfinite(raw_reference).sum()), 'xlim': list(xlim), 'ylim': list(ylim), 'color_scale_vmax_x1e3': float(vmax), 'title_removed': True, 'outputs': outputs}

def main() -> None:
    for directory in (FIG_DIR, TABLE_DIR, QA_DIR, QA_DIR / 'PDF\u6e32\u67d3\u68c0\u67e5'):
        directory.mkdir(parents=True, exist_ok=True)
    base = load_base_module()
    base.configure_style()
    source_hashes_before = {key: base.sha256(path) for key, path in SOURCE_PDFS.items()}
    periodontitis, healthy = base.load_and_validate()
    smoothed = base.make_linear_smoothed_ko(periodontitis)
    original_xlim = (-4.485280178207397, 6.833683480252695)
    original_ylim = (-4.8033357042048435, 4.012724355384307)
    axis_versions = {'\u539f\u56fe': (original_xlim, original_ylim), '\u65b0\u56fe1': ((0.5, original_xlim[1]), original_ylim), '\u65b0\u56fe2': ((0.0, original_xlim[1]), original_ylim)}
    ko_raw_full = pd.to_numeric(periodontitis['GDF15_KO_cosine_shift'], errors='coerce').dropna().to_numpy(float) * 1000.0
    oe_full = pd.to_numeric(healthy['GDF15_OE_cosine_shift'], errors='coerce').dropna().to_numpy(float) * 1000.0
    ko_vmax = float(np.quantile(ko_raw_full, 0.99))
    oe_vmax = float(np.quantile(oe_full, 0.99))
    outputs: dict[str, dict[str, object]] = {}
    inclusion_rows: list[dict[str, object]] = []
    for version, (xlim, ylim) in axis_versions.items():
        ko_raw_visible = select_in_axes(periodontitis, xlim, ylim)
        ko_smoothed_visible = select_in_axes(smoothed, xlim, ylim)
        oe_visible = select_in_axes(healthy, xlim, ylim)
        outputs[f'{version}_KO_\u539f\u59cb'] = draw_panel(base, ko_raw_visible, 'GDF15_KO_cosine_shift', 'GDF15_KO_cosine_shift', 'Reds', 'B', xlim, ylim, ko_vmax, True, f'{version}_KO_\u539f\u59cb')
        outputs[f'{version}_KO_\u5e73\u6ed1'] = draw_panel(base, ko_smoothed_visible, 'GDF15_KO_cosine_shift_smoothed_display', 'GDF15_KO_cosine_shift', 'Reds', 'B', xlim, ylim, ko_vmax, True, f'{version}_KO_\u5e73\u6ed1')
        outputs[f'{version}_OE'] = draw_panel(base, oe_visible, 'GDF15_OE_cosine_shift', 'GDF15_OE_cosine_shift', 'Blues', 'C', xlim, ylim, oe_vmax, False, f'{version}_OE')
        inclusion_rows.extend([{'version': version, 'population': 'Periodontitis ECM remodeling', 'input_cells': int(len(periodontitis)), 'plotted_inside_axes': int(len(ko_raw_visible)), 'cropped_outside_axes': int(len(periodontitis) - len(ko_raw_visible))}, {'version': version, 'population': 'Healthy ECM remodeling', 'input_cells': int(len(healthy)), 'plotted_inside_axes': int(len(oe_visible)), 'cropped_outside_axes': int(len(healthy) - len(oe_visible))}])
    expected_counts = {('\u539f\u56fe', 'Periodontitis ECM remodeling'): (542, 10), ('\u539f\u56fe', 'Healthy ECM remodeling'): (1884, 0), ('\u65b0\u56fe1', 'Periodontitis ECM remodeling'): (542, 10), ('\u65b0\u56fe1', 'Healthy ECM remodeling'): (1851, 33), ('\u65b0\u56fe2', 'Periodontitis ECM remodeling'): (542, 10), ('\u65b0\u56fe2', 'Healthy ECM remodeling'): (1852, 32)}
    for row in inclusion_rows:
        expected = expected_counts[row['version'], row['population']]
        actual = (row['plotted_inside_axes'], row['cropped_outside_axes'])
        if actual != expected:
            raise ValueError(f'Unexpected inclusion count for {row}: expected {expected}')
    pd.DataFrame(inclusion_rows).to_csv(TABLE_DIR / '\u5404\u7248\u672c\u5750\u6807\u8303\u56f4\u4e0e\u7ec6\u80de\u88c1\u526a\u8ba1\u6570.csv', index=False, encoding='utf-8-sig')
    periodontitis.assign(**{'\u539f\u56fe\u8303\u56f4\u5185': periodontitis['UMAP_1'].between(*original_xlim) & periodontitis['UMAP_2'].between(*original_ylim)}, **{'\u65b0\u56fe1\u8303\u56f4\u5185': periodontitis['UMAP_1'].between(0.5, original_xlim[1]) & periodontitis['UMAP_2'].between(*original_ylim)}, **{'\u65b0\u56fe2\u8303\u56f4\u5185': periodontitis['UMAP_1'].between(0.0, original_xlim[1]) & periodontitis['UMAP_2'].between(*original_ylim)}).to_csv(TABLE_DIR / 'KO\u7ec6\u80de\u53ca\u5404\u7248\u672c\u7eb3\u5165\u6807\u8bb0.csv.gz', index=False, encoding='utf-8-sig', compression='gzip')
    healthy.assign(**{'\u539f\u56fe\u8303\u56f4\u5185': healthy['UMAP_1'].between(*original_xlim) & healthy['UMAP_2'].between(*original_ylim)}, **{'\u65b0\u56fe1\u8303\u56f4\u5185': healthy['UMAP_1'].between(0.5, original_xlim[1]) & healthy['UMAP_2'].between(*original_ylim)}, **{'\u65b0\u56fe2\u8303\u56f4\u5185': healthy['UMAP_1'].between(0.0, original_xlim[1]) & healthy['UMAP_2'].between(*original_ylim)}).to_csv(TABLE_DIR / 'OE\u7ec6\u80de\u53ca\u5404\u7248\u672c\u7eb3\u5165\u6807\u8bb0.csv.gz', index=False, encoding='utf-8-sig', compression='gzip')
    source_hashes_after = {key: base.sha256(path) for key, path in SOURCE_PDFS.items()}
    if source_hashes_before != source_hashes_after:
        raise ValueError('A source PDF was modified')
    qa = {'status': 'PASS', 'output_PDF_count': len(outputs), 'short_filename_scheme': ['\u539f\u56fe_KO_\u539f\u59cb / \u539f\u56fe_KO_\u5e73\u6ed1 / \u539f\u56fe_OE', '\u65b0\u56fe1_KO_\u539f\u59cb / \u65b0\u56fe1_KO_\u5e73\u6ed1 / \u65b0\u56fe1_OE', '\u65b0\u56fe2_KO_\u539f\u59cb / \u65b0\u56fe2_KO_\u5e73\u6ed1 / \u65b0\u56fe2_OE'], 'axis_versions': {key: {'xlim': list(value[0]), 'ylim': list(value[1])} for key, value in axis_versions.items()}, 'header_title_removed_from_all_outputs': True, 'panel_letters_retained': ['B', 'C'], 'KO_raw_and_smoothed_both_included': True, 'cell_counts': inclusion_rows, 'source_PDFs_unchanged': source_hashes_before == source_hashes_after, 'source_PDF_sha256': source_hashes_after, 'outputs': outputs}
    (QA_DIR / 'UMAP1\u53cc\u9608\u503c_\u53bb\u8868\u5934_\u5ba1\u8ba1.json').write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding='utf-8')
    (ROOT / 'README_\u8bf7\u5148\u770b.md').write_text('# UMAP1 \u53cc\u9608\u503c\u3001\u53bb\u8868\u5934\u7248\u672c\n\n- \u56fe\u7247\u76ee\u5f55\u51719\u5f20\uff1a\u539f\u56fe\u8303\u56f4\u3001\u65b0\u56fe1\u3001\u65b0\u56fe2\u5404\u542bKO\u539f\u59cb\u3001KO\u5e73\u6ed1\u548cOE\u3002\n- \u6240\u6709\u56fe\u7247\u5747\u53bb\u6389\u9876\u90e8 GDF15 ... sensitivity \u6807\u9898\uff0c\u4fdd\u7559B/C\u9762\u677f\u7f16\u53f7\u548c\u8272\u6807\u3002\n- \u539f\u56fe\uff1a\u4fdd\u6301\u8f93\u5165\u56fe\u5750\u6807\u8303\u56f4\uff1b\u65b0\u56fe1\uff1aUMAP1\u6700\u5c0f\u503c0.5\uff1b\u65b0\u56fe2\uff1aUMAP1\u6700\u5c0f\u503c0\u3002\n- \u4e09\u7ec4UMAP1\u6700\u5927\u503c\u5747\u4e3a6.8336834803\uff0c\u7eb5\u8f74\u8303\u56f4\u5747\u4fdd\u6301\u8f93\u5165\u539f\u56fe\u3002\n- \u8303\u56f4\u5916\u7ec6\u80de\u5747\u5728\u7ed8\u56fe\u524d\u5254\u9664\uff1b\u8be6\u60c5\u89c1\u6570\u636e\u8868\u3002\n- \u8f93\u51fa\u6587\u4ef6\u540d\u5df2\u7f29\u77ed\uff0c\u65e2\u6709\u6e90PDF\u54c8\u5e0c\u672a\u6539\u53d8\uff0c\u672a\u8986\u76d6\u539f\u56fe\u3002\n', encoding='utf-8')
    print(json.dumps(qa, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
