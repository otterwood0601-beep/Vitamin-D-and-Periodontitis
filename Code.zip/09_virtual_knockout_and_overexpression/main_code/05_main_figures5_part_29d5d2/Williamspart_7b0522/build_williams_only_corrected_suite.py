from __future__ import annotations
import json
import math
import re
import textwrap
from pathlib import Path
import h5py
import matplotlib
import numpy as np
import pandas as pd
import umap
matplotlib.use('Agg')
from matplotlib import colors as mcolors
from matplotlib import pyplot as plt
from matplotlib.gridspec import GridSpec
from matplotlib.lines import Line2D
from matplotlib.patches import FancyArrowPatch, Patch
from scipy import stats
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
SOURCE_ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260904_Geneformer_GDF15_ERK_MAPK_ECM_\u8bba\u6587\u540c\u578b\u590d\u73b0_v1')
DATA_ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20')
OUT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260906_Geneformer_GDF15_Williams\u5355\u961f\u5217_\u5168\u56fe\u7ea0\u9519\u6c47\u603b_v1')
FIG = OUT / '\u56fe\u7247'
TABLE = OUT / '\u6570\u636e\u8868'
QA = OUT / 'QA'
EXT = SOURCE_ROOT / '08_\u6269\u5c55\u56fe\u8868_PLOS_Frontiers\u540c\u578b' / '\u6570\u636e\u8868'
V2 = SOURCE_ROOT / '09_\u8bba\u6587\u539f\u56fe\u4e25\u683c\u590d\u6838\u4e0eGDF15\u8fc7\u8868\u8fbe\u8865\u5145_v2' / '\u6570\u636e\u8868'
V3 = SOURCE_ROOT / '09_\u8bba\u6587\u539f\u56fe\u4e25\u683c\u590d\u6838\u4e0eGDF15\u8fc7\u8868\u8fbe\u8865\u5145_v3_\u5168\u91cf\u72b6\u6001\u7ec6\u80de' / '\u6570\u636e\u8868'
EXTRA = SOURCE_ROOT / '10_\u539f\u6587Figure5-6\u4e0eExtendedData9-10\u65b0\u589e\u5e72\u5b9e\u9a8c_v1' / '\u6570\u636e\u8868'
RAW_MODEL = SOURCE_ROOT / '11_\u56fe1_rawLogits\u4e0e\u6a21\u578b\u6548\u80fd\u4f18\u5316_\u652f\u7ebf_v3' / '\u6570\u636e\u8868' / '\u9010\u7ec6\u80de\u539f\u59cblogits_\u9a8c\u8bc1\u4e0e\u6d4b\u8bd5\u96c6.csv.gz'
EMBED = SOURCE_ROOT / '02_\u72b6\u6001\u5206\u7c7b\u5668' / 'Williams' / 'embedding_umap_coordinates.csv'
KO_SCREEN = SOURCE_ROOT / '03_\u5168\u57fa\u56e0\u865a\u62df\u6572\u9664' / 'Williams' / 'exact_delete_gene_summary.csv'
OE_SCREEN = EXTRA / '07_\u53cc\u5411\u6269\u5c55\u7b5b\u9009' / 'Williams' / 'expanded_OE_gene_summary.csv'
OE_SCREEN_EXACT = V2 / '\u5168\u57fa\u56e0\u8fc7\u8868\u8fbe\u7b5b\u9009' / 'Williams' / 'exact_overexpression_gene_summary.csv'
CELL_METADATA = SOURCE_ROOT / '01_\u8f93\u5165\u4e0eGeneformer\u5206\u8bcd' / 'Williams' / 'cell_metadata.csv'
H5AD = DATA_ROOT / '\u539f\u59cb\u6570\u636e' / '05_\u5355\u7ec6\u80deRNA' / '01_scRNA-seq' / 'CELLxGENE_Integrated_Periodontitis_Atlas' / 'processed' / 'Integrated_Human_Periodontitis_Atlas_105918cells.h5ad'
CLUSTER_MAP = DATA_ROOT / '\u539f\u59cb\u6570\u636e' / '05_\u5355\u7ec6\u80deRNA' / '\u6d3e\u751f\u8f93\u5165' / 'GDF15_Figure1' / 'cell_cluster_mapping.csv.gz'
FIVE_MAP = DATA_ROOT / '\u539f\u59cb\u6570\u636e' / '05_\u5355\u7ec6\u80deRNA' / '\u6d3e\u751f\u8f93\u5165' / 'GDF15_Figure1' / 'five_type_merge_mapping.csv'
KO_BLUE = '#397FC0'
KO_BLUE_DARK = '#1F5F9B'
OE_RED = '#D9544D'
OE_RED_DARK = '#A93434'
INK = '#222222'
GRID = '#DCE2E5'
GREY = '#B8C0C4'
LIGHT_GREY = '#EBEEF0'
WHITE = '#FFFFFF'
SEED = 42
MAPK_PRIORITY = {'MAPK1', 'MAPK3', 'DUSP1', 'DUSP2', 'DUSP4', 'DUSP5', 'DUSP6', 'FOS', 'FOSB', 'JUN', 'JUNB', 'JUND', 'EGR1', 'EGR2', 'ATF3', 'ELK1', 'ETS1', 'SPRY1', 'SPRY2'}
ECM_PRIORITY = {'COL1A1', 'COL1A2', 'COL3A1', 'COL5A1', 'COL5A2', 'COL6A1', 'COL6A2', 'COL6A3', 'COL12A1', 'COL14A1', 'FN1', 'FBLN1', 'FBLN2', 'EFEMP1', 'TIMP1', 'TIMP2', 'MMP2', 'MMP14', 'SPARC', 'DCN', 'LUM', 'BGN', 'VCAN', 'POSTN', 'THBS1', 'ITGA5', 'ITGB1', 'SERPINE1', 'SFRP1', 'SLIT3', 'AEBP1', 'ITGBL1', 'FSTL1'}
HOUSEKEEPING = {'ACTB', 'GAPDH', 'B2M', 'HPRT1', 'PPIA', 'RPL3', 'RPL4', 'RPL5', 'RPL7', 'RPL8', 'RPL9', 'RPL10', 'RPL11', 'RPL13', 'RPL18', 'RPS3', 'RPS4X', 'RPS5', 'RPS6', 'RPS8', 'RPS9', 'RPS11', 'RPS14', 'RPS18', 'RPS19', 'RPS27A', 'EEF1A1', 'TUBB', 'UBC'}
SCENARIOS = {'Periodontitis_GDF15_KO_to_Healthy': ('GDF15 KO in periodontitis fibroblasts', KO_BLUE, KO_BLUE_DARK), 'Healthy_GDF15_OE_to_Periodontitis': ('GDF15 OE in healthy fibroblasts', OE_RED, OE_RED_DARK)}

def ensure_dirs() -> None:
    for path in (FIG, TABLE, QA):
        path.mkdir(parents=True, exist_ok=True)

def set_style() -> None:
    plt.rcParams.update({'font.family': 'Arial', 'font.size': 8, 'axes.titlesize': 9, 'axes.labelsize': 8, 'xtick.labelsize': 7, 'ytick.labelsize': 7, 'axes.linewidth': 0.7, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none', 'figure.facecolor': 'white', 'axes.facecolor': 'white', 'savefig.facecolor': 'white'})

def clean_axis(ax: plt.Axes, grid_axis: str | None=None) -> None:
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    if grid_axis:
        ax.grid(axis=grid_axis, color=GRID, linewidth=0.55, linestyle=(0, (3, 3)), zorder=0)
    else:
        ax.grid(False)

def save_figure(fig: plt.Figure, stem: str) -> None:
    fig.savefig(FIG / f'{stem}.pdf', dpi=300, bbox_inches='tight', facecolor='white')
    fig.savefig(FIG / f'{stem}.png', dpi=360, bbox_inches='tight', facecolor='white')
    fig.savefig(FIG / f'{stem}.svg', bbox_inches='tight', facecolor='white')
    plt.close(fig)

def bh_fdr(values: pd.Series | np.ndarray) -> np.ndarray:
    p = np.asarray(values, dtype=float)
    result = np.full(len(p), np.nan)
    valid = np.isfinite(p)
    if not valid.any():
        return result
    pv = p[valid]
    order = np.argsort(pv)
    ranked = pv[order]
    q = ranked * len(ranked) / np.arange(1, len(ranked) + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    restored = np.empty_like(q)
    restored[order] = np.clip(q, 0, 1)
    result[valid] = restored
    return result

def panel_letter(ax: plt.Axes, letter: str, x: float=-0.12, y: float=1.06) -> None:
    ax.text(x, y, letter, transform=ax.transAxes, fontsize=14, va='top', ha='left')

def label_points(ax: plt.Axes, frame: pd.DataFrame, genes: list[str], x: str, y: str, color: str=INK, offset_map: dict[str, tuple[float, float]] | None=None, position_map: dict[str, tuple[float, float, str]] | None=None) -> None:
    offsets = [(4, 4), (4, -9), (-4, 4), (-4, -9), (7, 1), (-7, 1)]
    for i, gene in enumerate(genes):
        row = frame.loc[frame['Gene_name'].eq(gene)]
        if row.empty:
            continue
        r = row.iloc[0]
        absolute_position = (position_map or {}).get(gene)
        dx, dy = (offset_map or {}).get(gene, offsets[i % len(offsets)])
        if absolute_position is None:
            xytext = (dx, dy)
            textcoords = 'offset points'
            horizontal_alignment = 'left' if dx >= 0 else 'right'
            vertical_alignment = 'bottom' if dy >= 0 else 'top'
        else:
            text_x, text_y, horizontal_alignment = absolute_position
            xytext = (text_x, text_y)
            textcoords = 'data'
            vertical_alignment = 'center'
        ax.annotate(gene, (float(r[x]), float(r[y])), xytext=xytext, textcoords=textcoords, fontsize=5.8, fontstyle='italic', color=color, ha=horizontal_alignment, va=vertical_alignment, arrowprops={'arrowstyle': '-', 'color': '#7F888C', 'lw': 0.3, 'shrinkA': 2, 'shrinkB': 4})

def load_classifier_test() -> tuple[pd.DataFrame, np.ndarray, float]:
    data = pd.read_csv(RAW_MODEL)
    data = data.loc[(data['cohort'] == 'Williams') & (data['split'] == 'test')].copy()
    data['source_order'] = np.arange(len(data))
    data = data.sort_values(['observed_label', 'source_order'], kind='stable').reset_index(drop=True)
    threshold = 0.394
    predicted = (data['probability_from_raw_logits'].to_numpy(float) >= threshold).astype(int)
    return (data, predicted, threshold)

def plot_figure1() -> dict:
    data, predicted, threshold = load_classifier_test()
    labels = data['observed_label'].to_numpy(int)
    scores = data[['healthy_logit_raw', 'periodontitis_logit_raw']].to_numpy(float)
    vmax = float(np.quantile(np.abs(scores), 0.995))
    vmax = max(vmax, 1e-06)
    state_colors = ['#392448', '#DCE6C3']
    state_cmap = mcolors.ListedColormap(state_colors)
    score_cmap = mcolors.LinearSegmentedColormap.from_list('raw_logits', ['#2E6FB0', '#FFFFFF', '#B64A4A'])
    fig = plt.figure(figsize=(4.8, 7.2))
    outer = GridSpec(2, 1, figure=fig, height_ratios=[2.45, 1.55], hspace=0.34)
    top = outer[0].subgridspec(3, 4, width_ratios=[0.07, 0.035, 0.035, 1.0], height_ratios=[0.055, 1, 0.02], wspace=0.025, hspace=0.01)
    ax_cbar_shell = fig.add_subplot(top[1, 0])
    ax_cbar_shell.axis('off')
    ax_cbar = ax_cbar_shell.inset_axes([0.2, 0.2, 0.5, 0.6])
    ax_true = fig.add_subplot(top[1, 2])
    ax_pred = fig.add_subplot(top[0, 3])
    ax_heat = fig.add_subplot(top[1, 3])
    heat = ax_heat.pcolormesh(np.arange(3), np.arange(len(scores) + 1), scores, cmap=score_cmap, vmin=-vmax, vmax=vmax, shading='flat', rasterized=True)
    ax_heat.set(xlim=(0, 2), ylim=(len(scores), 0))
    ax_heat.set_xticks([])
    ax_heat.set_yticks([])
    for spine in ax_heat.spines.values():
        spine.set_visible(False)
    ax_true.pcolormesh([0, 1], np.arange(len(labels) + 1), labels[:, None], cmap=state_cmap, vmin=0, vmax=1, shading='flat', rasterized=True)
    ax_true.set(xlim=(0, 1), ylim=(len(labels), 0))
    ax_true.set_xticks([])
    ax_true.set_yticks([])
    for spine in ax_true.spines.values():
        spine.set_visible(False)
    ax_true.text(-1.6, 0.5, 'True', transform=ax_true.transAxes, rotation=90, ha='center', va='center')
    ax_pred.pcolormesh([0, 1, 2], [0, 1], np.asarray([[0, 1]]), cmap=state_cmap, vmin=0, vmax=1, shading='flat')
    ax_pred.set(xlim=(0, 2), ylim=(0, 1))
    ax_pred.set_xticks([])
    ax_pred.set_yticks([])
    for spine in ax_pred.spines.values():
        spine.set_visible(False)
    ax_pred.text(1.03, 0.5, 'Predicted', transform=ax_pred.transAxes, ha='left', va='center')
    ax_pred.legend([Patch(facecolor=state_colors[0]), Patch(facecolor=state_colors[1])], ['Healthy', 'Periodontitis'], title='Cell states', ncol=2, frameon=True, edgecolor='#D9D9D9', loc='lower center', bbox_to_anchor=(0.5, 1.45), handlelength=1.1, columnspacing=0.8, borderpad=0.25)
    cbar = fig.colorbar(heat, cax=ax_cbar)
    cbar.set_ticks([-vmax, 0, vmax])
    cbar.set_ticklabels([f'{-vmax:.2f}', '0', f'{vmax:.2f}'])
    cbar.ax.yaxis.set_ticks_position('left')
    cbar.ax.tick_params(labelsize=6, length=2, pad=1)
    cbar.outline.set_linewidth(0.45)
    panel_letter(ax_heat, 'D', -0.4, 1.12)
    bottom = outer[1].subgridspec(1, 3, width_ratios=[0.34, 1.0, 0.24])
    ax = fig.add_subplot(bottom[0, 1])
    cm = confusion_matrix(labels, predicted, labels=[0, 1]).astype(float)
    cmn = cm / np.maximum(cm.sum(axis=1, keepdims=True), 1)
    image = ax.pcolormesh([0, 1, 2], [0, 1, 2], cmn, cmap='Blues', vmin=0, vmax=1, edgecolors='white', linewidth=0.5)
    for row in range(2):
        for col in range(2):
            ax.text(col + 0.5, row + 0.5, f'{cmn[row, col]:.2f}', ha='center', va='center', fontsize=10, color='white' if cmn[row, col] > 0.55 else INK, fontweight='bold' if row == col else 'normal')
    true_n = cm.sum(1).astype(int)
    pred_n = cm.sum(0).astype(int)
    ax.set(xlim=(0, 2), ylim=(2, 0), aspect='equal')
    ax.set_xticks([0.5, 1.5], [f'Healthy\nn={pred_n[0]}', f'Periodontitis\nn={pred_n[1]}'])
    ax.set_yticks([0.5, 1.5], [f'Healthy\nn={true_n[0]}', f'Periodontitis\nn={true_n[1]}'])
    ax.set_xlabel('Predicted label')
    ax.set_ylabel('True label')
    ax.tick_params(length=0)
    fig.colorbar(image, ax=ax, fraction=0.045, pad=0.04).ax.tick_params(labelsize=6)
    acc = accuracy_score(labels, predicted)
    f1 = f1_score(labels, predicted, average='macro')
    ax.text(0.5, -0.32, f'Accuracy: {acc:.4f}\nF1 score: {f1:.4f}', transform=ax.transAxes, ha='center', va='top', fontsize=8.5)
    panel_letter(ax, 'E', -0.48, 1.17)
    fig.subplots_adjust(left=0.12, right=0.94, top=0.92, bottom=0.08)
    stem = '\u56fe1_Geneformer\u7ec6\u80de\u72b6\u6001\u9884\u6d4b\u70ed\u56fe\u4e0e\u6df7\u6dc6\u77e9\u9635_Williams\u5355\u961f\u5217\u7ea0\u9519\u7248'
    save_figure(fig, stem)
    data.assign(predicted_label_corrected=predicted).to_csv(TABLE / '\u56fe1_Williams\u6d4b\u8bd5\u96c6\u539f\u59cblogits\u4e0e\u9884\u6d4b.csv.gz', index=False, compression='gzip', encoding='utf-8-sig')
    return {'figure': stem, 'n': len(data), 'threshold': threshold, 'accuracy': acc, 'macro_f1': f1}

def formal_umap_coordinates() -> pd.DataFrame:
    cache = TABLE / '\u6b63\u5f0fUMAP_Williams_\u4e94\u7c7b\u6210\u7ea4\u7ef4\u7ec6\u80de\u5750\u6807.csv.gz'
    if cache.exists():
        return pd.read_csv(cache)
    clusters = pd.read_csv(CLUSTER_MAP)
    clusters = clusters.loc[clusters['Study'].eq('Williams')].copy()
    mapping = pd.read_csv(FIVE_MAP)
    meta = pd.read_csv(CELL_METADATA)
    data = clusters.merge(mapping, left_on='fb_id', right_on='original_fb_id', how='left', validate='many_to_one')
    data = data.merge(meta[['cell_id', 'h5ad_row_python', 'dataset_index', 'disease']], left_on='cell_barcode', right_on='cell_id', how='inner', suffixes=('', '_metadata'), validate='one_to_one')
    rows = data['h5ad_row_python'].to_numpy(int)
    with h5py.File(H5AD, 'r') as handle:
        pca = np.asarray(handle['obsm']['X_pca'][rows, :30], dtype=np.float32)
    reducer = umap.UMAP(n_neighbors=35, min_dist=0.28, metric='euclidean', random_state=SEED, n_jobs=1)
    coords = reducer.fit_transform(pca)
    data['UMAP_1_raw'] = coords[:, 0]
    data['UMAP_2_raw'] = coords[:, 1]
    short = {'Vascular-associated fibroblasts': 'Vascular', 'Immune-associated fibroblasts': 'Immune', 'ECM remodeling-associated fibroblasts': 'ECM remodeling', 'Pre-extracellular matrix-associated fibroblasts': 'Pre-extracellular matrix', 'Matrix homeostasis-associated fibroblasts': 'Matrix homeostasis'}
    data['Fibroblast_type'] = data['final_fibroblast_type'].map(short)
    valid = data.dropna(subset=['Fibroblast_type'])
    centroids = valid.groupby('Fibroblast_type')[['UMAP_1_raw', 'UMAP_2_raw']].mean()
    target = pd.DataFrame({'Vascular': [0.0, 2.8], 'Immune': [-1.4, 0.3], 'ECM remodeling': [2.1, -0.1], 'Pre-extracellular matrix': [-1.7, -2.4], 'Matrix homeostasis': [0.1, -2.6]}, index=['x', 'y']).T
    common = [x for x in target.index if x in centroids.index]
    a = centroids.loc[common].to_numpy(float)
    b = target.loc[common].to_numpy(float)
    ac = a - a.mean(0)
    bc = b - b.mean(0)
    u, singular, vt = np.linalg.svd(ac.T @ bc)
    rotation = u @ vt
    scale = float(singular.sum() / np.maximum(np.square(ac).sum(), 1e-12))
    aligned = (coords - a.mean(0)) @ rotation * scale + b.mean(0)
    data['UMAP_1'] = aligned[:, 0]
    data['UMAP_2'] = aligned[:, 1]
    keep = ['cell_id', 'dataset_index', 'disease_metadata', 'fb_id', 'Fibroblast_type', 'UMAP_1', 'UMAP_2']
    data[keep].rename(columns={'disease_metadata': 'disease'}).to_csv(cache, index=False, compression='gzip', encoding='utf-8-sig')
    return pd.read_csv(cache)

def plot_figure2() -> dict:
    coords = formal_umap_coordinates()
    ko = pd.read_csv(V3 / '\u7259\u5468\u708e\u5168\u90e83277\u7ec6\u80de_GDF15\u6572\u9664\u654f\u611f\u6027.csv.gz', usecols=['cell_id', 'GDF15_KO_cosine_shift'])
    oe = pd.read_csv(V3 / '\u5065\u5eb7\u5168\u90e89980\u7ec6\u80de_GDF15\u8fc7\u8868\u8fbe\u654f\u611f\u6027.csv.gz', usecols=['cell_id', 'GDF15_OE_cosine_shift'])
    data = coords.merge(ko, on='cell_id', how='left').merge(oe, on='cell_id', how='left')
    palette = {'Vascular': '#E9A34D', 'Immune': '#398AF6', 'ECM remodeling': '#2AAC4A', 'Pre-extracellular matrix': '#A892FF', 'Matrix homeostasis': '#FF79B8'}
    order = list(palette)
    fig, axes = plt.subplots(1, 3, figsize=(13.6, 4.35), sharex=True, sharey=True)
    ax = axes[0]
    for label in order:
        frame = data.loc[data['Fibroblast_type'].eq(label)]
        ax.scatter(frame['UMAP_1'], frame['UMAP_2'], s=2.0, color=palette[label], edgecolors='none', rasterized=True, label=label)
    ax.legend(title='Fibroblast type', frameon=False, loc='lower right', fontsize=6.2, title_fontsize=7, markerscale=2.3, handletextpad=0.3, labelspacing=0.25)
    ax.set_title('Williams fibroblast states', fontweight='bold')
    panel_letter(ax, 'A', -0.12, 1.08)
    definitions = [(axes[1], 'periodontitis', 'GDF15_KO_cosine_shift', 'GDF15 knockout sensitivity', 'Blues', 'B'), (axes[2], 'normal', 'GDF15_OE_cosine_shift', 'GDF15 overexpression sensitivity', 'Reds', 'C')]
    counts = {}
    for ax, disease, column, title, cmap, letter in definitions:
        frame = data.loc[data['disease'].eq(disease)].copy()
        counts[column] = len(frame)
        ax.scatter(frame['UMAP_1'], frame['UMAP_2'], s=1.8, color='#E7E7E7', edgecolors='none', rasterized=True)
        eligible = frame[column].notna() & np.isfinite(frame[column])
        shown = frame.loc[eligible].sort_values(column)
        values = shown[column].to_numpy(float) * 1000
        vmax = float(np.quantile(values[values > 0], 0.99)) if np.any(values > 0) else 1.0
        sc = ax.scatter(shown['UMAP_1'], shown['UMAP_2'], s=3.2, c=values, cmap=cmap, vmin=0, vmax=max(vmax, 1e-06), edgecolors='none', rasterized=True)
        cbar = fig.colorbar(sc, ax=ax, fraction=0.043, pad=0.025)
        cbar.ax.set_title('Cosine shift\n(x10^3)', fontsize=6.3, pad=4)
        cbar.ax.tick_params(labelsize=6)
        cbar.outline.set_linewidth(0.45)
        ax.set_title(title, fontweight='bold')
        panel_letter(ax, letter, -0.12, 1.08)
    for ax in axes:
        ax.set_xlabel('UMAP 1')
        ax.set_ylabel('UMAP 2')
        ax.tick_params(length=2.5)
        for spine in ax.spines.values():
            spine.set_color(INK)
            spine.set_linewidth(0.7)
    fig.subplots_adjust(left=0.055, right=0.975, bottom=0.13, top=0.88, wspace=0.26)
    stem = '\u56fe2_GDF15\u6572\u9664\u4e0e\u8fc7\u8868\u8fbe\u654f\u611f\u6027UMAP_Williams\u5168\u91cf\u7ec6\u80de\u7ea0\u9519\u7248'
    save_figure(fig, stem)
    data.to_csv(TABLE / '\u56fe2_Williams\u6b63\u5f0fUMAP\u4e0eGDF15\u6270\u52a8\u654f\u611f\u6027.csv.gz', index=False, compression='gzip', encoding='utf-8-sig')
    return {'figure': stem, 'all_cells': len(data), 'periodontitis_cells': counts['GDF15_KO_cosine_shift'], 'healthy_cells': counts['GDF15_OE_cosine_shift']}

def circle_selection(summary: pd.DataFrame, scenario: str, total: int=28) -> pd.DataFrame:
    frame = summary.loc[(summary['scenario'] == scenario) & (summary['cohort'] == 'Williams')].copy()
    frame = frame.sort_values('Mean_token_cosine_shift', ascending=False)
    axis = frame.loc[frame['Priority_class'].isin(['MAPK-response', 'ECM-remodeling'])].head(20)
    other = frame.loc[frame['Priority_class'].eq('Other')].head(max(total - len(axis), 0))
    return pd.concat([axis, other], ignore_index=True).drop_duplicates('Gene').head(total)

def draw_single_track_circle(ax: plt.Axes, summary: pd.DataFrame, scenario: str, cmap: str, outer: str) -> None:
    selected = circle_selection(summary, scenario)
    selected = selected.sort_values('Mean_token_cosine_shift', ascending=False).reset_index(drop=True)
    n = len(selected)
    theta = np.linspace(math.radians(8), math.radians(352), n, endpoint=False)
    width = math.radians(344 / max(n, 1)) * 0.96
    values = selected['Mean_token_cosine_shift'].to_numpy(float) * 1000
    vmax = max(float(np.quantile(values, 0.98)), 1e-06)
    norm = mcolors.Normalize(0, vmax)
    cm = plt.get_cmap(cmap)
    ax.bar(theta, np.repeat(0.85, n), bottom=1.05, width=width, color=[cm(norm(v)) for v in values], edgecolor='white', linewidth=0.25)
    strong = selected['N_strong_hits'].fillna(0).to_numpy(float)
    strong_scaled = 0.55 * strong / max(float(strong.max()), 1.0)
    ax.bar(theta, strong_scaled, bottom=2.0, width=width, color=outer, edgecolor='white', linewidth=0.2)
    for angle, gene in zip(theta, selected['Gene_name'].astype(str)):
        deg = math.degrees(angle) % 360
        rot = deg - 90
        ha = 'left'
        if 90 < deg < 270:
            rot += 180
            ha = 'right'
        ax.text(angle, 2.7, gene, rotation=rot, rotation_mode='anchor', ha=ha, va='center', fontsize=4.9, fontstyle='italic')
    ax.set_ylim(0, 3.05)
    ax.set_axis_off()
    cax = ax.inset_axes([0.34, 0.02, 0.34, 0.025])
    cbar = plt.colorbar(plt.cm.ScalarMappable(norm=norm, cmap=cm), cax=cax, orientation='horizontal')
    cbar.set_ticks([0, vmax])
    cbar.set_ticklabels(['Low', 'High'])
    cbar.ax.tick_params(labelsize=5, length=0)
    cbar.outline.set_linewidth(0.35)

def plot_figure3() -> dict:
    cell = pd.read_csv(EXT / 'GDF15_directional_perturbation_cell_level.csv')
    cell = cell.loc[cell['cohort'].eq('Williams')].copy()
    summary = pd.read_csv(EXT / 'GDF15_downstream_gene_evidence_summary.csv')
    summary = summary.loc[summary['cohort'].eq('Williams')].copy()
    fig = plt.figure(figsize=(11.8, 5.0))
    gs = GridSpec(1, 4, figure=fig, width_ratios=[0.55, 1.72, 0.55, 1.72], wspace=0.06)
    setup = [('Periodontitis_GDF15_KO_to_Healthy', 'GDF15 KO', KO_BLUE, 'Blues', KO_BLUE_DARK, 'D'), ('Healthy_GDF15_OE_to_Periodontitis', 'GDF15 OE', OE_RED, 'Reds', OE_RED_DARK, 'E')]
    for i, (scenario, title, color, cmap, outer, letter) in enumerate(setup):
        ax_box = fig.add_subplot(gs[0, i * 2])
        values = cell.loc[cell['scenario'].eq(scenario), 'Cosine_shift'].to_numpy(float) * 1000
        rng = np.random.default_rng(SEED + i)
        ax_box.scatter(rng.normal(1, 0.045, len(values)), values, s=8, color=color, alpha=0.55, edgecolors='none')
        box = ax_box.boxplot([values], positions=[1], widths=0.42, patch_artist=True, showfliers=False, medianprops={'color': INK, 'lw': 0.9}, boxprops={'edgecolor': color, 'lw': 0.8}, whiskerprops={'color': color, 'lw': 0.7}, capprops={'color': color, 'lw': 0.7})
        box['boxes'][0].set_facecolor('white')
        ax_box.set_xticks([1], [f'Williams\n(n={len(values)})'])
        ax_box.set_ylabel('Cosine shift (x10^3)')
        ax_box.set_title(title, fontsize=8, pad=3)
        clean_axis(ax_box)
        panel_letter(ax_box, letter, -0.32, 1.14)
        ax_circle = fig.add_subplot(gs[0, i * 2 + 1], projection='polar')
        draw_single_track_circle(ax_circle, summary, scenario, cmap, outer)
        ax_circle.legend([Patch(facecolor=plt.get_cmap(cmap)(0.65)), Patch(facecolor=outer)], ['Williams gene shift', 'N strong hits'], frameon=False, loc='lower center', bbox_to_anchor=(0.5, -0.03), fontsize=6)
    fig.subplots_adjust(left=0.06, right=0.985, top=0.94, bottom=0.06)
    stem = '\u56fe3_GDF15\u6572\u9664\u4e0e\u8fc7\u8868\u8fbe\u5706\u5f62\u57fa\u56e0\u8bc1\u636e\u56fe_Williams\u5355\u961f\u5217\u7ea0\u9519\u7248'
    save_figure(fig, stem)
    cell.to_csv(TABLE / '\u56fe3_Williams_GDF15\u5b9a\u5411\u6270\u52a8\u9010\u7ec6\u80de.csv', index=False, encoding='utf-8-sig')
    summary.to_csv(TABLE / '\u56fe3_Williams_GDF15\u4e0b\u6e38\u57fa\u56e0\u8bc1\u636e\u6c47\u603b.csv', index=False, encoding='utf-8-sig')
    return {'figure': stem, 'cell_rows': len(cell), 'gene_rows': len(summary)}

def direct_summary(scenario: str) -> pd.Series:
    summary = pd.read_csv(EXT / 'GDF15_directional_perturbation_cohort_summary.csv')
    return summary.loc[(summary['Scope'] == 'Williams') & (summary['Scenario'] == scenario)].iloc[0]

def screen_frame(mode: str, exact_oe: bool=True) -> pd.DataFrame:
    if mode == 'KO':
        frame = pd.read_csv(KO_SCREEN)
        frame['N_cells'] = frame['N_Detections']
        scenario = 'Periodontitis_GDF15_KO_to_Healthy'
    else:
        path = OE_SCREEN_EXACT if exact_oe else OE_SCREEN
        frame = pd.read_csv(path)
        n_col = 'N_Perturbed_cells' if 'N_Perturbed_cells' in frame.columns else 'N_cells'
        frame['N_cells'] = frame[n_col]
        scenario = 'Healthy_GDF15_OE_to_Periodontitis'
    frame = frame.loc[~frame['Gene_name'].eq('GDF15')].copy()
    direct = direct_summary(scenario)
    row = {'Gene': -1, 'Gene_name': 'GDF15', 'Ensembl_ID': 'ENSG00000130513', 'Priority_class': 'GDF15', 'N_cells': int(direct['N_cells']), 'Shift_to_goal_end': float(direct['Shift_to_target']), 'Shift_away_start_end': float(direct['Shift_away_source']), 'Desirability_score': float(direct['Shift_to_target'] - direct['Shift_away_source']), 'Goal_end_vs_random_pval': np.nan}
    return pd.concat([frame, pd.DataFrame([row])], ignore_index=True, sort=False)

def choose_labels(frame: pd.DataFrame, n: int=12) -> list[str]:
    temp = frame.copy()
    sx = max(float(temp['Shift_to_goal_end'].std()), 1e-09)
    sy = max(float(temp['Shift_away_start_end'].std()), 1e-09)
    temp['distance'] = np.hypot(temp['Shift_to_goal_end'] / sx, temp['Shift_away_start_end'] / sy)
    labels = ['GDF15']
    narrative = temp.loc[temp['Gene_name'].isin(MAPK_PRIORITY | ECM_PRIORITY)].nlargest(7, 'distance')
    labels.extend([g for g in narrative['Gene_name'].astype(str) if g not in labels])
    for gene in temp.nlargest(n * 2, 'distance')['Gene_name'].astype(str):
        if gene not in labels:
            labels.append(gene)
        if len(labels) >= n:
            break
    return labels[:n]

def bubble_plot(frame: pd.DataFrame, mode: str, title: str, stem: str) -> dict:
    color = KO_BLUE if mode == 'KO' else OE_RED
    x = frame['Shift_to_goal_end'].to_numpy(float)
    y = frame['Shift_away_start_end'].to_numpy(float)
    n = frame['N_cells'].fillna(0).to_numpy(float)
    sizes = 12 + 92 * np.sqrt(n / max(float(n.max()), 1.0))
    fig, ax = plt.subplots(figsize=(5.35, 5.0))
    ax.scatter(x, y, s=sizes, color=color, alpha=0.78, edgecolor='white', linewidth=0.35)
    ax.axvline(0, color='#8A8A8A', lw=0.7, linestyle=(0, (2, 2)))
    ax.axhline(0, color='#8A8A8A', lw=0.7, linestyle=(0, (2, 2)))
    limits = [min(x.min(), y.min()), max(x.max(), y.max())]
    ax.plot(limits, limits, color='#777777', lw=0.65, linestyle=(0, (5, 3)))
    ko_label_offsets = {'GDF15': (-44, 22), 'THBS1': (20, -34), 'MAPK1': (44, 30), 'EFEMP1': (46, 13), 'DUSP6': (46, -6), 'SLIT3': (-34, 40), 'COL1A2': (-48, -12), 'MAPK3': (45, -25), 'CDC16': (-10, 10), 'SNX11': (8, -12), 'ZNF142': (12, 10), 'FOXC2': (-12, 10), 'PTBP2': (10, 10)}
    oe_label_offsets = {'GDF15': (10, 10), 'MAPK1': (-34, -28), 'MAPK3': (35, -30), 'DUSP6': (0, -44)}
    ko_label_positions = {'DUSP1': (-0.005, 0.0023, 'right'), 'FOS': (-0.005, 0.0017, 'right'), 'FOSB': (-0.005, 0.0011, 'right'), 'EGR1': (-0.005, 0.0005, 'right'), 'NR4A1': (-0.005, -0.0001, 'right'), 'PIK3R1': (-0.005, -0.0007, 'right'), 'ATF3': (-0.005, -0.0013, 'right'), 'JUN': (-0.005, -0.0019, 'right'), 'MAPK1': (0.0046, 0.0023, 'left'), 'DUSP6': (0.0046, 0.0015, 'left'), 'MAPK3': (0.0046, 0.0007, 'left'), 'DUSP5': (0.0046, -0.0001, 'left'), 'GDF15': (0.0046, -0.0009, 'left'), 'TIMP2': (0.0046, -0.0017, 'left')}
    oe_label_positions = {'DUSP1': (-0.00465, 0.00042, 'right'), 'TIMP2': (-0.00465, 0.0002, 'right'), 'NR4A1': (-0.00465, -2e-05, 'right'), 'MAPK3': (-0.00465, -0.00024, 'right'), 'PIK3R1': (-0.00465, -0.00046, 'right'), 'DUSP5': (-0.00465, -0.00068, 'right'), 'ATF3': (-0.00465, -0.0009, 'right'), 'MAPK1': (-0.00465, -0.00112, 'right'), 'DUSP6': (-0.00465, -0.00134, 'right'), 'GDF15': (0.00128, 0.00116, 'left'), 'FOSB': (0.00128, 0.00082, 'left'), 'EGR1': (0.00128, 0.00048, 'left'), 'JUN': (0.00128, 0.00014, 'left'), 'FOS': (0.00128, -0.0002, 'left')}
    requested_labels = ('GDF15', 'MAPK1', 'MAPK3', 'DUSP6', 'DUSP5', 'DUSP1', 'FOS', 'EGR1', 'ATF3', 'JUN', 'FOSB', 'NR4A1', 'TIMP2', 'PIK3R1', 'SOD2')
    labels = [gene for gene in requested_labels if frame['Gene_name'].eq(gene).any()]
    label_points(ax, frame, labels, 'Shift_to_goal_end', 'Shift_away_start_end', offset_map=ko_label_offsets if mode == 'KO' else oe_label_offsets, position_map=ko_label_positions if mode == 'KO' else oe_label_positions)
    ax.set_xlabel('Shift to goal end (Healthy)' if mode == 'KO' else 'Shift to goal end (Periodontitis)')
    ax.set_ylabel('Shift away start (Periodontitis)' if mode == 'KO' else 'Shift away start (Healthy)')
    legend_values = np.unique(np.quantile(n[n > 0], [0.25, 0.5, 0.75, 1.0]).astype(int)) if np.any(n > 0) else np.array([1])
    handles = [Line2D([0], [0], marker='o', linestyle='', color='none', markerfacecolor=color, markersize=math.sqrt(12 + 92 * math.sqrt(v / max(float(n.max()), 1))) / 1.25, label=str(int(v))) for v in legend_values]
    ax.legend(handles=handles, title='Number of cells', frameon=False, loc='upper left', fontsize=6, title_fontsize=6.5)
    clean_axis(ax)
    fig.subplots_adjust(left=0.17, right=0.97, bottom=0.14, top=0.97)
    save_figure(fig, stem)
    frame.to_csv(TABLE / f'{stem}_\u4f5c\u56fe\u6570\u636e.csv', index=False, encoding='utf-8-sig')
    return {'figure': stem, 'genes': len(frame)}

def plot_figures4_5() -> list[dict]:
    ko = screen_frame('KO')
    oe = screen_frame('OE')
    return [bubble_plot(ko, 'KO', 'Candidate therapeutic targets after GDF15 knockout', '\u56fe4_GDF15\u865a\u62df\u6572\u9664\u5019\u9009\u6cbb\u7597\u9776\u70b9\u6c14\u6ce1\u56fe_Williams\u5355\u961f\u5217\u7ea0\u9519\u7248'), bubble_plot(oe, 'OE', 'GDF15 overexpression candidates shifting Healthy toward Periodontitis', '\u56fe5_GDF15\u8fc7\u8868\u8fbe\u5065\u5eb7\u5411\u7259\u5468\u708e\u5019\u9009\u57fa\u56e0\u6c14\u6ce1\u56fe_Williams\u5355\u961f\u5217\u7ea0\u9519\u7248')]

def downstream_gene_table() -> pd.DataFrame:
    raw = pd.read_csv(EXT / 'GDF15_downstream_gene_evidence_cell_level.csv.gz')
    raw = raw.loc[raw['cohort'].eq('Williams')].copy()

    def classify(gene: str) -> str | None:
        if gene in MAPK_PRIORITY:
            return 'MAPK-response'
        if gene in ECM_PRIORITY:
            return 'ECM-remodeling'
        if gene in HOUSEKEEPING:
            return 'Housekeeping'
        return None
    raw['Target_group'] = raw['Gene_name'].astype(str).map(classify)
    raw = raw.dropna(subset=['Target_group'])
    gene = raw.groupby(['scenario', 'Gene', 'Gene_name', 'Target_group'], as_index=False).agg(Mean_token_cosine_shift=('Token_cosine_shift', 'mean'), N_cells=('dataset_index', 'nunique'))
    return gene

def plot_figure6() -> dict:
    gene = downstream_gene_table()
    groups = ['MAPK-response', 'ECM-remodeling', 'Housekeeping']
    fig, axes = plt.subplots(1, 2, figsize=(8.9, 3.7), sharey=True)
    stats_rows = []
    for ax, (scenario, (title, color, dark)), letter in zip(axes, SCENARIOS.items(), ['a', 'b']):
        frame = gene.loc[gene['scenario'].eq(scenario)]
        arrays = [frame.loc[frame['Target_group'].eq(group), 'Mean_token_cosine_shift'].to_numpy(float) for group in groups]
        box = ax.boxplot(arrays, positions=np.arange(3), widths=0.56, patch_artist=True, showfliers=False, medianprops={'color': INK, 'lw': 0.9}, whiskerprops={'color': dark, 'lw': 0.7}, capprops={'color': dark, 'lw': 0.7}, boxprops={'edgecolor': dark, 'lw': 0.7})
        for i, patch in enumerate(box['boxes']):
            patch.set_facecolor(color if i < 2 else LIGHT_GREY)
            patch.set_alpha(0.82)
        rng = np.random.default_rng(SEED)
        for x, values in enumerate(arrays):
            ax.scatter(rng.normal(x, 0.045, len(values)), values, s=10, facecolor='white', edgecolor=dark if x < 2 else GREY, linewidth=0.45, zorder=3)
            if x < 2 and len(values) and len(arrays[2]):
                p = stats.mannwhitneyu(values, arrays[2], alternative='greater').pvalue
                stats_rows.append({'scenario': scenario, 'Target_group': groups[x], 'N_genes': len(values), 'Raw_P_vs_housekeeping': p})
        ax.set_xticks(np.arange(3), [f'{g}\n(n={len(v)})' for g, v in zip(groups, arrays)], rotation=18, ha='right')
        ax.set_title(title, loc='left', fontweight='bold')
        panel_letter(ax, letter, -0.13, 1.08)
        clean_axis(ax, 'y')
    axes[0].set_ylabel('Mean target-gene embedding cosine shift')
    fig.tight_layout(w_pad=1.5)
    stem = '\u56fe6_GDF15\u4e0b\u6e38\u7f51\u7edc\u9776\u6807\u53d7\u6270\u52a8\u5f71\u54cd_Williams\u5355\u961f\u5217\u7ea0\u9519\u7248'
    save_figure(fig, stem)
    gene.to_csv(TABLE / '\u56fe6_Williams\u4e0b\u6e38\u5206\u7ec4\u57fa\u56e0\u7ea7.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(stats_rows).to_csv(TABLE / '\u56fe6_Williams\u4e0b\u6e38\u5206\u7ec4\u7edf\u8ba1.csv', index=False, encoding='utf-8-sig')
    return {'figure': stem, 'genes': gene['Gene_name'].nunique()}

def plot_figure7() -> dict:
    data = pd.read_csv(EXTRA / '02_GDF15_MAPK\u7ec4\u5408\u6fc0\u6d3b' / 'GDF15_MAPK_combination_activation_cell_level.csv.gz')
    data = data.loc[data['cohort'].eq('Williams')].copy()
    order = ['GDF15', 'MAPK1', 'MAPK3', 'GDF15+MAPK1', 'GDF15+MAPK3', 'MAPK1+MAPK3', 'GDF15+MAPK1+MAPK3']
    pivot = data.pivot(index='dataset_index', columns='condition', values='Desirability_score')
    combos = {'GDF15+MAPK1': ['GDF15', 'MAPK1'], 'GDF15+MAPK3': ['GDF15', 'MAPK3'], 'MAPK1+MAPK3': ['MAPK1', 'MAPK3'], 'GDF15+MAPK1+MAPK3': ['GDF15', 'MAPK1', 'MAPK3']}
    synergy = pd.DataFrame({name: pivot[name] - sum((pivot[g] for g in singles)) for name, singles in combos.items()})
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 3.7))
    ax = axes[0]
    x = np.arange(len(order))
    ecm = [data.loc[data['condition'].eq(c), 'Mean_ECM_target_shift'].to_numpy(float) for c in order]
    house = [data.loc[data['condition'].eq(c), 'Mean_housekeeping_shift'].to_numpy(float) for c in order]
    b1 = ax.boxplot(ecm, positions=x - 0.15, widths=0.27, patch_artist=True, showfliers=False)
    b2 = ax.boxplot(house, positions=x + 0.15, widths=0.27, patch_artist=True, showfliers=False)
    for p in b1['boxes']:
        p.set(facecolor=OE_RED, edgecolor=OE_RED_DARK, linewidth=0.6)
    for p in b2['boxes']:
        p.set(facecolor=LIGHT_GREY, edgecolor=INK, linewidth=0.6)
    for med in b1['medians'] + b2['medians']:
        med.set(color=INK, linewidth=0.8)
    ax.set_xticks(x, order, rotation=26, ha='right')
    ax.set_ylabel('Target-gene embedding cosine shift')
    ax.set_title('Single and combined activation', loc='left', fontweight='bold')
    ax.legend([Patch(facecolor=OE_RED), Patch(facecolor=LIGHT_GREY, edgecolor=INK)], ['ECM-remodeling targets', 'Housekeeping controls'], frameon=False, loc='upper left')
    panel_letter(ax, 'a', -0.1, 1.08)
    clean_axis(ax, 'y')
    ax = axes[1]
    arrays = [synergy[c].dropna().to_numpy(float) for c in combos]
    box = ax.boxplot(arrays, positions=np.arange(4), widths=0.58, patch_artist=True, showfliers=False)
    for p in box['boxes']:
        p.set(facecolor=OE_RED, edgecolor=OE_RED_DARK, linewidth=0.7)
    for med in box['medians']:
        med.set(color=INK, linewidth=0.9)
    ax.axhline(0, color=INK, lw=0.7, linestyle='--')
    ax.set_xticks(np.arange(4), list(combos), rotation=26, ha='right')
    ax.set_ylabel('Synergy in shift toward Healthy\n(observed - additive expectation)')
    ax.set_title('Combination cooperativity', loc='left', fontweight='bold')
    panel_letter(ax, 'b', -0.1, 1.08)
    clean_axis(ax, 'y')
    fig.tight_layout(w_pad=1.6)
    stem = '\u56fe7_GDF15_MAPK1_MAPK3\u7ec4\u5408\u6fc0\u6d3b\u534f\u540c\u6548\u5e94_Williams\u5355\u961f\u5217\u7ea0\u9519\u7248'
    save_figure(fig, stem)
    data.to_csv(TABLE / '\u56fe7_Williams\u7ec4\u5408\u6fc0\u6d3b\u9010\u7ec6\u80de.csv.gz', index=False, compression='gzip', encoding='utf-8-sig')
    synergy.reset_index().to_csv(TABLE / '\u56fe7_Williams\u7ec4\u5408\u6fc0\u6d3b\u534f\u540c\u6548\u5e94.csv', index=False, encoding='utf-8-sig')
    return {'figure': stem, 'cells': data['dataset_index'].nunique()}

def plot_figure8() -> tuple[dict, pd.DataFrame, pd.DataFrame]:
    ko = pd.read_csv(KO_SCREEN).copy()
    ko['N_cells'] = ko['N_Detections']
    oe = pd.read_csv(OE_SCREEN).copy()
    oe['N_cells'] = oe['N_Perturbed_cells']
    fig, axes = plt.subplots(1, 2, figsize=(9.6, 4.15))
    for ax, frame, mode, title, color, letter in [(axes[0], ko, 'KO', 'In silico knockout in periodontitis fibroblasts', KO_BLUE, 'a'), (axes[1], oe, 'OE', 'In silico overexpression in healthy fibroblasts', OE_RED, 'b')]:
        sizes = 10 + 2.7 * np.sqrt(frame['N_cells'].clip(lower=1))
        ax.scatter(frame['Shift_to_goal_end'], frame['Shift_away_start_end'], s=sizes, color=color, alpha=0.58, edgecolor='white', linewidth=0.35)
        ax.axvline(0, color='#888888', linestyle=':', lw=0.75)
        ax.axhline(0, color='#888888', linestyle=':', lw=0.75)
        lim = max(abs(ax.get_xlim()[0]), abs(ax.get_xlim()[1]), abs(ax.get_ylim()[0]), abs(ax.get_ylim()[1]))
        ax.plot([-lim, lim], [lim, -lim], color='#6D767B', linestyle='--', lw=0.7)
        labels = choose_labels(frame.assign(N_cells=frame['N_cells']), 10)
        label_points(ax, frame, labels, 'Shift_to_goal_end', 'Shift_away_start_end')
        ax.set_xlabel('Shift toward Healthy' if mode == 'KO' else 'Shift toward Periodontitis')
        ax.set_ylabel('Shift relative to Periodontitis' if mode == 'KO' else 'Shift relative to Healthy')
        ax.set_title(title, loc='left', fontweight='bold')
        panel_letter(ax, letter, -0.12, 1.08)
        clean_axis(ax)
    fig.tight_layout(w_pad=1.8)
    stem = '\u56fe8_Geneformer\u53cc\u5411\u75be\u75c5\u5efa\u6a21\u4e0e\u6cbb\u7597\u7b5b\u9009_Williams\u5355\u961f\u5217\u7ea0\u9519\u7248'
    save_figure(fig, stem)
    ko.to_csv(TABLE / '\u56fe8_Williams_KO\u7b5b\u9009.csv', index=False, encoding='utf-8-sig')
    oe.to_csv(TABLE / '\u56fe8_Williams_OE\u7b5b\u9009.csv', index=False, encoding='utf-8-sig')
    return ({'figure': stem, 'ko_genes': len(ko), 'oe_genes': len(oe)}, ko, oe)

def draw_confusion(ax: plt.Axes, matrix: np.ndarray, title: str, large: bool=False) -> None:
    ax.pcolormesh([0, 1, 2], [0, 1, 2], matrix, cmap='Blues', vmin=0, vmax=1, edgecolors='white', linewidth=0.35)
    for r in range(2):
        for c in range(2):
            ax.text(c + 0.5, r + 0.5, f'{matrix[r, c]:.2f}', ha='center', va='center', fontsize=10 if large else 7, color='white' if matrix[r, c] > 0.55 else INK)
    ax.set(xlim=(0, 2), ylim=(2, 0), aspect='equal')
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_title(title, fontsize=9 if large else 7.5, fontweight='bold', pad=3)
    for spine in ax.spines.values():
        spine.set_visible(False)

def plot_extended1() -> dict:
    pred = pd.read_csv(V2 / '\u6269\u5c55\u56fe7\u578b\u5206\u7c7b\u5668\u57fa\u51c6' / 'benchmark_test_predictions.csv.gz')
    pred = pred.loc[pred['cohort'].eq('Williams')].copy()
    order = ['GF', 'SVM-r', 'RF-r', 'LR-r', 'SVM-c', 'RF-c', 'LR-c']
    matrices, rows = ({}, [])
    for model in order:
        frame = pred.loc[pred['model'].eq(model)]
        cm = confusion_matrix(frame['true_label'], frame['predicted_label'], labels=[0, 1]).astype(float)
        cmn = cm / np.maximum(cm.sum(1, keepdims=True), 1)
        matrices[model] = cmn
        rows.append({'model': model, 'n_test': len(frame), 'macro_f1': f1_score(frame['true_label'], frame['predicted_label'], average='macro'), 'accuracy': accuracy_score(frame['true_label'], frame['predicted_label'])})
    metrics = pd.DataFrame(rows)
    fig = plt.figure(figsize=(11.5, 3.1))
    outer = GridSpec(1, 3, figure=fig, width_ratios=[1.05, 1.8, 1.02], wspace=0.18)
    ax_gf = fig.add_subplot(outer[0, 0])
    draw_confusion(ax_gf, matrices['GF'], 'Geneformer (GF)', True)
    ax_gf.set_xticks([0.5, 1.5], ['Healthy', 'Periodontitis'])
    ax_gf.set_yticks([0.5, 1.5], ['Healthy', 'Periodontitis'])
    ax_gf.set_xlabel('Predicted')
    ax_gf.set_ylabel('True')
    ax_gf.tick_params(length=0)
    grid = outer[0, 1].subgridspec(2, 3, wspace=0.16, hspace=0.3)
    for i, model in enumerate(order[1:]):
        draw_confusion(fig.add_subplot(grid[i // 3, i % 3]), matrices[model], model)
    ax = fig.add_subplot(outer[0, 2])
    vals = metrics.set_index('model').loc[order, 'macro_f1'].to_numpy()
    colors = ['#D35445', '#F29E57', '#F1D38A', '#F3EDB7', '#D9ECF2', '#94C0D3', '#5D86B5']
    y = np.arange(len(order))
    ax.barh(y, vals, color=colors, edgecolor='#555555', linewidth=0.35)
    ax.set_yticks(y, order)
    ax.invert_yaxis()
    ax.set_xlabel('F1 score')
    ax.set_xlim(max(0, vals.min() - 0.07), min(1, vals.max() + 0.05))
    for yy, value in zip(y, vals):
        ax.text(value + 0.004, yy, f'{value:.2f}', va='center', fontsize=6.5)
    clean_axis(ax)
    panel_letter(ax_gf, 'a', -0.35, 1.14)
    fig.text(0.5, 0.02, f"Williams held-out fibroblasts, n={pred.loc[pred['model'].eq('GF')].shape[0]}", ha='center', fontsize=6.5)
    fig.subplots_adjust(left=0.06, right=0.985, top=0.9, bottom=0.19)
    stem = '\u6269\u5c55\u56fe1_Geneformer\u4e0e\u4f20\u7edf\u6a21\u578b\u5206\u7c7b\u57fa\u51c6_Williams\u5355\u961f\u5217\u7ea0\u9519\u7248'
    save_figure(fig, stem)
    pred.to_csv(TABLE / '\u6269\u5c55\u56fe1_Williams\u6a21\u578b\u6d4b\u8bd5\u9884\u6d4b.csv.gz', index=False, compression='gzip', encoding='utf-8-sig')
    metrics.to_csv(TABLE / '\u6269\u5c55\u56fe1_Williams\u6a21\u578b\u57fa\u51c6\u6307\u6807.csv', index=False, encoding='utf-8-sig')
    return {'figure': stem, 'n': int(metrics.loc[metrics['model'].eq('GF'), 'n_test'].iloc[0])}

def plot_extended2() -> dict:
    data, predicted, threshold = load_classifier_test()
    labels = data['observed_label'].to_numpy(int)
    cm = confusion_matrix(labels, predicted, labels=[0, 1]).astype(float)
    cmn = cm / np.maximum(cm.sum(1, keepdims=True), 1)
    data['predicted_corrected'] = predicted
    data['correct'] = data['predicted_corrected'].eq(data['observed_label'])
    donors = data.groupby(['donor_id', 'disease'], as_index=False).agg(N_cells=('correct', 'size'), Accuracy=('correct', 'mean'))
    se = np.sqrt(donors['Accuracy'] * (1 - donors['Accuracy']) / donors['N_cells'].clip(lower=1))
    donors['CI95_low'] = (donors['Accuracy'] - 1.96 * se).clip(0, 1)
    donors['CI95_high'] = (donors['Accuracy'] + 1.96 * se).clip(0, 1)
    donors = donors.sort_values(['disease', 'Accuracy']).reset_index(drop=True)
    fig = plt.figure(figsize=(8.8, 4.2))
    gs = GridSpec(1, 2, figure=fig, width_ratios=[0.9, 1.7], wspace=0.45)
    ax = fig.add_subplot(gs[0, 0])
    draw_confusion(ax, cmn, 'Williams within-cohort test', True)
    ax.set_xticks([0.5, 1.5], ['Healthy', 'Periodontitis'], rotation=20)
    ax.set_yticks([0.5, 1.5], ['Healthy', 'Periodontitis'])
    ax.set_xlabel('Predicted')
    ax.set_ylabel('True')
    ax.text(0.5, -0.4, f"Accuracy {accuracy_score(labels, predicted):.4f}\nF1 {f1_score(labels, predicted, average='macro'):.4f}", transform=ax.transAxes, ha='center', va='top')
    panel_letter(ax, 'a', -0.24, 1.12)
    ax = fig.add_subplot(gs[0, 1])
    y = np.arange(len(donors))
    xerr = np.vstack([donors['Accuracy'] - donors['CI95_low'], donors['CI95_high'] - donors['Accuracy']])
    ax.errorbar(donors['Accuracy'], y, xerr=xerr, fmt='none', ecolor=INK, lw=0.65, capsize=2)
    colors = np.where(donors['disease'].eq('periodontitis'), OE_RED, KO_BLUE)
    ax.scatter(donors['Accuracy'], y, s=25, c=colors, edgecolor=INK, linewidth=0.35, zorder=3)
    labels_y = [f"{(re.search('GSM\\d+', str(x)).group(0) if re.search('GSM\\d+', str(x)) else x)} (n={n})" for x, n in zip(donors['donor_id'], donors['N_cells'])]
    ax.set_yticks(y, labels_y)
    ax.invert_yaxis()
    ax.set_xlim(0, 1.03)
    ax.set_xlabel('Correctly classified cells per donor (fraction; 95% CI)')
    ax.set_title('Donor-level performance', loc='left', fontweight='bold')
    ax.legend([Line2D([0], [0], marker='o', linestyle='', color=KO_BLUE), Line2D([0], [0], marker='o', linestyle='', color=OE_RED)], ['Healthy', 'Periodontitis'], frameon=False, ncol=2, loc='lower right')
    panel_letter(ax, 'b', -0.12, 1.08)
    clean_axis(ax, 'x')
    fig.subplots_adjust(left=0.19, right=0.985, top=0.9, bottom=0.23)
    stem = '\u6269\u5c55\u56fe2_Williams\u4f9b\u4f53\u7ea7\u5206\u7c7b\u7a33\u5065\u6027_\u7ea0\u9519\u7248'
    save_figure(fig, stem)
    donors.to_csv(TABLE / '\u6269\u5c55\u56fe2_Williams\u4f9b\u4f53\u7ea7\u5206\u7c7b\u51c6\u786e\u7387.csv', index=False, encoding='utf-8-sig')
    return {'figure': stem, 'donors': len(donors), 'threshold': threshold}

def plot_extended3() -> dict:
    data = pd.read_csv(EXTRA / '04_GDF15\u6270\u52a8\u4e9a\u7fa4\u7279\u5f02\u6027_\u9010\u7ec6\u80de.csv')
    data = data.loc[data['cohort'].eq('Williams')].copy()
    summary = data.groupby(['scenario', 'subtype_group'], as_index=False).agg(N_cells=('dataset_index', 'size'), Mean_desirability=('Desirability_score', 'mean'), SD=('Desirability_score', 'std'))
    summary['SE'] = summary['SD'] / np.sqrt(summary['N_cells'].clip(lower=1))
    summary['CI95_low'] = summary['Mean_desirability'] - 1.96 * summary['SE']
    summary['CI95_high'] = summary['Mean_desirability'] + 1.96 * summary['SE']
    fig, axes = plt.subplots(1, 2, figsize=(9.0, 4.1), sharex=True)
    for ax, (scenario, (title, color, dark)), letter in zip(axes, SCENARIOS.items(), ['a', 'b']):
        frame = summary.loc[summary['scenario'].eq(scenario) & (summary['N_cells'] >= 3)].sort_values('Mean_desirability')
        y = np.arange(len(frame))
        err = np.vstack([frame['Mean_desirability'] - frame['CI95_low'], frame['CI95_high'] - frame['Mean_desirability']])
        ax.errorbar(frame['Mean_desirability'], y, xerr=err, fmt='none', ecolor=dark, lw=0.7, capsize=2)
        ax.scatter(frame['Mean_desirability'], y, s=28 + 4 * np.sqrt(frame['N_cells']), color=color, edgecolor=dark, linewidth=0.5, zorder=3)
        ax.axvline(0, color=INK, lw=0.7, linestyle='--')
        ax.set_yticks(y, [f'{r.subtype_group} (n={r.N_cells})' for r in frame.itertuples()])
        ax.set_xlabel('State-shift desirability (mean; 95% CI)')
        ax.set_title(title, loc='left', fontweight='bold')
        panel_letter(ax, letter, -0.13, 1.08)
        clean_axis(ax, 'x')
    fig.tight_layout(w_pad=1.7)
    stem = '\u6269\u5c55\u56fe3_GDF15\u6270\u52a8\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e9a\u7fa4\u7279\u5f02\u6027_Williams\u5355\u961f\u5217\u7ea0\u9519\u7248'
    save_figure(fig, stem)
    summary.to_csv(TABLE / '\u6269\u5c55\u56fe3_Williams\u4e9a\u7fa4\u7279\u5f02\u6027\u7edf\u8ba1.csv', index=False, encoding='utf-8-sig')
    return {'figure': stem, 'subtypes': summary['subtype_group'].nunique()}

def plot_extended4() -> dict:
    data = pd.read_csv(EXTRA / '05_GDF15\u8fc7\u8868\u8fbeRank\u5242\u91cf\u626b\u63cf' / 'GDF15_rank_dose_cell_level.csv.gz')
    data = data.loc[data['cohort'].eq('Williams')].copy()
    metrics = [('Shift_to_Periodontitis', 'Shift toward Periodontitis'), ('Shift_away_Healthy', 'Shift relative to Healthy')]
    rows = []
    for rank, frame in data.groupby('Perturbed_GDF15_rank'):
        for metric, _ in metrics:
            values = frame[metric].to_numpy(float)
            se = np.nanstd(values, ddof=1) / math.sqrt(max(len(values), 1))
            rows.append({'Perturbed_GDF15_rank': rank, 'metric': metric, 'N_cells': len(values), 'Mean': np.nanmean(values), 'CI95_low': np.nanmean(values) - 1.96 * se, 'CI95_high': np.nanmean(values) + 1.96 * se})
    summary = pd.DataFrame(rows)
    ranks = [1, 10, 25, 50, 100]
    fig, axes = plt.subplots(1, 2, figsize=(8.0, 3.45), sharex=True)
    for ax, (metric, title), letter in zip(axes, metrics, ['a', 'b']):
        frame = summary.loc[summary['metric'].eq(metric)].set_index('Perturbed_GDF15_rank').loc[ranks]
        mean = frame['Mean'].to_numpy(float)
        yerr = np.vstack([mean - frame['CI95_low'].to_numpy(float), frame['CI95_high'].to_numpy(float) - mean])
        ax.errorbar(np.arange(5), mean, yerr=yerr, color=OE_RED, marker='o', markeredgecolor=OE_RED_DARK, lw=1.2, capsize=2)
        ax.axhline(0, color=INK, lw=0.7, linestyle='--')
        ax.set_xticks(np.arange(5), [str(x) for x in ranks])
        ax.set_xlabel('Forced GDF15 rank')
        ax.set_ylabel('Delta cosine similarity')
        ax.set_title(title, loc='left', fontweight='bold')
        panel_letter(ax, letter, -0.12, 1.08)
        clean_axis(ax, 'y')
    fig.tight_layout(w_pad=1.7)
    stem = '\u6269\u5c55\u56fe4_GDF15\u8fc7\u8868\u8fbeRank\u5242\u91cf\u53cd\u5e94_Williams\u5355\u961f\u5217\u7ea0\u9519\u7248'
    save_figure(fig, stem)
    summary.to_csv(TABLE / '\u6269\u5c55\u56fe4_Williams_GDF15\u8fc7\u8868\u8fbeRank\u5242\u91cf\u7edf\u8ba1.csv', index=False, encoding='utf-8-sig')
    return {'figure': stem, 'cells': data['dataset_index'].nunique()}

def plot_extended5(ko: pd.DataFrame, oe: pd.DataFrame) -> dict:
    de = pd.read_csv(EXTRA / '08_\u75be\u75c5\u5dee\u5f02\u8868\u8fbe\u91cd\u53e0' / 'Williams_fibroblast_donor_pseudobulk_DE.csv.gz')
    de_map = de.set_index('Ensembl_ID')['DE_FDR_0.05_abs_log2FC_0.25'].astype(bool).to_dict()
    rows = []
    for mode, frame in [('KO', ko), ('OE', oe)]:
        temp = frame.copy()
        temp['DE'] = temp['Ensembl_ID'].map(de_map).fillna(False).astype(bool)
        temp['GF_associated'] = temp['Goal_end_vs_random_pval'].astype(float) < 0.05
        a = int((temp['DE'] & temp['GF_associated']).sum())
        b = int((~temp['DE'] & temp['GF_associated']).sum())
        c = int((temp['DE'] & ~temp['GF_associated']).sum())
        d = int((~temp['DE'] & ~temp['GF_associated']).sum())
        odds, p = stats.fisher_exact([[a, b], [c, d]], alternative='greater')
        rows.append({'mode': mode, 'GF_associated_DE': a, 'GF_associated_not_DE': b, 'background_DE': c, 'background_not_DE': d, 'GF_associated_DE_fraction': a / max(a + b, 1), 'background_DE_fraction': c / max(c + d, 1), 'odds_ratio': odds, 'Raw_P_Fisher_greater': p})
    result = pd.DataFrame(rows)
    result['BH_FDR_Fisher'] = bh_fdr(result['Raw_P_Fisher_greater'])
    fig, ax = plt.subplots(figsize=(5.3, 3.7))
    x = np.arange(2)
    width = 0.34
    colors = [KO_BLUE, OE_RED]
    for i, row in result.iterrows():
        ax.bar(i - width / 2, row['GF_associated_DE_fraction'], width, color=colors[i], edgecolor=INK, linewidth=0.5)
        ax.bar(i + width / 2, row['background_DE_fraction'], width, color=LIGHT_GREY, edgecolor=INK, linewidth=0.5)
        ax.text(i, max(row['GF_associated_DE_fraction'], row['background_DE_fraction']) + 0.01, f"FDR={row['BH_FDR_Fisher']:.2g}", ha='center', fontsize=7)
    ax.set_xticks(x, ['KO', 'OE'])
    ax.set_ylabel('Fraction overlapping disease DE genes')
    ax.legend([Patch(facecolor='#808080'), Patch(facecolor=LIGHT_GREY, edgecolor=INK)], ['Geneformer-associated genes', 'Screened background genes'], frameon=False)
    panel_letter(ax, 'c', -0.1, 1.08)
    clean_axis(ax, 'y')
    fig.tight_layout()
    stem = '\u6269\u5c55\u56fe5_Geneformer\u6270\u52a8\u5019\u9009\u4e0e\u75be\u75c5\u5dee\u5f02\u57fa\u56e0\u91cd\u53e0_Williams\u5355\u961f\u5217\u7ea0\u9519\u7248'
    save_figure(fig, stem)
    result.to_csv(TABLE / '\u6269\u5c55\u56fe5_Williams\u6270\u52a8\u5019\u9009\u4e0e\u75be\u75c5DE\u91cd\u53e0\u7edf\u8ba1.csv', index=False, encoding='utf-8-sig')
    return {'figure': stem, 'tests': len(result)}

def read_gmt(path: Path, category: str) -> list[dict]:
    records = []
    with path.open(encoding='utf-8', errors='ignore') as handle:
        for line in handle:
            parts = line.rstrip('\n').split('\t')
            if len(parts) >= 4:
                records.append({'Category': category, 'Term': parts[0].strip(), 'genes': {g.strip().upper() for g in parts[2:] if g.strip()}})
    return records

def enrich_screens(ko: pd.DataFrame, oe: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    gene_sets = DATA_ROOT / '\u539f\u59cb\u6570\u636e' / '05_\u5355\u7ec6\u80deRNA' / 'gene_sets'
    kegg = DATA_ROOT / '\u8f93\u51fa\u7ed3\u679c' / '20260821_GDF15\u865a\u62df\u6572\u9664_scTenifoldKnk_\u9996\u7248' / '03_enrichment' / 'KEGG_2026_local_library.gmt'
    libraries = []
    for filename, category in [('GO_Biological_Process_2025.gmt', 'GO BP'), ('GO_Cellular_Component_2025.gmt', 'GO CC'), ('GO_Molecular_Function_2025.gmt', 'GO MF'), ('Reactome_Pathways_2024.gmt', 'Reactome')]:
        libraries.extend(read_gmt(gene_sets / filename, category))
    libraries.extend(read_gmt(kegg, 'KEGG'))
    rows = []
    for label, frame in [('KO toward Healthy', ko), ('OE toward Periodontitis', oe)]:
        frame = frame.drop_duplicates('Gene_name')
        universe = set(frame['Gene_name'].astype(str).str.upper())
        scores = dict(zip(frame['Gene_name'].astype(str).str.upper(), frame['Desirability_score'].astype(float)))
        n_top = max(20, int(round(len(frame) * 0.15)))
        top = set(frame.nlargest(n_top, 'Desirability_score')['Gene_name'].astype(str).str.upper())
        for record in libraries:
            members = record['genes'] & universe
            if not 3 <= len(members) <= 300:
                continue
            overlap = members & top
            if len(overlap) < 2:
                continue
            p = stats.hypergeom.sf(len(overlap) - 1, len(universe), len(members), len(top))
            rows.append({'Scenario': label, 'Category': record['Category'], 'Term': record['Term'], 'Count': len(overlap), 'GeneRatio': len(overlap) / len(top), 'Raw_P_hypergeometric': float(p), 'Mean_score_term': float(np.mean([scores[g] for g in members])), 'Genes': '/'.join(sorted(overlap))})
    result = pd.DataFrame(rows)
    for scenario, idx in result.groupby('Scenario').groups.items():
        result.loc[idx, 'BH_FDR_hypergeometric'] = bh_fdr(result.loc[idx, 'Raw_P_hypergeometric'])
    related = re.compile('MAPK|ERK|SIGNAL TRANSDUCTION|PHOSPHORYLATION|MTOR|CELL MOTILITY|LOCOMOTION|TUMOR NECROSIS FACTOR|EXTRACELLULAR MATRIX|COLLAGEN|FIBROBLAST|TGF|FOCAL ADHESION|INTEGRIN|WOUND|CYTOKINE|GROWTH FACTOR|MATRIX ORGANIZATION|PROTEOGLYCAN', re.I)
    selected = []
    quotas = {'GO BP': 6, 'GO CC': 3, 'GO MF': 3, 'Reactome': 4, 'KEGG': 4}
    for scenario, sf in result.groupby('Scenario'):
        sf = sf.loc[sf['Raw_P_hypergeometric'] < 0.05].copy()
        for category, quota in quotas.items():
            sub = sf.loc[(sf['Category'] == category) & sf['Term'].str.contains(related)].sort_values(['Raw_P_hypergeometric', 'GeneRatio'], ascending=[True, False]).head(quota)
            if not sub.empty:
                selected.append(sub)
    selected_df = pd.concat(selected, ignore_index=True) if selected else result.nsmallest(20, 'Raw_P_hypergeometric')
    return (result, selected_df)

def plot_extended6(ko: pd.DataFrame, oe: pd.DataFrame) -> dict:
    result, selected = enrich_screens(ko, oe)
    result.to_csv(TABLE / '\u6269\u5c55\u56fe6_Williams\u65b9\u5411\u6027\u5019\u9009\u901a\u8def\u5bcc\u96c6_\u5168\u90e8\u7ed3\u679c.csv.gz', index=False, compression='gzip', encoding='utf-8-sig')
    selected.to_csv(TABLE / '\u6269\u5c55\u56fe6_Williams\u65b9\u5411\u6027\u5019\u9009\u901a\u8def\u5bcc\u96c6_\u4f5c\u56fe\u6761\u76ee.csv', index=False, encoding='utf-8-sig')
    cat_colors = {'GO BP': '#CEE1E6', 'GO CC': '#F1DFC0', 'GO MF': '#DFCFE2', 'Reactome': '#D7E3CD', 'KEGG': '#F1CDC7'}
    fig, axes = plt.subplots(1, 2, figsize=(13.2, 7.1))
    setup = [('KO toward Healthy', 'KO candidates ranked toward Healthy', 'Blues', 'd'), ('OE toward Periodontitis', 'OE candidates ranked toward Periodontitis', 'Reds', 'e')]
    for ax, (scenario, title, cmap, letter) in zip(axes, setup):
        frame = selected.loc[selected['Scenario'].eq(scenario)].copy()
        order = ['GO BP', 'GO CC', 'GO MF', 'Reactome', 'KEGG']
        frame['Category'] = pd.Categorical(frame['Category'], order, ordered=True)
        frame = frame.sort_values(['Category', 'GeneRatio'], ascending=[True, False]).reset_index(drop=True)
        y = np.arange(len(frame))[::-1]
        for yy, row in zip(y, frame.itertuples()):
            ax.barh(yy, row.GeneRatio, color=cat_colors[str(row.Category)], height=0.78, edgecolor='none')
        sc = ax.scatter(frame['GeneRatio'], y, s=18 + 14 * frame['Count'], c=-np.log10(frame['Raw_P_hypergeometric'].clip(lower=1e-300)), cmap=cmap, edgecolor='white', linewidth=0.45, zorder=3)
        labels = []
        for term in frame['Term'].astype(str):
            label = re.sub('\\s+\\(GO:\\d+\\)$', '', term, flags=re.I).replace('_', ' ')
            labels.append(textwrap.fill(label.title() if label.isupper() else label, 38, break_long_words=False))
        ax.set_yticks(y, labels)
        ax.set_xlabel('Gene ratio (top 15% ranked candidates)')
        ax.set_title(title, loc='left', fontweight='bold')
        panel_letter(ax, letter, -0.18, 1.04)
        clean_axis(ax, 'x')
        cbar = fig.colorbar(sc, ax=ax, fraction=0.035, pad=0.02)
        cbar.set_label('-log10(raw P)')
    fig.legend([Patch(facecolor=v) for v in cat_colors.values()], list(cat_colors), frameon=False, loc='lower center', ncol=5, title='Category')
    fig.subplots_adjust(left=0.24, right=0.985, top=0.95, bottom=0.14, wspace=0.92)
    stem = '\u6269\u5c55\u56fe6_Geneformer\u65b9\u5411\u6027\u5019\u9009\u901a\u8def\u5bcc\u96c6_Williams\u5355\u961f\u5217\u7ea0\u9519\u7248'
    save_figure(fig, stem)
    return {'figure': stem, 'displayed_terms': len(selected)}

def plot_extended7() -> dict:
    raw = pd.read_csv(EXTRA / '10_\u6ce8\u610f\u529b\u4e0e\u7f51\u7edc\u5c42\u7ea7' / 'pretrained_attention_512token_cell_level.csv.gz')
    gdf = raw.loc[raw['network_group'].eq('GDF15')]
    matrix = gdf.groupby(['layer', 'head'])['within_cell_attention_percentile'].median().unstack('head').sort_index()
    rows = []
    for (layer, head), group in raw.groupby(['layer', 'head']):
        axis = group.loc[group['network_group'].isin(['GDF15', 'MAPK-response', 'ECM-remodeling']), 'within_cell_attention_percentile'].to_numpy(float)
        other = group.loc[group['network_group'].eq('Other'), 'within_cell_attention_percentile'].to_numpy(float)
        p = stats.mannwhitneyu(axis, other, alternative='greater').pvalue if len(axis) and len(other) else 1
        rows.append({'layer': layer, 'head': head, 'Median_axis': np.median(axis), 'Median_other': np.median(other), 'Median_GDF15': group.loc[group['network_group'].eq('GDF15'), 'within_cell_attention_percentile'].median(), 'Raw_P': p})
    stat = pd.DataFrame(rows)
    stat['BH_FDR'] = bh_fdr(stat['Raw_P'])
    stat['score'] = stat['Median_GDF15'] + stat['Median_axis'] - stat['Median_other']
    best = stat.sort_values(['BH_FDR', 'score'], ascending=[True, False]).iloc[0]
    focus = raw.loc[(raw['layer'] == best['layer']) & (raw['head'] == best['head'])].copy()
    focus['rank_bin'] = pd.cut(focus['rank'], [0, 64, 128, 256, 384, 512], labels=['1-64', '65-128', '129-256', '257-384', '385-512'])
    rank = focus.groupby(['network_group', 'rank_bin'], observed=True)['within_cell_attention_percentile'].agg(['mean', 'sem']).reset_index()
    fig = plt.figure(figsize=(10.3, 3.7))
    gs = GridSpec(1, 3, figure=fig, width_ratios=[1, 1.1, 1.55], wspace=0.43)
    ax = fig.add_subplot(gs[0, 0])
    val = matrix.to_numpy()
    ax.pcolormesh(np.arange(val.shape[1] + 1), np.arange(val.shape[0] + 1), val, cmap='YlGnBu', vmin=0, vmax=1)
    ax.set(xlim=(0, val.shape[1]), ylim=(val.shape[0], 0))
    ax.set_xticks(np.arange(val.shape[1]) + 0.5, matrix.columns.astype(str))
    ax.set_yticks(np.arange(val.shape[0]) + 0.5, matrix.index.astype(str))
    ax.set_xlabel('Attention head')
    ax.set_ylabel('Layer')
    ax.set_title('GDF15 attention percentile', loc='left', fontweight='bold')
    panel_letter(ax, 'a', -0.2, 1.08)
    ax = fig.add_subplot(gs[0, 1])
    groups = ['GDF15', 'MAPK-response', 'ECM-remodeling', 'Other']
    arrays = [focus.loc[focus['network_group'].eq(g), 'within_cell_attention_percentile'].to_numpy(float) for g in groups]
    box = ax.boxplot(arrays, positions=np.arange(4), widths=0.58, patch_artist=True, showfliers=False)
    for p, c in zip(box['boxes'], ['#2B6E93', '#D5A24E', '#86B8BA', LIGHT_GREY]):
        p.set(facecolor=c, edgecolor=INK, linewidth=0.6)
    for med in box['medians']:
        med.set(color=INK, linewidth=0.9)
    ax.set_xticks(np.arange(4), groups, rotation=25, ha='right')
    ax.set_ylabel('Within-cell attention percentile')
    ax.set_title(f"Layer {int(best['layer'])}, head {int(best['head'])}", loc='left', fontweight='bold')
    panel_letter(ax, 'b', -0.18, 1.08)
    clean_axis(ax, 'y')
    ax = fig.add_subplot(gs[0, 2])
    rb = ['1-64', '65-128', '129-256', '257-384', '385-512']
    for group, color, marker in [('MAPK-response', '#8D6525', 's'), ('ECM-remodeling', '#397A7D', 'o'), ('Other', '#777777', '^')]:
        fr = rank.loc[rank['network_group'].eq(group)].set_index('rank_bin').reindex(rb)
        ax.errorbar(np.arange(5), fr['mean'], yerr=fr['sem'], color=color, marker=marker, lw=1, markersize=4, capsize=2, label=group)
    ax.set_xticks(np.arange(5), rb, rotation=25, ha='right')
    ax.set_xlabel('Gene rank in 512-token encoding')
    ax.set_ylabel('Mean attention percentile')
    ax.set_title('Contextual attention versus rank', loc='left', fontweight='bold')
    ax.legend(frameon=False)
    panel_letter(ax, 'c', -0.14, 1.08)
    clean_axis(ax, 'y')
    fig.subplots_adjust(left=0.07, right=0.985, top=0.91, bottom=0.23)
    stem = '\u6269\u5c55\u56fe7_GDF15_MAPK_ECM\u6ce8\u610f\u529b\u7f51\u7edc\u5c42\u7ea7_Williams\u5355\u961f\u5217\u6838\u5bf9\u7248'
    save_figure(fig, stem)
    stat.to_csv(TABLE / '\u6269\u5c55\u56fe7_Williams\u6ce8\u610f\u529b\u5934\u7edf\u8ba1.csv', index=False, encoding='utf-8-sig')
    return {'figure': stem, 'cells': raw['dataset_index'].nunique() if 'dataset_index' in raw else np.nan}

def plot_supplementary1() -> dict:
    data = pd.read_csv(EMBED)
    colors = {0: KO_BLUE, 1: OE_RED}
    fig, axes = plt.subplots(1, 2, figsize=(8.6, 4.0))
    for ax, x, y, title, letter in [(axes[0], 'UMAP1_pretrained', 'UMAP2_pretrained', 'Pretrained embeddings', 'a'), (axes[1], 'UMAP1_finetuned', 'UMAP2_finetuned', 'Fine-tuned embeddings', 'b')]:
        for label, name in [(0, 'Healthy'), (1, 'Periodontitis')]:
            frame = data.loc[data['label'].eq(label)]
            ax.scatter(frame[x], frame[y], s=5, color=colors[label], alpha=0.62, edgecolor='none', rasterized=True, label=name)
        ax.set_xlabel('UMAP 1')
        ax.set_ylabel('UMAP 2')
        ax.set_title(title, loc='left', fontweight='bold')
        panel_letter(ax, letter, -0.12, 1.08)
        clean_axis(ax)
    axes[0].legend(frameon=False)
    fig.tight_layout(w_pad=1.5)
    stem = '\u8865\u5145\u56fe1_Geneformer\u5fae\u8c03\u524d\u540e\u72b6\u6001\u5d4c\u5165UMAP_Williams\u5355\u961f\u5217\u7ea0\u9519\u7248'
    save_figure(fig, stem)
    data.to_csv(TABLE / '\u8865\u5145\u56fe1_Williams\u5d4c\u5165UMAP\u5750\u6807.csv', index=False, encoding='utf-8-sig')
    return {'figure': stem, 'cells': len(data)}

def schematic(ax: plt.Axes) -> None:
    rng = np.random.default_rng(SEED)
    for x, color, label in [(-1.0, OE_RED, 'Periodontitis'), (1.0, KO_BLUE, 'Healthy')]:
        pts = rng.normal([x, 0], [0.12, 0.12], size=(11, 2))
        ax.scatter(pts[:, 0], pts[:, 1], s=55, color=color, alpha=0.75, edgecolor=INK, linewidth=0.3)
        ax.text(x, -0.55, label, ha='center', va='top')
    ax.add_patch(FancyArrowPatch((-0.55, 0.18), (0.55, 0.18), arrowstyle='-|>', mutation_scale=12, color=KO_BLUE_DARK, lw=1.3))
    ax.add_patch(FancyArrowPatch((0.55, -0.18), (-0.55, -0.18), arrowstyle='-|>', mutation_scale=12, color=OE_RED_DARK, lw=1.3))
    ax.text(0, 0.38, 'KO: shift toward Healthy', ha='center', color=KO_BLUE_DARK, fontsize=7)
    ax.text(0, -0.42, 'OE: shift toward Periodontitis', ha='center', color=OE_RED_DARK, fontsize=7)
    ax.set_xlim(-1.8, 1.8)
    ax.set_ylim(-0.9, 0.9)
    ax.axis('off')
    panel_letter(ax, 'A', -0.02, 1.02)

def plot_supplementary2() -> dict:
    ko = screen_frame('KO')
    oe = screen_frame('OE')
    fig = plt.figure(figsize=(11.3, 3.45))
    gs = GridSpec(1, 3, figure=fig, width_ratios=[1.0, 1.3, 1.3], wspace=0.42)
    ax = fig.add_subplot(gs[0, 0])
    schematic(ax)
    for ax, frame, title, color, letter, xlab, ylab in [(fig.add_subplot(gs[0, 1]), ko, 'GDF15 knockout', KO_BLUE, 'B', 'Shift to goal end (Healthy)', 'Shift away start (Periodontitis)'), (fig.add_subplot(gs[0, 2]), oe, 'GDF15 overexpression', OE_RED, 'C', 'Shift to goal end (Periodontitis)', 'Shift away start (Healthy)')]:
        ax.scatter(frame['Shift_to_goal_end'], frame['Shift_away_start_end'], s=10, color=color, alpha=0.78, edgecolor='none')
        gdf = frame.loc[frame['Gene_name'].eq('GDF15')]
        ax.scatter(gdf['Shift_to_goal_end'], gdf['Shift_away_start_end'], s=50, color=color, marker='*', edgecolor=INK, linewidth=0.4, zorder=4)
        label_points(ax, frame, choose_labels(frame, 8), 'Shift_to_goal_end', 'Shift_away_start_end', color=INK)
        ax.axvline(0, color='#888888', lw=0.6, linestyle=':')
        ax.axhline(0, color='#888888', lw=0.6, linestyle=':')
        ax.set_xlabel(xlab)
        ax.set_ylabel(ylab)
        ax.set_title(title, fontweight='bold')
        panel_letter(ax, letter, -0.14, 1.08)
        clean_axis(ax)
    fig.subplots_adjust(left=0.03, right=0.985, top=0.91, bottom=0.2)
    stem = '\u8865\u5145\u56fe2_GDF15\u865a\u62df\u6572\u9664\u4e0e\u8fc7\u8868\u8fbe\u8bba\u6587\u540c\u578b\u6563\u70b9_Williams\u5355\u961f\u5217\u7ea0\u9519\u7248'
    save_figure(fig, stem)
    return {'figure': stem, 'ko_genes': len(ko), 'oe_genes': len(oe)}

def write_readme(records: list[dict]) -> None:
    rows = []
    for record in records:
        rows.append({'\u6587\u4ef6': record['figure'] + '.pdf', '\u961f\u5217': 'Williams', 'KO\u989c\u8272': KO_BLUE, 'OE\u989c\u8272': OE_RED, '\u72b6\u6001': '\u5df2\u91cd\u7b97\u6216\u6309Williams\u539f\u59cb\u7ed3\u679c\u91cd\u7ed8'})
    audit = pd.DataFrame(rows)
    audit.to_csv(QA / '\u9010\u56fe\u961f\u5217\u4e0e\u914d\u8272\u6838\u5bf9\u8868.csv', index=False, encoding='utf-8-sig')
    text = ['# Williams \u5355\u961f\u5217\u5168\u56fe\u7ea0\u9519\u6c47\u603b', '', '\u672c\u76ee\u5f55\u7684\u6240\u6709\u5206\u6790\u56fe\u53ea\u4f7f\u7528 Williams \u961f\u5217\u3002KO \u7edf\u4e00\u4f7f\u7528\u84dd\u8272\uff0cOE \u7edf\u4e00\u4f7f\u7528\u7ea2\u8272\uff1b\u65e7\u76ee\u5f55\u672a\u88ab\u8986\u76d6\u3002', '', f'- PDF\uff1a{len(records)} \u5f20', f'- KO \u4e3b\u8272\uff1a{KO_BLUE}', f'- OE \u4e3b\u8272\uff1a{OE_RED}', '- \u56fe2\uff1aKO \u9762\u677f\u7eb3\u5165\u5168\u90e8\u7259\u5468\u708e\u6210\u7ea4\u7ef4\u7ec6\u80de\uff1bOE \u9762\u677f\u7eb3\u5165\u5168\u90e8\u5065\u5eb7\u6210\u7ea4\u7ef4\u7ec6\u80de\uff1b\u5171\u540c\u4f7f\u7528\u6b63\u5f0f\u4e94\u7c7b\u6210\u7ea4\u7ef4\u7ec6\u80de UMAP \u5750\u6807\u3002', '- \u56fe1\uff1a\u4f7f\u7528\u672a\u7ecf softmax\u3001Z-score \u6216\u4eba\u4e3a\u622a\u65ad\u7684\u539f\u59cb logits\uff1b\u4ec5\u6309\u771f\u5b9e\u7c7b\u522b\u5206\u7ec4\uff0c\u4e0d\u6309\u9884\u6d4b\u5f97\u5206\u8fdb\u884c\u7ec4\u5185\u6392\u5e8f\u3002', '', '## \u56fe\u6587\u4ef6', '']
    text.extend([f"- {r['figure']}.pdf" for r in records])
    (OUT / 'README_\u8bf7\u5148\u770b.md').write_text('\n'.join(text) + '\n', encoding='utf-8')
    manifest = {'cohort': 'Williams', 'ko_color': KO_BLUE, 'oe_color': OE_RED, 'pdf_count': len(records), 'figures': records}
    (QA / 'figure_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')

def main() -> None:
    ensure_dirs()
    set_style()
    records: list[dict] = []
    records.append(plot_figure1())
    records.append(plot_figure2())
    records.append(plot_figure3())
    records.extend(plot_figures4_5())
    records.append(plot_figure6())
    records.append(plot_figure7())
    record8, ko, oe = plot_figure8()
    records.append(record8)
    records.append(plot_extended1())
    records.append(plot_extended2())
    records.append(plot_extended3())
    records.append(plot_extended4())
    records.append(plot_extended5(ko, oe))
    records.append(plot_extended6(ko, oe))
    records.append(plot_extended7())
    records.append(plot_supplementary1())
    records.append(plot_supplementary2())
    if len(records) != 17:
        raise RuntimeError(f'Expected 17 figure records, found {len(records)}')
    write_readme(records)
    print(json.dumps({'output': str(OUT), 'pdf_count': len(records)}, ensure_ascii=False, indent=2), flush=True)
if __name__ == '__main__':
    main()
