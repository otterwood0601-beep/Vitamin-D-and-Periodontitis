from __future__ import annotations
import argparse
import math
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib import colors as mcolors
from matplotlib.gridspec import GridSpec
from matplotlib.patches import Patch
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260906_Geneformer_GDF15_Williams\u5355\u961f\u5217_\u5168\u56fe\u7ea0\u9519\u6c47\u603b_v1')
FIG_DIR = ROOT / '\u56fe\u7247'
TABLE_DIR = ROOT / '\u6570\u636e\u8868'
QA_DIR = ROOT / 'QA_\u5750\u6807\u6838\u5bf9' / '\u56fe3_\u539f\u7248\u753b\u5e034X\u65e0\u91cd\u53e0\u7248'
SUMMARY_PATH = TABLE_DIR / '\u56fe3_Williams_GDF15\u4e0b\u6e38\u57fa\u56e0\u8bc1\u636e\u6c47\u603b.csv'
CELL_PATH = TABLE_DIR / '\u56fe3_Williams_GDF15\u5b9a\u5411\u6270\u52a8\u9010\u7ec6\u80de.csv'
STEM = '\u56fe3_GDF15\u6572\u9664\u4e0e\u8fc7\u8868\u8fbe\u5706\u5f62\u57fa\u56e0\u8bc1\u636e\u56fe_Williams\u5355\u961f\u5217\u7ea0\u9519\u7248_\u753b\u5e034X\u65e0\u6587\u5b57\u91cd\u53e0\u7248'
KO_SCENARIO = 'Periodontitis_GDF15_KO_to_Healthy'
OE_SCENARIO = 'Healthy_GDF15_OE_to_Periodontitis'
KO_BLUE = '#397FC0'
KO_BLUE_DARK = '#1F5F9B'
OE_RED = '#D9544D'
OE_RED_DARK = '#A93434'
INK = '#222222'
SEED = 42
ORIGINAL_PAGE_POINTS = (829.434, 396.539)
CANVAS_INCHES = (2 * ORIGINAL_PAGE_POINTS[0] / 72, 2 * ORIGINAL_PAGE_POINTS[1] / 72)

def set_style() -> None:
    plt.rcParams.update({'font.family': 'Arial', 'font.size': 10, 'axes.titlesize': 11, 'axes.labelsize': 10, 'xtick.labelsize': 9, 'ytick.labelsize': 9, 'axes.linewidth': 0.8, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none', 'figure.facecolor': 'white', 'axes.facecolor': 'white', 'savefig.facecolor': 'white'})

def validate_inputs(summary: pd.DataFrame, cell: pd.DataFrame) -> None:
    if set(summary['cohort'].astype(str).unique()) != {'Williams'}:
        raise ValueError('Figure 3 summary must contain Williams only.')
    if set(cell['cohort'].astype(str).unique()) != {'Williams'}:
        raise ValueError('Figure 3 cell data must contain Williams only.')
    joined = ' '.join(summary.astype(str).to_numpy().ravel()) + ' ' + ' '.join(cell.astype(str).to_numpy().ravel())
    if 'Caetano' in joined:
        raise ValueError('Caetano was detected in the Figure 3 input.')

def circle_selection(summary: pd.DataFrame, scenario: str, total: int=28) -> pd.DataFrame:
    frame = summary.loc[(summary['scenario'] == scenario) & (summary['cohort'] == 'Williams')].copy()
    frame = frame.sort_values('Mean_token_cosine_shift', ascending=False)
    axis = frame.loc[frame['Priority_class'].isin(['MAPK-response', 'ECM-remodeling'])].head(20)
    other = frame.loc[frame['Priority_class'].eq('Other')].head(max(total - len(axis), 0))
    selected = pd.concat([axis, other], ignore_index=True).drop_duplicates('Gene').head(total)
    return selected.sort_values('Mean_token_cosine_shift', ascending=False).reset_index(drop=True)

def upright_tangential_rotation(angle_degrees: float) -> float:
    rotation = (angle_degrees - 90 + 180) % 360 - 180
    if rotation > 90:
        rotation -= 180
    elif rotation < -90:
        rotation += 180
    return rotation

def draw_circle(ax: plt.Axes, summary: pd.DataFrame, scenario: str, cmap_name: str, outer_color: str) -> list[plt.Text]:
    selected = circle_selection(summary, scenario)
    n = len(selected)
    theta = np.linspace(math.radians(8), math.radians(352), n, endpoint=False)
    width = math.radians(344 / max(n, 1)) * 0.94
    values = selected['Mean_token_cosine_shift'].to_numpy(float) * 1000
    vmax = max(float(np.quantile(values, 0.98)), 1e-06)
    norm = mcolors.Normalize(0, vmax)
    cmap = plt.get_cmap(cmap_name)
    ax.bar(theta, np.repeat(0.85, n), bottom=1.05, width=width, color=[cmap(norm(v)) for v in values], edgecolor='white', linewidth=0.55)
    strong = selected['N_strong_hits'].fillna(0).to_numpy(float)
    strong_scaled = 0.55 * strong / max(float(strong.max()), 1.0)
    ax.bar(theta, strong_scaled, bottom=2.0, width=width, color=outer_color, edgecolor='white', linewidth=0.45)
    labels: list[plt.Text] = []
    label_radius = 2.78
    for angle, gene in zip(theta, selected['Gene_name'].astype(str)):
        degrees = math.degrees(angle) % 360
        rotation = upright_tangential_rotation(degrees)
        label = ax.text(angle, label_radius, gene, rotation=rotation, rotation_mode='anchor', ha='center', va='center', fontsize=7.8, fontstyle='italic', color=INK, clip_on=False)
        labels.append(label)
    ax.set_ylim(0, 3.08)
    ax.set_axis_off()
    cax = ax.inset_axes([0.34, 0.015, 0.34, 0.022])
    cbar = plt.colorbar(plt.cm.ScalarMappable(norm=norm, cmap=cmap), cax=cax, orientation='horizontal')
    cbar.set_ticks([0, vmax])
    cbar.set_ticklabels(['Low', 'High'])
    cbar.ax.tick_params(labelsize=7, length=0, pad=1)
    cbar.outline.set_linewidth(0.45)
    return labels

def draw_boxplot(ax: plt.Axes, values: np.ndarray, title: str, color: str, seed: int, common_ylim: tuple[float, float]) -> None:
    rng = np.random.default_rng(seed)
    ax.scatter(rng.normal(1, 0.045, len(values)), values, s=16, color=color, alpha=0.55, edgecolors='none', rasterized=True)
    box = ax.boxplot([values], positions=[1], widths=0.42, patch_artist=True, showfliers=False, medianprops={'color': INK, 'lw': 1.05}, boxprops={'edgecolor': color, 'lw': 0.95}, whiskerprops={'color': color, 'lw': 0.85}, capprops={'color': color, 'lw': 0.85})
    box['boxes'][0].set_facecolor('white')
    ax.set_xticks([1], [f'Williams\n(n={len(values)})'])
    ax.set_ylabel('Cosine shift (x10^3)')
    ax.set_title(title, fontsize=10.5, pad=6)
    ax.set_ylim(*common_ylim)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.grid(False)

def check_labels(fig: plt.Figure, label_groups: list[list[plt.Text]]) -> None:
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    for panel_index, labels in enumerate(label_groups, start=1):
        boxes = [label.get_window_extent(renderer=renderer).expanded(1.04, 1.12) for label in labels]
        overlaps: list[tuple[str, str]] = []
        for i in range(len(boxes)):
            for j in range(i + 1, len(boxes)):
                if boxes[i].overlaps(boxes[j]):
                    overlaps.append((labels[i].get_text(), labels[j].get_text()))
        if overlaps:
            raise RuntimeError(f'Text overlap in circular panel {panel_index}: {overlaps}')
        inverted: list[str] = []
        for label in labels:
            rotation = (label.get_rotation() + 180) % 360 - 180
            if not -90 <= rotation <= 90:
                inverted.append(label.get_text())
        if inverted:
            raise RuntimeError(f'Inverted text in circular panel {panel_index}: {inverted}')

def build_figure() -> plt.Figure:
    summary = pd.read_csv(SUMMARY_PATH)
    cell = pd.read_csv(CELL_PATH)
    summary = summary.loc[summary['cohort'].eq('Williams')].copy()
    cell = cell.loc[cell['cohort'].eq('Williams')].copy()
    validate_inputs(summary, cell)
    ko_values = cell.loc[cell['scenario'].eq(KO_SCENARIO), 'Cosine_shift'].to_numpy(float) * 1000
    oe_values = cell.loc[cell['scenario'].eq(OE_SCENARIO), 'Cosine_shift'].to_numpy(float) * 1000
    combined = np.concatenate([ko_values, oe_values])
    margin = max(1.5, 0.04 * (float(np.nanmax(combined)) - float(np.nanmin(combined))))
    common_ylim = (min(-2.0, float(np.nanmin(combined)) - margin), float(np.nanmax(combined)) + margin)
    fig = plt.figure(figsize=CANVAS_INCHES)
    gs = GridSpec(1, 4, figure=fig, width_ratios=[0.55, 1.72, 0.55, 1.72], wspace=0.06)
    ax_ko_box = fig.add_subplot(gs[0, 0])
    draw_boxplot(ax_ko_box, ko_values, 'GDF15 KO', KO_BLUE, SEED, common_ylim)
    ax_ko_circle = fig.add_subplot(gs[0, 1], projection='polar')
    ko_labels = draw_circle(ax_ko_circle, summary, KO_SCENARIO, 'Blues', KO_BLUE_DARK)
    ax_ko_circle.legend([Patch(facecolor=plt.get_cmap('Blues')(0.65)), Patch(facecolor=KO_BLUE_DARK)], ['Williams gene shift', 'N strong hits'], frameon=False, loc='lower center', bbox_to_anchor=(0.5, -0.025), fontsize=8, ncol=2)
    ax_oe_box = fig.add_subplot(gs[0, 2])
    draw_boxplot(ax_oe_box, oe_values, 'GDF15 OE', OE_RED, SEED + 1, common_ylim)
    ax_oe_circle = fig.add_subplot(gs[0, 3], projection='polar')
    oe_labels = draw_circle(ax_oe_circle, summary, OE_SCENARIO, 'Reds', OE_RED_DARK)
    ax_oe_circle.legend([Patch(facecolor=plt.get_cmap('Reds')(0.65)), Patch(facecolor=OE_RED_DARK)], ['Williams gene shift', 'N strong hits'], frameon=False, loc='lower center', bbox_to_anchor=(0.5, -0.025), fontsize=8, ncol=2)
    fig.text(0.014, 0.965, 'D', fontsize=21, ha='left', va='top')
    fig.text(0.507, 0.965, 'E', fontsize=21, ha='left', va='top')
    fig.subplots_adjust(left=0.055, right=0.985, top=0.94, bottom=0.07)
    check_labels(fig, [ko_labels, oe_labels])
    return fig

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--format', choices=['png', 'pdf', 'svg', 'all'], default='all')
    parser.add_argument('--preview', action='store_true')
    args = parser.parse_args()
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    QA_DIR.mkdir(parents=True, exist_ok=True)
    set_style()
    fig = build_figure()
    output_dir = QA_DIR if args.preview else FIG_DIR
    formats = ['png', 'pdf', 'svg'] if args.format == 'all' else [args.format]
    for fmt in formats:
        dpi = 300 if fmt == 'png' else 300
        fig.savefig(output_dir / f'{STEM}.{fmt}', dpi=dpi, facecolor='white')
    plt.close(fig)
    print(output_dir / f'{STEM}.{formats[0]}')
if __name__ == '__main__':
    main()
