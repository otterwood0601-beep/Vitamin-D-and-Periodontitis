from __future__ import annotations
import importlib.util
import math
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260906_Geneformer_GDF15_Williams\u5355\u961f\u5217_\u5168\u56fe\u7ea0\u9519\u6c47\u603b_v1')
CASES = [('main', ROOT / '\u4ee3\u7801' / 'revise_figure3_main_equal_wedges_half_inward.py', math.radians(180.0 / 23.0), 0.66, False), ('branch1', ROOT / '\u652f\u7ebf1_\u7b49\u5927\u6247\u5f62\u534a\u957f\u5411\u5185\u7f29\u5c0f\u7248' / '\u4ee3\u7801' / 'plot_figure3_branch1_equal_wedges_half_inward.py', math.radians(360.0 / 48.0), 0.66, False), ('branch2', ROOT / '\u652f\u7ebf2_\u7b49\u5927\u6247\u5f62\u534a\u957f\u5411\u5916\u7f29\u5c0f_\u4e2d\u5fc3\u7bb1\u7ebf\u56fe\u7248' / '\u4ee3\u7801' / 'plot_figure3_branch2_equal_wedges_half_outward_center_boxplots.py', math.radians(360.0 / 48.0), 1.28, True)]

def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'Cannot load {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def validate_case(name: str, script: Path, expected_width: float, expected_bottom: float, centered: bool) -> None:
    module = load_module(f'figure3_{name}', script)
    module.set_style()
    fig, selected = module.build_figure()
    try:
        counts = selected.groupby('Ring_side').size().to_dict()
        if sorted(counts.values()) != [23, 23]:
            raise AssertionError(f'{name}: expected 23 genes per side, got {counts}')
        joined = ' '.join(selected.astype(str).to_numpy().ravel())
        if 'Caetano' in joined or set(selected['cohort'].astype(str)) != {'Williams'}:
            raise AssertionError(f'{name}: cohort contamination detected')
        polar_axes = [axis for axis in fig.axes if getattr(axis, 'name', '') == 'polar']
        if len(polar_axes) != 1:
            raise AssertionError(f'{name}: expected one polar axis')
        polar = polar_axes[0]
        base_bars = [patch for patch in polar.patches if np.isclose(float(patch.get_height()), 0.62, atol=1e-10)]
        if len(base_bars) != 46:
            raise AssertionError(f'{name}: expected 46 gene sectors, got {len(base_bars)}')
        if not all((np.isclose(float(patch.get_width()), expected_width, atol=1e-10) for patch in base_bars)):
            raise AssertionError(f'{name}: gene-sector angular widths are not identical')
        if not all((np.isclose(float(patch.get_y()), expected_bottom, atol=1e-10) for patch in base_bars)):
            raise AssertionError(f'{name}: ring starts at the wrong radius')
        all_bar_widths = [float(patch.get_width()) for patch in polar.patches]
        if not all((np.isclose(width, expected_width, atol=1e-10) for width in all_bar_widths)):
            raise AssertionError(f'{name}: at least one visible bar sector has a different angular width')
        central_gdf15 = [text for text in polar.texts if text.get_text().strip() == 'GDF15']
        if centered:
            if central_gdf15:
                raise AssertionError('branch2: central GDF15 text was not removed')
            if len(polar.child_axes) != 2:
                raise AssertionError('branch2: expected two compact boxplots in the central opening')
            left, right = sorted(polar.child_axes, key=lambda axis: axis.get_position().x0)
            if left.yaxis.get_ticks_position() != 'left' or right.yaxis.get_ticks_position() != 'right':
                raise AssertionError('branch2: compact boxplot y axes are not mirrored')
        elif len(central_gdf15) != 1:
            raise AssertionError(f'{name}: expected one central GDF15 label')
        print(f'PASS {name}: Williams only; KO=23; OE=23; sector={math.degrees(expected_width):.6f} deg; ring height=0.62; inner={expected_bottom:.2f}')
    finally:
        plt.close(fig)

def main() -> None:
    for case in CASES:
        validate_case(*case)
if __name__ == '__main__':
    main()
