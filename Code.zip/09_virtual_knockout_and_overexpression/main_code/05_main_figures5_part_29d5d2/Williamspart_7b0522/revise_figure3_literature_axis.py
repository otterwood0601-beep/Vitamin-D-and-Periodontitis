from __future__ import annotations
import argparse
import math
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib import colors as mcolors
from matplotlib.gridspec import GridSpec
from matplotlib.patches import Circle, Patch, Wedge
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260906_Geneformer_GDF15_Williams\u5355\u961f\u5217_\u5168\u56fe\u7ea0\u9519\u6c47\u603b_v1')
FIG_DIR = ROOT / '\u56fe\u7247'
TABLE_DIR = ROOT / '\u6570\u636e\u8868'
QA_DIR = ROOT / 'QA_\u5750\u6807\u6838\u5bf9' / '\u56fe3_\u6587\u732e\u8f74\u805a\u7126\u6392\u7248\u4f18\u5316\u7248'
SUMMARY_PATH = TABLE_DIR / '\u56fe3_Williams_GDF15\u4e0b\u6e38\u57fa\u56e0\u8bc1\u636e\u6c47\u603b.csv'
CELL_PATH = TABLE_DIR / '\u56fe3_Williams_GDF15\u5b9a\u5411\u6270\u52a8\u9010\u7ec6\u80de.csv'
STEM_COLUMNS = '\u56fe3_GDF15\u6572\u9664\u4e0e\u8fc7\u8868\u8fbe\u5706\u5f62\u57fa\u56e0\u8bc1\u636e\u56fe_Williams\u5355\u961f\u5217_\u6587\u732e\u8f74\u805a\u7126\u6392\u7248\u4f18\u5316\u7248'
STEM_WRAP = '\u56fe3_GDF15\u6572\u9664\u4e0e\u8fc7\u8868\u8fbe\u5706\u5f62\u57fa\u56e0\u8bc1\u636e\u56fe_Williams\u5355\u961f\u5217_\u6587\u732e\u8f74\u805a\u7126_\u57fa\u56e0\u540d\u73af\u7ed5\u7248'
KO_SCENARIO = 'Periodontitis_GDF15_KO_to_Healthy'
OE_SCENARIO = 'Healthy_GDF15_OE_to_Periodontitis'
KO_BLUE = '#397FC0'
KO_BLUE_DARK = '#1F5F9B'
OE_RED = '#D9544D'
OE_RED_DARK = '#A93434'
INK = '#222222'
LEADER = '#A9B0B4'
SEED = 42
LITERATURE_GENES = ['MAPK1', 'MAPK3', 'DUSP1', 'FOS', 'JUN', 'TGFB1', 'TGFBR1', 'COL1A1', 'COL1A2', 'COL3A1', 'COL4A1', 'FN1', 'MMP1', 'MMP2', 'MMP3', 'MMP9', 'MMP14', 'TIMP1', 'TIMP2']
EVIDENCE = {'MAPK1': ('ERK1/2-MAPK core', 'GDF15 phosphorylates ERK1/2 in human fibroblasts; vitamin D regulates MAPK/AP-1 in human gingival fibroblasts', 'PMC4618626; PMID:28345770'), 'MAPK3': ('ERK1/2-MAPK core', 'GDF15 phosphorylates ERK1/2 in human fibroblasts; vitamin D regulates MAPK/AP-1 in human gingival fibroblasts', 'PMC4618626; PMID:28345770'), 'DUSP1': ('ERK1/2-MAPK feedback', 'MAPK phosphatase-1 modulates ERK1/2 signaling in human periodontal-ligament fibroblasts', 'PMID:34024253'), 'FOS': ('MAPK/AP-1 response', 'ERK1/2-dependent c-FOS response is demonstrated in periodontal fibroblasts; vitamin D regulates MAPK/AP-1 in gingival fibroblasts', 'PMID:24858180; PMID:25604255; PMID:28345770'), 'JUN': ('MAPK/AP-1 response', 'AP-1 is a measured vitamin-D-responsive MAPK output in human gingival fibroblasts', 'PMID:28345770'), 'TGFB1': ('Fibroblast profibrotic bridge', 'GDF15 and vitamin D intersect experimentally with TGF-beta-driven fibroblast activation and ECM remodeling', 'PMC9462497; PMC5544725'), 'TGFBR1': ('Fibroblast profibrotic bridge', 'GDF15-induced lung-fibroblast activation is mediated by ALK5/TGFBR1', 'PMC9462497'), 'COL1A1': ('ECM structural output', 'Assayed in GDF15-treated human fibroblasts and suppressed by vitamin D in fibroblast fibrosis models', 'PMC4618626; PMC5544725'), 'COL1A2': ('ECM structural output', 'Vitamin D suppresses TGF-beta-induced COL1A2 in human fibroblasts', 'PMC5544725; PMID:23295467'), 'COL3A1': ('ECM structural output', 'Assayed in GDF15-treated human fibroblasts and suppressed by vitamin D derivatives in human fibroblasts', 'PMC4618626; PMID:23295467'), 'COL4A1': ('ECM structural output', 'Included among ECM genes directly assayed after GDF15 treatment in human fibroblasts', 'PMC4618626'), 'FN1': ('ECM structural output', 'Vitamin D reduces TGF-beta-induced fibronectin in human fibroblasts', 'PMC5544725'), 'MMP1': ('ECM turnover output', 'Gingival-fibroblast ERK signaling controls MMP1; MMP1 was also assayed after GDF15 treatment', 'PMID:26829555; PMID:38855909; PMC4618626'), 'MMP2': ('ECM turnover output', 'Vitamin D inhibits fibroblast MMP2; gingival-fibroblast ERK signaling is linked to MMP2 production', 'PMC4165663; PMC1615859'), 'MMP3': ('ECM turnover output', 'ERK-dependent MMP3 remodeling is demonstrated in human gingival fibroblasts', 'PMID:26829555; PMC3734242; PMC1615859'), 'MMP9': ('ECM turnover output', 'Vitamin D inhibits fibroblast MMP9 and collagen degradation', 'PMC4165663'), 'MMP14': ('ECM turnover output', 'MAPK activation and MMP14 induction are demonstrated in human gingival fibroblasts', 'PMID:26829555'), 'TIMP1': ('ECM turnover restraint', 'Vitamin D restores fibroblast TIMP1 and TIMP1 was assayed after GDF15 treatment', 'PMC4165663; PMC4618626'), 'TIMP2': ('ECM turnover restraint', 'Vitamin D restores TIMP2 in human fibroblasts', 'PMC4165663')}

def set_style() -> None:
    plt.rcParams.update({'font.family': 'Arial', 'font.size': 8.5, 'axes.titlesize': 10, 'axes.labelsize': 8.5, 'xtick.labelsize': 7.5, 'ytick.labelsize': 7.5, 'axes.linewidth': 0.75, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none', 'figure.facecolor': 'white', 'axes.facecolor': 'white', 'savefig.facecolor': 'white'})

def validate_inputs(summary: pd.DataFrame, cell: pd.DataFrame) -> None:
    if set(summary['cohort'].astype(str).unique()) != {'Williams'}:
        raise ValueError('Figure 3 must contain Williams only.')
    if set(cell['cohort'].astype(str).unique()) != {'Williams'}:
        raise ValueError('Figure 3 cell data must contain Williams only.')
    joined = ' '.join(summary.astype(str).to_numpy().ravel()) + ' ' + ' '.join(cell.astype(str).to_numpy().ravel())
    if 'Caetano' in joined:
        raise ValueError('Caetano was detected in the Figure 3 input.')
    available = set(summary['Gene_name'].astype(str))
    missing = [gene for gene in LITERATURE_GENES if gene not in available]
    if missing:
        raise ValueError(f'Evidence genes missing from source table: {missing}')
    for scenario in (KO_SCENARIO, OE_SCENARIO):
        frame = summary.loc[summary['scenario'].eq(scenario)]
        duplicated = frame.loc[frame['Gene_name'].duplicated(), 'Gene_name'].tolist()
        if duplicated:
            raise ValueError(f'Duplicated genes in {scenario}: {duplicated}')

def select_genes(summary: pd.DataFrame, scenario: str) -> pd.DataFrame:
    frame = summary.loc[summary['scenario'].eq(scenario) & summary['Gene_name'].isin(LITERATURE_GENES)].copy()
    frame['plot_order'] = frame['Gene_name'].map({g: i for i, g in enumerate(LITERATURE_GENES)})
    frame = frame.sort_values('plot_order').reset_index(drop=True)
    if frame['Gene_name'].tolist() != LITERATURE_GENES:
        raise ValueError(f'Unexpected gene order or missing genes for {scenario}')
    return frame

def clean_axis(ax: plt.Axes) -> None:
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.grid(False)

def panel_letter(fig: plt.Figure, x: float, letter: str) -> None:
    fig.text(x, 0.965, letter, fontsize=17, fontweight='normal', ha='left', va='top')

def draw_boxplot(ax: plt.Axes, values: np.ndarray, color: str, title: str, seed: int, common_ylim: tuple[float, float]) -> None:
    rng = np.random.default_rng(seed)
    ax.scatter(rng.normal(1, 0.044, len(values)), values, s=10, color=color, alpha=0.58, edgecolors='none', rasterized=True, zorder=2)
    box = ax.boxplot([values], positions=[1], widths=0.44, patch_artist=True, showfliers=False, medianprops={'color': INK, 'lw': 1.0}, boxprops={'edgecolor': color, 'lw': 0.9}, whiskerprops={'color': color, 'lw': 0.8}, capprops={'color': color, 'lw': 0.8})
    box['boxes'][0].set_facecolor('white')
    ax.set_xticks([1], [f'Williams\n(n={len(values)})'])
    ax.set_ylabel('Cosine shift (x10^3)')
    ax.set_title(title, fontsize=9.5, pad=7)
    ax.set_ylim(*common_ylim)
    ax.set_xlim(0.48, 1.52)
    ax.tick_params(length=3)
    clean_axis(ax)

def _slot_labels(angles: np.ndarray, base_radius: float, max_radius: float) -> dict[int, tuple[float, float, str]]:
    records: list[tuple[int, float, float, str]] = []
    for idx, angle in enumerate(angles):
        rad = math.radians(angle)
        x = max_radius * math.cos(rad)
        y = max_radius * math.sin(rad)
        side = 'right' if x >= 0 else 'left'
        records.append((idx, x, y, side))
    slots: dict[int, tuple[float, float, str]] = {}
    for side in ('left', 'right'):
        side_rows = [record for record in records if record[3] == side]
        side_rows.sort(key=lambda record: record[2], reverse=True)
        ys = np.linspace(2.65, -2.65, len(side_rows))
        label_x = 3.18 if side == 'right' else -3.18
        for record, y_slot in zip(side_rows, ys):
            slots[record[0]] = (label_x, float(y_slot), side)
    return slots

def draw_circle(ax: plt.Axes, selected: pd.DataFrame, cmap_name: str, outer_color: str, label_style: str) -> list[plt.Text]:
    n = len(selected)
    angles = 90 - np.arange(n) * (360.0 / n)
    wedge_width = 360.0 / n * 0.92
    values = selected['Mean_token_cosine_shift'].to_numpy(float) * 1000.0
    vmax = max(float(np.quantile(values, 0.98)), 1e-06)
    norm = mcolors.Normalize(vmin=0.0, vmax=vmax)
    cmap = plt.get_cmap(cmap_name)
    inner_base = 1.06
    inner_height = 0.94
    outer_base = 2.06
    strong = selected['N_strong_hits'].fillna(0).to_numpy(float)
    strong_height = 0.62 * strong / max(float(strong.max()), 1.0)
    for angle, value, outer_h in zip(angles, values, strong_height):
        ax.add_patch(Wedge((0, 0), inner_base + inner_height, angle - wedge_width / 2, angle + wedge_width / 2, width=inner_height, facecolor=cmap(norm(value)), edgecolor='white', linewidth=0.8))
        if outer_h > 0:
            ax.add_patch(Wedge((0, 0), outer_base + outer_h, angle - wedge_width / 2, angle + wedge_width / 2, width=outer_h, facecolor=outer_color, edgecolor='white', linewidth=0.7))
        else:
            ax.plot([outer_base * math.cos(math.radians(angle))], [outer_base * math.sin(math.radians(angle))], marker='o', markersize=1.5, color=outer_color, alpha=0.55)
    ax.add_patch(Circle((0, 0), inner_base - 0.015, facecolor='white', edgecolor='none'))
    max_outer = outer_base + 0.66
    labels: list[plt.Text] = []
    if label_style == 'wrap':
        label_radius = max_outer + 0.28
        for angle, gene in zip(angles, selected['Gene_name'].astype(str)):
            rad = math.radians(angle)
            rotation = (angle - 90 + 180) % 360 - 180
            if rotation > 90:
                rotation -= 180
            elif rotation < -90:
                rotation += 180
            label = ax.text(label_radius * math.cos(rad), label_radius * math.sin(rad), gene, rotation=rotation, rotation_mode='anchor', ha='center', va='center', fontsize=8.0, fontstyle='italic', color=INK, clip_on=False)
            labels.append(label)
        ax.set_xlim(-3.5, 3.5)
        ax.set_ylim(-3.5, 3.5)
    else:
        slots = _slot_labels(angles, inner_base, max_outer)
        for idx, (angle, gene) in enumerate(zip(angles, selected['Gene_name'].astype(str))):
            rad = math.radians(angle)
            start_radius = outer_base + strong_height[idx] + 0.04
            start_x = start_radius * math.cos(rad)
            start_y = start_radius * math.sin(rad)
            label_x, label_y, side = slots[idx]
            elbow_x = 2.88 if side == 'right' else -2.88
            end_x = label_x - 0.08 if side == 'right' else label_x + 0.08
            ax.plot([start_x, elbow_x, end_x], [start_y, label_y, label_y], color=LEADER, linewidth=0.45, solid_capstyle='round', zorder=0)
            label = ax.text(label_x, label_y, gene, rotation=0, ha='left' if side == 'right' else 'right', va='center', fontsize=8.0, fontstyle='italic', color=INK, clip_on=False)
            labels.append(label)
        ax.set_xlim(-4.02, 4.02)
        ax.set_ylim(-3.3, 3.3)
    ax.set_aspect('equal', adjustable='box')
    ax.axis('off')
    cax = ax.inset_axes([0.355, -0.015, 0.29, 0.025])
    cbar = plt.colorbar(plt.cm.ScalarMappable(norm=norm, cmap=cmap), cax=cax, orientation='horizontal')
    cbar.set_ticks([0, vmax])
    cbar.set_ticklabels(['Low', 'High'])
    cbar.ax.tick_params(labelsize=5.8, length=0, pad=1)
    cbar.outline.set_linewidth(0.4)
    ax.legend([Patch(facecolor=cmap(0.67)), Patch(facecolor=outer_color)], ['Williams gene shift', 'N strong hits'], frameon=False, ncol=2, loc='lower center', bbox_to_anchor=(0.5, -0.115), fontsize=6.5, handlelength=1.6, columnspacing=1.3)
    return labels

def check_label_overlap(fig: plt.Figure, label_groups: list[list[plt.Text]]) -> None:
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    for panel_index, labels in enumerate(label_groups, start=1):
        boxes = [label.get_window_extent(renderer=renderer).expanded(1.02, 1.12) for label in labels]
        collisions: list[tuple[str, str]] = []
        for i in range(len(boxes)):
            for j in range(i + 1, len(boxes)):
                if boxes[i].overlaps(boxes[j]):
                    collisions.append((labels[i].get_text(), labels[j].get_text()))
        if collisions:
            raise RuntimeError(f'Label overlap detected in circular panel {panel_index}: {collisions}')
        inverted = []
        for label in labels:
            normalized_rotation = (label.get_rotation() + 180) % 360 - 180
            if not -90 <= normalized_rotation <= 90:
                inverted.append(label.get_text())
        if inverted:
            raise RuntimeError(f'Inverted labels detected in circular panel {panel_index}: {inverted}')

def write_evidence_table(summary: pd.DataFrame) -> None:
    rows = []
    for gene in LITERATURE_GENES:
        group, basis, source = EVIDENCE[gene]
        ko = summary.loc[summary['scenario'].eq(KO_SCENARIO) & summary['Gene_name'].eq(gene)].iloc[0]
        oe = summary.loc[summary['scenario'].eq(OE_SCENARIO) & summary['Gene_name'].eq(gene)].iloc[0]
        rows.append({'Gene': gene, 'Evidence_group': group, 'Literature_selection_basis': basis, 'Primary_source': source, 'KO_mean_token_cosine_shift': ko['Mean_token_cosine_shift'], 'KO_N_strong_hits': ko['N_strong_hits'], 'OE_mean_token_cosine_shift': oe['Mean_token_cosine_shift'], 'OE_N_strong_hits': oe['N_strong_hits'], 'Cohort': 'Williams'})
    pd.DataFrame(rows).to_csv(TABLE_DIR / '\u56fe3_\u6587\u732e\u8f74\u7b5b\u9009\u57fa\u56e0\u4e0e\u8bc1\u636e\u4f9d\u636e_Williams.csv', index=False, encoding='utf-8-sig')

def build_figure(label_style: str) -> plt.Figure:
    summary = pd.read_csv(SUMMARY_PATH)
    cell = pd.read_csv(CELL_PATH)
    summary = summary.loc[summary['cohort'].eq('Williams')].copy()
    cell = cell.loc[cell['cohort'].eq('Williams')].copy()
    validate_inputs(summary, cell)
    ko = select_genes(summary, KO_SCENARIO)
    oe = select_genes(summary, OE_SCENARIO)
    ko_values = cell.loc[cell['scenario'].eq(KO_SCENARIO), 'Cosine_shift'].to_numpy(float) * 1000.0
    oe_values = cell.loc[cell['scenario'].eq(OE_SCENARIO), 'Cosine_shift'].to_numpy(float) * 1000.0
    combined = np.concatenate([ko_values, oe_values])
    margin = max(1.5, 0.045 * (float(np.nanmax(combined)) - float(np.nanmin(combined))))
    common_ylim = (min(-2.0, float(np.nanmin(combined)) - margin), float(np.nanmax(combined)) + margin)
    figsize = (16.8, 7.8) if label_style == 'wrap' else (18.0, 8.0)
    fig = plt.figure(figsize=figsize)
    gs = GridSpec(1, 4, figure=fig, width_ratios=[0.62, 3.45, 0.62, 3.45], wspace=0.045)
    ax_ko_box = fig.add_subplot(gs[0, 0])
    draw_boxplot(ax_ko_box, ko_values, KO_BLUE, 'GDF15 KO', SEED, common_ylim)
    ax_ko_circle = fig.add_subplot(gs[0, 1])
    ko_labels = draw_circle(ax_ko_circle, ko, 'Blues', KO_BLUE_DARK, label_style)
    ax_oe_box = fig.add_subplot(gs[0, 2])
    draw_boxplot(ax_oe_box, oe_values, OE_RED, 'GDF15 OE', SEED + 1, common_ylim)
    ax_oe_circle = fig.add_subplot(gs[0, 3])
    oe_labels = draw_circle(ax_oe_circle, oe, 'Reds', OE_RED_DARK, label_style)
    panel_letter(fig, 0.012, 'D')
    panel_letter(fig, 0.505, 'E')
    fig.subplots_adjust(left=0.055, right=0.992, top=0.925, bottom=0.155)
    check_label_overlap(fig, [ko_labels, oe_labels])
    write_evidence_table(summary)
    return fig

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--format', choices=['png', 'pdf', 'svg', 'all'], default='all')
    parser.add_argument('--preview', action='store_true', help='Save PNG to the QA folder instead of the final image folder.')
    parser.add_argument('--label-style', choices=['wrap', 'columns'], default='wrap')
    args = parser.parse_args()
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    TABLE_DIR.mkdir(parents=True, exist_ok=True)
    QA_DIR.mkdir(parents=True, exist_ok=True)
    set_style()
    fig = build_figure(args.label_style)
    target_dir = QA_DIR if args.preview else FIG_DIR
    stem = STEM_WRAP if args.label_style == 'wrap' else STEM_COLUMNS
    formats = ['png', 'pdf', 'svg'] if args.format == 'all' else [args.format]
    for fmt in formats:
        dpi = 420 if fmt == 'png' else 300
        fig.savefig(target_dir / f'{stem}.{fmt}', dpi=dpi, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    print(target_dir / f'{stem}.{formats[0]}')
if __name__ == '__main__':
    main()
