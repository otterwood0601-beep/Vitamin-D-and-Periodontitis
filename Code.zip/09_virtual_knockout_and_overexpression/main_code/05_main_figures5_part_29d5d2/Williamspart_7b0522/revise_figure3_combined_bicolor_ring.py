from __future__ import annotations
import argparse
import math
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib import colors as mcolors
from matplotlib.gridspec import GridSpec
from matplotlib.patches import Patch
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260906_Geneformer_GDF15_Williams\u5355\u961f\u5217_\u5168\u56fe\u7ea0\u9519\u6c47\u603b_v1')
FIG_DIR = ROOT / '\u56fe\u7247'
TABLE_DIR = ROOT / '\u6570\u636e\u8868'
QA_DIR = ROOT / 'QA_\u5750\u6807\u6838\u5bf9' / '\u56fe3_\u5de6\u84dd\u53f3\u7ea2\u5408\u5e76\u5706\u73af\u7248'
SUMMARY_PATH = TABLE_DIR / '\u56fe3_Williams_GDF15\u4e0b\u6e38\u57fa\u56e0\u8bc1\u636e\u6c47\u603b.csv'
CELL_PATH = TABLE_DIR / '\u56fe3_Williams_GDF15\u5b9a\u5411\u6270\u52a8\u9010\u7ec6\u80de.csv'
STEM = '\u56fe3_GDF15\u6572\u9664\u4e0e\u8fc7\u8868\u8fbe\u5408\u5e76\u5706\u73af\u57fa\u56e0\u8bc1\u636e\u56fe_Williams\u5355\u961f\u5217_MAPK-ERK\u8f74\u805a\u7126\u7248'
KO_SCENARIO = 'Periodontitis_GDF15_KO_to_Healthy'
OE_SCENARIO = 'Healthy_GDF15_OE_to_Periodontitis'
KO_BLUE = '#397FC0'
KO_BLUE_DARK = '#1F5F9B'
OE_RED = '#D9544D'
OE_RED_DARK = '#A93434'
INK = '#222222'
SEED = 42
GDF15_BRIDGE_GENES = {'TGFB1', 'TGFBR1', 'TGFBR2'}
MIN_GENE_CELLS = 3

def set_style() -> None:
    plt.rcParams.update({'font.family': 'Arial', 'font.size': 9, 'axes.titlesize': 10, 'axes.labelsize': 9, 'xtick.labelsize': 8, 'ytick.labelsize': 8, 'axes.linewidth': 0.8, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none', 'figure.facecolor': 'white', 'axes.facecolor': 'white', 'savefig.facecolor': 'white'})

def validate_inputs(summary: pd.DataFrame, cell: pd.DataFrame) -> None:
    if set(summary['cohort'].astype(str).unique()) != {'Williams'}:
        raise ValueError('Figure 3 summary must contain Williams only.')
    if set(cell['cohort'].astype(str).unique()) != {'Williams'}:
        raise ValueError('Figure 3 cell data must contain Williams only.')
    joined = ' '.join(summary.astype(str).to_numpy().ravel()) + ' ' + ' '.join(cell.astype(str).to_numpy().ravel())
    if 'Caetano' in joined:
        raise ValueError('Caetano was detected in the Figure 3 input.')

def select_axis_genes(summary: pd.DataFrame, scenario: str, side: str) -> pd.DataFrame:
    frame = summary.loc[summary['scenario'].eq(scenario) & summary['cohort'].eq('Williams')].copy()
    related = frame['Priority_class'].eq('MAPK-response') | frame['Gene_name'].isin(GDF15_BRIDGE_GENES)
    frame = frame.loc[related & (pd.to_numeric(frame['N_cells'], errors='coerce') >= MIN_GENE_CELLS)].copy()
    frame = frame.sort_values(['Mean_token_cosine_shift', 'Gene_name'], ascending=[False, True]).reset_index(drop=True)
    frame['Ring_side'] = side
    frame['Selection_rule'] = 'MAPK-response or GDF15/TGF bridge; N_cells >= 3'
    if frame.empty:
        raise ValueError(f'No eligible genes for {scenario}')
    return frame

def upright_tangential_rotation(angle_degrees: float) -> float:
    rotation = (angle_degrees - 90 + 180) % 360 - 180
    if rotation > 90:
        rotation -= 180
    elif rotation < -90:
        rotation += 180
    return rotation

def draw_half_ring(ax: plt.Axes, selected: pd.DataFrame, angles_degrees: np.ndarray, cmap_name: str, outer_color: str) -> tuple[list[plt.Text], mcolors.Normalize]:
    n = len(selected)
    if len(angles_degrees) != n:
        raise ValueError('The angle vector must match the gene count.')
    spacing = abs(float(angles_degrees[1] - angles_degrees[0])) if n > 1 else 160.0
    width = math.radians(spacing * 0.88)
    theta = np.radians(angles_degrees)
    values = selected['Mean_token_cosine_shift'].to_numpy(float) * 1000.0
    vmax = max(float(np.quantile(values, 0.98)), 1e-06)
    norm = mcolors.Normalize(0, vmax)
    cmap = plt.get_cmap(cmap_name)
    ax.bar(theta, np.repeat(0.88, n), bottom=1.03, width=width, color=[cmap(norm(value)) for value in values], edgecolor='white', linewidth=0.55, align='center', zorder=2)
    strong = selected['N_strong_hits'].fillna(0).to_numpy(float)
    strong_scaled = 0.56 * strong / max(2.0, float(strong.max()), 1.0)
    ax.bar(theta, strong_scaled, bottom=2.01, width=width, color=outer_color, edgecolor='white', linewidth=0.45, align='center', zorder=2)
    labels: list[plt.Text] = []
    label_radius = 3.06
    for angle, gene in zip(angles_degrees, selected['Gene_name'].astype(str)):
        rotation = upright_tangential_rotation(float(angle) % 360)
        label = ax.text(math.radians(angle), label_radius, gene, rotation=rotation, rotation_mode='anchor', ha='center', va='center', fontsize=7.0, fontstyle='italic', color=INK, clip_on=False, zorder=4)
        labels.append(label)
    return (labels, norm)

def draw_boxplot(ax: plt.Axes, values: np.ndarray, color: str, title: str, seed: int, common_ylim: tuple[float, float], side: str) -> None:
    rng = np.random.default_rng(seed)
    ax.scatter(rng.normal(1, 0.045, len(values)), values, s=12, color=color, alpha=0.58, edgecolors='none', rasterized=True, zorder=2)
    box = ax.boxplot([values], positions=[1], widths=0.43, patch_artist=True, showfliers=False, medianprops={'color': INK, 'lw': 1.0}, boxprops={'edgecolor': color, 'lw': 0.9}, whiskerprops={'color': color, 'lw': 0.8}, capprops={'color': color, 'lw': 0.8})
    box['boxes'][0].set_facecolor('white')
    ax.set_xticks([1], [f'Williams\n(n={len(values)})'])
    ax.set_ylabel('Cosine shift (x10^3)')
    ax.set_title(title, fontsize=9.5, pad=6)
    ax.set_xlim(0.48, 1.52)
    ax.set_ylim(*common_ylim)
    ax.spines['top'].set_visible(False)
    ax.grid(False)
    if side == 'left':
        ax.spines['right'].set_visible(False)
        ax.yaxis.tick_left()
        ax.yaxis.set_label_position('left')
    else:
        ax.spines['left'].set_visible(False)
        ax.spines['right'].set_visible(True)
        ax.yaxis.tick_right()
        ax.yaxis.set_label_position('right')

def check_label_layout(fig: plt.Figure, labels: list[plt.Text]) -> None:
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    boxes = [label.get_window_extent(renderer=renderer).expanded(1.04, 1.14) for label in labels]
    overlaps: list[tuple[str, str]] = []
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            if boxes[i].overlaps(boxes[j]):
                overlaps.append((labels[i].get_text(), labels[j].get_text()))
    if overlaps:
        raise RuntimeError(f'Circular-label overlap detected: {overlaps}')
    inverted: list[str] = []
    for label in labels:
        rotation = (label.get_rotation() + 180) % 360 - 180
        if not -90 <= rotation <= 90:
            inverted.append(label.get_text())
    if inverted:
        raise RuntimeError(f'Inverted circular labels detected: {inverted}')

def build_figure() -> tuple[plt.Figure, pd.DataFrame]:
    summary = pd.read_csv(SUMMARY_PATH)
    cell = pd.read_csv(CELL_PATH)
    summary = summary.loc[summary['cohort'].eq('Williams')].copy()
    cell = cell.loc[cell['cohort'].eq('Williams')].copy()
    validate_inputs(summary, cell)
    ko = select_axis_genes(summary, KO_SCENARIO, 'Left / KO / blue')
    oe = select_axis_genes(summary, OE_SCENARIO, 'Right / OE / red')
    ko_angles = np.linspace(96, 264, len(ko))
    oe_angles = np.linspace(84, -84, len(oe))
    ko_values = cell.loc[cell['scenario'].eq(KO_SCENARIO), 'Cosine_shift'].to_numpy(float) * 1000.0
    oe_values = cell.loc[cell['scenario'].eq(OE_SCENARIO), 'Cosine_shift'].to_numpy(float) * 1000.0
    combined = np.concatenate([ko_values, oe_values])
    margin = max(1.5, 0.045 * (float(np.nanmax(combined)) - float(np.nanmin(combined))))
    common_ylim = (min(-2.0, float(np.nanmin(combined)) - margin), float(np.nanmax(combined)) + margin)
    fig = plt.figure(figsize=(19.5, 10.8))
    gs = GridSpec(1, 3, figure=fig, width_ratios=[0.82, 4.5, 0.82], wspace=0.035)
    ax_left = fig.add_subplot(gs[0, 0])
    draw_boxplot(ax_left, ko_values, KO_BLUE, 'GDF15 KO', SEED, common_ylim, 'left')
    ax_ring = fig.add_subplot(gs[0, 1], projection='polar')
    ko_labels, ko_norm = draw_half_ring(ax_ring, ko, ko_angles, 'Blues', KO_BLUE_DARK)
    oe_labels, oe_norm = draw_half_ring(ax_ring, oe, oe_angles, 'Reds', OE_RED_DARK)
    ax_ring.set_ylim(0, 3.36)
    ax_ring.set_axis_off()
    ax_ring.text(0.5, 0.515, 'GDF15', transform=ax_ring.transAxes, ha='center', va='center', fontsize=13, fontweight='bold', color=INK)
    ko_cax = ax_ring.inset_axes([0.19, 0.018, 0.245, 0.02])
    ko_cbar = plt.colorbar(plt.cm.ScalarMappable(norm=ko_norm, cmap=plt.get_cmap('Blues')), cax=ko_cax, orientation='horizontal')
    ko_cbar.set_ticks([0, ko_norm.vmax])
    ko_cbar.set_ticklabels(['Low', 'High'])
    ko_cbar.ax.tick_params(labelsize=6.2, length=0, pad=1)
    ko_cbar.outline.set_linewidth(0.4)
    oe_cax = ax_ring.inset_axes([0.565, 0.018, 0.245, 0.02])
    oe_cbar = plt.colorbar(plt.cm.ScalarMappable(norm=oe_norm, cmap=plt.get_cmap('Reds')), cax=oe_cax, orientation='horizontal')
    oe_cbar.set_ticks([0, oe_norm.vmax])
    oe_cbar.set_ticklabels(['Low', 'High'])
    oe_cbar.ax.tick_params(labelsize=6.2, length=0, pad=1)
    oe_cbar.outline.set_linewidth(0.4)
    ax_ring.legend([Patch(facecolor=plt.get_cmap('Blues')(0.65)), Patch(facecolor=KO_BLUE_DARK), Patch(facecolor=plt.get_cmap('Reds')(0.65)), Patch(facecolor=OE_RED_DARK)], ['KO gene shift', 'KO N strong hits', 'OE gene shift', 'OE N strong hits'], frameon=False, loc='lower center', bbox_to_anchor=(0.5, -0.055), ncol=4, fontsize=6.8, handlelength=1.5, columnspacing=1.2)
    ax_right = fig.add_subplot(gs[0, 2])
    draw_boxplot(ax_right, oe_values, OE_RED, 'GDF15 OE', SEED + 1, common_ylim, 'right')
    fig.text(0.015, 0.965, 'D', fontsize=18, ha='left', va='top')
    fig.text(0.958, 0.965, 'E', fontsize=18, ha='right', va='top')
    fig.subplots_adjust(left=0.055, right=0.945, top=0.93, bottom=0.12)
    check_label_layout(fig, ko_labels + oe_labels)
    selected = pd.concat([ko, oe], ignore_index=True)
    return (fig, selected)

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--format', choices=['png', 'pdf', 'svg', 'all'], default='all')
    parser.add_argument('--preview', action='store_true')
    args = parser.parse_args()
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    TABLE_DIR.mkdir(parents=True, exist_ok=True)
    QA_DIR.mkdir(parents=True, exist_ok=True)
    set_style()
    fig, selected = build_figure()
    selected.to_csv(TABLE_DIR / '\u56fe3_\u5408\u5e76\u5706\u73af_MAPK-ERK-GDF15\u8f74\u7b5b\u9009\u57fa\u56e0_Williams.csv', index=False, encoding='utf-8-sig')
    output_dir = QA_DIR if args.preview else FIG_DIR
    formats = ['png', 'pdf', 'svg'] if args.format == 'all' else [args.format]
    for fmt in formats:
        dpi = 360 if fmt == 'png' else 300
        fig.savefig(output_dir / f'{STEM}.{fmt}', dpi=dpi, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    print(f"KO genes: {sum(selected['Ring_side'].eq('Left / KO / blue'))}")
    print(f"OE genes: {sum(selected['Ring_side'].eq('Right / OE / red'))}")
    print(output_dir / f'{STEM}.{formats[0]}')
if __name__ == '__main__':
    main()
