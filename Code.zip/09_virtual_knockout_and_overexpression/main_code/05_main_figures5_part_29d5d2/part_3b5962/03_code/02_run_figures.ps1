[CmdletBinding()]
param(
    [string]$InputRoot = "E:\$([char]0x8840)$([char]0x6E05)$([char]0x7EF4)$([char]0x751F)$([char]0x7D20)\$([char]0x4EE3)$([char]0x7801)\$([char]0x8FD0)$([char]0x884C)$([char]0x8F93)$([char]0x51FA)\20260821_GDF15$([char]0x865A)$([char]0x62DF)$([char]0x6572)$([char]0x9664)_scTenifoldKnk_$([char]0x9996)$([char]0x7248)",
    [string]$OutputRoot = (Split-Path -Parent $PSScriptRoot),
    [string]$Rscript = 'C:\Program Files\R\R-4.5.3\bin\Rscript.exe'
)

$ErrorActionPreference = 'Stop'

$inputResolved = (Resolve-Path -LiteralPath $InputRoot).Path
$outputResolved = (Resolve-Path -LiteralPath $OutputRoot).Path
$figureScript = Join-Path $PSScriptRoot '01_make_GDF15_vKO_figures.R'

if (-not (Test-Path -LiteralPath $Rscript -PathType Leaf)) {
    throw "Rscript not found: $Rscript"
}
if (-not (Test-Path -LiteralPath $figureScript -PathType Leaf)) {
    throw "Figure script not found: $figureScript"
}

$existingMappings = @(subst.exe)
if ($existingMappings -match '^V:\\:') {
    throw 'Drive V: is already in use. Remove or change that mapping before rerunning.'
}
if ($existingMappings -match '^Y:\\:') {
    throw 'Drive Y: is already in use. Remove or change that mapping before rerunning.'
}

$mappedV = $false
$mappedY = $false
$oldInputEnv = $env:GDF15_VKO_INPUT_ROOT
$oldOutputEnv = $env:GDF15_VKO_OUTPUT_ROOT

try {
    & subst.exe V: $inputResolved
    if ($LASTEXITCODE -ne 0) { throw 'Unable to map V: to the input directory.' }
    $mappedV = $true

    & subst.exe Y: $outputResolved
    if ($LASTEXITCODE -ne 0) { throw 'Unable to map Y: to the output directory.' }
    $mappedY = $true

    $env:GDF15_VKO_INPUT_ROOT = 'V:/'
    $env:GDF15_VKO_OUTPUT_ROOT = 'Y:/'

    & $Rscript $figureScript
    if ($LASTEXITCODE -ne 0) {
        throw "Figure generation failed with exit code $LASTEXITCODE."
    }
}
finally {
    $env:GDF15_VKO_INPUT_ROOT = $oldInputEnv
    $env:GDF15_VKO_OUTPUT_ROOT = $oldOutputEnv
    if ($mappedY) { & subst.exe Y: /D | Out-Null }
    if ($mappedV) { & subst.exe V: /D | Out-Null }
}
