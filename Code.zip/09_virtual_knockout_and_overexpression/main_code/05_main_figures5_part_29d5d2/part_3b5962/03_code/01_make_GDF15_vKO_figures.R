options(stringsAsFactors = FALSE, scipen = 999)

local_lib <- "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_enrichment"
if (dir.exists(local_lib)) {
  .libPaths(c(local_lib, .libPaths()))
}

suppressPackageStartupMessages({
  library(Matrix)
  library(ggplot2)
  library(ggrepel)
  library(patchwork)
  library(scales)
  library(svglite)
})

input_root <- Sys.getenv("GDF15_VKO_INPUT_ROOT", unset = "")
output_root <- Sys.getenv("GDF15_VKO_OUTPUT_ROOT", unset = "")
if (!nzchar(input_root) || !nzchar(output_root)) {
  stop("Set GDF15_VKO_INPUT_ROOT and GDF15_VKO_OUTPUT_ROOT before running.")
}
figure_dir <- file.path(output_root, "01_figures")
source_dir <- file.path(output_root, "02_source_data")
qa_dir <- file.path(output_root, "04_QA")
png_tmp_dir <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/_\u4e34\u65f6\u8fd0\u884c\u533a/codex_tmp/gdf15_vko_20260824_png"

dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(qa_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(png_tmp_dir, recursive = TRUE, showWarnings = FALSE)

ink <- "#292827"
muted_ink <- "#5B5A58"
grid <- "#D9DEDF"
teal <- "#4F9B9D"
teal_dark <- "#2F6F73"
teal_light <- "#DCEDEE"
gold <- "#C4953A"
burgundy <- "#6B3030"
burgundy_mid <- "#9B5555"
burgundy_light <- "#C98D8D"
burgundy_xlight <- "#EADCDC"
neutral <- "#D8D8D6"
neutral_light <- "#F6F6F4"

base_family <- "Arial"

theme_research <- function(base_size = 12) {
  theme_minimal(base_size = base_size, base_family = base_family) +
    theme(
      plot.background = element_rect(fill = "white", colour = NA),
      panel.background = element_rect(fill = "white", colour = NA),
      panel.grid.minor = element_blank(),
      panel.grid.major = element_line(colour = grid, linewidth = 0.35),
      axis.line = element_line(colour = ink, linewidth = 0.45),
      axis.ticks = element_line(colour = ink, linewidth = 0.4),
      axis.text = element_text(colour = ink),
      axis.title = element_text(colour = ink, face = "bold"),
      plot.title = element_text(colour = ink, face = "bold", size = rel(1.35), hjust = 0),
      plot.subtitle = element_text(colour = muted_ink, size = rel(0.9), margin = margin(b = 8)),
      plot.caption = element_text(colour = muted_ink, size = rel(0.76), hjust = 0, margin = margin(t = 8)),
      legend.title = element_text(colour = ink, face = "bold"),
      legend.text = element_text(colour = ink),
      legend.key = element_rect(fill = "white", colour = NA),
      strip.text = element_text(colour = ink, face = "bold"),
      strip.background = element_rect(fill = neutral_light, colour = grid, linewidth = 0.4)
    )
}

write_csv_utf8 <- function(x, path) {
  write.csv(x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8")
}

save_plot_set <- function(plot, stem, width, height) {
  pdf_path <- file.path(figure_dir, paste0(stem, ".pdf"))
  svg_path <- file.path(figure_dir, paste0(stem, ".svg"))
  png_path <- file.path(figure_dir, paste0(stem, ".png"))
  png_temp_path <- file.path(png_tmp_dir, paste0(stem, ".png"))

  ggsave(
    pdf_path, plot = plot, width = width, height = height, units = "in",
    device = cairo_pdf, bg = "white"
  )
  ggsave(
    svg_path, plot = plot, width = width, height = height, units = "in",
    device = svglite::svglite, bg = "white"
  )
  ggsave(
    png_temp_path, plot = plot, width = width, height = height, units = "in",
    device = ragg::agg_png, dpi = 320, bg = "white"
  )
  copied <- file.copy(png_temp_path, png_path, overwrite = TRUE)
  if (!isTRUE(copied)) stop("Unable to copy rendered PNG to output path: ", png_path)
  unlink(png_temp_path)

  data.frame(
    figure = stem,
    format = c("PDF", "SVG", "PNG"),
    path = c(pdf_path, svg_path, png_path),
    width_in = width,
    height_in = height,
    stringsAsFactors = FALSE
  )
}

parse_ratio <- function(x) {
  vapply(strsplit(as.character(x), "/", fixed = TRUE), function(parts) {
    if (length(parts) != 2L) return(NA_real_)
    as.numeric(parts[1]) / as.numeric(parts[2])
  }, numeric(1))
}

wrap_label <- function(x, width = 42) {
  vapply(x, function(one) paste(strwrap(one, width = width), collapse = "\n"), character(1))
}

result_path <- file.path(input_root, "02_virtual_ko", "scTenifoldKnk_GDF15_full_result.rds")
diff_path <- file.path(input_root, "02_virtual_ko", "GDF15_differential_regulation_all_genes.csv")

stopifnot(file.exists(result_path), file.exists(diff_path))
result <- readRDS(result_path)
WT <- as.matrix(result$tensorNetworks$WT)
diff_reg <- read.csv(diff_path, check.names = FALSE, fileEncoding = "UTF-8")

required_diff_cols <- c("gene", "distance", "Z", "FC", "p.value", "p.adj")
stopifnot(all(required_diff_cols %in% colnames(diff_reg)))
stopifnot("GDF15" %in% rownames(WT), "GDF15" %in% colnames(WT))

for (nm in c("distance", "Z", "FC", "p.value", "p.adj")) {
  diff_reg[[nm]] <- as.numeric(diff_reg[[nm]])
}

top_directed_edges <- function(values, direction, n = 10L) {
  gene_names <- names(values)
  d <- data.frame(
    gene = gene_names,
    weight = as.numeric(values),
    abs_weight = abs(as.numeric(values)),
    stringsAsFactors = FALSE
  )
  d <- subset(d, gene != "GDF15" & is.finite(abs_weight) & abs_weight > 0)
  d <- d[order(-d$abs_weight, d$gene), , drop = FALSE]
  d <- head(d, n)
  d$direction <- direction
  d$rank_within_direction <- seq_len(nrow(d))
  d
}

out_values <- WT["GDF15", ]
in_values <- WT[, "GDF15"]

out_edges <- top_directed_edges(out_values, "GDF15 to gene", 10L)
in_edges <- top_directed_edges(in_values, "Gene to GDF15", 10L)
network_edges <- rbind(out_edges, in_edges)
network_edges$sign <- ifelse(network_edges$weight >= 0, "Positive weight", "Negative weight")
network_edges$from <- ifelse(network_edges$direction == "GDF15 to gene", "GDF15", network_edges$gene)
network_edges$to <- ifelse(network_edges$direction == "GDF15 to gene", network_edges$gene, "GDF15")

outer_genes <- unique(network_edges$gene)
node_importance <- aggregate(abs_weight ~ gene, network_edges, max)
node_importance <- node_importance[order(-node_importance$abs_weight, node_importance$gene), ]
node_importance$angle <- pi / 2 - 2 * pi * (seq_len(nrow(node_importance)) - 1) / nrow(node_importance)
node_importance$x <- cos(node_importance$angle)
node_importance$y <- sin(node_importance$angle)
node_importance$label_x <- 1.20 * node_importance$x
node_importance$label_y <- 1.20 * node_importance$y
node_importance$hjust <- ifelse(
  node_importance$label_x > 0.16, 0,
  ifelse(node_importance$label_x < -0.16, 1, 0.5)
)
node_importance$edge_roles <- vapply(node_importance$gene, function(g) {
  roles <- unique(network_edges$direction[network_edges$gene == g])
  if (length(roles) == 2L) "Incoming and outgoing" else roles
}, character(1))

coord_lookup <- setNames(
  split(node_importance[, c("x", "y")], node_importance$gene),
  node_importance$gene
)
network_edges$outer_x <- vapply(network_edges$gene, function(g) coord_lookup[[g]]$x, numeric(1))
network_edges$outer_y <- vapply(network_edges$gene, function(g) coord_lookup[[g]]$y, numeric(1))

network_edges$x <- ifelse(network_edges$direction == "GDF15 to gene", 0.12 * network_edges$outer_x, 0.86 * network_edges$outer_x)
network_edges$y <- ifelse(network_edges$direction == "GDF15 to gene", 0.12 * network_edges$outer_y, 0.86 * network_edges$outer_y)
network_edges$xend <- ifelse(network_edges$direction == "GDF15 to gene", 0.86 * network_edges$outer_x, 0.12 * network_edges$outer_x)
network_edges$yend <- ifelse(network_edges$direction == "GDF15 to gene", 0.86 * network_edges$outer_y, 0.12 * network_edges$outer_y)

network_nodes <- rbind(
  data.frame(
    gene = "GDF15", abs_weight = max(network_edges$abs_weight) * 1.30,
    angle = NA_real_, x = 0, y = 0, label_x = 0, label_y = 0,
    hjust = 0.5, edge_roles = "Knockout target", stringsAsFactors = FALSE
  ),
  node_importance
)

write_csv_utf8(network_edges, file.path(source_dir, "Figure1_GDF15_centered_network_edges.csv"))
write_csv_utf8(network_nodes, file.path(source_dir, "Figure1_GDF15_centered_network_nodes.csv"))

p_network <- ggplot() +
  geom_curve(
    data = subset(network_edges, direction == "GDF15 to gene"),
    aes(x = x, y = y, xend = xend, yend = yend, linewidth = abs_weight,
        colour = direction, linetype = sign),
    curvature = 0.13,
    arrow = grid::arrow(length = grid::unit(2.6, "mm"), type = "closed"),
    lineend = "round", alpha = 0.88
  ) +
  geom_curve(
    data = subset(network_edges, direction == "Gene to GDF15"),
    aes(x = x, y = y, xend = xend, yend = yend, linewidth = abs_weight,
        colour = direction, linetype = sign),
    curvature = -0.13,
    arrow = grid::arrow(length = grid::unit(2.6, "mm"), type = "closed"),
    lineend = "round", alpha = 0.88
  ) +
  geom_point(
    data = node_importance,
    aes(x = x, y = y, size = abs_weight),
    shape = 21, fill = "white", colour = ink, stroke = 0.8
  ) +
  geom_point(
    aes(x = 0, y = 0),
    shape = 21, size = 15.5, fill = burgundy, colour = ink, stroke = 1.0
  ) +
  geom_text(
    data = node_importance,
    mapping = aes(x = label_x, y = label_y, label = gene, hjust = hjust),
    family = base_family, colour = ink, fontface = "bold", size = 4.0
  ) +
  annotate(
    "text", x = 0, y = 0, label = "GDF15", family = base_family,
    colour = "white", fontface = "bold", size = 4.1
  ) +
  scale_colour_manual(
    values = c("GDF15 to gene" = teal_dark, "Gene to GDF15" = gold),
    breaks = c("GDF15 to gene", "Gene to GDF15"),
    name = "Inferred direction"
  ) +
  scale_linetype_manual(
    values = c("Positive weight" = "solid", "Negative weight" = "22"),
    name = "Weight sign"
  ) +
  scale_linewidth_continuous(
    range = c(0.45, 2.5), name = "Absolute weight",
    labels = label_number(accuracy = 0.0001)
  ) +
  scale_size_continuous(range = c(4.8, 9.0), guide = "none") +
  coord_fixed(xlim = c(-1.48, 1.48), ylim = c(-1.44, 1.46), clip = "off") +
  labs(
    title = "GDF15-centered regulatory network",
    subtitle = "Top 10 outgoing and top 10 incoming edges in the inferred wild-type network",
    caption = paste0(
      "Arrowheads show inferred direction; edge width shows absolute network weight. ",
      "\nModel-derived wild-type network; not a validated physical-interaction map."
    )
  ) +
  theme_void(base_family = base_family, base_size = 12) +
  theme(
    plot.background = element_rect(fill = "white", colour = NA),
    plot.title = element_text(colour = ink, face = "bold", size = 20, hjust = 0),
    plot.subtitle = element_text(colour = muted_ink, size = 11.5, margin = margin(b = 9)),
    plot.caption = element_text(colour = muted_ink, size = 9.2, hjust = 0, margin = margin(t = 10)),
    plot.margin = margin(18, 30, 18, 30),
    legend.position = "bottom",
    legend.box = "vertical",
    legend.title = element_text(colour = ink, face = "bold", size = 10),
    legend.text = element_text(colour = ink, size = 9),
    legend.key.width = grid::unit(1.3, "cm")
  ) +
  guides(
    colour = guide_legend(order = 1, override.aes = list(linewidth = 1.5, linetype = "solid")),
    linetype = guide_legend(order = 2, override.aes = list(colour = ink, linewidth = 1.2)),
    linewidth = guide_legend(order = 3, override.aes = list(colour = ink))
  )

enrichment_files <- c(
  BP = file.path(input_root, "03_enrichment", "GO_BP_all_terms.csv"),
  CC = file.path(input_root, "03_enrichment", "GO_CC_all_terms.csv"),
  MF = file.path(input_root, "03_enrichment", "GO_MF_all_terms.csv"),
  KEGG = file.path(input_root, "03_enrichment", "KEGG_all_terms.csv")
)

category_titles <- c(
  BP = "GO Biological Process",
  CC = "GO Cellular Component",
  MF = "GO Molecular Function",
  KEGG = "KEGG pathways"
)

enrichment_top <- do.call(rbind, lapply(names(enrichment_files), function(category) {
  path <- enrichment_files[[category]]
  stopifnot(file.exists(path))
  d <- read.csv(path, check.names = FALSE, fileEncoding = "UTF-8")
  required <- c("ID", "Description", "GeneRatio", "Count", "pvalue", "p.adjust")
  stopifnot(all(required %in% colnames(d)))
  d$pvalue <- as.numeric(d$pvalue)
  d$p.adjust <- as.numeric(d$p.adjust)
  d$Count <- as.numeric(d$Count)
  d$GeneRatioNumeric <- parse_ratio(d$GeneRatio)
  d <- d[is.finite(d$pvalue) & d$pvalue > 0 & is.finite(d$GeneRatioNumeric), , drop = FALSE]
  d <- d[order(d$pvalue, d$p.adjust, -d$Count, d$Description), , drop = FALSE]
  d <- head(d, 10L)
  d$Category <- category
  d$CategoryTitle <- unname(category_titles[category])
  d$rank_raw_p <- seq_len(nrow(d))
  d$neg_log10_raw_p <- -log10(d$pvalue)
  d$raw_p_bin <- ifelse(
    d$pvalue < 0.001, "< 0.001",
    ifelse(d$pvalue < 0.01, "0.001 to <0.01",
      ifelse(d$pvalue < 0.05, "0.01 to <0.05", ">= 0.05")
    )
  )
  d$raw_p_bin <- factor(
    d$raw_p_bin,
    levels = c("< 0.001", "0.001 to <0.01", "0.01 to <0.05", ">= 0.05")
  )
  d$DescriptionWrapped <- wrap_label(d$Description, width = ifelse(category == "KEGG", 36, 42))
  d
}))
rownames(enrichment_top) <- NULL

write_csv_utf8(enrichment_top, file.path(source_dir, "Figure2_GO_BP_CC_MF_KEGG_top10_rawP_source.csv"))

count_limits <- range(enrichment_top$Count, na.rm = TRUE)
count_breaks <- pretty(count_limits, n = 4)
count_breaks <- count_breaks[count_breaks >= count_limits[1] & count_breaks <= count_limits[2]]

p_palette <- c(
  "< 0.001" = burgundy,
  "0.001 to <0.01" = burgundy_mid,
  "0.01 to <0.05" = burgundy_light,
  ">= 0.05" = burgundy_xlight
)

make_bubble_panel <- function(category) {
  d <- enrichment_top[enrichment_top$Category == category, , drop = FALSE]
  d$Term <- factor(d$DescriptionWrapped, levels = rev(d$DescriptionWrapped))

  ggplot(d, aes(x = GeneRatioNumeric, y = Term)) +
    geom_point(
      aes(size = Count, fill = raw_p_bin),
      shape = 21, colour = ink, stroke = 0.55, alpha = 0.96
    ) +
    scale_x_continuous(
      labels = label_percent(accuracy = 1),
      expand = expansion(mult = c(0.03, 0.12))
    ) +
    scale_size_continuous(
      range = c(3.2, 9.0), limits = count_limits, breaks = count_breaks,
      name = "Gene count"
    ) +
    scale_fill_manual(values = p_palette, drop = FALSE, name = "Raw P") +
    labs(
      title = unname(category_titles[category]),
      subtitle = sprintf("Top %d terms ranked by raw P", nrow(d)),
      x = "Gene ratio",
      y = NULL
    ) +
    theme_research(11.5) +
    theme(
      panel.grid.major.y = element_blank(),
      axis.text.y = element_text(size = 9.0, lineheight = 0.92),
      plot.title = element_text(size = 15),
      plot.subtitle = element_text(size = 9.5),
      legend.position = "bottom",
      plot.margin = margin(8, 16, 8, 10)
    ) +
    guides(
      fill = guide_legend(order = 1, nrow = 1, override.aes = list(size = 5)),
      size = guide_legend(order = 2, nrow = 1)
    )
}

p_bp <- make_bubble_panel("BP")
p_cc <- make_bubble_panel("CC")
p_mf <- make_bubble_panel("MF")
p_kegg <- make_bubble_panel("KEGG")

min_fdr <- min(enrichment_top$p.adjust, na.rm = TRUE)
bubble_design <- "
AB
CD
EE
"
p_bubbles <- (
  (p_bp + theme(legend.position = "bottom", legend.box = "horizontal")) +
    (p_cc + theme(legend.position = "none")) +
    (p_mf + theme(legend.position = "none")) +
    (p_kegg + theme(legend.position = "none")) +
    guide_area()
) +
  plot_layout(
    design = bubble_design,
    heights = c(1, 1, 0.12),
    guides = "collect"
  ) +
  plot_annotation(
    title = "GO and KEGG enrichment after virtual GDF15 knockout",
    subtitle = "Top 10 terms per category; ranking and color use raw P, while point size shows the number of input genes",
    caption = sprintf(
      "Exploratory raw-P display. No term passed BH-FDR < 0.05 (minimum displayed adjusted P = %.3f).",
      min_fdr
    ),
    tag_levels = "A",
    theme = theme(
      plot.background = element_rect(fill = "white", colour = NA),
      plot.title = element_text(family = base_family, colour = ink, face = "bold", size = 21, hjust = 0),
      plot.subtitle = element_text(family = base_family, colour = muted_ink, size = 11.2, hjust = 0, margin = margin(b = 10)),
      plot.caption = element_text(family = base_family, colour = muted_ink, size = 9.2, hjust = 0, margin = margin(t = 10)),
      plot.tag = element_text(family = base_family, colour = ink, face = "bold", size = 15)
    )
  )

diff_reg$log10_FC_plus_1 <- log10(diff_reg$FC + 1)
diff_reg$neg_log10_raw_p <- -log10(pmax(diff_reg$p.value, .Machine$double.xmin))
diff_reg$status <- ifelse(
  diff_reg$gene == "GDF15", "Knockout target",
  ifelse(diff_reg$p.adj < 0.05, "BH-FDR < 0.05", "Not BH-significant")
)
diff_reg$status <- factor(
  diff_reg$status,
  levels = c("Not BH-significant", "BH-FDR < 0.05", "Knockout target")
)
diff_reg$rank_by_displacement <- rank(-diff_reg$FC, ties.method = "first")

write_csv_utf8(diff_reg, file.path(source_dir, "Figure3_virtual_KO_perturbation_scatter_source.csv"))

status_fill <- c(
  "Not BH-significant" = "white",
  "BH-FDR < 0.05" = teal,
  "Knockout target" = burgundy
)
status_colour <- c(
  "Not BH-significant" = "#A5A5A2",
  "BH-FDR < 0.05" = teal_dark,
  "Knockout target" = ink
)
status_shape <- c(
  "Not BH-significant" = 21,
  "BH-FDR < 0.05" = 21,
  "Knockout target" = 23
)

make_scatter_panel <- function(d, title, label_genes, all_genes = FALSE) {
  threshold_y <- -log10(0.05)
  p <- ggplot(d, aes(x = log10_FC_plus_1, y = neg_log10_raw_p)) +
    geom_hline(
      yintercept = threshold_y, colour = muted_ink,
      linewidth = 0.65, linetype = "32"
    ) +
    geom_point(
      aes(fill = status, colour = status, shape = status),
      size = 2.2, stroke = 0.6, alpha = 0.90
    ) +
    geom_label_repel(
      data = d[d$gene %in% label_genes, , drop = FALSE],
      aes(label = gene),
      family = base_family, colour = ink, fill = alpha("white", 0.92),
      label.size = 0.20, label.r = grid::unit(0.08, "lines"),
      size = 3.0, fontface = "bold", box.padding = 0.38,
      point.padding = 0.18, min.segment.length = 0,
      segment.colour = muted_ink, segment.size = 0.35,
      max.overlaps = Inf, seed = 20260824
    ) +
    annotate(
      "text", x = Inf, y = threshold_y, label = "raw P = 0.05",
      hjust = 1.05, vjust = -0.45, family = base_family,
      colour = muted_ink, size = 3.0
    ) +
    scale_fill_manual(values = status_fill, drop = FALSE, name = NULL) +
    scale_colour_manual(values = status_colour, drop = FALSE, name = NULL) +
    scale_shape_manual(values = status_shape, drop = FALSE, name = NULL) +
    scale_x_continuous(expand = expansion(mult = c(0.02, 0.08))) +
    scale_y_continuous(expand = expansion(mult = c(0.02, 0.08))) +
    labs(
      title = title,
      x = expression(log[10](FC + 1)),
      y = expression(-log[10](raw~P))
    ) +
    theme_research(12) +
    theme(
      panel.grid.minor = element_blank(),
      legend.position = "bottom",
      plot.title = element_text(size = 15),
      plot.margin = margin(10, 12, 10, 10)
    ) +
    guides(
      fill = guide_legend(
        override.aes = list(
          shape = unname(status_shape),
          fill = unname(status_fill),
          colour = unname(status_colour),
          size = 3.4
        ),
        nrow = 1
      ),
      colour = "none",
      shape = "none"
    )

  if (all_genes) {
    p <- p + labs(subtitle = "All 1,001 tested network genes, including the knockout target")
  } else {
    p <- p + labs(subtitle = "Downstream view with GDF15 removed to resolve non-target genes")
  }
  p
}

top_non_target <- subset(diff_reg, gene != "GDF15")
top_non_target <- top_non_target[order(-top_non_target$FC, top_non_target$p.adj, top_non_target$gene), ]
top20_labels <- head(top_non_target$gene, 20L)

p_scatter_all <- make_scatter_panel(
  diff_reg,
  "All tested genes",
  "GDF15",
  all_genes = TRUE
)

p_scatter_zoom <- make_scatter_panel(
  subset(diff_reg, gene != "GDF15"),
  "Non-target perturbations",
  top20_labels,
  all_genes = FALSE
)

n_fdr_non_target <- sum(diff_reg$gene != "GDF15" & diff_reg$p.adj < 0.05, na.rm = TRUE)
scatter_design <- "
AB
CC
"
p_scatter <- (
  (p_scatter_all + theme(legend.position = "bottom", legend.box = "horizontal")) +
    (p_scatter_zoom + theme(legend.position = "none")) +
    guide_area()
) +
  plot_layout(
    design = scatter_design,
    heights = c(1, 0.10),
    guides = "collect"
  ) +
  plot_annotation(
    title = "Virtual GDF15 knockout perturbation overview",
    subtitle = paste0(
      "X = log10(FC + 1); Y = -log10(raw P). FC is a non-directional relative regulatory displacement, ",
      "not expression fold change."
    ),
    caption = sprintf(
      "%d non-target genes passed BH-FDR < 0.05. Labels in the right panel identify the 20 largest non-target FC values.",
      n_fdr_non_target
    ),
    tag_levels = "A",
    theme = theme(
      plot.background = element_rect(fill = "white", colour = NA),
      plot.title = element_text(family = base_family, colour = ink, face = "bold", size = 21, hjust = 0),
      plot.subtitle = element_text(family = base_family, colour = muted_ink, size = 11.0, hjust = 0, margin = margin(b = 10)),
      plot.caption = element_text(family = base_family, colour = muted_ink, size = 9.2, hjust = 0, margin = margin(t = 10)),
      plot.tag = element_text(family = base_family, colour = ink, face = "bold", size = 15)
    )
  )

manifest <- rbind(
  save_plot_set(p_network, "Figure1_GDF15_centered_regulatory_network", 10.5, 9.5),
  save_plot_set(p_bubbles, "Figure2_GO_BP_CC_MF_KEGG_rawP_bubble", 15.5, 12.5),
  save_plot_set(p_scatter, "Figure3_virtual_KO_perturbation_scatter_rawP", 15.5, 7.8)
)

manifest$file_size_bytes <- file.info(manifest$path)$size
manifest$exists_nonempty <- file.exists(manifest$path) & manifest$file_size_bytes > 10000
manifest$path <- file.path("01_figures", basename(manifest$path))
write_csv_utf8(manifest, file.path(qa_dir, "figure_manifest.csv"))

qa <- data.frame(
  check_id = character(), check_name = character(), expected = character(),
  observed = character(), pass = logical(), severity = character(),
  note = character(), stringsAsFactors = FALSE
)

add_qa <- function(id, name, expected, observed, pass, severity = "critical", note = "") {
  qa <<- rbind(
    qa,
    data.frame(
      check_id = id, check_name = name, expected = as.character(expected),
      observed = as.character(observed), pass = isTRUE(pass), severity = severity,
      note = note, stringsAsFactors = FALSE
    )
  )
}

add_qa("Q01", "Differential-regulation rows", "1001", nrow(diff_reg), nrow(diff_reg) == 1001)
add_qa("Q02", "Finite scatter coordinates", "all finite",
       sum(!is.finite(diff_reg$log10_FC_plus_1) | !is.finite(diff_reg$neg_log10_raw_p)),
       all(is.finite(diff_reg$log10_FC_plus_1)) && all(is.finite(diff_reg$neg_log10_raw_p)))
add_qa("Q03", "GDF15 outgoing nonzero edges", ">=10", sum(WT["GDF15", ] != 0), sum(WT["GDF15", ] != 0) >= 10)
add_qa("Q04", "GDF15 incoming nonzero edges", ">=10", sum(WT[, "GDF15"] != 0), sum(WT[, "GDF15"] != 0) >= 10)
add_qa("Q05", "Selected network edges", "20", nrow(network_edges), nrow(network_edges) == 20)
for (category in names(enrichment_files)) {
  n_rows <- sum(enrichment_top$Category == category)
  add_qa(paste0("Q_ENRICH_", category), paste0(category, " raw-P terms"), "10", n_rows, n_rows == 10)
}
add_qa("Q06", "Raw P used for bubble ranking", "ascending raw pvalue",
       "rank_raw_p generated from pvalue", TRUE, "critical",
       "p.adjust is preserved in source data but is not used for bubble ranking or color.")
add_qa("Q07", "Expected figure exports", "9 nonempty files", sum(manifest$exists_nonempty),
       nrow(manifest) == 9 && all(manifest$exists_nonempty))
add_qa("Q08", "Non-target BH-FDR significant genes", "40", n_fdr_non_target,
       n_fdr_non_target == 40, "warning", "Used only for status coloring and caption.")

qa$overall_status <- ifelse(
  any(!qa$pass & qa$severity == "critical"), "FAIL",
  ifelse(any(!qa$pass), "PASS_WITH_WARNINGS", "PASS")
)
write_csv_utf8(qa, file.path(qa_dir, "QA_checks.csv"))

if (any(!qa$pass & qa$severity == "critical")) {
  stop("Critical QA failure; inspect 04_QA/QA_checks.csv")
}

cat("Completed all figures.\n")
cat("Output root:", output_root, "\n")
cat("Network nodes:", nrow(network_nodes), "network edges:", nrow(network_edges), "\n")
cat("Enrichment terms:", nrow(enrichment_top), "\n")
cat("Scatter genes:", nrow(diff_reg), "non-target FDR<0.05:", n_fdr_non_target, "\n")
cat("Figure files:", nrow(manifest), "\n")
