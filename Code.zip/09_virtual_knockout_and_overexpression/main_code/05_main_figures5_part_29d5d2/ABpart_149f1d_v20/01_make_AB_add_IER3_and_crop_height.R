invisible(Sys.setlocale("LC_CTYPE", "Chinese (Simplified)_China.utf8"))
options(stringsAsFactors = FALSE, scipen = 999)

local_lib <- "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_enrichment"
if (dir.exists(local_lib)) .libPaths(c(local_lib, .libPaths()))

suppressPackageStartupMessages({
  library(ggplot2)
  library(ggrepel)
})

output_root <- Sys.getenv(
  "GDF15_AB_V20_OUTPUT_ROOT",
  unset = "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260907_GDF15\u865a\u62df\u6572\u9664_AB\u589e\u52a0IER3\u4e0eA\u88c1\u9ad8_v20"
)
main_dir <- file.path(output_root, "01_\u4e3b\u7ebf\u6700\u7ec8\u56fe")
side_dir <- file.path(output_root, "02_\u652f\u7ebf\u5bbd\u5ea6\u538b\u7f29A\u56fe")
source_dir <- file.path(output_root, "03_\u6e90\u6570\u636e")
qa_dir <- file.path(output_root, "05_QA")
tmp_dir <- file.path(output_root, "tmp", "pdfs")
for (d in c(main_dir, side_dir, source_dir, qa_dir, tmp_dir)) {
  dir.create(d, recursive = TRUE, showWarnings = FALSE)
}

write_csv_utf8 <- function(x, path) {
  write.csv(x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8")
}

input_path <- file.path(source_dir, "A_virtual_KO_axis_focused_non_target_input_v8.csv")
if (!file.exists(input_path)) stop("Missing source data: ", input_path)
dat <- read.csv(input_path, check.names = FALSE, fileEncoding = "UTF-8")

required <- c(
  "gene", "FC", "p.value", "p.adj", "log10_FC_plus_1",
  "neg_log10_raw_p", "EvidenceLayer"
)
missing <- setdiff(required, names(dat))
if (length(missing)) stop("Missing required columns: ", paste(missing, collapse = ", "))
for (nm in c("FC", "p.value", "p.adj", "log10_FC_plus_1", "neg_log10_raw_p")) {
  dat[[nm]] <- as.numeric(dat[[nm]])
}
if (nrow(dat) != 1000L || anyDuplicated(dat$gene)) {
  stop("Expected 1000 unique tested genes.")
}

raw_p_threshold <- 0.05
threshold_y <- -log10(raw_p_threshold)
dat$AboveThreshold <- dat$p.value < raw_p_threshold
dat$DisplayClass <- ifelse(
  dat$AboveThreshold,
  "Differentially regulated genes",
  "Non-differentially regulated genes"
)
display_levels <- c(
  "Non-differentially regulated genes",
  "Differentially regulated genes"
)
dat$DisplayClass <- factor(dat$DisplayClass, levels = display_levels)

established_genes <- c(
  "FOSB", "SLIT3", "SFRP1", "DST", "EGR1", "ITGBL1", "EDIL3",
  "NR4A1", "CPXM2", "COL12A1", "LTBP2", "AEBP1", "ATF3", "TIMP2",
  "FBLN1", "EFEMP1", "WNT5A", "JUN", "FOS"
)
added_erk_gene <- "IER3"
selected_genes <- c(established_genes, added_erk_gene)
if (length(unique(selected_genes)) != 20L) stop("Expected 20 unique selected genes.")

dat$Established19 <- dat$gene %in% established_genes
dat$AddedERK1_2Gene <- dat$gene == added_erk_gene
dat$LabelVisible <- dat$gene %in% selected_genes
dat$DisplayLabel <- ifelse(dat$LabelVisible, dat$gene, "")
dat$RepelLabel <- ifelse(dat$LabelVisible & dat$gene != "FOS", dat$gene, "")

ier3_row <- dat[dat$gene == added_erk_gene, , drop = FALSE]
if (nrow(ier3_row) != 1L) stop("IER3 missing or duplicated.")
if (!(ier3_row$p.value < 0.05 && ier3_row$p.adj < 0.05)) {
  stop("IER3 must satisfy raw P < 0.05 and BH-FDR < 0.05.")
}

dat$RemovedFromA_Ygt6 <- dat$neg_log10_raw_p > 6
removed_rows <- dat[dat$RemovedFromA_Ygt6, , drop = FALSE]
if (!setequal(removed_rows$gene, c("SOD2", "AHNAK"))) {
  stop("Expected the two removed points to be SOD2 and AHNAK.")
}
plot_dat <- dat[!dat$RemovedFromA_Ygt6, , drop = FALSE]

fos_row <- plot_dat[plot_dat$gene == "FOS", , drop = FALSE]
if (nrow(fos_row) != 1L || !fos_row$LabelVisible) stop("Expected one visible FOS row.")
fos_label_x <- 0.855
fos_label_y <- 2.30

ink <- "#292827"
muted_ink <- "#5B5A58"
grid_col <- "#D9DEDF"
neutral <- "#D8D8D6"
uniform_teal <- rgb(134, 184, 186, maxColorValue = 255)
teal_dark <- "#2F6F73"
base_family <- "Arial"

display_fills <- c(
  "Non-differentially regulated genes" = "white",
  "Differentially regulated genes" = uniform_teal
)
display_colours <- c(
  "Non-differentially regulated genes" = neutral,
  "Differentially regulated genes" = teal_dark
)

theme_research <- function(base_size = 12) {
  theme_minimal(base_size = base_size, base_family = base_family) +
    theme(
      plot.background = element_rect(fill = "white", colour = NA),
      panel.background = element_rect(fill = "white", colour = NA),
      panel.grid.minor = element_blank(),
      panel.grid.major = element_line(colour = grid_col, linewidth = 0.35),
      axis.line = element_line(colour = ink, linewidth = 0.45),
      axis.ticks = element_line(colour = ink, linewidth = 0.4),
      axis.text = element_text(colour = ink),
      axis.title = element_text(colour = ink, face = "bold"),
      legend.text = element_text(colour = ink),
      legend.key = element_rect(fill = "white", colour = NA)
    )
}

make_a_plot <- function() {
  ggplot(plot_dat, aes(x = log10_FC_plus_1, y = neg_log10_raw_p)) +
    geom_hline(
      yintercept = threshold_y,
      colour = muted_ink,
      linewidth = 0.65,
      linetype = "dashed"
    ) +
    geom_point(
      aes(fill = DisplayClass, colour = DisplayClass),
      shape = 21,
      size = 2.55,
      stroke = 0.65,
      alpha = 0.92
    ) +
    ggrepel::geom_text_repel(
      aes(label = RepelLabel),
      family = base_family,
      fontface = "bold",
      colour = ink,
      size = 3.20,
      box.padding = grid::unit(0.52, "lines"),
      point.padding = grid::unit(0.64, "lines"),
      force = 3.4,
      force_pull = 0.85,
      max.time = 16,
      max.iter = 300000,
      max.overlaps = Inf,
      min.segment.length = 0,
      segment.colour = ink,
      segment.size = 0.38,
      seed = 20260907,
      show.legend = FALSE
    ) +
    geom_segment(
      data = fos_row,
      aes(
        x = log10_FC_plus_1,
        y = neg_log10_raw_p,
        xend = fos_label_x + 0.006,
        yend = fos_label_y - 0.012
      ),
      inherit.aes = FALSE,
      colour = ink,
      linewidth = 0.38
    ) +
    annotate(
      "text",
      x = fos_label_x,
      y = fos_label_y,
      label = "FOS",
      hjust = 1,
      family = base_family,
      fontface = "bold",
      colour = ink,
      size = 3.20
    ) +
    scale_fill_manual(
      values = display_fills,
      breaks = display_levels,
      drop = FALSE,
      name = NULL
    ) +
    scale_colour_manual(
      values = display_colours,
      breaks = display_levels,
      drop = FALSE,
      guide = "none"
    ) +
    scale_x_continuous(
      breaks = c(0, 0.5, 1.0, 1.5),
      expand = expansion(mult = c(0.02, 0.10))
    ) +
    scale_y_continuous(
      limits = c(-0.10, 5.78),
      breaks = c(0, 2, 4),
      expand = expansion(mult = 0)
    ) +
    labs(
      x = expression(log[10](FC + 1)),
      y = expression(-log[10](raw~P))
    ) +
    theme_research(12) +
    theme(
      legend.position = "inside",
      legend.position.inside = c(0.025, 0.865),
      legend.justification = c(0, 1),
      legend.direction = "vertical",
      legend.box = "vertical",
      legend.background = element_rect(fill = "white", colour = NA),
      legend.text = element_text(size = 9.2),
      legend.key.height = grid::unit(6.0, "mm"),
      plot.margin = margin(8, 12, 7, 10),
      axis.title = element_text(size = 11),
      axis.text = element_text(size = 9.5)
    ) +
    guides(
      fill = guide_legend(
        order = 1,
        ncol = 1,
        byrow = TRUE,
        override.aes = list(shape = 21, size = 3.8, alpha = 1)
      )
    )
}

p_a_main <- make_a_plot()
p_a_side <- make_a_plot()

bar_data <- dat[dat$LabelVisible, , drop = FALSE]
bar_data <- bar_data[order(-bar_data$log10_FC_plus_1, bar_data$gene), , drop = FALSE]
rownames(bar_data) <- NULL
bar_data$RankTopToBottom <- seq_len(nrow(bar_data))
bar_data$gene_plot <- factor(bar_data$gene, levels = rev(bar_data$gene))
bar_data$BarFill <- toupper(uniform_teal)

x_max <- ceiling(max(bar_data$log10_FC_plus_1) * 4) / 4
x_breaks <- seq(0, x_max, by = 0.25)

p_b <- ggplot(bar_data, aes(x = log10_FC_plus_1, y = gene_plot)) +
  geom_col(
    width = 0.68,
    fill = uniform_teal,
    colour = teal_dark,
    linewidth = 0.45,
    alpha = 0.98
  ) +
  scale_x_continuous(
    limits = c(0, x_max),
    breaks = x_breaks,
    expand = expansion(mult = c(0, 0.01))
  ) +
  scale_y_discrete(expand = expansion(add = c(0.42, 0.42))) +
  labs(x = expression(log[10](FC + 1)), y = NULL) +
  theme_minimal(base_family = base_family, base_size = 12) +
  theme(
    plot.background = element_rect(fill = "white", colour = NA),
    panel.background = element_rect(fill = "white", colour = NA),
    panel.border = element_blank(),
    panel.grid.major.x = element_line(colour = "#E4E8E8", linewidth = 0.42),
    panel.grid.major.y = element_blank(),
    panel.grid.minor = element_blank(),
    axis.text.y = element_text(
      colour = ink,
      face = "bold.italic",
      size = 10.4,
      margin = margin(r = 8)
    ),
    axis.text.x = element_text(colour = ink, size = 9.5),
    axis.title.x = element_text(colour = ink, size = 11.2, margin = margin(t = 10)),
    axis.line.x = element_line(colour = ink, linewidth = 0.52),
    axis.line.y = element_blank(),
    axis.ticks.x = element_line(colour = ink, linewidth = 0.42),
    axis.ticks.length.x = grid::unit(2.8, "pt"),
    axis.ticks.y = element_blank(),
    plot.margin = margin(18, 24, 16, 18)
  )

main_width <- 12.8
main_height <- 6.55
side_width <- main_width / 1.5
b_width <- 8.6
b_height <- 8.70

main_work_pdf <- file.path(tmp_dir, "A\u56fe_\u4e3b\u7ebf\u672a\u88c1\u526a\u5de5\u4f5c\u7a3f.pdf")
side_work_pdf <- file.path(tmp_dir, "A\u56fe_\u652f\u7ebf\u5bbd\u5ea6\u4e09\u5206\u4e4b\u4e8c\u672a\u88c1\u526a\u5de5\u4f5c\u7a3f.pdf")

ggsave(
  main_work_pdf,
  plot = p_a_main,
  width = main_width,
  height = main_height,
  units = "in",
  device = grDevices::cairo_pdf,
  bg = "white"
)
ggsave(
  side_work_pdf,
  plot = p_a_side,
  width = side_width,
  height = main_height,
  units = "in",
  device = grDevices::cairo_pdf,
  bg = "white"
)
ggsave(
  file.path(main_dir, "B\u56fe_TOP20\u5dee\u5f02\u8c03\u63a7\u57fa\u56e0_\u6a2a\u5411\u6761\u5f62\u67f1\u72b6\u56fe_\u6700\u7ec8\u7248.pdf"),
  plot = p_b,
  width = b_width,
  height = b_height,
  units = "in",
  device = grDevices::cairo_pdf,
  bg = "white"
)

a_source_columns <- c(
  "gene", "distance", "Z", "FC", "p.value", "p.adj",
  "rank_by_FDR_then_FC", "FDR_lt_0_05", "log10_FC_plus_1",
  "neg_log10_raw_p", "EvidenceLayer", "AboveThreshold", "DisplayClass",
  "Established19", "AddedERK1_2Gene", "LabelVisible", "DisplayLabel",
  "RepelLabel", "RemovedFromA_Ygt6"
)
write_csv_utf8(
  dat[, intersect(a_source_columns, names(dat)), drop = FALSE],
  file.path(source_dir, "A\u56fe_\u6700\u7ec8\u5206\u7c7b\u6807\u6ce8\u4e0e\u5220\u70b9\u6570\u636e.csv")
)

b_source_columns <- c(
  "RankTopToBottom", "gene", "log10_FC_plus_1", "FC", "p.value", "p.adj",
  "neg_log10_raw_p", "EvidenceLayer", "Established19", "AddedERK1_2Gene",
  "AboveThreshold", "LabelVisible", "BarFill"
)
write_csv_utf8(
  bar_data[, intersect(b_source_columns, names(bar_data)), drop = FALSE],
  file.path(source_dir, "B\u56fe_TOP20\u542bIER3\u6761\u5f62\u56fe\u6570\u636e.csv")
)

same_gene_set <- setequal(as.character(bar_data$gene), selected_genes)
same_gene_order <- identical(
  as.character(bar_data$gene),
  dat$gene[dat$LabelVisible][order(
    -dat$log10_FC_plus_1[dat$LabelVisible],
    dat$gene[dat$LabelVisible]
  )]
)

qa <- data.frame(
  check_id = sprintf("Q%02d", 1:15),
  check_name = c(
    "Input tested genes",
    "A removed point count where y > 6",
    "A removed genes are SOD2 and AHNAK",
    "A plotted point count",
    "A plotted maximum y is below 6",
    "A plotted differentially regulated points",
    "A visible gene labels",
    "All visible labels satisfy raw P < 0.05",
    "IER3 is included",
    "IER3 raw P < 0.05",
    "IER3 BH-FDR < 0.05",
    "B gene count",
    "A label and B gene sets match",
    "B order decreases by log10(FC + 1)",
    "Side A width equals two-thirds of main working width"
  ),
  expected = c(
    "1000", "2", "TRUE", "998", "TRUE", "85", "20", "TRUE", "TRUE",
    "TRUE", "TRUE", "20", "TRUE", "TRUE", "TRUE"
  ),
  observed = c(
    nrow(dat),
    nrow(removed_rows),
    setequal(removed_rows$gene, c("SOD2", "AHNAK")),
    nrow(plot_dat),
    max(plot_dat$neg_log10_raw_p) < 6,
    sum(plot_dat$AboveThreshold),
    sum(dat$LabelVisible),
    all(dat$p.value[dat$LabelVisible] < raw_p_threshold),
    added_erk_gene %in% dat$gene[dat$LabelVisible],
    ier3_row$p.value < 0.05,
    ier3_row$p.adj < 0.05,
    nrow(bar_data),
    same_gene_set,
    same_gene_order && all(diff(bar_data$log10_FC_plus_1) <= 1e-12),
    isTRUE(all.equal(side_width, main_width * 2 / 3))
  ),
  pass = c(
    nrow(dat) == 1000L,
    nrow(removed_rows) == 2L,
    setequal(removed_rows$gene, c("SOD2", "AHNAK")),
    nrow(plot_dat) == 998L,
    max(plot_dat$neg_log10_raw_p) < 6,
    sum(plot_dat$AboveThreshold) == 85L,
    sum(dat$LabelVisible) == 20L,
    all(dat$p.value[dat$LabelVisible] < raw_p_threshold),
    added_erk_gene %in% dat$gene[dat$LabelVisible],
    ier3_row$p.value < 0.05,
    ier3_row$p.adj < 0.05,
    nrow(bar_data) == 20L,
    same_gene_set,
    same_gene_order && all(diff(bar_data$log10_FC_plus_1) <= 1e-12),
    isTRUE(all.equal(side_width, main_width * 2 / 3))
  ),
  stringsAsFactors = FALSE
)
write_csv_utf8(qa, file.path(qa_dir, "AB_\u589e\u52a0IER3\u4e0eA\u5220\u70b9\u88c1\u9ad8\u6570\u636eQA.csv"))
capture.output(sessionInfo(), file = file.path(qa_dir, "R_sessionInfo.txt"))

if (any(!qa$pass)) stop("Critical QA failure; inspect AB_\u589e\u52a0IER3\u4e0eA\u5220\u70b9\u88c1\u9ad8\u6570\u636eQA.csv")
cat("Created main and side working files.\n")
cat("Added gene: IER3; raw P =", ier3_row$p.value, "; BH-FDR =", ier3_row$p.adj, "\n")
cat("Removed from A:", paste(removed_rows$gene, collapse = ", "), "\n")
