from __future__ import annotations
import argparse
import csv
import re
import subprocess
import tempfile
from pathlib import Path
from xml.etree import ElementTree as ET
from PIL import Image

def read_expected_genes(csv_path: Path) -> set[str]:
    with csv_path.open('r', newline='', encoding='utf-8-sig') as handle:
        genes = {row['gene'].strip() for row in csv.DictReader(handle)}
    if len(genes) != 20:
        raise ValueError(f'Expected 20 genes, observed {len(genes)}')
    return genes

def extract_gene_boxes(pdf_path: Path, pdftotext: str, expected_genes: set[str]) -> dict[str, tuple[float, float, float, float]]:
    with tempfile.TemporaryDirectory() as tmp:
        html_path = Path(tmp) / 'bbox.html'
        subprocess.run([pdftotext, '-bbox-layout', str(pdf_path), str(html_path)], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        root = ET.parse(html_path).getroot()
    found: dict[str, list[tuple[float, float, float, float]]] = {}
    for node in root.iter():
        if not node.tag.endswith('word'):
            continue
        word = re.sub('\\s+', '', ''.join(node.itertext()))
        if word in expected_genes:
            found.setdefault(word, []).append(tuple((float(node.attrib[key]) for key in ('xMin', 'yMin', 'xMax', 'yMax'))))
    duplicated = {gene: boxes for gene, boxes in found.items() if len(boxes) != 1}
    if duplicated:
        raise RuntimeError(f'Duplicated PDF gene labels: {sorted(duplicated)}')
    return {gene: boxes[0] for gene, boxes in found.items()}

def rectangles_overlap(a: tuple[float, float, float, float], b: tuple[float, float, float, float]) -> bool:
    return min(a[2], b[2]) > max(a[0], b[0]) and min(a[3], b[3]) > max(a[1], b[1])

def is_highlight_point_colour(pixel: tuple[int, int, int]) -> bool:
    roots = ((134, 184, 186), (47, 111, 115))
    return any((max((abs(pixel[i] - root[i]) for i in range(3))) <= 22 for root in roots))

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--pdf', required=True, type=Path)
    parser.add_argument('--png', required=True, type=Path)
    parser.add_argument('--genes-csv', required=True, type=Path)
    parser.add_argument('--pdftotext', required=True)
    parser.add_argument('--dpi', type=float, default=300.0)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--padding-px', type=int, default=2)
    args = parser.parse_args()
    expected_genes = read_expected_genes(args.genes_csv)
    boxes = extract_gene_boxes(args.pdf, args.pdftotext, expected_genes)
    missing = sorted(expected_genes - boxes.keys())
    if missing:
        raise RuntimeError(f'Missing PDF gene labels: {missing}')
    image = Image.open(args.png).convert('RGB')
    scale = args.dpi / 72.0
    rows: list[dict[str, object]] = []
    for gene in sorted(expected_genes):
        box = boxes[gene]
        x0 = max(0, int(box[0] * scale) - args.padding_px)
        y0 = max(0, int(box[1] * scale) - args.padding_px)
        x1 = min(image.width, int(box[2] * scale + 0.9999) + args.padding_px)
        y1 = min(image.height, int(box[3] * scale + 0.9999) + args.padding_px)
        point_pixels = 0
        for y in range(y0, y1):
            for x in range(x0, x1):
                if is_highlight_point_colour(image.getpixel((x, y))):
                    point_pixels += 1
        rows.append({'gene': gene, 'x_min_pt': f'{box[0]:.3f}', 'y_min_pt': f'{box[1]:.3f}', 'x_max_pt': f'{box[2]:.3f}', 'y_max_pt': f'{box[3]:.3f}', 'highlight_point_pixels_in_padded_text_box': point_pixels, 'text_point_overlap_pass': point_pixels == 0})
    label_pairs: list[str] = []
    genes = sorted(expected_genes)
    for index, gene_a in enumerate(genes):
        for gene_b in genes[index + 1:]:
            if rectangles_overlap(boxes[gene_a], boxes[gene_b]):
                label_pairs.append(f'{gene_a}|{gene_b}')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('w', newline='', encoding='utf-8-sig') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    point_failures = sum((not row['text_point_overlap_pass'] for row in rows))
    print(f'labels={len(boxes)}')
    print(f'text-point overlap failures={point_failures}')
    print(f'text-text overlap pairs={len(label_pairs)}')
    if label_pairs:
        print('overlapping labels:', ', '.join(label_pairs))
    if point_failures or label_pairs:
        raise RuntimeError('A label-overlap QA failed')
if __name__ == '__main__':
    main()
