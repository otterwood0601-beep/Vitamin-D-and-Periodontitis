from __future__ import annotations
import csv
import re
import shutil
import subprocess
from pathlib import Path
from pypdf import PdfReader
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260907_GDF15\u865a\u62df\u6572\u9664_AB\u589e\u52a0IER3\u4e0eA\u88c1\u9ad8_v20')
GENE_CSV = ROOT / '03_\u6e90\u6570\u636e' / 'B\u56fe_TOP20\u542bIER3\u6761\u5f62\u56fe\u6570\u636e.csv'
PDFS = {'Main A': ROOT / '01_\u4e3b\u7ebf\u6700\u7ec8\u56fe' / 'A\u56fe_GDF15\u865a\u62df\u6572\u9664\u6270\u52a8\u603b\u89c8_\u6700\u7ec8\u7248.pdf', 'Main B': ROOT / '01_\u4e3b\u7ebf\u6700\u7ec8\u56fe' / 'B\u56fe_TOP20\u5dee\u5f02\u8c03\u63a7\u57fa\u56e0_\u6a2a\u5411\u6761\u5f62\u67f1\u72b6\u56fe_\u6700\u7ec8\u7248.pdf', 'Side A': ROOT / '02_\u652f\u7ebf\u5bbd\u5ea6\u538b\u7f29A\u56fe' / 'A\u56fe_GDF15\u865a\u62df\u6572\u9664\u6270\u52a8\u603b\u89c8_\u5bbd\u5ea6\u4e3a\u4e3b\u7ebf\u4e09\u5206\u4e4b\u4e8c_\u652f\u7ebf\u7248.pdf'}
REMOVED_FROM_A = {'SOD2', 'AHNAK'}

def count_symbol(text: str, gene: str) -> int:
    pattern = f'(?<![A-Za-z0-9_.-]){re.escape(gene)}(?![A-Za-z0-9_.-])'
    return len(re.findall(pattern, text))

def extract_layout_text(path: Path) -> str:
    executable = shutil.which('pdftotext')
    if not executable:
        raise FileNotFoundError('pdftotext is unavailable')
    result = subprocess.run([executable, '-layout', str(path), '-'], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return result.stdout.decode('utf-8', errors='replace')

def main() -> None:
    with GENE_CSV.open('r', encoding='utf-8-sig', newline='') as handle:
        genes = [row['gene'].strip() for row in csv.DictReader(handle)]
    if len(genes) != 20 or len(set(genes)) != 20 or 'IER3' not in genes:
        raise ValueError('Expected 20 unique B genes including IER3.')
    rows: list[dict[str, object]] = []
    for name, path in PDFS.items():
        reader = PdfReader(str(path))
        text = extract_layout_text(path)
        counts = {gene: count_symbol(text, gene) for gene in genes}
        missing = sorted((gene for gene, count in counts.items() if count == 0))
        duplicated = sorted((gene for gene, count in counts.items() if count > 1))
        removed_present = sorted((gene for gene in REMOVED_FROM_A if count_symbol(text, gene) > 0))
        if name == 'Main B':
            removed_present = []
        rows.append({'figure': name, 'pages': len(reader.pages), 'expected_selected_genes': 20, 'missing_selected_genes': len(missing), 'missing_list': ';'.join(missing), 'duplicated_selected_genes': len(duplicated), 'duplicated_list': ';'.join(duplicated), 'IER3_occurrences': counts['IER3'], 'removed_y_gt_6_genes_visible_in_A': ';'.join(removed_present), 'pass': len(reader.pages) == 1 and (not missing) and (not duplicated) and (counts['IER3'] == 1) and (name == 'Main B' or not removed_present)})
    output = ROOT / '05_QA' / '\u6700\u7ec8PDF\u5185\u5bb9QA.csv'
    with output.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    if not all((bool(row['pass']) for row in rows)):
        raise RuntimeError('Final PDF content QA failed.')
    print('Final PDF content QA passed for main A, main B and side A.')
if __name__ == '__main__':
    main()
