from __future__ import annotations
import argparse
import csv
import shutil
import subprocess
from pathlib import Path
from PIL import Image, ImageChops
from pypdf import PdfReader, PdfWriter, Transformation
from pypdf.generic import RectangleObject

def find_pdftoppm(explicit: str | None) -> str:
    if explicit:
        candidate = Path(explicit)
        if candidate.is_file():
            return str(candidate)
        raise FileNotFoundError(f'pdftoppm not found: {candidate}')
    found = shutil.which('pdftoppm')
    if found:
        return found
    runtime = Path('C:\\Users\\Lin\\.cache\\codex-runtimes')
    matches = list(runtime.rglob('pdftoppm.exe'))
    if not matches:
        raise FileNotFoundError('pdftoppm is unavailable')
    return str(matches[0])

def content_bbox(image_path: Path) -> tuple[int, int, int, int]:
    image = Image.open(image_path).convert('RGB')
    white = Image.new('RGB', image.size, 'white')
    diff = ImageChops.difference(image, white).convert('L')
    mask = diff.point(lambda value: 255 if value > 12 else 0)
    bbox = mask.getbbox()
    if bbox is None:
        raise RuntimeError('Rendered PDF page is blank')
    return bbox

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--qa-dir', required=True, type=Path)
    parser.add_argument('--tag', required=True)
    parser.add_argument('--pdftoppm')
    parser.add_argument('--dpi', type=int, default=220)
    parser.add_argument('--margin-pt', type=float, default=8.0)
    args = parser.parse_args()
    input_pdf = args.input.resolve()
    output_pdf = args.output.resolve()
    qa_dir = args.qa_dir.resolve()
    qa_dir.mkdir(parents=True, exist_ok=True)
    output_pdf.parent.mkdir(parents=True, exist_ok=True)
    pdftoppm = find_pdftoppm(args.pdftoppm)
    scan_prefix = qa_dir / f'{args.tag}_\u5185\u5bb9\u8fb9\u754c\u626b\u63cf'
    subprocess.run([pdftoppm, '-png', '-r', str(args.dpi), '-singlefile', str(input_pdf), str(scan_prefix)], check=True)
    scan_png = scan_prefix.with_suffix('.png')
    left, top, right, bottom = content_bbox(scan_png)
    reader = PdfReader(str(input_pdf))
    if len(reader.pages) != 1:
        raise ValueError('Expected a one-page PDF')
    page = reader.pages[0]
    page_width = float(page.mediabox.width)
    page_height = float(page.mediabox.height)
    px_to_pt = 72.0 / args.dpi
    x0 = max(0.0, left * px_to_pt - args.margin_pt)
    x1 = min(page_width, right * px_to_pt + args.margin_pt)
    y0 = max(0.0, page_height - bottom * px_to_pt - args.margin_pt)
    y1 = min(page_height, page_height - top * px_to_pt + args.margin_pt)
    new_width = x1 - x0
    new_height = y1 - y0
    page.add_transformation(Transformation().translate(tx=-x0, ty=-y0))
    box = RectangleObject([0, 0, new_width, new_height])
    page.mediabox = box
    page.cropbox = box
    page.trimbox = box
    page.bleedbox = box
    page.artbox = box
    writer = PdfWriter()
    writer.add_page(page)
    with output_pdf.open('wb') as stream:
        writer.write(stream)
    qa_csv = qa_dir / f'{args.tag}_\u753b\u5e03\u88c1\u526aQA.csv'
    rows = [('Original page width pt', f'{page_width:.3f}', True), ('Original page height pt', f'{page_height:.3f}', True), ('Detected content bbox px', f'{left};{top};{right};{bottom}', True), ('Crop margin pt', f'{args.margin_pt:.3f}', True), ('Final page width pt', f'{new_width:.3f}', True), ('Final page height pt', f'{new_height:.3f}', True), ('Width reduction percent', f'{(1 - new_width / page_width) * 100:.3f}', True), ('Height reduction percent', f'{(1 - new_height / page_height) * 100:.3f}', True)]
    with qa_csv.open('w', newline='', encoding='utf-8-sig') as handle:
        writer_csv = csv.writer(handle)
        writer_csv.writerow(['Check', 'Observed', 'Pass'])
        writer_csv.writerows(rows)
if __name__ == '__main__':
    main()
