from pathlib import Path
import heapq
import h5py
import numpy as np
import pandas as pd
from pypdf import PdfReader
from pypdf.generic import ContentStream
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split
PDF = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u6b63\u6587\u56fe\\\u6b63\u6587\u56fe4 sc-RNA\\A.5\u79cd\u7ec6\u80de\u5206\u7c7b\u5730\u56fe.pdf')
ATLAS = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u539f\u59cb\u6570\u636e\\05_\u5355\u7ec6\u80deRNA\\\u6d3e\u751f\u8f93\u5165\\GDF15_Figure1')
H5AD = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u539f\u59cb\u6570\u636e\\05_\u5355\u7ec6\u80deRNA\\01_scRNA-seq') / 'CELLxGENE_Integrated_Periodontitis_Atlas' / 'processed' / 'Integrated_Human_Periodontitis_Atlas_105918cells.h5ad'

def extract_points():
    page = PdfReader(str(PDF)).pages[0]
    operations = ContentStream(page.get_contents(), page.pdf).operations
    groups = {f'/P{i}': [] for i in range(5)}
    for index, (operands, operator) in enumerate(operations):
        if operator != b'Do' or str(operands[0]) not in groups:
            continue
        previous_operands, previous_operator = operations[index - 1]
        if previous_operator != b'cm':
            raise RuntimeError('Unexpected marker transform in reference PDF')
        x_page = float(previous_operands[4])
        y_page = float(previous_operands[5])
        x = -6.0 + (x_page - 54.0) / 446.39 * 13.25
        y = -6.5 + (y_page - 53.28) / 446.39 * 13.25
        groups[str(operands[0])].append((x, y))
    return {name: np.asarray(points) for name, points in groups.items()}

def main():
    groups = extract_points()
    clusters = pd.read_csv(ATLAS / 'cell_cluster_mapping.csv.gz')
    mapping = pd.read_csv(ATLAS / 'five_type_merge_mapping.csv')
    metadata = pd.read_csv(ATLAS / 'input_fb' / 'CELLxGENE\u76f4\u63a5\u6807\u6ce8fibroblast_\u9010\u7ec6\u80de\u5143\u6570\u636e_QC\u540e.csv.gz')
    cells = clusters.merge(mapping[['original_fb_id', 'final_fibroblast_type']], left_on='fb_id', right_on='original_fb_id', how='left', validate='many_to_one').merge(metadata[['cell_barcode', 'h5ad_row']], on='cell_barcode', how='left', validate='one_to_one')
    rows = cells['h5ad_row'].to_numpy(int) - 1
    with h5py.File(H5AD, 'r') as handle:
        atlas_umap = np.asarray(handle['obsm']['X_umap'][rows], dtype=float)
        atlas_pca = np.asarray(handle['obsm']['X_pca'][rows, :50], dtype=float)
    cells['atlas_x'] = atlas_umap[:, 0]
    cells['atlas_y'] = atlas_umap[:, 1]
    names = ['Vascular-associated fibroblasts', 'Immune-associated fibroblasts', 'ECM remodeling-associated fibroblasts', 'Pre-extracellular matrix-associated fibroblasts', 'Matrix homeostasis-associated fibroblasts']
    exact_indices = []
    exact_coordinates = []
    for i, name in enumerate(names):
        subset = cells.loc[cells['final_fibroblast_type'].eq(name)].copy()
        points = groups[f'/P{i}']
        print(i, name, len(subset), len(points))
        if len(subset) == len(points):
            for source_axis, source_col in enumerate(['atlas_x', 'atlas_y']):
                for target_axis in range(2):
                    corr = np.corrcoef(subset[source_col], points[:, target_axis])[0, 1]
                    print(f'  corr {source_col} vs pdf{target_axis}: {corr:.6f}')
            exact_indices.extend(subset.index.tolist())
            exact_coordinates.extend(points.tolist())
    exact_indices = np.asarray(exact_indices, dtype=int)
    exact_coordinates = np.asarray(exact_coordinates, dtype=float)
    train, test = train_test_split(np.arange(len(exact_indices)), test_size=0.25, random_state=42)
    features = np.column_stack([atlas_pca, atlas_umap])
    regressor = ExtraTreesRegressor(n_estimators=300, min_samples_leaf=2, max_features=0.85, n_jobs=-1, random_state=42)
    regressor.fit(features[exact_indices[train]], exact_coordinates[train])
    prediction = regressor.predict(features[exact_indices[test]])
    print('held-out r2', r2_score(exact_coordinates[test], prediction, multioutput='raw_values'))
    print('held-out median error', np.median(np.linalg.norm(exact_coordinates[test] - prediction, axis=1)))
    regressor.fit(features[exact_indices], exact_coordinates)
    all_prediction = regressor.predict(features)

    def find_two_skips(predicted, observed):
        n = len(predicted)
        if len(observed) != n - 2:
            raise ValueError('This helper is only for two clipped source rows')
        dp = np.full(3, np.inf)
        dp[0] = 0.0
        paths = [tuple(), tuple(), tuple()]
        for i in range(n):
            next_dp = np.full(3, np.inf)
            next_paths = [tuple(), tuple(), tuple()]
            for skipped in range(3):
                if not np.isfinite(dp[skipped]):
                    continue
                observed_index = i - skipped
                if observed_index < len(observed):
                    cost = dp[skipped] + float(np.square(predicted[i] - observed[observed_index]).sum())
                    if cost < next_dp[skipped]:
                        next_dp[skipped] = cost
                        next_paths[skipped] = paths[skipped]
                if skipped < 2 and dp[skipped] < next_dp[skipped + 1]:
                    next_dp[skipped + 1] = dp[skipped]
                    next_paths[skipped + 1] = paths[skipped] + (i,)
            dp, paths = (next_dp, next_paths)
        return [(float(dp[2]), *paths[2])]
    for i, name in enumerate(names[:2]):
        indices = cells.index[cells['final_fibroblast_type'].eq(name)].to_numpy()
        predicted = all_prediction[indices]
        observed = groups[f'/P{i}']
        ranked = find_two_skips(predicted, observed)
        print('\n', name, 'two-skip candidates')
        for score, first, second in ranked:
            row1 = cells.loc[indices[first], ['cell_barcode', 'Study', 'fb_id']].to_dict()
            row2 = cells.loc[indices[second], ['cell_barcode', 'Study', 'fb_id']].to_dict()
            print(score, first, second, predicted[first].tolist(), predicted[second].tolist(), row1, row2)
        smallest = np.argsort(predicted[:, 0])[:10]
        print('smallest predicted x')
        for position in smallest:
            row = cells.loc[indices[position], ['cell_barcode', 'Study', 'fb_id']].to_dict()
            print(position, predicted[position].tolist(), row)
if __name__ == '__main__':
    main()
