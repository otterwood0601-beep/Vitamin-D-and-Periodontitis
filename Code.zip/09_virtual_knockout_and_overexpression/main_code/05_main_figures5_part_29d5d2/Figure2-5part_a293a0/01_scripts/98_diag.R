proj <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260816_Figure2-5_pipeline\u590d\u73b0/R_library_453"
.libPaths(c(proj, .libPaths()))
for(p in c("WGCNA","monocle","DDRTree","GSVA","org.Hs.eg.db","Nebulosa","DOSE")){
  ondisk <- dir.exists(file.path(proj, p))
  err <- tryCatch({ library(p, lib.loc=proj, character.only=TRUE, quietly=TRUE); "LOADED OK" },
                  error=function(e) conditionMessage(e))
  cat(sprintf("%-14s on_disk=%-5s load=%s\n", p, ondisk, err))
}
