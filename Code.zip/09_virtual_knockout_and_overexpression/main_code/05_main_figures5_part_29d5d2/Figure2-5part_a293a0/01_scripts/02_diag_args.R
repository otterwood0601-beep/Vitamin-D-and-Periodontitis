args <- commandArgs(trailingOnly = TRUE)
for (i in seq_along(args)) {
  cat("arg", i, ":", args[i], " | exists=", file.exists(args[i]), "\n")
}
.libPaths(c(args[1], args[2], args[3], .libPaths()))
cat("--- final .libPaths ---\n")
print(.libPaths())
cat("Seurat loadable:", requireNamespace("Seurat", quietly = TRUE), "\n")
