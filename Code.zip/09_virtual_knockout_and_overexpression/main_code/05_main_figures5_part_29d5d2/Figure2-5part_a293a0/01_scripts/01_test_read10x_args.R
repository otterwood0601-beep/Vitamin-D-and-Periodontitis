args <- commandArgs(trailingOnly = TRUE)
lib1 <- args[1]; lib2 <- args[2]; lib3 <- args[3]; dat <- args[4]
.libPaths(c(lib1, lib2, lib3, .libPaths()))
suppressPackageStartupMessages(library(Seurat))
cat("Seurat:", as.character(packageVersion("Seurat")), "\n")
c <- Read10X(data.dir = dat)
cat("GM1 dims:", nrow(c), "features x", ncol(c), "cells\n")
cat("OK\n")
