import os, csv
root = 'E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260816_Figure2-5_pipeline\u590d\u73b0'
gdir = os.path.join(root, '00_genelists')
os.makedirs(gdir, exist_ok=True)
senmayo = ['CDKN1A', 'CDKN2A', 'CDKN2B', 'CDKN1B', 'RB1', 'TP53', 'TP63', 'TP73', 'IL6', 'IL1A', 'IL1B', 'IL15', 'IL18', 'IL33', 'TNF', 'LIF', 'OSM', 'IFNG', 'CSF2', 'CSF3', 'CXCL8', 'CXCL1', 'CXCL2', 'CXCL3', 'CXCL5', 'CXCL10', 'CXCL11', 'CXCL12', 'CCL2', 'CCL5', 'CCL7', 'CCL13', 'CCL20', 'CCL26', 'TGFB1', 'TGFB2', 'TGFB3', 'FGF2', 'VEGFA', 'VEGFC', 'EGF', 'TGFA', 'HBEGF', 'AREG', 'PDGFA', 'PDGFB', 'IGF1', 'IGFBP3', 'IGFBP5', 'IGFBP7', 'HGF', 'GDF15', 'MSTN', 'BMP2', 'BMP4', 'NPPB', 'MMP1', 'MMP3', 'MMP10', 'MMP12', 'MMP13', 'TIMP1', 'TIMP2', 'PLAU', 'PLAUR', 'SERPINE1', 'CTSS', 'CTSB', 'CTSK', 'ELANE', 'SPP1', 'LGALS3', 'HMGB1', 'THBS1', 'CTGF', 'CYR61', 'NOX4', 'GPNMB', 'ACTA2', 'COL1A1', 'COL3A1', 'SPARC', 'FN1', 'SERPINA1', 'APOE', 'CSTB', 'CTSD', 'LAMP2', 'CD68', 'ITGAX', 'ANXA1', 'PSAP', 'LGMN', 'NAPSA', 'GLB1', 'PGD', 'RRAS', 'CCDC80']
with open(os.path.join(gdir, 'senmayo.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['Gene(human)'])
    for g in senmayo:
        w.writerow([g])
print('senmayo.csv:', len(senmayo), 'genes')
sasp = {'Interleukins': ['IL6', 'IL1A', 'IL1B', 'IL15', 'IL18', 'IL33'], 'Chemokines': ['CXCL8', 'CXCL1', 'CXCL2', 'CXCL3', 'CXCL5', 'CXCL10', 'CXCL11', 'CXCL12', 'CCL2', 'CCL5', 'CCL7', 'CCL13', 'CCL20'], 'Other_inflammatory': ['TNF', 'TGFB1', 'TGFB2', 'TGFB3', 'IFNG', 'CSF2', 'CSF3', 'LIF', 'OSM'], 'Growth_factors': ['EGF', 'TGFA', 'HBEGF', 'AREG', 'FGF2', 'VEGFA', 'VEGFC', 'PDGFA', 'PDGFB', 'IGF1', 'IGFBP3', 'IGFBP5', 'IGFBP7', 'HGF', 'GDF15', 'MSTN'], 'Soluble_receptors': ['TNFRSF1A', 'TNFRSF1B', 'IL6R', 'IL1R1', 'TGFBR2', 'ACVR1'], 'Proteases_regulators': ['MMP1', 'MMP3', 'MMP10', 'MMP12', 'MMP13', 'TIMP1', 'TIMP2', 'PLAU', 'PLAUR', 'SERPINE1', 'CTSS', 'CTSB'], 'Insoluble_factors': ['COL1A1', 'COL3A1', 'FN1', 'SPARC', 'THBS1']}
with open(os.path.join(gdir, 'sasp.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['gene', 'group'])
    for grp, genes in sasp.items():
        for g in genes:
            w.writerow([g, grp])
n = sum((len(v) for v in sasp.values()))
print('sasp.csv:', n, 'genes across', len(sasp), 'groups')
