args <- commandArgs(trailingOnly = TRUE)
lib1 <- args[1]; lib2 <- args[2]; proj <- args[3]
.libPaths(c(lib1, lib2, proj, "C:/Users/Lin/AppData/Local/R/win-library/4.5", .libPaths()))
options(Ncpus = 4, repos = "https://cloud.r-project.org")
cat("proj_lib =", proj, "\n")

verify <- function(p){
  ok <- suppressWarnings(tryCatch(requireNamespace(p, quietly = TRUE), error = function(e) FALSE))
  cat(sprintf("  %-14s %s\n", p, if(isTRUE(ok)) "LOADABLE" else "MISSING"))
  isTRUE(ok)
}

cat("== [1/3] Bioc/CRAN: DOSE, Nebulosa, org.Hs.eg.db, VISION ==\n")
BiocManager::install(c("DOSE","Nebulosa","org.Hs.eg.db","VISION"),
                     lib = proj, ask = FALSE, update = FALSE, force = TRUE)

cat("== [2/3] CellChat (github jinworks/CellChat) ==\n")
remotes::install_github("jinworks/CellChat", lib = proj, upgrade = "never", force = TRUE)

cat("== [3/3] scMetabolism (github wu-yc/scMetabolism, needs VISION) ==\n")
remotes::install_github("wu-yc/scMetabolism", lib = proj, upgrade = "never", force = TRUE)

cat("== FINAL VERIFY (full pipeline libPaths) ==\n")
pkgs <- c("DOSE","Nebulosa","org.Hs.eg.db","VISION","CellChat","scMetabolism",
          "WGCNA","monocle","DDRTree","GSVA","ggrepel","limma")
allok <- TRUE
for(p in pkgs) if(!verify(p)) allok <- FALSE
cat("ALL_OK =", allok, "\n")
