set -e

HD="/e/"$'\u8840\u6e05\u7ef4\u751f\u7d20'"/"$'\u8f93\u51fa'"/20260723-"$'\u9636\u6bb5'"11（"$'\u7ef4\u751f\u7d20'"D-"$'\u7259\u9f88'"-"$'\u9f8b\u75c5'"_"$'\u4e25\u683c\u7259\u9f88\u9650\u5b9a\u590d\u523b'"）/source_data/GSE164241_healthy_gingiva_RAW"
DS="/e/"$'\u8840\u6e05\u7ef4\u751f\u7d20'"/"$'\u8f93\u51fa'"/20260723-"$'\u9636\u6bb5'"11（"$'\u7ef4\u751f\u7d20'"D-"$'\u7259\u9f88'"-"$'\u9f8b\u75c5'"_"$'\u4e25\u683c\u7259\u9f88\u9650\u5b9a\u590d\u523b'"）/source_data/GSE164241_diseased_gingiva_RAW"
DST="/e/"$'\u8840\u6e05\u7ef4\u751f\u7d20'"/"$'\u8f93\u51fa'"/20260816_Figure2-5_pipeline"$'\u590d\u73b0'"/00_data_10x"

healthy=(GSM5005048_GM136 GSM5005049_GM143 GSM5005050_GM144 GSM5005051_GM147 GSM5005052_GM148 GSM5005053_GM183 GSM5005054_GM184a GSM5005055_GM238 GSM5005056_GM241 GSM5005057_GM242 GSM5177039_GM169 GSM5177040_GM283 GSM5177041_GM289)

diseased=(GSM5005058_PD134 GSM5005059_PD153 GSM5005060_PD161 GSM5005061_PD161b GSM5005062_PD164 GSM5177042_PD164b GSM5177043_PD164c GSM5177044_PD170)

copy_one() {
  local src="$1" dst="$2" prefix="$3"
  mkdir -p "$dst"
  cp "$src/${prefix}_barcodes.tsv.gz" "$dst/barcodes.tsv.gz"
  if [ -f "$src/${prefix}_features.tsv.gz" ]; then
    cp "$src/${prefix}_features.tsv.gz" "$dst/features.tsv.gz"
  else
    cp "$src/${prefix}_genes.tsv.gz"    "$dst/features.tsv.gz"
  fi
  cp "$src/${prefix}_matrix.mtx.gz"    "$dst/matrix.mtx.gz"
}

i=1
for p in "${healthy[@]}"; do
  copy_one "$HD" "$DST/GM$i" "$p"
  i=$((i+1))
done

i=1
for p in "${diseased[@]}"; do
  copy_one "$DS" "$DST/PD$i" "$p"
  i=$((i+1))
done

echo "=== reorganized folders ==="
ls "$DST"
echo "=== sample GM/PD counts ==="
echo "GM: $(ls -d "$DST"/GM* | wc -l)   PD: $(ls -d "$DST"/PD* | wc -l)"
echo "=== verify one folder (GM1) ==="
ls -la "$DST/GM1"
