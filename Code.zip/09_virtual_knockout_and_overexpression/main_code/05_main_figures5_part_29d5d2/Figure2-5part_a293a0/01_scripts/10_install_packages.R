args <- commandArgs(trailingOnly = TRUE)
lib1 <- args[1]   
lib2 <- args[2]   
proj_lib <- args[3]  

dir.create(proj_lib, recursive = TRUE, showWarnings = FALSE)
.libPaths(c(lib1, lib2, proj_lib, "C:/Users/Lin/AppData/Local/R/win-library/4.5", .libPaths()))
options(Ncpus = 4, repos = "https://cloud.r-project.org")
cat("proj_lib =", proj_lib, "\n")
cat("libPaths:\n"); print(.libPaths())
cat("Seurat present:", requireNamespace("Seurat", quietly = TRUE),
    as.character(utils::packageVersion("Seurat")), "\n")

logf <- file.path(proj_lib, "..", "03_logs", "install_packages.log")
zz <- file(logf, open = "wt", encoding = "UTF-8")
sink(zz, type = "output", split = TRUE)
sink(zz, type = "message", append = TRUE)

cat("===== INSTALL START", as.character(Sys.time()), "=====\n")

safe <- function(name, expr) {
  r <- tryCatch({ force(expr); "OK" },
                error = function(e) paste("FAIL:", conditionMessage(e)))
  cat(sprintf("[%s] %s\n", r, name))
  flush.console()
}

safe("ggpubr(CRAN)", install.packages("ggpubr", lib = proj_lib))
safe("Bioc deps", BiocManager::install(
  c("org.Hs.eg.db", "WGCNA", "Nebulosa", "GSVA", "limma", "monocle", "ggrepel", "DOSE"),
  lib = proj_lib, ask = FALSE, update = FALSE))
safe("CellChat(github)", remotes::install_github("jinworks/CellChat", lib = proj_lib, upgrade = "never"))
safe("scMetabolism(github)", remotes::install_github("wu-yc/scMetabolism", lib = proj_lib, upgrade = "never"))

cat("===== INSTALL DONE", as.character(Sys.time()), "=====\n")
cat("Loaded-check:\n")
for (p in c("ggpubr","org.Hs.eg.db","WGCNA","Nebulosa","GSVA","monocle","CellChat","scMetabolism"))
  cat(sprintf("  %s = %s\n", p, requireNamespace(p, quietly = TRUE)))
sink(type = "message"); sink()
