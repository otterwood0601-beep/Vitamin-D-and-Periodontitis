args <- commandArgs(trailingOnly = TRUE)
lib1 <- args[1]; lib2 <- args[2]; proj_lib <- args[3]; root <- args[4]
.libPaths(c(lib1, lib2, proj_lib,
            "C:/Users/Lin/AppData/Local/R/win-library/4.5", .libPaths()))
suppressPackageStartupMessages(library(Seurat))
suppressPackageStartupMessages(library(ggplot2))
suppressPackageStartupMessages(library(patchwork))
suppressPackageStartupMessages(library(dplyr))
suppressPackageStartupMessages(library(ggpubr))
suppressPackageStartupMessages(library(clusterProfiler))
suppressPackageStartupMessages(library(org.Hs.eg.db))

fig_dir  <- file.path(root, "02_figures")
rds_dir  <- file.path(root, "04_rds")
data_dir <- file.path(root, "00_data_10x")
gen_dir  <- file.path(root, "00_genelists")
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(rds_dir, recursive = TRUE, showWarnings = FALSE)

logf <- file.path(root, "03_logs", "pipeline.log")
zz <- file(logf, open = "wt", encoding = "UTF-8")
sink(zz, type = "output", split = TRUE); sink(zz, type = "message", append = TRUE)
on.exit({ try(sink(type="message"), silent=TRUE); try(sink(type="output"), silent=TRUE); try(close(zz), silent=TRUE) }, add=TRUE)
cat("===== PIPELINE START", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "=====\n")
cat("R:", R.version.string, " Seurat:", as.character(packageVersion("Seurat")), "\n")

annotate_by_markers <- function(obj, marker_list, slot = "data") {
  mat <- as.matrix(GetAssayData(obj, slot = slot))
  Idents(obj) <- "seurat_clusters"
  cl <- sort(unique(Idents(obj)))
  score <- matrix(0, nrow = length(cl), ncol = length(marker_list))
  rownames(score) <- cl; colnames(score) <- names(marker_list)
  for (i in seq_along(cl)) {
    cells <- colnames(obj)[WhichCells(obj, idents = cl[i])]
    sub <- mat[, cells, drop = FALSE]
    for (j in seq_along(marker_list)) {
      gs <- intersect(marker_list[[j]], rownames(sub))
      if (length(gs) > 0) score[i, j] <- mean(colMeans(sub[gs, , drop = FALSE]))
    }
  }
  
  best <- apply(score, 1, function(r) {
    if (max(r, na.rm = TRUE) <= 0) return("Others")
    names(sort(r, decreasing = TRUE))[1]
  })
  best
}

samples <- c(paste0("GM", 1:13), paste0("PD", 1:8))
cond_of <- function(s) if (grepl("^GM", s)) "Healthy" else "Periodontitis"
scRNAlist <- list()
for (s in samples) {
  p <- file.path(data_dir, s)
  if (!dir.exists(p)) { cat("!! \u7f3a\u5c11\u6837\u672c\u76ee\u5f55:", s, "\n"); next }
  counts <- Read10X(data.dir = p)
  so <- CreateSeuratObject(counts, min.cells = 3, min.features = 200,
                           project = s)
  so[["MT_percent"]] <- PercentageFeatureSet(so, pattern = "^MT-")
  so$Condition <- cond_of(s)
  scRNAlist[[s]] <- so
  cat("\u8bfb\u5165", s, "->", ncol(so), "cells\n")
}
cat("\u6837\u672c\u6570:", length(scRNAlist), "\n")

sc_int <- merge(scRNAlist[[1]], y = scRNAlist[-1])
cat("\u5408\u5e76\u540e\u7ec6\u80de\u6570:", ncol(sc_int), "\n")
sc_pbmc1 <- subset(sc_int, subset = nFeature_RNA > 200 & nFeature_RNA < 5000 &
                      MT_percent < 15 & nCount_RNA < 25000 & nCount_RNA > 1000)
cat("QC \u540e\u7ec6\u80de\u6570:", ncol(sc_pbmc1), "\n")
sc_pbmc1 <- NormalizeData(sc_pbmc1, normalization.method = "LogNormalize", block.size = 1000)
sc_pbmc1 <- FindVariableFeatures(sc_pbmc1, selection.method = "vst", nfeatures = 2000)
sc_pbmc1 <- ScaleData(sc_pbmc1, block.size = 1000)
sc_pbmc1 <- RunPCA(sc_pbmc1, npcs = 50, seed.use = 42)
sc_pbmc1 <- RunUMAP(sc_pbmc1, dims = 1:20, reduction = "pca", reduction.name = "umap.unintegrated")

for (i in seq_along(scRNAlist)) {
  scRNAlist[[i]] <- NormalizeData(scRNAlist[[i]])
  scRNAlist[[i]] <- FindVariableFeatures(scRNAlist[[i]], selection.method = "vst", nfeatures = 2000)
}
features <- SelectIntegrationFeatures(object.list = scRNAlist, nfeatures = 2000)
anchors <- FindIntegrationAnchors(object.list = scRNAlist, anchor.features = features,
                                  normalization.method = "LogNormalize", reduction = "cca")
sc_integrated <- IntegrateData(anchorset = anchors, normalization.method = "LogNormalize")
DefaultAssay(sc_integrated) <- "integrated"
sc_integrated <- ScaleData(sc_integrated, block.size = 1000)
sc_integrated <- RunPCA(sc_integrated, npcs = 50)
sc_integrated <- RunUMAP(sc_integrated, reduction = "pca", dims = 1:12)
sc_integrated <- FindNeighbors(sc_integrated, reduction = "pca", dims = 1:12)
sc_integrated <- FindClusters(sc_integrated, resolution = 0.2)
sc_pbmc1 <- sc_integrated
cat("\u6574\u5408\u540e\u805a\u7c7b\u6570:", length(unique(Idents(sc_pbmc1))), "\n")
saveRDS(sc_pbmc1, file.path(rds_dir, "sc_pbmc1_integrated.Rds"))

main_markers <- list(
  "Fibroblasts"      = c("COL1A1","DCN","PDGFRA","COL3A1","LUM"),
  "Endothelial cells"= c("PECAM1","CLDN5","VWF","ACKR1","PLVAP"),
  "Immune cells"     = c("PTPRC","CD3D","MS4A1","CD68","ITGAM","NKG7"),
  "Epithelial cells" = c("EPCAM","KRT14","KRT5","KRT8","KRT18"),
  "Others"           = c("ACTA2","RGS5","MCAM","TAGLN")
)
ann_main <- annotate_by_markers(sc_pbmc1, main_markers)
sc_pbmc1$Celltype   <- ann_main[as.character(Idents(sc_pbmc1))]
sc_pbmc1$Celltype   <- factor(sc_pbmc1$Celltype,
  levels = c("Fibroblasts","Endothelial cells","Immune cells","Epithelial cells","Others"))
sc_pbmc1$Condition  <- factor(sc_pbmc1$Condition, levels = c("Healthy","Periodontitis"))
cat("\u5168\u56fe\u8c31\u7ec6\u80de\u7c7b\u578b\u5206\u5e03:\n"); print(table(sc_pbmc1$Celltype))

cols5 <- c("#5e3a00","#c04093","#7b8443","#477f8c","#ffbe4e")

p2a <- DimPlot(sc_pbmc1, reduction = "umap", label = FALSE, pt.size = 0.2, cols = cols5) +
  ggtitle("Cell types (integrated)")
ggsave(file.path(fig_dir, "Figure2A_celltype_umap.pdf"), p2a, width = 8, height = 6)

p2b <- DimPlot(sc_pbmc1, reduction = "umap", pt.size = 0.2, cols = cols5,
               split.by = "Condition") + ggtitle("Healthy vs Periodontitis")
ggsave(file.path(fig_dir, "Figure2B_condition_split.pdf"), p2b, width = 12, height = 5)

cellnum <- table(sc_pbmc1$Celltype, sc_pbmc1$Condition)
cell.prop <- as.data.frame(prop.table(cellnum))
colnames(cell.prop) <- c("Celltype","Condition","Proportion")
p2c <- ggplot(cell.prop, aes(Condition, Proportion, fill = Celltype)) +
  geom_bar(stat = "identity", position = "fill") +
  scale_fill_manual(values = cols5) + ggtitle("cell proportion") +
  theme_bw() + theme(axis.ticks.length = unit(0.2, "cm"))
ggsave(file.path(fig_dir, "Figure2C_cell_proportion.pdf"), p2c, width = 7, height = 5)

senmayo <- read.csv(file.path(gen_dir, "senmayo.csv"))
senmayo_genes <- as.character(senmayo$`Gene(human)`)
senmayo_genes <- intersect(senmayo_genes, rownames(sc_pbmc1))
sc_pbmc1 <- AddModuleScore(sc_pbmc1, features = list(senmayo_genes), name = "senmayo")
sen_col <- colnames(sc_pbmc1@meta.data)[grep("^senmayo", colnames(sc_pbmc1@meta.data))][1]
sc_pbmc1$SenMayo <- sc_pbmc1@meta.data[[sen_col]]
md <- sc_pbmc1@meta.data
p2d <- ggviolin(md, "Celltype", "SenMayo", color = "Condition",
               palette = c("#4979b6","#d9352a"), add = "mean_sd",
               error.plot = "crossbar", fill = "gray") +
  stat_compare_means(aes(group = Condition),
    symnum.args = list(cutpoints = c(0,0.0001,0.001,0.01,0.05,1),
      symbols = c("****","***","**","*","ns")),
    label = "p.signif", bracket.size = 0.5, tip.length = 0.02, hide.ns = FALSE) +
  RotatedAxis() + ggtitle("SenMayo senescence score")
ggsave(file.path(fig_dir, "Figure2D_senmayo_violin.pdf"), p2d, width = 9, height = 5)

sceFB <- subset(sc_pbmc1, Celltype == "Fibroblasts")
Idents(sceFB) <- "Condition"
deg <- FindMarkers(sceFB, ident.1 = "Periodontitis", ident.2 = "Healthy", min.pct = 0.01)
deg$SYMBOL <- rownames(deg)
need <- deg[, c("avg_log2FC","p_val")]
colnames(need) <- c("log2FoldChange","pvalue")
df <- bitr(need$SYMBOL, fromType = "SYMBOL", toType = "ENTREZID", OrgDb = "org.Hs.eg.db")
need <- merge(need, df, by = "SYMBOL")
geneList <- need$log2FoldChange; names(geneList) <- need$ENTREZID
geneList <- sort(geneList, decreasing = TRUE)
kk <- gseKEGG(geneList = geneList, organism = "hsa", pvalueCutoff = 0.25)
cat("KEGG GSEA \u547d\u4e2d\u901a\u8def\u6570:", ifelse(is.list(kk), nrow(kk@result), 0), "\n")
if (is.list(kk) && nrow(kk@result) > 0) {
  idx <- which(kk@result$Description == "Cellular senescence")[1]
  if (!is.na(idx)) {
    p2e <- gseaplot2(kk, geneSetID = rownames(kk@result)[idx], title = "Cellular senescence")
    ggsave(file.path(fig_dir, "Figure2E_GSEA_senescence.pdf"), p2e, width = 7, height = 5)
  }
  write.csv(kk@result, file.path(fig_dir, "Figure2E_KEGG_GSEA_table.csv"))
}
saveRDS(sceFB, file.path(rds_dir, "sceFB.Rds"))

sce <- subset(sc_pbmc1, Celltype == "Fibroblasts")
sce <- NormalizeData(sce, normalization.method = "LogNormalize", scale.factor = 10000)
sce <- FindVariableFeatures(sce, selection.method = "vst", nfeatures = 2000)
sce <- ScaleData(sce)
sce <- RunPCA(sce, features = VariableFeatures(object = sce))
sce <- FindNeighbors(sce, dims = 1:15)
sce <- FindClusters(sce, resolution = 0.1)
sce <- RunUMAP(sce, dims = 1:15)
cat("\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e9a\u7fa4\u6570:", length(unique(Idents(sce))), "\n")

fib_markers <- list(
  "EmFB"    = c("COL1A1","COL3A1","COL5A1","DCN","LUM","FBN1","POSTN"),
  "CD81+FB" = c("CD81","CD9","CD63","CDKN2A","CDKN1A","PCOLCE","ASPN"),
  "P-EmFB"  = c("MKI67","TOP2A","PCNA","COL1A1","COL3A1"),
  "MyFB"    = c("ACTA2","TAGLN","MYL9","MYH11","CNN1","PDGFRB"),
  "P-MyFB"  = c("ACTA2","MKI67","TOP2A","TAGLN"),
  "VFB"     = c("RGS5","MCAM","PDGFRB","CSPG4","NOTCH3"),
  "ImFB"    = c("HLA-DRA","HLA-DRB1","CXCL12","CCL2","IL6","VCAM1")
)
ann_fib <- annotate_by_markers(sce, fib_markers)
sce$Subtype <- ann_fib[as.character(Idents(sce))]
sce$Subtype <- factor(sce$Subtype, levels = names(fib_markers))
cat("\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e9a\u578b\u5206\u5e03:\n"); print(table(sce$Subtype))

sc_pbmc1$Subtype_from_fib <- sce$Subtype[match(colnames(sc_pbmc1), colnames(sce))]
cols7 <- c("#eb3fa3","#e7ad1d","#aacc54","#d96122","#3abc98","#374a9d","#7470b6")

p3a <- DimPlot(sce, reduction = "umap", pt.size = 0.2, cols = cols7) + ggtitle("Fibroblast subclusters")
ggsave(file.path(fig_dir, "Figure3A_fib_umap.pdf"), p3a, width = 7, height = 6)

p3b_num <- table(sce$Subtype, sce$Condition)
p3b_prop <- as.data.frame(prop.table(p3b_num))
colnames(p3b_prop) <- c("Subtype","Condition","Proportion")
p3b <- ggplot(p3b_prop, aes(Condition, Proportion, fill = Subtype)) +
  geom_bar(stat = "identity", position = "fill") + scale_fill_manual(values = cols7) +
  ggtitle("fibroblast subtype proportion") + theme_bw()
ggsave(file.path(fig_dir, "Figure3B_subtype_proportion.pdf"), p3b, width = 7, height = 5)

p3c <- ggviolin(sce@meta.data, "Subtype", "SenMayo", color = "Condition",
               palette = c("#4979b6","#d9352a"), add = "mean_sd",
               error.plot = "crossbar", fill = "gray") +
  stat_compare_means(aes(group = Condition),
    symnum.args = list(cutpoints = c(0,0.0001,0.001,0.01,0.05,1),
      symbols = c("****","***","**","*","ns")),
    label = "p.signif", bracket.size = 0.5, tip.length = 0.02, hide.ns = FALSE) +
  RotatedAxis() + ggtitle("SenMayo by fibroblast subtype")
ggsave(file.path(fig_dir, "Figure3C_subtype_senmayo.pdf"), p3c, width = 10, height = 5)

sce.markers <- FindAllMarkers(sce, only.pos = TRUE, test.use = "wilcox", slot = "data")
sce.markers1 <- subset(sce.markers, avg_log2FC >= 0.5)
write.csv(sce.markers, file.path(fig_dir, "Figure3D_markers.csv"))

if (requireNamespace("clusterProfiler", quietly = TRUE)) {
  gene_id <- bitr(sce.markers1$gene, fromType = "SYMBOL", toType = "ENTREZID", OrgDb = "org.Hs.eg.db")
  dataGO <- merge(gene_id, data.frame(gene = sce.markers1$gene, group = sce.markers1$cluster),
                  by.x = "SYMBOL", by.y = "gene")
  cGO <- compareCluster(ENTREZID ~ group, data = dataGO, fun = "enrichGO",
                        OrgDb = "org.Hs.eg.db", ont = "BP",
                        pAdjustMethod = "BH", pvalueCutoff = 0.05, qvalueCutoff = 0.05)
  if (nrow(cGO@compareClusterResult) > 0) {
    res <- cGO@compareClusterResult
    res$log10pvalue <- -log10(res$pvalue)
    p3d <- ggplot(res, aes(Description, Cluster)) +
      geom_point(aes(fill = log10pvalue, size = Count), shape = 21) +
      theme_bw() + theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
                         axis.text = element_text(color = "black", size = 10)) +
      scale_fill_gradient(low = "yellow", high = "purple") + labs(x = NULL, y = NULL) +
      coord_flip()
    ggsave(file.path(fig_dir, "Figure3D_GO_bubble.pdf"), p3d, width = 8, height = 10)
    write.csv(res, file.path(fig_dir, "Figure3D_GO_table.csv"))
  }
}

top20_c1 <- sce.markers1 %>% filter(cluster == 1) %>% slice_head(n = 20)
p3e <- DotPlot(sce, features = top20_c1$gene) +
  scale_color_gradientn(colors = c("#060b37","white","#c92233")) +
  theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), axis.text = element_text(size = 10))
ggsave(file.path(fig_dir, "Figure3E_dotplot_cluster1.pdf"), p3e, width = 10, height = 6)

if (requireNamespace("Nebulosa", quietly = TRUE)) {
  library(Nebulosa)
  p3f_dens <- plot_density(sce, "CD81") + ggtitle("CD81 density")
  ggsave(file.path(fig_dir, "Figure3F_CD81_density.pdf"), p3f_dens, width = 7, height = 6)
}
p3f <- DimPlot(sce, reduction = "umap", pt.size = 0.2, cols = cols7) + ggtitle("Fibroblast subtypes (7)")
ggsave(file.path(fig_dir, "Figure3F_subtype_umap.pdf"), p3f, width = 7, height = 6)
saveRDS(sce, file.path(rds_dir, "sce_fibroblasts.Rds"))

sasp <- read.csv(file.path(gen_dir, "sasp.csv"))
sasp_genes <- intersect(unique(as.character(sasp$gene)), rownames(sceFB))
if (length(sasp_genes) > 0) {
  Idents(sceFB) <- "Condition"
  ave <- AverageExpression(sceFB, features = sasp_genes, verbose = FALSE)$RNA
  ann_row <- data.frame(Group = factor(sasp$group[match(rownames(ave), sasp$gene)]))
  rownames(ann_row) <- rownames(ave)
  ann_color <- list(Group = c(Interleukins="#0089CF", Chemokines="#E889BD",
    Other_inflammatory_factors="#85B22E", Growth_factors="#39c6a0",
    Soluble_receptors="#ed8183", Proteases_regulators="#E29827", Insoluble_factors="#c3380d"))
  p4a <- pheatmap::pheatmap(ave, scale = "row", cellwidth = 14, cellheight = 12,
    cluster_cols = FALSE, cluster_rows = TRUE, main = "SASP (Healthy vs Periodontitis)",
    annotation_row = ann_row, annotation_colors = ann_color)
  ggsave(file.path(fig_dir, "Figure4A_SASP_heatmap.pdf"), p4a, width = 6, height = 10)
}

if (requireNamespace("monocle", quietly = TRUE)) {
  cat(">>> \u8fd0\u884c monocle \u62df\u65f6\u5e8f...\n")
  library(monocle)
  cnt <- as(as.matrix(GetAssayData(sce, slot = "counts")), "sparseMatrix")
  pd0 <- new("AnnotatedDataFrame", data = data.frame(row.names = colnames(cnt)))
  fd0 <- new("AnnotatedDataFrame", data = data.frame(gene_short_name = rownames(cnt), row.names = rownames(cnt)))
  cds <- newCellDataSet(cnt, phenoData = pd0, featureData = fd0, expressionFamily = negbinomial.size())
  cds <- estimateSizeFactors(cds); cds <- estimateDispersions(cds)
  cds <- detectGenes(cds, min_expr = 0.5)
  expressed_genes <- row.names(subset(fData(cds), num_cells_expressed >= 10))
  diff_res <- differentialGeneTest(cds[expressed_genes, ], fullModelFormulaStr = "~Subtype")
  ordering_genes <- row.names(subset(diff_res, qval < 1e-5))
  if (length(ordering_genes) > 800) ordering_genes <- ordering_genes[order(diff_res$qval[ordering_genes])[1:800]]
  cds <- setOrderingFilter(cds, ordering_genes)
  cds <- reduceDimension(cds, max_components = 2, method = "DDRTree")
  cds <- orderCells(cds)
  p4b <- plot_cell_trajectory(cds, color_by = "Subtype") + scale_color_manual(values = cols7)
  ggsave(file.path(fig_dir, "Figure4B_trajectory.pdf"), p4b, width = 8, height = 6)
  p4c <- plot_cell_trajectory(cds, color_by = "Pseudotime") + scale_color_viridis_c()
  ggsave(file.path(fig_dir, "Figure4C_pseudotime.pdf"), p4c, width = 8, height = 6)
  diff_pt <- differentialGeneTest(cds, fullModelFormulaStr = "~sm.ns(Pseudotime)", cores = 4)
  time_genes <- diff_pt %>% arrange(qval) %>% pull(gene_short_name)
  if (length(time_genes) > 0) {
    ph <- plot_pseudotime_heatmap(cds[time_genes, ], cores = 4, num_clusters = 4,
                                  return_heatmap = TRUE, hmcols = colorRampPalette(c("#2166ac","#f7f7f7","#b2182b"))(100))
    p4d <- ph$plot
    ggsave(file.path(fig_dir, "Figure4D_pseudotime_heatmap.pdf"), p4d, width = 10, height = 8)
    clustering <- data.frame(clusters = cutree(ph$tree_row, k = 4))
    rownames(clustering) <- rownames(ph$tree_row)
    cl3 <- rownames(clustering)[clustering$clusters == 3]
    if (length(cl3) > 0 && requireNamespace("clusterProfiler", quietly = TRUE)) {
      ego <- enrichGO(gene = cl3, OrgDb = org.Hs.eg.db, keyType = "SYMBOL",
                      ont = "BP", pvalueCutoff = 0.05, qvalueCutoff = 0.2, readable = TRUE)
      write.csv(ego@result, file.path(fig_dir, "Figure4E_cluster3_GO.csv"))
    }
  }
  saveRDS(cds, file.path(rds_dir, "cds_monocle.Rds"))
}

if (requireNamespace("scMetabolism", quietly = TRUE)) {
  cat(">>> \u8fd0\u884c scMetabolism...\n")
  library(scMetabolism)
  countexp <- sc.metabolism.Seurat(obj = sce, method = "VISION", imputation = FALSE,
                                   ncores = 2, metabolism.type = "KEGG")
  score <- countexp@assays$METABOLISM$score
  mdf <- data.frame(t(score), Subtype = sce$Subtype)
  avg <- aggregate(. ~ Subtype, data = mdf, mean)
  rownames(avg) <- avg$Subtype; avg <- avg[, -1]
  p4s <- pheatmap::pheatmap(t(scale(t(avg))), scale = "row", show_colnames = TRUE,
    main = "KEGG metabolism by subtype")
  ggsave(file.path(fig_dir, "Figure4S_metabolism.pdf"), p4s, width = 10, height = 12)
}

if (requireNamespace("CellChat", quietly = TRUE)) {
  cat(">>> \u8fd0\u884c CellChat...\n")
  library(CellChat)
  
  sc_pbmc1$Celltype2 <- ifelse(sc_pbmc1$Celltype == "Fibroblasts",
                                as.character(sc_pbmc1$Subtype_from_fib),
                                as.character(sc_pbmc1$Celltype))
  data.input <- GetAssayData(sc_pbmc1, slot = "data")
  meta <- data.frame(labels = sc_pbmc1$Celltype2, row.names = colnames(sc_pbmc1))
  cc <- createCellChat(object = data.input, meta = meta, group.by = "labels")
  cc <- addMeta(cc, meta = meta); cc <- setIdent(cc, ident.use = "labels")
  cc <- subsetData(cc)
  cc <- identifyOverExpressedGenes(cc)
  cc <- identifyOverExpressedInteractions(cc)
  cc <- projectData(cc, PPI.human)
  cc <- computeCommunProb(cc)
  cc <- filterCommunication(cc, min.cells = 10)
  cc <- computeCommunProbPathway(cc)
  cc <- aggregateNet(cc)
  p5 <- netVisual_aggregate(cc, weighting.graph = TRUE, label.edge = FALSE)
  ggsave(file.path(fig_dir, "Figure5_cellchat_network.pdf"), p5, width = 10, height = 8)
  saveRDS(cc, file.path(rds_dir, "cellchat.Rds"))
}

cat("===== PIPELINE DONE", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "=====\n")
cat("\u8f93\u51fa\u56fe\u4f4d\u4e8e:", fig_dir, "\n")
