args <- commandArgs(trailingOnly=TRUE)
proj <- args[1]
.libPaths(c(proj, .libPaths()))
cat("proj_lib =", proj, "\n")
cat("libPaths[1:3] =\n")
print(.libPaths()[1:3])
pkgs <- c("Seurat","WGCNA","monocle","ggrepel","VGAM","DDRTree","HSMMSingleCell",
          "GSVA","DOSE","Nebulosa","CellChat","scMetabolism","VISION","ggpubr",
          "org.Hs.eg.db","limma","BiocManager","remotes")
for(p in pkgs){
  ok <- suppressWarnings(tryCatch(requireNamespace(p, quietly=TRUE), error=function(e) FALSE))
  cat(sprintf("%-16s %s\n", p, if(isTRUE(ok)) "OK" else "MISSING"))
}
