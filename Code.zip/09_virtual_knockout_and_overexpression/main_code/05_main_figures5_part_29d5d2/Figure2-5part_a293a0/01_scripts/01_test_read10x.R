.libPaths(c(
  "/e/\u8840\u6e05\u7ef4\u751f\u7d20/\u8f93\u51fa/20260724-\u6700\u65b0\u7248\u8ba1\u5212\uff08\u7ef4\u751f\u7d20D-\u7259\u9f88-\u9f8b\u75c5_\u53c2\u8003\u6587\u732eFigure3-4\u590d\u7b97\uff09/source_data/R_library_Seurat4",
  "/e/\u8840\u6e05\u7ef4\u751f\u7d20/\u8f93\u51fa/20260723-\u9636\u6bb511\uff08\u7ef4\u751f\u7d20D-\u7259\u9f88-\u9f8b\u75c5_\u4e25\u683c\u7259\u9f88\u9650\u5b9a\u590d\u523b\uff09/source_data/R_library",
  "C:/Users/Lin/AppData/Local/R/win-library/4.5",
  .libPaths()
))
suppressPackageStartupMessages(library(Seurat))
cat("Seurat version:", as.character(packageVersion("Seurat")), "\n")
counts <- Read10X(data.dir = "/e/\u8840\u6e05\u7ef4\u751f\u7d20/\u8f93\u51fa/20260816_Figure2-5_pipeline\u590d\u73b0/00_data_10x/GM1")
cat("GM1 matrix dims: features =", nrow(counts), " cells =", ncol(counts), "\n")
cat("Read10X OK\n")
