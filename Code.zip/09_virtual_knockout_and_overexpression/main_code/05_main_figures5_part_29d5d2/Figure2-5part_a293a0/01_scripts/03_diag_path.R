args <- commandArgs(trailingOnly = TRUE)
for (i in seq_along(args)) {
  p <- args[i]
  cat("arg", i, " | exists=", file.exists(p),
      " | norm=", normalizePath(p, mustWork = FALSE), "\n")
  if (file.exists(p)) cat("   list.files:", paste(list.files(p)[1:5], collapse = ","), "\n")
}
cat("ASCII control exists(C:/Users/Lin):", file.exists("C:/Users/Lin"), "\n")
