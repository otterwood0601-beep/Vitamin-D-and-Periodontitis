$ErrorActionPreference = 'Stop'

$outputRoot = (Resolve-Path -LiteralPath (Split-Path -Parent $PSScriptRoot)).Path
$v15Root = "E:\$([char]0x8840)$([char]0x6E05)$([char]0x7EF4)$([char]0x751F)$([char]0x7D20)\$([char]0x4EE3)$([char]0x7801)\$([char]0x8FD0)$([char]0x884C)$([char]0x8F93)$([char]0x51FA)\20260825_GDF15$([char]0x865A)$([char]0x62DF)$([char]0x6572)$([char]0x9664)_ABCD$([char]0x6700)$([char]0x65B0)$([char]0x56DB)$([char]0x56FE)$([char]0x6C47)$([char]0x603B)_v15_A$([char]0x56FE)$([char]0x5408)$([char]0x5E76)$([char]0x9AD8)$([char]0x4EAE)$([char]0x7AD6)$([char]0x56FE)$([char]0x4F8B)"
$desktopRoot = "C:\Users\Lin\Desktop\$([char]0x6700)$([char]0x7EC8)$([char]0x6295)$([char]0x7A3F)$([char]0x6587)$([char]0x672C)\$([char]0x6B63)$([char]0x6587)$([char]0x56FE)\$([char]0x6B63)$([char]0x6587)$([char]0x56FE)5 $([char]0x865A)$([char]0x62DF)$([char]0x6572)$([char]0x9664)"
$rscript = 'C:\Program Files\R\R-4.5.3\bin\Rscript.exe'
$mappedDrive = 'X:'

foreach ($required in @($v15Root, $desktopRoot, $rscript)) {
    if (-not (Test-Path -LiteralPath $required)) { throw "Missing required path: $required" }
}

$figureRoot = Join-Path $outputRoot '01_figures'
$sourceRoot = Join-Path $outputRoot '02_source_data'
$qaRoot = Join-Path $outputRoot '04_QA'

function Get-FileRows {
    param([string]$Root)
    Get-ChildItem -LiteralPath $Root -File | Sort-Object Name | ForEach-Object {
        [pscustomobject]@{
            Name = $_.Name
            Path = $_.FullName
            Length = $_.Length
            LastWriteTime = $_.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss')
            SHA256 = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash
        }
    }
}

function Get-ProtectedHashes {
    param([string[]]$Paths)
    foreach ($path in $Paths) {
        $item = Get-Item -LiteralPath $path
        [pscustomobject]@{
            Path = $item.FullName
            Length = $item.Length
            SHA256 = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
        }
    }
}

$panelStems = @(
    "A$([char]0x56FE)_GDF15$([char]0x865A)$([char]0x62DF)$([char]0x6572)$([char]0x9664)$([char]0x6270)$([char]0x52A8)$([char]0x603B)$([char]0x89C8)_$([char]0x6700)$([char]0x7EC8)$([char]0x7248)",
    "B$([char]0x56FE)_TOP20$([char]0x5DEE)$([char]0x5F02)$([char]0x8C03)$([char]0x63A7)$([char]0x57FA)$([char]0x56E0)_$([char]0x6A2A)$([char]0x5411)$([char]0x6761)$([char]0x5F62)$([char]0x67F1)$([char]0x72B6)$([char]0x56FE)_$([char]0x6700)$([char]0x7EC8)$([char]0x7248)",
    "C$([char]0x56FE)_GDF15$([char]0x4E2D)$([char]0x5FC3)$([char]0x8C03)$([char]0x63A7)$([char]0x7F51)$([char]0x7EDC)_$([char]0x56FE)$([char]0x4F8B)$([char]0x7EB5)$([char]0x5411)$([char]0x6392)$([char]0x5217)_$([char]0x6700)$([char]0x7EC8)$([char]0x7248)"
)
$protectedFiles = @()
foreach ($stem in $panelStems) {
    foreach ($ext in @('pdf', 'svg', 'png')) {
        $protectedFiles += Join-Path $v15Root "$stem.$ext"
    }
}
$protectedFiles += Join-Path $sourceRoot 'D_GO_mechanism_terms_GeneRatio_input_v8.csv'
$protectedFiles += Join-Path $sourceRoot 'KEGG_all_terms_input.csv'
foreach ($path in $protectedFiles) {
    if (-not (Test-Path -LiteralPath $path)) { throw "Missing protected source: $path" }
}

$protectedBefore = @(Get-ProtectedHashes -Paths $protectedFiles)
$protectedBefore | Export-Csv -LiteralPath (Join-Path $qaRoot 'protected_sources_before.csv') -NoTypeInformation -Encoding UTF8

foreach ($stem in $panelStems) {
    foreach ($ext in @('pdf', 'svg', 'png')) {
        Copy-Item -LiteralPath (Join-Path $v15Root "$stem.$ext") -Destination (
            Join-Path $outputRoot "$stem.$ext"
        ) -Force
    }
}

$existingMappings = @(subst.exe)
if ($existingMappings -match ('^' + [regex]::Escape($mappedDrive) + '\:')) {
    throw "Drive $mappedDrive is already in use."
}

$mapped = $false
$oldOutputRoot = $env:GDF15_D_V16_OUTPUT_ROOT
try {
    & subst.exe $mappedDrive $outputRoot
    if ($LASTEXITCODE -ne 0) { throw "Unable to map $mappedDrive to the v16 output root." }
    $mapped = $true
    $env:GDF15_D_V16_OUTPUT_ROOT = 'X:/'

    & $rscript 'X:\03_code\01_make_D_add_KEGG.R'
    if ($LASTEXITCODE -ne 0) { throw "R script failed with exit code $LASTEXITCODE" }
}
finally {
    $env:GDF15_D_V16_OUTPUT_ROOT = $oldOutputRoot
    if ($mapped) { & subst.exe $mappedDrive /D | Out-Null }
}

$dEnglishStem = 'D_GO_BP_CC_MF_KEGG_integrated_bar_bubble_no_group_gaps'
$dChineseStem = "D$([char]0x56FE)_GO$([char]0x4E0E)KEGG$([char]0x529F)$([char]0x80FD)$([char]0x5BCC)$([char]0x96C6)_BP_CC_MF_KEGG_$([char]0x65E0)$([char]0x5206)$([char]0x7EC4)$([char]0x7A7A)$([char]0x4F4D)_$([char]0x6700)$([char]0x7EC8)$([char]0x7248)"
foreach ($ext in @('pdf', 'svg', 'png')) {
    Copy-Item -LiteralPath (Join-Path $figureRoot "$dEnglishStem.$ext") -Destination (
        Join-Path $outputRoot "$dChineseStem.$ext"
    ) -Force
}

$finalRows = @()
foreach ($index in 0..2) {
    $panel = @('A', 'B', 'C')[$index]
    $stem = $panelStems[$index]
    foreach ($ext in @('pdf', 'svg', 'png')) {
        $source = Join-Path $v15Root "$stem.$ext"
        $destination = Join-Path $outputRoot "$stem.$ext"
        $sourceHash = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
        $destinationHash = (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash
        $finalRows += [pscustomobject]@{
            Panel = $panel
            Version = 'unchanged from v15'
            Format = $ext.ToUpperInvariant()
            FinalFile = Split-Path -Leaf $destination
            Bytes = (Get-Item -LiteralPath $destination).Length
            SHA256 = $destinationHash
            SourcePath = $source
            IdenticalToSource = ($sourceHash -eq $destinationHash)
        }
    }
}
foreach ($ext in @('pdf', 'svg', 'png')) {
    $source = Join-Path $figureRoot "$dEnglishStem.$ext"
    $destination = Join-Path $outputRoot "$dChineseStem.$ext"
    $sourceHash = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
    $destinationHash = (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash
    $finalRows += [pscustomobject]@{
        Panel = 'D'
        Version = 'v16 - 21 GO terms plus 2 raw-P-significant KEGG pathways'
        Format = $ext.ToUpperInvariant()
        FinalFile = Split-Path -Leaf $destination
        Bytes = (Get-Item -LiteralPath $destination).Length
        SHA256 = $destinationHash
        SourcePath = $source
        IdenticalToSource = ($sourceHash -eq $destinationHash)
    }
}
$finalRows | Export-Csv -LiteralPath (Join-Path $outputRoot "$([char]0x56DB)$([char]0x56FE)$([char]0x7248)$([char]0x672C)$([char]0x4E0E)$([char]0x54C8)$([char]0x5E0C)$([char]0x6838)$([char]0x5BF9).csv") -NoTypeInformation -Encoding UTF8

if (@($finalRows | Where-Object IdenticalToSource -NE $true).Count -gt 0) {
    throw 'At least one final copy differs from its source.'
}

$desktopBefore = @(Get-FileRows -Root $desktopRoot)
$desktopBefore | Export-Csv -LiteralPath (Join-Path $qaRoot "desktop_$([char]0x6B63)$([char]0x6587)$([char]0x56FE)5_before.csv") -NoTypeInformation -Encoding UTF8

$oldDesktopD = Join-Path $desktopRoot "D$([char]0x56FE)_GO$([char]0x529F)$([char]0x80FD)$([char]0x5BCC)$([char]0x96C6)_BP_CC_MF_$([char]0x53BB)$([char]0x9664)$([char]0x5206)$([char]0x7EC4)$([char]0x7A7A)$([char]0x4F4D)_$([char]0x6700)$([char]0x7EC8)$([char]0x7248).pdf"
$newDesktopD = Join-Path $desktopRoot "$dChineseStem.pdf"
$newRootD = Join-Path $outputRoot "$dChineseStem.pdf"

if (Test-Path -LiteralPath $oldDesktopD) {
    Copy-Item -LiteralPath $oldDesktopD -Destination (
        Join-Path $qaRoot "desktop$([char]0x539F)D$([char]0x56FE)_$([char]0x589E)$([char]0x52A0)KEGG$([char]0x524D)$([char]0x5907)$([char]0x4EFD).pdf"
    ) -Force
}

$desktopPartial = "$newDesktopD.partial"
Copy-Item -LiteralPath $newRootD -Destination $desktopPartial -Force
if ((Get-FileHash -LiteralPath $newRootD -Algorithm SHA256).Hash -ne
    (Get-FileHash -LiteralPath $desktopPartial -Algorithm SHA256).Hash) {
    throw 'Desktop partial D copy hash mismatch.'
}
Move-Item -LiteralPath $desktopPartial -Destination $newDesktopD -Force

if ((Get-FileHash -LiteralPath $newRootD -Algorithm SHA256).Hash -ne
    (Get-FileHash -LiteralPath $newDesktopD -Algorithm SHA256).Hash) {
    throw 'Desktop final D copy hash mismatch.'
}

if ((Test-Path -LiteralPath $oldDesktopD) -and ($oldDesktopD -ne $newDesktopD)) {
    Remove-Item -LiteralPath $oldDesktopD -Force
}

$desktopAfter = @(Get-FileRows -Root $desktopRoot)
$desktopAfter | Export-Csv -LiteralPath (Join-Path $qaRoot "desktop_$([char]0x6B63)$([char]0x6587)$([char]0x56FE)5_after.csv") -NoTypeInformation -Encoding UTF8

$abcUnchanged = foreach ($stem in $panelStems) {
    $name = "$stem.pdf"
    $before = $desktopBefore | Where-Object Name -EQ $name
    $after = $desktopAfter | Where-Object Name -EQ $name
    [pscustomobject]@{
        Name = $name
        BeforeSHA256 = $before.SHA256
        AfterSHA256 = $after.SHA256
        Unchanged = ($null -ne $before -and $null -ne $after -and $before.SHA256 -eq $after.SHA256)
    }
}
$abcUnchanged | Export-Csv -LiteralPath (Join-Path $qaRoot 'desktop_ABC_unchanged_check.csv') -NoTypeInformation -Encoding UTF8

$desktopPdfCount = @(Get-ChildItem -LiteralPath $desktopRoot -File -Filter '*.pdf').Count
$desktopSync = [pscustomobject]@{
    DesktopFolder = $desktopRoot
    NewDFile = $newDesktopD
    NewDHashMatchesE = (
        (Get-FileHash -LiteralPath $newRootD -Algorithm SHA256).Hash -eq
        (Get-FileHash -LiteralPath $newDesktopD -Algorithm SHA256).Hash
    )
    OldDRemoved = -not (Test-Path -LiteralPath $oldDesktopD)
    ABCUnchanged = -not (@($abcUnchanged | Where-Object Unchanged -NE $true).Count)
    PdfCount = $desktopPdfCount
    ExpectedPdfCount = 4
    Pass = (
        -not (Test-Path -LiteralPath $oldDesktopD) -and
        -not (@($abcUnchanged | Where-Object Unchanged -NE $true).Count) -and
        $desktopPdfCount -eq 4
    )
}
$desktopSync | Export-Csv -LiteralPath (Join-Path $qaRoot 'desktop_sync_report.csv') -NoTypeInformation -Encoding UTF8
if (-not $desktopSync.Pass) { throw 'Desktop synchronization QA failed.' }

$protectedAfter = @(Get-ProtectedHashes -Paths $protectedFiles)
$protectedAfter | Export-Csv -LiteralPath (Join-Path $qaRoot 'protected_sources_after.csv') -NoTypeInformation -Encoding UTF8
$integrity = foreach ($beforeRow in $protectedBefore) {
    $afterRow = $protectedAfter | Where-Object Path -EQ $beforeRow.Path
    [pscustomobject]@{
        Path = $beforeRow.Path
        BeforeLength = $beforeRow.Length
        AfterLength = $afterRow.Length
        BeforeSHA256 = $beforeRow.SHA256
        AfterSHA256 = $afterRow.SHA256
        Unchanged = (
            $beforeRow.Length -eq $afterRow.Length -and
            $beforeRow.SHA256 -eq $afterRow.SHA256
        )
    }
}
$integrity | Export-Csv -LiteralPath (Join-Path $qaRoot 'protected_sources_integrity_check.csv') -NoTypeInformation -Encoding UTF8
if (@($integrity | Where-Object Unchanged -NE $true).Count -gt 0) {
    throw 'At least one protected source changed unexpectedly.'
}

Write-Output "Completed and synchronized: $outputRoot"
