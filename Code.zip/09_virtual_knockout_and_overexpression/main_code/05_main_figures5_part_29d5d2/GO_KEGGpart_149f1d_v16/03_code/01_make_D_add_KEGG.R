options(stringsAsFactors = FALSE, scipen = 999)

local_lib <- "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_enrichment"
if (dir.exists(local_lib)) .libPaths(c(local_lib, .libPaths()))

suppressPackageStartupMessages({
  library(ggplot2)
  library(scales)
  library(svglite)
  library(ragg)
})

output_root <- Sys.getenv("GDF15_D_V16_OUTPUT_ROOT", unset = "")
if (!nzchar(output_root)) stop("Set GDF15_D_V16_OUTPUT_ROOT.")

figure_dir <- file.path(output_root, "01_figures")
source_dir <- file.path(output_root, "02_source_data")
qa_dir <- file.path(output_root, "04_QA")
png_tmp_dir <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/_\u4e34\u65f6\u8fd0\u884c\u533a/codex_tmp/gdf15_d_v16_png"
for (d in c(figure_dir, source_dir, qa_dir, png_tmp_dir)) {
  dir.create(d, recursive = TRUE, showWarnings = FALSE)
}

write_csv_utf8 <- function(x, path) {
  write.csv(x, path, row.names = FALSE, na = "", fileEncoding = "UTF-8")
}

parse_ratio <- function(x) {
  vapply(strsplit(as.character(x), "/", fixed = TRUE), function(parts) {
    if (length(parts) != 2L) return(NA_real_)
    as.numeric(parts[1]) / as.numeric(parts[2])
  }, numeric(1))
}

wrap_label <- function(x, width = 60L) {
  vapply(x, function(label) {
    paste(strwrap(label, width = width), collapse = "\n")
  }, character(1))
}

as_numeric_safe <- function(x) suppressWarnings(as.numeric(as.character(x)))

go_path <- file.path(source_dir, "D_GO_mechanism_terms_GeneRatio_input_v8.csv")
kegg_path <- file.path(source_dir, "KEGG_all_terms_input.csv")
if (!file.exists(go_path)) stop("Missing GO source: ", go_path)
if (!file.exists(kegg_path)) stop("Missing KEGG source: ", kegg_path)

go_input <- read.csv(go_path, check.names = FALSE, fileEncoding = "UTF-8")
kegg_all <- read.csv(kegg_path, check.names = FALSE, fileEncoding = "UTF-8")

required_go <- c(
  "Ontology", "OntologyTitle", "ID", "Description", "GeneRatio",
  "Count", "pvalue", "p.adjust", "geneID"
)
required_kegg <- c(
  "ID", "Description", "GeneRatio", "Count", "pvalue", "p.adjust", "geneID"
)
missing_go <- setdiff(required_go, names(go_input))
missing_kegg <- setdiff(required_kegg, names(kegg_all))
if (length(missing_go)) stop("GO source missing columns: ", paste(missing_go, collapse = ", "))
if (length(missing_kegg)) stop("KEGG source missing columns: ", paste(missing_kegg, collapse = ", "))

go_focus <- data.frame(
  Ontology = as.character(go_input$Ontology),
  OntologyTitle = as.character(go_input$OntologyTitle),
  ID = as.character(go_input$ID),
  DescriptionOriginal = as.character(go_input$Description),
  Description = as.character(go_input$Description),
  GeneRatio = as.character(go_input$GeneRatio),
  GeneRatioNumeric = if ("GeneRatioNumeric" %in% names(go_input)) {
    as_numeric_safe(go_input$GeneRatioNumeric)
  } else {
    parse_ratio(go_input$GeneRatio)
  },
  Count = as_numeric_safe(go_input$Count),
  pvalue = as_numeric_safe(go_input$pvalue),
  p.adjust = as_numeric_safe(go_input$p.adjust),
  qvalue = if ("qvalue" %in% names(go_input)) as_numeric_safe(go_input$qvalue) else NA_real_,
  geneID = as.character(go_input$geneID),
  NarrativeStage = if ("NarrativeStage" %in% names(go_input)) {
    as.character(go_input$NarrativeStage)
  } else {
    "GO term linked to MAPK response or ECM remodeling"
  },
  SelectionRationale = if ("SelectionRationale" %in% names(go_input)) {
    as.character(go_input$SelectionRationale)
  } else {
    "Previously approved GO term"
  },
  SelectionPriority = if ("SelectionPriority" %in% names(go_input)) {
    as_numeric_safe(go_input$SelectionPriority)
  } else {
    seq_len(nrow(go_input))
  },
  stringsAsFactors = FALSE
)

kegg_all$pvalue <- as_numeric_safe(kegg_all$pvalue)
kegg_all$p.adjust <- as_numeric_safe(kegg_all$p.adjust)
kegg_all$Count <- as_numeric_safe(kegg_all$Count)
kegg_all$GeneRatioNumeric <- parse_ratio(kegg_all$GeneRatio)

kegg_selected <- kegg_all[kegg_all$pvalue < 0.05, , drop = FALSE]
kegg_selected <- kegg_selected[
  order(-kegg_selected$GeneRatioNumeric, kegg_selected$pvalue, kegg_selected$Description),
  , drop = FALSE
]

expected_kegg <- c("APOPTOSIS", "AXON GUIDANCE")
if (!setequal(as.character(kegg_selected$ID), expected_kegg)) {
  stop(
    "Unexpected raw-P-significant KEGG set: ",
    paste(as.character(kegg_selected$ID), collapse = ", ")
  )
}

kegg_focus <- data.frame(
  Ontology = "KEGG",
  OntologyTitle = "KEGG Pathway",
  ID = as.character(kegg_selected$ID),
  DescriptionOriginal = as.character(kegg_selected$Description),
  Description = tolower(as.character(kegg_selected$Description)),
  GeneRatio = as.character(kegg_selected$GeneRatio),
  GeneRatioNumeric = as_numeric_safe(kegg_selected$GeneRatioNumeric),
  Count = as_numeric_safe(kegg_selected$Count),
  pvalue = as_numeric_safe(kegg_selected$pvalue),
  p.adjust = as_numeric_safe(kegg_selected$p.adjust),
  qvalue = if ("qvalue" %in% names(kegg_selected)) {
    as_numeric_safe(kegg_selected$qvalue)
  } else {
    NA_real_
  },
  geneID = as.character(kegg_selected$geneID),
  NarrativeStage = ifelse(
    as.character(kegg_selected$ID) == "APOPTOSIS",
    "MAPK/stress-response related",
    "ECM-remodeling/cell-guidance related"
  ),
  SelectionRationale = ifelse(
    as.character(kegg_selected$ID) == "APOPTOSIS",
    "Raw P < 0.05; PIK3R1/MCL1/NFKBIA connect the perturbation to stress-response and survival signaling.",
    "Raw P < 0.05; PIK3R1/SLIT3/WNT5A connect the perturbation to cell guidance, migration and ECM remodeling."
  ),
  SelectionPriority = seq_len(nrow(kegg_selected)),
  stringsAsFactors = FALSE
)

combined <- rbind(go_focus, kegg_focus)
combined$Category <- factor(
  as.character(combined$Ontology),
  levels = c("BP", "CC", "MF", "KEGG")
)
category_index <- c(BP = 1L, CC = 2L, MF = 3L, KEGG = 4L)
combined$CategoryIndex <- unname(category_index[as.character(combined$Category)])

if (anyNA(combined$CategoryIndex)) stop("Unexpected category in Figure D.")
if (anyNA(combined$GeneRatioNumeric)) stop("Missing GeneRatioNumeric values.")
if (any(combined$pvalue >= 0.05)) stop("Figure D requires raw P < 0.05 for every term.")

combined <- combined[
  order(
    combined$CategoryIndex,
    -combined$GeneRatioNumeric,
    combined$pvalue,
    combined$Description
  ),
  , drop = FALSE
]
rownames(combined) <- NULL
combined$RankWithinCategory <- ave(
  seq_len(nrow(combined)), combined$Category, FUN = seq_along
)
combined$RawP_lt_0_05 <- combined$pvalue < 0.05
combined$BH_FDR_lt_0_05 <- combined$p.adjust < 0.05
combined$SignificanceRule <- "raw P < 0.05"
combined$DescriptionWrapped <- wrap_label(combined$Description, width = 60L)
combined$TermKey <- paste(
  as.character(combined$Category),
  combined$DescriptionWrapped,
  sep = "___"
)
combined$DisplayPositionTopToBottom <- seq_len(nrow(combined))

term_order_no_gaps <- combined$TermKey
combined$term_factor <- factor(combined$TermKey, levels = rev(term_order_no_gaps))

category_colors <- c(
  BP = "#C8DEE5",
  CC = "#F0DDB6",
  MF = "#DCC8DD",
  KEGG = "#C9DFC2"
)
p_limits <- range(combined$pvalue)
count_limits <- range(combined$Count)
base_family <- "Arial"
paper_text <- "#4A1717"

p_d <- ggplot(combined, aes(x = GeneRatioNumeric, y = term_factor)) +
  geom_col(aes(fill = Category), width = 0.72, alpha = 0.74) +
  geom_point(
    aes(colour = pvalue, size = Count),
    shape = 16, alpha = 0.96
  ) +
  scale_fill_manual(
    values = category_colors,
    breaks = c("BP", "CC", "MF", "KEGG"),
    drop = FALSE,
    name = "Category"
  ) +
  scale_colour_gradient(
    low = "#E7645D", high = "#1285B5", limits = p_limits,
    breaks = scales::pretty_breaks(n = 4),
    labels = scales::label_number(accuracy = 0.001),
    name = "pvalue"
  ) +
  scale_size_continuous(
    limits = count_limits, range = c(3.0, 8.5),
    breaks = c(5, 10, 15), name = "Count"
  ) +
  scale_x_continuous(
    limits = c(0, max(combined$GeneRatioNumeric) * 1.08),
    breaks = scales::pretty_breaks(n = 5),
    labels = scales::label_number(accuracy = 0.01),
    expand = expansion(mult = c(0, 0.01))
  ) +
  scale_y_discrete(
    limits = rev(term_order_no_gaps),
    drop = FALSE,
    labels = function(x) sub("^(BP|CC|MF|KEGG)___", "", x)
  ) +
  labs(x = "Gene ratio", y = NULL) +
  guides(
    fill = guide_legend(
      order = 1, ncol = 1, byrow = TRUE,
      override.aes = list(alpha = 0.85)
    ),
    colour = guide_colourbar(
      order = 2, title.position = "top",
      barheight = grid::unit(34, "mm"),
      barwidth = grid::unit(4.5, "mm")
    ),
    size = guide_legend(order = 3, ncol = 1, byrow = TRUE)
  ) +
  theme_minimal(base_family = base_family, base_size = 9.5) +
  theme(
    plot.background = element_rect(fill = "white", colour = NA),
    panel.background = element_rect(fill = "white", colour = NA),
    panel.border = element_blank(),
    panel.grid.major.x = element_line(
      colour = "#D9DEDF", linewidth = 0.38, linetype = "dashed"
    ),
    panel.grid.major.y = element_blank(),
    panel.grid.minor = element_blank(),
    axis.text.y = element_text(
      colour = "#202020", size = 8.0, lineheight = 0.95
    ),
    axis.text.x = element_text(colour = paper_text, size = 9.0),
    axis.title.x = element_text(colour = paper_text, size = 11.0),
    axis.line.x = element_line(colour = "#686765", linewidth = 0.55),
    axis.line.y = element_blank(),
    axis.ticks.x = element_line(colour = "#686765"),
    axis.ticks.y = element_blank(),
    legend.position = "right",
    legend.box = "vertical",
    legend.direction = "vertical",
    legend.title = element_text(size = 8.5),
    legend.text = element_text(size = 7.6),
    legend.key.height = grid::unit(4.5, "mm"),
    plot.margin = margin(18, 10, 14, 10)
  )

stem <- "D_GO_BP_CC_MF_KEGG_integrated_bar_bubble_no_group_gaps"
pdf_path <- file.path(figure_dir, paste0(stem, ".pdf"))
svg_path <- file.path(figure_dir, paste0(stem, ".svg"))
png_path <- file.path(figure_dir, paste0(stem, ".png"))
png_tmp <- file.path(png_tmp_dir, paste0(stem, ".png"))

ggsave(
  pdf_path, plot = p_d, width = 12.0, height = 12.4, units = "in",
  device = grDevices::cairo_pdf, bg = "white"
)
ggsave(
  svg_path, plot = p_d, width = 12.0, height = 12.4, units = "in",
  device = svglite::svglite, bg = "white"
)
ggsave(
  png_tmp, plot = p_d, width = 12.0, height = 12.4, units = "in",
  device = ragg::agg_png, dpi = 600, bg = "white"
)
if (!file.copy(png_tmp, png_path, overwrite = TRUE)) {
  stop("Unable to copy PNG to output.")
}
unlink(png_tmp)

source_columns <- c(
  "DisplayPositionTopToBottom", "Category", "RankWithinCategory",
  "Ontology", "OntologyTitle", "ID", "DescriptionOriginal", "Description",
  "GeneRatio", "GeneRatioNumeric", "Count", "pvalue", "p.adjust", "qvalue",
  "geneID", "RawP_lt_0_05", "BH_FDR_lt_0_05", "SignificanceRule",
  "NarrativeStage", "SelectionRationale", "SelectionPriority"
)
source_out <- combined[, source_columns, drop = FALSE]
write_csv_utf8(
  source_out,
  file.path(source_dir, "D_GO_KEGG_mechanism_terms_GeneRatio_no_group_gaps_source.csv")
)

kegg_audit <- data.frame(
  ID = as.character(kegg_selected$ID),
  Description = tolower(as.character(kegg_selected$Description)),
  GeneRatio = as.character(kegg_selected$GeneRatio),
  GeneRatioNumeric = as_numeric_safe(kegg_selected$GeneRatioNumeric),
  Count = as_numeric_safe(kegg_selected$Count),
  pvalue = as_numeric_safe(kegg_selected$pvalue),
  p.adjust = as_numeric_safe(kegg_selected$p.adjust),
  geneID = as.character(kegg_selected$geneID),
  Included = TRUE,
  NarrativeStage = kegg_focus$NarrativeStage,
  SelectionRationale = kegg_focus$SelectionRationale,
  stringsAsFactors = FALSE
)
write_csv_utf8(kegg_audit, file.path(source_dir, "D_KEGG_selection_audit.csv"))

paths <- c(pdf_path, svg_path, png_path)
manifest <- data.frame(
  figure = stem,
  format = c("PDF", "SVG", "PNG"),
  relative_path = file.path("01_figures", basename(paths)),
  width_in = 12.0,
  height_in = 12.4,
  file_size_bytes = file.info(paths)$size,
  exists_nonempty = file.exists(paths) & file.info(paths)$size > 10000,
  stringsAsFactors = FALSE
)
write_csv_utf8(manifest, file.path(qa_dir, "D_figure_manifest.csv"))

qa <- data.frame(
  check_id = character(), check_name = character(), expected = character(),
  observed = character(), pass = logical(), stringsAsFactors = FALSE
)
add_qa <- function(check_id, check_name, expected, observed, pass) {
  qa <<- rbind(qa, data.frame(
    check_id = check_id,
    check_name = check_name,
    expected = as.character(expected),
    observed = as.character(observed),
    pass = isTRUE(pass),
    stringsAsFactors = FALSE
  ))
}

category_counts <- table(combined$Category)
within_category_descending <- all(vapply(
  split(combined$GeneRatioNumeric, combined$Category),
  function(x) all(diff(x) <= 1e-12), logical(1)
))
raw_sig_ids <- sort(as.character(kegg_all$ID[kegg_all$pvalue < 0.05]))
selected_ids <- sort(as.character(kegg_selected$ID))

add_qa("D01", "Term count", "23", nrow(combined), nrow(combined) == 23L)
add_qa(
  "D02", "Raw-P significance", "23/23 raw P < 0.05",
  paste0(sum(combined$pvalue < 0.05), "/", nrow(combined)),
  all(combined$pvalue < 0.05)
)
add_qa(
  "D03", "Category counts", "BP=12;CC=2;MF=7;KEGG=2",
  paste(names(category_counts), as.integer(category_counts), sep = "=", collapse = ";"),
  identical(as.integer(category_counts), c(12L, 2L, 7L, 2L))
)
add_qa(
  "D04", "Within-category GeneRatio order",
  "non-increasing within BP/CC/MF/KEGG", within_category_descending,
  within_category_descending
)
add_qa(
  "D05", "Category block order", "BP,CC,MF,KEGG",
  paste(as.character(unique(combined$Category)), collapse = ","),
  identical(as.character(unique(combined$Category)), c("BP", "CC", "MF", "KEGG"))
)
add_qa(
  "D06", "Spacer rows removed", "0 dummy gap levels",
  sum(grepl("^__GAP_", term_order_no_gaps)),
  !any(grepl("^__GAP_", term_order_no_gaps))
)
add_qa(
  "D07", "Only real terms on y-axis", "23 levels for 23 terms",
  paste(length(term_order_no_gaps), nrow(combined), sep = "/"),
  length(term_order_no_gaps) == nrow(combined)
)
add_qa(
  "D08", "All raw-P-significant KEGG terms retained", "exact match",
  paste(selected_ids, collapse = ";"), identical(raw_sig_ids, selected_ids)
)
add_qa(
  "D09", "No non-significant KEGG term displayed", "0",
  sum(kegg_focus$pvalue >= 0.05), all(kegg_focus$pvalue < 0.05)
)
add_qa(
  "D10", "Pure-white panel background", "white",
  p_d$theme$panel.background$fill,
  identical(p_d$theme$panel.background$fill, "white")
)
add_qa(
  "D11", "No outer panel border", "element_blank",
  class(p_d$theme$panel.border)[1],
  inherits(p_d$theme$panel.border, "element_blank")
)
add_qa(
  "D12", "No title/subtitle/caption", "all absent",
  paste(c(
    !is.null(p_d$labels$title),
    !is.null(p_d$labels$subtitle),
    !is.null(p_d$labels$caption)
  ), collapse = ";"),
  is.null(p_d$labels$title) &&
    is.null(p_d$labels$subtitle) &&
    is.null(p_d$labels$caption)
)
add_qa(
  "D13", "Expected D exports", "3 nonempty files",
  sum(manifest$exists_nonempty),
  nrow(manifest) == 3L && all(manifest$exists_nonempty)
)
add_qa(
  "D14", "BH-FDR significant displayed terms", "0",
  sum(combined$BH_FDR_lt_0_05), sum(combined$BH_FDR_lt_0_05) == 0L
)
write_csv_utf8(qa, file.path(qa_dir, "D_QA_checks.csv"))
capture.output(sessionInfo(), file = file.path(qa_dir, "R_sessionInfo.txt"))

if (any(!qa$pass)) stop("Critical QA failure; inspect 04_QA/D_QA_checks.csv")
cat("Completed Figure D with GO plus KEGG and zero category spacer rows.\n")
cat(
  "Terms:", nrow(combined),
  "| categories:", paste(names(category_counts), category_counts, collapse = ", "),
  "\n"
)
