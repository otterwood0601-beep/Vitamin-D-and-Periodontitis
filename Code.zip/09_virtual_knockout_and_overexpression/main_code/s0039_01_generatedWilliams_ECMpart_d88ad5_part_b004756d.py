from __future__ import annotations
import hashlib
import json
import math
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.patches import Rectangle
from matplotlib.ticker import MaxNLocator
import numpy as np
import pandas as pd
from scipy.interpolate import RBFInterpolator
from scipy.spatial.distance import cdist
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260907_Geneformer_GDF15_Williams_ECM\u5206\u72b6\u6001_\u6b63\u5f0f\u5750\u6807_\u539f\u59cb\u4e0e\u7ebf\u6027\u5e73\u6ed1_v1')
SOURCE = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260906_Geneformer_GDF15_KO_OE_Williams\u5168\u90e8\u7ec6\u80de_\u4e00\u6b21\u6027\u652f\u7ebf_v1\\\u6570\u636e\u8868\\Williams\u5168\u90e813257\u7ec6\u80de_GDF15_KO_OE\u654f\u611f\u6027.csv.gz')
REFERENCE_PDF = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u6b63\u6587\u56fe\\\u6b63\u6587\u56fe4 sc-RNA\\A.5\u79cd\u7ec6\u80de\u5206\u7c7b\u5730\u56fe.pdf')
FIG_DIR = ROOT / '\u56fe\u7247'
TABLE_DIR = ROOT / '\u6570\u636e\u8868'
QA_DIR = ROOT / 'QA'
ECM_LABEL = 'ECM remodeling'
SMOOTH_COVERAGE = 0.3
KO_RAW_STEM = '\u56fe2B_GDF15\u6572\u9664\u654f\u611f\u6027UMAP_Williams\u7259\u5468\u708e\u5168\u90e8ECM-remodeling\u7ec6\u80de_\u6b63\u5f0f\u5750\u6807_\u539f\u59cb\u503c'
KO_SMOOTH_STEM = '\u56fe2B_GDF15\u6572\u9664\u654f\u611f\u6027UMAP_Williams\u7259\u5468\u708e\u5168\u90e8ECM-remodeling\u7ec6\u80de_\u6b63\u5f0f\u5750\u6807_\u90bb\u57df\u7ebf\u6027\u5e73\u6ed1\u5c55\u793a\u7248'
OE_RAW_STEM = '\u56fe2C_GDF15\u8fc7\u8868\u8fbe\u654f\u611f\u6027UMAP_Williams\u5065\u5eb7\u5168\u90e8ECM-remodeling\u7ec6\u80de_\u6b63\u5f0f\u5750\u6807_\u539f\u59cb\u503c'

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def configure_style() -> None:
    plt.rcParams.update({'font.family': 'Arial', 'font.size': 9.0, 'axes.titlesize': 12.0, 'axes.labelsize': 11.0, 'xtick.labelsize': 8.5, 'ytick.labelsize': 8.5, 'axes.linewidth': 0.75, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none', 'savefig.facecolor': 'white'})

def truncated_colormap(name: str, low: float=0.1) -> LinearSegmentedColormap:
    base = plt.get_cmap(name)
    colors = base(np.linspace(low, 1.0, 256))
    return LinearSegmentedColormap.from_list(f'{name}_visible', colors)

def tight_limits(frame: pd.DataFrame) -> tuple[tuple[float, float], tuple[float, float]]:
    x = frame['UMAP_1'].to_numpy(float)
    y = frame['UMAP_2'].to_numpy(float)
    x_span = float(x.max() - x.min())
    y_span = float(y.max() - y.min())
    x_pad = max(0.1, x_span * 0.025)
    y_pad = max(0.1, y_span * 0.025)
    return ((float(x.min() - x_pad), float(x.max() + x_pad)), (float(y.min() - y_pad), float(y.max() + y_pad)))

def load_and_validate() -> tuple[pd.DataFrame, pd.DataFrame]:
    for directory in (FIG_DIR, TABLE_DIR, QA_DIR, QA_DIR / 'PDF\u6e32\u67d3\u68c0\u67e5'):
        directory.mkdir(parents=True, exist_ok=True)
    data = pd.read_csv(SOURCE)
    required = {'cell_id', 'dataset_index', 'disease', 'Study', 'Fibroblast_type', 'UMAP_1', 'UMAP_2', 'coordinate_source', 'projection_reason', 'GDF15_token_present', 'GDF15_KO_cosine_shift', 'GDF15_OE_cosine_shift'}
    missing = required.difference(data.columns)
    if missing:
        raise ValueError(f'Missing required columns: {sorted(missing)}')
    if set(data['Study'].astype(str)) != {'Williams'}:
        raise ValueError('The source is not Williams-only')
    if data['cell_id'].duplicated().any() or data['dataset_index'].duplicated().any():
        raise ValueError('Duplicated cells detected')
    ecm = data.loc[data['Fibroblast_type'].eq(ECM_LABEL)].copy()
    state_counts = ecm.groupby('disease').size().to_dict()
    if state_counts != {'normal': 1884, 'periodontitis': 552}:
        raise ValueError(f'Unexpected ECM state counts: {state_counts}')
    if set(ecm['coordinate_source'].astype(str)) != {'exact_formal_PDF'}:
        raise ValueError('At least one ECM cell does not use an exact coordinate from the formal PDF')
    if ecm['projection_reason'].notna().any():
        raise ValueError('Projected coordinates are present in the ECM subset')
    periodontitis = ecm.loc[ecm['disease'].eq('periodontitis')].copy()
    healthy = ecm.loc[ecm['disease'].eq('normal')].copy()
    periodontitis = periodontitis.sort_values('dataset_index', kind='stable').reset_index(drop=True)
    healthy = healthy.sort_values('dataset_index', kind='stable').reset_index(drop=True)
    ko = pd.to_numeric(periodontitis['GDF15_KO_cosine_shift'], errors='coerce')
    oe = pd.to_numeric(healthy['GDF15_OE_cosine_shift'], errors='coerce')
    if int(ko.notna().sum()) != 4:
        raise ValueError(f'Expected four executable periodontitis ECM KO cells, found {int(ko.notna().sum())}')
    if int(oe.notna().sum()) != len(healthy):
        raise ValueError('Healthy ECM OE is incomplete')
    return (periodontitis, healthy)

def make_linear_smoothed_ko(periodontitis: pd.DataFrame) -> pd.DataFrame:
    result = periodontitis.copy()
    xy = result[['UMAP_1', 'UMAP_2']].to_numpy(float)
    raw = pd.to_numeric(result['GDF15_KO_cosine_shift'], errors='coerce').to_numpy(float)
    observed = np.isfinite(raw)
    observed_xy = xy[observed]
    observed_values = raw[observed]
    interpolator = RBFInterpolator(observed_xy, observed_values, kernel='linear', smoothing=1e-06)
    estimated = interpolator(xy)
    estimated = np.clip(estimated, 0.0, float(observed_values.max()))
    estimated[observed] = raw[observed]
    nearest_distance = cdist(xy, observed_xy).min(axis=1)
    target_n = max(int(math.ceil(SMOOTH_COVERAGE * len(result))), int(observed.sum()))
    selected_order = np.argsort(nearest_distance, kind='stable')[:target_n]
    selected = np.zeros(len(result), dtype=bool)
    selected[selected_order] = True
    selected[observed] = True
    display = np.full(len(result), np.nan, dtype=float)
    display[selected] = estimated[selected]
    result['GDF15_KO_cosine_shift_linear_smoothed'] = estimated
    result['GDF15_KO_cosine_shift_smoothed_display'] = display
    result['distance_to_nearest_observed_KO_cell'] = nearest_distance
    result['raw_KO_observed'] = observed
    result['smoothed_display_colored'] = selected
    if int(selected.sum()) < int(math.ceil(SMOOTH_COVERAGE * len(result))):
        raise ValueError('Smoothed colored coverage is below 30%')
    return result

def draw_single_panel(frame: pd.DataFrame, value_column: str, raw_reference_column: str, title: str, cmap_name: str, panel_letter: str, stem: str) -> dict[str, object]:
    x = frame['UMAP_1'].to_numpy(float)
    y = frame['UMAP_2'].to_numpy(float)
    values = pd.to_numeric(frame[value_column], errors='coerce').to_numpy(float) * 1000.0
    raw_reference = pd.to_numeric(frame[raw_reference_column], errors='coerce').to_numpy(float) * 1000.0
    colored_mask = np.isfinite(values)
    raw_finite = raw_reference[np.isfinite(raw_reference)]
    vmax = max(float(np.quantile(raw_finite, 0.99)), 1e-09)
    xlim, ylim = tight_limits(frame)
    data_ratio = (xlim[1] - xlim[0]) / (ylim[1] - ylim[0])
    figure_height = 5.1
    figure_width = min(7.0, max(4.15, 1.05 + 4.25 * data_ratio))
    fig, ax = plt.subplots(figsize=(figure_width, figure_height), layout='constrained')
    base_size = 5.0 if len(frame) < 800 else 2.8
    color_size = 8.2 if len(frame) < 800 else 3.8
    ax.scatter(x, y, s=base_size, c='#DDDDDD', alpha=0.78, edgecolors='none', linewidths=0, zorder=1)
    order = np.flatnonzero(colored_mask)
    order = order[np.argsort(values[order], kind='stable')]
    cmap = truncated_colormap(cmap_name, low=0.1)
    norm = Normalize(vmin=0.0, vmax=vmax, clip=True)
    colored = ax.scatter(x[order], y[order], s=color_size, c=values[order], cmap=cmap, norm=norm, alpha=0.95, edgecolors='none', linewidths=0, zorder=2)
    ax.set_xlim(*xlim)
    ax.set_ylim(*ylim)
    ax.set_aspect('equal', adjustable='box')
    ax.set_title(title, fontweight='bold', pad=7)
    ax.set_xlabel('UMAP 1')
    ax.set_ylabel('UMAP 2')
    ax.grid(False)
    ax.set_facecolor('white')
    ax.margins(0)
    ax.tick_params(direction='out', length=3.2, width=0.7, color='#222222')
    ax.xaxis.set_major_locator(MaxNLocator(nbins=6))
    ax.yaxis.set_major_locator(MaxNLocator(nbins=6))
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_color('#222222')
    ax.spines['bottom'].set_color('#222222')
    ax.spines['left'].set_linewidth(0.75)
    ax.spines['bottom'].set_linewidth(0.75)
    ax.text(0.015, 0.985, panel_letter, transform=ax.transAxes, fontsize=17, va='top', ha='left')
    colorbar = fig.colorbar(colored, ax=ax, fraction=0.052, pad=0.025)
    if colorbar.solids is not None:
        colorbar.solids.remove()
    color_edges = np.linspace(0.0, vmax, 513)
    for lower, upper in zip(color_edges[:-1], color_edges[1:]):
        midpoint = 0.5 * (lower + upper)
        colorbar.ax.add_patch(Rectangle((0.0, lower), 1.0, upper - lower, facecolor=cmap(norm(midpoint)), edgecolor=cmap(norm(midpoint)), linewidth=0.0, zorder=0))
    colorbar.ax.set_title('Cosine shift\n(x10^3)', fontsize=9.0, pad=5)
    colorbar.ax.yaxis.set_major_locator(MaxNLocator(nbins=5))
    colorbar.ax.tick_params(labelsize=8, length=3, width=0.65)
    colorbar.outline.set_linewidth(0.65)
    outputs: dict[str, str] = {}
    for suffix, kwargs in (('pdf', {}), ('svg', {}), ('png', {'dpi': 600})):
        output = FIG_DIR / f'{stem}.{suffix}'
        fig.savefig(output, bbox_inches='tight', pad_inches=0.035, facecolor='white', **kwargs)
        outputs[suffix] = str(output)
    plt.close(fig)
    return {'displayed_cells': int(len(frame)), 'colored_cells': int(colored_mask.sum()), 'colored_fraction': float(colored_mask.mean()), 'raw_observed_cells': int(np.isfinite(raw_reference).sum()), 'xlim': list(xlim), 'ylim': list(ylim), 'color_scale_vmax_x1e3_q99_raw': vmax, 'outputs': outputs}

def write_documentation(periodontitis: pd.DataFrame, healthy: pd.DataFrame, smoothed: pd.DataFrame, panels: dict[str, dict[str, object]]) -> None:
    periodontitis.to_csv(TABLE_DIR / 'Williams\u7259\u5468\u708e\u5168\u90e8552\u4e2aECM-remodeling\u7ec6\u80de_GDF15_KO\u539f\u59cb\u503c.csv.gz', index=False, encoding='utf-8-sig', compression='gzip')
    healthy.to_csv(TABLE_DIR / 'Williams\u5065\u5eb7\u5168\u90e81884\u4e2aECM-remodeling\u7ec6\u80de_GDF15_OE\u539f\u59cb\u503c.csv.gz', index=False, encoding='utf-8-sig', compression='gzip')
    smoothed.to_csv(TABLE_DIR / 'Williams\u7259\u5468\u708e\u5168\u90e8552\u4e2aECM-remodeling\u7ec6\u80de_GDF15_KO\u90bb\u57df\u7ebf\u6027\u5e73\u6ed1.csv.gz', index=False, encoding='utf-8-sig', compression='gzip')
    smoothed_n = int(smoothed['smoothed_display_colored'].sum())
    qa = {'status': 'PASS', 'scope': 'Williams ECM remodeling fibroblasts separated by disease state', 'coordinate_validation': {'reference_pdf': str(REFERENCE_PDF), 'reference_pdf_sha256': sha256(REFERENCE_PDF), 'source_table': str(SOURCE), 'source_table_sha256': sha256(SOURCE), 'periodontitis_exact_formal_coordinates': int(periodontitis['coordinate_source'].eq('exact_formal_PDF').sum()), 'healthy_exact_formal_coordinates': int(healthy['coordinate_source'].eq('exact_formal_PDF').sum()), 'projected_ECM_coordinates': 0, 'crop_rule': 'Each disease-state panel is cropped to its own observed ECM coordinate extent plus 2.5% padding; aspect ratio remains 1:1.'}, 'populations': {'periodontitis_ECM': int(len(periodontitis)), 'healthy_ECM': int(len(healthy))}, 'perturbation': {'periodontitis_KO_raw_observed': int(periodontitis['GDF15_KO_cosine_shift'].notna().sum()), 'healthy_OE_raw_observed': int(healthy['GDF15_OE_cosine_shift'].notna().sum())}, 'smoothing': {'applies_only_to': 'periodontitis ECM GDF15 KO display', 'method': 'Linear radial-basis interpolation on exact formal UMAP coordinates, restricted to cells nearest an observed KO cell.', 'raw_anchor_cells': int(periodontitis['GDF15_KO_cosine_shift'].notna().sum()), 'target_fraction': SMOOTH_COVERAGE, 'colored_cells': smoothed_n, 'colored_fraction': float(smoothed_n / len(smoothed)), 'raw_values_preserved': True, 'smoothed_values_are_visualization_estimates': True}, 'palette': {'periodontitis_KO': 'Reds', 'healthy_OE': 'Blues'}, 'canvas_text_rule': 'The phrases raw values and neighborhood linear smoothing display version occur only in filenames and QA, never inside the figure canvas.', 'panels': panels}
    (QA_DIR / 'Williams_ECM\u5206\u72b6\u6001_\u6b63\u5f0f\u5750\u6807_\u539f\u59cb\u4e0e\u7ebf\u6027\u5e73\u6ed1_\u6570\u636e\u7248\u5f0f\u5ba1\u8ba1.json').write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding='utf-8')
    (ROOT / 'README_\u8bf7\u5148\u770b.md').write_text(f'# Williams ECM remodeling \u7ec6\u80de\u5206\u72b6\u6001 UMAP\n\n- \u7259\u5468\u708e\u56fe\u4ec5\u5305\u542b Williams \u7684 552 \u4e2a ECM remodeling \u6210\u7ea4\u7ef4\u7ec6\u80de\u3002\n- \u5065\u5eb7\u56fe\u4ec5\u5305\u542b Williams \u7684 1,884 \u4e2a ECM remodeling \u6210\u7ea4\u7ef4\u7ec6\u80de\u3002\n- 2,436 \u4e2a ECM \u7ec6\u80de\u7684\u5750\u6807\u5168\u90e8\u6765\u81ea\u6b63\u5f0f A.5 PDF\uff1b\u672c\u5b50\u96c6\u6ca1\u6709\u6295\u5f71\u5750\u6807\u3002\n- \u539f\u59cb KO \u56fe\u4ec5\u663e\u793a 4 \u4e2a\u771f\u5b9e\u53ef\u6267\u884c GDF15 token \u5220\u9664\u7ed3\u679c\u3002\n- \u7ebf\u6027\u5e73\u6ed1\u56fe\u663e\u793a {smoothed_n}/552 \u4e2a\u7ec6\u80de\uff08{smoothed_n / len(smoothed):.1%}\uff09\uff1b\u5e73\u6ed1\u503c\u53ea\u7528\u4e8e\u53ef\u89c6\u5316\uff0c\u4e0d\u66ff\u4ee3\u539f\u59cb\u7ed3\u679c\u3002\n- \u5e73\u6ed1\u8bf4\u660e\u4ec5\u5199\u5728\u6587\u4ef6\u540d\u548c QA \u4e2d\uff0c\u672a\u653e\u5165\u56fe\u9762\u3002\n- \u6240\u6709\u7248\u672c\u5747\u4e3a\u65b0\u6587\u4ef6\uff0c\u672a\u8986\u76d6\u6b64\u524d\u4e3b\u7ebf\u6216\u652f\u7ebf\u56fe\u3002\n', encoding='utf-8')

def main() -> None:
    configure_style()
    periodontitis, healthy = load_and_validate()
    smoothed = make_linear_smoothed_ko(periodontitis)
    panels = {'periodontitis_KO_raw': draw_single_panel(periodontitis, 'GDF15_KO_cosine_shift', 'GDF15_KO_cosine_shift', 'GDF15 knockout sensitivity', 'Reds', 'B', KO_RAW_STEM), 'periodontitis_KO_linear_smoothed': draw_single_panel(smoothed, 'GDF15_KO_cosine_shift_smoothed_display', 'GDF15_KO_cosine_shift', 'GDF15 knockout sensitivity', 'Reds', 'B', KO_SMOOTH_STEM), 'healthy_OE_raw': draw_single_panel(healthy, 'GDF15_OE_cosine_shift', 'GDF15_OE_cosine_shift', 'GDF15 overexpression sensitivity', 'Blues', 'C', OE_RAW_STEM)}
    write_documentation(periodontitis, healthy, smoothed, panels)
    print(json.dumps({'status': 'PASS', 'panels': panels}, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
