from __future__ import annotations
import argparse
import json
import math
from collections import Counter
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.colors as mcolors
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
import torch
import umap
from matplotlib.gridspec import GridSpec
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from scipy.stats import wilcoxon
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
from geneformer_core import AXIS_PRIORITY, ECM_PRIORITY, GDF15_ENSEMBL, GDF15_TOKEN_ID, MAPK_PRIORITY, MAX_LENGTH, SEED, batch_embeddings, bh_fdr, bootstrap_mean_ci, embed_variable_sequences, load_classifier, priority_class, set_deterministic, state_shift, stratified_sample_indices
from run_geneformer_pipeline import load_token_reference, load_tokenized
ROOT = Path('/work')
MODEL_OUT = ROOT / '02_\u72b6\u6001\u5206\u7c7b\u5668'
SCREEN_OUT = ROOT / '03_\u5168\u57fa\u56e0\u865a\u62df\u6572\u9664'
EXT_OUT = ROOT / '08_\u6269\u5c55\u56fe\u8868_PLOS_Frontiers\u540c\u578b'
TABLE_OUT = EXT_OUT / '\u6570\u636e\u8868'
FIG_OUT = EXT_OUT / '\u56fe\u7247'
QA_OUT = EXT_OUT / 'QA'
COHORTS = ['Williams', 'Caetano']
PLOS_URL = 'https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0344084'
FRONTIERS_URL = 'https://www.frontiersin.org/journals/immunology/articles/10.3389/fimmu.2026.1859310/full'

def ensure_dirs() -> None:
    for path in (TABLE_OUT, FIG_OUT, QA_OUT):
        path.mkdir(parents=True, exist_ok=True)

def paired_cosine_distance(original: np.ndarray, perturbed: np.ndarray) -> np.ndarray:
    numerator = np.einsum('ij,ij->i', original, perturbed)
    denominator = np.linalg.norm(original, axis=1) * np.linalg.norm(perturbed, axis=1)
    similarity = numerator / np.clip(denominator, 1e-12, None)
    return np.clip(1.0 - similarity, 0.0, None)

def make_perturbed_sequence(sequence: np.ndarray, mode: str) -> np.ndarray | None:
    sequence = np.asarray(sequence, dtype=np.int64).copy()
    if mode == 'delete':
        positions = np.flatnonzero(sequence == GDF15_TOKEN_ID)
        if len(positions) == 0:
            return None
        return np.delete(sequence, int(positions[0]))
    if mode == 'overexpress':
        sequence_without = sequence[sequence != GDF15_TOKEN_ID]
        return np.concatenate([np.asarray([GDF15_TOKEN_ID], dtype=np.int64), sequence_without])[:MAX_LENGTH]
    raise ValueError(f'Unsupported perturbation mode: {mode}')

def build_sequence_pairs(input_ids: np.ndarray, lengths: np.ndarray, indices: np.ndarray, mode: str) -> tuple[np.ndarray, list[np.ndarray], list[np.ndarray]]:
    retained: list[int] = []
    originals: list[np.ndarray] = []
    perturbed: list[np.ndarray] = []
    for raw_index in indices:
        index = int(raw_index)
        length = int(lengths[index])
        original = np.asarray(input_ids[index, :length], dtype=np.int64).copy()
        changed = make_perturbed_sequence(original, mode)
        if changed is None:
            continue
        retained.append(index)
        originals.append(original)
        perturbed.append(changed)
    return (np.asarray(retained, dtype=int), originals, perturbed)

def compute_cell_effect(cohort: str, model, input_ids: np.ndarray, lengths: np.ndarray, metadata: pd.DataFrame, indices: np.ndarray, mode: str, goal_centroid: np.ndarray, start_centroid: np.ndarray, scenario: str) -> tuple[pd.DataFrame, list[np.ndarray], list[np.ndarray]]:
    retained, originals, perturbed = build_sequence_pairs(input_ids, lengths, indices, mode)
    if len(retained) == 0:
        return (pd.DataFrame(), [], [])
    original_embeddings = embed_variable_sequences(model, originals, batch_size=8)
    perturbed_embeddings = embed_variable_sequences(model, perturbed, batch_size=8)
    shift_goal, shift_start = state_shift(original_embeddings, perturbed_embeddings, goal_centroid, start_centroid)
    cosine_shift = paired_cosine_distance(original_embeddings, perturbed_embeddings)
    result = metadata.loc[retained, ['dataset_index', 'cell_id', 'donor_id', 'disease', 'label']].copy().reset_index(drop=True)
    result.insert(0, 'cohort', cohort)
    result.insert(1, 'scenario', scenario)
    result['perturbation'] = mode
    result['Gene'] = GDF15_TOKEN_ID
    result['Gene_name'] = 'GDF15'
    result['Ensembl_ID'] = GDF15_ENSEMBL
    result['Shift_to_target'] = shift_goal.astype(float)
    result['Shift_away_source'] = shift_start.astype(float)
    result['Desirability_score'] = result['Shift_to_target'] - result['Shift_away_source']
    result['Cosine_shift'] = cosine_shift.astype(float)
    return (result, originals, perturbed)

def one_sided_positive_p(values: np.ndarray) -> float:
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    if len(values) == 0 or np.allclose(values, 0.0):
        return 1.0
    try:
        return float(wilcoxon(values, alternative='greater', zero_method='wilcox', method='auto').pvalue)
    except ValueError:
        return 1.0

def summarize_direction(frame: pd.DataFrame, scope: str) -> dict:
    x = frame['Shift_to_target'].to_numpy(dtype=float)
    y = frame['Shift_away_source'].to_numpy(dtype=float)
    cosine = frame['Cosine_shift'].to_numpy(dtype=float)
    low, high = bootstrap_mean_ci(x, SEED + len(frame))
    return {'Scope': scope, 'Scenario': str(frame['scenario'].iloc[0]), 'Start_state': 'Periodontitis' if str(frame['perturbation'].iloc[0]) == 'delete' else 'Healthy', 'Perturbation': 'GDF15 knockout' if str(frame['perturbation'].iloc[0]) == 'delete' else 'GDF15 overexpression', 'Target_state': 'Healthy' if str(frame['perturbation'].iloc[0]) == 'delete' else 'Periodontitis', 'Gene': 'GDF15', 'N_cells': int(len(frame)), 'N_donors': int(frame['donor_id'].nunique()), 'Shift_to_target': float(np.mean(x)), 'Shift_to_target_CI95_low': float(low), 'Shift_to_target_CI95_high': float(high), 'Shift_away_source': float(np.mean(y)), 'Mean_cosine_shift': float(np.mean(cosine)), 'Raw_P_one_sided': one_sided_positive_p(x), 'Desired_direction': bool(np.mean(x) > 0 and np.mean(y) < 0)}

def select_downstream_tokens(originals_by_scenario: dict[str, list[np.ndarray]], token_to_gene: dict[int, str]) -> set[int]:
    counts: Counter[int] = Counter()
    for sequences in originals_by_scenario.values():
        for sequence in sequences:
            counts.update((int(x) for x in sequence.tolist() if int(x) != GDF15_TOKEN_ID))
    axis_tokens = {token for token in counts if token_to_gene.get(int(token), '') in AXIS_PRIORITY}
    common_tokens = [token for token, _ in counts.most_common(190)]
    return set(common_tokens) | axis_tokens

def token_hidden_state_effects(cohort: str, scenario: str, model, metadata: pd.DataFrame, indices: np.ndarray, originals: list[np.ndarray], perturbed: list[np.ndarray], candidate_tokens: set[int], token_to_gene: dict[int, str], token_to_ensembl: dict[int, str], pair_batch_size: int=2) -> list[dict]:
    records: list[dict] = []
    model.eval()
    with torch.inference_mode():
        for start in range(0, len(indices), pair_batch_size):
            stop = min(start + pair_batch_size, len(indices))
            sequence_batch: list[np.ndarray] = []
            for i in range(start, stop):
                sequence_batch.extend([originals[i], perturbed[i]])
            max_len = max((len(x) for x in sequence_batch))
            ids = torch.zeros((len(sequence_batch), max_len), dtype=torch.long)
            mask = torch.zeros_like(ids)
            for row, sequence in enumerate(sequence_batch):
                ids[row, :len(sequence)] = torch.as_tensor(sequence, dtype=torch.long)
                mask[row, :len(sequence)] = 1
            hidden = model.bert(input_ids=ids, attention_mask=mask, return_dict=True).last_hidden_state.cpu().numpy()
            for offset, i in enumerate(range(start, stop)):
                original = originals[i]
                changed = perturbed[i]
                original_positions = {int(token): position for position, token in enumerate(original.tolist()) if int(token) in candidate_tokens}
                changed_positions = {int(token): position for position, token in enumerate(changed.tolist()) if int(token) in candidate_tokens}
                common = sorted(set(original_positions) & set(changed_positions))
                if not common:
                    continue
                op = np.asarray([original_positions[token] for token in common], dtype=int)
                cp = np.asarray([changed_positions[token] for token in common], dtype=int)
                original_hidden = hidden[2 * offset, op, :]
                changed_hidden = hidden[2 * offset + 1, cp, :]
                shifts = paired_cosine_distance(original_hidden, changed_hidden)
                cell_index = int(indices[i])
                cell_meta = metadata.loc[cell_index]
                for token, shift in zip(common, shifts.tolist()):
                    gene_name = token_to_gene.get(int(token), str(token))
                    records.append({'cohort': cohort, 'scenario': scenario, 'dataset_index': cell_index, 'cell_id': cell_meta['cell_id'], 'donor_id': cell_meta['donor_id'], 'Gene': int(token), 'Gene_name': gene_name, 'Ensembl_ID': token_to_ensembl.get(int(token), ''), 'Priority_class': priority_class(gene_name), 'Token_cosine_shift': float(shift)})
            print(f'[{cohort}] {scenario} downstream token evidence {stop}/{len(indices)} cells', flush=True)
    return records

def prepare_umap_sensitivity() -> None:
    ensure_dirs()
    input_ids, lengths, labels, metadata = load_tokenized('Williams')
    model = load_classifier(MODEL_OUT / 'Williams' / 'best_model')
    archive = np.load(MODEL_OUT / 'Williams' / 'embedding_samples.npz')
    base_indices = archive['dataset_indices'].astype(int)
    base_embeddings = archive['finetuned_embeddings'].astype(np.float32)
    all_positive = metadata.index[metadata['GDF15_token_present'].astype(bool)].to_numpy(dtype=int)
    missing = np.setdiff1d(all_positive, base_indices)
    if len(missing):
        missing_embeddings = batch_embeddings(model, input_ids, lengths, missing, batch_size=8)
        all_indices = np.concatenate([base_indices, missing])
        all_embeddings = np.vstack([base_embeddings, missing_embeddings])
    else:
        all_indices = base_indices
        all_embeddings = base_embeddings
    reducer = umap.UMAP(n_neighbors=15, min_dist=0.3, metric='cosine', random_state=SEED, n_jobs=1)
    coordinates = reducer.fit_transform(all_embeddings)
    ko_values = np.zeros(len(all_indices), dtype=float)
    ko_positions = np.flatnonzero(metadata.loc[all_indices, 'GDF15_token_present'].astype(bool).to_numpy())
    if len(ko_positions):
        _, originals, changed = build_sequence_pairs(input_ids, lengths, all_indices[ko_positions], 'delete')
        changed_embeddings = embed_variable_sequences(model, changed, batch_size=8)
        ko_values[ko_positions] = paired_cosine_distance(all_embeddings[ko_positions], changed_embeddings)
    result = metadata.loc[all_indices, ['dataset_index', 'cell_id', 'donor_id', 'disease', 'label', 'GDF15_token_present']].copy().reset_index(drop=True)
    result['UMAP_1'] = coordinates[:, 0]
    result['UMAP_2'] = coordinates[:, 1]
    result['GDF15_KO_cosine_shift'] = ko_values
    result['GDF15_OE_cosine_shift'] = np.nan
    result.to_csv(TABLE_OUT / 'Williams_GDF15_KO_OE_sensitivity_UMAP_base.csv', index=False, encoding='utf-8-sig')
    np.savez_compressed(TABLE_OUT / 'Williams_GDF15_UMAP_original_embeddings.npz', dataset_indices=all_indices, original_embeddings=all_embeddings)
    chunk_size = 96
    manifest = {'n_cells': int(len(all_indices)), 'chunk_size': chunk_size, 'n_chunks': int(math.ceil(len(all_indices) / chunk_size))}
    (QA_OUT / 'umap_oe_chunk_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(manifest, ensure_ascii=False), flush=True)

def compute_umap_oe_chunk(chunk_index: int, chunk_size: int=96) -> None:
    ensure_dirs()
    chunk_dir = QA_OUT / 'umap_oe_chunks'
    chunk_dir.mkdir(parents=True, exist_ok=True)
    archive = np.load(TABLE_OUT / 'Williams_GDF15_UMAP_original_embeddings.npz')
    all_indices = archive['dataset_indices'].astype(int)
    original_embeddings = archive['original_embeddings'].astype(np.float32)
    start = int(chunk_index) * int(chunk_size)
    stop = min(start + int(chunk_size), len(all_indices))
    if start >= len(all_indices):
        raise ValueError(f'chunk_index {chunk_index} starts after {len(all_indices)} cells')
    input_ids, lengths, labels, metadata = load_tokenized('Williams')
    model = load_classifier(MODEL_OUT / 'Williams' / 'best_model')
    indices = all_indices[start:stop]
    _, _, changed = build_sequence_pairs(input_ids, lengths, indices, 'overexpress')
    changed_embeddings = embed_variable_sequences(model, changed, batch_size=8)
    values = paired_cosine_distance(original_embeddings[start:stop], changed_embeddings)
    pd.DataFrame({'dataset_index': indices, 'GDF15_OE_cosine_shift': values, 'chunk_index': int(chunk_index)}).to_csv(chunk_dir / f'chunk_{chunk_index:04d}.csv', index=False, encoding='utf-8-sig')
    print(f'UMAP OE chunk {chunk_index}: {start}:{stop} written', flush=True)

def finalize_umap_sensitivity() -> None:
    ensure_dirs()
    base = pd.read_csv(TABLE_OUT / 'Williams_GDF15_KO_OE_sensitivity_UMAP_base.csv')
    manifest = json.loads((QA_OUT / 'umap_oe_chunk_manifest.json').read_text(encoding='utf-8'))
    chunk_files = [QA_OUT / 'umap_oe_chunks' / f'chunk_{i:04d}.csv' for i in range(manifest['n_chunks'])]
    missing = [str(path) for path in chunk_files if not path.exists()]
    if missing:
        raise FileNotFoundError(f'Missing UMAP OE chunks: {missing}')
    values = pd.concat([pd.read_csv(path) for path in chunk_files], ignore_index=True)
    if values['dataset_index'].duplicated().any() or len(values) != len(base):
        raise ValueError('UMAP OE chunks do not form a one-to-one complete set')
    base = base.drop(columns=['GDF15_OE_cosine_shift'], errors='ignore').merge(values[['dataset_index', 'GDF15_OE_cosine_shift']], on='dataset_index', how='left', validate='one_to_one')
    if base['GDF15_OE_cosine_shift'].isna().any():
        raise ValueError('Final UMAP contains missing OE sensitivity values')
    base.to_csv(TABLE_OUT / 'Williams_GDF15_KO_OE_sensitivity_UMAP.csv', index=False, encoding='utf-8-sig')
    print(f'Final UMAP sensitivity written for {len(base)} cells', flush=True)

def aggregate_downstream(raw: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict] = []
    for (scenario, cohort, token), group in raw.groupby(['scenario', 'cohort', 'Gene'], observed=True):
        rows.append({'scenario': scenario, 'cohort': cohort, 'Gene': int(token), 'Gene_name': group['Gene_name'].iloc[0], 'Ensembl_ID': group['Ensembl_ID'].iloc[0], 'Priority_class': group['Priority_class'].iloc[0], 'Mean_token_cosine_shift': float(group['Token_cosine_shift'].mean()), 'Median_token_cosine_shift': float(group['Token_cosine_shift'].median()), 'N_cells': int(group['dataset_index'].nunique()), 'N_donors': int(group['donor_id'].nunique())})
    for (scenario, token), group in raw.groupby(['scenario', 'Gene'], observed=True):
        rows.append({'scenario': scenario, 'cohort': 'Pooled', 'Gene': int(token), 'Gene_name': group['Gene_name'].iloc[0], 'Ensembl_ID': group['Ensembl_ID'].iloc[0], 'Priority_class': group['Priority_class'].iloc[0], 'Mean_token_cosine_shift': float(group['Token_cosine_shift'].mean()), 'Median_token_cosine_shift': float(group['Token_cosine_shift'].median()), 'N_cells': int(group['dataset_index'].nunique()), 'N_donors': int(group['donor_id'].nunique())})
    result = pd.DataFrame(rows)
    hit_frames: list[pd.DataFrame] = []
    for (scenario, cohort), group in result.loc[result['cohort'] != 'Pooled'].groupby(['scenario', 'cohort'], observed=True):
        cutoff = float(group['Mean_token_cosine_shift'].quantile(0.9))
        temp = group[['scenario', 'Gene']].copy()
        temp['Strong_hit'] = (group['Mean_token_cosine_shift'].to_numpy() >= cutoff).astype(int)
        hit_frames.append(temp)
    if hit_frames:
        hit_counts = pd.concat(hit_frames, ignore_index=True).groupby(['scenario', 'Gene'], as_index=False)['Strong_hit'].sum().rename(columns={'Strong_hit': 'N_strong_hits'})
        result = result.merge(hit_counts, on=['scenario', 'Gene'], how='left')
    result['N_strong_hits'] = result.get('N_strong_hits', 0).fillna(0).astype(int)
    return result.sort_values(['scenario', 'cohort', 'Mean_token_cosine_shift'], ascending=[True, True, False])

def compute_all() -> None:
    ensure_dirs()
    set_deterministic()
    _, token_to_gene, token_to_ensembl = load_token_reference()
    all_cell_frames: list[pd.DataFrame] = []
    all_summaries: list[dict] = []
    downstream_records: list[dict] = []
    for cohort in COHORTS:
        print(f'[{cohort}] loading tokenized data and fine-tuned classifier', flush=True)
        input_ids, lengths, labels, metadata = load_tokenized(cohort)
        model = load_classifier(MODEL_OUT / cohort / 'best_model')
        centroids = np.load(MODEL_OUT / cohort / 'state_centroids.npz')
        ko_indices = metadata.index[(metadata['label'] == 1) & metadata['GDF15_token_present'].astype(bool)].to_numpy(dtype=int)
        normal_meta = metadata.loc[metadata['label'] == 0]
        oe_indices = stratified_sample_indices(normal_meta, min(128, len(normal_meta)), ['donor_id'], SEED + 77)
        ko_frame, ko_originals, ko_perturbed = compute_cell_effect(cohort, model, input_ids, lengths, metadata, ko_indices, 'delete', centroids['normal'], centroids['periodontitis'], 'Periodontitis_GDF15_KO_to_Healthy')
        oe_frame, oe_originals, oe_perturbed = compute_cell_effect(cohort, model, input_ids, lengths, metadata, oe_indices, 'overexpress', centroids['periodontitis'], centroids['normal'], 'Healthy_GDF15_OE_to_Periodontitis')
        for frame in (ko_frame, oe_frame):
            if not frame.empty:
                all_cell_frames.append(frame)
                all_summaries.append(summarize_direction(frame, cohort))
        original_by_scenario = {'Periodontitis_GDF15_KO_to_Healthy': ko_originals, 'Healthy_GDF15_OE_to_Periodontitis': oe_originals}
        candidate_tokens = select_downstream_tokens(original_by_scenario, token_to_gene)
        downstream_records.extend(token_hidden_state_effects(cohort, 'Periodontitis_GDF15_KO_to_Healthy', model, metadata, ko_frame['dataset_index'].to_numpy(dtype=int), ko_originals, ko_perturbed, candidate_tokens, token_to_gene, token_to_ensembl))
        downstream_records.extend(token_hidden_state_effects(cohort, 'Healthy_GDF15_OE_to_Periodontitis', model, metadata, oe_frame['dataset_index'].to_numpy(dtype=int), oe_originals, oe_perturbed, candidate_tokens, token_to_gene, token_to_ensembl))
        del model
    cell_level = pd.concat(all_cell_frames, ignore_index=True)
    summary = pd.DataFrame(all_summaries)
    summary['BH_FDR_four_cohort_tests'] = bh_fdr(summary['Raw_P_one_sided'].to_numpy())
    pooled_rows: list[dict] = []
    for scenario, group in cell_level.groupby('scenario', observed=True):
        pooled_rows.append(summarize_direction(group, 'Pooled_cells'))
    pooled = pd.DataFrame(pooled_rows)
    pooled['BH_FDR_two_pooled_tests'] = bh_fdr(pooled['Raw_P_one_sided'].to_numpy())
    cell_level.to_csv(TABLE_OUT / 'GDF15_directional_perturbation_cell_level.csv', index=False, encoding='utf-8-sig')
    summary.to_csv(TABLE_OUT / 'GDF15_directional_perturbation_cohort_summary.csv', index=False, encoding='utf-8-sig')
    pooled.to_csv(TABLE_OUT / 'GDF15_directional_perturbation_pooled_summary.csv', index=False, encoding='utf-8-sig')
    downstream_raw = pd.DataFrame(downstream_records)
    downstream_raw.to_csv(TABLE_OUT / 'GDF15_downstream_gene_evidence_cell_level.csv.gz', index=False, compression='gzip', encoding='utf-8-sig')
    downstream_summary = aggregate_downstream(downstream_raw)
    downstream_summary.to_csv(TABLE_OUT / 'GDF15_downstream_gene_evidence_summary.csv', index=False, encoding='utf-8-sig')
    print('Computation complete', flush=True)

def set_figure_style() -> None:
    sns.set_theme(style='white', context='paper')
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8, 'axes.titlesize': 9, 'axes.labelsize': 8, 'xtick.labelsize': 7, 'ytick.labelsize': 7, 'legend.fontsize': 7, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'axes.linewidth': 0.7, 'savefig.facecolor': 'white'})

def save_figure(fig: plt.Figure, basename: str, dpi: int=600) -> None:
    for suffix in ('pdf', 'svg', 'png'):
        fig.savefig(FIG_OUT / f'{basename}.{suffix}', dpi=dpi if suffix == 'png' else None, bbox_inches='tight', facecolor='white')
    plt.close(fig)

def plot_prediction_heatmap_confusion() -> None:
    frames = []
    for cohort in COHORTS:
        frame = pd.read_csv(MODEL_OUT / cohort / 'validation_and_test_predictions.csv')
        frame = frame.loc[frame['split'] == 'test'].copy()
        frame['cohort'] = cohort
        frames.append(frame)
    data = pd.concat(frames, ignore_index=True)
    data = data.sort_values(['observed_label', 'predicted_label', 'periodontitis_probability'], ascending=[True, True, True]).reset_index(drop=True)
    probability = np.clip(data['periodontitis_probability'].to_numpy(dtype=float), 1e-05, 1 - 1e-05)
    logit = np.log(probability / (1 - probability))
    z = (logit - logit.mean()) / max(logit.std(ddof=0), 1e-12)
    z = np.clip(z, -2.5, 2.5)
    scores = np.vstack([-z, z])
    labels = data['observed_label'].to_numpy(dtype=int)
    predicted = data['predicted_label'].to_numpy(dtype=int)
    state_colors = ['#3E2F4F', '#B7CC69']
    cmap_state = mcolors.ListedColormap(state_colors)
    cmap_score = sns.diverging_palette(240, 10, s=85, l=50, as_cmap=True)
    fig = plt.figure(figsize=(12.0, 5.3))
    outer = GridSpec(1, 2, figure=fig, width_ratios=[2.65, 1.0], wspace=0.34)
    left = outer[0].subgridspec(5, 1, height_ratios=[0.18, 0.18, 1.7, 0.11, 0.18], hspace=0.13)
    ax_true = fig.add_subplot(left[0])
    ax_pred = fig.add_subplot(left[1], sharex=ax_true)
    ax_heat = fig.add_subplot(left[2], sharex=ax_true)
    ax_cbar = fig.add_subplot(left[4])
    cell_edges = np.arange(len(data) + 1)
    ax_true.pcolormesh(cell_edges, [0, 1], labels[np.newaxis, :], cmap=cmap_state, vmin=0, vmax=1, shading='flat')
    ax_pred.pcolormesh(cell_edges, [0, 1], predicted[np.newaxis, :], cmap=cmap_state, vmin=0, vmax=1, shading='flat')
    for axis, label in ((ax_true, 'True'), (ax_pred, 'Predicted')):
        axis.set_xlim(0, len(data))
        axis.set_ylim(0, 1)
        axis.set_yticks([0.5])
        axis.set_yticklabels([label], rotation=0)
        axis.set_xticks([])
        axis.tick_params(length=0, pad=3)
        for spine in axis.spines.values():
            spine.set_visible(False)
    image = ax_heat.pcolormesh(cell_edges, [0, 1, 2], scores, cmap=cmap_score, vmin=-2.5, vmax=2.5, shading='flat')
    ax_heat.set_xlim(0, len(data))
    ax_heat.set_ylim(2, 0)
    ax_heat.set_yticks([0.5, 1.5])
    ax_heat.set_yticklabels(['Healthy', 'Periodontitis'])
    ax_heat.set_xlabel(f'Test cells (n = {len(data):,})')
    ax_heat.set_xticks([])
    for spine in ax_heat.spines.values():
        spine.set_linewidth(0.7)
        spine.set_color('black')
    cbar = fig.colorbar(image, cax=ax_cbar, orientation='horizontal')
    cbar.set_label('Standardized prediction likelihood', labelpad=2)
    cbar.set_ticks([-2.5, 0, 2.5])
    handles = [Patch(facecolor=state_colors[0], edgecolor='none', label='Healthy'), Patch(facecolor=state_colors[1], edgecolor='none', label='Periodontitis')]
    ax_true.legend(handles=handles, title='Cell states', loc='lower right', bbox_to_anchor=(1.0, 1.55), frameon=False, ncol=2, handlelength=1.2, columnspacing=1.2)
    ax_true.text(-0.055, 2.15, 'D', transform=ax_true.transAxes, fontsize=13, fontweight='bold', va='top')
    ax_cm = fig.add_subplot(outer[1])
    cm = confusion_matrix(labels, predicted, labels=[0, 1]).astype(float)
    cm_norm = cm / np.clip(cm.sum(axis=1, keepdims=True), 1, None)
    im_cm = ax_cm.pcolormesh([0, 1, 2], [0, 1, 2], cm_norm, cmap='Blues', vmin=0, vmax=1, shading='flat', edgecolors='white', linewidth=0.6)
    for i in range(2):
        for j in range(2):
            color = 'white' if cm_norm[i, j] > 0.55 else 'black'
            ax_cm.text(j + 0.5, i + 0.5, f'{cm_norm[i, j]:.2f}', ha='center', va='center', fontsize=11, color=color)
    true_counts = cm.sum(axis=1).astype(int)
    pred_counts = cm.sum(axis=0).astype(int)
    ax_cm.set_xlim(0, 2)
    ax_cm.set_ylim(2, 0)
    ax_cm.set_aspect('equal')
    ax_cm.set_xticks([0.5, 1.5], [f'Healthy\nn={pred_counts[0]}', f'Periodontitis\nn={pred_counts[1]}'])
    ax_cm.set_yticks([0.5, 1.5], [f'Healthy\nn={true_counts[0]}', f'Periodontitis\nn={true_counts[1]}'])
    ax_cm.set_xlabel('Predicted label')
    ax_cm.set_ylabel('True label')
    ax_cm.tick_params(length=0)
    cbar_cm = fig.colorbar(im_cm, ax=ax_cm, fraction=0.046, pad=0.05)
    cbar_cm.set_label('Row proportion')
    accuracy = accuracy_score(labels, predicted)
    macro_f1 = f1_score(labels, predicted, average='macro')
    ax_cm.text(0.5, -0.27, f'Accuracy = {accuracy:.3f}\nF1 score = {macro_f1:.3f}', transform=ax_cm.transAxes, ha='center', va='top', fontsize=8.5)
    ax_cm.text(-0.22, 1.1, 'E', transform=ax_cm.transAxes, fontsize=13, fontweight='bold', va='top')
    fig.subplots_adjust(top=0.88, bottom=0.18, left=0.09, right=0.96)
    save_figure(fig, '\u56fe1_Geneformer\u5206\u7c7b\u9884\u6d4b\u70ed\u56fe\u4e0e\u6df7\u6dc6\u77e9\u9635_PLOS\u56fe2D-E\u540c\u578b')

def plot_umap_sensitivity() -> None:
    data = pd.read_csv(TABLE_OUT / 'Williams_GDF15_KO_OE_sensitivity_UMAP.csv')
    fig, axes = plt.subplots(1, 2, figsize=(11.2, 5.2), sharex=True, sharey=True)
    configurations = [('GDF15_KO_cosine_shift', 'Gene knockout sensitivity', 'Reds', 'B'), ('GDF15_OE_cosine_shift', 'Gene overexpression sensitivity', 'Blues', 'C')]
    for ax, (column, title, cmap, letter) in zip(axes, configurations):
        values = data[column].to_numpy(dtype=float) * 1000.0
        positive = values[values > 0]
        vmax = float(np.quantile(positive, 0.99)) if len(positive) else 1.0
        vmax = max(vmax, 1e-06)
        order = np.argsort(values)
        sc = ax.scatter(data['UMAP_1'].to_numpy()[order], data['UMAP_2'].to_numpy()[order], c=values[order], s=4.0, cmap=cmap, vmin=0, vmax=vmax, linewidths=0, rasterized=True)
        ax.set_title(title, fontsize=10, fontweight='normal', pad=7)
        ax.set_xlabel('UMAP 1')
        ax.set_ylabel('UMAP 2')
        ax.grid(False)
        ax.set_facecolor('white')
        for spine in ax.spines.values():
            spine.set_visible(True)
            spine.set_linewidth(0.75)
            spine.set_color('black')
        cbar = fig.colorbar(sc, ax=ax, fraction=0.045, pad=0.035)
        cbar.ax.set_title('Cosine shift\n(\xd710\xb3)', fontsize=7, pad=5)
        cbar.outline.set_linewidth(0.5)
        ax.text(-0.13, 1.06, letter, transform=ax.transAxes, fontsize=13, fontweight='bold', va='top')
    fig.subplots_adjust(wspace=0.28, left=0.07, right=0.94, bottom=0.12, top=0.9)
    save_figure(fig, '\u56fe2_GDF15\u6572\u9664\u4e0e\u8fc7\u8868\u8fbe\u654f\u611f\u6027UMAP_Frontiers\u56fe5B-C\u540c\u578b')

def circular_positions(classes: list[str]) -> tuple[np.ndarray, float, list[int]]:
    start_angle = math.radians(25)
    span = math.radians(310)
    positions: list[float] = []
    boundaries: list[int] = []
    cursor = 0.0
    previous = None
    for index, category in enumerate(classes):
        if previous is not None and category != previous:
            cursor += 2.0
            boundaries.append(index)
        positions.append(cursor)
        cursor += 1.0
        previous = category
    total_units = cursor
    theta = start_angle + np.asarray(positions) / total_units * span
    width = span / total_units * 0.9
    return (theta, width, boundaries)

def select_circle_genes(summary: pd.DataFrame, scenario: str, n_total: int=32) -> pd.DataFrame:
    pooled = summary.loc[(summary['scenario'] == scenario) & (summary['cohort'] == 'Pooled')].copy()
    pooled = pooled.sort_values('Mean_token_cosine_shift', ascending=False)
    axis = pooled.loc[pooled['Priority_class'] != 'Other'].head(24)
    other = pooled.loc[pooled['Priority_class'] == 'Other'].head(max(0, n_total - len(axis)))
    selected = pd.concat([axis, other], ignore_index=True).drop_duplicates('Gene')
    class_order = {'MAPK-response': 0, 'ECM-remodeling': 1, 'Other': 2}
    selected['class_order'] = selected['Priority_class'].map(class_order).fillna(2)
    return selected.sort_values(['class_order', 'Mean_token_cosine_shift'], ascending=[True, False]).reset_index(drop=True)

def draw_box_strip(ax: plt.Axes, data: pd.DataFrame, color: str, title: str) -> None:
    order = [x for x in COHORTS if x in data['cohort'].unique()]
    rng = np.random.default_rng(SEED + (0 if 'KO' in title else 1))
    values_by_cohort = []
    for position, cohort in enumerate(order):
        values = data.loc[data['cohort'] == cohort, 'Cosine_shift'].to_numpy(dtype=float) * 1000.0
        values_by_cohort.append(values)
        jitter = rng.normal(position + 1, 0.055, len(values))
        ax.scatter(jitter, values, s=10, alpha=0.55, color=color, edgecolors='none', zorder=2)
    box = ax.boxplot(values_by_cohort, positions=np.arange(1, len(order) + 1), widths=0.42, patch_artist=True, showfliers=False, medianprops={'color': 'black', 'linewidth': 1.2}, whiskerprops={'color': color, 'linewidth': 0.9}, capprops={'color': color, 'linewidth': 0.9}, boxprops={'edgecolor': color, 'linewidth': 1.1})
    for patch in box['boxes']:
        patch.set_facecolor('white')
        patch.set_alpha(0.9)
    ax.set_xticks(np.arange(1, len(order) + 1), [f'{x}\n(n={len(values_by_cohort[i])})' for i, x in enumerate(order)])
    ax.set_ylabel('Cosine shift (\xd710\xb3)')
    ax.set_title(title, fontsize=8.5, pad=5)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.grid(False)
    ax.tick_params(axis='x', length=0)

def draw_circular_evidence(ax: plt.Axes, summary: pd.DataFrame, scenario: str, cmap_name: str, strong_color: str) -> None:
    selected = select_circle_genes(summary, scenario)
    genes = selected['Gene'].astype(int).tolist()
    classes = selected['Priority_class'].astype(str).tolist()
    theta, width, boundaries = circular_positions(classes)
    subset = summary.loc[(summary['scenario'] == scenario) & summary['Gene'].isin(genes)].copy()
    all_values = subset['Mean_token_cosine_shift'].to_numpy(dtype=float) * 1000.0
    vmax = float(np.quantile(all_values[np.isfinite(all_values)], 0.98)) if np.isfinite(all_values).any() else 1.0
    vmax = max(vmax, 1e-06)
    norm = mcolors.Normalize(vmin=0, vmax=vmax)
    cmap = plt.get_cmap(cmap_name)
    tracks = [('Caetano', 1.35), ('Williams', 2.05), ('Pooled', 2.75)]
    track_height = 0.54
    for cohort, bottom in tracks:
        indexed = subset.loc[subset['cohort'] == cohort].set_index('Gene')
        values = np.asarray([indexed.at[gene, 'Mean_token_cosine_shift'] * 1000.0 if gene in indexed.index else np.nan for gene in genes])
        colors = [cmap(norm(value)) if np.isfinite(value) else '#F3F3F3' for value in values]
        ax.bar(theta, np.repeat(track_height, len(theta)), bottom=bottom, width=width, color=colors, edgecolor='white', linewidth=0.25, align='center')
    pooled_index = subset.loc[subset['cohort'] == 'Pooled'].set_index('Gene')
    strong = np.asarray([pooled_index.at[gene, 'N_strong_hits'] if gene in pooled_index.index else 0 for gene in genes], dtype=float)
    ax.bar(theta, strong * 0.24, bottom=3.52, width=width, color=strong_color, edgecolor='white', linewidth=0.2)
    label_radius = 4.25
    for angle, gene_name in zip(theta, selected['Gene_name'].astype(str)):
        degrees = math.degrees(angle) % 360
        rotation = degrees - 90
        horizontal = 'left'
        if 90 < degrees < 270:
            rotation += 180
            horizontal = 'right'
        ax.text(angle, label_radius, gene_name, rotation=rotation, rotation_mode='anchor', ha=horizontal, va='center', fontsize=5.0, color='black')
    for boundary in boundaries:
        if boundary < len(theta):
            angle = theta[boundary] - width
            ax.plot([angle, angle], [1.18, 4.05], color='#777777', linewidth=0.55, linestyle=(0, (2, 2)))
    ax.set_ylim(0, 4.75)
    ax.set_axis_off()
    ax.set_facecolor('white')
    scalar = plt.cm.ScalarMappable(norm=norm, cmap=cmap)
    cax = ax.inset_axes([0.35, -0.02, 0.34, 0.032], transform=ax.transAxes)
    cbar = plt.colorbar(scalar, cax=cax, orientation='horizontal')
    cbar.set_ticks([0, vmax])
    cbar.set_ticklabels(['Low', 'High'])
    cbar.ax.tick_params(length=0, labelsize=5)
    cbar.set_label('Cosine shift', fontsize=5, labelpad=-15)
    cbar.outline.set_linewidth(0.4)

def plot_circular_evidence() -> None:
    cell = pd.read_csv(TABLE_OUT / 'GDF15_directional_perturbation_cell_level.csv')
    summary = pd.read_csv(TABLE_OUT / 'GDF15_downstream_gene_evidence_summary.csv')
    scenarios = [('Periodontitis_GDF15_KO_to_Healthy', 'GDF15 KO', 'Reds', '#C58B2B', '#D95F5F', 'D'), ('Healthy_GDF15_OE_to_Periodontitis', 'GDF15 OE', 'Blues', '#355C9A', '#4C78A8', 'E')]
    fig = plt.figure(figsize=(15.6, 7.4))
    outer = GridSpec(1, 2, figure=fig, wspace=0.16)
    for panel_index, (scenario, title, cmap, strong_color, point_color, letter) in enumerate(scenarios):
        nested = outer[panel_index].subgridspec(2, 2, width_ratios=[0.82, 2.25], height_ratios=[1.1, 1.0], wspace=0.06)
        ax_box = fig.add_subplot(nested[0, 0])
        ax_legend = fig.add_subplot(nested[1, 0])
        ax_polar = fig.add_subplot(nested[:, 1], projection='polar')
        draw_box_strip(ax_box, cell.loc[cell['scenario'] == scenario], point_color, title)
        draw_circular_evidence(ax_polar, summary, scenario, cmap, strong_color)
        ax_legend.axis('off')
        legend_handles = [Patch(facecolor=plt.get_cmap(cmap)(0.8), edgecolor='none', label='Pooled'), Patch(facecolor=plt.get_cmap(cmap)(0.58), edgecolor='none', label='Williams'), Patch(facecolor=plt.get_cmap(cmap)(0.36), edgecolor='none', label='Caetano'), Patch(facecolor=strong_color, edgecolor='none', label='N strong hits')]
        ax_legend.legend(handles=legend_handles, loc='upper left', frameon=False, title='Tracks', borderaxespad=0)
        ax_legend.text(0, 0.36, 'Priority groups\nMAPK-response\nECM-remodeling\nOther', transform=ax_legend.transAxes, fontsize=6.5, va='top', linespacing=1.45)
        ax_box.text(-0.28, 1.19, letter, transform=ax_box.transAxes, fontsize=13, fontweight='bold', va='top')
    fig.subplots_adjust(left=0.05, right=0.98, bottom=0.06, top=0.92)
    save_figure(fig, '\u56fe3_GDF15\u6572\u9664\u4e0e\u8fc7\u8868\u8fbe\u5706\u5f62\u57fa\u56e0\u8bc1\u636e\u56fe_Frontiers\u56fe5D-E\u540c\u578b')

def plot_candidate_bubble() -> None:
    data = pd.read_csv(SCREEN_OUT / 'Williams' / 'exact_delete_gene_summary.csv')
    direct = pd.read_csv(TABLE_OUT / 'GDF15_directional_perturbation_cohort_summary.csv')
    direct = direct.loc[(direct['Scope'] == 'Williams') & (direct['Scenario'] == 'Periodontitis_GDF15_KO_to_Healthy')].iloc[0]
    data = data.loc[data['Gene_name'] != 'GDF15'].copy()
    gdf_row = {'Gene': GDF15_TOKEN_ID, 'Gene_name': 'GDF15', 'Ensembl_ID': GDF15_ENSEMBL, 'Priority_class': 'GDF15', 'N_Detections': int(direct['N_cells']), 'Shift_to_goal_end': float(direct['Shift_to_target']), 'Shift_away_start_end': float(direct['Shift_away_source'])}
    data = pd.concat([data, pd.DataFrame([gdf_row])], ignore_index=True)
    x = data['Shift_to_goal_end'].to_numpy(dtype=float)
    y = data['Shift_away_start_end'].to_numpy(dtype=float)
    n = data['N_Detections'].to_numpy(dtype=float)
    size = 18 + 280 * np.sqrt(n / max(n.max(), 1))
    fig, ax = plt.subplots(figsize=(8.4, 6.8))
    ax.scatter(x, y, s=size, color='#E64B35', alpha=0.72, edgecolors='white', linewidths=0.35)
    ax.axvline(0, color='#D73027', linewidth=1.0, linestyle=(0, (2, 2)))
    ax.axhline(0, color='#D73027', linewidth=1.0, linestyle=(0, (2, 2)))
    limit = max(np.max(np.abs(x)), np.max(np.abs(y))) * 1.13
    diagonal = np.linspace(-limit, limit, 100)
    ax.plot(diagonal, diagonal, color='#888888', linewidth=0.8, linestyle=(0, (5, 3)), zorder=0)
    radius = np.hypot(x / max(np.std(x), 1e-12), y / max(np.std(y), 1e-12))
    label_indices = set(np.argsort(radius)[-10:].tolist())
    axis_indices = data.index[data['Priority_class'].isin(['MAPK-response', 'ECM-remodeling'])].to_numpy()
    if len(axis_indices):
        axis_rank = axis_indices[np.argsort(radius[axis_indices])[-6:]]
        label_indices.update(axis_rank.tolist())
    gdf_index = int(data.index[data['Gene_name'] == 'GDF15'][0])
    label_indices.add(gdf_index)
    texts = []
    for idx in sorted(label_indices):
        is_gdf = idx == gdf_index
        text = ax.text(x[idx], y[idx], str(data.at[idx, 'Gene_name']), fontsize=7.0 if is_gdf else 6.0, fontweight='bold' if is_gdf else 'normal', ha='left' if x[idx] >= 0 else 'right', va='bottom' if y[idx] >= 0 else 'top', bbox=dict(boxstyle='round,pad=0.18', facecolor='white', edgecolor='black' if is_gdf else 'none', linewidth=0.8 if is_gdf else 0, alpha=0.88))
        texts.append(text)
    try:
        from adjustText import adjust_text
        adjust_text(texts, ax=ax, arrowprops=dict(arrowstyle='-', color='#777777', lw=0.35))
    except ImportError:
        pass
    ax.set_xlabel('Shift to goal state (Healthy)')
    ax.set_ylabel('Shift to alternate state (Periodontitis)')
    ax.set_title('Candidate therapeutic targets whose in silico deletion in periodontitis fibroblasts\nshifts toward Healthy, away from Periodontitis', fontsize=10, fontweight='bold', pad=10)
    ax.grid(False)
    ax.set_facecolor('white')
    for spine in ax.spines.values():
        spine.set_linewidth(0.8)
        spine.set_color('black')
    quantiles = sorted(set((int(round(value)) for value in np.quantile(n, [0.25, 0.5, 0.75, 1.0]))))
    handles = [Line2D([0], [0], marker='o', linestyle='', markerfacecolor='#E64B35', markeredgecolor='white', markersize=math.sqrt(18 + 280 * math.sqrt(value / max(n.max(), 1))) / 1.5, label=f'{value}') for value in quantiles]
    ax.legend(handles=handles, title='Number of cells', frameon=False, loc='lower left')
    ax.text(-0.12, 1.08, 'b', transform=ax.transAxes, fontsize=14, fontweight='bold', va='top')
    fig.subplots_adjust(left=0.13, right=0.97, bottom=0.12, top=0.86)
    save_figure(fig, '\u56fe4_GDF15\u865a\u62df\u6572\u9664\u5019\u9009\u6cbb\u7597\u9776\u70b9\u6c14\u6ce1\u56fe_Geneformer\u56fe2b\u540c\u578b')

def write_plot_manifest() -> None:
    manifest = {'classification_test_cells': {cohort: int((pd.read_csv(MODEL_OUT / cohort / 'validation_and_test_predictions.csv')['split'] == 'test').sum()) for cohort in COHORTS}, 'primary_format_references': {'PLOS_Figure_2D_E': PLOS_URL, 'Frontiers_Figure_5B_E': FRONTIERS_URL}, 'figures': ['\u56fe1_Geneformer\u5206\u7c7b\u9884\u6d4b\u70ed\u56fe\u4e0e\u6df7\u6dc6\u77e9\u9635_PLOS\u56fe2D-E\u540c\u578b', '\u56fe2_GDF15\u6572\u9664\u4e0e\u8fc7\u8868\u8fbe\u654f\u611f\u6027UMAP_Frontiers\u56fe5B-C\u540c\u578b', '\u56fe3_GDF15\u6572\u9664\u4e0e\u8fc7\u8868\u8fbe\u5706\u5f62\u57fa\u56e0\u8bc1\u636e\u56fe_Frontiers\u56fe5D-E\u540c\u578b', '\u56fe4_GDF15\u865a\u62df\u6572\u9664\u5019\u9009\u6cbb\u7597\u9776\u70b9\u6c14\u6ce1\u56fe_Geneformer\u56fe2b\u540c\u578b'], 'seed': SEED}
    (EXT_OUT / 'figure_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')

def plot_all() -> None:
    ensure_dirs()
    set_figure_style()
    plot_prediction_heatmap_confusion()
    plot_umap_sensitivity()
    plot_circular_evidence()
    plot_candidate_bubble()
    write_plot_manifest()
    print('Four requested figures written in PDF/SVG/PNG', flush=True)

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', choices=['compute', 'umap_prepare', 'umap_chunk', 'umap_finalize', 'plot', 'all'])
    parser.add_argument('--chunk-index', type=int, default=None)
    parser.add_argument('--chunk-size', type=int, default=96)
    args = parser.parse_args()
    if args.stage in {'compute', 'all'}:
        compute_all()
    if args.stage in {'umap_prepare', 'all'}:
        prepare_umap_sensitivity()
    if args.stage == 'umap_chunk':
        if args.chunk_index is None:
            parser.error('--chunk-index is required for umap_chunk')
        compute_umap_oe_chunk(args.chunk_index, args.chunk_size)
    if args.stage in {'umap_finalize', 'all'}:
        if args.stage == 'all':
            raise RuntimeError("Run umap_chunk processes before umap_finalize; 'all' intentionally stops here")
        finalize_umap_sensitivity()
    if args.stage in {'plot', 'all'}:
        plot_all()
if __name__ == '__main__':
    main()
