options(stringsAsFactors = FALSE, warn = 1)

local_lib <- Sys.getenv("VITDKO_R_LIB", unset = "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_enrichment")
.libPaths(c(local_lib, .libPaths()))

suppressPackageStartupMessages({
  library(AnnotationDbi)
  library(org.Hs.eg.db)
  library(clusterProfiler)
  library(ggplot2)
  library(patchwork)
})

out_root <- Sys.getenv("VITDKO_OUT_ROOT", unset = "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260821_GDF15\u865a\u62df\u6572\u9664_scTenifoldKnk_\u9996\u7248")
diff_file <- file.path(
  out_root, "02_virtual_ko",
  "GDF15_differential_regulation_all_genes.csv"
)
dir.create(file.path(out_root, "03_enrichment"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(out_root, "04_figures"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(out_root, "06_qa"), recursive = TRUE, showWarnings = FALSE)

log_file <- file.path(out_root, "06_qa", "03_enrichment_and_figures.log")
sink(log_file, split = TRUE)
on.exit(sink(), add = TRUE)

stopifnot(file.exists(diff_file))
diff_reg <- read.csv(diff_file, check.names = FALSE, stringsAsFactors = FALSE)
stopifnot(all(c("gene", "FC", "p.adj", "log10_FC_plus_1") %in% colnames(diff_reg)))
diff_reg <- diff_reg[is.finite(diff_reg$FC) & diff_reg$gene != "GDF15", , drop = FALSE]

top20 <- head(diff_reg[order(-diff_reg$FC, diff_reg$p.adj, diff_reg$gene), , drop = FALSE], 20L)
top20$plot_order <- seq_len(nrow(top20))
write.csv(
  top20,
  file.path(out_root, "04_figures", "Panel_E_top20_differentially_regulated_genes_source.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

sig <- diff_reg[is.finite(diff_reg$p.adj) & diff_reg$p.adj < 0.05, , drop = FALSE]
sig <- sig[order(-sig$FC, sig$p.adj, sig$gene), , drop = FALSE]
enrichment_gene_cap <- 200L
enrichment_input <- head(sig, enrichment_gene_cap)
if (nrow(enrichment_input) < 10L) {
  warning("Fewer than 10 FDR-significant genes; using the 50 largest shifts as an exploratory fallback.")
  enrichment_input <- head(diff_reg[order(-diff_reg$FC), , drop = FALSE], 50L)
  enrichment_input_rule <- "fallback_top50_FC_due_to_lt10_FDR_genes"
} else {
  enrichment_input_rule <- "top200_FC_among_FDR_lt_0.05"
}
write.csv(
  enrichment_input,
  file.path(out_root, "03_enrichment", "enrichment_input_genes.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

all_symbols <- unique(diff_reg$gene)
map <- suppressMessages(AnnotationDbi::select(
  org.Hs.eg.db,
  keys = all_symbols,
  columns = c("SYMBOL", "ENTREZID"),
  keytype = "SYMBOL"
))
map <- map[!is.na(map$ENTREZID) & nzchar(map$ENTREZID), , drop = FALSE]
map <- map[!duplicated(map[, c("SYMBOL", "ENTREZID")]), , drop = FALSE]
universe_entrez <- unique(map$ENTREZID)
input_entrez <- unique(map$ENTREZID[map$SYMBOL %in% enrichment_input$gene])
stopifnot(length(input_entrez) >= 5L, length(universe_entrez) > length(input_entrez))

run_go <- function(ontology) {
  as.data.frame(suppressMessages(clusterProfiler::enrichGO(
    gene = input_entrez,
    universe = universe_entrez,
    OrgDb = org.Hs.eg.db,
    keyType = "ENTREZID",
    ont = ontology,
    pAdjustMethod = "BH",
    pvalueCutoff = 1,
    qvalueCutoff = 1,
    minGSSize = 10,
    maxGSSize = 500,
    readable = TRUE
  )))
}

go_bp <- run_go("BP")
go_cc <- run_go("CC")
go_mf <- run_go("MF")

local_kegg_gmt <- file.path(out_root, "03_enrichment", "KEGG_2026_local_library.gmt")
if (file.exists(local_kegg_gmt)) {
  gmt_lines <- readLines(local_kegg_gmt, warn = FALSE, encoding = "UTF-8")
  gmt_parts <- strsplit(gmt_lines, "\t", fixed = TRUE)
  term2gene <- do.call(rbind, lapply(gmt_parts, function(z) {
    genes <- unique(z[seq.int(3L, length(z))])
    genes <- genes[nzchar(genes)]
    data.frame(term = z[[1L]], gene = genes, stringsAsFactors = FALSE)
  }))
  term2name <- unique(data.frame(
    term = vapply(gmt_parts, `[[`, character(1), 1L),
    name = vapply(gmt_parts, `[[`, character(1), 1L),
    stringsAsFactors = FALSE
  ))
  kegg_result <- suppressMessages(clusterProfiler::enricher(
    gene = unique(enrichment_input$gene),
    universe = unique(diff_reg$gene),
    TERM2GENE = term2gene,
    TERM2NAME = term2name,
    pAdjustMethod = "BH",
    pvalueCutoff = 1,
    qvalueCutoff = 1,
    minGSSize = 10,
    maxGSSize = 500
  ))
  kegg <- as.data.frame(kegg_result)
  kegg_source <- "local fixed KEGG_2026.gmt"
} else {
  kegg_result <- try(suppressMessages(clusterProfiler::enrichKEGG(
    gene = input_entrez,
    universe = universe_entrez,
    organism = "hsa",
    keyType = "kegg",
    pAdjustMethod = "BH",
    pvalueCutoff = 1,
    qvalueCutoff = 1,
    minGSSize = 10,
    maxGSSize = 500,
    use_internal_data = FALSE
  )), silent = TRUE)
  if (inherits(kegg_result, "try-error")) {
    warning("KEGG enrichment failed: ", as.character(kegg_result))
    kegg <- data.frame()
    kegg_source <- "KEGG REST failed; no local library"
  } else {
    kegg <- as.data.frame(kegg_result)
    kegg_source <- "KEGG REST"
  }
}

write_enrichment <- function(x, name) {
  write.csv(
    x,
    file.path(out_root, "03_enrichment", paste0(name, "_all_terms.csv")),
    row.names = FALSE,
    fileEncoding = "UTF-8"
  )
}
write_enrichment(go_bp, "GO_BP")
write_enrichment(go_cc, "GO_CC")
write_enrichment(go_mf, "GO_MF")
write_enrichment(kegg, "KEGG")

select_terms <- function(x, category, quota) {
  if (nrow(x) == 0L) return(data.frame())
  required <- c("Description", "p.adjust", "Count", "geneID")
  if (!all(required %in% colnames(x))) return(data.frame())
  x <- x[is.finite(x$p.adjust) & x$p.adjust > 0, , drop = FALSE]
  x <- x[order(x$p.adjust, -x$Count, x$Description), , drop = FALSE]
  x <- head(x, quota)
  if (nrow(x) == 0L) return(data.frame())
  x$Category <- category
  x$FDR_lt_0_05 <- x$p.adjust < 0.05
  x
}

panel_f <- do.call(rbind, list(
  select_terms(go_bp, "BP", 2L),
  select_terms(go_cc, "CC", 5L),
  select_terms(go_mf, "MF", 4L),
  select_terms(kegg, "KEGG", 4L)
))
stopifnot(nrow(panel_f) > 0L)
panel_f$minus_log10_adjusted_P <- -log10(panel_f$p.adjust)
panel_f$rank_in_panel <- seq_len(nrow(panel_f))
panel_f$gene_symbols <- gsub("/", ", ", panel_f$geneID, fixed = TRUE)
panel_f$gene_symbols_short <- ifelse(
  nchar(panel_f$gene_symbols) > 92,
  paste0(substr(panel_f$gene_symbols, 1, 89), "..."),
  panel_f$gene_symbols
)
write.csv(
  panel_f,
  file.path(out_root, "04_figures", "Panel_F_functional_enrichment_source.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

paper_bg <- "#F1EBEC"
paper_grid <- "#C9D4D6"
paper_text <- "#4A1717"
paper_teal <- "#5BA5A7"
category_colors <- c(BP = "#C8DEE5", CC = "#F0DDB6", MF = "#DCC8DD", KEGG = "#A8C98A")

top20$gene_factor <- factor(top20$gene, levels = rev(top20$gene))
p_e <- ggplot(top20, aes(x = log10_FC_plus_1, y = gene_factor)) +
  geom_col(width = 0.82, fill = paper_teal) +
  scale_x_continuous(expand = expansion(mult = c(0, 0.04))) +
  labs(
    title = "Top 20 Differentially Regulated Genes",
    x = expression(log[10](FC + 1)),
    y = NULL
  ) +
  theme_minimal(base_size = 11) +
  theme(
    plot.background = element_rect(fill = "white", color = NA),
    panel.background = element_rect(fill = paper_bg, color = "black", linewidth = 0.9),
    panel.grid.major = element_line(color = paper_grid, linewidth = 0.45, linetype = "dashed"),
    panel.grid.minor = element_blank(),
    plot.title = element_text(
      color = paper_text, face = "bold.italic", size = 15,
      hjust = 0.5, margin = margin(b = 8)
    ),
    axis.title.x = element_text(color = paper_text, size = 11),
    axis.text.x = element_text(color = paper_text, size = 9),
    axis.text.y = element_text(color = paper_text, face = "bold.italic", size = 9),
    axis.ticks = element_line(color = "black"),
    plot.margin = margin(10, 12, 10, 10)
  )

panel_f$term_factor <- factor(panel_f$Description, levels = rev(panel_f$Description))
p_f <- ggplot(panel_f, aes(x = minus_log10_adjusted_P, y = term_factor)) +
  geom_col(aes(fill = Category), width = 0.72, alpha = 0.55) +
  geom_text(
    aes(x = 0.02 * max(minus_log10_adjusted_P), label = gene_symbols_short, color = Category),
    hjust = 0, size = 1.9, alpha = 0.58, fontface = "italic"
  ) +
  geom_point(
    aes(size = Count), shape = 21, fill = "white", color = "black",
    stroke = 0.6
  ) +
  geom_text(aes(label = rank_in_panel), size = 2.2, color = "black") +
  scale_fill_manual(values = category_colors, drop = FALSE) +
  scale_color_manual(values = category_colors, guide = "none", drop = FALSE) +
  scale_size_continuous(range = c(2.6, 7.0), breaks = scales::pretty_breaks(n = 4)) +
  scale_x_continuous(expand = expansion(mult = c(0, 0.05))) +
  labs(
    x = expression(-log[10](adjusted~P)),
    y = NULL,
    size = "Count",
    fill = "Category"
  ) +
  guides(fill = guide_legend(override.aes = list(alpha = 0.8))) +
  theme_minimal(base_size = 9) +
  theme(
    plot.background = element_rect(fill = "white", color = NA),
    panel.background = element_rect(fill = paper_bg, color = "black", linewidth = 0.9),
    panel.grid.major = element_line(color = paper_grid, linewidth = 0.4, linetype = "dashed"),
    panel.grid.minor = element_blank(),
    axis.text.y = element_text(color = "#202020", size = 7.3),
    axis.text.x = element_text(color = paper_text, size = 8),
    axis.title.x = element_text(color = paper_text, size = 10),
    legend.position = "right",
    legend.title = element_text(size = 8),
    legend.text = element_text(size = 7),
    plot.margin = margin(8, 8, 8, 8)
  )

combined <- p_e / p_f +
  plot_layout(heights = c(1.0, 1.15)) +
  plot_annotation(tag_levels = list(c("E", "F"))) &
  theme(plot.tag = element_text(face = "plain", family = "serif", size = 18))

save_plot_set <- function(plot, stem, width, height) {
  ggsave(
    file.path(out_root, "04_figures", paste0(stem, ".pdf")),
    plot = plot, width = width, height = height, units = "in",
    device = grDevices::cairo_pdf
  )
  ggsave(
    file.path(out_root, "04_figures", paste0(stem, ".svg")),
    plot = plot, width = width, height = height, units = "in",
    device = svglite::svglite
  )
  ggsave(
    file.path(out_root, "04_figures", paste0(stem, ".png")),
    plot = plot, width = width, height = height, units = "in",
    dpi = 600, bg = "white"
  )
}

save_plot_set(p_e, "Panel_E_GDF15_virtual_KO_top20_reference_style", 7.4, 5.4)
save_plot_set(p_f, "Panel_F_GDF15_virtual_KO_enrichment_reference_style", 8.0, 7.3)
save_plot_set(combined, "Panels_EF_GDF15_virtual_KO_reference_style", 8.3, 12.0)

figure_manifest <- data.frame(
  metric = c(
    "Panel_E_genes", "Panel_E_ranking_rule", "enrichment_input_rule",
    "enrichment_input_genes", "universe_mapped_genes", "KEGG_source", "Panel_F_terms",
    "Panel_F_BP_terms", "Panel_F_CC_terms", "Panel_F_MF_terms", "Panel_F_KEGG_terms",
    "Panel_F_FDR_lt_0.05_terms"
  ),
  value = c(
    nrow(top20), "largest scTenifoldKnk FC excluding GDF15", enrichment_input_rule,
    nrow(enrichment_input), length(universe_entrez), kegg_source, nrow(panel_f),
    sum(panel_f$Category == "BP"), sum(panel_f$Category == "CC"),
    sum(panel_f$Category == "MF"), sum(panel_f$Category == "KEGG"),
    sum(panel_f$FDR_lt_0_05)
  ),
  stringsAsFactors = FALSE
)
write.csv(
  figure_manifest,
  file.path(out_root, "04_figures", "figure_manifest.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

cat("Panel E top genes:", paste(top20$gene, collapse = ", "), "\n")
cat("Enrichment input:", nrow(enrichment_input), "genes via", enrichment_input_rule, "\n")
cat("Panel F terms:", nrow(panel_f), "of which FDR < 0.05:", sum(panel_f$FDR_lt_0_05), "\n")
cat("Finished figures:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")
