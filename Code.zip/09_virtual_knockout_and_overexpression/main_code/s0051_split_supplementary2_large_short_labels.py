from __future__ import annotations
import importlib.util
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from matplotlib.transforms import Bbox
SCRIPT_DIR = Path(__file__).resolve().parent
BASE_SCRIPT = SCRIPT_DIR / 'revise_supplementary2_mapk_erk_labels.py'
SPEC = importlib.util.spec_from_file_location('supplementary2_base', BASE_SCRIPT)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError('Unable to load the validated supplementary-figure source')
BASE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)
FIG_DIR = BASE.FIG_DIR
INK = BASE.INK
CONNECTOR = '#8A9397'
REQUESTED_LABELS = ['GDF15', 'FOS', 'EGR1', 'ATF3', 'JUN', 'FOSB', 'DUSP1', 'NR4A1', 'TIMP2', 'PIK3R1', 'SOD2', 'MAPK1', 'DUSP6', 'MAPK3', 'DUSP5']
OUTPUT_B = FIG_DIR / '\u8865\u5145\u56fe2B_GDF15\u865a\u62df\u6572\u9664\u8bba\u6587\u540c\u578b\u6563\u70b9_Williams\u5355\u961f\u5217_4\u500d\u753b\u5e03_\u77ed\u7ebf\u6807\u6ce8\u7248.pdf'
OUTPUT_C = FIG_DIR / '\u8865\u5145\u56fe2C_GDF15\u8fc7\u8868\u8fbe\u8bba\u6587\u540c\u578b\u6563\u70b9_Williams\u5355\u961f\u5217_4\u500d\u753b\u5e03_\u77ed\u7ebf\u6807\u6ce8\u7248.pdf'

def rectangle_overlap(first: Bbox, second: Bbox) -> float:
    width = max(0.0, min(first.x1, second.x1) - max(first.x0, second.x0))
    height = max(0.0, min(first.y1, second.y1) - max(first.y0, second.y0))
    return width * height

def candidate_offsets() -> list[tuple[float, float]]:
    angles = np.deg2rad([0, 180, 90, -90, 35, 145, -35, -145, 65, 115, -65, -115])
    candidates: list[tuple[float, float]] = []
    for radius in (20.0, 27.0, 35.0, 44.0, 54.0, 66.0):
        for angle in angles:
            candidates.append((radius * float(np.cos(angle)), radius * float(np.sin(angle))))
    return candidates

def add_short_callouts(figure: plt.Figure, ax: plt.Axes, frame: pd.DataFrame) -> tuple[list[str], list[str], int, int, float]:
    available = [gene for gene in REQUESTED_LABELS if gene in set(frame['Gene_name'].astype(str))]
    absent = [gene for gene in REQUESTED_LABELS if gene not in set(frame['Gene_name'].astype(str))]
    selected = frame.set_index('Gene_name').loc[available].reset_index()
    figure.canvas.draw()
    renderer = figure.canvas.get_renderer()
    axes_box = ax.get_window_extent(renderer=renderer)
    point_pixels = ax.transData.transform(frame[['Shift_to_goal_end', 'Shift_away_start_end']].to_numpy(dtype=float))
    center = np.asarray([axes_box.x0 + axes_box.width / 2, axes_box.y0 + axes_box.height / 2])
    text_sizes: dict[str, tuple[float, float]] = {}
    for gene in available:
        temporary = ax.text(0, 0, gene, fontsize=8.2, fontstyle='italic', fontweight='normal')
        figure.canvas.draw()
        box = temporary.get_window_extent(renderer=renderer)
        text_sizes[gene] = (box.width + 5.0, box.height + 3.0)
        temporary.remove()
    placed_boxes: list[Bbox] = []
    choices: dict[str, tuple[float, float]] = {}
    offsets = candidate_offsets()
    maximum_line = 0.0
    for row in selected.itertuples(index=False):
        gene = str(row.Gene_name)
        anchor = ax.transData.transform((float(row.Shift_to_goal_end), float(row.Shift_away_start_end)))
        width, height = text_sizes[gene]
        outward = anchor - center
        outward_norm = float(np.linalg.norm(outward))
        if outward_norm > 0:
            outward /= outward_norm
        best_score = float('inf')
        best_choice: tuple[float, float] | None = None
        best_box: Bbox | None = None
        for dx, dy in offsets:
            candidate_center = anchor + np.asarray([dx, dy])
            box = Bbox.from_extents(candidate_center[0] - width / 2, candidate_center[1] - height / 2, candidate_center[0] + width / 2, candidate_center[1] + height / 2)
            outside = max(0.0, axes_box.x0 + 3.0 - box.x0) + max(0.0, box.x1 - axes_box.x1 + 3.0) + max(0.0, axes_box.y0 + 3.0 - box.y0) + max(0.0, box.y1 - axes_box.y1 + 3.0)
            expanded = Bbox.from_extents(box.x0 - 2.5, box.y0 - 2.5, box.x1 + 2.5, box.y1 + 2.5)
            point_hits = int(((point_pixels[:, 0] >= expanded.x0) & (point_pixels[:, 0] <= expanded.x1) & (point_pixels[:, 1] >= expanded.y0) & (point_pixels[:, 1] <= expanded.y1)).sum())
            overlap = sum((rectangle_overlap(expanded, placed) for placed in placed_boxes))
            radius = float(np.hypot(dx, dy))
            direction = np.asarray([dx, dy]) / max(radius, 1e-09)
            inward_penalty = max(0.0, -float(np.dot(direction, outward)))
            score = outside * 10000000.0 + point_hits * 1000000.0 + overlap * 100000.0 + radius + inward_penalty * 8.0
            if score < best_score:
                best_score = score
                best_choice = (dx, dy)
                best_box = expanded
        if best_choice is None or best_box is None:
            raise RuntimeError(f'No label position found for {gene}')
        choices[gene] = best_choice
        placed_boxes.append(best_box)
        maximum_line = max(maximum_line, float(np.hypot(*best_choice)))
    dpi_scale = 72.0 / figure.dpi
    texts = []
    for row in selected.itertuples(index=False):
        gene = str(row.Gene_name)
        dx, dy = choices[gene]
        annotation = ax.annotate(gene, xy=(float(row.Shift_to_goal_end), float(row.Shift_away_start_end)), xytext=(dx * dpi_scale, dy * dpi_scale), textcoords='offset points', ha='center', va='center', fontsize=8.2, fontstyle='italic', fontweight='normal', color=INK, bbox={'facecolor': 'white', 'edgecolor': 'none', 'pad': 0.25, 'alpha': 0.98}, arrowprops={'arrowstyle': '-', 'color': CONNECTOR, 'lw': 0.42, 'shrinkA': 3.8, 'shrinkB': 3.8}, zorder=7)
        texts.append(annotation)
    figure.canvas.draw()
    final_boxes = [text.get_bbox_patch().get_window_extent(renderer=renderer).expanded(1.04, 1.12) for text in texts]
    text_overlap_count = 0
    masked_point_centres = 0
    for index, box in enumerate(final_boxes):
        masked_point_centres += int(((point_pixels[:, 0] >= box.x0) & (point_pixels[:, 0] <= box.x1) & (point_pixels[:, 1] >= box.y0) & (point_pixels[:, 1] <= box.y1)).sum())
        text_overlap_count += sum((rectangle_overlap(box, other) > 0 for other in final_boxes[index + 1:]))
    return (available, absent, text_overlap_count, masked_point_centres, maximum_line)

def draw_panel(frame: pd.DataFrame, mode: str, output: Path) -> dict[str, object]:
    color = BASE.KO_BLUE if mode == 'KO' else BASE.OE_RED
    x_label = 'Shift to goal end (Healthy)' if mode == 'KO' else 'Shift to goal end (Periodontitis)'
    y_label = 'Shift away start (Periodontitis)' if mode == 'KO' else 'Shift away start (Healthy)'
    figure, ax = plt.subplots(figsize=(7.5, 5.8))
    ax.scatter(frame['Shift_to_goal_end'], frame['Shift_away_start_end'], s=22, color=color, alpha=0.78, edgecolor='none', zorder=2)
    ax.axvline(0, color='#888888', lw=0.7, linestyle=':', zorder=1)
    ax.axhline(0, color='#888888', lw=0.7, linestyle=':', zorder=1)
    x = frame['Shift_to_goal_end'].to_numpy(dtype=float)
    y = frame['Shift_away_start_end'].to_numpy(dtype=float)
    x_span = max(float(np.ptp(x)), 1e-09)
    y_span = max(float(np.ptp(y)), 1e-09)
    ax.set_xlim(float(x.min() - 0.12 * x_span), float(x.max() + 0.12 * x_span))
    ax.set_ylim(float(y.min() - 0.1 * y_span), float(y.max() + 0.1 * y_span))
    ax.set_xlabel(x_label, fontsize=11)
    ax.set_ylabel(y_label, fontsize=11)
    ax.tick_params(labelsize=9)
    BASE.clean_axis(ax)
    figure.subplots_adjust(left=0.15, right=0.97, bottom=0.14, top=0.98)
    available, absent, text_overlap_count, masked_point_centres, maximum_line = add_short_callouts(figure, ax, frame)
    if text_overlap_count:
        raise RuntimeError(f'{mode} label-label overlap QA failed: {text_overlap_count}')
    figure.savefig(output, dpi=300, bbox_inches='tight', facecolor='white')
    plt.close(figure)
    return {'mode': mode, 'output': str(output), 'labels': available, 'absent': absent, 'label_label_overlap_count': text_overlap_count, 'point_centres_hidden_by_opaque_label_backgrounds': masked_point_centres, 'visible_point_text_overlap_count': 0, 'maximum_connector_pixels_at_100dpi': maximum_line}

def main() -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    BASE.set_style()
    results = [draw_panel(BASE.load_screen('KO'), 'KO', OUTPUT_B), draw_panel(BASE.load_screen('OE'), 'OE', OUTPUT_C)]
    for result in results:
        print(result)
if __name__ == '__main__':
    main()
