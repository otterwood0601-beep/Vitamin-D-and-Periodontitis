from __future__ import annotations
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from matplotlib.gridspec import GridSpec
from matplotlib.patches import FancyArrowPatch
SOURCE_ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260904_Geneformer_GDF15_ERK_MAPK_ECM_\u8bba\u6587\u540c\u578b\u590d\u73b0_v1')
OUT_ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260906_Geneformer_GDF15_Williams\u5355\u961f\u5217_\u5168\u56fe\u7ea0\u9519\u6c47\u603b_v1')
FIG_DIR = OUT_ROOT / '\u56fe\u7247'
KO_SCREEN = SOURCE_ROOT / '03_\u5168\u57fa\u56e0\u865a\u62df\u6572\u9664' / 'Williams' / 'exact_delete_gene_summary.csv'
OE_SCREEN = SOURCE_ROOT / '09_\u8bba\u6587\u539f\u56fe\u4e25\u683c\u590d\u6838\u4e0eGDF15\u8fc7\u8868\u8fbe\u8865\u5145_v2' / '\u6570\u636e\u8868' / '\u5168\u57fa\u56e0\u8fc7\u8868\u8fbe\u7b5b\u9009' / 'Williams' / 'exact_overexpression_gene_summary.csv'
DIRECT_SUMMARY = SOURCE_ROOT / '08_\u6269\u5c55\u56fe\u8868_PLOS_Frontiers\u540c\u578b' / '\u6570\u636e\u8868' / 'GDF15_directional_perturbation_cohort_summary.csv'
KO_BLUE = '#397FC0'
KO_BLUE_DARK = '#1F5F9B'
OE_RED = '#D9544D'
OE_RED_DARK = '#A93434'
INK = '#222222'
CONNECTOR = '#7F888C'
SEED = 42
MAPK_ERK_LABELS = ['GDF15', 'MAPK1', 'MAPK3', 'DUSP1', 'DUSP5', 'DUSP6', 'FOS', 'JUN', 'EGR1', 'ATF3']
OUTPUT_STEM = '\u8865\u5145\u56fe2_GDF15\u865a\u62df\u6572\u9664\u4e0e\u8fc7\u8868\u8fbe\u8bba\u6587\u540c\u578b\u6563\u70b9_Williams\u5355\u961f\u5217_MAPK-ERK\u8f74\u6807\u6ce8\u907f\u8ba9\u7248'
OUTPUT_PDF = FIG_DIR / f'{OUTPUT_STEM}.pdf'

def set_style() -> None:
    plt.rcParams.update({'font.family': 'Arial', 'font.size': 8, 'axes.titlesize': 9, 'axes.labelsize': 8, 'xtick.labelsize': 7, 'ytick.labelsize': 7, 'axes.linewidth': 0.7, 'pdf.fonttype': 42, 'figure.facecolor': 'white', 'axes.facecolor': 'white', 'savefig.facecolor': 'white'})

def clean_axis(ax: plt.Axes) -> None:
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.grid(False)

def panel_letter(ax: plt.Axes, letter: str, x: float, y: float=1.08) -> None:
    ax.text(x, y, letter, transform=ax.transAxes, fontsize=14, va='top', ha='left')

def direct_row(scenario: str) -> dict[str, object]:
    summary = pd.read_csv(DIRECT_SUMMARY)
    row = summary.loc[summary['Scope'].eq('Williams') & summary['Scenario'].eq(scenario)]
    if len(row) != 1:
        raise ValueError(f'Expected one Williams direct-perturbation row for {scenario}')
    direct = row.iloc[0]
    return {'Gene': -1, 'Gene_name': 'GDF15', 'Ensembl_ID': 'ENSG00000130513', 'N_cells': int(direct['N_cells']), 'Shift_to_goal_end': float(direct['Shift_to_target']), 'Shift_away_start_end': float(direct['Shift_away_source'])}

def load_screen(mode: str) -> pd.DataFrame:
    if mode == 'KO':
        frame = pd.read_csv(KO_SCREEN)
        frame['N_cells'] = frame['N_Detections']
        scenario = 'Periodontitis_GDF15_KO_to_Healthy'
    else:
        frame = pd.read_csv(OE_SCREEN)
        frame['N_cells'] = frame['N_Perturbed_cells']
        scenario = 'Healthy_GDF15_OE_to_Periodontitis'
    frame = frame.loc[~frame['Gene_name'].eq('GDF15')].copy()
    frame = pd.concat([frame, pd.DataFrame([direct_row(scenario)])], ignore_index=True)
    missing = sorted(set(MAPK_ERK_LABELS) - set(frame['Gene_name'].astype(str)))
    if missing:
        raise ValueError(f'MAPK/ERK labels absent from {mode} screen: {missing}')
    return frame

def spread_positions(values: np.ndarray, low: float, high: float) -> np.ndarray:
    if len(values) == 0:
        return values
    order = np.argsort(values)
    sorted_values = np.clip(values[order], low, high)
    minimum_gap = 0.105 * (high - low)
    if len(values) > 1 and minimum_gap * (len(values) - 1) > high - low:
        minimum_gap = (high - low) / (len(values) - 1)
    placed = sorted_values.copy()
    for index in range(1, len(placed)):
        placed[index] = max(placed[index], placed[index - 1] + minimum_gap)
    if placed[-1] > high:
        placed -= placed[-1] - high
    for index in range(len(placed) - 2, -1, -1):
        placed[index] = min(placed[index], placed[index + 1] - minimum_gap)
    if placed[0] < low:
        placed += low - placed[0]
    restored = np.empty_like(placed)
    restored[order] = placed
    return restored

def add_mapk_erk_callouts(ax: plt.Axes, frame: pd.DataFrame) -> None:
    labels = frame.loc[frame['Gene_name'].isin(MAPK_ERK_LABELS)].copy()
    labels['label_order'] = labels['Gene_name'].map({gene: index for index, gene in enumerate(MAPK_ERK_LABELS)})
    labels = labels.sort_values('label_order')
    x_all = frame['Shift_to_goal_end'].to_numpy(dtype=float)
    y_all = frame['Shift_away_start_end'].to_numpy(dtype=float)
    x_span = max(float(np.ptp(x_all)), 1e-09)
    y_span = max(float(np.ptp(y_all)), 1e-09)
    raw_left = float(x_all.min())
    raw_right = float(x_all.max())
    raw_bottom = float(y_all.min())
    raw_top = float(y_all.max())
    ranked = labels.sort_values('Shift_to_goal_end')
    left_genes = set(ranked.iloc[:len(ranked) // 2]['Gene_name'].astype(str))
    left = labels.loc[labels['Gene_name'].isin(left_genes)].copy()
    right = labels.loc[~labels['Gene_name'].isin(left_genes)].copy()
    label_low = raw_bottom + 0.035 * y_span
    label_high = raw_top - 0.035 * y_span
    left_y = spread_positions(left['Shift_away_start_end'].to_numpy(float), label_low, label_high)
    right_y = spread_positions(right['Shift_away_start_end'].to_numpy(float), label_low, label_high)
    left_x = raw_left - 0.065 * x_span
    right_x = raw_right + 0.065 * x_span
    for side, subset, label_y, label_x in (('left', left, left_y, left_x), ('right', right, right_y, right_x)):
        for (_, row), text_y in zip(subset.iterrows(), label_y):
            gene = str(row['Gene_name'])
            point_x = float(row['Shift_to_goal_end'])
            point_y = float(row['Shift_away_start_end'])
            ax.annotate(gene, xy=(point_x, point_y), xytext=(label_x, float(text_y)), textcoords='data', ha='right' if side == 'left' else 'left', va='center', fontsize=5.8, fontstyle='italic', fontweight='bold' if gene == 'GDF15' else 'normal', color=INK, bbox={'facecolor': 'white', 'edgecolor': 'none', 'pad': 0.25}, arrowprops={'arrowstyle': '-', 'color': CONNECTOR, 'lw': 0.38, 'shrinkA': 1.5, 'shrinkB': 2.4, 'connectionstyle': 'arc3,rad=0'}, zorder=6)
    ax.set_xlim(raw_left - 0.27 * x_span, raw_right + 0.27 * x_span)
    ax.set_ylim(raw_bottom - 0.05 * y_span, raw_top + 0.05 * y_span)

def schematic(ax: plt.Axes) -> None:
    rng = np.random.default_rng(SEED)
    for x, color, label in [(-1.0, OE_RED, 'Periodontitis'), (1.0, KO_BLUE, 'Healthy')]:
        points = rng.normal([x, 0], [0.12, 0.12], size=(11, 2))
        ax.scatter(points[:, 0], points[:, 1], s=55, color=color, alpha=0.75, edgecolor=INK, linewidth=0.3)
        ax.text(x, -0.55, label, ha='center', va='top')
    ax.add_patch(FancyArrowPatch((-0.55, 0.18), (0.55, 0.18), arrowstyle='-|>', mutation_scale=12, color=KO_BLUE_DARK, lw=1.3))
    ax.add_patch(FancyArrowPatch((0.55, -0.18), (-0.55, -0.18), arrowstyle='-|>', mutation_scale=12, color=OE_RED_DARK, lw=1.3))
    ax.text(0, 0.38, 'KO: shift toward Healthy', ha='center', color=KO_BLUE_DARK, fontsize=7)
    ax.text(0, -0.42, 'OE: shift toward Periodontitis', ha='center', color=OE_RED_DARK, fontsize=7)
    ax.set_xlim(-1.8, 1.8)
    ax.set_ylim(-0.9, 0.9)
    ax.axis('off')
    panel_letter(ax, 'A', -0.02, 1.02)

def scatter_panel(ax: plt.Axes, frame: pd.DataFrame, title: str, color: str, letter: str, x_label: str, y_label: str) -> None:
    ax.scatter(frame['Shift_to_goal_end'], frame['Shift_away_start_end'], s=10, color=color, alpha=0.78, edgecolor='none', zorder=2)
    gdf15 = frame.loc[frame['Gene_name'].eq('GDF15')]
    ax.scatter(gdf15['Shift_to_goal_end'], gdf15['Shift_away_start_end'], s=50, color=color, marker='*', edgecolor=INK, linewidth=0.4, zorder=4)
    ax.axvline(0, color='#888888', lw=0.6, linestyle=':', zorder=1)
    ax.axhline(0, color='#888888', lw=0.6, linestyle=':', zorder=1)
    add_mapk_erk_callouts(ax, frame)
    ax.set_xlabel(x_label)
    ax.set_ylabel(y_label)
    ax.set_title(title, fontweight='bold')
    panel_letter(ax, letter, -0.14)
    clean_axis(ax)

def main() -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    set_style()
    ko = load_screen('KO')
    oe = load_screen('OE')
    figure = plt.figure(figsize=(11.8, 3.45))
    grid = GridSpec(1, 3, figure=figure, width_ratios=[1.0, 1.42, 1.42], wspace=0.35)
    schematic(figure.add_subplot(grid[0, 0]))
    scatter_panel(figure.add_subplot(grid[0, 1]), ko, 'GDF15 knockout', KO_BLUE, 'B', 'Shift to goal end (Healthy)', 'Shift away start (Periodontitis)')
    scatter_panel(figure.add_subplot(grid[0, 2]), oe, 'GDF15 overexpression', OE_RED, 'C', 'Shift to goal end (Periodontitis)', 'Shift away start (Healthy)')
    figure.subplots_adjust(left=0.03, right=0.985, top=0.91, bottom=0.2)
    figure.savefig(OUTPUT_PDF, dpi=300, bbox_inches='tight', facecolor='white')
    plt.close(figure)
    print(OUTPUT_PDF)
if __name__ == '__main__':
    main()
