from __future__ import annotations
import hashlib
import importlib.util
import json
import math
import platform
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
import sklearn
from scipy.special import expit
from sklearn.base import clone
from sklearn.linear_model import LogisticRegression, RidgeClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import LinearSVC
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa')
SOURCE_ROOT = ROOT / '20260904_Geneformer_GDF15_ERK_MAPK_ECM_\u8bba\u6587\u540c\u578b\u590d\u73b0_v1'
OUT = ROOT / '20260906_Geneformer_Williams\u51bb\u7ed3\u7f16\u7801\u5668\u5206\u7c7b\u5934\u4f18\u5316_\u652f\u7ebf_v6'
SPLITS = SOURCE_ROOT / '02_\u72b6\u6001\u5206\u7c7b\u5668/Williams/data_splits.csv'
EMBEDDINGS = SOURCE_ROOT / '14_GDF15\u5168\u7ec6\u80de\u6572\u9664\u654f\u611f\u6027UMAP_\u652f\u7ebf_v1/\u6570\u636e\u8868/Williams_Geneformer_\u5168\u90e813257\u7ec6\u80de\u539f\u59cb\u5d4c\u5165.npz'
BASELINE_CELL_SCORES = SOURCE_ROOT / '11_\u56fe1_rawLogits\u4e0e\u6a21\u578b\u6548\u80fd\u4f18\u5316_\u652f\u7ebf_v3/\u6570\u636e\u8868/\u9010\u7ec6\u80de\u539f\u59cblogits_\u9a8c\u8bc1\u4e0e\u6d4b\u8bd5\u96c6.csv.gz'
PLOTTER = SOURCE_ROOT / '12_\u56fe1_\u56feD\u6a2a\u5411\u534a\u5bbd_\u652f\u7ebf_v4/\u4ee3\u7801/render_panel_d_half_width_v4.py'
ATTACHED_V5 = SOURCE_ROOT / '13_\u56fe1_\u8272\u6761\u7f29\u77ed\u4e0e\u6548\u80fd\u4f18\u5316_\u652f\u7ebf_v5/\u56fe\u7247/\u56fe1_Geneformer\u7ec6\u80de\u72b6\u6001\u9884\u6d4b\u70ed\u56fe\u4e0e\u6df7\u6dc6\u77e9\u9635_\u56feD\u534a\u5bbd_\u8272\u6761\u7f29\u77ed_\u9a8c\u8bc1\u96c6\u6548\u80fd\u4f18\u5316_v5.pdf'
CORRECTED_WILLIAMS = ROOT / '20260906_Geneformer_GDF15_Williams\u5355\u961f\u5217_\u5168\u56fe\u7ea0\u9519\u6c47\u603b_v1/\u56fe\u7247/\u56fe1_Geneformer\u7ec6\u80de\u72b6\u6001\u9884\u6d4b\u70ed\u56fe\u4e0e\u6df7\u6dc6\u77e9\u9635_Williams\u5355\u961f\u5217\u7ea0\u9519\u7248.pdf'
FIGURE_STEM = '\u56fe1_Geneformer\u7ec6\u80de\u72b6\u6001\u9884\u6d4b\u70ed\u56fe\u4e0e\u6df7\u6dc6\u77e9\u9635_Williams\u51bb\u7ed3\u7f16\u7801\u5668\u5206\u7c7b\u5934\u4f18\u5316_v6'
RANDOM_SEED = 20260906

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def load_plotter():
    spec = importlib.util.spec_from_file_location('paper_matched_plotter', PLOTTER)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'Unable to load plotting module: {PLOTTER}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def score_values(model: Pipeline, matrix: np.ndarray) -> np.ndarray:
    if hasattr(model, 'decision_function'):
        return np.asarray(model.decision_function(matrix), dtype=float).reshape(-1)
    probabilities = np.asarray(model.predict_proba(matrix), dtype=float)[:, 1]
    clipped = np.clip(probabilities, 1e-12, 1 - 1e-12)
    return np.log(clipped / (1 - clipped))

def metric_record(labels: np.ndarray, predictions: np.ndarray, scores: np.ndarray) -> dict:
    matrix = confusion_matrix(labels, predictions, labels=[0, 1])
    tn, fp, fn, tp = matrix.ravel()
    return {'accuracy': float(accuracy_score(labels, predictions)), 'macro_f1': float(f1_score(labels, predictions, average='macro')), 'roc_auc': float(roc_auc_score(labels, scores)), 'sensitivity_periodontitis': float(tp / (tp + fn)), 'specificity_healthy': float(tn / (tn + fp)), 'confusion_matrix': matrix.astype(int).tolist()}

def optimize_threshold(labels: np.ndarray, scores: np.ndarray) -> tuple[float, pd.DataFrame]:
    unique_scores = np.unique(np.asarray(scores, dtype=float))
    if len(unique_scores) < 2:
        candidates = np.array([float(unique_scores[0])])
    else:
        gaps = (unique_scores[:-1] + unique_scores[1:]) / 2.0
        epsilon = max(1e-12, float(np.ptp(unique_scores)) * 1e-09)
        candidates = np.concatenate(([unique_scores[0] - epsilon], gaps, [unique_scores[-1] + epsilon]))
    rows = []
    for threshold in candidates:
        predicted = (scores >= threshold).astype(int)
        accuracy = float(accuracy_score(labels, predicted))
        macro_f1 = float(f1_score(labels, predicted, average='macro'))
        rows.append({'threshold_raw_decision_score': float(threshold), 'accuracy': accuracy, 'macro_f1': macro_f1, 'joint_objective_min_ACC_macroF1': min(accuracy, macro_f1)})
    table = pd.DataFrame(rows)
    ranked = table.assign(abs_threshold=table['threshold_raw_decision_score'].abs()).sort_values(['joint_objective_min_ACC_macroF1', 'macro_f1', 'accuracy', 'abs_threshold'], ascending=[False, False, False, True], kind='stable')
    return (float(ranked.iloc[0]['threshold_raw_decision_score']), table)

def main() -> None:
    for subdirectory in ('\u6a21\u578b', '\u6570\u636e\u8868', '\u56fe\u7247', 'QA'):
        (OUT / subdirectory).mkdir(parents=True, exist_ok=True)
    guarded_paths = [ATTACHED_V5, CORRECTED_WILLIAMS]
    hashes_before = {str(path): sha256(path) for path in guarded_paths}
    splits = pd.read_csv(SPLITS)
    required_columns = {'dataset_index', 'label', 'split', 'used_for_training_run', 'donor_id', 'cell_id', 'disease'}
    missing = sorted(required_columns.difference(splits.columns))
    if missing:
        raise ValueError(f'Missing split columns: {missing}')
    embedding_bundle = np.load(EMBEDDINGS)
    embedding_indices = embedding_bundle['dataset_indices'].astype(int)
    embedding_matrix = embedding_bundle['original_embeddings'].astype(np.float32)
    if len(np.unique(embedding_indices)) != len(embedding_indices):
        raise ValueError('Embedding dataset indices are not unique')
    row_lookup = pd.Series(np.arange(len(embedding_indices)), index=embedding_indices)
    train_meta = splits.loc[splits['split'].eq('train')].sort_values('dataset_index', kind='stable').copy()
    validation_meta = splits.loc[splits['split'].eq('validation') & splits['used_for_training_run'].astype(bool)].sort_values('dataset_index', kind='stable').copy()
    test_meta = splits.loc[splits['split'].eq('test') & splits['used_for_training_run'].astype(bool)].sort_values('dataset_index', kind='stable').copy()
    for name, frame in (('train', train_meta), ('validation', validation_meta), ('test', test_meta)):
        if not frame['dataset_index'].isin(row_lookup.index).all():
            raise ValueError(f'{name} contains cells without saved Geneformer embeddings')
    if len(validation_meta) != 600 or len(test_meta) != 600:
        raise ValueError('Expected the fixed Williams validation and test sets to contain 600 cells each')
    donor_sets = {name: set(frame['donor_id'].astype(str)) for name, frame in (('train', train_meta), ('validation', validation_meta), ('test', test_meta))}
    donor_overlap = {'train_validation': sorted(donor_sets['train'] & donor_sets['validation']), 'train_test': sorted(donor_sets['train'] & donor_sets['test']), 'validation_test': sorted(donor_sets['validation'] & donor_sets['test'])}
    if any(donor_overlap.values()):
        raise ValueError(f'Donor leakage detected: {donor_overlap}')

    def take(frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        rows = row_lookup.loc[frame['dataset_index'].astype(int)].to_numpy(int)
        return (embedding_matrix[rows], frame['label'].to_numpy(int))
    x_train, y_train = take(train_meta)
    x_validation, y_validation = take(validation_meta)
    x_test, y_test = take(test_meta)
    candidates: dict[str, Pipeline] = {}
    for c_value in (0.0001, 0.0003, 0.001, 0.003, 0.01):
        candidates[f'LinearSVC_C{c_value:g}'] = Pipeline([('scale', StandardScaler()), ('head', LinearSVC(C=c_value, class_weight='balanced', dual='auto', max_iter=10000, random_state=RANDOM_SEED))])
    for c_value in (0.001, 0.003, 0.01, 0.03, 0.1):
        candidates[f'LogisticRegression_C{c_value:g}'] = Pipeline([('scale', StandardScaler()), ('head', LogisticRegression(C=c_value, class_weight='balanced', max_iter=10000, random_state=RANDOM_SEED))])
    for alpha in (1.0, 10.0, 100.0):
        candidates[f'RidgeClassifier_alpha{alpha:g}'] = Pipeline([('scale', StandardScaler()), ('head', RidgeClassifier(alpha=alpha, class_weight='balanced'))])
    validation_rows = []
    fitted_models: dict[str, Pipeline] = {}
    for name, template in candidates.items():
        model = clone(template)
        model.fit(x_train, y_train)
        validation_scores = score_values(model, x_validation)
        validation_predictions = model.predict(x_validation).astype(int)
        metrics = metric_record(y_validation, validation_predictions, validation_scores)
        validation_rows.append({'candidate': name, 'selection_split': 'Williams donor-disjoint validation', 'n_train_all_assigned_cells': int(len(y_train)), 'n_validation_fixed_cells': int(len(y_validation)), 'accuracy': metrics['accuracy'], 'macro_f1': metrics['macro_f1'], 'roc_auc': metrics['roc_auc']})
        fitted_models[name] = model
    validation_table = pd.DataFrame(validation_rows).sort_values(['macro_f1', 'accuracy', 'roc_auc'], ascending=False, kind='stable').reset_index(drop=True)
    selected_name = str(validation_table.iloc[0]['candidate'])
    selected_model = fitted_models[selected_name]
    validation_scores = score_values(selected_model, x_validation)
    selected_threshold, threshold_table = optimize_threshold(y_validation, validation_scores)
    validation_predictions = (validation_scores >= selected_threshold).astype(int)
    validation_metrics = metric_record(y_validation, validation_predictions, validation_scores)
    test_scores = score_values(selected_model, x_test)
    test_predictions = (test_scores >= selected_threshold).astype(int)
    test_metrics = metric_record(y_test, test_predictions, test_scores)
    baseline_scores = pd.read_csv(BASELINE_CELL_SCORES)
    baseline_test = baseline_scores.loc[baseline_scores['cohort'].eq('Williams') & baseline_scores['split'].eq('test')].copy()
    if set(baseline_test['cell_id'].astype(str)) != set(test_meta['cell_id'].astype(str)):
        raise ValueError('The optimized model and Williams baseline do not use the same held-out test cells')
    baseline_probability_threshold = 0.394
    baseline_labels = baseline_test['observed_label'].to_numpy(int)
    baseline_probabilities = baseline_test['probability_from_raw_logits'].to_numpy(float)
    baseline_predictions = (baseline_probabilities >= baseline_probability_threshold).astype(int)
    baseline_metrics = metric_record(baseline_labels, baseline_predictions, baseline_probabilities)
    if not (test_metrics['accuracy'] > baseline_metrics['accuracy'] and test_metrics['macro_f1'] > baseline_metrics['macro_f1']):
        raise RuntimeError('The independently evaluated v6 model did not improve both requested metrics')
    validation_table.to_csv(OUT / '\u6570\u636e\u8868/\u5019\u9009\u5206\u7c7b\u5934_\u4ec5\u9a8c\u8bc1\u96c6\u6548\u80fd.csv', index=False, encoding='utf-8-sig')
    threshold_table.to_csv(OUT / '\u6570\u636e\u8868/\u6240\u9009\u5206\u7c7b\u5934_\u9a8c\u8bc1\u96c6\u9608\u503c\u626b\u63cf.csv', index=False, encoding='utf-8-sig')
    test_output = test_meta[['cell_id', 'donor_id', 'disease', 'dataset_index', 'label', 'split']].rename(columns={'label': 'observed_label'}).copy()
    test_output['cohort'] = 'Williams'
    test_output['decision_score_raw'] = test_scores
    test_output['healthy_head_score_raw'] = -0.5 * test_scores
    test_output['periodontitis_head_score_raw'] = 0.5 * test_scores
    test_output['display_probability_from_decision_score'] = expit(test_scores)
    test_output['threshold_raw_decision_score_selected_on_validation'] = selected_threshold
    test_output['predicted_label'] = test_predictions
    test_output.to_csv(OUT / '\u6570\u636e\u8868/Williams\u6d4b\u8bd5\u96c6_\u4f18\u5316\u5206\u7c7b\u5934\u9010\u7ec6\u80de\u539f\u59cb\u51b3\u7b56\u5206\u6570.csv.gz', index=False, encoding='utf-8-sig', compression='gzip')
    comparison = pd.DataFrame([{'model': 'v5-compatible Williams-only baseline', 'test_population': 'Williams held-out test; 300 Healthy + 300 Periodontitis', 'accuracy': baseline_metrics['accuracy'], 'macro_f1': baseline_metrics['macro_f1'], 'roc_auc': baseline_metrics['roc_auc'], 'sensitivity_periodontitis': baseline_metrics['sensitivity_periodontitis'], 'specificity_healthy': baseline_metrics['specificity_healthy'], 'confusion_matrix': json.dumps(baseline_metrics['confusion_matrix'])}, {'model': f'v6 frozen Geneformer encoder + {selected_name}', 'test_population': 'Williams held-out test; 300 Healthy + 300 Periodontitis', 'accuracy': test_metrics['accuracy'], 'macro_f1': test_metrics['macro_f1'], 'roc_auc': test_metrics['roc_auc'], 'sensitivity_periodontitis': test_metrics['sensitivity_periodontitis'], 'specificity_healthy': test_metrics['specificity_healthy'], 'confusion_matrix': json.dumps(test_metrics['confusion_matrix'])}])
    comparison.to_csv(OUT / '\u6570\u636e\u8868/Williams\u540c\u4e00\u6d4b\u8bd5\u96c6_v5\u517c\u5bb9\u57fa\u7ebf\u4e0ev6\u6548\u80fd\u5bf9\u6bd4.csv', index=False, encoding='utf-8-sig')
    joblib.dump({'pipeline': selected_model, 'selected_threshold_raw_decision_score': selected_threshold, 'feature_source': str(EMBEDDINGS), 'class_mapping': {0: 'Healthy', 1: 'Periodontitis'}, 'random_seed': RANDOM_SEED}, OUT / '\u6a21\u578b/Williams_Geneformer\u51bb\u7ed3\u7f16\u7801\u5668_\u4f18\u5316\u7ebf\u6027\u5206\u7c7b\u5934.joblib', compress=3)
    plot_data = pd.DataFrame({'cohort': 'Williams', 'observed_label': y_test, 'healthy_logit_raw': -0.5 * test_scores, 'periodontitis_logit_raw': 0.5 * test_scores, 'probability_from_raw_logits': expit(test_scores)})
    probability_threshold = float(expit(selected_threshold))
    plotter = load_plotter()
    figure_info = plotter.plot(plot_data, {'Williams': probability_threshold}, figure_output_dir=OUT / '\u56fe\u7247', figure_stem=FIGURE_STEM, colorbar_height_fraction=0.6, metric_decimals=5)
    hashes_after = {str(path): sha256(path) for path in guarded_paths}
    if hashes_before != hashes_after:
        raise RuntimeError('A guarded pre-existing figure changed unexpectedly')
    audit = {'status': 'one-time side-task v6; no previous figure or model overwritten', 'scientific_scope': 'Williams fibroblasts only; Caetano excluded', 'encoder': 'existing fine-tuned Williams Geneformer encoder kept frozen', 'optimization': {'change': 'replace the original classification head with a class-weighted linear head trained on all cells assigned to Williams training donors', 'selection_rule': 'highest validation macro-F1, then validation accuracy and ROC-AUC', 'threshold_rule': 'validation-only threshold maximizing min(accuracy, macro-F1)', 'test_policy': 'held-out Williams test labels evaluated once after model and threshold were frozen', 'selected_candidate': selected_name, 'selected_threshold_raw_decision_score': selected_threshold, 'selected_threshold_display_probability': probability_threshold, 'random_seed': RANDOM_SEED}, 'counts': {'train_all_assigned': int(len(y_train)), 'train_by_class': {str(k): int(v) for k, v in pd.Series(y_train).value_counts().sort_index().items()}, 'validation_fixed': int(len(y_validation)), 'test_fixed': int(len(y_test))}, 'donor_overlap': donor_overlap, 'validation_metrics_after_threshold_selection': validation_metrics, 'test_baseline': baseline_metrics, 'test_v6': test_metrics, 'figure': figure_info, 'figure_interpretation': 'Panel D contains unscaled raw linear-head scores and is grouped only by true label; no within-group score sorting. Panel E is the same held-out Williams test set.', 'guarded_files_sha256_before': hashes_before, 'guarded_files_sha256_after': hashes_after, 'software': {'python': platform.python_version(), 'numpy': np.__version__, 'pandas': pd.__version__, 'scikit_learn': sklearn.__version__}, 'sources': {'split_table': str(SPLITS), 'fixed_embeddings': str(EMBEDDINGS), 'baseline_cell_scores': str(BASELINE_CELL_SCORES), 'visual_format_reference': str(ATTACHED_V5)}}
    (OUT / 'QA/\u8fd0\u884c\u4e0e\u65b9\u6cd5\u5ba1\u8ba1.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
    readme = f"# Williams Geneformer \u5206\u7c7b\u5934\u4f18\u5316\uff08v6\uff09\n\n\u672c\u76ee\u5f55\u662f\u4e00\u6b21\u6027\u652f\u7ebf\u4efb\u52a1\uff1b\u672a\u8986\u76d6 v5\u3001Williams \u5355\u961f\u5217\u7ea0\u9519\u7248\u6216\u4e3b\u7ebf\u6a21\u578b\u3002\n\n## \u505a\u4e86\u4ec0\u4e48\n\n- \u7814\u7a76\u5bf9\u8c61\u4ec5\u4e3a Williams \u961f\u5217\u6210\u7ea4\u7ef4\u7ec6\u80de\uff0c\u660e\u786e\u6392\u9664 Caetano\u3002\n- \u4fdd\u6301\u73b0\u6709 Geneformer \u7f16\u7801\u5668\u53ca\u5176 256 \u7ef4\u5355\u7ec6\u80de\u5d4c\u5165\u4e0d\u53d8\uff0c\u4ec5\u4f18\u5316 Healthy/Periodontitis \u7ebf\u6027\u5206\u7c7b\u5934\u3002\n- \u8bad\u7ec3\u4f7f\u7528 Williams \u8bad\u7ec3\u4f9b\u8005\u7684\u5168\u90e8 {len(y_train):,} \u4e2a\u7ec6\u80de\uff0c\u5e76\u4f7f\u7528\u7c7b\u522b\u6743\u91cd\u5904\u7406\u7ec4\u95f4\u4e0d\u5e73\u8861\u3002\n- \u6a21\u578b\u7c7b\u578b\u4e0e\u8d85\u53c2\u6570\u53ea\u5728\u56fa\u5b9a\u3001\u4f9b\u8005\u9694\u79bb\u7684\u9a8c\u8bc1\u96c6\u4e0a\u9009\u62e9\uff1b\u5206\u7c7b\u9608\u503c\u4e5f\u53ea\u7528\u9a8c\u8bc1\u96c6\u786e\u5b9a\u3002\n- \u6700\u7ec8\u4ec5\u5728\u56fa\u5b9a\u7684 Williams \u6d4b\u8bd5\u96c6\uff08Healthy 300\uff0cPeriodontitis 300\uff09\u8bc4\u4f30\u4e00\u6b21\u3002\n\n## \u72ec\u7acb\u6d4b\u8bd5\u7ed3\u679c\n\n- \u539f Williams \u57fa\u7ebf\uff1aACC {baseline_metrics['accuracy']:.5f}\uff0cmacro-F1 {baseline_metrics['macro_f1']:.5f}\u3002\n- v6\uff1aACC {test_metrics['accuracy']:.5f}\uff0cmacro-F1 {test_metrics['macro_f1']:.5f}\uff0cROC-AUC {test_metrics['roc_auc']:.5f}\u3002\n- v6 \u6df7\u6dc6\u77e9\u9635\uff1a{test_metrics['confusion_matrix']}\uff08\u884c\uff1a\u771f\u5b9e Healthy/Periodontitis\uff1b\u5217\uff1a\u9884\u6d4b Healthy/Periodontitis\uff09\u3002\n\n## \u56fe\u5f62\u5904\u7406\n\n\u56fe D \u6cbf\u7528 v5 \u7684\u534a\u5bbd\u3001\u7f29\u77ed\u8272\u6761\u548c\u8bba\u6587\u5f0f\u5e03\u5c40\uff0c\u663e\u793a\u672a\u7ecf softmax\u3001Z-score \u6216\u4eba\u5de5\u7f29\u653e\u7684\u539f\u59cb\u7ebf\u6027\u5206\u7c7b\u5934\u5206\u6570\uff1b\u7ec6\u80de\u4ec5\u6309\u771f\u5b9e\u7c7b\u522b\u5206\u7ec4\uff0c\u7ec4\u5185\u4e0d\u4f9d\u636e\u9884\u6d4b\u5206\u6570\u4e8c\u6b21\u6392\u5e8f\u3002\u56fe E \u4f7f\u7528\u540c\u4e00\u72ec\u7acb\u6d4b\u8bd5\u96c6\u3002\n\n\u8be6\u7ec6\u5019\u9009\u6a21\u578b\u3001\u9608\u503c\u626b\u63cf\u3001\u9010\u7ec6\u80de\u5206\u6570\u4e0e\u5b8c\u6574\u5ba1\u8ba1\u8bb0\u5f55\u89c1\u201c\u6570\u636e\u8868\u201d\u548c\u201cQA\u201d\u76ee\u5f55\u3002\n"
    (OUT / 'README_\u8bf7\u5148\u770b.md').write_text(readme, encoding='utf-8')
    print(json.dumps(audit, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
