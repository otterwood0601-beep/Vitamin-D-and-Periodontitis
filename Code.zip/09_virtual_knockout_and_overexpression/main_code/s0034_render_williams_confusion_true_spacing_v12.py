from __future__ import annotations
import hashlib
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.colors as mcolors
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import numpy as np
import pandas as pd
OUT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260907_Williams\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de\u6df7\u6dc6\u77e9\u9635_\u4ec5E\u56fe_True\u95f4\u8ddd\u5bf9\u79f0_\u652f\u7ebf_v12')
SOURCE_DATA = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260906_Geneformer_Williams\u7aef\u5230\u7aef\u4fdd\u5b88\u6a21\u578b_\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de_D-E\u91cd\u7ed8_\u652f\u7ebf_v8\\\u6570\u636e\u8868\\Williams\u5168\u90e81450\u4e2a\u6d4b\u8bd5\u7ec6\u80de_\u539f\u59cbGeneformer_logits.csv.gz')
SOURCE_V11 = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260907_Williams\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de\u6df7\u6dc6\u77e9\u9635_\u4ec5E\u56fe_\u53bblabel_\u6781\u7b80\u753b\u5e03_\u652f\u7ebf_v11\\\u56fe\u7247\\\u56fe1E_Geneformer\u7ec6\u80de\u72b6\u6001\u9884\u6d4b\u6df7\u6dc6\u77e9\u9635_Williams\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de_\u53bblabel_\u6781\u7b80\u753b\u5e03_v11.pdf')
STEM = '\u56fe1E_Geneformer\u7ec6\u80de\u72b6\u6001\u9884\u6d4b\u6df7\u6dc6\u77e9\u9635_Williams\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de_True\u95f4\u8ddd\u5bf9\u79f0_v12'
CLASS_NAMES = ('Healthy', 'Periodontitis')

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def calculate() -> tuple[np.ndarray, float, float, list[list[int]]]:
    data = pd.read_csv(SOURCE_DATA)
    labels = data['observed_label'].to_numpy(dtype=int)
    predictions = data['predicted_label'].to_numpy(dtype=int)
    if len(data) != 1450:
        raise ValueError(f'Expected 1450 cells, found {len(data)}')
    matrix = np.zeros((2, 2), dtype=int)
    for observed, predicted in zip(labels, predictions, strict=True):
        matrix[int(observed), int(predicted)] += 1
    if not np.array_equal(matrix, np.array([[677, 235], [166, 372]], dtype=int)):
        raise ValueError(f'Confusion matrix changed: {matrix.tolist()}')
    accuracy = float(np.mean(labels == predictions))
    f1_values: list[float] = []
    for category in (0, 1):
        tp = int(((labels == category) & (predictions == category)).sum())
        fp = int(((labels != category) & (predictions == category)).sum())
        fn = int(((labels == category) & (predictions != category)).sum())
        f1_values.append(2 * tp / (2 * tp + fp + fn))
    macro_f1 = float(np.mean(f1_values))
    if not np.isclose(accuracy, 0.723448275862069):
        raise ValueError('Accuracy changed')
    if not np.isclose(macro_f1, 0.7106458154493089):
        raise ValueError('Macro-F1 changed')
    return (matrix / matrix.sum(axis=1, keepdims=True), accuracy, macro_f1, matrix.tolist())

def draw(matrix_norm: np.ndarray, accuracy: float, macro_f1: float) -> dict[str, object]:
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 7.5, 'axes.labelsize': 8, 'xtick.labelsize': 7.5, 'ytick.labelsize': 7.5, 'axes.linewidth': 0.6, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none'})
    fig = plt.figure(figsize=(2.6, 2.65), facecolor='white')
    ax = fig.add_axes([0.27, 0.35, 0.56, 0.56])
    cmap = plt.get_cmap('Blues')
    norm = mcolors.Normalize(vmin=0.0, vmax=1.0)
    for row in range(2):
        for column in range(2):
            value = float(matrix_norm[row, column])
            ax.add_patch(Rectangle((column, row), 1, 1, facecolor=cmap(norm(value)), edgecolor='white', linewidth=0.5))
            ax.text(column + 0.5, row + 0.5, f'{value:.2f}', ha='center', va='center', fontsize=10, color='white' if value >= 0.55 else 'black')
    ax.set_xlim(0, 2)
    ax.set_ylim(2, 0)
    ax.set_aspect('equal')
    ax.set_xticks([0.5, 1.5], CLASS_NAMES)
    ax.set_yticks([0.5, 1.5], CLASS_NAMES)
    for tick_label in ax.get_yticklabels():
        tick_label.set_rotation(90)
        tick_label.set_rotation_mode('anchor')
        tick_label.set_horizontalalignment('center')
        tick_label.set_verticalalignment('center')
    ax.set_xlabel('Predicted', labelpad=4)
    ax.set_ylabel('True', labelpad=4)
    ax.tick_params(axis='x', length=0, pad=4)
    ax.tick_params(axis='y', length=0, pad=4)
    for spine in ax.spines.values():
        spine.set_color('#B0B0B0')
        spine.set_linewidth(0.6)
    colorbar_ax = fig.add_axes([0.855, 0.35, 0.036, 0.56])
    for step in range(128):
        y0 = step / 128
        colorbar_ax.add_patch(Rectangle((0, y0), 1, 1 / 128, facecolor=cmap((step + 0.5) / 128), edgecolor='none', linewidth=0))
    colorbar_ax.set_xlim(0, 1)
    colorbar_ax.set_ylim(0, 1)
    colorbar_ax.set_xticks([])
    colorbar_ax.set_yticks([0.2, 0.4, 0.6, 0.8])
    colorbar_ax.yaxis.tick_right()
    colorbar_ax.tick_params(axis='y', labelsize=6, length=2, pad=2)
    for spine in colorbar_ax.spines.values():
        spine.set_linewidth(0.5)
    ax.text(0.5, -0.31, f'Accuracy: {accuracy:.2f}\nF1 score: {macro_f1:.2f}', transform=ax.transAxes, ha='center', va='top', fontsize=8.5, linespacing=1.12)
    image_dir = OUT / '\u56fe\u7247'
    image_dir.mkdir(parents=True, exist_ok=True)
    paths = {suffix: image_dir / f'{STEM}.{suffix}' for suffix in ('pdf', 'svg', 'png')}
    fig.savefig(paths['pdf'], facecolor='white', bbox_inches='tight', pad_inches=0.025)
    fig.savefig(paths['svg'], facecolor='white', bbox_inches='tight', pad_inches=0.025)
    fig.savefig(paths['png'], dpi=600, facecolor='white', bbox_inches='tight', pad_inches=0.025)
    plt.close(fig)
    return {name: str(path) for name, path in paths.items()}

def main() -> None:
    for directory in ('\u56fe\u7247', '\u6570\u636e\u8868', 'QA'):
        (OUT / directory).mkdir(parents=True, exist_ok=True)
    source_hash_before = sha256(SOURCE_V11)
    matrix_norm, accuracy, macro_f1, matrix = calculate()
    outputs = draw(matrix_norm, accuracy, macro_f1)
    source_hash_after = sha256(SOURCE_V11)
    if source_hash_before != source_hash_after:
        raise RuntimeError('v11 source was modified')
    pd.DataFrame({'True state': CLASS_NAMES, 'Predicted Healthy': matrix_norm[:, 0], 'Predicted Periodontitis': matrix_norm[:, 1]}).to_csv(OUT / '\u6570\u636e\u8868' / 'Williams\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de_\u884c\u5f52\u4e00\u5316\u6df7\u6dc6\u77e9\u9635_v12.csv', index=False, encoding='utf-8-sig')
    audit = {'status': 'left whitespace reduced; v11 not overwritten', 'source_v11': str(SOURCE_V11), 'source_v11_sha256_before': source_hash_before, 'source_v11_sha256_after': source_hash_after, 'change': 'True-to-category spacing now uses the same 4 pt axis-label and tick-label padding as Predicted', 'population': {'Healthy': 912, 'Periodontitis': 538, 'total': 1450}, 'confusion_matrix': matrix, 'accuracy_full_precision': accuracy, 'macro_f1_full_precision': macro_f1, 'outputs': outputs, 'vector_contract': 'all visible objects are native PDF vectors; no embedded raster image'}
    (OUT / 'QA' / '\u8fd0\u884c\u4e0e\u77e2\u91cf\u5ba1\u8ba1_v12.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(audit, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
