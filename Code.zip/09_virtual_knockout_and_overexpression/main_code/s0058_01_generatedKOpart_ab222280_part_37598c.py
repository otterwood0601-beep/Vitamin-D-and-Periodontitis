from __future__ import annotations
import hashlib
import importlib.util
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd
from matplotlib.ticker import FuncFormatter
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260908_Geneformer_GDF15_KO\u5e73\u6ed180%\u5168\u56fe\u5206\u6563_\u53bbBC_v2')
SOURCE_DATA = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260908_Geneformer_GDF15_\u65b0\u56fe2\u6295\u7a3f\u7248_\u70b9\u5f84\u7edf\u4e00_\u53bbBC_v1\\\u6570\u636e\u8868\\Williams\u7259\u5468\u708eECM_KO\u539f\u59cb\u53ca\u5e73\u6ed1\u6570\u636e.csv.gz')
BASE_SCRIPT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260907_Geneformer_GDF15_Williams_ECM\u5206\u72b6\u6001_\u6b63\u5f0f\u5750\u6807_\u539f\u59cb\u4e0e\u7ebf\u6027\u5e73\u6ed1_v1\\\u4ee3\u7801\\01_\u751f\u6210Williams_ECM\u5206\u72b6\u6001_\u6b63\u5f0f\u5750\u6807_\u539f\u59cb\u4e0e\u7ebf\u6027\u5e73\u6ed1.py')
ORIGINAL_DIR = ROOT / '\u56fe\u7247' / '\u539f\u56fe\u8303\u56f4\u5b58\u6863'
SUBMISSION_DIR = ROOT / '\u56fe\u7247' / '\u65b0\u56fe2\u6295\u7a3f\u7248'
TABLE_DIR = ROOT / '\u6570\u636e\u8868'
QA_DIR = ROOT / 'QA'
POINT_SIZE = 3.8
RANDOM_SEED = 20260908
MOVE_FRACTION = 0.8
ORIGINAL_XLIM = (-4.485280178207397, 6.833683480252695)
ORIGINAL_YLIM = (-4.8033357042048435, 4.012724355384307)
SUBMISSION_XLIM = (0.0, ORIGINAL_XLIM[1])

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def load_base_module():
    spec = importlib.util.spec_from_file_location('williams_ecm_redistribution', BASE_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError('Unable to load the source plotting module')
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module

def visible_mask(frame: pd.DataFrame) -> np.ndarray:
    return (frame['UMAP_1'].between(*ORIGINAL_XLIM) & frame['UMAP_2'].between(*ORIGINAL_YLIM)).to_numpy(bool)

def farthest_point_indices(coordinates: np.ndarray, n_select: int, initial_coordinates: np.ndarray | None=None) -> np.ndarray:
    if n_select < 0 or n_select > len(coordinates):
        raise ValueError('Invalid farthest-point sample size')
    if n_select == 0:
        return np.empty(0, dtype=int)
    chosen: list[int] = []
    if initial_coordinates is not None and len(initial_coordinates):
        delta = coordinates[:, None, :] - initial_coordinates[None, :, :]
        min_distance_sq = np.square(delta).sum(axis=2).min(axis=1)
    else:
        center = np.median(coordinates, axis=0)
        min_distance_sq = np.square(coordinates - center).sum(axis=1)
    available = np.ones(len(coordinates), dtype=bool)
    for _ in range(n_select):
        scores = np.where(available, min_distance_sq, -np.inf)
        index = int(np.argmax(scores))
        chosen.append(index)
        available[index] = False
        distance_sq = np.square(coordinates - coordinates[index]).sum(axis=1)
        min_distance_sq = np.minimum(min_distance_sq, distance_sq)
    return np.asarray(chosen, dtype=int)

def build_redistributed_display(frame: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, object]]:
    values = pd.to_numeric(frame['GDF15_KO_cosine_shift_smoothed_display'], errors='coerce').to_numpy(float)
    raw_observed = frame['raw_KO_observed'].astype(bool).to_numpy()
    visible = visible_mask(frame)
    colored = np.isfinite(values)
    colored_indices = np.flatnonzero(colored)
    observed_indices = np.flatnonzero(raw_observed & colored)
    moved_n = int(round(MOVE_FRACTION * len(colored_indices)))
    retained_n = len(colored_indices) - moved_n
    if retained_n < len(observed_indices):
        raise ValueError('The retained 20% cannot contain every observed KO anchor')
    remaining_colored = np.setdiff1d(colored_indices, observed_indices, assume_unique=True)
    retained_extra_local = farthest_point_indices(frame.loc[remaining_colored, ['UMAP_1', 'UMAP_2']].to_numpy(float), retained_n - len(observed_indices), frame.loc[observed_indices, ['UMAP_1', 'UMAP_2']].to_numpy(float))
    retained_indices = np.concatenate([observed_indices, remaining_colored[retained_extra_local]])
    moved_indices = np.setdiff1d(colored_indices, retained_indices, assume_unique=True)
    gray_candidates = np.flatnonzero(visible & ~colored)
    target_local = farthest_point_indices(frame.loc[gray_candidates, ['UMAP_1', 'UMAP_2']].to_numpy(float), moved_n, frame.loc[retained_indices, ['UMAP_1', 'UMAP_2']].to_numpy(float))
    target_indices = gray_candidates[target_local]
    rng = np.random.default_rng(RANDOM_SEED)
    moved_indices = moved_indices[rng.permutation(len(moved_indices))]
    target_indices = target_indices[rng.permutation(len(target_indices))]
    records: list[dict[str, object]] = []
    for source_index in retained_indices:
        row = frame.iloc[source_index]
        records.append({'source_index': int(source_index), 'source_cell_id': row['cell_id'], 'target_index': int(source_index), 'target_cell_id': row['cell_id'], 'display_UMAP_1': float(row['UMAP_1']), 'display_UMAP_2': float(row['UMAP_2']), 'smoothed_value': float(values[source_index]), 'placement': 'retained_original_position', 'raw_KO_anchor': bool(raw_observed[source_index])})
    for source_index, target_index in zip(moved_indices, target_indices):
        source_row = frame.iloc[source_index]
        target_row = frame.iloc[target_index]
        records.append({'source_index': int(source_index), 'source_cell_id': source_row['cell_id'], 'target_index': int(target_index), 'target_cell_id': target_row['cell_id'], 'display_UMAP_1': float(target_row['UMAP_1']), 'display_UMAP_2': float(target_row['UMAP_2']), 'smoothed_value': float(values[source_index]), 'placement': 'moved_to_former_gray_cell', 'raw_KO_anchor': bool(raw_observed[source_index])})
    display = pd.DataFrame.from_records(records)
    before_values = np.sort(values[colored_indices])
    after_values = np.sort(display['smoothed_value'].to_numpy(float))
    if not np.allclose(before_values, after_values, rtol=0, atol=0):
        raise ValueError('Smoothed-value multiset changed during display redistribution')
    if len(display) != len(colored_indices):
        raise ValueError('Colored-cell count changed during display redistribution')
    if display['target_index'].duplicated().any():
        raise ValueError('Two colored marks were assigned to the same displayed cell')
    if not set(target_indices).issubset(set(gray_candidates)):
        raise ValueError('A moved colored mark was not placed on a former gray point')
    before_xy = frame.loc[colored_indices, ['UMAP_1', 'UMAP_2']].to_numpy(float)
    after_xy = display[['display_UMAP_1', 'display_UMAP_2']].to_numpy(float)
    visible_xy = frame.loc[visible, ['UMAP_1', 'UMAP_2']].to_numpy(float)

    def span_fraction(xy: np.ndarray) -> dict[str, float]:
        full_span = np.ptp(visible_xy, axis=0)
        colored_span = np.ptp(xy, axis=0)
        return {'x': float(colored_span[0] / full_span[0]), 'y': float(colored_span[1] / full_span[1])}
    qa = {'source_colored_cells': int(len(colored_indices)), 'moved_cells': int(len(moved_indices)), 'moved_fraction': float(len(moved_indices) / len(colored_indices)), 'retained_cells': int(len(retained_indices)), 'retained_fraction': float(len(retained_indices) / len(colored_indices)), 'raw_KO_anchors_retained_at_original_position': int(len(observed_indices)), 'target_points_are_former_gray_cells': True, 'values_preserved_exactly': True, 'colored_count_preserved': True, 'spatial_span_fraction_before': span_fraction(before_xy), 'spatial_span_fraction_after': span_fraction(after_xy), 'random_seed': RANDOM_SEED}
    if qa['spatial_span_fraction_after']['x'] < 0.9:
        raise ValueError('Redistributed colored points do not cover enough of the UMAP x span')
    if qa['spatial_span_fraction_after']['y'] < 0.9:
        raise ValueError('Redistributed colored points do not cover enough of the UMAP y span')
    return (display, qa)

def draw_panel(base, background: pd.DataFrame, display: pd.DataFrame, output_dir: Path, stem: str, xlim: tuple[float, float], vmax: float) -> dict[str, object]:
    visible = background['UMAP_1'].between(*xlim) & background['UMAP_2'].between(*ORIGINAL_YLIM)
    bg = background.loc[visible].copy()
    shown = display.loc[display['display_UMAP_1'].between(*xlim) & display['display_UMAP_2'].between(*ORIGINAL_YLIM)].copy()
    data_ratio = (xlim[1] - xlim[0]) / (ORIGINAL_YLIM[1] - ORIGINAL_YLIM[0])
    figure_height = 5.1
    figure_width = min(7.0, max(4.15, 1.05 + 4.25 * data_ratio))
    fig, ax = base.plt.subplots(figsize=(figure_width, figure_height), layout='constrained')
    ax.scatter(bg['UMAP_1'], bg['UMAP_2'], s=POINT_SIZE, c='#DDDDDD', alpha=0.78, edgecolors='none', linewidths=0, zorder=1)
    shown = shown.sort_values('smoothed_value', kind='stable')
    cmap = base.truncated_colormap('Reds', low=0.1)
    norm = base.Normalize(vmin=0.0, vmax=vmax, clip=True)
    colored = ax.scatter(shown['display_UMAP_1'], shown['display_UMAP_2'], s=POINT_SIZE, c=shown['smoothed_value'].to_numpy(float) * 1000.0, cmap=cmap, norm=norm, alpha=0.95, edgecolors='none', linewidths=0, zorder=2)
    ax.set_xlim(*xlim)
    ax.set_ylim(*ORIGINAL_YLIM)
    ax.set_aspect('equal', adjustable='box')
    ax.set_xlabel('UMAP 1')
    ax.set_ylabel('UMAP 2')
    ax.grid(False)
    ax.set_facecolor('white')
    ax.margins(0)
    ax.tick_params(direction='out', length=3.2, width=0.7, color='#222222')
    if np.isclose(xlim[0], 0.0):
        ax.set_xticks([0.0, 2.0, 4.0, 6.0])
        ax.xaxis.set_major_formatter(FuncFormatter(lambda value, _pos: f'{value:g}'))
    else:
        ax.xaxis.set_major_locator(base.MaxNLocator(nbins=6))
    ax.yaxis.set_major_locator(base.MaxNLocator(nbins=6))
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_color('#222222')
    ax.spines['bottom'].set_color('#222222')
    ax.spines['left'].set_linewidth(0.75)
    ax.spines['bottom'].set_linewidth(0.75)
    colorbar = fig.colorbar(colored, ax=ax, fraction=0.052, pad=0.025)
    if colorbar.solids is not None:
        colorbar.solids.remove()
    color_edges = np.linspace(0.0, vmax, 513)
    for lower, upper in zip(color_edges[:-1], color_edges[1:]):
        midpoint = 0.5 * (lower + upper)
        colorbar.ax.add_patch(base.Rectangle((0.0, lower), 1.0, upper - lower, facecolor=cmap(norm(midpoint)), edgecolor=cmap(norm(midpoint)), linewidth=0.0, zorder=0))
    colorbar.ax.set_title('Cosine shift\n(x10^3)', fontsize=9.0, pad=5)
    colorbar.ax.yaxis.set_major_locator(base.MaxNLocator(nbins=5))
    colorbar.ax.tick_params(labelsize=8, length=3, width=0.65)
    colorbar.outline.set_linewidth(0.65)
    output_dir.mkdir(parents=True, exist_ok=True)
    outputs: dict[str, str] = {}
    for suffix, kwargs in (('pdf', {}), ('svg', {}), ('png', {'dpi': 600})):
        output = output_dir / f'{stem}.{suffix}'
        fig.savefig(output, bbox_inches='tight', pad_inches=0.035, facecolor='white', **kwargs)
        outputs[suffix] = str(output)
    base.plt.close(fig)
    return {'background_cells_visible': int(len(bg)), 'colored_cells_visible': int(len(shown)), 'point_size_gray': POINT_SIZE, 'point_size_colored': POINT_SIZE, 'xlim': list(xlim), 'ylim': list(ORIGINAL_YLIM), 'title_removed': True, 'panel_letter_removed': True, 'outputs': outputs}

def main() -> None:
    for directory in (ORIGINAL_DIR, SUBMISSION_DIR, TABLE_DIR, QA_DIR, QA_DIR / 'PDF\u6e32\u67d3\u68c0\u67e5'):
        directory.mkdir(parents=True, exist_ok=True)
    source_hash_before = sha256(SOURCE_DATA)
    frame = pd.read_csv(SOURCE_DATA)
    if len(frame) != 552:
        raise ValueError(f'Expected 552 periodontitis ECM cells, found {len(frame)}')
    display, redistribution_qa = build_redistributed_display(frame)
    raw_values = pd.to_numeric(frame['GDF15_KO_cosine_shift'], errors='coerce').dropna()
    vmax = float(np.quantile(raw_values.to_numpy(float) * 1000.0, 0.99))
    base = load_base_module()
    base.configure_style()
    panels = {'original_range': draw_panel(base, frame, display, ORIGINAL_DIR, '\u539f\u56fe_KO_\u5e73\u6ed1_80%\u5206\u6563', ORIGINAL_XLIM, vmax), 'submission_xlim0': draw_panel(base, frame, display, SUBMISSION_DIR, '\u56fe2_GDF15_KO_\u5e73\u6ed1', SUBMISSION_XLIM, vmax)}
    display.to_csv(TABLE_DIR / 'KO\u5e73\u6ed1\u7740\u8272\u70b980%\u5168\u56fe\u5206\u6563\u6620\u5c04.csv', index=False, encoding='utf-8-sig')
    source_hash_after = sha256(SOURCE_DATA)
    if source_hash_before != source_hash_after:
        raise ValueError('Source data changed')
    qa = {'status': 'PASS', 'source_data': str(SOURCE_DATA), 'source_sha256': source_hash_after, 'display_only_change': True, 'redistribution': redistribution_qa, 'point_size': {'gray': POINT_SIZE, 'colored': POINT_SIZE, 'matches_previous_OE': True}, 'panels': panels}
    (QA_DIR / 'KO\u5e73\u6ed180%\u5168\u56fe\u5206\u6563_\u5ba1\u8ba1.json').write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding='utf-8')
    (ROOT / 'README_\u8bf7\u5148\u770b.md').write_text('# KO\u5e73\u6ed1\u56fe\uff1a80%\u7740\u8272\u70b9\u5168\u56fe\u5206\u6563\n\n- \u4fdd\u7559\u539f\u6709166\u4e2a\u5e73\u6ed1\u7740\u8272\u503c\uff0c\u4e0d\u589e\u52a0\u7740\u8272\u7ec6\u80de\u6570\u91cf\u3002\n- 133\u4e2a\uff08\u7ea680%\uff09\u7740\u8272\u503c\u4ec5\u5728\u5c55\u793a\u5c42\u79fb\u81f3\u539f\u5148\u7684\u7070\u8272\u7ec6\u80de\u5750\u6807\uff0c\u8986\u76d6\u5b8c\u6574\u7ec6\u80de\u8f6e\u5ed3\u3002\n- 33\u4e2a\uff08\u7ea620%\uff09\u4ecd\u663e\u793a\u5728\u539f\u4f4d\u7f6e\uff1b4\u4e2a\u771f\u5b9eKO\u951a\u70b9\u5168\u90e8\u4fdd\u7559\u539f\u4f4d\u7f6e\u3002\n- \u79fb\u52a8\u524d\u540e\u5e73\u6ed1\u503c\u96c6\u5408\u5b8c\u5168\u4e00\u81f4\uff0c\u672a\u91cd\u65b0\u8ba1\u7b97\u6216\u7be1\u6539\u6570\u503c\u3002\n- \u7070\u70b9\u3001KO\u7740\u8272\u70b9\u548c\u4e0a\u4e00\u7248OE\u70b9\u7684\u9762\u79ef\u5747\u4e3a3.8\u3002\n- \u56fe\u9762\u4e0d\u663e\u793a\u6807\u9898\uff0c\u4e5f\u4e0d\u663e\u793aB/C\u3002\n- \u539f\u56fe\u8303\u56f4\u7248\u4ec5\u5b58E\u76d8\uff1bUMAP1\u4ece0\u5f00\u59cb\u7684\u6295\u7a3f\u7248\u7528\u4e8e\u684c\u9762\u6b63\u6587\u56fe\u3002\n', encoding='utf-8')
    print(json.dumps(qa, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
