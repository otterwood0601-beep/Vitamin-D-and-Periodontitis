from __future__ import annotations
import argparse
import hashlib
import json
import os
import platform
import random
import sys
import time
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import h5py
import numpy as np
import pandas as pd
import pypdf
import sklearn
import torch
import transformers
from pypdf import PdfReader
from pypdf.generic import ContentStream
from sklearn.ensemble import ExtraTreesRegressor
from transformers import BertForSequenceClassification
SEED = 20260904
PAD_TOKEN_ID = 0
GDF15_TOKEN_ID = 6248
MAX_LENGTH = 2048
EXPECTED_ALL = 13257
EXPECTED_HEALTHY = 9980
EXPECTED_PERIODONTITIS = 3277
REFERENCE_UMAP_SEED = 42
EXPECTED_FORMAL_EXACT = 13203
EXPECTED_PROJECTED = 54
PDF_MARKER_TO_TYPE = {'/P0': 'Vascular', '/P1': 'Immune', '/P2': 'ECM remodeling', '/P3': 'Pre-extracellular matrix', '/P4': 'Matrix homeostasis'}
PDF_EXPECTED_COUNTS = {'/P0': 3500, '/P1': 5695, '/P2': 2797, '/P3': 1573, '/P4': 1744}
CLIPPED_SOURCE_POSITIONS = {'Vascular': {2710, 3499}, 'Immune': {790, 4679}}
PROJECT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260904_Geneformer_GDF15_ERK_MAPK_ECM_\u8bba\u6587\u540c\u578b\u590d\u73b0_v1')
OUT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260906_Geneformer_GDF15_KO_OE_Williams\u5168\u90e8\u7ec6\u80de_\u4e00\u6b21\u6027\u652f\u7ebf_v1')
INPUT_DIR = PROJECT / '01_\u8f93\u5165\u4e0eGeneformer\u5206\u8bcd' / 'Williams'
MODEL_DIR = PROJECT / '02_\u72b6\u6001\u5206\u7c7b\u5668' / 'Williams' / 'best_model'
ALL_CELL_BRANCH = PROJECT / '14_GDF15\u5168\u7ec6\u80de\u6572\u9664\u654f\u611f\u6027UMAP_\u652f\u7ebf_v1'
KO_SOURCE = ALL_CELL_BRANCH / '\u6570\u636e\u8868' / 'Williams_GDF15_KO_sensitivity_UMAP_\u5168\u90e813257\u7ec6\u80de.csv.gz'
EMBED_SOURCE = ALL_CELL_BRANCH / '\u6570\u636e\u8868' / 'Williams_Geneformer_\u5168\u90e813257\u7ec6\u80de\u539f\u59cb\u5d4c\u5165.npz'
HEALTHY_OE_SOURCE = PROJECT / '09_\u8bba\u6587\u539f\u56fe\u4e25\u683c\u590d\u6838\u4e0eGDF15\u8fc7\u8868\u8fbe\u8865\u5145_v3_\u5168\u91cf\u72b6\u6001\u7ec6\u80de' / '\u6570\u636e\u8868' / '\u5065\u5eb7\u5168\u90e89980\u7ec6\u80de_GDF15\u8fc7\u8868\u8fbe\u654f\u611f\u6027.csv.gz'
REFERENCE_PDF = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u6b63\u6587\u56fe\\\u6b63\u6587\u56fe4 sc-RNA\\A.5\u79cd\u7ec6\u80de\u5206\u7c7b\u5730\u56fe.pdf')
ATLAS_DERIVED = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u539f\u59cb\u6570\u636e\\05_\u5355\u7ec6\u80deRNA\\\u6d3e\u751f\u8f93\u5165\\GDF15_Figure1')
FULL_CLUSTER_MAP = ATLAS_DERIVED / 'cell_cluster_mapping.csv.gz'
FULL_CELL_METADATA = ATLAS_DERIVED / 'input_fb' / 'CELLxGENE\u76f4\u63a5\u6807\u6ce8fibroblast_\u9010\u7ec6\u80de\u5143\u6570\u636e_QC\u540e.csv.gz'
FIVE_TYPE_MAP = ATLAS_DERIVED / 'five_type_merge_mapping.csv'
H5AD = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u539f\u59cb\u6570\u636e\\05_\u5355\u7ec6\u80deRNA\\01_scRNA-seq') / 'CELLxGENE_Integrated_Periodontitis_Atlas' / 'processed' / 'Integrated_Human_Periodontitis_Atlas_105918cells.h5ad'
MAINLINE_GUARDS = [PROJECT / '09_\u8bba\u6587\u539f\u56fe\u4e25\u683c\u590d\u6838\u4e0eGDF15\u8fc7\u8868\u8fbe\u8865\u5145_v3_\u5168\u91cf\u72b6\u6001\u7ec6\u80de' / '\u56fe\u7247' / '\u56fe2_GDF15\u6572\u9664\u4e0e\u8fc7\u8868\u8fbe\u654f\u611f\u6027UMAP_Frontiers\u4e25\u683c\u540c\u578b_v3_\u5168\u91cf\u72b6\u6001\u7ec6\u80de.pdf', Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa') / '20260906_Geneformer_GDF15_Williams\u5355\u961f\u5217_\u5168\u56fe\u7ea0\u9519\u6c47\u603b_v1' / '\u56fe\u7247' / '\u56fe2_GDF15\u6572\u9664\u4e0e\u8fc7\u8868\u8fbe\u654f\u611f\u6027UMAP_Williams\u5168\u91cf\u7ec6\u80de\u7ea0\u9519\u7248.pdf']
FIG_DIR = OUT / '\u56fe\u7247'
TABLE_DIR = OUT / '\u6570\u636e\u8868'
QA_DIR = OUT / 'QA'
OE_CHUNK_DIR = QA_DIR / '\u7259\u5468\u708e\u7ec6\u80deGDF15\u8fc7\u8868\u8fbe\u5206\u5757'
OUTPUT_TABLE = TABLE_DIR / 'Williams\u5168\u90e813257\u7ec6\u80de_GDF15_KO_OE\u654f\u611f\u6027.csv.gz'
REFERENCE_UMAP_CACHE = TABLE_DIR / 'Williams\u5168\u90e813257\u7ec6\u80de_A\u56fe\u53c2\u8003\u5750\u6807\u7cfb_UMAP\u5750\u6807.csv.gz'
STEM = '\u8865\u5145\u56fe_GDF15\u6572\u9664\u4e0e\u8fc7\u8868\u8fbe\u654f\u611f\u6027UMAP_Williams\u5168\u90e813257\u7ec6\u80de_\u4e00\u6b21\u6027\u652f\u7ebf'
OUTPUT_PDF = FIG_DIR / f'{STEM}.pdf'
OUTPUT_PNG = FIG_DIR / f'{STEM}.png'
OUTPUT_SVG = FIG_DIR / f'{STEM}.svg'
QA_JSON = QA_DIR / 'Williams\u5168\u90e8\u7ec6\u80de_KO_OE_\u4e00\u6b21\u6027\u652f\u7ebf_\u8fd0\u884c\u4e0e\u6570\u636e\u5ba1\u8ba1.json'

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description='One-off Williams all-cell GDF15 KO/OE sensitivity figure')
    parser.add_argument('stage', choices=['compute', 'plot', 'all'])
    parser.add_argument('--batch-size', type=int, default=8)
    parser.add_argument('--chunk-size', type=int, default=256)
    return parser.parse_args()

def ensure_dirs() -> None:
    for path in (FIG_DIR, TABLE_DIR, QA_DIR, OE_CHUNK_DIR):
        path.mkdir(parents=True, exist_ok=True)

def set_deterministic() -> None:
    os.environ.setdefault('PYTHONHASHSEED', str(SEED))
    random.seed(SEED)
    np.random.seed(SEED)
    torch.manual_seed(SEED)
    torch.use_deterministic_algorithms(False)
    torch.set_num_threads(min(14, os.cpu_count() or 1))

def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def guard_hashes() -> dict[str, str]:
    return {str(path): file_sha256(path) for path in MAINLINE_GUARDS if path.exists()}

def mean_pool(last_hidden: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
    weights = attention_mask.unsqueeze(-1).to(last_hidden.dtype)
    return (last_hidden * weights).sum(dim=1) / weights.sum(dim=1).clamp_min(1.0)

def embed_sequences(model: BertForSequenceClassification, sequences: list[np.ndarray], batch_size: int) -> np.ndarray:
    outputs: list[np.ndarray] = []
    model.eval()
    with torch.inference_mode():
        for start in range(0, len(sequences), batch_size):
            batch = sequences[start:start + batch_size]
            max_len = max((len(sequence) for sequence in batch))
            ids = torch.full((len(batch), max_len), PAD_TOKEN_ID, dtype=torch.long)
            mask = torch.zeros((len(batch), max_len), dtype=torch.long)
            for row, sequence in enumerate(batch):
                length = len(sequence)
                ids[row, :length] = torch.as_tensor(sequence, dtype=torch.long)
                mask[row, :length] = 1
            hidden = model.bert(input_ids=ids, attention_mask=mask, return_dict=True).last_hidden_state
            outputs.append(mean_pool(hidden, mask).cpu().numpy().astype(np.float32))
    return np.concatenate(outputs, axis=0)

def paired_cosine_distance(original: np.ndarray, perturbed: np.ndarray) -> np.ndarray:
    numerator = np.einsum('ij,ij->i', original, perturbed)
    denominator = np.linalg.norm(original, axis=1) * np.linalg.norm(perturbed, axis=1)
    similarity = numerator / np.clip(denominator, 1e-12, None)
    return np.clip(1.0 - similarity, 0.0, None)

def overexpress_sequence(sequence: np.ndarray) -> np.ndarray:
    sequence_without_gdf15 = sequence[sequence != GDF15_TOKEN_ID]
    return np.concatenate([np.asarray([GDF15_TOKEN_ID], dtype=np.int64), sequence_without_gdf15.astype(np.int64)])[:MAX_LENGTH]

def extract_formal_pdf_coordinates() -> dict[str, np.ndarray]:
    page = PdfReader(str(REFERENCE_PDF)).pages[0]
    operations = ContentStream(page.get_contents(), page.pdf).operations
    groups: dict[str, list[tuple[float, float]]] = {marker: [] for marker in PDF_MARKER_TO_TYPE}
    for operation_index, (operands, operator) in enumerate(operations):
        if operator != b'Do' or str(operands[0]) not in groups:
            continue
        previous_operands, previous_operator = operations[operation_index - 1]
        if previous_operator != b'cm':
            raise RuntimeError('Unexpected marker transform in formal A-panel PDF')
        x_page = float(previous_operands[4])
        y_page = float(previous_operands[5])
        x_data = -6.0 + (x_page - 54.0) / 446.39 * 13.25
        y_data = -6.5 + (y_page - 53.28) / 446.39 * 13.25
        groups[str(operands[0])].append((x_data, y_data))
    extracted = {marker: np.asarray(points, dtype=np.float64) for marker, points in groups.items()}
    counts = {marker: len(points) for marker, points in extracted.items()}
    if counts != PDF_EXPECTED_COUNTS:
        raise ValueError(f'Unexpected marker counts in formal A-panel PDF: {counts}')
    return extracted

def build_reference_umap_coordinates(metadata: pd.DataFrame) -> pd.DataFrame:
    if REFERENCE_UMAP_CACHE.exists():
        cached = pd.read_csv(REFERENCE_UMAP_CACHE)
        required = {'dataset_index', 'UMAP_1', 'UMAP_2', 'coordinate_source'}
        if required.issubset(cached.columns) and len(cached) == EXPECTED_ALL and (cached['dataset_index'].nunique() == EXPECTED_ALL) and (int(cached['coordinate_source'].eq('exact_formal_PDF').sum()) == EXPECTED_FORMAL_EXACT):
            return cached
    pdf_groups = extract_formal_pdf_coordinates()
    clusters = pd.read_csv(FULL_CLUSTER_MAP)
    clusters['source_order'] = np.arange(len(clusters), dtype=int)
    full_metadata = pd.read_csv(FULL_CELL_METADATA)
    mapping = pd.read_csv(FIVE_TYPE_MAP)[['original_fb_id', 'final_fibroblast_type']]
    atlas = clusters.merge(mapping, left_on='fb_id', right_on='original_fb_id', how='left', sort=False, validate='many_to_one').merge(full_metadata[['cell_barcode', 'h5ad_row']], on='cell_barcode', how='inner', sort=False, validate='one_to_one').sort_values('source_order').reset_index(drop=True)
    if len(atlas) != 15371:
        raise ValueError(f'Unexpected integrated fibroblast reference size: {len(atlas)}')
    short = {'Vascular-associated fibroblasts': 'Vascular', 'Immune-associated fibroblasts': 'Immune', 'ECM remodeling-associated fibroblasts': 'ECM remodeling', 'Pre-extracellular matrix-associated fibroblasts': 'Pre-extracellular matrix', 'Matrix homeostasis-associated fibroblasts': 'Matrix homeostasis'}
    atlas['Fibroblast_type'] = atlas['final_fibroblast_type'].map(short)
    atlas['UMAP_1'] = np.nan
    atlas['UMAP_2'] = np.nan
    atlas['coordinate_source'] = ''
    atlas['projection_reason'] = ''
    clipped_atlas_rows: set[int] = set()
    for marker, fibroblast_type in PDF_MARKER_TO_TYPE.items():
        source_rows = np.flatnonzero(atlas['Fibroblast_type'].astype(str).eq(fibroblast_type).to_numpy())
        skipped_positions = CLIPPED_SOURCE_POSITIONS.get(fibroblast_type, set())
        retained_positions = np.asarray([position for position in range(len(source_rows)) if position not in skipped_positions], dtype=int)
        points = pdf_groups[marker]
        if len(retained_positions) != len(points):
            raise ValueError(f'Source/PDF count mismatch for {fibroblast_type}: {len(retained_positions)} vs {len(points)}')
        exact_rows = source_rows[retained_positions]
        atlas.loc[exact_rows, ['UMAP_1', 'UMAP_2']] = points
        atlas.loc[exact_rows, 'coordinate_source'] = 'exact_formal_PDF'
        for skipped_position in skipped_positions:
            clipped_atlas_rows.add(int(source_rows[skipped_position]))
    exact_mask = atlas['coordinate_source'].eq('exact_formal_PDF').to_numpy()
    if int(exact_mask.sum()) != sum(PDF_EXPECTED_COUNTS.values()):
        raise ValueError('Not every formal PDF marker was mapped to one source cell')
    h5ad_rows = atlas['h5ad_row'].to_numpy(dtype=int) - 1
    with h5py.File(H5AD, 'r') as handle:
        atlas_pca = np.asarray(handle['obsm']['X_pca'][h5ad_rows, :50], dtype=np.float32)
        atlas_umap = np.asarray(handle['obsm']['X_umap'][h5ad_rows, :2], dtype=np.float32)
    features = np.column_stack([atlas_pca, atlas_umap])
    targets = atlas.loc[exact_mask, ['UMAP_1', 'UMAP_2']].to_numpy(dtype=float)
    projector = ExtraTreesRegressor(n_estimators=400, min_samples_leaf=2, max_features=0.85, n_jobs=-1, random_state=REFERENCE_UMAP_SEED)
    projector.fit(features[exact_mask], targets)
    missing_mask = ~exact_mask
    projected = projector.predict(features[missing_mask])
    projected[:, 0] = np.clip(projected[:, 0], -5.92, 7.18)
    projected[:, 1] = np.clip(projected[:, 1], -6.42, 6.68)
    atlas.loc[missing_mask, ['UMAP_1', 'UMAP_2']] = projected
    atlas.loc[missing_mask, 'coordinate_source'] = 'projected_into_formal_PDF_manifold'
    atlas.loc[atlas['fb_id'].eq('FB8'), 'projection_reason'] = 'FB8_absent_from_formal_five-state_panel'
    if clipped_atlas_rows:
        atlas.loc[list(clipped_atlas_rows), 'projection_reason'] = 'outside_formal_PDF_axis'
    williams = metadata[['cell_id', 'dataset_index', 'disease', 'Study']].merge(atlas[['cell_barcode', 'fb_id', 'Fibroblast_type', 'UMAP_1', 'UMAP_2', 'coordinate_source', 'projection_reason']], left_on='cell_id', right_on='cell_barcode', how='left', sort=False, validate='one_to_one')
    if len(williams) != EXPECTED_ALL:
        raise ValueError('Williams reference-coordinate merge changed the cell count')
    if not williams['Study'].astype(str).eq('Williams').all():
        raise ValueError('Non-Williams cell detected in the requested output coordinate table')
    if williams[['UMAP_1', 'UMAP_2']].isna().any().any():
        raise ValueError('A Williams cell is missing its formal A-panel coordinate')
    coordinate_counts = williams['coordinate_source'].value_counts().to_dict()
    if coordinate_counts.get('exact_formal_PDF', 0) != EXPECTED_FORMAL_EXACT:
        raise ValueError(f'Unexpected exact formal-coordinate count: {coordinate_counts}')
    if coordinate_counts.get('projected_into_formal_PDF_manifold', 0) != EXPECTED_PROJECTED:
        raise ValueError(f'Unexpected projected-coordinate count: {coordinate_counts}')
    williams = williams.drop(columns='cell_barcode').sort_values('dataset_index')
    williams.to_csv(REFERENCE_UMAP_CACHE, index=False, encoding='utf-8-sig', compression='gzip')
    return williams

def load_sources() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, np.ndarray, np.ndarray, np.ndarray]:
    metadata = pd.read_csv(INPUT_DIR / 'cell_metadata.csv')
    formal_umap = build_reference_umap_coordinates(metadata)
    ko = pd.read_csv(KO_SOURCE)
    healthy_oe = pd.read_csv(HEALTHY_OE_SOURCE)
    input_ids = np.load(INPUT_DIR / 'input_ids.npy', mmap_mode='r')
    lengths = np.load(INPUT_DIR / 'lengths.npy', mmap_mode='r')
    archive = np.load(EMBED_SOURCE)
    embedding_indices = archive['dataset_indices'].astype(int)
    original_embeddings = archive['original_embeddings'].astype(np.float32)
    expected_indices = np.arange(EXPECTED_ALL, dtype=int)
    if len(metadata) != EXPECTED_ALL:
        raise ValueError(f'Expected {EXPECTED_ALL} Williams cells, found {len(metadata)}')
    if not np.array_equal(metadata['dataset_index'].to_numpy(dtype=int), expected_indices):
        raise ValueError('Williams metadata is not in complete dataset_index order')
    if not np.array_equal(embedding_indices, expected_indices):
        raise ValueError('Original embedding archive is not complete dataset_index order')
    if original_embeddings.shape != (EXPECTED_ALL, 256):
        raise ValueError(f'Unexpected original embedding shape: {original_embeddings.shape}')
    if input_ids.shape[0] != EXPECTED_ALL or len(lengths) != EXPECTED_ALL:
        raise ValueError('Token arrays do not contain all Williams cells')
    for name, table, expected_count in (('formal UMAP', formal_umap, EXPECTED_ALL), ('KO source', ko, EXPECTED_ALL), ('healthy OE source', healthy_oe, EXPECTED_HEALTHY)):
        if len(table) != expected_count or table['dataset_index'].nunique() != expected_count:
            raise ValueError(f'{name} is incomplete or contains duplicate dataset_index values')
    if formal_umap[['UMAP_1', 'UMAP_2']].isna().any().any():
        raise ValueError('Formal Williams UMAP contains missing coordinates')
    if healthy_oe['GDF15_OE_cosine_shift'].isna().any():
        raise ValueError('Existing healthy-cell OE source contains missing values')
    state_counts = metadata['disease'].astype(str).value_counts().to_dict()
    if state_counts.get('normal') != EXPECTED_HEALTHY:
        raise ValueError(f'Unexpected healthy count: {state_counts}')
    if state_counts.get('periodontitis') != EXPECTED_PERIODONTITIS:
        raise ValueError(f'Unexpected periodontitis count: {state_counts}')
    return (metadata, formal_umap, ko, input_ids, lengths, original_embeddings)

def compute_periodontitis_oe(metadata: pd.DataFrame, input_ids: np.ndarray, lengths: np.ndarray, original_embeddings: np.ndarray, batch_size: int, chunk_size: int) -> pd.DataFrame:
    periodontitis_indices = metadata.loc[metadata['disease'].astype(str).eq('periodontitis'), 'dataset_index'].to_numpy(dtype=int)
    if len(periodontitis_indices) != EXPECTED_PERIODONTITIS:
        raise ValueError('Periodontitis index selection failed')
    model = BertForSequenceClassification.from_pretrained(str(MODEL_DIR), num_labels=2)
    started = time.time()
    chunks: list[pd.DataFrame] = []
    for start in range(0, len(periodontitis_indices), chunk_size):
        stop = min(start + chunk_size, len(periodontitis_indices))
        chunk_indices = periodontitis_indices[start:stop]
        checkpoint = OE_CHUNK_DIR / f'oe_periodontitis_{start:05d}_{stop:05d}.csv'
        if checkpoint.exists():
            chunk = pd.read_csv(checkpoint)
            if not np.array_equal(chunk['dataset_index'].to_numpy(dtype=int), chunk_indices):
                raise ValueError(f'Checkpoint key mismatch: {checkpoint}')
        else:
            sequences = [overexpress_sequence(np.asarray(input_ids[index, :int(lengths[index])], dtype=np.int64).copy()) for index in chunk_indices]
            perturbed_embeddings = embed_sequences(model, sequences, batch_size)
            shifts = paired_cosine_distance(original_embeddings[chunk_indices], perturbed_embeddings)
            chunk = pd.DataFrame({'dataset_index': chunk_indices, 'GDF15_OE_cosine_shift': shifts.astype(float)})
            chunk.to_csv(checkpoint, index=False, encoding='utf-8-sig')
        chunks.append(chunk)
        elapsed_minutes = (time.time() - started) / 60.0
        print(f'Periodontitis GDF15 OE: {stop}/{len(periodontitis_indices)} cells ({elapsed_minutes:.1f} min)', flush=True)
    result = pd.concat(chunks, ignore_index=True)
    if len(result) != EXPECTED_PERIODONTITIS or result['dataset_index'].duplicated().any():
        raise ValueError('New periodontitis OE results are incomplete or duplicated')
    if result['GDF15_OE_cosine_shift'].isna().any():
        raise ValueError('New periodontitis OE results contain missing values')
    return result

def compute_output_table(batch_size: int, chunk_size: int) -> None:
    metadata, formal_umap, ko, input_ids, lengths, original_embeddings = load_sources()
    periodontitis_oe = compute_periodontitis_oe(metadata, input_ids, lengths, original_embeddings, batch_size, chunk_size)
    healthy_oe = pd.read_csv(HEALTHY_OE_SOURCE)[['dataset_index', 'GDF15_OE_cosine_shift']]
    all_oe = pd.concat([healthy_oe, periodontitis_oe], ignore_index=True).sort_values('dataset_index')
    if len(all_oe) != EXPECTED_ALL or all_oe['dataset_index'].duplicated().any():
        raise ValueError('Combined all-cell OE result is incomplete or duplicated')
    metadata_small = metadata[['dataset_index', 'donor_id', 'label', 'GDF15_token_present']].copy()
    ko_small = ko[['dataset_index', 'GDF15_KO_cosine_shift']].copy()
    output = formal_umap.merge(metadata_small, on='dataset_index', how='left', validate='one_to_one').merge(ko_small, on='dataset_index', how='left', validate='one_to_one').merge(all_oe, on='dataset_index', how='left', validate='one_to_one').sort_values('dataset_index').reset_index(drop=True)
    if len(output) != EXPECTED_ALL or output['dataset_index'].duplicated().any():
        raise ValueError('Final table does not contain each Williams cell exactly once')
    if output['GDF15_OE_cosine_shift'].isna().any():
        raise ValueError('Final all-cell OE column contains missing values')
    token_positive = output['GDF15_token_present'].astype(bool)
    if output.loc[token_positive, 'GDF15_KO_cosine_shift'].isna().any():
        raise ValueError('A GDF15-token-positive cell is missing its KO result')
    if output.loc[~token_positive, 'GDF15_KO_cosine_shift'].notna().any():
        raise ValueError('A GDF15-token-negative cell has a KO result')
    output.to_csv(OUTPUT_TABLE, index=False, encoding='utf-8-sig', compression='gzip')

def plot_panel(ax: plt.Axes, data: pd.DataFrame, value_column: str, title: str, cmap: str, letter: str) -> None:
    values = data[value_column].to_numpy(dtype=float) * 1000.0
    finite = np.isfinite(values)
    ax.scatter(data['UMAP_1'], data['UMAP_2'], s=1.8, c='#E6E6E6', edgecolors='none', rasterized=True)
    positive = values[finite & (values > 0)]
    vmax = float(np.quantile(positive, 0.99)) if len(positive) else 1.0
    vmax = max(vmax, 1e-06)
    positions = np.flatnonzero(finite)
    positions = positions[np.argsort(values[positions])]
    scatter = ax.scatter(data.iloc[positions]['UMAP_1'], data.iloc[positions]['UMAP_2'], c=values[positions], s=7.0 if value_column == 'GDF15_KO_cosine_shift' else 2.3, cmap=cmap, vmin=0, vmax=vmax, edgecolors='none', rasterized=True)
    ax.set_title(title, fontsize=10, fontweight='bold', y=1.075, pad=0)
    ax.text(0.5, 1.018, 'All Williams fibroblasts (n = 13,257)', transform=ax.transAxes, ha='center', va='bottom', fontsize=7.2)
    ax.set_xlabel('UMAP 1')
    ax.set_ylabel('UMAP 2')
    ax.grid(False)
    ax.set_facecolor('white')
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_color('black')
        spine.set_linewidth(0.7)
    colorbar = ax.figure.colorbar(scatter, ax=ax, fraction=0.046, pad=0.03)
    colorbar.ax.set_title('Cosine shift\n(\xd710\xb3)', fontsize=6.8, pad=4)
    colorbar.ax.tick_params(labelsize=6.2, length=2.5)
    colorbar.outline.set_linewidth(0.45)
    ax.text(-0.12, 1.115, letter, transform=ax.transAxes, fontsize=16, fontweight='normal', va='top')

def plot_output() -> None:
    if not OUTPUT_TABLE.exists():
        raise FileNotFoundError('Run the compute stage before plotting')
    data = pd.read_csv(OUTPUT_TABLE)
    if len(data) != EXPECTED_ALL:
        raise ValueError('Plot input is not all 13,257 Williams cells')
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 7.5, 'axes.titlesize': 10, 'axes.labelsize': 8, 'xtick.labelsize': 7, 'ytick.labelsize': 7, 'axes.linewidth': 0.7, 'pdf.fonttype': 42, 'ps.fonttype': 42})
    fig, axes = plt.subplots(1, 2, figsize=(9.8, 4.65), sharex=True, sharey=True, facecolor='white')
    plot_panel(axes[0], data, 'GDF15_KO_cosine_shift', 'GDF15 knockout sensitivity', 'Blues', 'B')
    plot_panel(axes[1], data, 'GDF15_OE_cosine_shift', 'GDF15 overexpression sensitivity', 'Reds', 'C')
    for ax in axes:
        ax.set_xlim(-6.0, 7.25)
        ax.set_ylim(-6.5, 6.75)
        ax.set_aspect('equal', adjustable='box')
    fig.subplots_adjust(left=0.07, right=0.95, bottom=0.12, top=0.84, wspace=0.28)
    fig.savefig(OUTPUT_PDF, dpi=300, facecolor='white', bbox_inches='tight')
    fig.savefig(OUTPUT_SVG, facecolor='white', bbox_inches='tight')
    fig.savefig(OUTPUT_PNG, dpi=600, facecolor='white', bbox_inches='tight')
    plt.close(fig)

def write_qa(elapsed_seconds: float, guard_before: dict[str, str]) -> None:
    data = pd.read_csv(OUTPUT_TABLE)
    state_counts = data['disease'].astype(str).value_counts().to_dict()
    ko_finite = data['GDF15_KO_cosine_shift'].notna()
    oe_finite = data['GDF15_OE_cosine_shift'].notna()
    guard_after = guard_hashes()
    mainline_unchanged = guard_before == guard_after
    qa = {'status': 'PASS', 'scope': 'one-time side task; no mainline files written', 'input_population': {'cohort': 'Williams', 'cells_in_each_panel': EXPECTED_ALL, 'healthy_cells': int(state_counts.get('normal', 0)), 'periodontitis_cells': int(state_counts.get('periodontitis', 0))}, 'panel_B_KO': {'input_cells': EXPECTED_ALL, 'palette': 'blue', 'GDF15_token_positive_and_KO_executable_cells': int(ko_finite.sum()), 'healthy_executable_cells': int((ko_finite & data['disease'].astype(str).eq('normal')).sum()), 'periodontitis_executable_cells': int((ko_finite & data['disease'].astype(str).eq('periodontitis')).sum())}, 'panel_C_OE': {'input_cells': EXPECTED_ALL, 'palette': 'red', 'executed_cells': int(oe_finite.sum()), 'healthy_cells_reused_from_validated_mainline_table': EXPECTED_HEALTHY, 'periodontitis_cells_newly_computed': EXPECTED_PERIODONTITIS}, 'shared_coordinates': {'source': str(REFERENCE_UMAP_CACHE), 'visual_reference_pdf': str(REFERENCE_PDF), 'visual_reference_pdf_sha256': file_sha256(REFERENCE_PDF), 'coordinate_cells': EXPECTED_ALL, 'exact_coordinates_extracted_from_formal_PDF': int(data['coordinate_source'].eq('exact_formal_PDF').sum()), 'coordinates_projected_for_cells_not_visible_in_formal_PDF': int(data['coordinate_source'].eq('projected_into_formal_PDF_manifold').sum()), 'output_non_Williams_cells': int((~data['Study'].astype(str).eq('Williams')).sum()), 'reference_manifold': {'method': 'direct vector-coordinate extraction from the supplied formal A.5 PDF', 'projection_model_for_unshown_cells': 'ExtraTreesRegressor', 'projection_random_state': REFERENCE_UMAP_SEED, 'note': '13,203 Williams cells use exact formal-PDF marker coordinates; 4 clipped cells and 50 FB8 cells are projected into that same manifold.'}}, 'model': str(MODEL_DIR), 'model_sha256': file_sha256(MODEL_DIR / 'model.safetensors'), 'seed': SEED, 'mainline_guard': {'unchanged': mainline_unchanged, 'sha256_before': guard_before, 'sha256_after': guard_after}, 'software': {'python': sys.version, 'platform': platform.platform(), 'torch': torch.__version__, 'transformers': transformers.__version__, 'numpy': np.__version__, 'pandas': pd.__version__, 'matplotlib': matplotlib.__version__, 'pypdf': pypdf.__version__, 'scikit_learn': sklearn.__version__}, 'elapsed_minutes': elapsed_seconds / 60.0, 'outputs': {'pdf': str(OUTPUT_PDF), 'png': str(OUTPUT_PNG), 'svg': str(OUTPUT_SVG), 'table': str(OUTPUT_TABLE), 'script': str(Path(__file__))}}
    if state_counts.get('normal') != EXPECTED_HEALTHY:
        raise ValueError('Final healthy count failed QA')
    if state_counts.get('periodontitis') != EXPECTED_PERIODONTITIS:
        raise ValueError('Final periodontitis count failed QA')
    if int(oe_finite.sum()) != EXPECTED_ALL:
        raise ValueError('All-cell OE execution coverage failed QA')
    if int(data['coordinate_source'].eq('exact_formal_PDF').sum()) != EXPECTED_FORMAL_EXACT:
        raise ValueError('Exact formal-coordinate coverage failed QA')
    if int(data['coordinate_source'].eq('projected_into_formal_PDF_manifold').sum()) != EXPECTED_PROJECTED:
        raise ValueError('Projected coordinate coverage failed QA')
    if not data['Study'].astype(str).eq('Williams').all():
        raise ValueError('Final table contains a non-Williams cell')
    if int(ko_finite.sum()) != int(data['GDF15_token_present'].astype(bool).sum()):
        raise ValueError('KO execution coverage does not match GDF15 token presence')
    if not mainline_unchanged:
        raise RuntimeError('A guarded mainline PDF changed during this side task')
    QA_JSON.write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding='utf-8')

def main() -> None:
    args = parse_args()
    ensure_dirs()
    set_deterministic()
    started = time.time()
    guard_before = guard_hashes()
    if args.stage in {'compute', 'all'}:
        compute_output_table(args.batch_size, args.chunk_size)
    if args.stage in {'plot', 'all'}:
        plot_output()
        write_qa(time.time() - started, guard_before)
        print(OUTPUT_PDF, flush=True)
if __name__ == '__main__':
    main()
