from __future__ import annotations
import hashlib
import json
import os
import platform
import random
import sys
import time
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import transformers
from transformers import BertForSequenceClassification
SEED = 20260904
PAD_TOKEN_ID = 0
GDF15_TOKEN_ID = 6248
MAX_LENGTH = 2048
PROJECT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260904_Geneformer_GDF15_ERK_MAPK_ECM_\u8bba\u6587\u540c\u578b\u590d\u73b0_v1')
LATEST = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260906_Geneformer_GDF15_Williams\u5355\u961f\u5217_\u5168\u56fe\u7ea0\u9519\u6c47\u603b_v1')
OUT = LATEST / '\u652f\u7ebf_Williams\u5168\u90e8ECM\u6210\u7ea4\u7ef4\u7ec6\u80de_UMAP_v2_KO-OE\u57472436\u7ec6\u80de'
FIG_DIR = OUT / '\u56fe\u7247'
TABLE_DIR = OUT / '\u6570\u636e\u8868'
QA_DIR = OUT / 'QA'
CHUNK_DIR = QA_DIR / '\u7259\u5468\u708eECM\u7ec6\u80de_GDF15\u8fc7\u8868\u8fbe\u8ba1\u7b97\u5206\u5757'
INPUT_DIR = PROJECT / '01_\u8f93\u5165\u4e0eGeneformer\u5206\u8bcd' / 'Williams'
MODEL_DIR = PROJECT / '02_\u72b6\u6001\u5206\u7c7b\u5668' / 'Williams' / 'best_model'
ALL_CELL_DIR = PROJECT / '14_GDF15\u5168\u7ec6\u80de\u6572\u9664\u654f\u611f\u6027UMAP_\u652f\u7ebf_v1' / '\u6570\u636e\u8868'
ALL_KO_SOURCE = ALL_CELL_DIR / 'Williams_GDF15_KO_sensitivity_UMAP_\u5168\u90e813257\u7ec6\u80de.csv.gz'
ALL_EMBED_SOURCE = ALL_CELL_DIR / 'Williams_Geneformer_\u5168\u90e813257\u7ec6\u80de\u539f\u59cb\u5d4c\u5165.npz'
HEALTHY_OE_SOURCE = PROJECT / '09_\u8bba\u6587\u539f\u56fe\u4e25\u683c\u590d\u6838\u4e0eGDF15\u8fc7\u8868\u8fbe\u8865\u5145_v3_\u5168\u91cf\u72b6\u6001\u7ec6\u80de' / '\u6570\u636e\u8868' / '\u5065\u5eb7\u5168\u90e89980\u7ec6\u80de_GDF15\u8fc7\u8868\u8fbe\u654f\u611f\u6027.csv.gz'
SUBTYPE_SOURCE = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa') / '20260904_CellOracle_GDF15_ERK_MAPK_ECM\u4e3b\u7ebf\u4e0eGDF15\u652f\u7ebf_v1' / '01_input_qc' / '08_prepared_cell_metadata.csv'
KO_TABLE = TABLE_DIR / 'Williams\u5168\u90e82436\u4e2aECM\u6210\u7ea4\u7ef4\u7ec6\u80de_GDF15\u6572\u9664\u654f\u611f\u6027.csv.gz'
OE_TABLE = TABLE_DIR / 'Williams\u5168\u90e82436\u4e2aECM\u6210\u7ea4\u7ef4\u7ec6\u80de_GDF15\u8fc7\u8868\u8fbe\u654f\u611f\u6027.csv.gz'
STEM = '\u652f\u7ebf\u56fe2_GDF15\u6572\u9664\u4e0e\u8fc7\u8868\u8fbe\u654f\u611f\u6027UMAP_Williams\u5168\u90e8ECM\u6210\u7ea4\u7ef4\u7ec6\u80de_KO-OE\u57472436\u7ec6\u80de_v2'

def set_deterministic() -> None:
    os.environ.setdefault('PYTHONHASHSEED', str(SEED))
    random.seed(SEED)
    np.random.seed(SEED)
    torch.manual_seed(SEED)
    torch.use_deterministic_algorithms(False)
    torch.set_num_threads(min(14, os.cpu_count() or 1))

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def mean_pool(last_hidden: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
    weights = attention_mask.unsqueeze(-1).to(last_hidden.dtype)
    return (last_hidden * weights).sum(dim=1) / weights.sum(dim=1).clamp_min(1.0)

def embed_sequences(model: BertForSequenceClassification, sequences: list[np.ndarray], batch_size: int) -> np.ndarray:
    outputs: list[np.ndarray] = []
    model.eval()
    with torch.inference_mode():
        for start in range(0, len(sequences), batch_size):
            chunk = sequences[start:start + batch_size]
            max_len = max((len(sequence) for sequence in chunk))
            ids = torch.full((len(chunk), max_len), PAD_TOKEN_ID, dtype=torch.long)
            mask = torch.zeros((len(chunk), max_len), dtype=torch.long)
            for row, sequence in enumerate(chunk):
                length = len(sequence)
                ids[row, :length] = torch.as_tensor(sequence, dtype=torch.long)
                mask[row, :length] = 1
            hidden = model.bert(input_ids=ids, attention_mask=mask, return_dict=True).last_hidden_state
            outputs.append(mean_pool(hidden, mask).cpu().numpy().astype(np.float32))
    return np.concatenate(outputs, axis=0)

def overexpress_sequence(sequence: np.ndarray) -> np.ndarray:
    sequence_without_gdf15 = sequence[sequence != GDF15_TOKEN_ID]
    return np.concatenate([np.asarray([GDF15_TOKEN_ID], dtype=np.int64), sequence_without_gdf15.astype(np.int64)])[:MAX_LENGTH]

def paired_cosine_distance(original: np.ndarray, perturbed: np.ndarray) -> np.ndarray:
    numerator = np.einsum('ij,ij->i', original, perturbed)
    denominator = np.linalg.norm(original, axis=1) * np.linalg.norm(perturbed, axis=1)
    similarity = numerator / np.clip(denominator, 1e-12, None)
    return np.clip(1.0 - similarity, 0.0, None)

def load_ecm_population() -> tuple[pd.DataFrame, tuple[float, float], tuple[float, float]]:
    all_ko = pd.read_csv(ALL_KO_SOURCE)
    subtype = pd.read_csv(SUBTYPE_SOURCE)
    if len(all_ko) != 13257 or all_ko['dataset_index'].nunique() != 13257:
        raise ValueError('All-Williams KO source is incomplete or duplicated')
    subtype = subtype.loc[subtype['Study'].eq('Williams') & subtype['fibroblast_type'].eq('ECM remodeling-associated fibroblasts') & subtype['disease'].isin(['normal', 'periodontitis'])].copy()
    keys = subtype[['cell_id', 'donor_id', 'disease', 'fb_id', 'fibroblast_type', 'fibroblast_state', 'Pseudotime']].drop_duplicates(subset=['cell_id', 'donor_id', 'disease'])
    ecm = all_ko.merge(keys, on=['cell_id', 'donor_id', 'disease'], how='inner', validate='one_to_one').sort_values('dataset_index').reset_index(drop=True)
    counts = ecm.groupby('disease', observed=True).size().to_dict()
    if counts != {'normal': 1884, 'periodontitis': 552}:
        raise ValueError(f'Unexpected ECM state counts: {counts}')
    if len(ecm) != 2436 or ecm['dataset_index'].nunique() != 2436:
        raise ValueError('Expected 2436 unique Williams ECM fibroblasts')
    ecm['GDF15_KO_cosine_shift'] = pd.to_numeric(ecm['GDF15_KO_cosine_shift'], errors='coerce')
    executable_by_state = ecm.groupby('disease', observed=True)['GDF15_KO_cosine_shift'].apply(lambda values: int(values.notna().sum())).to_dict()
    if executable_by_state != {'normal': 6, 'periodontitis': 4}:
        raise ValueError(f'Unexpected KO execution coverage: {executable_by_state}')
    if int(ecm['GDF15_token_present'].astype(bool).sum()) != 10:
        raise ValueError('GDF15-token coverage must equal the 10 executable KO cells')
    x_values = all_ko['UMAP_1'].to_numpy(float)
    y_values = all_ko['UMAP_2'].to_numpy(float)
    x_pad = 0.05 * (float(x_values.max()) - float(x_values.min()))
    y_pad = 0.05 * (float(y_values.max()) - float(y_values.min()))
    xlim = (float(x_values.min()) - x_pad, float(x_values.max()) + x_pad)
    ylim = (float(y_values.min()) - y_pad, float(y_values.max()) + y_pad)
    return (ecm, xlim, ylim)

def compute_periodontitis_oe(periodontitis_indices: np.ndarray, batch_size: int=8, chunk_size: int=128) -> pd.DataFrame:
    input_ids = np.load(INPUT_DIR / 'input_ids.npy', mmap_mode='r')
    lengths = np.load(INPUT_DIR / 'lengths.npy', mmap_mode='r')
    archive = np.load(ALL_EMBED_SOURCE)
    archive_indices = archive['dataset_indices'].astype(int)
    original_embeddings = archive['original_embeddings'].astype(np.float32)
    expected = np.arange(13257, dtype=int)
    if not np.array_equal(archive_indices, expected):
        raise ValueError('Original embedding archive is not ordered by dataset_index')
    if input_ids.shape[0] != 13257 or len(lengths) != 13257:
        raise ValueError('Token arrays are not complete for Williams')
    CHUNK_DIR.mkdir(parents=True, exist_ok=True)
    model: BertForSequenceClassification | None = None
    chunks: list[pd.DataFrame] = []
    started = time.time()
    for start in range(0, len(periodontitis_indices), chunk_size):
        stop = min(start + chunk_size, len(periodontitis_indices))
        indices = periodontitis_indices[start:stop]
        checkpoint = CHUNK_DIR / f'oe_{start:04d}_{stop:04d}.csv'
        if checkpoint.exists():
            frame = pd.read_csv(checkpoint)
            if not np.array_equal(frame['dataset_index'].to_numpy(int), indices):
                raise ValueError(f'Checkpoint index mismatch: {checkpoint}')
        else:
            if model is None:
                model = BertForSequenceClassification.from_pretrained(str(MODEL_DIR), num_labels=2)
            sequences = [overexpress_sequence(np.asarray(input_ids[index, :int(lengths[index])], dtype=np.int64).copy()) for index in indices]
            perturbed_embeddings = embed_sequences(model, sequences, batch_size=batch_size)
            shifts = paired_cosine_distance(original_embeddings[indices], perturbed_embeddings)
            frame = pd.DataFrame({'dataset_index': indices, 'GDF15_OE_cosine_shift': shifts.astype(float)})
            frame.to_csv(checkpoint, index=False, encoding='utf-8-sig')
        chunks.append(frame)
        print(f'Periodontitis ECM GDF15 OE: {stop}/{len(periodontitis_indices)} ({(time.time() - started) / 60.0:.1f} min)', flush=True)
    output = pd.concat(chunks, ignore_index=True)
    if len(output) != len(periodontitis_indices):
        raise ValueError('Periodontitis ECM OE output is incomplete')
    if output['dataset_index'].duplicated().any() or output['GDF15_OE_cosine_shift'].isna().any():
        raise ValueError('Periodontitis ECM OE output is duplicated or contains missing values')
    return output

def prepare_tables() -> tuple[pd.DataFrame, pd.DataFrame, tuple[float, float], tuple[float, float]]:
    ecm, xlim, ylim = load_ecm_population()
    healthy_oe = pd.read_csv(HEALTHY_OE_SOURCE)[['dataset_index', 'GDF15_OE_cosine_shift']].copy()
    healthy_indices = ecm.loc[ecm['disease'].eq('normal'), 'dataset_index'].to_numpy(int)
    healthy_oe = healthy_oe.loc[healthy_oe['dataset_index'].isin(healthy_indices)].copy()
    if len(healthy_oe) != 1884 or healthy_oe['dataset_index'].nunique() != 1884:
        raise ValueError('Healthy ECM OE reuse table must contain 1884 unique cells')
    periodontitis_indices = ecm.loc[ecm['disease'].eq('periodontitis'), 'dataset_index'].to_numpy(int)
    periodontitis_oe = compute_periodontitis_oe(periodontitis_indices)
    oe_values = pd.concat([healthy_oe, periodontitis_oe], ignore_index=True)
    if len(oe_values) != 2436 or oe_values['dataset_index'].nunique() != 2436:
        raise ValueError('Combined ECM OE table must contain 2436 unique cells')
    ko = ecm.copy()
    oe = ecm.drop(columns=['GDF15_KO_cosine_shift'], errors='ignore').merge(oe_values, on='dataset_index', how='left', validate='one_to_one')
    if oe['GDF15_OE_cosine_shift'].isna().any():
        raise ValueError('Combined ECM OE table contains missing values')
    if set(ko['dataset_index']) != set(oe['dataset_index']):
        raise ValueError('KO and OE panels do not contain the identical 2436-cell set')
    TABLE_DIR.mkdir(parents=True, exist_ok=True)
    ko.to_csv(KO_TABLE, index=False, encoding='utf-8-sig', compression='gzip')
    oe.to_csv(OE_TABLE, index=False, encoding='utf-8-sig', compression='gzip')
    return (ko, oe, xlim, ylim)

def plot_panel(ax: plt.Axes, data: pd.DataFrame, value_column: str, title: str, cmap: str, letter: str, xlim: tuple[float, float], ylim: tuple[float, float]) -> None:
    values = data[value_column].to_numpy(dtype=float) * 1000.0
    executable = np.isfinite(values)
    ax.scatter(data['UMAP_1'], data['UMAP_2'], s=2.2, c='#E6E6E6', edgecolors='none', rasterized=True)
    positive = values[executable & (values > 0)]
    vmax = max(float(np.quantile(positive, 0.99)) if len(positive) else 1.0, 1e-06)
    positions = np.flatnonzero(executable)
    positions = positions[np.argsort(values[positions])]
    scatter = ax.scatter(data.iloc[positions]['UMAP_1'], data.iloc[positions]['UMAP_2'], c=values[positions], s=4.2 if letter == 'B' else 2.7, cmap=cmap, vmin=0, vmax=vmax, edgecolors='none', rasterized=True)
    ax.set_title(title, fontsize=9, fontweight='bold', pad=7)
    ax.set_xlabel('UMAP 1')
    ax.set_ylabel('UMAP 2')
    ax.set_xlim(*xlim)
    ax.set_ylim(*ylim)
    ax.grid(False)
    ax.set_facecolor('white')
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_color('black')
        spine.set_linewidth(0.7)
    colorbar = ax.figure.colorbar(scatter, ax=ax, fraction=0.046, pad=0.03)
    colorbar.ax.set_title('Cosine shift\n(x10^3)', fontsize=6.5, pad=4)
    colorbar.ax.tick_params(labelsize=6)
    colorbar.outline.set_linewidth(0.45)
    ax.text(-0.13, 1.08, letter, transform=ax.transAxes, fontsize=15, va='top')

def plot_outputs(ko: pd.DataFrame, oe: pd.DataFrame, xlim: tuple[float, float], ylim: tuple[float, float]) -> None:
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 7.5, 'axes.titlesize': 9, 'axes.labelsize': 8, 'xtick.labelsize': 7, 'ytick.labelsize': 7, 'axes.linewidth': 0.7, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'figure.facecolor': 'white', 'axes.facecolor': 'white', 'savefig.facecolor': 'white'})
    fig, axes = plt.subplots(1, 2, figsize=(9.8, 4.65), sharex=True, sharey=True, facecolor='white')
    plot_panel(axes[0], ko, 'GDF15_KO_cosine_shift', 'GDF15 knockout sensitivity', 'Reds', 'B', xlim, ylim)
    plot_panel(axes[1], oe, 'GDF15_OE_cosine_shift', 'GDF15 overexpression sensitivity', 'Blues', 'C', xlim, ylim)
    fig.subplots_adjust(left=0.07, right=0.95, bottom=0.12, top=0.88, wspace=0.28)
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG_DIR / f'{STEM}.pdf', dpi=300, bbox_inches='tight', facecolor='white')
    fig.savefig(FIG_DIR / f'{STEM}.svg', bbox_inches='tight', facecolor='white')
    fig.savefig(FIG_DIR / f'{STEM}.png', dpi=600, bbox_inches='tight', facecolor='white')
    plt.close(fig)

def write_qa(ko: pd.DataFrame, oe: pd.DataFrame, xlim: tuple[float, float], ylim: tuple[float, float], elapsed_seconds: float) -> None:
    QA_DIR.mkdir(parents=True, exist_ok=True)
    ko_by_state = ko.groupby('disease', observed=True)['GDF15_KO_cosine_shift'].apply(lambda values: int(values.notna().sum())).to_dict()
    oe_by_state = oe.groupby('disease', observed=True)['GDF15_OE_cosine_shift'].apply(lambda values: int(values.notna().sum())).to_dict()
    audit = {'status': 'PASS', 'task_type': 'side_branch_v2_corrected', 'cohort': 'Williams', 'subtype_filter': 'ECM remodeling-associated fibroblasts', 'identical_panel_population': True, 'panel_B_KO': {'displayed_cells': int(len(ko)), 'state_counts': ko.groupby('disease', observed=True).size().to_dict(), 'GDF15_KO_executable_cells': int(ko['GDF15_KO_cosine_shift'].notna().sum()), 'executable_by_state': ko_by_state}, 'panel_C_OE': {'displayed_cells': int(len(oe)), 'state_counts': oe.groupby('disease', observed=True).size().to_dict(), 'GDF15_OE_executed_cells': int(oe['GDF15_OE_cosine_shift'].notna().sum()), 'executed_by_state': oe_by_state}, 'population_overlap': {'same_dataset_index_set': set(ko['dataset_index']) == set(oe['dataset_index']), 'shared_cells': int(len(set(ko['dataset_index']) & set(oe['dataset_index'])))}, 'umap_coordinates': {'source': 'unchanged Williams 13257-cell Geneformer embedding UMAP', 'xlim': [float(xlim[0]), float(xlim[1])], 'ylim': [float(ylim[0]), float(ylim[1])], 'seed': SEED}, 'OE_calculation': {'healthy_1884': 'reused exact values from completed all-healthy Williams OE run', 'periodontitis_552': 'newly computed with the identical fine-tuned model and overexpression algorithm', 'imputation': False}, 'sources': {'all_KO': {'path': str(ALL_KO_SOURCE), 'sha256': sha256(ALL_KO_SOURCE)}, 'healthy_OE': {'path': str(HEALTHY_OE_SOURCE), 'sha256': sha256(HEALTHY_OE_SOURCE)}, 'subtype': {'path': str(SUBTYPE_SOURCE), 'sha256': sha256(SUBTYPE_SOURCE)}, 'model': {'path': str(MODEL_DIR), 'sha256': sha256(MODEL_DIR / 'model.safetensors')}}, 'software': {'python': sys.version, 'platform': platform.platform(), 'torch': torch.__version__, 'transformers': transformers.__version__, 'numpy': np.__version__, 'pandas': pd.__version__, 'matplotlib': matplotlib.__version__}, 'elapsed_minutes': float(elapsed_seconds / 60.0), 'outputs': {'pdf': str(FIG_DIR / f'{STEM}.pdf'), 'png': str(FIG_DIR / f'{STEM}.png'), 'svg': str(FIG_DIR / f'{STEM}.svg'), 'KO_table': str(KO_TABLE), 'OE_table': str(OE_TABLE)}}
    if audit['panel_B_KO']['displayed_cells'] != 2436:
        raise ValueError('KO panel does not display 2436 cells')
    if audit['panel_C_OE']['displayed_cells'] != 2436:
        raise ValueError('OE panel does not display 2436 cells')
    if audit['population_overlap']['shared_cells'] != 2436:
        raise ValueError('KO and OE panel populations are not identical')
    if audit['panel_B_KO']['GDF15_KO_executable_cells'] != 10:
        raise ValueError('Expected 10 executable KO cells in the combined ECM population')
    if audit['panel_C_OE']['GDF15_OE_executed_cells'] != 2436:
        raise ValueError('Expected 2436 executed OE cells')
    (QA_DIR / '\u8fd0\u884c\u4e0e\u6570\u636e\u5ba1\u8ba1.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
    (QA_DIR / '\u56fe\u8868\u5951\u7ea6.md').write_text('# \u56fe\u8868\u5951\u7ea6\n\n- \u4e24\u4e2a\u9762\u677f\u4f7f\u7528\u5b8c\u5168\u76f8\u540c\u76842436\u4e2aWilliams ECM\u6210\u7ea4\u7ef4\u7ec6\u80de\uff1a552\u4e2a\u7259\u5468\u708e\u52a01884\u4e2a\u5065\u5eb7\u7ec6\u80de\u3002\n- B\uff1aGDF15 KO\uff1bC\uff1aGDF15 OE\uff1b\u4fdd\u6301Frontiers\u540c\u578b\u7248\u5f0f\u4e0e\u5168\u91cfWilliams UMAP\u5750\u6807\u3002\n- KO\u4e0d\u53ef\u6267\u884c\u7ec6\u80de\u663e\u793a\u6d45\u7070\u8272\uff1bOE\u5168\u90e82436\u4e2a\u7ec6\u80de\u5747\u6267\u884c\uff1b\u4e0d\u8fdb\u884c\u63d2\u8865\u3002\n- \u65b0\u5efav2\u652f\u7ebf\uff0c\u4e0d\u8986\u76d6\u4e3b\u7ebf\u6216v1\u3002\n', encoding='utf-8')
    (OUT / 'README_\u8bf7\u5148\u770b.md').write_text('# Williams \u5168\u90e8 ECM \u6210\u7ea4\u7ef4\u7ec6\u80de UMAP \u652f\u7ebf v2\n\n\u672c\u7248\u7ea0\u6b63\u4e86v1\u6309\u75be\u75c5\u72b6\u6001\u62c6\u5206\u9762\u677f\u7684\u95ee\u9898\u3002KO\u4e0eOE\u4e24\u4e2a\u9762\u677f\u5747\u5305\u542b\u540c\u4e00\u7ec42436\u4e2a\u7ec6\u80de\uff1a552\u4e2a\u7259\u5468\u708e\u7ec6\u80de\u548c1884\u4e2a\u5065\u5eb7\u7ec6\u80de\u3002KO\u53ef\u6267\u884c10\u4e2a\uff08\u7259\u5468\u708e4\u4e2a\u3001\u5065\u5eb76\u4e2a\uff09\uff1bOE\u5bf92436\u4e2a\u7ec6\u80de\u5168\u90e8\u6267\u884c\u3002\u672a\u63d2\u8865\uff0c\u672a\u8986\u76d6\u4e3b\u7ebf\u6216v1\u3002\n', encoding='utf-8')

def main() -> None:
    set_deterministic()
    for path in (FIG_DIR, TABLE_DIR, QA_DIR, CHUNK_DIR):
        path.mkdir(parents=True, exist_ok=True)
    started = time.time()
    ko, oe, xlim, ylim = prepare_tables()
    plot_outputs(ko, oe, xlim, ylim)
    write_qa(ko, oe, xlim, ylim, time.time() - started)
    print(FIG_DIR / f'{STEM}.pdf', flush=True)
    print(f"KO displayed={len(ko)}, executable={ko['GDF15_KO_cosine_shift'].notna().sum()}", flush=True)
    print(f"OE displayed={len(oe)}, executed={oe['GDF15_OE_cosine_shift'].notna().sum()}", flush=True)
if __name__ == '__main__':
    main()
