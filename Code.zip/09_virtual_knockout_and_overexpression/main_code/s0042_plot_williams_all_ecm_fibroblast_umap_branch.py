from __future__ import annotations
import hashlib
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
SEED = 20260904
PROJECT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260904_Geneformer_GDF15_ERK_MAPK_ECM_\u8bba\u6587\u540c\u578b\u590d\u73b0_v1')
LATEST = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260906_Geneformer_GDF15_Williams\u5355\u961f\u5217_\u5168\u56fe\u7ea0\u9519\u6c47\u603b_v1')
OUT = LATEST / '\u652f\u7ebf_Williams\u5168\u90e8ECM\u6210\u7ea4\u7ef4\u7ec6\u80de_UMAP_v1'
FIG_DIR = OUT / '\u56fe\u7247'
TABLE_DIR = OUT / '\u6570\u636e\u8868'
QA_DIR = OUT / 'QA'
FULL_STATE_DIR = PROJECT / '09_\u8bba\u6587\u539f\u56fe\u4e25\u683c\u590d\u6838\u4e0eGDF15\u8fc7\u8868\u8fbe\u8865\u5145_v3_\u5168\u91cf\u72b6\u6001\u7ec6\u80de'
KO_SOURCE = FULL_STATE_DIR / '\u6570\u636e\u8868' / '\u7259\u5468\u708e\u5168\u90e83277\u7ec6\u80de_GDF15\u6572\u9664\u654f\u611f\u6027.csv.gz'
OE_SOURCE = FULL_STATE_DIR / '\u6570\u636e\u8868' / '\u5065\u5eb7\u5168\u90e89980\u7ec6\u80de_GDF15\u8fc7\u8868\u8fbe\u654f\u611f\u6027.csv.gz'
SUBTYPE_SOURCE = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa') / '20260904_CellOracle_GDF15_ERK_MAPK_ECM\u4e3b\u7ebf\u4e0eGDF15\u652f\u7ebf_v1' / '01_input_qc' / '08_prepared_cell_metadata.csv'
KO_TABLE = TABLE_DIR / 'Williams\u7259\u5468\u708e\u5168\u90e8552\u4e2aECM\u6210\u7ea4\u7ef4\u7ec6\u80de_GDF15\u6572\u9664\u654f\u611f\u6027.csv.gz'
OE_TABLE = TABLE_DIR / 'Williams\u5065\u5eb7\u5168\u90e81884\u4e2aECM\u6210\u7ea4\u7ef4\u7ec6\u80de_GDF15\u8fc7\u8868\u8fbe\u654f\u611f\u6027.csv.gz'
STEM = '\u652f\u7ebf\u56fe2_GDF15\u6572\u9664\u4e0e\u8fc7\u8868\u8fbe\u654f\u611f\u6027UMAP_Williams\u5168\u90e8ECM\u6210\u7ea4\u7ef4\u7ec6\u80de_v1'

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def prepare_data() -> tuple[pd.DataFrame, pd.DataFrame, tuple[float, float], tuple[float, float]]:
    ko_all = pd.read_csv(KO_SOURCE)
    oe_all = pd.read_csv(OE_SOURCE)
    subtype = pd.read_csv(SUBTYPE_SOURCE)
    if len(ko_all) != 3277 or len(oe_all) != 9980:
        raise ValueError(f'Unexpected full-state inputs: KO={len(ko_all)}, OE={len(oe_all)}')
    if set(ko_all['Study'].astype(str)) != {'Williams'}:
        raise ValueError('KO source is not Williams-only')
    if set(oe_all['Study'].astype(str)) != {'Williams'}:
        raise ValueError('OE source is not Williams-only')
    full_coords = pd.concat([ko_all[['dataset_index', 'UMAP_1', 'UMAP_2']], oe_all[['dataset_index', 'UMAP_1', 'UMAP_2']]], ignore_index=True)
    if len(full_coords) != 13257 or full_coords['dataset_index'].nunique() != 13257:
        raise ValueError('Global Williams UMAP coordinates are incomplete or duplicated')
    subtype = subtype.loc[subtype['Study'].eq('Williams') & subtype['fibroblast_type'].eq('ECM remodeling-associated fibroblasts') & subtype['disease'].isin(['normal', 'periodontitis'])].copy()
    subtype_keys = subtype[['cell_id', 'donor_id', 'disease', 'fb_id', 'fibroblast_type', 'fibroblast_state', 'Pseudotime']].drop_duplicates(subset=['cell_id', 'donor_id', 'disease'])
    ko_keys = subtype_keys.loc[subtype_keys['disease'].eq('periodontitis')]
    oe_keys = subtype_keys.loc[subtype_keys['disease'].eq('normal')]
    ko = ko_all.merge(ko_keys, on=['cell_id', 'donor_id', 'disease'], how='inner', validate='one_to_one', suffixes=('', '_subtype'))
    oe = oe_all.merge(oe_keys, on=['cell_id', 'donor_id', 'disease'], how='inner', validate='one_to_one', suffixes=('', '_subtype'))
    ko['GDF15_KO_cosine_shift'] = pd.to_numeric(ko['GDF15_KO_cosine_shift'], errors='coerce')
    oe['GDF15_OE_cosine_shift'] = pd.to_numeric(oe['GDF15_OE_cosine_shift'], errors='coerce')
    if len(ko) != 552 or ko['dataset_index'].nunique() != 552:
        raise ValueError(f'Expected 552 periodontitis ECM fibroblasts, found {len(ko)}')
    if len(oe) != 1884 or oe['dataset_index'].nunique() != 1884:
        raise ValueError(f'Expected 1884 healthy ECM fibroblasts, found {len(oe)}')
    if int(ko['GDF15_KO_cosine_shift'].notna().sum()) != 4:
        raise ValueError('Expected exactly 4 executable GDF15-KO ECM fibroblasts')
    if int(ko['GDF15_token_present'].astype(bool).sum()) != 4:
        raise ValueError('KO executable-cell count does not match GDF15-token coverage')
    if oe['GDF15_OE_cosine_shift'].isna().any():
        raise ValueError('Healthy ECM fibroblast OE results contain missing values')
    for frame in (ko, oe):
        if frame[['UMAP_1', 'UMAP_2']].isna().any().any():
            raise ValueError('ECM subset contains missing UMAP coordinates')
    x_values = full_coords['UMAP_1'].to_numpy(float)
    y_values = full_coords['UMAP_2'].to_numpy(float)
    x_pad = 0.05 * (float(x_values.max()) - float(x_values.min()))
    y_pad = 0.05 * (float(y_values.max()) - float(y_values.min()))
    xlim = (float(x_values.min()) - x_pad, float(x_values.max()) + x_pad)
    ylim = (float(y_values.min()) - y_pad, float(y_values.max()) + y_pad)
    TABLE_DIR.mkdir(parents=True, exist_ok=True)
    ko.sort_values('dataset_index').to_csv(KO_TABLE, index=False, encoding='utf-8-sig', compression='gzip')
    oe.sort_values('dataset_index').to_csv(OE_TABLE, index=False, encoding='utf-8-sig', compression='gzip')
    return (ko, oe, xlim, ylim)

def plot_panel(ax: plt.Axes, data: pd.DataFrame, value_column: str, title: str, cmap: str, letter: str, xlim: tuple[float, float], ylim: tuple[float, float]) -> None:
    values = data[value_column].to_numpy(dtype=float) * 1000.0
    executable = np.isfinite(values)
    ax.scatter(data['UMAP_1'], data['UMAP_2'], s=2.2, c='#E6E6E6', edgecolors='none', rasterized=True)
    positive = values[executable & (values > 0)]
    vmax = float(np.quantile(positive, 0.99)) if len(positive) else 1.0
    vmax = max(vmax, 1e-06)
    positions = np.flatnonzero(executable)
    positions = positions[np.argsort(values[positions])]
    scatter = ax.scatter(data.iloc[positions]['UMAP_1'], data.iloc[positions]['UMAP_2'], c=values[positions], s=4.2 if letter == 'B' else 2.7, cmap=cmap, vmin=0, vmax=vmax, edgecolors='none', rasterized=True)
    ax.set_title(title, fontsize=9, fontweight='bold', pad=7)
    ax.set_xlabel('UMAP 1')
    ax.set_ylabel('UMAP 2')
    ax.set_xlim(*xlim)
    ax.set_ylim(*ylim)
    ax.grid(False)
    ax.set_facecolor('white')
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_color('black')
        spine.set_linewidth(0.7)
    colorbar = ax.figure.colorbar(scatter, ax=ax, fraction=0.046, pad=0.03)
    colorbar.ax.set_title('Cosine shift\n(x10^3)', fontsize=6.5, pad=4)
    colorbar.ax.tick_params(labelsize=6)
    colorbar.outline.set_linewidth(0.45)
    ax.text(-0.13, 1.08, letter, transform=ax.transAxes, fontsize=15, fontweight='normal', va='top')

def build_figure(ko: pd.DataFrame, oe: pd.DataFrame, xlim: tuple[float, float], ylim: tuple[float, float]) -> None:
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 7.5, 'axes.titlesize': 9, 'axes.labelsize': 8, 'xtick.labelsize': 7, 'ytick.labelsize': 7, 'axes.linewidth': 0.7, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'figure.facecolor': 'white', 'axes.facecolor': 'white', 'savefig.facecolor': 'white'})
    fig, axes = plt.subplots(1, 2, figsize=(9.8, 4.65), sharex=True, sharey=True, facecolor='white')
    plot_panel(axes[0], ko, 'GDF15_KO_cosine_shift', 'GDF15 knockout sensitivity', 'Reds', 'B', xlim, ylim)
    plot_panel(axes[1], oe, 'GDF15_OE_cosine_shift', 'GDF15 overexpression sensitivity', 'Blues', 'C', xlim, ylim)
    fig.subplots_adjust(left=0.07, right=0.95, bottom=0.12, top=0.88, wspace=0.28)
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG_DIR / f'{STEM}.pdf', dpi=300, bbox_inches='tight', facecolor='white')
    fig.savefig(FIG_DIR / f'{STEM}.svg', bbox_inches='tight', facecolor='white')
    fig.savefig(FIG_DIR / f'{STEM}.png', dpi=600, bbox_inches='tight', facecolor='white')
    plt.close(fig)

def write_supporting_files(ko: pd.DataFrame, oe: pd.DataFrame, xlim: tuple[float, float], ylim: tuple[float, float]) -> None:
    QA_DIR.mkdir(parents=True, exist_ok=True)
    audit = {'status': 'PASS', 'task_type': 'side_branch', 'cohort': 'Williams', 'subtype_filter': 'ECM remodeling-associated fibroblasts', 'panel_B': {'population': 'all Williams periodontitis ECM-remodeling fibroblasts', 'displayed_cells': int(len(ko)), 'donors': int(ko['donor_id'].nunique()), 'GDF15_KO_executable_cells': int(ko['GDF15_KO_cosine_shift'].notna().sum()), 'GDF15_token_positive_cells': int(ko['GDF15_token_present'].astype(bool).sum())}, 'panel_C': {'population': 'all Williams healthy ECM-remodeling fibroblasts', 'displayed_cells': int(len(oe)), 'donors': int(oe['donor_id'].nunique()), 'GDF15_OE_executed_cells': int(oe['GDF15_OE_cosine_shift'].notna().sum())}, 'umap_coordinates': {'source': 'unchanged Williams 13257-cell Geneformer embedding UMAP', 'xlim': [float(xlim[0]), float(xlim[1])], 'ylim': [float(ylim[0]), float(ylim[1])], 'seed': SEED}, 'calculation_reuse': 'Exact per-cell KO/OE shifts were subset from the completed all-state Williams run; no perturbation value was imputed or recomputed.', 'sources': {'KO_source': str(KO_SOURCE), 'KO_source_sha256': sha256(KO_SOURCE), 'OE_source': str(OE_SOURCE), 'OE_source_sha256': sha256(OE_SOURCE), 'subtype_source': str(SUBTYPE_SOURCE), 'subtype_source_sha256': sha256(SUBTYPE_SOURCE)}, 'outputs': {'pdf': str(FIG_DIR / f'{STEM}.pdf'), 'png': str(FIG_DIR / f'{STEM}.png'), 'svg': str(FIG_DIR / f'{STEM}.svg'), 'KO_table': str(KO_TABLE), 'OE_table': str(OE_TABLE)}}
    (QA_DIR / '\u8fd0\u884c\u4e0e\u6570\u636e\u5ba1\u8ba1.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
    (QA_DIR / '\u56fe\u8868\u5951\u7ea6.md').write_text('# \u56fe\u8868\u5951\u7ea6\n\n- \u95ee\u9898\uff1a\u5728 Williams \u5168\u90e8 ECM remodeling-associated \u6210\u7ea4\u7ef4\u7ec6\u80de\u4e2d\uff0cGDF15 KO/OE \u654f\u611f\u6027\u5982\u4f55\u5206\u5e03\uff1f\n- \u56fe\u5f62\uff1a\u4e0e\u6b63\u5f0f\u56fe\u4e00\u81f4\u7684\u53cc\u9762\u677f UMAP \u6563\u70b9\u56fe\uff1bB \u4e3a\u7259\u5468\u708e KO\uff0cC \u4e3a\u5065\u5eb7 OE\u3002\n- \u5750\u6807\uff1a\u6cbf\u7528 Williams \u5168\u90e813257\u4e2a\u6210\u7ea4\u7ef4\u7ec6\u80de\u7684 Geneformer \u5d4c\u5165 UMAP\uff0c\u4e0d\u91cd\u65b0\u62df\u5408\u3002\n- \u989c\u8272\uff1aKO \u4f7f\u7528 Reds\uff0cOE \u4f7f\u7528 Blues\uff1b\u7070\u8272\u4ec5\u8868\u793a KO \u4e0d\u53ef\u6267\u884c\u7ec6\u80de\uff0c\u4e0d\u589e\u52a0\u6587\u5b57\u8bf4\u660e\u3002\n- \u6837\u672c\uff1aB\u663e\u793a552\u4e2a\u7259\u5468\u708e ECM \u7ec6\u80de\uff0c\u5176\u4e2d4\u4e2a\u53ef\u6267\u884c\uff1bC\u663e\u793a1884\u4e2a\u5065\u5eb7 ECM \u7ec6\u80de\uff0c\u5168\u90e8\u6267\u884cOE\u3002\n- \u8f93\u51fa\uff1aPDF\u3001SVG\u3001600 dpi PNG\uff1b\u4e3b\u7ebf\u6587\u4ef6\u4e0d\u8986\u76d6\u3002\n', encoding='utf-8')
    (OUT / 'README_\u8bf7\u5148\u770b.md').write_text('# Williams \u5168\u90e8 ECM \u6210\u7ea4\u7ef4\u7ec6\u80de UMAP \u652f\u7ebf\n\n\u672c\u652f\u7ebf\u4e25\u683c\u7b5b\u9009 `fibroblast_type = ECM remodeling-associated fibroblasts`\u3002\u7259\u5468\u708e KO \u9762\u677f\u7eb3\u5165\u5168\u90e8552\u4e2a\u7ec6\u80de\uff084\u4e2a\u53ef\u6267\u884c\uff09\uff1b\u5065\u5eb7 OE \u9762\u677f\u7eb3\u5165\u5168\u90e81884\u4e2a\u7ec6\u80de\u3002\u56fe\u5f62\u6cbf\u7528\u6b63\u5f0f\u7248 Williams \u5168\u91cf UMAP \u5750\u6807\u53ca\u7248\u5f0f\uff0c\u672a\u8986\u76d6\u4efb\u4f55\u4e3b\u7ebf\u56fe\u3002\n', encoding='utf-8')

def main() -> None:
    ko, oe, xlim, ylim = prepare_data()
    build_figure(ko, oe, xlim, ylim)
    write_supporting_files(ko, oe, xlim, ylim)
    print(FIG_DIR / f'{STEM}.pdf')
    print(f"KO displayed={len(ko)}, executable={ko['GDF15_KO_cosine_shift'].notna().sum()}")
    print(f"OE displayed={len(oe)}, executed={oe['GDF15_OE_cosine_shift'].notna().sum()}")
if __name__ == '__main__':
    main()
