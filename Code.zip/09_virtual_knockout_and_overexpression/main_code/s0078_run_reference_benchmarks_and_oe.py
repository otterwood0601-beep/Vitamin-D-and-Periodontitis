from __future__ import annotations
import argparse
import json
import pickle
import time
from collections import Counter
from pathlib import Path
import h5py
import numpy as np
import pandas as pd
from scipy import sparse
from scipy.stats import ranksums
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, f1_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import LinearSVC
from geneformer_core import GDF15_ENSEMBL, GDF15_TOKEN_ID, MAX_LENGTH, SEED, batch_embeddings, bh_fdr, embed_variable_sequences, load_classifier, priority_class, set_deterministic, state_shift, stratified_sample_indices
from run_geneformer_pipeline import COHORTS, H5AD_PATH, MODEL_OUT, SCREEN_OUT, TOKEN_DIR, decode_strings, load_tokenized
ROOT = Path('/work')
OUT = ROOT / '09_\u8bba\u6587\u539f\u56fe\u4e25\u683c\u590d\u6838\u4e0eGDF15\u8fc7\u8868\u8fbe\u8865\u5145_v2'
TABLE_OUT = OUT / '\u6570\u636e\u8868'
BENCH_OUT = TABLE_OUT / '\u6269\u5c55\u56fe7\u578b\u5206\u7c7b\u5668\u57fa\u51c6'
OE_OUT = TABLE_OUT / '\u5168\u57fa\u56e0\u8fc7\u8868\u8fbe\u7b5b\u9009'

def ensure_dirs() -> None:
    BENCH_OUT.mkdir(parents=True, exist_ok=True)
    OE_OUT.mkdir(parents=True, exist_ok=True)

def strip_version(value: str) -> str:
    return str(value).split('.', 1)[0]

def top_rank_tokens(input_ids: np.ndarray, lengths: np.ndarray, train_indices: np.ndarray, n_features: int=2048) -> list[int]:
    document_frequency: Counter[int] = Counter()
    for idx in train_indices:
        length = int(lengths[int(idx)])
        document_frequency.update(set((int(x) for x in input_ids[int(idx), :length])))
    return [token for token, _ in document_frequency.most_common(n_features)]

def rank_matrix(input_ids: np.ndarray, lengths: np.ndarray, indices: np.ndarray, selected_tokens: list[int]) -> sparse.csr_matrix:
    token_to_column = {token: column for column, token in enumerate(selected_tokens)}
    rows: list[int] = []
    cols: list[int] = []
    values: list[float] = []
    for row, idx in enumerate(indices):
        idx = int(idx)
        length = int(lengths[idx])
        sequence = input_ids[idx, :length]
        denominator = float(max(length, 1))
        for rank, token in enumerate(sequence):
            column = token_to_column.get(int(token))
            if column is None:
                continue
            rows.append(row)
            cols.append(column)
            values.append((length - rank) / denominator)
    return sparse.csr_matrix((np.asarray(values, dtype=np.float32), (rows, cols)), shape=(len(indices), len(selected_tokens)), dtype=np.float32)

def count_matrix(metadata: pd.DataFrame, indices: np.ndarray, selected_tokens: list[int], token_to_ensembl: dict[int, str]) -> tuple[sparse.csr_matrix, list[int]]:
    with h5py.File(H5AD_PATH, 'r') as handle:
        var_ids = decode_strings(handle['raw/var/_index'])
        ensembl_to_raw_column = {strip_version(value): i for i, value in enumerate(var_ids)}
        retained_tokens = [token for token in selected_tokens if strip_version(token_to_ensembl.get(int(token), '')) in ensembl_to_raw_column]
        raw_column_to_output = np.full(len(var_ids), -1, dtype=np.int32)
        for output_column, token in enumerate(retained_tokens):
            raw_column = ensembl_to_raw_column[strip_version(token_to_ensembl[int(token)])]
            raw_column_to_output[raw_column] = output_column
        data_ds = handle['raw/X/data']
        column_ds = handle['raw/X/indices']
        indptr_ds = handle['raw/X/indptr']
        rows: list[int] = []
        cols: list[int] = []
        values: list[float] = []
        for output_row, idx in enumerate(indices):
            h5ad_row = int(metadata.loc[int(idx), 'h5ad_row_python'])
            start = int(indptr_ds[h5ad_row])
            stop = int(indptr_ds[h5ad_row + 1])
            raw_columns = column_ds[start:stop].astype(np.int64)
            raw_values = data_ds[start:stop].astype(np.float64)
            library_size = float(raw_values.sum())
            mapped_columns = raw_column_to_output[raw_columns]
            keep = mapped_columns >= 0
            if not np.any(keep):
                continue
            transformed = np.log1p(raw_values[keep] * (10000.0 / max(library_size, 1.0)))
            rows.extend([output_row] * int(np.sum(keep)))
            cols.extend(mapped_columns[keep].astype(int).tolist())
            values.extend(transformed.astype(np.float32).tolist())
    matrix = sparse.csr_matrix((np.asarray(values, dtype=np.float32), (rows, cols)), shape=(len(indices), len(retained_tokens)), dtype=np.float32)
    return (matrix, retained_tokens)

def make_estimator(method: str, parameter: float | int):
    if method == 'SVM':
        return make_pipeline(StandardScaler(with_mean=False), LinearSVC(C=float(parameter), class_weight='balanced', dual='auto', max_iter=20000, random_state=SEED))
    if method == 'LR':
        return make_pipeline(StandardScaler(with_mean=False), LogisticRegression(C=float(parameter), class_weight='balanced', solver='liblinear', max_iter=4000, random_state=SEED))
    if method == 'RF':
        return RandomForestClassifier(n_estimators=280, min_samples_leaf=int(parameter), max_features='sqrt', class_weight='balanced_subsample', n_jobs=-1, random_state=SEED)
    raise ValueError(method)

def tune_and_predict(method: str, train_x: sparse.csr_matrix, train_y: np.ndarray, validation_x: sparse.csr_matrix, validation_y: np.ndarray, test_x: sparse.csr_matrix) -> tuple[np.ndarray, dict]:
    grid = [0.05, 0.2, 1.0] if method in {'SVM', 'LR'} else [1, 3]
    candidates: list[dict] = []
    best_parameter = grid[0]
    best_score = -np.inf
    for parameter in grid:
        estimator = make_estimator(method, parameter)
        estimator.fit(train_x, train_y)
        validation_prediction = estimator.predict(validation_x)
        score = float(f1_score(validation_y, validation_prediction, average='macro'))
        candidates.append({'parameter': parameter, 'validation_macro_f1': score})
        if score > best_score:
            best_score = score
            best_parameter = parameter
    final_estimator = make_estimator(method, best_parameter)
    final_estimator.fit(sparse.vstack([train_x, validation_x]), np.concatenate([train_y, validation_y]))
    return (final_estimator.predict(test_x).astype(int), {'best_parameter': best_parameter, 'validation_macro_f1': best_score, 'grid': candidates})

def benchmark_one_cohort(cohort: str, token_to_ensembl: dict[int, str]) -> tuple[list[pd.DataFrame], dict]:
    input_ids, lengths, labels, metadata = load_tokenized(cohort)
    split = pd.read_csv(MODEL_OUT / cohort / 'data_splits.csv')
    split = split.loc[split['used_for_training_run'].astype(str).str.lower().eq('true')].copy()
    split['dataset_index'] = split['dataset_index'].astype(int)
    index_by_split = {name: split.loc[split['split'] == name, 'dataset_index'].to_numpy(dtype=int) for name in ['train', 'validation', 'test']}
    ordered_indices = np.concatenate([index_by_split[name] for name in ['train', 'validation', 'test']])
    offsets: dict[str, slice] = {}
    cursor = 0
    for name in ['train', 'validation', 'test']:
        n = len(index_by_split[name])
        offsets[name] = slice(cursor, cursor + n)
        cursor += n
    selected_tokens = top_rank_tokens(input_ids, lengths, index_by_split['train'], n_features=2048)
    rank_x = rank_matrix(input_ids, lengths, ordered_indices, selected_tokens)
    count_x, retained_count_tokens = count_matrix(metadata, ordered_indices, selected_tokens, token_to_ensembl)
    feature_matrices = {'r': rank_x, 'c': count_x}
    predictions: list[pd.DataFrame] = []
    tuning: dict = {}
    for representation, matrix in feature_matrices.items():
        for method in ['SVM', 'RF', 'LR']:
            model_name = f'{method}-{representation}'
            prediction, details = tune_and_predict(method, matrix[offsets['train']], labels[index_by_split['train']], matrix[offsets['validation']], labels[index_by_split['validation']], matrix[offsets['test']])
            predictions.append(pd.DataFrame({'cohort': cohort, 'model': model_name, 'dataset_index': index_by_split['test'], 'true_label': labels[index_by_split['test']].astype(int), 'predicted_label': prediction}))
            tuning[model_name] = details
            print(f"[{cohort}] {model_name} complete; validation F1={details['validation_macro_f1']:.3f}", flush=True)
    gf = pd.read_csv(MODEL_OUT / cohort / 'validation_and_test_predictions.csv')
    gf = gf.loc[gf['split'] == 'test', ['dataset_index', 'observed_label', 'predicted_label']].copy()
    gf.insert(0, 'model', 'GF')
    gf.insert(0, 'cohort', cohort)
    gf = gf.rename(columns={'observed_label': 'true_label'})
    predictions.insert(0, gf)
    manifest = {'cohort': cohort, 'same_split_as_Geneformer': True, 'n_train': int(len(index_by_split['train'])), 'n_validation': int(len(index_by_split['validation'])), 'n_test': int(len(index_by_split['test'])), 'rank_features': int(len(selected_tokens)), 'count_features': int(len(retained_count_tokens)), 'rank_definition': 'inverse within-cell Geneformer rank on the 2,048 most prevalent training tokens', 'count_definition': 'library-size normalized (10,000) log1p raw counts for the same mapped genes', 'tuning': tuning}
    return (predictions, manifest)

def run_benchmarks() -> None:
    ensure_dirs()
    reference = pd.read_csv(TOKEN_DIR / 'Geneformer_V1_token_reference.csv')
    token_to_ensembl = dict(zip(reference['token_id'].astype(int), reference['Ensembl_ID'].astype(str)))
    frames: list[pd.DataFrame] = []
    manifests: list[dict] = []
    for cohort in COHORTS:
        cohort_frames, cohort_manifest = benchmark_one_cohort(cohort, token_to_ensembl)
        frames.extend(cohort_frames)
        manifests.append(cohort_manifest)
    predictions = pd.concat(frames, ignore_index=True)
    predictions.to_csv(BENCH_OUT / 'benchmark_test_predictions.csv.gz', index=False, compression='gzip', encoding='utf-8-sig')
    model_order = ['GF', 'SVM-r', 'RF-r', 'LR-r', 'SVM-c', 'RF-c', 'LR-c']
    metric_rows: list[dict] = []
    for model_name in model_order:
        group = predictions.loc[predictions['model'] == model_name]
        cm = confusion_matrix(group['true_label'], group['predicted_label'], labels=[0, 1])
        cm_norm = cm / np.clip(cm.sum(axis=1, keepdims=True), 1, None)
        metric_rows.append({'model': model_name, 'n_test': int(len(group)), 'macro_f1': float(f1_score(group['true_label'], group['predicted_label'], average='macro')), 'healthy_to_healthy': float(cm_norm[0, 0]), 'healthy_to_periodontitis': float(cm_norm[0, 1]), 'periodontitis_to_healthy': float(cm_norm[1, 0]), 'periodontitis_to_periodontitis': float(cm_norm[1, 1])})
    pd.DataFrame(metric_rows).to_csv(BENCH_OUT / 'benchmark_metrics.csv', index=False, encoding='utf-8-sig')
    (BENCH_OUT / 'benchmark_manifest.json').write_text(json.dumps({'cohorts': manifests, 'pooled_test_cells': int(len(predictions.loc[predictions['model'] == 'GF']))}, ensure_ascii=False, indent=2), encoding='utf-8')

def activate_sequence(sequence: np.ndarray, token: int) -> np.ndarray:
    without = sequence[sequence != int(token)]
    return np.concatenate([np.asarray([int(token)], dtype=np.int64), without])[:MAX_LENGTH]

def exact_overexpression_one_cohort(cohort: str) -> None:
    cohort_out = OE_OUT / cohort
    cohort_out.mkdir(parents=True, exist_ok=True)
    started = time.time()
    input_ids, lengths, labels, metadata = load_tokenized(cohort)
    model = load_classifier(MODEL_OUT / cohort / 'best_model')
    centroids = np.load(MODEL_OUT / cohort / 'state_centroids.npz')
    reference = pd.read_csv(TOKEN_DIR / 'Geneformer_V1_token_reference.csv')
    reference['token_id'] = reference['token_id'].astype(int)
    ref_index = reference.set_index('token_id')
    candidates = pd.read_csv(SCREEN_OUT / cohort / 'exact_delete_candidates.csv')
    priority = candidates.loc[candidates['Priority_class'] != 'Other', 'Gene'].astype(int).tolist()
    ordered = candidates['Gene'].astype(int).tolist()
    tokens = list(dict.fromkeys(priority + ordered))[:179]
    if GDF15_TOKEN_ID not in tokens:
        tokens.append(GDF15_TOKEN_ID)
    candidate_rows: list[dict] = []
    for order, token in enumerate(tokens, start=1):
        if token in ref_index.index:
            item = ref_index.loc[token]
            gene_name = str(item['Gene_name'])
            ensembl = str(item['Ensembl_ID'])
        else:
            gene_name = 'GDF15' if token == GDF15_TOKEN_ID else str(token)
            ensembl = GDF15_ENSEMBL if token == GDF15_TOKEN_ID else ''
        candidate_rows.append({'Gene': int(token), 'Gene_name': gene_name, 'Ensembl_ID': ensembl, 'Priority_class': priority_class(gene_name), 'Candidate_order': order})
    candidate_table = pd.DataFrame(candidate_rows)
    candidate_table.to_csv(cohort_out / 'overexpression_candidates.csv', index=False, encoding='utf-8-sig')
    normal_meta = metadata.loc[metadata['label'] == 0]
    screen_indices = stratified_sample_indices(normal_meta, min(24, len(normal_meta)), ['donor_id'], SEED + 404)
    metadata.loc[screen_indices, ['dataset_index', 'cell_id', 'donor_id', 'disease']].to_csv(cohort_out / 'overexpression_screen_cells.csv', index=False, encoding='utf-8-sig')
    original_embeddings = batch_embeddings(model, input_ids, lengths, screen_indices, batch_size=8)
    checkpoint_path = cohort_out / 'overexpression_cell_level_checkpoint.pkl'
    if checkpoint_path.exists():
        with checkpoint_path.open('rb') as handle:
            checkpoint = pickle.load(handle)
        if checkpoint.get('candidate_tokens') == tokens and checkpoint.get('screen_indices') == screen_indices.tolist():
            records = checkpoint.get('records', [])
            completed = set(checkpoint.get('completed_indices', []))
            print(f'[{cohort}] resumed OE from {len(completed)} cells', flush=True)
        else:
            records = []
            completed = set()
            print(f'[{cohort}] ignored incompatible earlier checkpoint', flush=True)
    else:
        records = []
        completed: set[int] = set()
    baseline_detection = Counter()
    for idx in screen_indices:
        length = int(lengths[int(idx)])
        baseline_detection.update(set((int(x) for x in input_ids[int(idx), :length])))
    for cell_number, (idx, original_embedding) in enumerate(zip(screen_indices, original_embeddings), start=1):
        idx = int(idx)
        if idx in completed:
            continue
        length = int(lengths[idx])
        sequence = input_ids[idx, :length].astype(np.int64)
        perturbed_sequences = [activate_sequence(sequence, token) for token in tokens]
        perturbed_embeddings = embed_variable_sequences(model, perturbed_sequences, batch_size=16)
        original = np.repeat(original_embedding[None, :], len(tokens), axis=0)
        x_shift, y_shift = state_shift(original, perturbed_embeddings, centroids['periodontitis'], centroids['normal'])
        cell_meta = metadata.loc[idx]
        for token, x_value, y_value in zip(tokens, x_shift, y_shift):
            records.append({'cohort': cohort, 'dataset_index': idx, 'cell_id': cell_meta['cell_id'], 'donor_id': cell_meta['donor_id'], 'disease': cell_meta['disease'], 'Gene': int(token), 'Shift_to_goal_end': float(x_value), 'Shift_away_start_end': float(y_value)})
        completed.add(idx)
        with checkpoint_path.open('wb') as handle:
            pickle.dump({'records': records, 'completed_indices': sorted(completed), 'candidate_tokens': tokens, 'screen_indices': screen_indices.tolist()}, handle)
        print(f'[{cohort}] exact OE {len(completed)}/{len(screen_indices)} cells; {len(records)} perturbations', flush=True)
    cell_level = pd.DataFrame(records).merge(candidate_table[['Gene', 'Gene_name', 'Ensembl_ID', 'Priority_class']], on='Gene', how='left')
    cell_level.to_csv(cohort_out / 'exact_overexpression_cell_level.csv.gz', index=False, compression='gzip', encoding='utf-8-sig')
    pooled_x = cell_level['Shift_to_goal_end'].to_numpy(dtype=float)
    pooled_y = cell_level['Shift_away_start_end'].to_numpy(dtype=float)
    summaries: list[dict] = []
    for token, group in cell_level.groupby('Gene', sort=False):
        x = group['Shift_to_goal_end'].to_numpy(dtype=float)
        y = group['Shift_away_start_end'].to_numpy(dtype=float)
        summaries.append({'Gene': int(token), 'Gene_name': group['Gene_name'].iloc[0], 'Ensembl_ID': group['Ensembl_ID'].iloc[0], 'Priority_class': group['Priority_class'].iloc[0], 'N_Perturbed_cells': int(len(group)), 'N_Baseline_detected_cells': int(baseline_detection[int(token)]), 'Shift_to_goal_end': float(x.mean()), 'Shift_away_start_end': float(y.mean()), 'Goal_end_vs_random_pval': float(ranksums(pooled_x, x).pvalue), 'Start_end_vs_random_pval': float(ranksums(pooled_y, y).pvalue), 'Desirability_score': float(x.mean() - y.mean()), 'Desired_quadrant': bool(x.mean() > 0 and y.mean() < 0)})
    summary = pd.DataFrame(summaries)
    summary['Goal_end_FDR'] = bh_fdr(summary['Goal_end_vs_random_pval'].to_numpy())
    summary['Start_end_FDR'] = bh_fdr(summary['Start_end_vs_random_pval'].to_numpy())
    summary = summary.sort_values(['Desired_quadrant', 'Desirability_score'], ascending=[False, False])
    summary.to_csv(cohort_out / 'exact_overexpression_gene_summary.csv', index=False, encoding='utf-8-sig')
    (cohort_out / 'overexpression_manifest.json').write_text(json.dumps({'cohort': cohort, 'start_state': 'Healthy fibroblasts', 'target_state': 'Periodontitis fibroblasts', 'operation': 'move each candidate token to rank 1; insert it when absent', 'screen_cells': int(len(screen_indices)), 'candidate_genes': int(len(tokens)), 'perturbations': int(len(cell_level)), 'elapsed_minutes': (time.time() - started) / 60.0}, ensure_ascii=False, indent=2), encoding='utf-8')

def run_overexpression_screen() -> None:
    ensure_dirs()
    set_deterministic()
    for cohort in COHORTS:
        exact_overexpression_one_cohort(cohort)

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', choices=['benchmark', 'oe', 'all'])
    args = parser.parse_args()
    ensure_dirs()
    if args.stage in {'benchmark', 'all'}:
        run_benchmarks()
    if args.stage in {'oe', 'all'}:
        run_overexpression_screen()
if __name__ == '__main__':
    main()
