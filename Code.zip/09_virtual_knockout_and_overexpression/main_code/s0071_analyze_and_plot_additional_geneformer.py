from __future__ import annotations
import json
import math
import re
import sys
import textwrap
from pathlib import Path
import numpy as np
import pandas as pd
from adjustText import adjust_text
from matplotlib import pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from scipy import stats
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, roc_auc_score
ROOT = Path('/work')
DATA_ROOT = Path('/data')
CODE_DIR = ROOT / 'code'
sys.path.insert(0, str(CODE_DIR))
from geneformer_core import ECM_PRIORITY, MAPK_PRIORITY, SEED, bh_fdr
OUT = ROOT / '10_\u539f\u6587Figure5-6\u4e0eExtendedData9-10\u65b0\u589e\u5e72\u5b9e\u9a8c_v1'
TABLE = OUT / '\u6570\u636e\u8868'
FIG = OUT / '\u56fe\u7247'
QA = OUT / 'QA'
REPORT = OUT / '\u62a5\u544a'
OLD_EXT = ROOT / '08_\u6269\u5c55\u56fe\u8868_PLOS_Frontiers\u540c\u578b' / '\u6570\u636e\u8868'
KO_ROOT = ROOT / '03_\u5168\u57fa\u56e0\u865a\u62df\u6572\u9664'
CELLORACLE = DATA_ROOT / '\u8f93\u51fa\u7ed3\u679c/20260904_CellOracle_GDF15_ERK_MAPK_ECM\u4e3b\u7ebf\u4e0eGDF15\u652f\u7ebf_v1'
SUBTYPE_ROOT = DATA_ROOT / '\u8f93\u51fa\u7ed3\u679c/20260730-\u591a\u6570\u636e\u5e93-\u7259\u9f88\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e9a\u7fa4-Scissor-Figure4\u590d\u7b97/04_CELLxGENE'
GENESET_ROOT = DATA_ROOT / '\u539f\u59cb\u6570\u636e/05_\u5355\u7ec6\u80deRNA/gene_sets'
KEGG_GMT = DATA_ROOT / '\u8f93\u51fa\u7ed3\u679c/20260821_GDF15\u865a\u62df\u6572\u9664_scTenifoldKnk_\u9996\u7248/03_enrichment/KEGG_2026_local_library.gmt'
COHORTS = ['Williams', 'Caetano']
SCENARIO_LABELS = {'Periodontitis_GDF15_KO_to_Healthy': 'GDF15 KO in periodontitis fibroblasts', 'Healthy_GDF15_OE_to_Periodontitis': 'GDF15 OE in healthy fibroblasts'}
INK = '#222222'
GRID = '#D9DFE2'
GREY = '#B8C0C4'
LIGHT_GREY = '#E8ECEE'
TEAL = '#86B8BA'
TEAL_DARK = '#397A7D'
GOLD = '#D5A24E'
GOLD_DARK = '#8D6525'
BLUE = '#4C91B8'
CORAL = '#E76F61'
PURPLE = '#A882A8'
HOUSEKEEPING = {'ACTB', 'GAPDH', 'B2M', 'HPRT1', 'PPIA', 'RPL3', 'RPL4', 'RPL5', 'RPL7', 'RPL8', 'RPL9', 'RPL10', 'RPL11', 'RPL13', 'RPL18', 'RPS3', 'RPS4X', 'RPS5', 'RPS6', 'RPS8', 'RPS9', 'RPS11', 'RPS14', 'RPS18', 'RPS19', 'RPS27A', 'EEF1A1', 'TUBB', 'UBC'}

def ensure_dirs() -> None:
    for path in [TABLE, FIG, QA, REPORT]:
        path.mkdir(parents=True, exist_ok=True)

def set_style() -> None:
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8, 'axes.titlesize': 9, 'axes.labelsize': 8, 'xtick.labelsize': 7, 'ytick.labelsize': 7, 'axes.linewidth': 0.7, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none', 'savefig.facecolor': 'white', 'figure.facecolor': 'white', 'axes.facecolor': 'white'})

def save_figure(fig: plt.Figure, name: str, dpi: int=600) -> None:
    fig.savefig(FIG / f'{name}.pdf', bbox_inches='tight', pad_inches=0.04)
    fig.savefig(FIG / f'{name}.png', dpi=dpi, bbox_inches='tight', pad_inches=0.04)
    fig.savefig(FIG / f'{name}.svg', bbox_inches='tight', pad_inches=0.04)
    plt.close(fig)

def clean_axis(ax: plt.Axes, grid_axis: str | None=None) -> None:
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    if grid_axis:
        ax.grid(axis=grid_axis, color=GRID, linewidth=0.55, linestyle='--', alpha=0.8)
        ax.set_axisbelow(True)

def bootstrap_ci(values: np.ndarray, seed_offset: int=0, n_boot: int=2000) -> tuple[float, float]:
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    if len(values) == 0:
        return (np.nan, np.nan)
    if len(values) == 1:
        return (float(values[0]), float(values[0]))
    rng = np.random.default_rng(SEED + seed_offset)
    means = np.asarray([rng.choice(values, len(values), replace=True).mean() for _ in range(n_boot)])
    return (float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975)))

def p_label(p: float) -> str:
    if not np.isfinite(p):
        return 'NA'
    if p < 0.001:
        return '***'
    if p < 0.01:
        return '**'
    if p < 0.05:
        return '*'
    return 'NS'

def safe_wilcoxon(values: np.ndarray, alternative: str='greater') -> float:
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    if len(values) < 2 or np.allclose(values, 0):
        return 1.0
    try:
        return float(stats.wilcoxon(values, alternative=alternative, method='auto').pvalue)
    except ValueError:
        return 1.0

def direct_proximal_ecm_genes() -> set[str]:
    edges = pd.read_csv(CELLORACLE / '02_mainline_TF_KO/06_filtered_GRN_edges.csv.gz')
    return set(edges.loc[edges['source'].isin(MAPK_PRIORITY) & edges['target'].isin(ECM_PRIORITY), 'target'].astype(str))

def analyze_downstream_groups() -> pd.DataFrame:
    raw = pd.read_csv(OLD_EXT / 'GDF15_downstream_gene_evidence_cell_level.csv.gz')
    proximal = direct_proximal_ecm_genes()

    def classify(gene: str) -> str | None:
        if gene in MAPK_PRIORITY:
            return 'MAPK-response'
        if gene in proximal:
            return 'MAPK-linked ECM targets'
        if gene in ECM_PRIORITY:
            return 'Other ECM-remodeling'
        if gene in HOUSEKEEPING:
            return 'Housekeeping'
        return None
    raw['Target_group'] = raw['Gene_name'].astype(str).map(classify)
    raw = raw.dropna(subset=['Target_group']).copy()
    gene = raw.groupby(['scenario', 'cohort', 'Gene', 'Gene_name', 'Target_group'], as_index=False).agg(Mean_token_cosine_shift=('Token_cosine_shift', 'mean'), N_cells=('dataset_index', 'nunique'))
    pooled = gene.groupby(['scenario', 'Gene', 'Gene_name', 'Target_group'], as_index=False).agg(Mean_token_cosine_shift=('Mean_token_cosine_shift', 'mean'), N_cohorts=('cohort', 'nunique'))
    rows: list[dict] = []
    for scenario, frame in pooled.groupby('scenario'):
        control = frame.loc[frame['Target_group'] == 'Housekeeping', 'Mean_token_cosine_shift'].to_numpy()
        for group, group_frame in frame.groupby('Target_group'):
            values = group_frame['Mean_token_cosine_shift'].to_numpy()
            if group == 'Housekeeping' or len(values) == 0 or len(control) == 0:
                p = np.nan
            else:
                p = float(stats.mannwhitneyu(values, control, alternative='greater').pvalue)
            rows.append({'scenario': scenario, 'Target_group': group, 'N_genes': len(values), 'Median_gene_shift': float(np.median(values)), 'Mean_gene_shift': float(np.mean(values)), 'Raw_P_vs_housekeeping_one_sided': p})
    stats_table = pd.DataFrame(rows)
    for scenario, idx in stats_table.groupby('scenario').groups.items():
        values = stats_table.loc[idx, 'Raw_P_vs_housekeeping_one_sided'].to_numpy(dtype=float)
        stats_table.loc[idx, 'BH_FDR_vs_housekeeping'] = bh_fdr(values)
    gene.to_csv(TABLE / '01_GDF15\u4e0b\u6e38\u5206\u7ec4_\u961f\u5217\u57fa\u56e0\u7ea7.csv', index=False, encoding='utf-8-sig')
    pooled.to_csv(TABLE / '01_GDF15\u4e0b\u6e38\u5206\u7ec4_\u5408\u5e76\u57fa\u56e0\u7ea7.csv', index=False, encoding='utf-8-sig')
    stats_table.to_csv(TABLE / '01_GDF15\u4e0b\u6e38\u5206\u7ec4_\u7edf\u8ba1.csv', index=False, encoding='utf-8-sig')
    order = ['MAPK-response', 'MAPK-linked ECM targets', 'Other ECM-remodeling', 'Housekeeping']
    colors = [GOLD, TEAL_DARK, TEAL, GREY]
    fig, axes = plt.subplots(1, 2, figsize=(9.2, 3.6), sharey=True)
    for letter, (scenario, ax) in zip(['a', 'b'], zip(SCENARIO_LABELS, axes)):
        frame = pooled.loc[pooled['scenario'] == scenario]
        arrays = [frame.loc[frame['Target_group'] == group, 'Mean_token_cosine_shift'].to_numpy() for group in order]
        box = ax.boxplot(arrays, positions=np.arange(len(order)), widths=0.58, patch_artist=True, showfliers=False, medianprops={'color': INK, 'linewidth': 1.0}, whiskerprops={'color': INK, 'linewidth': 0.7}, capprops={'color': INK, 'linewidth': 0.7}, boxprops={'edgecolor': INK, 'linewidth': 0.7})
        for patch, color in zip(box['boxes'], colors):
            patch.set_facecolor(color)
            patch.set_alpha(0.78)
        rng = np.random.default_rng(SEED)
        for x, values in enumerate(arrays):
            jitter = rng.normal(x, 0.055, size=len(values))
            ax.scatter(jitter, values, s=10, facecolors='white', edgecolors=INK, linewidths=0.45, alpha=0.8, zorder=3)
            row = stats_table.loc[(stats_table['scenario'] == scenario) & (stats_table['Target_group'] == order[x])]
            if x < 3 and (not row.empty):
                q = float(row['BH_FDR_vs_housekeeping'].iloc[0])
                ymax = max([np.nanmax(v) if len(v) else 0 for v in arrays])
                ax.text(x, ymax * 1.04, p_label(q), ha='center', va='bottom', fontsize=8, fontweight='bold')
        ax.set_xticks(np.arange(len(order)))
        ax.set_xticklabels([f'{g}\n(n={len(v)})' for g, v in zip(order, arrays)], rotation=20, ha='right')
        ax.set_title(SCENARIO_LABELS[scenario], loc='left', fontweight='bold')
        ax.text(-0.14, 1.04, letter, transform=ax.transAxes, fontsize=15, fontweight='bold')
        clean_axis(ax, 'y')
    global_ymax = float(pooled['Mean_token_cosine_shift'].max())
    for ax in axes:
        ymin, _ = ax.get_ylim()
        ax.set_ylim(ymin, global_ymax * 1.16)
    axes[0].set_ylabel('Mean target-gene embedding cosine shift')
    fig.tight_layout(w_pad=1.4)
    save_figure(fig, '\u56fe6_GDF15\u4e0b\u6e38\u7f51\u7edc\u9776\u6807\u53d7\u6270\u52a8\u5f71\u54cd_Figure5a\u540c\u578b')
    return stats_table

def analyze_combination() -> tuple[pd.DataFrame, pd.DataFrame]:
    path = TABLE / '02_GDF15_MAPK\u7ec4\u5408\u6fc0\u6d3b/GDF15_MAPK_combination_activation_cell_level.csv.gz'
    data = pd.read_csv(path)
    order = ['GDF15', 'MAPK1', 'MAPK3', 'GDF15+MAPK1', 'GDF15+MAPK3', 'MAPK1+MAPK3', 'GDF15+MAPK1+MAPK3']
    comparisons: list[dict] = []
    for cohort, frame in data.groupby('cohort'):
        for condition, group in frame.groupby('condition'):
            paired = group[['Mean_ECM_target_shift', 'Mean_housekeeping_shift']].dropna()
            diff = paired['Mean_ECM_target_shift'].to_numpy() - paired['Mean_housekeeping_shift'].to_numpy()
            comparisons.append({'cohort': cohort, 'condition': condition, 'N_cells': len(group), 'Mean_ECM_target_shift': float(group['Mean_ECM_target_shift'].mean()), 'Mean_housekeeping_shift': float(group['Mean_housekeeping_shift'].mean()), 'Raw_P_ECM_gt_housekeeping': safe_wilcoxon(diff, 'greater'), 'Mean_state_desirability': float(group['Desirability_score'].mean()), 'Raw_P_state_desirability_gt_zero': safe_wilcoxon(group['Desirability_score'].to_numpy(), 'greater')})
    comparison_stats = pd.DataFrame(comparisons)
    for cohort, idx in comparison_stats.groupby('cohort').groups.items():
        comparison_stats.loc[idx, 'BH_FDR_ECM_gt_housekeeping'] = bh_fdr(comparison_stats.loc[idx, 'Raw_P_ECM_gt_housekeeping'])
        comparison_stats.loc[idx, 'BH_FDR_state_desirability_gt_zero'] = bh_fdr(comparison_stats.loc[idx, 'Raw_P_state_desirability_gt_zero'])
    piv = data.pivot_table(index=['cohort', 'dataset_index', 'cell_id', 'donor_id'], columns='condition', values=['Desirability_score', 'Mean_ECM_target_shift'])
    synergy_rows: list[dict] = []
    definitions = {'GDF15+MAPK1': ['GDF15', 'MAPK1'], 'GDF15+MAPK3': ['GDF15', 'MAPK3'], 'MAPK1+MAPK3': ['MAPK1', 'MAPK3'], 'GDF15+MAPK1+MAPK3': ['GDF15', 'MAPK1', 'MAPK3']}
    for index, row in piv.iterrows():
        cohort, dataset_index, cell_id, donor_id = index
        for combo, singles in definitions.items():
            for metric in ['Desirability_score', 'Mean_ECM_target_shift']:
                observed = row[metric, combo]
                expected = sum((row[metric, single] for single in singles))
                synergy_rows.append({'cohort': cohort, 'dataset_index': dataset_index, 'cell_id': cell_id, 'donor_id': donor_id, 'combination': combo, 'metric': metric, 'observed': observed, 'additive_expected': expected, 'synergy': observed - expected})
    synergy = pd.DataFrame(synergy_rows)
    synergy_stats: list[dict] = []
    for (cohort, combo, metric), group in synergy.groupby(['cohort', 'combination', 'metric']):
        values = group['synergy'].to_numpy(dtype=float)
        synergy_stats.append({'cohort': cohort, 'combination': combo, 'metric': metric, 'N_cells': len(values), 'Mean_synergy': float(np.nanmean(values)), 'Median_synergy': float(np.nanmedian(values)), 'Raw_P_synergy_gt_zero': safe_wilcoxon(values, 'greater')})
    synergy_stats_df = pd.DataFrame(synergy_stats)
    for (cohort, metric), idx in synergy_stats_df.groupby(['cohort', 'metric']).groups.items():
        synergy_stats_df.loc[idx, 'BH_FDR_synergy_gt_zero'] = bh_fdr(synergy_stats_df.loc[idx, 'Raw_P_synergy_gt_zero'])
    comparison_stats.to_csv(TABLE / '02_GDF15_MAPK\u7ec4\u5408\u6fc0\u6d3b_\u5206\u7ec4\u6bd4\u8f83\u7edf\u8ba1.csv', index=False, encoding='utf-8-sig')
    synergy.to_csv(TABLE / '02_GDF15_MAPK\u7ec4\u5408\u6fc0\u6d3b_\u9010\u7ec6\u80de\u534f\u540c\u6548\u5e94.csv.gz', index=False, compression='gzip', encoding='utf-8-sig')
    synergy_stats_df.to_csv(TABLE / '02_GDF15_MAPK\u7ec4\u5408\u6fc0\u6d3b_\u534f\u540c\u6548\u5e94\u7edf\u8ba1.csv', index=False, encoding='utf-8-sig')
    pooled = data.groupby(['dataset_index', 'condition'], as_index=False).agg(Mean_ECM_target_shift=('Mean_ECM_target_shift', 'mean'), Mean_housekeeping_shift=('Mean_housekeeping_shift', 'mean'), Desirability_score=('Desirability_score', 'mean'))
    pooled_syn = synergy.groupby(['dataset_index', 'combination', 'metric'], as_index=False)['synergy'].mean()
    fig, axes = plt.subplots(1, 2, figsize=(10.8, 3.8))
    ax = axes[0]
    x = np.arange(len(order))
    ecm_arrays = [pooled.loc[pooled['condition'] == c, 'Mean_ECM_target_shift'].to_numpy() for c in order]
    hk_arrays = [pooled.loc[pooled['condition'] == c, 'Mean_housekeeping_shift'].to_numpy() for c in order]
    bp1 = ax.boxplot(ecm_arrays, positions=x - 0.16, widths=0.28, patch_artist=True, showfliers=False)
    bp2 = ax.boxplot(hk_arrays, positions=x + 0.16, widths=0.28, patch_artist=True, showfliers=False)
    for patch in bp1['boxes']:
        patch.set(facecolor=TEAL, edgecolor=TEAL_DARK, linewidth=0.7)
    for patch in bp2['boxes']:
        patch.set(facecolor=LIGHT_GREY, edgecolor=INK, linewidth=0.7)
    for artist in bp1['medians'] + bp2['medians']:
        artist.set(color=INK, linewidth=0.9)
    ax.set_xticks(x)
    ax.set_xticklabels(order, rotation=26, ha='right')
    ax.set_ylabel('Target-gene embedding cosine shift')
    ax.set_title('Single and combined activation', loc='left', fontweight='bold')
    ax.legend([Patch(facecolor=TEAL, edgecolor=TEAL_DARK), Patch(facecolor=LIGHT_GREY, edgecolor=INK)], ['ECM-remodeling targets', 'Housekeeping controls'], frameon=False, loc='upper left')
    ax.text(-0.1, 1.04, 'a', transform=ax.transAxes, fontsize=15, fontweight='bold')
    clean_axis(ax, 'y')
    ax = axes[1]
    combo_order = list(definitions)
    syn_arrays = [pooled_syn.loc[(pooled_syn['combination'] == c) & (pooled_syn['metric'] == 'Desirability_score'), 'synergy'].to_numpy() for c in combo_order]
    boxes = ax.boxplot(syn_arrays, positions=np.arange(4), widths=0.58, patch_artist=True, showfliers=False)
    for patch in boxes['boxes']:
        patch.set(facecolor=GOLD, edgecolor=GOLD_DARK, linewidth=0.7)
    for median in boxes['medians']:
        median.set(color=INK, linewidth=0.9)
    ax.axhline(0, color=INK, linewidth=0.7, linestyle='--')
    ax.set_xticks(np.arange(4))
    ax.set_xticklabels(combo_order, rotation=26, ha='right')
    ax.set_ylabel('Synergy in shift toward Healthy\n(observed - additive expectation)')
    ax.set_title('Combination cooperativity', loc='left', fontweight='bold')
    ax.text(-0.1, 1.04, 'b', transform=ax.transAxes, fontsize=15, fontweight='bold')
    clean_axis(ax, 'y')
    fig.tight_layout(w_pad=1.7)
    save_figure(fig, '\u56fe7_GDF15_MAPK1_MAPK3\u7ec4\u5408\u6fc0\u6d3b\u534f\u540c\u6548\u5e94_Figure5b\u540c\u578b')
    return (comparison_stats, synergy_stats_df)

def metric_row(labels: np.ndarray, probs: np.ndarray, name: str) -> dict:
    pred = (probs >= 0.5).astype(int)
    cm = confusion_matrix(labels, pred, labels=[0, 1])
    row_norm = cm / np.maximum(cm.sum(axis=1, keepdims=True), 1)
    return {'evaluation': name, 'N_cells': len(labels), 'Accuracy': float(accuracy_score(labels, pred)), 'Macro_F1': float(f1_score(labels, pred, average='macro')), 'AUROC': float(roc_auc_score(labels, probs)) if len(np.unique(labels)) == 2 else np.nan, 'Healthy_to_Healthy': row_norm[0, 0], 'Healthy_to_Periodontitis': row_norm[0, 1], 'Periodontitis_to_Healthy': row_norm[1, 0], 'Periodontitis_to_Periodontitis': row_norm[1, 1]}

def analyze_robustness() -> pd.DataFrame:
    cross = pd.read_csv(TABLE / '03_\u4f9b\u4f53\u4e0e\u8de8\u961f\u5217\u7a33\u5065\u6027/cross_cohort_predictions.csv.gz')
    frames: list[pd.DataFrame] = []
    for cohort in COHORTS:
        old = pd.read_csv(ROOT / '02_\u72b6\u6001\u5206\u7c7b\u5668' / cohort / 'validation_and_test_predictions.csv')
        old = old.loc[old['split'] == 'test'].copy()
        old['evaluation'] = f'{cohort} within-cohort test'
        old['label'] = old['observed_label']
        frames.append(old[['evaluation', 'dataset_index', 'cell_id', 'donor_id', 'disease', 'label', 'periodontitis_probability', 'predicted_label']])
    for (model_cohort, test_cohort), group in cross.groupby(['model_cohort', 'test_cohort']):
        temp = group.copy()
        temp['evaluation'] = f'{model_cohort} model to {test_cohort}'
        frames.append(temp[['evaluation', 'dataset_index', 'cell_id', 'donor_id', 'disease', 'label', 'periodontitis_probability', 'predicted_label']])
    predictions = pd.concat(frames, ignore_index=True)
    metrics = pd.DataFrame([metric_row(group['label'].to_numpy(dtype=int), group['periodontitis_probability'].to_numpy(dtype=float), name) for name, group in predictions.groupby('evaluation', sort=False)])
    metrics.to_csv(TABLE / '03_\u4f9b\u4f53\u4e0e\u8de8\u961f\u5217\u7a33\u5065\u6027_\u5206\u7c7b\u6307\u6807.csv', index=False, encoding='utf-8-sig')
    donor_rows: list[dict] = []
    for (evaluation, donor), group in predictions.groupby(['evaluation', 'donor_id']):
        correct = (group['predicted_label'].to_numpy(dtype=int) == group['label'].to_numpy(dtype=int)).astype(float)
        low, high = bootstrap_ci(correct, seed_offset=len(donor_rows))
        donor_rows.append({'evaluation': evaluation, 'donor_id': donor, 'disease': group['disease'].iloc[0], 'N_cells': len(group), 'Correct_fraction': correct.mean(), 'CI95_low': low, 'CI95_high': high})
    donors = pd.DataFrame(donor_rows)
    donors.to_csv(TABLE / '03_\u4f9b\u4f53\u4e0e\u8de8\u961f\u5217\u7a33\u5065\u6027_\u4f9b\u4f53\u7ea7\u51c6\u786e\u7387.csv', index=False, encoding='utf-8-sig')
    names = metrics['evaluation'].tolist()
    fig = plt.figure(figsize=(11.5, 8.2))
    gs = fig.add_gridspec(2, 4, height_ratios=[1.0, 2.45], hspace=0.43, wspace=0.44)
    for i, name in enumerate(names):
        ax = fig.add_subplot(gs[0, i])
        row = metrics.loc[metrics['evaluation'] == name].iloc[0]
        cm = np.asarray([[row['Healthy_to_Healthy'], row['Healthy_to_Periodontitis']], [row['Periodontitis_to_Healthy'], row['Periodontitis_to_Periodontitis']]])
        ax.pcolormesh(np.arange(3), np.arange(3), cm, cmap='Blues', vmin=0, vmax=1, shading='flat')
        ax.set_xlim(0, 2)
        ax.set_ylim(2, 0)
        for y in range(2):
            for x in range(2):
                ax.text(x + 0.5, y + 0.5, f'{cm[y, x]:.2f}', ha='center', va='center', color='white' if cm[y, x] > 0.55 else INK, fontsize=9)
        ax.set_xticks([0.5, 1.5], ['Healthy', 'Periodontitis'], rotation=25, ha='right')
        ax.set_yticks([0.5, 1.5], ['Healthy', 'Periodontitis'])
        ax.set_title(name.replace(' to ', '\n\u2192 '), fontsize=8, fontweight='bold')
        ax.set_xlabel('Predicted')
        if i == 0:
            ax.set_ylabel('True')
        ax.text(0.5, -0.45, f"Accuracy {row['Accuracy']:.3f} | F1 {row['Macro_F1']:.3f}", transform=ax.transAxes, ha='center', fontsize=7)
    ax = fig.add_subplot(gs[1, :])
    evaluation_order = names
    donors['evaluation'] = pd.Categorical(donors['evaluation'], evaluation_order, ordered=True)
    donor_order = donors.sort_values(['evaluation', 'disease', 'Correct_fraction']).reset_index(drop=True)
    y = np.arange(len(donor_order))
    colors = np.where(donor_order['disease'].eq('periodontitis'), GOLD, TEAL)
    xerr = np.vstack([donor_order['Correct_fraction'].to_numpy() - donor_order['CI95_low'].to_numpy(), donor_order['CI95_high'].to_numpy() - donor_order['Correct_fraction'].to_numpy()])
    ax.errorbar(donor_order['Correct_fraction'], y, xerr=xerr, fmt='none', ecolor=INK, elinewidth=0.6, capsize=1.5)
    ax.scatter(donor_order['Correct_fraction'], y, c=colors, s=20, edgecolor=INK, linewidth=0.4, zorder=3)
    evaluation_codes = {'Williams within-cohort test': 'W\u2192W', 'Caetano within-cohort test': 'C\u2192C', 'Caetano model to Williams': 'C\u2192W', 'Williams model to Caetano': 'W\u2192C'}
    labels = []
    for row in donor_order.itertuples():
        gsm = re.search('GSM\\d+', str(row.donor_id))
        donor_label = gsm.group(0) if gsm else str(row.donor_id)
        labels.append(f'{evaluation_codes[str(row.evaluation)]}  {donor_label} (n={row.N_cells})')
    ax.set_yticks(y, labels)
    ax.invert_yaxis()
    ax.set_xlim(-0.03, 1.03)
    ax.set_xlabel('Correctly classified cells per donor (fraction; 95% bootstrap CI)')
    ax.set_title('Donor-level performance', loc='left', fontweight='bold')
    ax.legend([Line2D([0], [0], marker='o', color='none', markerfacecolor=TEAL, markeredgecolor=INK), Line2D([0], [0], marker='o', color='none', markerfacecolor=GOLD, markeredgecolor=INK)], ['Healthy', 'Periodontitis'], frameon=False, loc='lower right', bbox_to_anchor=(1.0, 1.01), ncol=2)
    clean_axis(ax, 'x')
    fig.text(0.01, 0.97, 'a', fontsize=15, fontweight='bold')
    fig.text(0.01, 0.625, 'b', fontsize=15, fontweight='bold')
    fig.subplots_adjust(left=0.18, right=0.99, top=0.96, bottom=0.07)
    save_figure(fig, '\u6269\u5c55\u56fe2_\u4f9b\u4f53\u4e0e\u8de8\u961f\u5217\u5206\u7c7b\u7a33\u5065\u6027_ExtendedDataFigure10a\u540c\u578b')
    return metrics

def read_subtype_lookup() -> pd.DataFrame:
    frames: list[pd.DataFrame] = []
    for path in SUBTYPE_ROOT.glob('*/01_fibroblast_atlas/01_fibroblast_UMAP_metadata.csv.gz'):
        frame = pd.read_csv(path, compression='gzip')
        if 'fibroblast_subtype' in frame.columns:
            frames.append(frame[['cell', 'fibroblast_subtype', 'disease', 'study']])
    data = pd.concat(frames, ignore_index=True).drop_duplicates('cell')
    data['subtype_group'] = data['fibroblast_subtype'].astype(str).str.split(':', n=1).str[-1].str.strip()
    data['subtype_group'] = data['subtype_group'].str.replace('Inflammatory CXCL.*', 'Inflammatory CXCL', regex=True)
    return data

def analyze_subtypes() -> pd.DataFrame:
    direct = pd.read_csv(OLD_EXT / 'GDF15_directional_perturbation_cell_level.csv')
    direct = direct.loc[direct['cohort'] == 'Williams'].copy()
    lookup = read_subtype_lookup()
    data = direct.merge(lookup[['cell', 'fibroblast_subtype', 'subtype_group']], left_on='cell_id', right_on='cell', how='left', validate='many_to_one')
    rows: list[dict] = []
    for (scenario, subtype), group in data.dropna(subset=['subtype_group']).groupby(['scenario', 'subtype_group']):
        values = group['Desirability_score'].to_numpy(dtype=float)
        low, high = bootstrap_ci(values, seed_offset=len(rows) + 1200)
        rows.append({'scenario': scenario, 'subtype_group': subtype, 'N_cells': len(group), 'N_donors': group['donor_id'].nunique(), 'Mean_desirability': values.mean(), 'CI95_low': low, 'CI95_high': high, 'Raw_P_desirability_gt_zero': safe_wilcoxon(values, 'greater'), 'Mean_shift_to_target': group['Shift_to_target'].mean(), 'Mean_shift_away_source': group['Shift_away_source'].mean()})
    summary = pd.DataFrame(rows)
    for scenario, idx in summary.groupby('scenario').groups.items():
        summary.loc[idx, 'BH_FDR_desirability_gt_zero'] = bh_fdr(summary.loc[idx, 'Raw_P_desirability_gt_zero'])
    data.to_csv(TABLE / '04_GDF15\u6270\u52a8\u4e9a\u7fa4\u7279\u5f02\u6027_\u9010\u7ec6\u80de.csv', index=False, encoding='utf-8-sig')
    summary.to_csv(TABLE / '04_GDF15\u6270\u52a8\u4e9a\u7fa4\u7279\u5f02\u6027_\u7edf\u8ba1.csv', index=False, encoding='utf-8-sig')
    fig, axes = plt.subplots(1, 2, figsize=(9.2, 4.2), sharex=True)
    for letter, (scenario, ax) in zip(['a', 'b'], zip(SCENARIO_LABELS, axes)):
        frame = summary.loc[(summary['scenario'] == scenario) & (summary['N_cells'] >= 3)].sort_values('Mean_desirability')
        y = np.arange(len(frame))
        xerr = np.vstack([frame['Mean_desirability'] - frame['CI95_low'], frame['CI95_high'] - frame['Mean_desirability']])
        ax.errorbar(frame['Mean_desirability'], y, xerr=xerr, fmt='none', ecolor=INK, linewidth=0.7, capsize=2)
        sizes = 28 + np.sqrt(frame['N_cells'].to_numpy()) * 5
        face = [TEAL if n >= 5 else 'white' for n in frame['N_cells']]
        ax.scatter(frame['Mean_desirability'], y, s=sizes, c=face, edgecolor=TEAL_DARK, linewidth=0.8, zorder=3)
        ax.axvline(0, color=INK, linewidth=0.7, linestyle='--')
        ax.set_yticks(y, [f'{r.subtype_group} (n={r.N_cells})' for r in frame.itertuples()])
        ax.set_xlabel('State-shift desirability (mean; 95% CI)')
        ax.set_title(SCENARIO_LABELS[scenario], loc='left', fontweight='bold')
        ax.text(-0.14, 1.04, letter, transform=ax.transAxes, fontsize=15, fontweight='bold')
        clean_axis(ax, 'x')
    fig.tight_layout(w_pad=1.8)
    save_figure(fig, '\u6269\u5c55\u56fe3_GDF15\u6270\u52a8\u7684\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e9a\u7fa4\u7279\u5f02\u6027')
    return summary

def analyze_rank_dose() -> pd.DataFrame:
    data = pd.read_csv(TABLE / '05_GDF15\u8fc7\u8868\u8fbeRank\u5242\u91cf\u626b\u63cf/GDF15_rank_dose_cell_level.csv.gz')
    rows: list[dict] = []
    for (cohort, rank), group in data.groupby(['cohort', 'Perturbed_GDF15_rank']):
        for metric in ['Shift_to_Periodontitis', 'Shift_away_Healthy', 'Desirability_score']:
            values = group[metric].to_numpy(dtype=float)
            low, high = bootstrap_ci(values, seed_offset=len(rows) + 1400)
            rows.append({'cohort': cohort, 'Perturbed_GDF15_rank': rank, 'metric': metric, 'N_cells': len(group), 'Mean': values.mean(), 'CI95_low': low, 'CI95_high': high, 'Raw_P_gt_zero': safe_wilcoxon(values, 'greater')})
    summary = pd.DataFrame(rows)
    for (cohort, metric), idx in summary.groupby(['cohort', 'metric']).groups.items():
        summary.loc[idx, 'BH_FDR_gt_zero'] = bh_fdr(summary.loc[idx, 'Raw_P_gt_zero'])
    summary.to_csv(TABLE / '05_GDF15\u8fc7\u8868\u8fbeRank\u5242\u91cf\u626b\u63cf_\u7edf\u8ba1.csv', index=False, encoding='utf-8-sig')
    metrics = ['Shift_to_Periodontitis', 'Shift_away_Healthy']
    titles = ['Shift toward Periodontitis', 'Shift relative to Healthy']
    fig, axes = plt.subplots(1, 2, figsize=(8.2, 3.5), sharex=True)
    x_order = [1, 10, 25, 50, 100]
    x = np.arange(len(x_order))
    for letter, metric, title, ax in zip(['a', 'b'], metrics, titles, axes):
        for cohort, color, marker in [('Williams', TEAL_DARK, 'o'), ('Caetano', GOLD_DARK, 's')]:
            frame = summary.loc[(summary['cohort'] == cohort) & (summary['metric'] == metric)].set_index('Perturbed_GDF15_rank').loc[x_order]
            means = frame['Mean'].to_numpy()
            yerr = np.vstack([means - frame['CI95_low'].to_numpy(), frame['CI95_high'].to_numpy() - means])
            ax.errorbar(x, means, yerr=yerr, color=color, marker=marker, markersize=4, linewidth=1.1, capsize=2, label=cohort)
        ax.axhline(0, color=INK, linestyle='--', linewidth=0.7)
        ax.set_xticks(x, [str(v) for v in x_order])
        ax.set_xlabel('Forced GDF15 rank')
        ax.set_ylabel('Delta cosine similarity')
        ax.set_title(title, loc='left', fontweight='bold')
        ax.text(-0.12, 1.04, letter, transform=ax.transAxes, fontsize=15, fontweight='bold')
        clean_axis(ax, 'y')
    axes[0].legend(frameon=False, loc='best')
    fig.tight_layout(w_pad=1.8)
    save_figure(fig, '\u6269\u5c55\u56fe4_GDF15\u8fc7\u8868\u8fbeRank\u5242\u91cf\u53cd\u5e94')
    return summary

def load_screen(mode: str, cohort: str) -> pd.DataFrame:
    if mode == 'KO':
        frame = pd.read_csv(KO_ROOT / cohort / 'exact_delete_gene_summary.csv')
        frame['N_cells'] = frame['N_Detections']
    else:
        frame = pd.read_csv(TABLE / '07_\u53cc\u5411\u6269\u5c55\u7b5b\u9009' / cohort / 'expanded_OE_gene_summary.csv')
        frame['N_cells'] = frame['N_Perturbed_cells']
    frame['cohort'] = cohort
    frame['mode'] = mode
    return frame

def pooled_screen(mode: str) -> pd.DataFrame:
    frames = [load_screen(mode, cohort) for cohort in COHORTS]
    common = set(frames[0]['Gene_name']) & set(frames[1]['Gene_name'])
    merged = pd.concat([f.loc[f['Gene_name'].isin(common)] for f in frames], ignore_index=True)
    pooled = merged.groupby(['Gene_name', 'Ensembl_ID', 'Priority_class'], as_index=False).agg(Shift_to_goal_end=('Shift_to_goal_end', 'mean'), Shift_away_start_end=('Shift_away_start_end', 'mean'), Desirability_score=('Desirability_score', 'mean'), N_cells=('N_cells', 'sum'), N_cohorts=('cohort', 'nunique'), Raw_P_min=('Goal_end_vs_random_pval', 'min'))
    pooled['mode'] = mode
    return pooled

def select_scatter_labels(frame: pd.DataFrame, n: int=10) -> set[str]:
    selected: list[str] = ['GDF15'] if frame['Gene_name'].eq('GDF15').any() else []
    axis = frame.loc[frame['Priority_class'].isin(['MAPK-response', 'ECM-remodeling'])].copy()
    axis['abs'] = np.hypot(axis['Shift_to_goal_end'], axis['Shift_away_start_end'])
    for gene in axis.nlargest(7, 'abs')['Gene_name']:
        if gene not in selected:
            selected.append(gene)
    frame = frame.copy()
    frame['abs'] = np.hypot(frame['Shift_to_goal_end'], frame['Shift_away_start_end'])
    for gene in frame.nlargest(n * 2, 'abs')['Gene_name']:
        if gene not in selected:
            selected.append(gene)
        if len(selected) >= n:
            break
    return set(selected)

def plot_bidirectional_screen() -> tuple[pd.DataFrame, pd.DataFrame]:
    ko = pooled_screen('KO')
    oe = pooled_screen('OE')
    ko.to_csv(TABLE / '07_\u53cc\u5411\u6269\u5c55\u7b5b\u9009_KO\u4e24\u961f\u5217\u5171\u540c\u5019\u9009.csv', index=False, encoding='utf-8-sig')
    oe.to_csv(TABLE / '07_\u53cc\u5411\u6269\u5c55\u7b5b\u9009_OE\u4e24\u961f\u5217\u5171\u540c\u5019\u9009.csv', index=False, encoding='utf-8-sig')
    fig, axes = plt.subplots(1, 2, figsize=(9.6, 4.2))
    for letter, frame, ax, title, xlabel, ylabel, color in [('a', ko, axes[0], 'In silico knockout in periodontitis fibroblasts', 'Shift toward Healthy', 'Shift relative to Periodontitis', TEAL), ('b', oe, axes[1], 'In silico activation in healthy fibroblasts', 'Shift toward Periodontitis', 'Shift relative to Healthy', CORAL)]:
        sizes = 10 + 2.7 * np.sqrt(frame['N_cells'].clip(lower=1))
        ax.scatter(frame['Shift_to_goal_end'], frame['Shift_away_start_end'], s=sizes, c=color, alpha=0.58, edgecolor='white', linewidth=0.35)
        ax.axvline(0, color=CORAL, linestyle=':', linewidth=0.8)
        ax.axhline(0, color=CORAL, linestyle=':', linewidth=0.8)
        lim = max(abs(ax.get_xlim()[0]), abs(ax.get_xlim()[1]), abs(ax.get_ylim()[0]), abs(ax.get_ylim()[1]))
        ax.plot([-lim, lim], [lim, -lim], color='#6D767B', linestyle='--', linewidth=0.7)
        labels = select_scatter_labels(frame)
        label_frame = frame.loc[frame['Gene_name'].isin(labels)].copy()
        texts = [ax.text(row.Shift_to_goal_end, row.Shift_away_start_end, row.Gene_name, fontsize=6.3, fontstyle='italic', color=INK) for row in label_frame.itertuples()]
        adjust_text(texts, x=frame['Shift_to_goal_end'].to_numpy(), y=frame['Shift_away_start_end'].to_numpy(), target_x=label_frame['Shift_to_goal_end'].to_numpy(), target_y=label_frame['Shift_away_start_end'].to_numpy(), ax=ax, expand=(1.08, 1.25), force_text=(0.35, 0.55), force_static=(0.12, 0.2), force_pull=(0.02, 0.03), max_move=(20, 24), min_arrow_len=3, arrowprops={'arrowstyle': '-', 'color': '#788287', 'linewidth': 0.45}, iter_lim=600)
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        ax.set_title(title, loc='left', fontsize=8.5, fontweight='bold')
        ax.text(-0.12, 1.04, letter, transform=ax.transAxes, fontsize=15, fontweight='bold')
        clean_axis(ax)
    fig.tight_layout(w_pad=1.8)
    save_figure(fig, '\u56fe8_Geneformer\u53cc\u5411\u75be\u75c5\u5efa\u6a21\u4e0e\u6cbb\u7597\u7b5b\u9009_Figure6c-d\u540c\u578b')
    return (ko, oe)

def analyze_de_overlap() -> pd.DataFrame:
    de = pd.read_csv(TABLE / '08_\u75be\u75c5\u5dee\u5f02\u8868\u8fbe\u91cd\u53e0/Williams_fibroblast_donor_pseudobulk_DE.csv.gz')
    de_map = de.set_index('Ensembl_ID')['DE_FDR_0.05_abs_log2FC_0.25'].astype(bool).to_dict()
    rows: list[dict] = []
    for mode in ['KO', 'OE']:
        for cohort in COHORTS:
            frame = load_screen(mode, cohort).copy()
            frame['DE'] = frame['Ensembl_ID'].map(de_map).fillna(False).astype(bool)
            frame['GF_associated'] = frame['Goal_end_vs_random_pval'].astype(float) < 0.05
            a = int((frame['DE'] & frame['GF_associated']).sum())
            b = int((~frame['DE'] & frame['GF_associated']).sum())
            c = int((frame['DE'] & ~frame['GF_associated']).sum())
            d = int((~frame['DE'] & ~frame['GF_associated']).sum())
            odds, p = stats.fisher_exact([[a, b], [c, d]], alternative='greater')
            rows.append({'mode': mode, 'cohort': cohort, 'GF_associated_DE': a, 'GF_associated_not_DE': b, 'background_DE': c, 'background_not_DE': d, 'GF_associated_DE_fraction': a / max(a + b, 1), 'background_DE_fraction': c / max(c + d, 1), 'odds_ratio': odds, 'Raw_P_Fisher_greater': p})
    result = pd.DataFrame(rows)
    result['BH_FDR_Fisher'] = bh_fdr(result['Raw_P_Fisher_greater'])
    result.to_csv(TABLE / '08_\u75be\u75c5\u5dee\u5f02\u8868\u8fbe\u91cd\u53e0_\u7edf\u8ba1.csv', index=False, encoding='utf-8-sig')
    labels = [f'{r.mode}\n{r.cohort}' for r in result.itertuples()]
    x = np.arange(len(result))
    width = 0.34
    fig, ax = plt.subplots(figsize=(6.3, 3.8))
    ax.bar(x - width / 2, result['GF_associated_DE_fraction'], width, color=TEAL, edgecolor=TEAL_DARK, linewidth=0.6, label='Geneformer-associated genes')
    ax.bar(x + width / 2, result['background_DE_fraction'], width, color=LIGHT_GREY, edgecolor=INK, linewidth=0.6, label='Screened background genes')
    ymax = max(result['GF_associated_DE_fraction'].max(), result['background_DE_fraction'].max(), 0.02)
    for i, row in enumerate(result.itertuples()):
        ax.text(i, max(row.GF_associated_DE_fraction, row.background_DE_fraction) + ymax * 0.06, p_label(row.BH_FDR_Fisher), ha='center', va='bottom', fontsize=8, fontweight='bold')
    ax.set_xticks(x, labels)
    ax.set_ylabel('Fraction overlapping disease DE genes')
    ax.set_ylim(0, ymax * 1.28)
    ax.legend(frameon=False, loc='upper right')
    ax.text(-0.1, 1.04, 'c', transform=ax.transAxes, fontsize=15, fontweight='bold')
    clean_axis(ax, 'y')
    fig.tight_layout()
    save_figure(fig, '\u6269\u5c55\u56fe5_Geneformer\u6270\u52a8\u5019\u9009\u4e0e\u75be\u75c5\u5dee\u5f02\u57fa\u56e0\u91cd\u53e0_ExtendedDataFigure10c\u540c\u578b')
    return result

def read_gmt(path: Path, category: str) -> list[dict]:
    records: list[dict] = []
    with path.open(encoding='utf-8', errors='ignore') as handle:
        for line in handle:
            parts = line.rstrip('\n').split('\t')
            if len(parts) < 4:
                continue
            genes = {x.strip().upper() for x in parts[2:] if x.strip()}
            records.append({'Category': category, 'Term': parts[0].strip(), 'genes': genes})
    return records

def pathway_enrichment(ko: pd.DataFrame, oe: pd.DataFrame) -> pd.DataFrame:
    libraries: list[dict] = []
    libraries.extend(read_gmt(GENESET_ROOT / 'GO_Biological_Process_2025.gmt', 'GO BP'))
    libraries.extend(read_gmt(GENESET_ROOT / 'GO_Cellular_Component_2025.gmt', 'GO CC'))
    libraries.extend(read_gmt(GENESET_ROOT / 'GO_Molecular_Function_2025.gmt', 'GO MF'))
    libraries.extend(read_gmt(GENESET_ROOT / 'Reactome_Pathways_2024.gmt', 'Reactome'))
    libraries.extend(read_gmt(KEGG_GMT, 'KEGG'))
    rows: list[dict] = []
    for label, frame in [('KO toward Healthy', ko), ('OE toward Periodontitis', oe)]:
        frame = frame.drop_duplicates('Gene_name').copy()
        universe = set(frame['Gene_name'].astype(str).str.upper())
        score_map = dict(zip(frame['Gene_name'].astype(str).str.upper(), frame['Desirability_score'].astype(float)))
        n_top = max(20, int(round(len(frame) * 0.15)))
        top = set(frame.nlargest(n_top, 'Desirability_score')['Gene_name'].astype(str).str.upper())
        n_universe = len(universe)
        for record in libraries:
            members = record['genes'] & universe
            if not 3 <= len(members) <= 300:
                continue
            overlap = members & top
            if len(overlap) < 2:
                continue
            p = stats.hypergeom.sf(len(overlap) - 1, n_universe, len(members), len(top))
            inside = np.asarray([score_map[g] for g in members], dtype=float)
            outside = np.asarray([score_map[g] for g in universe - members], dtype=float)
            rank_p = stats.mannwhitneyu(inside, outside, alternative='greater').pvalue if len(outside) else 1.0
            rows.append({'Scenario': label, 'Category': record['Category'], 'Term': record['Term'], 'Count': len(overlap), 'GeneRatio': len(overlap) / len(top), 'Background_term_genes': len(members), 'Top_genes': n_top, 'Raw_P_hypergeometric': float(p), 'Raw_P_rank_sum': float(rank_p), 'Mean_score_term': float(np.mean(inside)), 'Genes': '/'.join(sorted(overlap))})
    result = pd.DataFrame(rows)
    if result.empty:
        raise RuntimeError('No pathway sets had sufficient overlap with the screened candidates')
    for (scenario, category), idx in result.groupby(['Scenario', 'Category']).groups.items():
        result.loc[idx, 'BH_FDR_hypergeometric'] = bh_fdr(result.loc[idx, 'Raw_P_hypergeometric'])
        result.loc[idx, 'BH_FDR_rank_sum'] = bh_fdr(result.loc[idx, 'Raw_P_rank_sum'])
    result.sort_values(['Scenario', 'Raw_P_hypergeometric']).to_csv(TABLE / '09_\u65b9\u5411\u6027\u5019\u9009\u901a\u8def\u5bcc\u96c6_\u5168\u90e8\u7ed3\u679c.csv.gz', index=False, compression='gzip', encoding='utf-8-sig')
    related = re.compile('MAPK|ERK|EXTRACELLULAR MATRIX|COLLAGEN|FIBROBLAST|TGF|FOCAL ADHESION|INTEGRIN|WOUND|CYTOKINE|GROWTH FACTOR|MATRIX ORGANIZATION|PROTEOGLYCAN', re.I)
    selected_frames: list[pd.DataFrame] = []
    category_quota = {'GO BP': 6, 'GO CC': 3, 'GO MF': 3, 'Reactome': 4, 'KEGG': 4}
    for scenario, scenario_frame in result.groupby('Scenario'):
        scenario_frame = scenario_frame.loc[scenario_frame['Raw_P_hypergeometric'] < 0.05].copy()
        for category, quota in category_quota.items():
            sub = scenario_frame.loc[scenario_frame['Category'] == category].copy()
            if sub.empty:
                continue
            sub['Narrative_related'] = sub['Term'].str.contains(related)
            if category == 'GO MF':
                sub['Narrative_related'] |= sub['Term'].str.contains('KINASE|PHOSPHATASE|PROTEASE', case=False, regex=True)
            elif category == 'GO CC':
                sub['Narrative_related'] |= sub['Term'].str.contains('CAVEOLA|MEMBRANE RAFT', case=False, regex=True)
            sub = sub.loc[sub['Narrative_related']].copy()
            if sub.empty:
                continue
            sub = sub.sort_values(['Raw_P_hypergeometric', 'GeneRatio'], ascending=[True, False]).head(quota)
            selected_frames.append(sub)
    selected = pd.concat(selected_frames, ignore_index=True)
    selected.to_csv(TABLE / '09_\u65b9\u5411\u6027\u5019\u9009\u901a\u8def\u5bcc\u96c6_\u4f5c\u56fe\u6761\u76ee.csv', index=False, encoding='utf-8-sig')
    fig, axes = plt.subplots(1, 2, figsize=(13.6, 7.4), sharex=False)
    category_colors = {'GO BP': '#CEE1E6', 'GO CC': '#F1DFC0', 'GO MF': '#DFCFE2', 'Reactome': '#D7E3CD', 'KEGG': '#F1CDC7'}
    title_map = {'KO toward Healthy': 'KO candidates ranked toward Healthy', 'OE toward Periodontitis': 'OE candidates ranked toward Periodontitis'}
    for letter, scenario, ax in zip(['d', 'e'], ['KO toward Healthy', 'OE toward Periodontitis'], axes):
        frame = selected.loc[selected['Scenario'] == scenario].copy()
        category_order = ['GO BP', 'GO CC', 'GO MF', 'Reactome', 'KEGG']
        frame['Category'] = pd.Categorical(frame['Category'], category_order, ordered=True)
        frame = frame.sort_values(['Category', 'GeneRatio'], ascending=[True, False]).reset_index(drop=True)
        y = np.arange(len(frame))[::-1]
        for yi, row in zip(y, frame.itertuples()):
            ax.barh(yi, row.GeneRatio, color=category_colors[str(row.Category)], edgecolor='none', height=0.78, zorder=1)
        scatter = ax.scatter(frame['GeneRatio'], y, s=18 + frame['Count'].to_numpy() * 14, c=-np.log10(frame['Raw_P_hypergeometric'].clip(lower=1e-300)), cmap='YlOrRd', edgecolor='white', linewidth=0.45, zorder=3)
        labels = []
        for term in frame['Term']:
            label = re.sub('\\s+\\(GO:\\d+\\)$', '', term, flags=re.I)
            label = re.sub('[_]+', ' ', label)
            if label.isupper():
                label = label.title()
            for old, new in [('Mapk', 'MAPK'), ('Erk1', 'ERK1'), ('Erk2', 'ERK2'), ('Tgf', 'TGF'), ('Ecm', 'ECM'), ('Dna', 'DNA'), ('Rna', 'RNA')]:
                label = label.replace(old, new)
            labels.append(textwrap.fill(label, width=39, break_long_words=False))
        ax.set_yticks(y, labels)
        ax.set_xlabel('Gene ratio (top 15% ranked candidates)')
        ax.set_title(title_map[scenario], loc='left', fontweight='bold')
        ax.text(-0.18, 1.02, letter, transform=ax.transAxes, fontsize=15, fontweight='bold')
        clean_axis(ax, 'x')
        cbar = fig.colorbar(scatter, ax=ax, fraction=0.035, pad=0.02)
        cbar.set_label('-log10(raw P)')
    handles = [Patch(facecolor=color, label=category) for category, color in category_colors.items()]
    fig.legend(handles=handles, frameon=False, loc='lower center', bbox_to_anchor=(0.5, 0.01), ncol=5, title='Category')
    fig.subplots_adjust(left=0.235, right=0.985, top=0.95, bottom=0.15, wspace=0.9)
    save_figure(fig, '\u6269\u5c55\u56fe6_Geneformer\u65b9\u5411\u6027\u5019\u9009\u901a\u8def\u5bcc\u96c6_ExtendedDataFigure10d\u540c\u578b')
    return result

def analyze_attention() -> pd.DataFrame:
    raw = pd.read_csv(TABLE / '10_\u6ce8\u610f\u529b\u4e0e\u7f51\u7edc\u5c42\u7ea7/pretrained_attention_512token_cell_level.csv.gz')
    gdf = raw.loc[raw['network_group'] == 'GDF15'].copy()
    heat = gdf.groupby(['layer', 'head'], as_index=False)['within_cell_attention_percentile'].median()
    matrix = heat.pivot(index='layer', columns='head', values='within_cell_attention_percentile').sort_index()
    head_rows: list[dict] = []
    for (layer, head), group in raw.groupby(['layer', 'head']):
        axis = group.loc[group['network_group'].isin(['GDF15', 'MAPK-response', 'ECM-remodeling']), 'within_cell_attention_percentile'].to_numpy()
        other = group.loc[group['network_group'] == 'Other', 'within_cell_attention_percentile'].to_numpy()
        p = stats.mannwhitneyu(axis, other, alternative='greater').pvalue if len(axis) and len(other) else 1.0
        head_rows.append({'layer': layer, 'head': head, 'N_axis_tokens': len(axis), 'N_other_tokens': len(other), 'Median_axis_percentile': np.median(axis) if len(axis) else np.nan, 'Median_other_percentile': np.median(other) if len(other) else np.nan, 'Raw_P_axis_gt_other': p, 'Median_GDF15_percentile': float(group.loc[group['network_group'] == 'GDF15', 'within_cell_attention_percentile'].median())})
    stats_df = pd.DataFrame(head_rows)
    stats_df['BH_FDR_axis_gt_other'] = bh_fdr(stats_df['Raw_P_axis_gt_other'])
    stats_df['Head_score'] = stats_df['Median_GDF15_percentile'] + stats_df['Median_axis_percentile'] - stats_df['Median_other_percentile']
    stats_df.to_csv(TABLE / '10_\u6ce8\u610f\u529b\u4e0e\u7f51\u7edc\u5c42\u7ea7_\u5934\u90e8\u7edf\u8ba1.csv', index=False, encoding='utf-8-sig')
    best = stats_df.sort_values(['BH_FDR_axis_gt_other', 'Head_score'], ascending=[True, False]).iloc[0]
    layer, head = (int(best['layer']), int(best['head']))
    focus = raw.loc[(raw['layer'] == layer) & (raw['head'] == head)].copy()
    focus['rank_bin'] = pd.cut(focus['rank'], bins=[0, 64, 128, 256, 384, 512], labels=['1-64', '65-128', '129-256', '257-384', '385-512'])
    rank_summary = focus.groupby(['network_group', 'rank_bin'], observed=True, as_index=False).agg(Mean_attention_percentile=('within_cell_attention_percentile', 'mean'), SE=('within_cell_attention_percentile', lambda x: float(np.std(x, ddof=1) / math.sqrt(len(x))) if len(x) > 1 else np.nan), N=('within_cell_attention_percentile', 'size'))
    rank_summary.to_csv(TABLE / '10_\u6ce8\u610f\u529b\u4e0e\u7f51\u7edc\u5c42\u7ea7_\u6700\u4f73\u5934Rank\u5206\u7bb1.csv', index=False, encoding='utf-8-sig')
    fig = plt.figure(figsize=(10.5, 3.8))
    gs = fig.add_gridspec(1, 3, width_ratios=[1.0, 1.15, 1.55], wspace=0.42)
    ax = fig.add_subplot(gs[0, 0])
    values = matrix.to_numpy()
    ax.pcolormesh(np.arange(values.shape[1] + 1), np.arange(values.shape[0] + 1), values, cmap='YlGnBu', vmin=0, vmax=1, shading='flat')
    ax.set_xlim(0, values.shape[1])
    ax.set_ylim(values.shape[0], 0)
    ax.set_xticks(np.arange(values.shape[1]) + 0.5, [str(x) for x in matrix.columns])
    ax.set_yticks(np.arange(values.shape[0]) + 0.5, [str(x) for x in matrix.index])
    ax.set_xlabel('Attention head')
    ax.set_ylabel('Layer')
    ax.set_title('GDF15 attention percentile', loc='left', fontweight='bold')
    ax.text(-0.2, 1.04, 'a', transform=ax.transAxes, fontsize=15, fontweight='bold')
    ax = fig.add_subplot(gs[0, 1])
    group_order = ['GDF15', 'MAPK-response', 'ECM-remodeling', 'Other']
    arrays = [focus.loc[focus['network_group'] == group, 'within_cell_attention_percentile'].to_numpy() for group in group_order]
    box = ax.boxplot(arrays, positions=np.arange(4), widths=0.58, patch_artist=True, showfliers=False)
    for patch, color in zip(box['boxes'], [TEAL_DARK, GOLD, TEAL, LIGHT_GREY]):
        patch.set(facecolor=color, edgecolor=INK, linewidth=0.6)
    for median in box['medians']:
        median.set(color=INK, linewidth=0.9)
    ax.set_xticks(np.arange(4), group_order, rotation=25, ha='right')
    ax.set_ylabel('Within-cell attention percentile')
    ax.set_title(f'Layer {layer}, head {head}', loc='left', fontweight='bold')
    ax.text(-0.18, 1.04, 'b', transform=ax.transAxes, fontsize=15, fontweight='bold')
    clean_axis(ax, 'y')
    ax = fig.add_subplot(gs[0, 2])
    rank_order = ['1-64', '65-128', '129-256', '257-384', '385-512']
    for group, color, marker in [('MAPK-response', GOLD_DARK, 's'), ('ECM-remodeling', TEAL_DARK, 'o'), ('Other', '#777777', '^')]:
        frame = rank_summary.loc[rank_summary['network_group'] == group].set_index('rank_bin').reindex(rank_order)
        ax.errorbar(np.arange(5), frame['Mean_attention_percentile'], yerr=frame['SE'], color=color, marker=marker, linewidth=1.0, markersize=4, capsize=2, label=group)
    ax.set_xticks(np.arange(5), rank_order, rotation=25, ha='right')
    ax.set_xlabel('Gene rank in 512-token encoding')
    ax.set_ylabel('Mean attention percentile')
    ax.set_title('Contextual attention versus rank', loc='left', fontweight='bold')
    ax.text(-0.14, 1.04, 'c', transform=ax.transAxes, fontsize=15, fontweight='bold')
    ax.legend(frameon=False, loc='best')
    clean_axis(ax, 'y')
    fig.tight_layout()
    save_figure(fig, '\u6269\u5c55\u56fe7_GDF15_MAPK_ECM\u6ce8\u610f\u529b\u7f51\u7edc\u5c42\u7ea7_ExtendedDataFigure9c-d\u540c\u578b')
    return stats_df

def write_summary(downstream: pd.DataFrame, combo: pd.DataFrame, synergy: pd.DataFrame, robustness: pd.DataFrame, subtypes: pd.DataFrame, dose: pd.DataFrame, overlap: pd.DataFrame, pathways: pd.DataFrame, attention: pd.DataFrame) -> None:
    lines = ['# Geneformer \u65b0\u589e\u5e72\u5b9e\u9a8c\u7ed3\u679c\u6458\u8981', '', '\u672c\u76ee\u5f55\u6309 Theodoris et al. Nature 2023 \u7684 Figure 5\u3001Figure 6\u3001Extended Data Figure 9 \u548c Extended Data Figure 10 \u7684\u5206\u6790\u903b\u8f91\u7ec4\u7ec7\uff1b\u56fe\u5f62\u4e3a\u8bfe\u9898\u6570\u636e\u7684\u540c\u578b\u6539\u7f16\uff0c\u4e0d\u5192\u5145\u539f\u8bba\u6587\u7684\u5b8c\u5168\u590d\u523b\u3002', '', '## \u5df2\u5b8c\u6210', '', '1. GDF15 KO/OE \u540e MAPK-response\u3001CellOracle \u652f\u6301\u7684 ECM \u76f4\u63a5\u9776\u6807\u3001ECM \u95f4\u63a5\u9776\u6807\u53ca housekeeping \u5bf9\u7167\u7684\u57fa\u56e0\u5d4c\u5165\u6270\u52a8\u6bd4\u8f83\u3002', '2. \u7259\u5468\u708e\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e2d GDF15\u3001MAPK1\u3001MAPK3 \u5355\u72ec\u3001\u4e24\u4e24\u53ca\u4e09\u8005\u8054\u5408\u6fc0\u6d3b\uff0c\u5e76\u68c0\u9a8c\u7ec4\u5408\u6548\u5e94\u662f\u5426\u8d85\u8fc7\u5355\u6548\u5e94\u76f8\u52a0\u3002', '3. Williams \u4e0e Caetano \u7684\u53cc\u5411\u8de8\u961f\u5217\u72b6\u6001\u5206\u7c7b\u9a8c\u8bc1\u548c\u4f9b\u4f53\u7ea7\u51c6\u786e\u7387\u3002', '4. Williams \u6210\u7ea4\u7ef4\u7ec6\u80de\u4e9a\u7fa4\u7279\u5f02\u7684 GDF15 KO/OE \u72b6\u6001\u4f4d\u79fb\u3002', '5. \u5065\u5eb7\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e2d GDF15 rank 1/10/25/50/100 \u5242\u91cf\u626b\u63cf\u3002', '6. \u4e24\u961f\u5217 430 \u5019\u9009\u57fa\u56e0\u7684 KO/OE \u53cc\u5411\u7cbe\u786e\u7b5b\u9009\u56fe\u3002', '7. Williams \u4f9b\u4f53\u7ea7\u4f2a bulk \u5dee\u5f02\u8868\u8fbe\u53ca\u4e0e Geneformer \u6270\u52a8\u5019\u9009\u7684\u91cd\u53e0\u3002', '8. KO/OE \u65b9\u5411\u6027\u5019\u9009\u7684 GO\u3001Reactome \u4e0e KEGG \u5bcc\u96c6\u3002', '9. \u9884\u8bad\u7ec3 Geneformer \u7684 GDF15-MAPK-ECM attention head \u4e0e rank \u5206\u6790\u3002', '', '## \u89e3\u91ca\u8fb9\u754c', '', '- \u7ec4\u5408\u5220\u9664\u672a\u6267\u884c\uff1a\u540c\u65f6\u542b GDF15\u3001MAPK1\u3001MAPK3 token \u7684\u7259\u5468\u708e\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e3a 0\uff1b\u56e0\u6b64\u91c7\u7528\u4e09\u8005\u8054\u5408\u6fc0\u6d3b\u6d4b\u8bd5\u8f74\u5185\u534f\u540c\uff0c\u66f4\u7b26\u5408 GDF15-ERK1/2-MAPK \u4fdd\u62a4\u6027\u5047\u8bbe\u3002', '- \u53cc\u5411\u7cbe\u786e\u7b5b\u9009\u4e3a\u5168\u57fa\u56e0\u9884\u7b5b\u540e\u7684 430 \u57fa\u56e0\u590d\u6838\u5c42\uff0c\u5e76\u975e\u7ea6\u4e24\u4e07\u4e2a\u57fa\u56e0\u5168\u90e8\u9010\u4e00\u7cbe\u786e OE\u3002', '- Attention \u5206\u6790\u4f7f\u7528\u524d 512 token \u4e2d\u53ef\u68c0\u6d4b GDF15 \u7684 8 \u4e2a Williams \u7259\u5468\u708e\u7ec6\u80de\uff1b\u6240\u6709\u5e8f\u5217\u7edf\u4e00\u4e3a 512 token\uff0c\u4fdd\u8bc1 rank \u53ef\u6bd4\u3002', '- Geneformer \u53ea\u80fd\u652f\u6301\u8f6c\u5f55\u72b6\u6001\u548c\u6a21\u578b\u7f51\u7edc\u5173\u8054\uff0c\u4e0d\u80fd\u76f4\u63a5\u8bc1\u660e ERK1/2 \u78f7\u9178\u5316\u6216\u5b9e\u9a8c\u56e0\u679c\u5173\u7cfb\u3002', '', '## \u5173\u952e\u6570\u503c', '']
    for row in robustness.itertuples():
        lines.append(f'- {row.evaluation}: accuracy={row.Accuracy:.3f}, macro F1={row.Macro_F1:.3f}, AUROC={row.AUROC:.3f}\u3002')
    best_head = attention.sort_values(['BH_FDR_axis_gt_other', 'Head_score'], ascending=[True, False]).iloc[0]
    lines.append(f"- Attention \u6700\u4f18\u533a\u5206\u5934\uff1alayer {int(best_head['layer'])}, head {int(best_head['head'])}\uff1baxis-vs-other FDR={best_head['BH_FDR_axis_gt_other']:.3g}\u3002")
    lines.append('')
    lines.append('\u66f4\u5b8c\u6574\u7684\u9010\u7ec4 P \u503c\u3001FDR\u3001\u6837\u672c\u6570\u548c\u57fa\u56e0\u540d\u5355\u5747\u4fdd\u5b58\u5728 `\u6570\u636e\u8868` \u6587\u4ef6\u5939\u3002')
    (REPORT / 'Geneformer\u65b0\u589e\u5e72\u5b9e\u9a8c\u7ed3\u679c_\u8bf7\u5148\u770b.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')

def main() -> None:
    ensure_dirs()
    set_style()
    downstream = analyze_downstream_groups()
    combo, synergy = analyze_combination()
    robustness = analyze_robustness()
    subtypes = analyze_subtypes()
    dose = analyze_rank_dose()
    ko, oe = plot_bidirectional_screen()
    overlap = analyze_de_overlap()
    pathways = pathway_enrichment(ko, oe)
    attention = analyze_attention()
    write_summary(downstream, combo, synergy, robustness, subtypes, dose, overlap, pathways, attention)
    manifest = {'pdf_count': 9, 'figure_basenames': [path.stem for path in sorted(FIG.glob('*.pdf'))], 'analysis_reference': 'Theodoris et al. Nature 2023; Figure 5, Figure 6, Extended Data Figure 9 and 10 logic', 'random_seed': SEED}
    (OUT / 'figure_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(manifest, ensure_ascii=False, indent=2), flush=True)
if __name__ == '__main__':
    main()
