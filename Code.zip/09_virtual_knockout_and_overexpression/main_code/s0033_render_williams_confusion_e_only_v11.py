from __future__ import annotations
import hashlib
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.colors as mcolors
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import numpy as np
import pandas as pd
ARCHIVE = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260907_Williams\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de\u6df7\u6dc6\u77e9\u9635_\u4ec5E\u56fe_\u53bblabel_\u6781\u7b80\u753b\u5e03_\u652f\u7ebf_v11')
SOURCE_TABLE = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260906_Geneformer_Williams\u7aef\u5230\u7aef\u4fdd\u5b88\u6a21\u578b_\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de_D-E\u91cd\u7ed8_\u652f\u7ebf_v8\\\u6570\u636e\u8868\\Williams\u5168\u90e81450\u4e2a\u6d4b\u8bd5\u7ec6\u80de_\u539f\u59cbGeneformer_logits.csv.gz')
SOURCE_V10 = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260907_Williams\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de\u6df7\u6dc6\u77e9\u9635_\u7248\u5f0f\u4fee\u6539_\u652f\u7ebf_v10\\\u56fe\u7247\\\u4fee\u6539\u7248_\u56fe1E_Geneformer\u7ec6\u80de\u72b6\u6001\u9884\u6d4b\u6df7\u6dc6\u77e9\u9635_Williams\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de_\u7ad6\u6392\u6807\u7b7e_\u7d27\u51d1\u753b\u5e03_v10.pdf')
STEM = '\u56fe1E_Geneformer\u7ec6\u80de\u72b6\u6001\u9884\u6d4b\u6df7\u6dc6\u77e9\u9635_Williams\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de_\u53bblabel_\u6781\u7b80\u753b\u5e03_v11'
CLASS_NAMES = ('Healthy', 'Periodontitis')

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def load_values() -> tuple[np.ndarray, dict[str, object]]:
    data = pd.read_csv(SOURCE_TABLE)
    labels = data['observed_label'].to_numpy(dtype=int)
    predictions = data['predicted_label'].to_numpy(dtype=int)
    counts = pd.Series(labels).value_counts().sort_index().to_dict()
    if len(data) != 1450 or counts != {0: 912, 1: 538}:
        raise ValueError(f'Unexpected Williams test population: n={len(data)}, counts={counts}')
    matrix = np.zeros((2, 2), dtype=int)
    for observed, predicted in zip(labels, predictions, strict=True):
        matrix[int(observed), int(predicted)] += 1
    if not np.array_equal(matrix, np.array([[677, 235], [166, 372]], dtype=int)):
        raise ValueError(f'Confusion matrix changed: {matrix.tolist()}')
    accuracy = float(np.mean(labels == predictions))
    class_f1: list[float] = []
    for category in (0, 1):
        true_positive = int(((labels == category) & (predictions == category)).sum())
        false_positive = int(((labels != category) & (predictions == category)).sum())
        false_negative = int(((labels == category) & (predictions != category)).sum())
        denominator = 2 * true_positive + false_positive + false_negative
        class_f1.append(0.0 if denominator == 0 else 2 * true_positive / denominator)
    macro_f1 = float(np.mean(class_f1))
    if not np.isclose(accuracy, 0.723448275862069):
        raise ValueError(f'Accuracy changed: {accuracy}')
    if not np.isclose(macro_f1, 0.7106458154493089):
        raise ValueError(f'Macro-F1 changed: {macro_f1}')
    return (matrix / matrix.sum(axis=1, keepdims=True), {'accuracy': accuracy, 'macro_f1': macro_f1, 'confusion_matrix': matrix.tolist()})

def draw(matrix_norm: np.ndarray, metrics: dict[str, object]) -> dict[str, object]:
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 7.5, 'axes.labelsize': 8, 'xtick.labelsize': 7.5, 'ytick.labelsize': 7.5, 'axes.linewidth': 0.6, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none'})
    fig = plt.figure(figsize=(2.6, 2.65), facecolor='white')
    ax = fig.add_axes([0.27, 0.35, 0.56, 0.56])
    cmap = plt.get_cmap('Blues')
    norm = mcolors.Normalize(vmin=0.0, vmax=1.0)
    for row in range(2):
        for column in range(2):
            value = float(matrix_norm[row, column])
            ax.add_patch(Rectangle((column, row), 1, 1, facecolor=cmap(norm(value)), edgecolor='white', linewidth=0.5))
            ax.text(column + 0.5, row + 0.5, f'{value:.2f}', ha='center', va='center', fontsize=10, color='white' if value >= 0.55 else 'black')
    ax.set_xlim(0, 2)
    ax.set_ylim(2, 0)
    ax.set_aspect('equal')
    ax.set_xticks([0.5, 1.5], CLASS_NAMES)
    ax.set_yticks([0.5, 1.5], CLASS_NAMES)
    for tick_label in ax.get_yticklabels():
        tick_label.set_rotation(90)
        tick_label.set_rotation_mode('anchor')
        tick_label.set_horizontalalignment('center')
        tick_label.set_verticalalignment('center')
    ax.set_xlabel('Predicted', labelpad=4)
    ax.set_ylabel('True', labelpad=20)
    ax.tick_params(axis='x', length=0, pad=4)
    ax.tick_params(axis='y', length=0, pad=7)
    for spine in ax.spines.values():
        spine.set_color('#B0B0B0')
        spine.set_linewidth(0.6)
    colorbar_ax = fig.add_axes([0.855, 0.35, 0.036, 0.56])
    color_steps = 128
    for step in range(color_steps):
        y0 = step / color_steps
        colorbar_ax.add_patch(Rectangle((0, y0), 1, 1 / color_steps, facecolor=cmap((step + 0.5) / color_steps), edgecolor='none', linewidth=0))
    colorbar_ax.set_xlim(0, 1)
    colorbar_ax.set_ylim(0, 1)
    colorbar_ax.set_xticks([])
    colorbar_ax.set_yticks([0.2, 0.4, 0.6, 0.8])
    colorbar_ax.yaxis.tick_right()
    colorbar_ax.tick_params(axis='y', labelsize=6, length=2, pad=2)
    for spine in colorbar_ax.spines.values():
        spine.set_linewidth(0.5)
    ax.text(0.5, -0.31, f"Accuracy: {float(metrics['accuracy']):.2f}\nF1 score: {float(metrics['macro_f1']):.2f}", transform=ax.transAxes, ha='center', va='top', fontsize=8.5, linespacing=1.12)
    image_dir = ARCHIVE / '\u56fe\u7247'
    image_dir.mkdir(parents=True, exist_ok=True)
    pdf_path = image_dir / f'{STEM}.pdf'
    svg_path = image_dir / f'{STEM}.svg'
    png_path = image_dir / f'{STEM}.png'
    fig.savefig(pdf_path, facecolor='white', bbox_inches='tight', pad_inches=0.025)
    fig.savefig(svg_path, facecolor='white', bbox_inches='tight', pad_inches=0.025)
    fig.savefig(png_path, dpi=600, facecolor='white', bbox_inches='tight', pad_inches=0.025)
    plt.close(fig)
    return {'pdf': str(pdf_path), 'svg': str(svg_path), 'png': str(png_path), 'panel': 'E only', 'axis_titles': {'x': 'Predicted', 'y': 'True'}, 'sample_sizes_shown': False, 'panel_letter_shown': False, 'metric_decimals': 2, 'canvas_inches_before_tight_crop': [2.6, 2.65]}

def main() -> None:
    for subdirectory in ('\u56fe\u7247', '\u6570\u636e\u8868', 'QA'):
        (ARCHIVE / subdirectory).mkdir(parents=True, exist_ok=True)
    source_hash_before = sha256(SOURCE_V10)
    matrix_norm, metrics = load_values()
    figure_info = draw(matrix_norm, metrics)
    source_hash_after = sha256(SOURCE_V10)
    if source_hash_before != source_hash_after:
        raise RuntimeError('The v10 source figure was modified')
    pd.DataFrame({'True state': CLASS_NAMES, 'Predicted Healthy': matrix_norm[:, 0], 'Predicted Periodontitis': matrix_norm[:, 1]}).to_csv(ARCHIVE / '\u6570\u636e\u8868' / 'Williams\u5168\u90e8\u6d4b\u8bd5\u7ec6\u80de_\u884c\u5f52\u4e00\u5316\u6df7\u6dc6\u77e9\u9635_v11.csv', index=False, encoding='utf-8-sig')
    audit = {'status': 'E-only layout revision; all values unchanged; no source overwritten', 'source_v10': str(SOURCE_V10), 'source_table': str(SOURCE_TABLE), 'source_v10_sha256_before': source_hash_before, 'source_v10_sha256_after': source_hash_after, 'population_used_for_values': {'Healthy': 912, 'Periodontitis': 538, 'total': 1450}, 'metrics_full_precision': metrics, 'displayed_metrics': {'Accuracy': '0.72', 'F1 score': '0.71'}, 'figure': figure_info, 'vector_contract': 'all visible objects are native PDF vectors; no embedded raster image'}
    (ARCHIVE / 'QA' / '\u8fd0\u884c\u4e0e\u77e2\u91cf\u5ba1\u8ba1_v11.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(audit, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
