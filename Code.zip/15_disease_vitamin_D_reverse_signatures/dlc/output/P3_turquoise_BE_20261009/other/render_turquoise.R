.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(ggplot2)})
OLD<-'C:/wb_links/dlc/output/P3_hdWGCNA6_BE_20261009_GRsmall/other'
OUT<-'C:/Users/Lin/AppData/Local/Temp/p3_turquoise_BE_20261009'
sd<-file.path(OUT,'source_data');fig<-file.path(OUT,'panels')
dir.create(sd,recursive=TRUE,showWarnings=FALSE);dir.create(fig,recursive=TRUE,showWarnings=FALSE)
mods<-'turquoise'
shared<-fread(file.path(OLD,'source_data/02_shared_gene_statistics_hd_membership.csv'))
rkD<-sort(setNames(shared$t,shared$gene),decreasing=TRUE)
sg<-fread(file.path(OLD,'source_data/04_BC_VD_signatures_by_module.csv'))[module=='turquoise']
gb<-fread(file.path(OLD,'source_data/05_BC_signature_GSEA_rawP.csv'))[module=='turquoise']
vs<-setNames(lapply(gb$pathway,function(n)sg[pathway==n]$gene),gb$pathway)
allmc<-fread(file.path(OLD,'source_data/06_D_module_GSEA_rawP.csv'))
allora<-fread(file.path(OLD,'source_data/08_E_KO_module_Fisher_rawP.csv'))
mc<-allmc[pathway=='turquoise'];ora<-allora[module=='turquoise']
stopifnot(nrow(gb)==2,nrow(mc)==2,nrow(ora)==2)
fwrite(gb,file.path(sd,'B_turquoise_GSEA.csv'))
fwrite(sg,file.path(sd,'BC_turquoise_gene_sets.csv'))
fwrite(mc,file.path(sd,'D_turquoise_GSEA.csv'))
fwrite(ora,file.path(sd,'E_turquoise_Fisher.csv'))
code<-readLines('C:/wb_links/dlc/output/P3_hdWGCNA6_BE_20261009/other/run_hd6.R',warn=FALSE)
first<-which(startsWith(code,'TH <-'));last<-which(startsWith(code,'plots<-'))-1L
eval(parse(text=code[first:last]))

pD<-pD+scale_fill_gradient2(low='#2166AC',mid='#F7F7F7',high='#B2182B',midpoint=0,
 limits=range(allmc$NES),name='GSEA NES')
pE<-pE+scale_fill_viridis_c(name='Odds ratio\n(capped at 10)',option='viridis',
 limits=c(0,max(pmin(allora$OR,10),na.rm=TRUE)))
plots<-list(B=pB,C=pC,D=pD,E=pE)
dims<-list(B=c(4.8,2.65),C=c(4.8,2.65),D=c(4.8,2.15),E=c(4.8,2.15))
for(n in names(plots)){
 p<-plots[[n]]+labs(title=NULL,subtitle=NULL,caption=NULL)
 ggsave(file.path(fig,paste0('Fig5',n,'_turquoise.pdf')),p,width=dims[[n]][1],height=dims[[n]][2],device=cairo_pdf)
 ggsave(file.path(fig,paste0('Fig5',n,'_turquoise.png')),p,width=dims[[n]][1],height=dims[[n]][2],dpi=200,device=grDevices::png,type='cairo')
}
cat('[DONE] turquoise display only; no statistical recomputation\n')
