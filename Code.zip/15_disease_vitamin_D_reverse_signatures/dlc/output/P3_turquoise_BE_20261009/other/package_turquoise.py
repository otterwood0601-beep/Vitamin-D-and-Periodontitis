from pathlib import Path
import json, shutil, hashlib
import pandas as pd
import fitz
old = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\P3_hdWGCNA6_BE_20261009_GRsmall\\other')
temp = Path('C:\\Users\\Lin\\AppData\\Local\\Temp\\p3_turquoise_BE_20261009')
out = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\P3_turquoise_BE_20261009')
(out / '\u56fe').mkdir(parents=True, exist_ok=True)
pairs = [('B_turquoise_GSEA.csv', '05_BC_signature_GSEA_rawP.csv', 'module'), ('D_turquoise_GSEA.csv', '06_D_module_GSEA_rawP.csv', 'pathway'), ('E_turquoise_Fisher.csv', '08_E_KO_module_Fisher_rawP.csv', 'module')]
for fresh, previous, col in pairs:
    actual = pd.read_csv(temp / 'source_data' / fresh)
    original = pd.read_csv(old / 'source_data' / previous)
    pd.testing.assert_frame_equal(actual, original.loc[original[col] == 'turquoise'].reset_index(drop=True))
curves = pd.read_csv(temp / 'source_data/10_C_running_enrichment.csv')
original = pd.read_csv(old / 'source_data/10_C_running_enrichment.csv')
pd.testing.assert_frame_equal(curves, original.loc[original.module == 'turquoise'].reset_index(drop=True))
shutil.copytree(temp / 'source_data', out / 'other/source_data', dirs_exist_ok=True)
shutil.copytree(temp / 'panels', out / 'other/panels', dirs_exist_ok=True)
doc = fitz.open()
page = doc.new_page(width=710, height=372)
rects = {'B': (6, 6, 348, 194.8125), 'C': (362, 6, 704, 194.8125), 'D': (6, 210, 348, 363.1875), 'E': (362, 210, 704, 363.1875)}
for n, rect in rects.items():
    with fitz.open(temp / 'panels' / f'Fig5{n}_turquoise.pdf') as part:
        text = part[0].get_text()
        assert 'turquoise' in text
        for module in ['green', 'blue', 'red', 'yellow', 'brown']:
            assert module not in text.split(), (n, module)
        page.show_pdf_page(fitz.Rect(rect), part, 0)
pdf = out / '\u56fe/Fig5_B-E_turquoise_latest.pdf'
doc.set_metadata({'title': 'Figure 5 B-E turquoise only', 'subject': 'Display subset of fixed six-module analysis; raw P; no recomputation'})
doc.save(pdf)
doc.close()
qa = {'all_BCDE_values_identical_to_prior_turquoise_rows': True, 'all_C_curve_values_identical': True, 'visible_modules': ['turquoise'], 'original_D_E_color_limits_preserved': True, 'pages': 1, 'pdf_sha256': hashlib.sha256(pdf.read_bytes()).hexdigest()}
(out / 'other/QA.json').write_text(json.dumps(qa, indent=2), encoding='utf-8')
print(pdf)
