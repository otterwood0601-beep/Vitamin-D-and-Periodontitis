options(stringsAsFactors = FALSE)
source("E:/\u8840\u6e05\u7ef4\u751f\u7d20D DLC/00_\u5171\u7528\u914d\u7f6e/project_paths.R")
PROJ <- "P3_\u53cd\u5411\u7b7e\u540d"; ensure_dirs(PROJ)
FIG <- SEG_FIGDIR(PROJ); SD <- SEG_SRC(PROJ); QA <- SEG_QA(PROJ)

suppressPackageStartupMessages({
  library(data.table); library(ggplot2); library(patchwork); library(ggrepel)
})
set.seed(20260910L)
t0 <- Sys.time()

cat("[0] load disease and treatment signatures\n")
dis <- fread(DE_DONOR_GZ)
setnames(dis, c("log2FC_periodontitis_minus_healthy", "FDR"),
         c("lfc_disease", "fdr_disease"), skip_absent = TRUE)
dis <- dis[, .(gene, lfc_disease, t_statistic, p_value, fdr_disease)]

vd <- fread(DESEQ_ALL)
setnames(vd, c("log2FoldChange", "padj"), c("lfc_vd", "fdr_vd"), skip_absent = TRUE)
vd <- vd[!is.na(gene_symbol), .(gene = gene_symbol, lfc_vd, fdr_vd, baseMean)]
vd <- vd[!duplicated(gene)]

gmt <- list()
for (ln in readLines(file.path(WORK, "01_\u6570\u636e\u51c6\u5907/outputs/curated_gene_sets_v1.gmt"))) {
  p <- strsplit(ln, "\t", fixed = TRUE)[[1]]
  gmt[[p[1]]] <- p[-c(1, 2)]
}

m <- merge(dis, vd, by = "gene", all = FALSE)
cat("    genes with both signatures:", nrow(m), "\n")
fwrite(m, file.path(SD, "01_disease_vs_vitaminD_logFC_integration.csv"))

cat("[A] quadrant plot\n")
m[, dir_disease := fcase(lfc_disease > 0.25 & fdr_disease < 0.05, "disease UP",
                         lfc_disease < -0.25 & fdr_disease < 0.05, "disease DOWN",
                         default = "ns")]
m[, dir_vd := fcase(lfc_vd > 0.5 & fdr_vd < 0.05, "VD UP",
                    lfc_vd < -0.5 & fdr_vd < 0.05, "VD DOWN", default = "ns")]
m[, module := {
  hit <- NA_character_
  for (s in names(gmt)) { if (gene %in% gmt[[s]]) hit <- ifelse(is.na(hit), s, paste(hit, s, sep = ";")) }
  hit
}, by = seq_len(nrow(m))]
setnames(m, "module", "locked_modules")

ct <- suppressWarnings(cor.test(m$lfc_disease, m$lfc_vd, method = "spearman"))
rho <- unname(ct$estimate); p_rho <- ct$p.value
ct_de <- suppressWarnings(cor.test(m[dir_disease != "ns"]$lfc_disease,
                                   m[dir_disease != "ns"]$lfc_vd, method = "spearman"))

mods <- m[!is.na(locked_modules)]
lab_genes <- c("GDF15", "MMP1", "MMP3", "MMP9", "MMP13", "TIMP1", "COL1A1", "COL3A1",
               "FN1", "FOS", "JUN", "EGR1", "DUSP1", "SPRY2", "IL11", "CXCL8", "PLAU", "IER3")
gpA <- ggplot(m, aes(lfc_disease, lfc_vd)) +
  geom_hline(yintercept = 0, colour = "grey60", linewidth = 0.35) +
  geom_vline(xintercept = 0, colour = "grey60", linewidth = 0.35) +
  geom_point(aes(colour = dir_vd), size = 0.35, alpha = 0.5, shape = 16) +
  geom_point(data = mods, size = 0.8, shape = 16, colour = "black") +
  geom_point(data = m[gene == "GDF15"], colour = "#B2182B", size = 2, shape = 17) +
  geom_text_repel(data = m[gene %in% lab_genes],
                  aes(label = gene), size = 2.2, max.overlaps = 20,
                  box.padding = 0.18, min.segment.length = 0, seed = 1) +
  scale_colour_manual(values = c("VD UP" = "#B2182B", "VD DOWN" = "#2166AC", "ns" = "grey80"),
                      na.translate = FALSE, name = "Vitamin D3 (GSE212728)") +
  labs(x = "log2 FC  periodontitis vs healthy (donor pseudobulk)",
       y = "log2 FC  vitamin D3 vs ethanol (GSE212728)",
       title = sprintf("Reverse-signature quadrant (Spearman rho = %.2f, p = %.1e)", rho, p_rho),
       subtitle = "Black dots = locked-module genes; triangle = GDF15") +
  THEME_NPJ + theme(plot.tag = element_text(face = "bold", size = 12),
                    plot.tag.position = "topleft", legend.position = "bottom") +
  labs(tag = "A")
ggsave(file.path(FIG, "\u56feP3A_\u75be\u75c5\u4e0eVD\u5904\u7406\u56db\u8c61\u9650\u56fe.pdf"), gpA, width = 4.0, height = 3.6)
ggsave(file.path(FIG, "\u56feP3A_\u75be\u75c5\u4e0eVD\u5904\u7406\u56db\u8c61\u9650\u56fe.png"), gpA, width = 4.0, height = 3.6, dpi = 300)

cat("[B] GSEA of VD signatures on disease ranking\n")
rk <- dis[!is.na(t_statistic)][order(-t_statistic)]
rnk_vec <- rk$t_statistic; names(rnk_vec) <- rk$gene
fg <- fgsea::fgseaMultilevel(
  pathways = list(VD_UP = vd[fdr_vd < 0.05 & lfc_vd > 0]$gene,
                  VD_DOWN = vd[fdr_vd < 0.05 & lfc_vd < 0]$gene),
  stats = rnk_vec, minSize = 5, maxSize = 2000,
  BPPARAM = BiocParallel::SerialParam())
fg_out <- as.data.table(fg)[, .(pathway, NES, pval, padj, size, leadingEdge)]
fg_out[, leadingEdge := sapply(leadingEdge, paste, collapse = ";")]
fwrite(fg_out, file.path(SD, "02_GSEA_VD_signature_on_disease_ranking.csv"))

fg_plot <- fg_out[, .(pathway, NES, pval, padj, size)]
gpB <- ggplot(fg_plot, aes(pathway, NES, fill = pathway)) +
  geom_col(width = 0.6, colour = "black", linewidth = 0.3) +
  geom_text(aes(label = sprintf("p.adj = %.1e\nn = %d", padj, size)), vjust = -0.15, size = 2.2) +
  geom_hline(yintercept = 0, linewidth = 0.4) +
  scale_fill_manual(values = c(VD_UP = "#B2182B", VD_DOWN = "#2166AC"), guide = "none") +
  coord_flip(ylim = c(0, max(fg_plot$NES) * 1.25)) +
  labs(x = NULL, y = "NES on disease ranking (limma t, PD vs healthy)",
       title = "Do vitamin-D-shifted genes move oppositely in disease?") +
  THEME_NPJ + theme(plot.tag = element_text(face = "bold", size = 12), plot.tag.position = "topleft") +
  labs(tag = "B")
ggsave(file.path(FIG, "\u56feP3B_VD\u7b7e\u540d\u75be\u75c5\u6392\u5e8fGSEA.pdf"), gpB, width = 3.4, height = 2.2)
ggsave(file.path(FIG, "\u56feP3B_VD\u7b7e\u540d\u75be\u75c5\u6392\u5e8fGSEA.png"), gpB, width = 3.4, height = 2.2, dpi = 300)

run_es <- function(set_name) {
  ord <- names(rnk_vec)
  g <- if (set_name == "VD_UP") vd[fdr_vd < 0.05 & lfc_vd > 0]$gene else
         vd[fdr_vd < 0.05 & lfc_vd < 0]$gene
  g <- intersect(g, ord)
  hits <- ord %in% g
  N <- length(hits); nh <- sum(hits)
  if (nh == 0 || nh == N)
    return(data.table(rank = integer(0), runningES = numeric(0), hit = logical(0),
                      set = set_name, rnk = numeric(0)))
  miss_w <- 1 / (N - nh)
  hit_w <- abs(rnk_vec[hits]) / sum(abs(rnk_vec[hits]))
  step <- rep(-miss_w, N)
  step[hits] <- hit_w
  runRS <- cumsum(step)
  data.table(rank = seq_along(hits), runningES = runRS, hit = hits,
             set = set_name, rnk = rnk_vec)
}
cur <- rbind(run_es("VD_UP"), run_es("VD_DOWN"))
gpB2 <- ggplot(cur, aes(rank, runningES, colour = set, group = set)) +
  geom_hline(yintercept = 0, linetype = "dashed", colour = "grey50", linewidth = 0.35) +
  geom_step(linewidth = 0.6) +
  geom_segment(aes(x = rank, xend = rank, y = runningES, yend = runningES - 0.02*hit),
               data = cur[hit == TRUE], linewidth = 0.15, alpha = 0.6) +
  facet_wrap(~set, scales = "free_x") +
  scale_colour_manual(values = c(VD_UP = "#B2182B", VD_DOWN = "#2166AC"), guide = "none") +
  labs(x = "Rank in disease-ordered list (limma t)", y = "Running enrichment score",
       title = "VD signatures on disease ranking") +
  THEME_NPJ + theme(plot.tag = element_text(face = "bold", size = 12), plot.tag.position = "topleft") +
  labs(tag = "B")
ggsave(file.path(FIG, "\u56feP3B2_VD\u7b7e\u540dGSEA\u5bcc\u96c6\u66f2\u7ebf.pdf"), gpB2, width = 4.2, height = 2.4)
ggsave(file.path(FIG, "\u56feP3B2_VD\u7b7e\u540dGSEA\u5bcc\u96c6\u66f2\u7ebf.png"), gpB2, width = 4.2, height = 2.4, dpi = 300)

cat("[C] module direction heatmap\n")
mod_dir <- rbindlist(lapply(names(gmt), function(s) {
  g <- intersect(gmt[[s]], m$gene)
  if (length(g) < 3) return(NULL)
  d <- m[gene %in% g]
  data.table(module = s, n_genes = length(g),
             mean_lfc_disease = mean(d$lfc_disease),
             mean_lfc_vd = mean(d$lfc_vd),
             t_disease = t.test(d$lfc_disease)$statistic,
             p_disease = t.test(d$lfc_disease)$p.value,
             t_vd = t.test(d$lfc_vd)$statistic,
             p_vd = t.test(d$lfc_vd)$p.value,
             sign_agree_pct = 100 * mean(sign(d$lfc_disease) == sign(d$lfc_vd)))
}))
mod_dir[, p_disease_BH := p.adjust(p_disease, "BH")]
mod_dir[, p_vd_BH := p.adjust(p_vd, "BH")]
fwrite(mod_dir, file.path(SD, "03_module_direction_consistency.csv"))

ml <- melt(mod_dir, id.vars = c("module", "n_genes", "sign_agree_pct",
                                "p_disease_BH", "p_vd_BH"),
           measure.vars = c("mean_lfc_disease", "mean_lfc_vd"))
ml[, dataset := fifelse(variable == "mean_lfc_disease", "Periodontitis (donor pseudobulk)",
                        "Vitamin D3 (GSE212728)")]
ml[, star := fifelse(dataset == "Periodontitis (donor pseudobulk)",
                     cut(p_disease_BH, c(-Inf, 0.001, 0.01, 0.05, Inf), labels = c("***", "**", "*", "")),
                     cut(p_vd_BH, c(-Inf, 0.001, 0.01, 0.05, Inf), labels = c("***", "**", "*", "")))]
ml[, lab := sprintf("%.2f%s", value, star)]
gpC <- ggplot(ml, aes(dataset, module, fill = value)) +
  geom_tile(colour = "white", linewidth = 0.6) +
  geom_text(aes(label = lab), size = 2.3) +
  scale_fill_gradient2(low = "#2166AC", mid = "#F7F7F7", high = "#B2182B", midpoint = 0,
                       name = "mean log2 FC") +
  labs(x = NULL, y = NULL, title = "Locked modules: disease vs vitamin-D direction",
       subtitle = "Stars = BH-adjusted one-sample t; % sign agreement shown in table") +
  THEME_NPJ + theme(axis.text.x = element_text(angle = 20, hjust = 1)) +
  theme(plot.tag = element_text(face = "bold", size = 12), plot.tag.position = "topleft") +
  labs(tag = "C")
ggsave(file.path(FIG, "\u56feP3C_\u6a21\u5757\u8de8\u6570\u636e\u65b9\u5411\u70ed\u56fe.pdf"), gpC, width = 4.6, height = 2.8)
ggsave(file.path(FIG, "\u56feP3C_\u6a21\u5757\u8de8\u6570\u636e\u65b9\u5411\u70ed\u56fe.png"), gpC, width = 4.6, height = 2.8, dpi = 300)

cat("[D] scTenifoldKnk GDF15-KO affected genes enrichment\n")
ko <- fread(file.path(SRC, "\u539f\u59cb\u6570\u636e/06_\u6700\u7ec8\u6295\u7a3f\u51fa\u56fe\u6e90\u8868/05_\u6b63\u6587\u56fe5_\u865a\u62df\u6572\u9664/AB\u7ec8\u7a3f_v20_\u6e90\u6570\u636e",
                      "A_virtual_KO_axis_focused_non_target_input_v8.csv"))
ko_sig <- ko[FDR_lt_0_05 == TRUE]$gene
uni <- m$gene
enr <- rbindlist(lapply(names(gmt), function(s) {
  g <- intersect(gmt[[s]], uni)
  k <- length(intersect(g, ko_sig))
  tab <- matrix(c(k, length(intersect(ko_sig, uni)) - k, length(g) - k,
                  length(uni) - length(intersect(g, ko_sig)) - (length(g) - k) - (length(intersect(ko_sig, uni)) - k)),
                nrow = 2)
  ft <- fisher.test(tab, alternative = "greater")
  data.table(module = s, n_module = length(g), n_ko_sig = length(intersect(ko_sig, uni)),
             overlap = k, OR = unname(ft$estimate), p_fisher = ft$p.value)
}))
enr[, p_BH := p.adjust(p_fisher, "BH")]
fwrite(enr, file.path(SD, "04_virtualKO_genes_module_enrichment.csv"))

gpD <- ggplot(enr, aes(module, -log10(p_fisher), fill = OR)) +
  geom_col(width = 0.62, colour = "black", linewidth = 0.3) +
  geom_hline(yintercept = -log10(0.05), linetype = "dashed", colour = "grey40", linewidth = 0.35) +
  scale_fill_viridis_c(name = "odds ratio", option = "viridis") +
  coord_flip() +
  labs(x = NULL, y = "-log10 Fisher p (one-sided)",
       title = sprintf("GDF15 virtual-KO affected genes (FDR<0.05, n=%d) vs locked modules", length(ko_sig)),
       subtitle = "Universe = genes shared by both signatures") +
  THEME_NPJ + theme(plot.tag = element_text(face = "bold", size = 12), plot.tag.position = "topleft") +
  labs(tag = "D")
ggsave(file.path(FIG, "\u56feP3D_\u865a\u62df\u6572\u9664\u57fa\u56e0\u6a21\u5757\u5bcc\u96c6.pdf"), gpD, width = 4.4, height = 2.6)
ggsave(file.path(FIG, "\u56feP3D_\u865a\u62df\u6572\u9664\u57fa\u56e0\u6a21\u5757\u5bcc\u96c6.png"), gpD, width = 4.4, height = 2.6, dpi = 300)

val <- list(created_at = format(Sys.time()), n_genes_merged = nrow(m),
            spearman_all = list(rho = rho, p = p_rho),
            spearman_diseaseDEGs = list(rho = unname(ct_de$estimate), p = ct_de$p.value),
            gsea = fg_out[, .(pathway, NES, pval, padj, size)],
            module_direction = mod_dir,
            caveat = "Cross-dataset reversal is associative: GSE212728 has 3 treated vs 2 control samples and no patient-level intervention data; reversal does not demonstrate in-vivo reversal of periodontitis.",
            sessionInfo = paste(capture.output(sessionInfo()), collapse = "\n"))
writeLines(jsonlite::toJSON(val, pretty = TRUE, auto_unbox = TRUE, digits = 6),
           file.path(QA, "P3_QA_report.json"))
cat("[done] P3 in", round(as.numeric(difftime(Sys.time(), t0, units = "mins")), 2), "min\n")
