import os, sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats as st
import gseapy as gp
from adjustText import adjust_text
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from style_npj import set_npj_style, save_npj, NPJ_CASE, NPJ_CTRL, MM
set_npj_style()
DER = 'C:\\wb_links\\dlc_derived'
OUTDIR = 'C:\\wb_links\\dlc_out\\\u6838\u5fc3\u7ed3\u679cB_\u53cd\u5411\u7b7e\u540d'
os.makedirs(OUTDIR, exist_ok=True)
dis = pd.read_csv('C:\\wb_links\\fig4_src\\03_donor_pseudobulk_DE_periodontitis_vs_healthy.csv.gz', encoding='utf-8-sig')
vd = pd.read_csv('C:\\wb_links\\fig3_bulk\\02_DESeq2_genome\\11_DESeq2_D3_vs_ethanol_all_genes.csv')
dis = dis.rename(columns={'gene': 'symbol', 'log2FC_periodontitis_minus_healthy': 'dis_log2FC', 't_statistic': 'dis_t', 'p_value': 'dis_p', 'FDR': 'dis_FDR'})
vd = vd[['gene_symbol', 'log2FoldChange', 'stat', 'pvalue', 'padj']].rename(columns={'gene_symbol': 'symbol', 'log2FoldChange': 'vd_log2FC', 'stat': 'vd_stat', 'pvalue': 'vd_p', 'padj': 'vd_FDR'})
m = dis.merge(vd, on='symbol', how='inner').dropna(subset=['dis_log2FC', 'vd_log2FC', 'vd_stat', 'dis_t'])
print('common genes:', len(m))
m.to_csv(os.path.join(DER, 'B3_gene_level_merged_disease_vs_VD.csv'), index=False)
rho, rho_p = st.spearmanr(m.dis_log2FC, m.vd_log2FC)
rho_t, rho_t_p = st.spearmanr(m.dis_t, m.vd_stat)
print(f'Spearman log2FC rho={rho:.3f} p={rho_p:.2e} | t-stat rho={rho_t:.3f} p={rho_t_p:.2e}')
thr = 0.5
sig = m[(m.dis_log2FC.abs() > thr) & (m.vd_log2FC.abs() > thr)]
opp = ((sig.dis_log2FC > 0) & (sig.vd_log2FC < 0)).sum() + ((sig.dis_log2FC < 0) & (sig.vd_log2FC > 0)).sum()
same = len(sig) - opp
fe_p = st.fisher_exact([[opp, same], [same, opp]])[1]
print(f'quadrant: |FC|>{thr} both: {len(sig)} genes, opposite={opp}, same={same}, Fisher p={fe_p:.3f}')
vd_pos = m.sort_values('vd_stat', ascending=False).query('vd_stat>0').head(300).symbol.tolist()
vd_neg = m.sort_values('vd_stat').query('vd_stat<0').head(300).symbol.tolist()
rnk = m[['symbol', 'dis_t']].dropna()
pre = gp.prerank(rnk=rnk, gene_sets={'VD_up_in_HGF_top300': vd_pos, 'VD_down_in_HGF_top300': vd_neg}, permutation_num=1000, seed=42, threads=4, min_size=10, max_size=3000, outdir=None, verbose=False)
res = pre.res2d[['Term', 'ES', 'NES', 'NOM p-val', 'FDR q-val']]
print(res.to_string())
res.to_csv(os.path.join(DER, 'B3_GSEA_VDsignatures_in_diseaseRank.csv'), index=False)
gdf = m[m.symbol == 'GDF15'][['symbol', 'dis_log2FC', 'dis_t', 'dis_p', 'dis_FDR', 'vd_log2FC', 'vd_stat', 'vd_p', 'vd_FDR']]
print(gdf.to_string())
fig = plt.figure(figsize=(180 * MM, 95 * MM))
gs = fig.add_gridspec(1, 3, wspace=0.38, left=0.08, right=0.97, top=0.84, bottom=0.17)
axA = fig.add_subplot(gs[0, 0])
axA.scatter(m.dis_log2FC, m.vd_log2FC, s=2, c='#BFBFBF', lw=0, rasterized=True)
lab_genes = {'GDF15': '#7E5AA7', 'FOS': NPJ_CASE, 'JUN': NPJ_CASE, 'COL1A1': NPJ_CTRL, 'MMP2': NPJ_CTRL, 'TIMP1': NPJ_CTRL}
offsets = {'GDF15': (6, -10), 'FOS': (-18, -10), 'JUN': (-16, 6), 'COL1A1': (6, 2), 'MMP2': (-24, 2), 'TIMP1': (6, 6)}
texts = []
for g, c in lab_genes.items():
    row = m[m.symbol == g]
    if len(row):
        x, y = (row.dis_log2FC.iloc[0], row.vd_log2FC.iloc[0])
        axA.scatter([x], [y], s=18, c=c, ec='black', lw=0.4, zorder=5)
        dx, dy = offsets.get(g, (4, 4))
        texts.append(axA.annotate(g, (x, y), textcoords='offset points', xytext=(dx, dy), fontsize=6))
adjust_text(texts, ax=axA, expand=(1.15, 1.25), force_text=(0.35, 0.55), arrowprops=dict(arrowstyle='-', color='#707070', lw=0.35))
axA.axhline(0, c='black', lw=0.5)
axA.axvline(0, c='black', lw=0.5)
axA.set_xlabel('Disease log2FC (PD \u2212 healthy)')
axA.set_ylabel('Vitamin D3 log2FC\n(D3 \u2212 ethanol, HGF)')
axA.text(0.03, 0.97, f'Spearman \u03c1 = {rho:.2f} (p = {rho_p:.0e})\nopposite-direction {opp}/{len(sig)} genes', transform=axA.transAxes, fontsize=7, va='top')
axA.set_title('Disease \xd7 vitamin-D quadrant', fontsize=8, fontweight='bold', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=0.35'))
fig.text(0.055, 0.92, 'A', fontsize=12, fontweight='bold')
for k, (term, tag, letter) in enumerate([('VD_down_in_HGF_top300', 'VD-down signature', 'B'), ('VD_up_in_HGF_top300', 'VD-up signature', 'C')]):
    ax = fig.add_subplot(gs[0, k + 1])
    r = pre.results[term]
    x = np.arange(len(r['RES']))
    es = float(res.loc[res.Term == term, 'ES'].iloc[0])
    ax.plot(x, r['RES'], lw=1.2, c=NPJ_CASE if es > 0 else NPJ_CTRL)
    ax.axhline(0, c='black', lw=0.5)
    hits = np.asarray(r['hits'], dtype=int)
    ax.vlines(hits, ymin=-0.04, ymax=0.04, lw=0.2, color='black', alpha=0.5)
    nes = float(res.loc[res.Term == term, 'NES'].iloc[0])
    fdr = float(res.loc[res.Term == term, 'FDR q-val'].iloc[0])
    ax.text(0.97, 0.96, f'NES = {nes:.2f}\nFDR = {fdr:.3f}', transform=ax.transAxes, fontsize=7, ha='right', va='top')
    ax.set_title(f'{tag} in disease rank', fontsize=8, fontweight='bold', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=0.35'))
    ax.set_xlabel('Rank in disease t-statistic')
    ax.set_ylabel('Enrichment score')
    fig.text(0.055 + (k + 1) * 0.305, 0.92, letter, fontsize=12, fontweight='bold')
save_npj(fig, os.path.join(OUTDIR, '\u6838\u5fc3\u7ed3\u679cB_\u53cd\u5411\u7b7e\u540d_\u56db\u8c61\u9650\u4e0eGSEA_20260914'), width_mm=180, height_mm=95, dpi=600)
print('FIG SAVED')
