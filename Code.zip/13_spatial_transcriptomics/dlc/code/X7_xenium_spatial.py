from __future__ import annotations
import gzip
import io
import os
import re
import sys
import zipfile
import numpy as np
import pandas as pd
from scipy import io as spio, sparse, stats
from scipy.spatial import cKDTree
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gingiva_reference import BROAD_ORDER, load_reference, derive_markers, marker_score_matrix, row_log_normalize, bh_fdr
from style_npj import set_npj_style, save_npj, NPJ_CASE, NPJ_CTRL, MM
set_npj_style()
ZIP = 'C:\\Users\\Lin\\Downloads\\dataverse_files.zip'
DER = 'E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\data_derived\\X7_Xenium'
OUT = 'E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\\u7b2c7\u9879_Xenium\u7a7a\u95f4\u5b9a\u4f4d'
os.makedirs(DER, exist_ok=True)
os.makedirs(OUT, exist_ok=True)

def unpack_bytes(b: bytes) -> bytes:
    return gzip.decompress(b) if b[:2] == b'\x1f\x8b' else b

def patient_id(sample: str) -> str:
    m = re.match('([HP]\\d+)', sample)
    return m.group(1) if m else sample

def read_tsv_symbols(z, fn):
    b = unpack_bytes(z.read(fn)).decode('utf-8')
    return [x.split('\t')[1] for x in b.splitlines() if x.strip()]

def find_entry(names, raw_sample, kind, variant=''):
    candidates = [n for n in names if n.startswith(raw_sample + '_') and '_' + kind in n]
    if variant == '-1':
        candidates = [n for n in candidates if '-1.gz' in n]
    else:
        candidates = [n for n in candidates if '-1.gz' not in n]
    if len(candidates) != 1:
        raise ValueError(f'{raw_sample}{variant} {kind}: expected 1 file, found {candidates}')
    return candidates[0]
z = zipfile.ZipFile(ZIP)
names = [e.filename for e in z.infolist() if not e.is_dir()]
cell_entries = [n for n in names if '_cells.csv' in n]
raw_counts = pd.Series([n.split('_', 1)[0] for n in cell_entries]).value_counts().to_dict()
records = []
for n in cell_entries:
    raw = n.split('_', 1)[0]
    variant = '-1' if '.csv-1.gz' in n else ''
    shown = raw + ('_rep2' if raw_counts.get(raw, 0) > 1 and variant else '')
    records.append((shown, raw, variant))
records.sort(key=lambda x: (x[0][0], int(re.search('\\d+', x[0]).group()), x[0]))
samples = [x[0] for x in records]
if not samples or any((s[0] not in 'HP' for s in samples)):
    raise ValueError('Xenium sample names do not encode H/P groups as expected.')
first_features = read_tsv_symbols(z, find_entry(names, records[0][1], 'features.tsv', records[0][2]))
Xref, obs_ref, ref_genes = load_reference(first_features)
markers, marker_audit, _ = derive_markers(Xref, obs_ref, ref_genes, top_n=10)
marker_audit.to_csv(os.path.join(DER, 'X7_gingiva_reference_marker_audit.csv'), index=False)
ref_scores = marker_score_matrix(Xref, ref_genes, markers)
ref_order = np.argsort(ref_scores, axis=1)
ref_pred = np.asarray(BROAD_ORDER)[ref_order[:, -1]]
ref_margin = ref_scores[np.arange(len(ref_scores)), ref_order[:, -1]] - ref_scores[np.arange(len(ref_scores)), ref_order[:, -2]]
truth = obs_ref['broad_type'].to_numpy()
fb_correct_margin = ref_margin[(truth == 'Fibroblast') & (ref_pred == 'Fibroblast')]
fb_margin_cut = float(np.quantile(fb_correct_margin, 0.1))
val = pd.crosstab(pd.Series(truth, name='truth'), pd.Series(ref_pred, name='pred'))
val.to_csv(os.path.join(DER, 'X7_reference_internal_confusion_counts.csv'))
pd.DataFrame([{'n_reference_cells': len(truth), 'overall_accuracy': np.mean(ref_pred == truth), 'fibroblast_sensitivity': np.mean(ref_pred[truth == 'Fibroblast'] == 'Fibroblast'), 'fibroblast_margin_10pct_cutoff': fb_margin_cut, 'reference_tissue': 'gingiva'}]).to_csv(os.path.join(DER, 'X7_reference_validation_metrics.csv'), index=False)
cell_tables = []
sample_rows = []
neigh_rows = []
rng = np.random.default_rng(20260914)
for si, (sample, raw_sample, variant) in enumerate(records, 1):
    f_features = find_entry(names, raw_sample, 'features.tsv', variant)
    f_matrix = find_entry(names, raw_sample, 'matrix.mtx', variant)
    f_cells = find_entry(names, raw_sample, 'cells.csv', variant)
    f_barcodes = find_entry(names, raw_sample, 'barcodes.tsv', variant)
    genes = read_tsv_symbols(z, f_features)
    raw_mtx = unpack_bytes(z.read(f_matrix))
    X = spio.mmread(io.BytesIO(raw_mtx), spmatrix=True).tocsr().T
    cells = pd.read_csv(io.BytesIO(unpack_bytes(z.read(f_cells))))
    barcodes = unpack_bytes(z.read(f_barcodes)).decode('utf-8').splitlines()
    if X.shape != (len(barcodes), len(genes)) or len(cells) != len(barcodes):
        raise ValueError(f'Dimension mismatch in {sample}: X={X.shape}, cells={len(cells)}, genes={len(genes)}')
    if cells['cell_id'].astype(str).tolist() != barcodes:
        raise ValueError(f'Barcode order mismatch in {sample}')
    g2i = {g: i for i, g in enumerate(genes)}
    common = [g for g in ref_genes if g in g2i]
    Xi = X[:, [g2i[g] for g in common]]
    Xn = row_log_normalize(Xi, 10000.0)
    scores = marker_score_matrix(Xn, common, markers)
    ord2 = np.argsort(scores, axis=1)
    pred = np.asarray(BROAD_ORDER)[ord2[:, -1]]
    margin = scores[np.arange(len(scores)), ord2[:, -1]] - scores[np.arange(len(scores)), ord2[:, -2]]
    total = np.asarray(X.sum(axis=1)).ravel()
    gi = g2i.get('GDF15')
    if gi is None:
        raise ValueError(f'GDF15 absent from {sample}')
    gdf_count = np.asarray(X[:, gi].todense()).ravel()
    gdf_norm = np.log1p(gdf_count / np.maximum(total, 1) * 10000.0)
    high_fb = (pred == 'Fibroblast') & (margin >= fb_margin_cut) & (total >= 20)
    group = 'Healthy' if sample.startswith('H') else 'Periodontitis'
    t = pd.DataFrame({'sample': sample, 'patient': patient_id(sample), 'group': group, 'cell_id': barcodes, 'x': cells.x_centroid.to_numpy(), 'y': cells.y_centroid.to_numpy(), 'total_counts': total, 'broad_type': pred, 'annotation_margin': margin, 'high_conf_fibroblast': high_fb, 'GDF15_count': gdf_count, 'GDF15_log_norm': gdf_norm})
    cell_tables.append(t)
    fb = t[t.high_conf_fibroblast]
    sample_rows.append({'sample': sample, 'patient': patient_id(sample), 'group': group, 'n_cells': len(t), 'median_transcripts': np.median(total), 'n_high_conf_fibroblasts': len(fb), 'n_GDF15pos_fibroblasts': int((fb.GDF15_count > 0).sum()), 'GDF15pos_fraction_fibroblasts': float((fb.GDF15_count > 0).mean()) if len(fb) else np.nan, 'mean_GDF15_log_norm_fibroblasts': fb.GDF15_log_norm.mean()})
    pos_idx = np.flatnonzero(high_fb & (gdf_count > 0))
    neg_idx = np.flatnonzero(high_fb & (gdf_count == 0))
    if len(pos_idx) > 2000:
        pos_idx = rng.choice(pos_idx, 2000, replace=False)
    if len(neg_idx) > max(len(pos_idx), 2000):
        neg_idx = rng.choice(neg_idx, max(len(pos_idx), 2000), replace=False)
    coords = cells[['x_centroid', 'y_centroid']].to_numpy()
    tree = cKDTree(coords)
    label_code = pd.Categorical(pred, categories=BROAD_ORDER).codes
    for status, anchors in [('GDF15+', pos_idx), ('GDF15-', neg_idx)]:
        if not len(anchors):
            continue
        counts = np.zeros(len(BROAD_ORDER), dtype=float)
        denom = 0
        for aidx, nb in zip(anchors, tree.query_ball_point(coords[anchors], r=50.0)):
            nb = np.asarray(nb, dtype=int)
            nb = nb[nb != aidx]
            code = label_code[nb]
            code = code[code >= 0]
            counts += np.bincount(code, minlength=len(BROAD_ORDER))
            denom += len(code)
        for k, ct in enumerate(BROAD_ORDER):
            neigh_rows.append({'sample': sample, 'patient': patient_id(sample), 'group': group, 'anchor_status': status, 'neighbor_type': ct, 'n_anchors': len(anchors), 'n_neighbors': denom, 'neighbor_fraction': counts[k] / denom if denom else np.nan})
    print(f'[{si:02d}/{len(samples)}] {sample}: cells={len(t):,}, high-conf FB={len(fb):,}, GDF15+ FB={(fb.GDF15_count > 0).sum():,}', flush=True)
z.close()
cells_all = pd.concat(cell_tables, ignore_index=True)
cells_all.to_csv(os.path.join(DER, 'X7_cell_annotations_GDF15.csv.gz'), index=False, compression='gzip')
sample_summary = pd.DataFrame(sample_rows)
sample_summary.to_csv(os.path.join(DER, 'X7_sample_summary.csv'), index=False)
neigh = pd.DataFrame(neigh_rows)
neigh.to_csv(os.path.join(DER, 'X7_radius50um_neighborhood_by_sample.csv'), index=False)
patient_summary = sample_summary.groupby(['patient', 'group'], as_index=False).agg(n_cells=('n_cells', 'sum'), n_high_conf_fibroblasts=('n_high_conf_fibroblasts', 'sum'), n_GDF15pos_fibroblasts=('n_GDF15pos_fibroblasts', 'sum'))
patient_summary['GDF15pos_fraction_fibroblasts'] = patient_summary.n_GDF15pos_fibroblasts / patient_summary.n_high_conf_fibroblasts
patient_summary.to_csv(os.path.join(DER, 'X7_patient_GDF15_summary.csv'), index=False)
h = patient_summary.query("group=='Healthy'").GDF15pos_fraction_fibroblasts.dropna()
p = patient_summary.query("group=='Periodontitis'").GDF15pos_fraction_fibroblasts.dropna()
u = stats.mannwhitneyu(p, h, alternative='two-sided')
pd.DataFrame([{'n_healthy_patients': len(h), 'n_periodontitis_patients': len(p), 'median_healthy': h.median(), 'median_periodontitis': p.median(), 'median_difference_PD_minus_H': p.median() - h.median(), 'MWU_p': u.pvalue}]).to_csv(os.path.join(DER, 'X7_patient_GDF15_group_test.csv'), index=False)
wide = neigh.pivot_table(index=['sample', 'patient', 'group', 'neighbor_type'], columns='anchor_status', values='neighbor_fraction').dropna().reset_index()
wide['difference_GDF15pos_minus_neg'] = wide['GDF15+'] - wide['GDF15-']
nw_patient = wide.groupby(['patient', 'group', 'neighbor_type'], as_index=False)['difference_GDF15pos_minus_neg'].mean()
nstat = []
for ct, q in nw_patient.groupby('neighbor_type', observed=True):
    x = q.difference_GDF15pos_minus_neg.dropna()
    w = stats.wilcoxon(x, alternative='two-sided') if len(x) >= 5 and np.any(x != 0) else None
    nstat.append({'neighbor_type': ct, 'n_patients': len(x), 'mean_difference': x.mean(), 'SEM': x.sem(), 'Wilcoxon_p': w.pvalue if w else np.nan})
nstat = pd.DataFrame(nstat)
nstat['Wilcoxon_FDR'] = bh_fdr(nstat.Wilcoxon_p)
nstat.to_csv(os.path.join(DER, 'X7_neighborhood_GDF15pos_vs_neg_stats.csv'), index=False)
rep = sample_summary.sort_values('n_GDF15pos_fibroblasts', ascending=False).groupby('group', as_index=False).first()
fig = plt.figure(figsize=(180 * MM, 145 * MM))
gs = fig.add_gridspec(2, 3, width_ratios=[1, 1, 0.72], left=0.12, right=0.98, bottom=0.09, top=0.9, wspace=0.32, hspace=0.38)
for j, group in enumerate(['Healthy', 'Periodontitis']):
    sample = rep.loc[rep.group == group, 'sample'].iloc[0]
    q = cells_all[cells_all['sample'] == sample]
    ax = fig.add_subplot(gs[0, j])
    ax.scatter(q.x, q.y, s=0.12, c='#D9D9D9', lw=0, rasterized=True)
    f = q[q.high_conf_fibroblast]
    ax.scatter(f.x, f.y, s=0.18, c='#9EC8C0', lw=0, rasterized=True)
    gp = f[f.GDF15_count > 0]
    ax.scatter(gp.x, gp.y, s=1.2, c='#6D4AA2', lw=0, rasterized=True)
    ax.set_aspect('equal')
    ax.invert_yaxis()
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_title(f'{group}: {sample}', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=.35'))
    ax.text(0.02, 0.03, f'purple: GDF15+ fibroblasts (n={len(gp):,})', transform=ax.transAxes, fontsize=6)
    fig.text(0.075 + j * 0.295, 0.94, chr(65 + j), fontsize=12, fontweight='bold')
ax = fig.add_subplot(gs[0, 2])
data = [h.to_numpy(), p.to_numpy()]
bp = ax.boxplot(data, positions=[0, 1], widths=0.55, patch_artist=True, showfliers=False, medianprops=dict(color='black', lw=0.8), boxprops=dict(lw=0.6), whiskerprops=dict(lw=0.6), capprops=dict(lw=0.6))
for patch, c in zip(bp['boxes'], [NPJ_CTRL, NPJ_CASE]):
    patch.set_facecolor(c)
    patch.set_alpha(0.78)
for x0, vals, c in [(0, data[0], NPJ_CTRL), (1, data[1], NPJ_CASE)]:
    ax.scatter(x0 + rng.uniform(-0.1, 0.1, len(vals)), vals, s=10, c=c, ec='black', lw=0.3, zorder=3)
ax.set_xticks([0, 1])
ax.set_xticklabels(['Healthy', 'PD'], rotation=25, ha='right')
ax.set_ylabel('GDF15+ fraction in fibroblasts')
ax.text(0.5, 0.98, f'MWU p={u.pvalue:.3g}', transform=ax.transAxes, ha='center', va='top', fontsize=6.5)
ax.set_title('Patient-level localization', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=.35'))
fig.text(0.69, 0.94, 'C', fontsize=12, fontweight='bold')
ax = fig.add_subplot(gs[1, :])
q = nstat.set_index('neighbor_type').reindex(BROAD_ORDER).dropna(subset=['mean_difference'])
y = np.arange(len(q))
ax.axvline(0, c='black', lw=0.5)
ax.errorbar(q.mean_difference, y, xerr=1.96 * q.SEM, fmt='o', ms=3.5, lw=0.8, c='#6D4AA2', ecolor='#6D4AA2', capsize=1.5)
ax.set_yticks(y)
ax.set_yticklabels(q.index)
ax.invert_yaxis()
ax.set_xlabel('Neighbour fraction difference (GDF15+ \u2212 GDF15\u2212 fibroblast anchors; 50 \xb5m)')
ax.set_title('Cellular neighbourhood around GDF15+ fibroblasts', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=.35'))
fig.text(0.075, 0.49, 'D', fontsize=12, fontweight='bold')
save_npj(fig, os.path.join(OUT, '\u7b2c7\u9879_\u7259\u9f88Xenium_GDF15\u7a7a\u95f4\u5b9a\u4f4d\u4e0e\u90bb\u57df_20260914'), 180, 145, 600)
print('REFERENCE ACCURACY', np.mean(ref_pred == truth))
print('FIBROBLAST SENSITIVITY', np.mean(ref_pred[truth == 'Fibroblast'] == 'Fibroblast'))
print('PATIENT TEST', {'median_H': h.median(), 'median_PD': p.median(), 'p': u.pvalue})
print(nstat.sort_values('Wilcoxon_FDR').to_string(index=False))
