$ProjectRoot = if ($env:SERUM_VITAMIN_PROJECT_ROOT) {
    $env:SERUM_VITAMIN_PROJECT_ROOT
} else {
    "E:\$([char]0x8840)$([char]0x6E05)$([char]0x7EF4)$([char]0x751F)$([char]0x7D20)"
}
$ArchiveRoot = if ($env:SERUM_VITAMIN_ARCHIVE_ROOT) {
    $env:SERUM_VITAMIN_ARCHIVE_ROOT
} else {
    "G:\$([char]0x8840)$([char]0x6E05)$([char]0x7EF4)$([char]0x751F)$([char]0x7D20)\E$([char]0x76D8)$([char]0x7CBE)$([char]0x7B80)$([char]0x5F52)$([char]0x6863)_20260908_v2\E$([char]0x76D8)$([char]0x539F)$([char]0x76F8)$([char]0x5BF9)$([char]0x7ED3)$([char]0x6784)"
}
$FinalSubmissionRoot = if ($env:SERUM_VITAMIN_FINAL_SUBMISSION_ROOT) {
    $env:SERUM_VITAMIN_FINAL_SUBMISSION_ROOT
} else {
    "C:\Users\Lin\Desktop\$([char]0x6700)$([char]0x7EC8)$([char]0x6295)$([char]0x7A3F)$([char]0x6587)$([char]0x672C)"
}

$RawDataRoot = Join-Path $ProjectRoot "$([char]0x539F)$([char]0x59CB)$([char]0x6570)$([char]0x636E)"
$CodeRoot = Join-Path $ProjectRoot "$([char]0x4EE3)$([char]0x7801)"
$FinalSourceTables = Join-Path $RawDataRoot "06_$([char]0x6700)$([char]0x7EC8)$([char]0x6295)$([char]0x7A3F)$([char]0x51FA)$([char]0x56FE)$([char]0x6E90)$([char]0x8868)"

$OutputRoot = if ($env:SERUM_VITAMIN_OUTPUT_ROOT) {
    $env:SERUM_VITAMIN_OUTPUT_ROOT
} else {
    Join-Path $CodeRoot "$([char]0x8FD0)$([char]0x884C)$([char]0x8F93)$([char]0x51FA)"
}
$TempOutputRoot = Join-Path $OutputRoot "_$([char]0x4E34)$([char]0x65F6)$([char]0x8FD0)$([char]0x884C)$([char]0x533A)"

$NhanesRaw = Join-Path $RawDataRoot "01_NHANES\NHANES$([char]0x539F)$([char]0x59CB)$([char]0x6570)$([char]0x636E)"
$XqtlAndReference = Join-Path $RawDataRoot "03_xQTL$([char]0x4E0E)$([char]0x53C2)$([char]0x8003)$([char]0x9762)$([char]0x677F)"
$BulkRnaRaw = Join-Path $RawDataRoot '04_Bulk_RNA'
$ScrnaRaw = Join-Path $RawDataRoot "05_$([char]0x5355)$([char]0x7EC6)$([char]0x80DE)RNA"

$PeriodontitisGwasArchive = Join-Path $ArchiveRoot "$([char]0x539F)$([char]0x59CB)$([char]0x6570)$([char]0x636E)\02_$([char]0x7259)$([char]0x5468)$([char]0x75C5)GWAS"
$PeriodontitisGwas = $PeriodontitisGwasArchive
$LegacyOutputRoot = Join-Path $ArchiveRoot "$([char]0x8F93)$([char]0x51FA)$([char]0x7ED3)$([char]0x679C)"
$RuntimeRoot = if ($env:SERUM_VITAMIN_RUNTIME_ROOT) {
    $env:SERUM_VITAMIN_RUNTIME_ROOT
} else {
    Join-Path $ArchiveRoot "$([char]0x4EE3)$([char]0x7801)\$([char]0x8FD0)$([char]0x884C)$([char]0x73AF)$([char]0x5883)"
}
