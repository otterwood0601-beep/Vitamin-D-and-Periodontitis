env_or <- function(name, default) {
  value <- Sys.getenv(name, unset = "")
  if (nzchar(value)) value else default
}

PROJECT_ROOT <- env_or("SERUM_VITAMIN_PROJECT_ROOT", "E:/\u8840\u6e05\u7ef4\u751f\u7d20")
ARCHIVE_ROOT <- env_or(
  "SERUM_VITAMIN_ARCHIVE_ROOT",
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784"
)
FINAL_SUBMISSION_ROOT <- env_or(
  "SERUM_VITAMIN_FINAL_SUBMISSION_ROOT",
  "C:/Users/Lin/Desktop/\u6700\u7ec8\u6295\u7a3f\u6587\u672c"
)

RAW_DATA_ROOT <- file.path(PROJECT_ROOT, "\u539f\u59cb\u6570\u636e")
CODE_ROOT <- file.path(PROJECT_ROOT, "\u4ee3\u7801")
FINAL_SOURCE_TABLES <- file.path(RAW_DATA_ROOT, "06_\u6700\u7ec8\u6295\u7a3f\u51fa\u56fe\u6e90\u8868")

OUTPUT_ROOT <- env_or(
  "SERUM_VITAMIN_OUTPUT_ROOT",
  file.path(CODE_ROOT, "\u8fd0\u884c\u8f93\u51fa")
)
TEMP_OUTPUT_ROOT <- file.path(OUTPUT_ROOT, "_\u4e34\u65f6\u8fd0\u884c\u533a")

NHANES_RAW <- file.path(RAW_DATA_ROOT, "01_NHANES", "NHANES\u539f\u59cb\u6570\u636e")
XQTL_AND_REFERENCE <- file.path(RAW_DATA_ROOT, "03_xQTL\u4e0e\u53c2\u8003\u9762\u677f")
BULK_RNA_RAW <- file.path(RAW_DATA_ROOT, "04_Bulk_RNA")
SCRNA_RAW <- file.path(RAW_DATA_ROOT, "05_\u5355\u7ec6\u80deRNA")

PERIODONTITIS_GWAS_ARCHIVE <- file.path(ARCHIVE_ROOT, "\u539f\u59cb\u6570\u636e", "02_\u7259\u5468\u75c5GWAS")
PERIODONTITIS_GWAS <- PERIODONTITIS_GWAS_ARCHIVE
LEGACY_OUTPUT_ROOT <- file.path(ARCHIVE_ROOT, "\u8f93\u51fa\u7ed3\u679c")
RUNTIME_ROOT <- env_or(
  "SERUM_VITAMIN_RUNTIME_ROOT",
  file.path(ARCHIVE_ROOT, "\u4ee3\u7801", "\u8fd0\u884c\u73af\u5883")
)
