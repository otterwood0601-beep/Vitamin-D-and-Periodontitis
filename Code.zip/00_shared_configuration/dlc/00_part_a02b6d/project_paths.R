if (.Platform$OS.type == "windows") {
  try(Sys.setlocale("LC_ALL", "Chinese (Simplified)_China.utf8"), silent = TRUE)
}

WORK    <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20D DLC"
SRC     <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20"                     
REF_DIR <- "C:/Users/Lin/Downloads"           

FB_RDS <- file.path(SRC, "\u539f\u59cb\u6570\u636e/05_\u5355\u7ec6\u80deRNA/\u6d3e\u751f\u8f93\u5165/GDF15_Figure1/input_fb",
                    "all_conditions_allStudies_CELLxGENE_direct_fibroblast_counts_only.rds")
CELL_MAP   <- file.path(SRC, "\u539f\u59cb\u6570\u636e/05_\u5355\u7ec6\u80deRNA/\u6d3e\u751f\u8f93\u5165/GDF15_Figure1", "cell_cluster_mapping.csv.gz")
FIVE_MAP   <- file.path(SRC, "\u539f\u59cb\u6570\u636e/05_\u5355\u7ec6\u80deRNA/\u6d3e\u751f\u8f93\u5165/GDF15_Figure1", "five_type_merge_mapping.csv")
GMT_DIR    <- file.path(SRC, "\u539f\u59cb\u6570\u636e/05_\u5355\u7ec6\u80deRNA/gene_sets")
GMT_GO_BP  <- file.path(GMT_DIR, "GO_Biological_Process_2025.gmt")
GMT_HALL   <- file.path(GMT_DIR, "MSigDB_Hallmark_2020.gmt")
GMT_REAC   <- file.path(GMT_DIR, "Reactome_Pathways_2024.gmt")

FIG4_SD <- file.path(SRC, "\u539f\u59cb\u6570\u636e/06_\u6700\u7ec8\u6295\u7a3f\u51fa\u56fe\u6e90\u8868/04_\u6b63\u6587\u56fe4_scRNA/20260907_\u6b63\u6587\u56fe4\u7ec8\u7a3f/02_source_data")
CELL_UMAP_GZ <- file.path(FIG4_SD, "01_cell_metadata_UMAP_GDF15.csv.gz")
DE_DONOR_GZ  <- file.path(FIG4_SD, "03_donor_pseudobulk_DE_periodontitis_vs_healthy.csv.gz")

DESEQ_ALL <- file.path(SRC, "\u539f\u59cb\u6570\u636e/06_\u6700\u7ec8\u6295\u7a3f\u51fa\u56fe\u6e90\u8868/03_\u6b63\u6587\u56fe3_SMR\u4e0eBulkRNA/BulkRNA/02_DESeq2_genome",
                       "11_DESeq2_D3_vs_ethanol_all_genes.csv")

R_LIBS <- c("C:/Users/Lin/R/win-library/4.5",
            "C:/Users/Lin/AppData/Local/R/win-library/4.5",
            "C:/Program Files/R/R-4.5.3/library")
.libPaths(R_LIBS)

FIVE_ORDER <- c("Immune-associated fibroblasts",
                "ECM remodeling-associated fibroblasts",
                "Vascular-associated fibroblasts",
                "Pre-extracellular matrix-associated fibroblasts",
                "Matrix homeostasis-associated fibroblasts")
FIVE_SHORT <- c("Immune-associated fibroblasts"          = "Immune",
                "ECM remodeling-associated fibroblasts"   = "ECM remodeling",
                "Vascular-associated fibroblasts"         = "Vascular",
                "Pre-extracellular matrix-associated fibroblasts" = "Pre-ECM",
                "Matrix homeostasis-associated fibroblasts" = "Matrix homeostasis")
FIVE_HEX <- c("Immune-associated fibroblasts"            = "#398AF6",
              "ECM remodeling-associated fibroblasts"    = "#2AAC4A",
              "Vascular-associated fibroblasts"          = "#E9A34D",
              "Pre-extracellular matrix-associated fibroblasts" = "#A892FF",
              "Matrix homeostasis-associated fibroblasts" = "#FF79B8")

THEME_NPJ <- ggplot2::theme_classic(base_size = 8, base_family = "sans") +
  ggplot2::theme(
    axis.title      = ggplot2::element_text(size = 8),
    axis.text       = ggplot2::element_text(size = 7, colour = "black"),
    axis.line       = ggplot2::element_line(linewidth = 0.4, colour = "black"),
    axis.ticks      = ggplot2::element_line(linewidth = 0.4),
    legend.title    = ggplot2::element_text(size = 7),
    legend.text     = ggplot2::element_text(size = 6.5),
    plot.title      = ggplot2::element_text(size = 8, face = "bold"),
    strip.background = ggplot2::element_blank(),
    strip.text      = ggplot2::element_text(size = 8, face = "bold.italic"),
    panel.grid      = ggplot2::element_blank()
  )

DISEASE_HEX <- c("normal" = "#3F9B8C", "periodontitis" = "#D9534F")
DISEASE_LAB <- c("normal" = "Healthy", "periodontitis" = "Periodontitis")

SEG_FIGDIR <- function(proj) file.path(WORK, proj, "outputs", "figures")
SEG_SRC    <- function(proj) file.path(WORK, proj, "outputs", "02_source_data")
SEG_QA     <- function(proj) file.path(WORK, proj, "outputs", "03_QA")

ensure_dirs <- function(proj) {
  for (d in c(SEG_FIGDIR(proj), SEG_SRC(proj), SEG_QA(proj)))
    dir.create(d, recursive = TRUE, showWarnings = FALSE)
  invisible(NULL)
}

cat("[project_paths] loaded:", format(Sys.time()), "\n")
