from __future__ import annotations
import numpy as np
import pandas as pd
from scipy import sparse
H5AD = 'C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u8865\u5145\u56fe\\\u3010\u5f85\u5b9a\u3011SCENIC\\1.\u6e90\u6570\u636e\\01_\u539f\u59cb\u8f93\u5165\\01_CELLxGENE\u6574\u5408\u7259\u5468\u56fe\u8c31\\Integrated_Human_Periodontitis_Atlas_105918cells.h5ad'
BROAD_ORDER = ['Fibroblast', 'Epithelial', 'Endothelial', 'Mural', 'T/NK', 'B/Plasma', 'Myeloid/DC', 'Neutrophil', 'Mast', 'Neural/Melanocyte']
CURATED = {'Fibroblast': ['COL1A1', 'COL1A2', 'COL3A1', 'DCN', 'LUM', 'PDGFRA', 'SFRP2', 'COL6A1'], 'Epithelial': ['EPCAM', 'KRT5', 'KRT14', 'KRT17', 'KRT19', 'KRT4', 'KRT13', 'SFN'], 'Endothelial': ['PECAM1', 'VWF', 'KDR', 'EMCN', 'ACKR1', 'PLVAP', 'CLDN5', 'RAMP2'], 'Mural': ['ACTA2', 'RGS5', 'MCAM', 'CSPG4', 'NOTCH3', 'MYH11', 'KCNJ8', 'ABCC9'], 'T/NK': ['CD3D', 'CD3E', 'TRBC1', 'TRBC2', 'IL7R', 'NKG7', 'KLRD1', 'CCL5'], 'B/Plasma': ['MS4A1', 'CD79A', 'CD37', 'CD74', 'MZB1', 'JCHAIN', 'SDC1', 'IGHG1'], 'Myeloid/DC': ['LYZ', 'FCER1G', 'CTSS', 'CD68', 'TYROBP', 'LST1', 'FCGR2A', 'CLEC10A'], 'Neutrophil': ['FCGR3B', 'CSF3R', 'CXCR2', 'S100A8', 'S100A9', 'MNDA', 'FPR1', 'SELL'], 'Mast': ['TPSAB1', 'TPSB2', 'KIT', 'CPA3', 'MS4A2', 'HDC', 'HPGDS', 'GATA2'], 'Neural/Melanocyte': ['S100B', 'SOX10', 'PLP1', 'SLC1A3', 'PMEL', 'MLANA', 'DCT', 'TYR']}

def broad_cell_type(cell_type: str) -> str:
    x = str(cell_type).lower()
    if x == 'fibroblast':
        return 'Fibroblast'
    if 'keratinocyte' in x or x == 'merkel cell':
        return 'Epithelial'
    if 'endothelial' in x:
        return 'Endothelial'
    if 'pericyte' in x or 'smooth muscle' in x:
        return 'Mural'
    if x == 'mast cell':
        return 'Mast'
    if 't cell' in x or 't-helper' in x or 'natural killer' in x or ('nk t' in x) or ('gamma-delta' in x) or ('regulatory t' in x) or ('mucosal-associated' in x):
        return 'T/NK'
    if x in {'b cell', 'plasma cell'}:
        return 'B/Plasma'
    if 'macrophage' in x or 'dendritic' in x or 'langerhans' in x:
        return 'Myeloid/DC'
    if x == 'neutrophil':
        return 'Neutrophil'
    if x in {'schwann cell', 'melanocyte'}:
        return 'Neural/Melanocyte'
    return 'Other'

def load_reference(panel_genes: list[str]):
    import anndata as ad
    a = ad.read_h5ad(H5AD, backed='r')
    var = a.var.reset_index().rename(columns={a.var.index.name or 'index': 'ensembl'})
    if 'ensembl' not in var.columns:
        var = var.rename(columns={var.columns[0]: 'ensembl'})
    var['symbol'] = var['feature_name'].astype(str)
    var = var.drop_duplicates('symbol')
    want = var[var['symbol'].isin(set(panel_genes))].copy().sort_values('symbol')
    idx = want.index.to_numpy()
    genes = want['symbol'].tolist()
    X = a.X[:, idx]
    if not sparse.issparse(X):
        X = sparse.csr_matrix(X)
    else:
        X = X.tocsr()
    obs = a.obs[['cell_type', 'donor_id', 'disease', 'tissue']].copy()
    a.file.close()
    if set(obs['tissue'].astype(str)) != {'gingiva'}:
        raise ValueError('Reference contains non-gingiva tissue; aborting.')
    obs['broad_type'] = obs['cell_type'].map(broad_cell_type)
    keep = obs['broad_type'].isin(BROAD_ORDER).to_numpy()
    return (X[keep], obs.loc[keep].reset_index(drop=True), genes)

def row_log_normalize(X, target_sum: float=10000.0):
    X = X.tocsr().astype(np.float32)
    lib = np.asarray(X.sum(axis=1)).ravel()
    scale = target_sum / np.maximum(lib, 1.0)
    Y = sparse.diags(scale).dot(X).tocsr()
    Y.data = np.log1p(Y.data)
    return Y

def class_means(X, labels: pd.Series, classes=BROAD_ORDER):
    rows = []
    for c in classes:
        ii = np.flatnonzero(labels.to_numpy() == c)
        rows.append(np.asarray(X[ii].mean(axis=0)).ravel())
    return np.vstack(rows)

def derive_markers(X_ref, obs: pd.DataFrame, genes: list[str], top_n: int=10):
    means = class_means(X_ref, obs['broad_type'])
    det = []
    for c in BROAD_ORDER:
        ii = np.flatnonzero(obs['broad_type'].to_numpy() == c)
        det.append(np.asarray((X_ref[ii] > 0).mean(axis=0)).ravel())
    det = np.vstack(det)
    g2i = {g: i for i, g in enumerate(genes)}
    markers = {}
    audit = []
    for k, c in enumerate(BROAD_ORDER):
        other_max = np.max(np.delete(means, k, axis=0), axis=0)
        spec = means[k] - other_max
        order = np.argsort(spec)[::-1]
        derived = [genes[j] for j in order if spec[j] > 0 and det[k, j] >= 0.03][:top_n]
        canonical = [g for g in CURATED[c] if g in g2i]
        chosen = list(dict.fromkeys(canonical + derived))
        markers[c] = chosen
        for g in chosen:
            j = g2i[g]
            audit.append({'broad_type': c, 'gene': g, 'source': 'curated' if g in canonical else 'reference-derived', 'mean_reference': means[k, j], 'detection_reference': det[k, j], 'specificity_vs_best_other': spec[j]})
    return (markers, pd.DataFrame(audit), means)

def marker_score_matrix(X, genes: list[str], markers: dict[str, list[str]]):
    g2i = {g: i for i, g in enumerate(genes)}
    W = np.zeros((len(genes), len(BROAD_ORDER)), dtype=np.float32)
    for k, c in enumerate(BROAD_ORDER):
        ids = [g2i[g] for g in markers[c] if g in g2i]
        if ids:
            W[ids, k] = 1.0 / len(ids)
    return np.asarray(X.dot(W))

def bh_fdr(p):
    p = np.asarray(p, float)
    order = np.argsort(np.nan_to_num(p, nan=np.inf))
    out = np.full(len(p), np.nan)
    ok = np.isfinite(p[order])
    idx = order[ok]
    n = len(idx)
    if n:
        q = p[idx] * n / np.arange(1, n + 1)
        q = np.minimum.accumulate(q[::-1])[::-1]
        out[idx] = np.minimum(q, 1)
    return out
