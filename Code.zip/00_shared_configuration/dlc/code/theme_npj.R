suppressPackageStartupMessages({library(ggplot2); library(grid)})

npj_pal_discrete <- c("#7E5AA7", "#E6862E", "#3FA796", "#C9403B", "#4A8FD4",
                      "#E5C832", "#D67BA6", "#8AA87E", "#6BB7D6", "#B0793C",
                      "#5CB85C", "#9467BD")
npj_col_group   <- c("case" = "#C9403B", "control" = "#3FA796")  
npj_col_feature <- c("#D9D9D9", "#6A51A3")                        
npj_col_dotplot <- c("#F7F7F7", "#54278F")                        
npj_col_div     <- c("#2166AC", "#F7F7F7", "#B2182B")             
npj_col_roe     <- c("#FFFFFF", "#FFF5F0", "#FEE0D2", "#FCBBA1",
                     "#FC9272", "#FB6A4A", "#EF3B2C", "#CB181D", "#99000D")

theme_npj_base <- theme_bw(base_size = 8, base_family = "sans") +
  theme(
    panel.grid       = element_blank(),
    panel.border     = element_rect(colour = "black", linewidth = 0.5),
    axis.text        = element_text(size = 7, colour = "black"),
    axis.title       = element_text(size = 8, colour = "black"),
    legend.text      = element_text(size = 7),
    legend.title     = element_text(size = 7, face = "bold"),
    legend.key.size  = unit(3.5, "mm"),
    plot.title       = element_text(size = 9, face = "bold", hjust = 0.5),
    strip.background = element_rect(fill = "#E4E6EB", colour = NA),
    strip.text       = element_text(size = 8, face = "bold", colour = "black",
                                    margin = margin(2, 4, 2, 4)),
    plot.margin      = margin(4, 4, 4, 4)
  )

theme_npj_umap <- theme_npj_base +
  theme(axis.line  = element_line(colour = "black", linewidth = 0.5),
        panel.border = element_blank(),
        axis.text  = element_blank(), axis.ticks = element_blank(),
        axis.title = element_text(size = 7, hjust = 0),
        aspect.ratio = 1)

theme_npj_tag <- theme(plot.tag = element_text(size = 12, face = "bold", family = "sans"),
                       plot.tag.position = c(0, 1))

npj_ggsave <- function(plot, file, width_mm = 180, height_mm = 180, dpi = 600) {
  ggsave(paste0(file, ".pdf"), plot, width = width_mm, height = height_mm,
         units = "mm", device = cairo_pdf)
  ggsave(paste0(file, ".png"), plot, width = width_mm, height = height_mm,
         units = "mm", dpi = dpi, bg = "white")
}
