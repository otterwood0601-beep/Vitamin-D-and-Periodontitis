import matplotlib as mpl
import matplotlib.pyplot as plt
NPJ_DISCRETE = ['#7E5AA7', '#E6862E', '#3FA796', '#C9403B', '#4A8FD4', '#E5C832', '#D67BA6', '#8AA87E', '#6BB7D6', '#B0793C', '#5CB85C', '#9467BD']
NPJ_CASE, NPJ_CTRL = ('#C9403B', '#3FA796')
NPJ_CMAP_FEATURE = 'Purples'
NPJ_CMAP_DIV = 'RdBu_r'
NPJ_CMAP_ROE = 'Reds'
MM = 1 / 25.4
FIGW = 180 * MM

def set_npj_style():
    mpl.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Arial', 'Liberation Sans', 'DejaVu Sans'], 'font.size': 7, 'axes.titlesize': 8, 'axes.titleweight': 'bold', 'axes.labelsize': 8, 'xtick.labelsize': 7, 'ytick.labelsize': 7, 'legend.fontsize': 7, 'legend.title_fontsize': 7, 'axes.linewidth': 0.5, 'axes.edgecolor': 'black', 'axes.grid': False, 'figure.facecolor': 'white', 'axes.facecolor': 'white', 'savefig.facecolor': 'white', 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none'})

def panel_label(ax, label, x=-0.08, y=1.04):
    ax.text(x, y, label, transform=ax.transAxes, fontsize=12, fontweight='bold', va='bottom', ha='left')

def strip_header(ax, text):
    ax.set_title(text, fontsize=8, fontweight='bold', pad=6)
    ax.title.set_bbox(dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=0.35'))

def save_npj(fig, path_stem, width_mm=180, height_mm=180, dpi=600):
    fig.set_size_inches(width_mm * MM, height_mm * MM)
    fig.savefig(path_stem + '.pdf')
    fig.savefig(path_stem + '.png', dpi=dpi)
