from __future__ import annotations
from pathlib import Path
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D
SOURCE_ALL = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260804-\u7259\u5468\u75c5OpenGWAS\u65b0\u589e\u4e0e\u65e2\u5f80\u5408\u5e76-SMR_HEIDI-Figure1\\04_results\\13_combined_previous_plus_new_SMR_HEIDI_all_results.csv')
SOURCE_SELECTED = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260805-11\u5019\u9009\u57fa\u56e0-\u7259\u5468\u75c5GWAS-\u65b0\u65e7\u5408\u5e76-SMR_HEIDI-Figure1\\04_results\\02_11candidate_combined_all_results_recalculated.csv')
SOURCE_FIGURE = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u6b63\u6587\u56fe\\\u6b63\u6587\u56fe3 SMR\u548cBulk-RNA\\A.SMR\u7ed3\u679c\u56fe.pdf')
OUT_DIR = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u6b63\u6587\u56fe\\\u6b63\u6587\u56fe3 SMR\u548cBulk-RNA\\A_SMR\u6563\u70b9\u56fe_GDF15_PLAU_\u4e0d\u8986\u76d6\u539f\u56fe_20260825')
OUT_PDF = OUT_DIR / 'A_SMR\u6563\u70b9\u56fe_GDF15_PLAU_\u4e25\u683c\u53c2\u8003\u7248_20260825.pdf'
OUT_PNG = OUT_DIR / 'A_SMR\u6563\u70b9\u56fe_GDF15_PLAU_\u4e25\u683c\u53c2\u8003\u7248_20260825.png'
OUT_ALL = OUT_DIR / 'A_SMR\u6563\u70b9\u56fe_\u5168\u90e8\u7ed8\u56fe\u6e90\u6570\u636e_20260825.csv'
OUT_LABELS = OUT_DIR / 'A_SMR\u6563\u70b9\u56fe_GDF15_PLAU\u6807\u6ce8\u6e90\u6570\u636e_20260825.csv'
OUT_PANEL_SOURCE = OUT_DIR / 'A_SMR\u6e90\u56fe\u4e09\u6761\u8bb0\u5f55_20260825.csv'
OUT_README = OUT_DIR / 'README_\u6e90\u6587\u4ef6\u4e0e\u7ed8\u56fe\u89c4\u5219.txt'
COLORS = {'Whole blood': '#22B2BC', 'Cultured fibroblasts': '#76C7BE', 'Plasma': '#234EA5'}

def classify_qtl(row: pd.Series) -> str:
    tissue = str(row.get('tissue', ''))
    qtl = str(row.get('qtl_display_base', ''))
    if 'Plasma' in tissue or 'plasma' in qtl.lower():
        return 'Plasma'
    if 'fibroblast' in tissue.lower() or 'fibroblast' in qtl.lower():
        return 'Cultured fibroblasts'
    return 'Whole blood'

def load_data() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    if not SOURCE_ALL.exists():
        raise FileNotFoundError(SOURCE_ALL)
    if not SOURCE_FIGURE.exists():
        raise FileNotFoundError(SOURCE_FIGURE)
    if not SOURCE_SELECTED.exists():
        raise FileNotFoundError(SOURCE_SELECTED)
    frame = pd.read_csv(SOURCE_ALL, low_memory=False)
    for column in ('b_SMR', 'p_SMR', 'p_HEIDI'):
        frame[column] = pd.to_numeric(frame[column], errors='coerce')
    frame = frame.loc[frame['b_SMR'].notna() & frame['p_SMR'].notna() & frame['p_SMR'].gt(0) & frame['p_SMR'].le(1)].copy()
    frame['minus_log10_p_SMR'] = -np.log10(frame['p_SMR'])
    frame['qtl_plot_group'] = frame.apply(classify_qtl, axis=1)
    frame['display_gene'] = frame['gene'].astype(str)
    legacy_plau = frame['probeID'].astype(str).eq('cg01951477') & frame['outcome_id'].astype(str).eq('OGWAS_UKB_MRCIEU_bleeding_gums')
    frame.loc[legacy_plau, 'display_gene'] = 'PLAU'
    frame['candidate_highlight'] = frame['display_gene'].isin(['GDF15', 'PLAU'])
    frame['shown_within_axes'] = frame['b_SMR'].between(-0.8, 0.8)
    selected = pd.read_csv(SOURCE_SELECTED, low_memory=False)
    for column in ('b_SMR', 'p_SMR', 'p_HEIDI'):
        selected[column] = pd.to_numeric(selected[column], errors='coerce')
    selected['minus_log10_p_SMR'] = -np.log10(selected['p_SMR'])
    selected['qtl_plot_group'] = selected.apply(classify_qtl, axis=1)
    selected['display_gene'] = selected['gene'].astype(str)
    selected_legacy_plau = selected['probeID'].astype(str).eq('cg01951477') & selected['outcome_id'].astype(str).eq('OGWAS_UKB_MRCIEU_bleeding_gums')
    selected.loc[selected_legacy_plau, 'display_gene'] = 'PLAU'
    panel_source_mask = selected['display_gene'].eq('GDF15') & selected['outcome_id'].astype(str).eq('OGWAS_UKB_Neale_bleeding_gums') & selected['probeID'].astype(str).eq('cg21088460') | selected['display_gene'].eq('GDF15') & selected['outcome_id'].astype(str).eq('OGWAS_UKB_MRCIEU_bleeding_gums') & selected['panel_id'].astype(str).eq('pQTL_INTERVAL_chr19') | selected_legacy_plau
    panel_source = selected.loc[panel_source_mask].copy()
    if len(panel_source) != 3:
        raise RuntimeError(f'Expected exactly three A-panel source records, got {len(panel_source)}')
    panel_source['source_figure_display_gene'] = panel_source['display_gene']
    gdf15_anchor = panel_source.loc[panel_source['display_gene'].eq('GDF15') & panel_source['outcome_id'].astype(str).eq('OGWAS_UKB_Neale_bleeding_gums')].copy()
    plau_anchor = panel_source.loc[panel_source['display_gene'].eq('PLAU')].copy()
    if len(gdf15_anchor) != 1 or len(plau_anchor) != 1:
        raise RuntimeError(f'Expected one label anchor per gene; GDF15={len(gdf15_anchor)}, PLAU={len(plau_anchor)}')
    labels = pd.concat([gdf15_anchor, plau_anchor], ignore_index=True)
    labels['label'] = ['GDF15', 'PLAU']
    frame.to_csv(OUT_ALL, index=False, encoding='utf-8-sig')
    labels.to_csv(OUT_LABELS, index=False, encoding='utf-8-sig')
    panel_source.to_csv(OUT_PANEL_SOURCE, index=False, encoding='utf-8-sig')
    return (frame, labels, panel_source)

def make_plot(frame: pd.DataFrame, labels: pd.DataFrame) -> None:
    mpl.rcParams.update({'font.family': 'Arial', 'font.size': 14, 'axes.labelsize': 18, 'xtick.labelsize': 14, 'ytick.labelsize': 14, 'legend.fontsize': 13, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'axes.unicode_minus': True})
    fig, ax = plt.subplots(figsize=(12.6, 8.3), facecolor='white')
    fig.subplots_adjust(left=0.105, right=0.74, bottom=0.13, top=0.965)
    visible = frame.loc[frame['shown_within_axes']].copy()
    background = visible.loc[~visible['candidate_highlight']]
    ax.scatter(background['b_SMR'], background['minus_log10_p_SMR'], s=42, c='#DADADA', alpha=0.36, linewidths=0, zorder=1)
    highlighted = visible.loc[visible['candidate_highlight']].copy()
    for group in ('Whole blood', 'Cultured fibroblasts', 'Plasma'):
        part = highlighted.loc[highlighted['qtl_plot_group'].eq(group)]
        ax.scatter(part['b_SMR'], part['minus_log10_p_SMR'], s=38, c=COLORS[group], alpha=0.92, linewidths=0, zorder=3)
    for _, row in labels.iterrows():
        ax.scatter([row['b_SMR']], [row['minus_log10_p_SMR']], s=58, c=COLORS[row['qtl_plot_group']], edgecolors='#303030', linewidths=1.2, zorder=6)
    label_positions = {'GDF15': (-0.18, 2.88), 'PLAU': (0.18, 2.13)}
    label_fills = {'GDF15': '#9BD5CB', 'PLAU': '#29B9C4'}
    for _, row in labels.iterrows():
        label = row['label']
        tx, ty = label_positions[label]
        ax.annotate(label, xy=(row['b_SMR'], row['minus_log10_p_SMR']), xytext=(tx, ty), ha='center', va='center', fontsize=17, color='#111111', bbox=dict(boxstyle='round,pad=0.22', facecolor=label_fills[label], edgecolor='#222222', linewidth=1.5), arrowprops=dict(arrowstyle='-', color='#2B2B2B', linewidth=1.4, shrinkA=0, shrinkB=4), zorder=7)
    threshold_y = -np.log10(0.05)
    ax.axvline(0, color='#3F3F3F', linestyle=(0, (3, 3)), linewidth=1.35, zorder=2)
    ax.axhline(threshold_y, color='#3F3F3F', linestyle=(0, (3, 3)), linewidth=1.35, zorder=2)
    ax.text(-0.72, threshold_y + 0.22, 'p_SMR = 0.05', fontsize=14, color='#303030')
    ax.set_xlim(-0.82, 0.82)
    ax.set_ylim(-0.3, 6.3)
    ax.set_xticks(np.arange(-0.75, 0.751, 0.25))
    ax.set_yticks([0, 2, 4, 6])
    ax.set_xlabel('\u03b2_SMR')
    ax.set_ylabel('\u2212log10(p_SMR value)')
    ax.grid(False)
    ax.tick_params(direction='out', width=1.15, length=5, color='#3A3A3A')
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_color('#555555')
        spine.set_linewidth(1.15)
    handles = [Line2D([0], [0], marker='o', linestyle='none', markerfacecolor=COLORS[group], markeredgecolor='none', markersize=7.5, label=group) for group in ('Whole blood', 'Cultured fibroblasts', 'Plasma')]
    legend = ax.legend(handles=handles, title='Candidate-gene QTL sources', loc='center left', bbox_to_anchor=(1.025, 0.5), frameon=False, borderaxespad=0, handletextpad=0.7, labelspacing=1.0)
    legend._legend_box.align = 'left'
    plt.setp(legend.get_title(), fontsize=16)
    fig.savefig(OUT_PDF, dpi=300, facecolor='white')
    fig.savefig(OUT_PNG, dpi=300, facecolor='white')
    plt.close(fig)

def write_readme(frame: pd.DataFrame, labels: pd.DataFrame, panel_source: pd.DataFrame) -> None:
    source_rows = panel_source[['source_figure_display_gene', 'gene', 'probeID', 'outcome_id', 'qtl_display_base', 'b_SMR', 'p_SMR', 'p_HEIDI']].to_string(index=False)
    text = f"Source figure (read-only):\n{SOURCE_FIGURE}\n\nAll-point SMR source table (read-only):\n{SOURCE_ALL}\n\nThree displayed A-panel records (read-only source table):\n{SOURCE_SELECTED}\n\nRows loaded: {len(frame)}\nRows shown inside x-axis range: {int(frame['shown_within_axes'].sum())}\nHighlighted associations: {int(frame['candidate_highlight'].sum())}\n\nLabel anchors:\n{source_rows}\n\nPlot rules:\n- x = b_SMR; y = -log10(p_SMR)\n- vertical dashed line: b_SMR = 0\n- horizontal dashed line: p_SMR = 0.05\n- light grey: non-highlighted SMR associations\n- colored points: GDF15/PLAU candidate-gene associations, grouped by QTL source\n- output does not overwrite the supplied A-panel PDF\n\nAudit note:\nThe supplied A-panel PDF labels probe cg01951477 as PLAU. In the current combined\nsource table, the same probe/outcome row is mapped in the gene column to TG. To\nstrictly reproduce the supplied A-panel labels, the plotted display label is kept\nas PLAU; the original source-table gene value remains preserved in the exported\naudit CSV.\n"
    OUT_README.write_text(text, encoding='utf-8')

def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    frame, labels, panel_source = load_data()
    make_plot(frame, labels)
    write_readme(frame, labels, panel_source)
    print(OUT_PDF)
    print(OUT_PNG)
    print(OUT_ALL)
    print(OUT_LABELS)
    print(OUT_PANEL_SOURCE)
if __name__ == '__main__':
    main()
