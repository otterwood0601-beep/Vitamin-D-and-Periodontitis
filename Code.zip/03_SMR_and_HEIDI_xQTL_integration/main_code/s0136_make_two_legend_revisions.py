from __future__ import annotations
from pathlib import Path
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D
SOURCE_ALL = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260804-\u7259\u5468\u75c5OpenGWAS\u65b0\u589e\u4e0e\u65e2\u5f80\u5408\u5e76-SMR_HEIDI-Figure1\\04_results\\13_combined_previous_plus_new_SMR_HEIDI_all_results.csv')
SOURCE_SELECTED = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260805-11\u5019\u9009\u57fa\u56e0-\u7259\u5468\u75c5GWAS-\u65b0\u65e7\u5408\u5e76-SMR_HEIDI-Figure1\\04_results\\02_11candidate_combined_all_results_recalculated.csv')
OUT_DIR = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u6b63\u6587\u56fe\\\u6b63\u6587\u56fe3 SMR\u548cBulk-RNA\\A_SMR\u6563\u70b9\u56fe_\u56fe\u4f8b\u4fee\u6539\u4e24\u7248_\u4e0d\u8986\u76d6_20260825')
V1_STEM = 'A_SMR\u6563\u70b9\u56fe_\u8840\u6db2\u8840\u6d46\u5408\u5e76_\u6210\u7ea4\u7ef4\u7ec6\u80de\u6df1\u84dd_\u56fe\u4f8b\u5185\u79fb_20260825'
V2_STEM = 'A_SMR\u6563\u70b9\u56fe_QTL_GTEx\u660e\u786e\u5206\u7c7b_\u56fe\u4f8b\u5185\u79fb_20260825'
TEAL = '#22B2BC'
LIGHT_TEAL = '#76C7BE'
BLUE = '#234EA5'
GREY = '#DADADA'

def strict_source_group(row: pd.Series) -> str | None:
    tissue = str(row.get('tissue', '')).lower()
    qtl = str(row.get('qtl_display_base', '')).lower()
    source = str(row.get('qtl_source', '')).lower()
    panel = str(row.get('panel_id', '')).lower()
    all_text = ' '.join((tissue, qtl, source, panel))
    if 'plasma' in all_text or 'interval' in all_text or 'scallop' in all_text:
        return 'Plasma pQTL'
    if 'fibroblast' in all_text and 'gtex' in all_text:
        return 'Fibroblast GTEx'
    if 'whole blood' in all_text or 'whole-blood' in all_text:
        return 'Blood QTL'
    return None

def load_data() -> tuple[pd.DataFrame, pd.DataFrame]:
    frame = pd.read_csv(SOURCE_ALL, low_memory=False)
    selected = pd.read_csv(SOURCE_SELECTED, low_memory=False)
    for table in (frame, selected):
        for column in ('b_SMR', 'p_SMR', 'p_HEIDI'):
            table[column] = pd.to_numeric(table[column], errors='coerce')
        table.dropna(subset=['b_SMR', 'p_SMR'], inplace=True)
        table.drop(table.loc[~table['p_SMR'].between(0, 1, inclusive='right')].index, inplace=True)
        table['minus_log10_p_SMR'] = -np.log10(table['p_SMR'])
        table['display_gene'] = table['gene'].astype(str)
        legacy_plau = table['probeID'].astype(str).eq('cg01951477') & table['outcome_id'].astype(str).eq('OGWAS_UKB_MRCIEU_bleeding_gums')
        table.loc[legacy_plau, 'display_gene'] = 'PLAU'
        table['source_group'] = table.apply(strict_source_group, axis=1)
        table['candidate_highlight'] = table['display_gene'].isin(['GDF15', 'PLAU'])
        table['shown_within_axes'] = table['b_SMR'].between(-0.8, 0.8)
    anchor_mask = selected['display_gene'].eq('GDF15') & selected['outcome_id'].astype(str).eq('OGWAS_UKB_Neale_bleeding_gums') & selected['probeID'].astype(str).eq('cg21088460') | selected['display_gene'].eq('PLAU') & selected['probeID'].astype(str).eq('cg01951477') & selected['outcome_id'].astype(str).eq('OGWAS_UKB_MRCIEU_bleeding_gums')
    labels = selected.loc[anchor_mask].copy()
    if len(labels) != 2:
        raise RuntimeError(f'Expected two annotation anchors, got {len(labels)}')
    labels['label'] = labels['display_gene']
    return (frame, labels)

def base_axes() -> tuple[plt.Figure, plt.Axes]:
    mpl.rcParams.update({'font.family': 'Arial', 'font.size': 14, 'axes.labelsize': 18, 'xtick.labelsize': 14, 'ytick.labelsize': 14, 'legend.fontsize': 12.5, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'axes.unicode_minus': True})
    fig, ax = plt.subplots(figsize=(9.5, 8.1), facecolor='white')
    fig.subplots_adjust(left=0.115, right=0.985, bottom=0.12, top=0.985)
    ax.set_xlim(-0.82, 0.82)
    ax.set_ylim(-0.3, 6.3)
    ax.set_xticks(np.arange(-0.75, 0.751, 0.25))
    ax.set_yticks([0, 2, 4, 6])
    ax.set_xlabel('\u03b2_SMR')
    ax.set_ylabel('\u2212log10(p_SMR value)')
    ax.grid(False)
    ax.tick_params(direction='out', width=1.15, length=5, color='#3A3A3A')
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_color('#555555')
        spine.set_linewidth(1.15)
    return (fig, ax)

def draw_common(ax: plt.Axes, frame: pd.DataFrame) -> pd.DataFrame:
    visible = frame.loc[frame['shown_within_axes']].copy()
    background = visible.loc[~visible['candidate_highlight'] | visible['source_group'].isna()]
    ax.scatter(background['b_SMR'], background['minus_log10_p_SMR'], s=42, c=GREY, alpha=0.36, linewidths=0, zorder=1)
    threshold_y = -np.log10(0.05)
    ax.axvline(0, color='#3F3F3F', linestyle=(0, (3, 3)), linewidth=1.35, zorder=2)
    ax.axhline(threshold_y, color='#3F3F3F', linestyle=(0, (3, 3)), linewidth=1.35, zorder=2)
    ax.text(-0.72, threshold_y + 0.22, 'p_SMR = 0.05', fontsize=14, color='#303030')
    return visible

def draw_annotations(ax: plt.Axes, labels: pd.DataFrame, color_for_group: dict[str, str], positions: dict[str, tuple[float, float]] | None=None) -> None:
    if positions is None:
        positions = {'GDF15': (-0.18, 2.88), 'PLAU': (0.18, 2.13)}
    fills = {'GDF15': '#9BD5CB', 'PLAU': '#29B9C4'}
    for _, row in labels.iterrows():
        color = color_for_group.get(str(row['source_group']), TEAL)
        ax.scatter([row['b_SMR']], [row['minus_log10_p_SMR']], s=58, c=color, edgecolors='#303030', linewidths=1.2, zorder=6)
        tx, ty = positions[row['label']]
        ax.annotate(row['label'], xy=(row['b_SMR'], row['minus_log10_p_SMR']), xytext=(tx, ty), ha='center', va='center', fontsize=17, color='#111111', bbox=dict(boxstyle='round,pad=0.22', facecolor=fills[row['label']], edgecolor='#222222', linewidth=1.5), arrowprops=dict(arrowstyle='-', color='#2B2B2B', linewidth=1.4, shrinkA=0, shrinkB=4), zorder=7)

def add_legend(ax: plt.Axes, categories: list[tuple[str, str]]) -> None:
    handles = [Line2D([0], [0], marker='o', linestyle='none', markerfacecolor=color, markeredgecolor='none', markersize=7.5, label=label) for label, color in categories]
    legend = ax.legend(handles=handles, title='Vitamin D related genes', loc='upper left', bbox_to_anchor=(0.045, 0.965), frameon=False, borderaxespad=0, handletextpad=0.7, labelspacing=0.85)
    legend._legend_box.align = 'left'
    plt.setp(legend.get_title(), fontsize=15)

def save(fig: plt.Figure, stem: str) -> None:
    fig.savefig(OUT_DIR / f'{stem}.pdf', dpi=300, facecolor='white', bbox_inches='tight', pad_inches=0.04)
    fig.savefig(OUT_DIR / f'{stem}.png', dpi=300, facecolor='white', bbox_inches='tight', pad_inches=0.04)
    plt.close(fig)

def make_merged_version(frame: pd.DataFrame, labels: pd.DataFrame) -> None:
    fig, ax = base_axes()
    visible = draw_common(ax, frame)
    merged_group = {'Blood QTL': 'Plasma / Whole blood', 'Plasma pQTL': 'Plasma / Whole blood', 'Fibroblast GTEx': 'Cultured fibroblasts'}
    palette = {'Plasma / Whole blood': TEAL, 'Cultured fibroblasts': BLUE}
    plotted = visible.loc[visible['candidate_highlight'] & visible['source_group'].notna()].copy()
    plotted['plot_group_v1'] = plotted['source_group'].map(merged_group)
    for group in ('Plasma / Whole blood', 'Cultured fibroblasts'):
        part = plotted.loc[plotted['plot_group_v1'].eq(group)]
        ax.scatter(part['b_SMR'], part['minus_log10_p_SMR'], s=38, c=palette[group], alpha=0.92, linewidths=0, zorder=3)
    draw_annotations(ax, labels, {'Blood QTL': TEAL, 'Plasma pQTL': TEAL, 'Fibroblast GTEx': BLUE})
    add_legend(ax, [('Plasma / Whole blood', TEAL), ('Cultured fibroblasts', BLUE)])
    frame.assign(plot_group_v1=frame['source_group'].map(merged_group)).to_csv(OUT_DIR / f'{V1_STEM}_source_data.csv', index=False, encoding='utf-8-sig')
    save(fig, V1_STEM)

def make_detailed_version(frame: pd.DataFrame, labels: pd.DataFrame) -> None:
    fig, ax = base_axes()
    visible = draw_common(ax, frame)
    palette = {'Blood QTL': TEAL, 'Fibroblast GTEx': LIGHT_TEAL, 'Plasma pQTL': BLUE}
    plotted = visible.loc[visible['candidate_highlight'] & visible['source_group'].notna()].copy()
    for group in ('Blood QTL', 'Fibroblast GTEx', 'Plasma pQTL'):
        part = plotted.loc[plotted['source_group'].eq(group)]
        ax.scatter(part['b_SMR'], part['minus_log10_p_SMR'], s=38, c=palette[group], alpha=0.92, linewidths=0, zorder=3)
    draw_annotations(ax, labels, palette)
    add_legend(ax, [('Blood QTL', TEAL), ('Fibroblast GTEx', LIGHT_TEAL), ('Plasma pQTL', BLUE)])
    frame.to_csv(OUT_DIR / f'{V2_STEM}_source_data.csv', index=False, encoding='utf-8-sig')
    save(fig, V2_STEM)

def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    frame, labels = load_data()
    make_merged_version(frame, labels)
    make_detailed_version(frame, labels)
    print(OUT_DIR / f'{V1_STEM}.pdf')
    print(OUT_DIR / f'{V2_STEM}.pdf')
if __name__ == '__main__':
    main()
