from __future__ import annotations
import make_two_legend_revisions as base
STEM = 'A_SMR\u6563\u70b9\u56fe_Whole_blood_QTL_GTEx_\u7eb5\u8f74\u4e0a\u96504_\u539f\u6bd4\u4f8b_20260825'

def main(stem: str=STEM, label_positions: dict[str, tuple[float, float]] | None=None) -> None:
    frame, labels = base.load_data()
    frame['shown_y_le_4'] = frame['minus_log10_p_SMR'].le(4.0)
    plot_frame = frame.loc[frame['shown_y_le_4']].copy()
    fig, ax = base.base_axes()
    ax.set_ylim(-0.3, 4.0)
    ax.set_yticks([0, 2, 4])
    ax.get_yticklabels()[-1].set_verticalalignment('top')
    visible = base.draw_common(ax, plot_frame)
    merged_group = {'Blood QTL': 'Whole blood QTL/GTEx', 'Plasma pQTL': 'Whole blood QTL/GTEx', 'Fibroblast GTEx': 'Cultured fibroblasts'}
    palette = {'Whole blood QTL/GTEx': base.TEAL, 'Cultured fibroblasts': base.BLUE}
    plotted = visible.loc[visible['candidate_highlight'] & visible['source_group'].notna()].copy()
    plotted['plot_group_v4'] = plotted['source_group'].map(merged_group)
    for group in ('Whole blood QTL/GTEx', 'Cultured fibroblasts'):
        part = plotted.loc[plotted['plot_group_v4'].eq(group)]
        ax.scatter(part['b_SMR'], part['minus_log10_p_SMR'], s=38, c=palette[group], alpha=0.92, linewidths=0, zorder=3)
    base.draw_annotations(ax, labels, {'Blood QTL': base.TEAL, 'Plasma pQTL': base.TEAL, 'Fibroblast GTEx': base.BLUE}, positions=label_positions)
    base.add_legend(ax, [('Whole blood QTL/GTEx', base.TEAL), ('Cultured fibroblasts', base.BLUE)])
    export = frame.copy()
    export['plot_group_v4'] = export['source_group'].map(merged_group)
    export.to_csv(base.OUT_DIR / f'{stem}_source_data.csv', index=False, encoding='utf-8-sig')
    base.save(fig, stem)
    print(base.OUT_DIR / f'{stem}.pdf')
if __name__ == '__main__':
    main()
