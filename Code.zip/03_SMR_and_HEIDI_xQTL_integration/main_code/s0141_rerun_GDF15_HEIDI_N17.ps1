$ErrorActionPreference = 'Stop'

$smrExe = "G:\$([char]0x8840)$([char]0x6E05)$([char]0x7EF4)$([char]0x751F)$([char]0x7D20)\E$([char]0x76D8)$([char]0x7CBE)$([char]0x7B80)$([char]0x5F52)$([char]0x6863)_20260908_v2\E$([char]0x76D8)$([char]0x539F)$([char]0x76F8)$([char]0x5BF9)$([char]0x7ED3)$([char]0x6784)\$([char]0x4EE3)$([char]0x7801)\$([char]0x8FD0)$([char]0x884C)$([char]0x73AF)$([char]0x5883)\SMR\smr-1.3.1-win.exe"
$runDir = "E:\$([char]0x8840)$([char]0x6E05)$([char]0x7EF4)$([char]0x751F)$([char]0x7D20)\$([char]0x4EE3)$([char]0x7801)\$([char]0x8FD0)$([char]0x884C)$([char]0x8F93)$([char]0x51FA)\20260804-$([char]0x7259)$([char]0x5468)$([char]0x75C5)OpenGWAS$([char]0x65B0)$([char]0x589E)$([char]0x4E0E)$([char]0x65E2)$([char]0x5F80)$([char]0x5408)$([char]0x5E76)-SMR_HEIDI-Figure1\03_SMR_runs\mQTL_McRae_Whole_Blood_chr19\OGWAS_UKB_Neale_bleeding_gums\17_gene_sensitivity_HEIDI"
$arguments = @(
    '--bfile', "E:\$([char]0x8840)$([char]0x6E05)$([char]0x7EF4)$([char]0x751F)$([char]0x7D20)\$([char]0x539F)$([char]0x59CB)$([char]0x6570)$([char]0x636E)\03_xQTL$([char]0x4E0E)$([char]0x53C2)$([char]0x8003)$([char]0x9762)$([char]0x677F)\1000G_EUR\g1000_eur",
    '--gwas-summary', "E:\$([char]0x8840)$([char]0x6E05)$([char]0x7EF4)$([char]0x751F)$([char]0x7D20)\$([char]0x4EE3)$([char]0x7801)\$([char]0x8FD0)$([char]0x884C)$([char]0x8F93)$([char]0x51FA)\20260804-$([char]0x7259)$([char]0x5468)$([char]0x75C5)OpenGWAS$([char]0x65B0)$([char]0x589E)$([char]0x4E0E)$([char]0x65E2)$([char]0x5F80)$([char]0x5408)$([char]0x5E76)-SMR_HEIDI-Figure1\02_prepared_GWAS\OGWAS_UKB_Neale_bleeding_gums.ma",
    '--beqtl-summary', "E:\$([char]0x8840)$([char]0x6E05)$([char]0x7EF4)$([char]0x751F)$([char]0x7D20)\$([char]0x539F)$([char]0x59CB)$([char]0x6570)$([char]0x636E)\03_xQTL$([char]0x4E0E)$([char]0x53C2)$([char]0x8003)$([char]0x9762)$([char]0x677F)\mQTL_McRae\LBC_BSGS_meta_lite\bl_mqtl_lite_chr19",
    '--extract-probe', "$runDir\GDF15_probe_for_HEIDI_N17.txt",
    '--peqtl-smr', '0.0016',
    '--peqtl-heidi', '0.0016',
    '--ld-upper-limit', '0.9',
    '--heidi-min-m', '3',
    '--heidi-max-m', '20',
    '--thread-num', '1',
    '--out', "$runDir\GDF15_HEIDI_N17"
)

& $smrExe @arguments
if ($LASTEXITCODE -ne 0) {
    throw "SMR failed with exit code $LASTEXITCODE"
}
