from __future__ import annotations
import gzip
import importlib.util
import json
import math
import os
import shutil
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict
from pathlib import Path
import numpy as np
import pandas as pd
CODE_ROOT = Path(__file__).resolve().parents[3]
ARCHIVE_ROOT = Path(os.environ.get('SERUM_VITAMIN_ARCHIVE_ROOT', 'G:\\\u8840\u6e05\u7ef4\u751f\u7d20\\E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2\\E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784'))
RUN_OUTPUT_ROOT = Path(os.environ.get('SERUM_VITAMIN_OUTPUT_ROOT', str(CODE_ROOT / '\u8fd0\u884c\u8f93\u51fa')))
BASE_SCRIPT = CODE_ROOT / '03_\u6b63\u6587\u56fe3_SMR\u4e0eBulkRNA' / 'SMR_HEIDI\u590d\u7b97' / 'scripts' / '20260804_periodontitis_smr_pipeline.py'
PREVIOUS_ROOT = ARCHIVE_ROOT / '\u8f93\u51fa\u7ed3\u679c' / '20260804-\u7ef4\u751f\u7d20D\u5019\u9009\u57fa\u56e0-\u7259\u5468\u75c5GWAS-SMR_HEIDI-Figure1\u590d\u7b97'
NEW_GWAS_ROOT = ARCHIVE_ROOT / '\u539f\u59cb\u6570\u636e' / '02_\u7259\u5468\u75c5GWAS' / 'OpenGWAS\u7259\u5468\u708e\u7ed3\u5c40'
OUTPUT_ROOT = RUN_OUTPUT_ROOT / '20260804-\u7259\u5468\u75c5OpenGWAS\u65b0\u589e\u4e0e\u65e2\u5f80\u5408\u5e76-SMR_HEIDI-Figure1'

def load_base_module():
    spec = importlib.util.spec_from_file_location('periodontitis_smr_base', BASE_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'Cannot import base pipeline: {BASE_SCRIPT}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module
base = load_base_module()
base.OUTPUT_ROOT = OUTPUT_ROOT
base.INVENTORY = OUTPUT_ROOT / '01_input_inventory'
base.PREPARED = OUTPUT_ROOT / '02_prepared_GWAS'
base.RUNS = OUTPUT_ROOT / '03_SMR_runs'
base.RESULTS = OUTPUT_ROOT / '04_results'
base.FIGURES = OUTPUT_ROOT / '05_figures'
base.QA = OUTPUT_ROOT / '06_QA'
base.SCRIPT_COPY = OUTPUT_ROOT / 'scripts'

def outcome_definitions() -> list:
    specs = [('OGWAS_UKB_Neale_painful_gums', 'Painful gums\n(UKB Neale EUR)', 'ukb-a-429.vcf.gz', 'European', False, 'N=336,138; cases=37,814; controls=298,324', 'UKB symptom endpoint; non-independent alternative analysis of the same phenotype as ukb-b-11161'), ('OGWAS_UKB_Neale_bleeding_gums', 'Bleeding gums\n(UKB Neale EUR)', 'ukb-a-430.vcf.gz', 'European', False, 'N=336,138; cases=43,469; controls=292,669', 'UKB symptom endpoint; non-independent alternative analysis of the same phenotype as ukb-b-7872'), ('OGWAS_UKB_MRCIEU_painful_gums', 'Painful gums\n(UKB MRC-IEU EUR)', 'ukb-b-11161.vcf.gz', 'European', True, 'N=461,113; cases=13,314; controls=447,799', 'Prespecified clinically interpretable periodontal symptom; overlaps UK Biobank symptom outcomes'), ('OGWAS_UKB_MRCIEU_bleeding_gums', 'Bleeding gums\n(UKB MRC-IEU EUR)', 'ukb-b-7872.vcf.gz', 'European', True, 'N=461,113; cases=60,218; controls=400,895', 'Prespecified clinically interpretable periodontal symptom; overlaps UK Biobank symptom outcomes'), ('OGWAS_FinnGen_acute_periodontitis', 'Acute periodontitis\n(FinnGen EUR)', 'finn-b-K11_PERIODON_ACUTE.vcf.gz', 'European', True, 'N=195,762; cases=367; controls=195,395', 'Clinical registry endpoint; low case count limits power'), ('OGWAS_FinnGen_chronic_periodontitis', 'Chronic periodontitis\n(FinnGen EUR)', 'finn-b-K11_PERIODON_CHRON.vcf.gz', 'European', True, 'N=198,441; cases=3,046; controls=195,395', 'Clinical registry endpoint'), ('OGWAS_EBI_GCF_IL1beta', 'High GCF IL-1beta\n(European inflammation proxy)', 'ebi-a-GCST007542.vcf.gz', 'European', False, 'N=4,910', 'Periodontal inflammation biomarker, not a periodontitis diagnosis'), ('OGWAS_BBJ_periodontal_disease', 'Periodontal disease\n(BBJ East Asian; EUR-LD sensitivity)', 'bbj-a-142.vcf.gz', 'East Asian', False, 'N=212,453; cases=3,219; controls=209,234', 'Sensitivity only because the available HEIDI LD panel is 1000G EUR')]
    outcomes = []
    for outcome_id, label, filename, ancestry, primary, sample, limitation in specs:
        outcomes.append(base.Outcome(outcome_id=outcome_id, label=label, source_path=NEW_GWAS_ROOT / filename, prepared_path=base.PREPARED / f'{outcome_id}.ma', converter='gwas_vcf', ancestry=ancestry, primary_eur=primary, sample_note=sample, overlap_note=limitation))
    return outcomes
DEFAULT_N = {'OGWAS_UKB_Neale_painful_gums': 336138, 'OGWAS_UKB_Neale_bleeding_gums': 336138, 'OGWAS_UKB_MRCIEU_painful_gums': 461113, 'OGWAS_UKB_MRCIEU_bleeding_gums': 461113, 'OGWAS_FinnGen_acute_periodontitis': 195762, 'OGWAS_FinnGen_chronic_periodontitis': 198441, 'OGWAS_EBI_GCF_IL1beta': 4910, 'OGWAS_BBJ_periodontal_disease': 212453}
INDEPENDENCE_FAMILY = {'OGWAS_UKB_Neale_painful_gums': 'UKB_painful_gums', 'OGWAS_UKB_MRCIEU_painful_gums': 'UKB_painful_gums', 'OGWAS_UKB_Neale_bleeding_gums': 'UKB_bleeding_gums', 'OGWAS_UKB_MRCIEU_bleeding_gums': 'UKB_bleeding_gums', 'OGWAS_FinnGen_acute_periodontitis': 'FinnGen_periodontitis', 'OGWAS_FinnGen_chronic_periodontitis': 'FinnGen_periodontitis', 'OGWAS_EBI_GCF_IL1beta': 'Dental_ARIC_GCF_IL1beta', 'OGWAS_BBJ_periodontal_disease': 'BioBank_Japan_periodontal_disease'}

def parse_meta_value(line: str) -> tuple[str, str] | None:
    if not line.startswith('##') or '=' not in line:
        return None
    key, value = line[2:].rstrip('\r\n').split('=', 1)
    return (key, value)

def parse_number(value: str | None) -> float | None:
    if value is None or value in {'', '.', 'NA', 'nan'}:
        return None
    try:
        number = float(value)
    except (ValueError, TypeError, OverflowError):
        return None
    return number if math.isfinite(number) else None

def lp_to_p(value: str | None) -> float | None:
    lp = parse_number(value)
    if lp is None or lp < 0:
        return None
    if lp >= 300:
        return 1e-300
    return 10.0 ** (-lp)

def convert_gwas_vcf(outcome, target_snps: set[str], position_map: dict[tuple[int, int], str], freq_map: dict[str, tuple[str, str, float]]) -> dict[str, object]:
    selected: dict[str, tuple[float, str]] = {}
    total = invalid = not_target = allele_mismatch = duplicate = 0
    metadata: dict[str, str] = {}
    outcome.prepared_path.parent.mkdir(parents=True, exist_ok=True)
    print(f'Preparing {outcome.outcome_id}: {outcome.source_path.name}', flush=True)
    with gzip.open(outcome.source_path, 'rt', encoding='utf-8', errors='replace') as handle:
        for line in handle:
            if line.startswith('##'):
                item = parse_meta_value(line)
                if item:
                    metadata[item[0]] = item[1]
                continue
            if line.startswith('#'):
                continue
            total += 1
            if total % 5000000 == 0:
                print(f'  {outcome.outcome_id}: scanned {total:,} variants', flush=True)
            fields = line.rstrip('\r\n').split('\t')
            if len(fields) < 10:
                invalid += 1
                continue
            chrom_token, pos_token, vcf_id, ref, alt = fields[:5]
            if ',' in alt:
                invalid += 1
                continue
            try:
                chromosome = int(chrom_token.removeprefix('chr'))
                position = int(pos_token)
            except ValueError:
                invalid += 1
                continue
            snp = vcf_id if vcf_id in target_snps else position_map.get((chromosome, position))
            if snp is None or snp not in target_snps or snp not in freq_map:
                not_target += 1
                continue
            ref = ref.upper()
            alt = alt.upper()
            if ref not in {'A', 'C', 'G', 'T'} or alt not in {'A', 'C', 'G', 'T'} or ref == alt:
                invalid += 1
                continue
            reference_frequency = base.effect_allele_frequency(snp, alt, ref, freq_map)
            if reference_frequency is None:
                allele_mismatch += 1
                continue
            keys = fields[8].split(':')
            values = fields[9].split(':')
            sample = dict(zip(keys, values))
            beta = parse_number(sample.get('ES'))
            se = parse_number(sample.get('SE'))
            p = lp_to_p(sample.get('LP'))
            af = parse_number(sample.get('AF'))
            n = parse_number(sample.get('SS')) or float(DEFAULT_N[outcome.outcome_id])
            if beta is None or se is None or p is None or (se <= 0) or (n <= 0):
                invalid += 1
                continue
            if af is None or not 0 <= af <= 1:
                af = float(reference_frequency)
            row = f'{snp}\t{alt}\t{ref}\t{af:.8g}\t{beta:.12g}\t{se:.12g}\t{p:.12g}\t{n:.12g}\n'
            old = selected.get(snp)
            if old is not None:
                duplicate += 1
                if p >= old[0]:
                    continue
            selected[snp] = (p, row)
    with outcome.prepared_path.open('w', encoding='utf-8', newline='') as output:
        output.write('SNP\tA1\tA2\tfreq\tb\tse\tp\tn\n')
        for snp in sorted(selected):
            output.write(selected[snp][1])
    if not selected:
        raise RuntimeError(f'No target QTL SNPs retained from {outcome.source_path}')
    print(f'  retained {len(selected):,} target variants', flush=True)
    return {'outcome_id': outcome.outcome_id, 'label': outcome.label.replace('\n', ' '), 'source_path': str(outcome.source_path), 'prepared_path': str(outcome.prepared_path), 'converter': outcome.converter, 'ancestry': outcome.ancestry, 'primary_eur': outcome.primary_eur, 'sample_note': outcome.sample_note, 'overlap_or_limitation': outcome.overlap_note, 'total_rows': total, 'retained_target_rows': len(selected), 'not_target_or_not_in_EUR_LD': not_target, 'allele_mismatch': allele_mismatch, 'invalid_rows': invalid, 'duplicate_rows': duplicate, 'vcf_total_variants_header': metadata.get('TotalVariants', ''), 'vcf_total_cases_header': metadata.get('TotalCases', ''), 'vcf_total_controls_header': metadata.get('TotalControls', ''), 'vcf_reference': metadata.get('reference', ''), 'prepared_sha256': base.sha256(outcome.prepared_path)}

def prepare_vcf_outcomes(outcomes: list, target_snps: set[str], position_map: dict[tuple[int, int], str], freq_map: dict[str, tuple[str, str, float]]) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = {executor.submit(convert_gwas_vcf, outcome, target_snps, position_map, freq_map): outcome for outcome in outcomes}
        for future in as_completed(futures):
            rows.append(future.result())
    audit = pd.DataFrame(rows).sort_values('outcome_id')
    audit.to_csv(base.PREPARED / '01_GWAS_preparation_audit.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame([{**asdict(outcome), 'source_path': str(outcome.source_path), 'prepared_path': str(outcome.prepared_path), 'independence_family': INDEPENDENCE_FAMILY[outcome.outcome_id]} for outcome in outcomes]).to_csv(base.PREPARED / '02_outcome_registry.csv', index=False, encoding='utf-8-sig')
    return audit

def bool_series(series: pd.Series) -> pd.Series:
    if pd.api.types.is_bool_dtype(series):
        return series.fillna(False)
    return series.astype(str).str.strip().str.lower().map({'true': True, '1': True, 'false': False, '0': False}).fillna(False)

def attach_metadata(frame: pd.DataFrame, outcomes: list, batch: str) -> pd.DataFrame:
    frame = frame.copy()
    lookup = {item.outcome_id: item for item in outcomes}
    frame['analysis_batch'] = batch
    frame['sample_note'] = frame['outcome_id'].map(lambda value: lookup[value].sample_note if value in lookup else 'Retained from prior completed run')
    frame['overlap_or_limitation'] = frame['outcome_id'].map(lambda value: lookup[value].overlap_note if value in lookup else 'See prior run audit')
    frame['independence_family'] = frame['outcome_id'].map(lambda value: INDEPENDENCE_FAMILY.get(value, f'prior_{value}'))
    return frame

def merge_previous_and_new(new_merged: pd.DataFrame, outcomes: list) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    prior_path = PREVIOUS_ROOT / '04_results' / '04_SMR_HEIDI_all_results.csv'
    base.require(prior_path)
    prior = pd.read_csv(prior_path, low_memory=False)
    prior = attach_metadata(prior, [], 'previous_completed_run')
    new = attach_metadata(new_merged, outcomes, 'new_local_OpenGWAS_run')
    columns = sorted(set(prior.columns) | set(new.columns))
    combined = pd.concat([prior.reindex(columns=columns), new.reindex(columns=columns)], ignore_index=True)
    combined['strict_SMR_HEIDI'] = bool_series(combined['strict_SMR_HEIDI'])
    combined['primary_eur'] = bool_series(combined['primary_eur'])
    duplicate_key = ['analysis_batch', 'outcome_id', 'panel_id', 'probeID']
    combined = combined.sort_values(['analysis_batch', 'outcome_id', 'panel_id', 'probeID', 'p_SMR'])
    combined = combined.drop_duplicates(duplicate_key, keep='first').reset_index(drop=True)
    strict = combined.loc[combined['strict_SMR_HEIDI']].copy()
    strict_primary = strict.loc[strict['primary_eur']].copy()
    return (combined, strict, strict_primary)

def candidate_summary(strict: pd.DataFrame, strict_primary: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for gene in base.CANDIDATE_GENES:
        all_rows = strict.loc[strict['gene'].eq(gene)]
        primary_rows = strict_primary.loc[strict_primary['gene'].eq(gene)]
        rows.append({'candidate_gene': gene, 'strict_positive_any_GWAS': not all_rows.empty, 'strict_positive_primary_EUR': not primary_rows.empty, 'n_strict_associations_all': len(all_rows), 'n_strict_associations_primary_EUR': len(primary_rows), 'outcomes_all': '; '.join(sorted(all_rows['outcome_label'].astype(str).str.replace('\n', ' ').unique())), 'qtl_types_all': ';'.join(sorted(all_rows['qtl_type'].dropna().astype(str).unique()))})
    return pd.DataFrame(rows)

def write_source_dedup_audit() -> None:
    rows = [('ukb-a-429.vcf.gz', 'included', 'Harmonized OpenGWAS VCF selected'), ('ukb-a-429_data.vcf.gz', 'excluded', 'Same OpenGWAS study ID as ukb-a-429; avoided duplicate analysis'), ('ukb-a-430.vcf.gz', 'included', 'Harmonized OpenGWAS VCF selected'), ('ukb-a-430_data.vcf.gz', 'excluded', 'Same OpenGWAS study ID as ukb-a-430; avoided duplicate analysis'), ('ukb-b-11161.vcf.gz', 'included', 'Harmonized OpenGWAS VCF selected'), ('ukb-b-11161_raw.vcf.gz', 'excluded', 'Raw copy excluded because harmonized OpenGWAS VCF was selected'), ('ukb-b-7872.vcf.gz', 'included', 'Harmonized OpenGWAS VCF selected'), ('ukb-b-7872_raw.vcf.gz', 'excluded', 'Raw copy excluded because harmonized OpenGWAS VCF was selected'), ('finn-b-K11_PERIODON_ACUTE.vcf.gz', 'included', 'Unique harmonized outcome'), ('finn-b-K11_PERIODON_CHRON.vcf.gz', 'included', 'Unique harmonized outcome'), ('ebi-a-GCST007542.vcf.gz', 'included', 'Unique periodontal-inflammation proxy'), ('bbj-a-142.vcf.gz', 'included', 'Harmonized OpenGWAS VCF selected'), ('hum0197.v3.BBJ.PeD.v1.zip', 'excluded', 'Source/raw BBJ archive excluded because harmonized OpenGWAS VCF was selected')]
    pd.DataFrame(rows, columns=['file', 'analysis_status', 'reason']).to_csv(base.INVENTORY / '07_OpenGWAS_source_deduplication_audit.csv', index=False, encoding='utf-8-sig')

def write_merged_outputs(outcomes: list, preparation: pd.DataFrame, new_merged: pd.DataFrame, new_strict: pd.DataFrame, combined: pd.DataFrame, strict: pd.DataFrame, strict_primary: pd.DataFrame) -> None:
    new_merged.to_csv(base.RESULTS / '11_new_OpenGWAS_SMR_HEIDI_all_results.csv', index=False, encoding='utf-8-sig')
    new_strict.to_csv(base.RESULTS / '12_new_OpenGWAS_strict_positive.csv', index=False, encoding='utf-8-sig')
    combined.to_csv(base.RESULTS / '13_combined_previous_plus_new_SMR_HEIDI_all_results.csv', index=False, encoding='utf-8-sig')
    strict.to_csv(base.RESULTS / '14_combined_previous_plus_new_strict_positive_all.csv', index=False, encoding='utf-8-sig')
    strict_primary.to_csv(base.RESULTS / '15_combined_previous_plus_new_strict_positive_primary_EUR.csv', index=False, encoding='utf-8-sig')
    genes = candidate_summary(strict, strict_primary)
    genes.to_csv(base.RESULTS / '16_combined_candidate_gene_intersection_summary.csv', index=False, encoding='utf-8-sig')
    outcome_rows = []
    for outcome in outcomes:
        subset = new_strict.loc[new_strict['outcome_id'].eq(outcome.outcome_id)]
        outcome_rows.append({'outcome_id': outcome.outcome_id, 'outcome_label': outcome.label.replace('\n', ' '), 'ancestry': outcome.ancestry, 'primary_eur': outcome.primary_eur, 'sample_note': outcome.sample_note, 'overlap_or_limitation': outcome.overlap_note, 'strict_gene_n': subset['gene'].nunique(), 'strict_genes': ';'.join(sorted(subset['gene'].unique())), 'strict_association_n': len(subset)})
    pd.DataFrame(outcome_rows).to_csv(base.RESULTS / '17_new_OpenGWAS_strict_genes_by_outcome.csv', index=False, encoding='utf-8-sig')
    strict_numeric = strict.copy()
    for col in ['p_SMR', 'p_HEIDI', 'p_eQTL', 'F_instrument', 'ci95_lower', 'ci95_upper', 'b_SMR']:
        strict_numeric[col] = pd.to_numeric(strict_numeric[col], errors='coerce')
    validation = {'candidate_gene_n': base.N_CANDIDATES, 'strict_P_SMR_threshold': base.STRICT_P, 'new_outcome_n': len(outcomes), 'new_prepared_all_have_target_rows': bool((preparation['retained_target_rows'] > 0).all()), 'new_strict_association_n': int(len(new_strict)), 'new_strict_genes': sorted(new_strict['gene'].unique().tolist()), 'combined_strict_association_n': int(len(strict)), 'combined_strict_genes': sorted(strict['gene'].unique().tolist()), 'combined_primary_EUR_strict_association_n': int(len(strict_primary)), 'combined_primary_EUR_strict_genes': sorted(strict_primary['gene'].unique().tolist()), 'all_combined_strict_P_SMR_pass': bool((strict_numeric['p_SMR'] < base.STRICT_P).all()), 'all_combined_strict_P_HEIDI_pass': bool((strict_numeric['p_HEIDI'] > base.HEIDI_P).all()), 'all_combined_strict_QTL_P_pass': bool((strict_numeric['p_eQTL'] <= base.INSTRUMENT_P).all()), 'all_combined_strict_F_pass': bool((strict_numeric['F_instrument'] >= base.F_MIN).all()), 'all_combined_CI_contains_beta': bool(((strict_numeric['ci95_lower'] <= strict_numeric['b_SMR']) & (strict_numeric['b_SMR'] <= strict_numeric['ci95_upper'])).all()), 'duplicate_result_keys_after_merge': int(combined.duplicated(['analysis_batch', 'outcome_id', 'panel_id', 'probeID']).sum()), 'no_fabrication': True}
    (base.RESULTS / '18_combined_validation_checks.json').write_text(json.dumps(validation, ensure_ascii=False, indent=2), encoding='utf-8')
    if not all((value for key, value in validation.items() if key.startswith('all_') or key.startswith('new_prepared'))):
        raise RuntimeError(f'Combined validation failed: {validation}')
    if validation['duplicate_result_keys_after_merge'] != 0:
        raise RuntimeError(f'Duplicate result keys remain: {validation}')
    audit = {'analysis_time_utc': base.now_utc(), 'analysis': 'Candidate-gene SMR/HEIDI on new local OpenGWAS periodontal outcomes, merged with the prior completed run', 'candidate_genes': base.CANDIDATE_GENES, 'thresholds': {'P_SMR': f'< 0.05/{base.N_CANDIDATES} = {base.STRICT_P}', 'P_HEIDI': f'> {base.HEIDI_P}', 'QTL_P': f'<= {base.INSTRUMENT_P}', 'F': f'>= {base.F_MIN}', 'HEIDI_LD_upper_r2': base.LD_UPPER}, 'new_GWAS_root': str(NEW_GWAS_ROOT), 'previous_run_root': str(PREVIOUS_ROOT), 'output_root': str(OUTPUT_ROOT), 'primary_analysis_rule': 'European outcomes with one primary UKB analysis per symptom; Neale duplicates, IL-1beta proxy, and East Asian BBJ are retained only in the expanded/sensitivity set', 'non_independence_warning': 'UKB symptom datasets and some prior GLIDE/UKB endpoints share participants or phenotype components and are not independent replications.', 'ancestry_warning': 'BBJ was analyzed only as an explicitly labelled EUR-LD sensitivity because no matched East Asian HEIDI LD panel was locally available.', 'no_fabrication': True}
    (base.RESULTS / '19_combined_analysis_audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
    readme = f"# Vitamin D candidate genes x periodontal GWAS: new OpenGWAS run plus prior results\n\n## Fixed filters\n\n- Candidate genes: {', '.join(base.CANDIDATE_GENES)}\n- P_SMR < 0.05/{base.N_CANDIDATES} = {base.STRICT_P:.12g}\n- P_HEIDI > {base.HEIDI_P}\n- QTL P <= {base.INSTRUMENT_P} and F >= {base.F_MIN}\n- HEIDI upper LD exclusion threshold: r^2 > {base.LD_UPPER}\n\n## New outcomes\n\nPainful gums and bleeding gums (two UKB pipelines each), FinnGen acute/chronic periodontitis, high gingival-crevicular-fluid IL-1beta, and BioBank Japan periodontal disease were analyzed. Duplicate/raw files in the user directory were not double-counted.\n\n## Interpretation boundaries\n\nUKB phenotype duplicates are displayed as separate sensitivity estimates, not independent replications. The GCF IL-1beta endpoint is a periodontal-inflammation proxy rather than a diagnosis. BBJ is an ancestry-mismatched EUR-LD sensitivity analysis. No absent SMR, HEIDI, QTL, or GWAS value was imputed.\n\n## Strict results\n\n- New OpenGWAS only: {len(new_strict)} strict associations; genes: {(', '.join(sorted(new_strict['gene'].unique())) if not new_strict.empty else 'none')}.\n- Prior + new combined: {len(strict)} strict associations; genes: {(', '.join(sorted(strict['gene'].unique())) if not strict.empty else 'none')}.\n- Primary EUR combined: {len(strict_primary)} strict associations; genes: {(', '.join(sorted(strict_primary['gene'].unique())) if not strict_primary.empty else 'none')}.\n"
    (base.RESULTS / 'README_combined_results.md').write_text(readme, encoding='utf-8')

def main() -> None:
    base.ensure_dirs()
    for path in (BASE_SCRIPT, PREVIOUS_ROOT / '04_results' / '04_SMR_HEIDI_all_results.csv', base.SMR_EXE, base.PLINK_EXE, Path(str(base.LD_COMBINED) + '.bed'), Path(str(base.LD_COMBINED) + '.bim'), Path(str(base.LD_COMBINED) + '.fam')):
        base.require(path)
    outcomes = outcome_definitions()
    for outcome in outcomes:
        base.require(outcome.source_path)
    (base.INVENTORY / '00_candidate_genes.txt').write_text('\n'.join(base.CANDIDATE_GENES) + '\n', encoding='utf-8')
    write_source_dedup_audit()
    panels, coverage = base.build_panels()
    target_snps, query_status = base.build_target_snp_union(panels)
    freq_map, position_map, ld_audit = base.load_reference_maps(target_snps)
    preparation_path = base.PREPARED / '01_GWAS_preparation_audit.csv'
    if preparation_path.exists() and all((item.prepared_path.exists() and item.prepared_path.stat().st_size > 0 for item in outcomes)):
        preparation = pd.read_csv(preparation_path)
        print('Reusing completed OpenGWAS target-only preparation files', flush=True)
    else:
        preparation = prepare_vcf_outcomes(outcomes, target_snps, position_map, freq_map)
    new_merged, new_strict, new_primary, _ = base.run_all_smr(panels, outcomes)
    combined, strict, strict_primary = merge_previous_and_new(new_merged, outcomes)
    write_merged_outputs(outcomes, preparation, new_merged, new_strict, combined, strict, strict_primary)
    base.make_forest(new_strict, 'Figure1_periodontal_SMR_HEIDI_new_OpenGWAS_only_red', 'New local OpenGWAS periodontal outcomes', 'All estimates are Vitamin D candidate-gene SMR/HEIDI results')
    base.make_forest(strict, 'Figure1_periodontal_SMR_HEIDI_combined_previous_plus_new_all_GWAS_red', 'Prior plus new periodontal outcomes', 'Expanded strict-positive SMR/HEIDI set')
    base.make_forest(strict_primary, 'Figure1_periodontal_SMR_HEIDI_combined_previous_plus_new_primary_EUR_red', 'Prior plus new primary European periodontal outcomes', 'Primary ancestry-matched strict-positive SMR/HEIDI set')
    shutil.copy2(Path(__file__).resolve(), base.SCRIPT_COPY / Path(__file__).name)
    completion = {'completed_utc': base.now_utc(), 'output_root': str(OUTPUT_ROOT), 'new_outcome_count': len(outcomes), 'new_strict_rows': int(len(new_strict)), 'new_strict_genes': sorted(new_strict['gene'].unique().tolist()), 'combined_strict_rows': int(len(strict)), 'combined_strict_genes': sorted(strict['gene'].unique().tolist()), 'combined_primary_EUR_strict_rows': int(len(strict_primary)), 'combined_primary_EUR_strict_genes': sorted(strict_primary['gene'].unique().tolist()), 'ld_reference': ld_audit, 'panel_count': len(panels), 'query_panel_count': len(query_status), 'coverage_rows': len(coverage)}
    (OUTPUT_ROOT / 'RUN_COMPLETE.json').write_text(json.dumps(completion, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(completion, ensure_ascii=False, indent=2), flush=True)
if __name__ == '__main__':
    main()
