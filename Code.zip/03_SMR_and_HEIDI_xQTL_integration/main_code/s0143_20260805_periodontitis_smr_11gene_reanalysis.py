from __future__ import annotations
import importlib.util
import json
import math
import os
import shutil
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D
CODE_ROOT = Path(__file__).resolve().parents[3]
ARCHIVE_ROOT = Path(os.environ.get('SERUM_VITAMIN_ARCHIVE_ROOT', 'G:\\\u8840\u6e05\u7ef4\u751f\u7d20\\E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2\\E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784'))
RUN_OUTPUT_ROOT = Path(os.environ.get('SERUM_VITAMIN_OUTPUT_ROOT', str(CODE_ROOT / '\u8fd0\u884c\u8f93\u51fa')))
BASE_SCRIPT = CODE_ROOT / '03_\u6b63\u6587\u56fe3_SMR\u4e0eBulkRNA' / 'SMR_HEIDI\u590d\u7b97' / 'scripts' / '20260804_periodontitis_smr_pipeline.py'
SOURCE_ROOT = ARCHIVE_ROOT / '\u8f93\u51fa\u7ed3\u679c' / '20260804-\u7259\u5468\u75c5OpenGWAS\u65b0\u589e\u4e0e\u65e2\u5f80\u5408\u5e76-SMR_HEIDI-Figure1'
OUTPUT_ROOT = RUN_OUTPUT_ROOT / '20260805-11\u5019\u9009\u57fa\u56e0-\u7259\u5468\u75c5GWAS-\u65b0\u65e7\u5408\u5e76-SMR_HEIDI-Figure1'
CANDIDATE_GENES = ['VDR', 'PLAU', 'TG', 'MYC', 'BTF3P11', 'PHEX', 'GDF15', 'CYP24A1', 'AR', 'GMNN', 'IL2']
STRICT_P = 0.05 / len(CANDIDATE_GENES)
INSTRUMENT_P = 0.0016
F_MIN = 10.0
HEIDI_P = 0.05

def load_base_module():
    spec = importlib.util.spec_from_file_location('periodontitis_smr_base_11gene', BASE_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'Cannot import base pipeline: {BASE_SCRIPT}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module
base = load_base_module()
base.CANDIDATE_GENES = CANDIDATE_GENES
base.N_CANDIDATES = len(CANDIDATE_GENES)
base.STRICT_P = STRICT_P
base.INSTRUMENT_P = INSTRUMENT_P
base.F_MIN = F_MIN
base.HEIDI_P = HEIDI_P
base.OUTPUT_ROOT = OUTPUT_ROOT
base.INVENTORY = OUTPUT_ROOT / '01_input_inventory'
base.PREPARED = OUTPUT_ROOT / '02_source_links'
base.RUNS = OUTPUT_ROOT / '03_targeted_HEIDI_runs'
base.RESULTS = OUTPUT_ROOT / '04_results'
base.FIGURES = OUTPUT_ROOT / '05_figures'
base.QA = OUTPUT_ROOT / '06_QA'
base.SCRIPT_COPY = OUTPUT_ROOT / 'scripts'

def bool_series(series: pd.Series) -> pd.Series:
    if pd.api.types.is_bool_dtype(series):
        return series.fillna(False)
    return series.astype(str).str.strip().str.lower().map({'true': True, '1': True, 'false': False, '0': False}).fillna(False)

def relevant_new_outcomes() -> list:
    prepared = SOURCE_ROOT / '02_prepared_GWAS'
    return [base.Outcome(outcome_id='OGWAS_UKB_Neale_bleeding_gums', label='Bleeding gums\n(UKB Neale EUR)', source_path=prepared / 'OGWAS_UKB_Neale_bleeding_gums.ma', prepared_path=prepared / 'OGWAS_UKB_Neale_bleeding_gums.ma', converter='prepared_ma', ancestry='European', primary_eur=False, sample_note='N=336,138; cases=43,469; controls=292,669', overlap_note='UKB Neale symptom endpoint'), base.Outcome(outcome_id='OGWAS_UKB_MRCIEU_bleeding_gums', label='Bleeding gums\n(UKB MRC-IEU EUR)', source_path=prepared / 'OGWAS_UKB_MRCIEU_bleeding_gums.ma', prepared_path=prepared / 'OGWAS_UKB_MRCIEU_bleeding_gums.ma', converter='prepared_ma', ancestry='European', primary_eur=True, sample_note='N=461,113; cases=60,218; controls=400,895', overlap_note='UKB MRC-IEU symptom endpoint')]

def build_nonempty_panels() -> tuple[list, pd.DataFrame]:
    original_require = base.require

    def allow_empty_probe_list(path: Path) -> None:
        if path.name == 'target_probes.txt' and path.exists():
            return
        original_require(path)
    base.require = allow_empty_probe_list
    try:
        panels, coverage = base.build_panels()
    finally:
        base.require = original_require
    nonempty = []
    for panel in panels:
        manifest = pd.read_csv(panel.manifest_file, sep='\t', dtype=str)
        if not manifest.empty:
            nonempty.append(panel)
    return (nonempty, coverage)

def load_and_recalculate() -> pd.DataFrame:
    path = SOURCE_ROOT / '04_results' / '13_combined_previous_plus_new_SMR_HEIDI_all_results.csv'
    base.require(path)
    frame = pd.read_csv(path, low_memory=False)
    frame = frame.loc[frame['gene'].isin(CANDIDATE_GENES)].copy()
    numeric = ['b_SMR', 'se_SMR', 'p_SMR', 'p_eQTL', 'F_instrument', 'ci95_lower', 'ci95_upper']
    for column in numeric:
        frame[column] = pd.to_numeric(frame[column], errors='coerce')
    frame['primary_eur'] = bool_series(frame['primary_eur'])
    frame['instrument_pass'] = (frame['p_eQTL'] <= INSTRUMENT_P) & (frame['F_instrument'] >= F_MIN)
    frame['SMR_pre_HEIDI_pass'] = (frame['p_SMR'] < STRICT_P) & frame['instrument_pass']
    frame['ci95_lower'] = frame['b_SMR'] - 1.96 * frame['se_SMR']
    frame['ci95_upper'] = frame['b_SMR'] + 1.96 * frame['se_SMR']
    frame = frame.drop(columns=['p_HEIDI', 'nsnp_HEIDI', 'HEIDI_pass', 'strict_SMR_HEIDI'], errors='ignore')
    return frame.sort_values(['p_SMR', 'gene', 'outcome_id']).reset_index(drop=True)

def run_targeted_heidi(frame: pd.DataFrame, panels: list, outcomes: list) -> tuple[pd.DataFrame, pd.DataFrame]:
    queue = frame.loc[frame['SMR_pre_HEIDI_pass']].copy()
    panel_lookup = {panel.panel_id: panel for panel in panels}
    outcome_lookup = {outcome.outcome_id: outcome for outcome in outcomes}
    missing_panels = sorted(set(queue['panel_id']) - set(panel_lookup))
    missing_outcomes = sorted(set(queue['outcome_id']) - set(outcome_lookup))
    if missing_panels or missing_outcomes:
        raise RuntimeError(f'Targeted HEIDI lookup failed; panels={missing_panels}, outcomes={missing_outcomes}')
    rows: list[dict[str, object]] = []
    for panel_id, outcome_id in queue[['panel_id', 'outcome_id']].drop_duplicates().itertuples(index=False):
        (base.RUNS / panel_id / outcome_id).mkdir(parents=True, exist_ok=True)
    with ThreadPoolExecutor(max_workers=3) as executor:
        futures = [executor.submit(base.run_heidi, panel_lookup[panel_id], outcome_lookup[outcome_id], group['probeID'].astype(str).tolist()) for (panel_id, outcome_id), group in queue.groupby(['panel_id', 'outcome_id'])]
        for future in as_completed(futures):
            row = future.result()
            rows.append(row)
            print(f"HEIDI {row['outcome_id']} x {row['panel_id']}: {row['status']}", flush=True)
    status = pd.DataFrame(rows)
    status.to_csv(base.RESULTS / '01_targeted_HEIDI_run_status.csv', index=False, encoding='utf-8-sig')
    heidi = base.parse_heidi(panels, outcomes)
    merged = frame.merge(heidi, on=['panel_id', 'outcome_id', 'probeID'], how='left', validate='many_to_one')
    merged['p_HEIDI'] = pd.to_numeric(merged['p_HEIDI'], errors='coerce')
    merged['nsnp_HEIDI'] = pd.to_numeric(merged['nsnp_HEIDI'], errors='coerce')
    merged.loc[merged['p_HEIDI'] < 0, ['p_HEIDI', 'nsnp_HEIDI']] = np.nan
    merged['HEIDI_pass'] = merged['p_HEIDI'] > HEIDI_P
    merged['strict_SMR_HEIDI'] = merged['SMR_pre_HEIDI_pass'] & merged['HEIDI_pass']
    merged['effect_ci'] = merged.apply(lambda row: f'{row.b_SMR:.3f} ({row.ci95_lower:.3f}, {row.ci95_upper:.3f})', axis=1)
    return (merged, status)

def missing_reason(gene: str) -> str:
    if gene in {'AR', 'PHEX'}:
        return 'Chromosome X unavailable in EUR LD panel'
    return 'No eligible probe in prespecified xQTL panels'

def select_one_row_per_candidate(frame: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for order, gene in enumerate(CANDIDATE_GENES):
        estimable = frame.loc[frame['gene'].eq(gene) & frame['instrument_pass'] & frame['p_SMR'].notna() & frame['b_SMR'].notna() & frame['se_SMR'].notna()].copy()
        strict = estimable.loc[estimable['strict_SMR_HEIDI']].copy()
        pool = strict if not strict.empty else estimable
        if pool.empty:
            rows.append({'candidate_order': order, 'gene': gene, 'estimable': False, 'strict_SMR_HEIDI': False, 'status': 'Not estimable', 'outcome_id': f'NOT_ESTIMABLE_{gene}', 'outcome_label': 'No analyzable estimate', 'qtl_display': missing_reason(gene), 'effect_ci': 'Not estimable', 'selection_rule': 'No eligible estimate'})
            continue
        chosen = pool.sort_values(['p_SMR', 'p_HEIDI'], ascending=[True, False], na_position='last').iloc[0].to_dict()
        chosen.update({'candidate_order': order, 'estimable': True, 'status': 'Strict positive' if bool(chosen['strict_SMR_HEIDI']) else 'Not strict', 'selection_rule': 'Minimum P_SMR (strongest statistical evidence) within status'})
        rows.append(chosen)
    result = pd.DataFrame(rows).sort_values('candidate_order').reset_index(drop=True)
    result['strict_SMR_HEIDI'] = bool_series(result['strict_SMR_HEIDI'])
    result['estimable'] = bool_series(result['estimable'])
    return result

def make_overview_forest(frame: pd.DataFrame, stem: str) -> None:
    base.set_plot_style()
    frame = frame.copy().sort_values('candidate_order').reset_index(drop=True)
    frame.to_csv(base.RESULTS / f'{stem}_source_data.csv', index=False, encoding='utf-8-sig')
    red = '#F8766D'
    grey = '#9CA3AF'
    ink = '#111827'
    n = len(frame)
    frame['y'] = np.arange(n)[::-1]
    fig_height = max(8.8, 0.72 * n + 2.1)
    fig = plt.figure(figsize=(17.5, fig_height), facecolor='white')
    grid = fig.add_gridspec(1, 2, width_ratios=[5.8, 2.5], left=0.04, right=0.93, top=0.9, bottom=0.1, wspace=0.025)
    table_ax = fig.add_subplot(grid[0, 0])
    forest_ax = fig.add_subplot(grid[0, 1], sharey=table_ax)
    table_ax.set_xlim(0, 1)
    table_ax.set_ylim(-0.55, n - 0.45)
    table_ax.axis('off')
    headers = [('Outcomes', 0.0, 'left'), ('Genes', 0.285, 'left'), ('QTL name', 0.385, 'left'), ('SMR effect (95% CI)', 0.715, 'center'), ('P_SMR', 0.875, 'center'), ('P_HEIDI', 0.975, 'center')]
    for label, x, alignment in headers:
        table_ax.text(x, 1.025, label, transform=table_ax.transAxes, ha=alignment, va='bottom', fontsize=11, fontweight='bold', color=ink)
    for index, row in frame.iterrows():
        y = row['y']
        if index % 2 == 1:
            table_ax.axhspan(y - 0.48, y + 0.48, color='#F8FAFC', zorder=-5)
            forest_ax.axhspan(y - 0.48, y + 0.48, color='#F8FAFC', zorder=-5)
        color = red if bool(row['strict_SMR_HEIDI']) else grey
        table_ax.text(0.0, y, str(row['outcome_label']), ha='left', va='center', fontsize=8.7, linespacing=1.12, color=color if not row['estimable'] else ink)
        table_ax.text(0.285, y, str(row['gene']), ha='left', va='center', fontsize=9.6, fontweight='bold', color=color)
        table_ax.text(0.385, y, str(row['qtl_display']), ha='left', va='center', fontsize=8.0, linespacing=1.1, color=color if not row['estimable'] else ink)
        table_ax.text(0.715, y, str(row['effect_ci']), ha='center', va='center', fontsize=8.6, color=color)
        table_ax.text(0.875, y, base.format_p(row.get('p_SMR', np.nan)), ha='center', va='center', fontsize=8.6, color=color)
        table_ax.text(0.975, y, base.format_p(row.get('p_HEIDI', np.nan)), ha='center', va='center', fontsize=8.6, color=color)
    numeric = frame.loc[frame['estimable']].copy()
    x_min = min(float(numeric['ci95_lower'].min()), 0.0)
    x_max = max(float(numeric['ci95_upper'].max()), 0.0)
    span = max(x_max - x_min, 0.02)
    forest_ax.set_xlim(x_min - 0.07 * span, x_max + 0.07 * span)
    forest_ax.axvline(0, color='#222222', linestyle=(0, (5, 4)), linewidth=1.4, zorder=1)
    for _, row in frame.iterrows():
        y = row['y']
        color = red if bool(row['strict_SMR_HEIDI']) else grey
        if bool(row['estimable']):
            forest_ax.errorbar(row['b_SMR'], y, xerr=np.array([[row['b_SMR'] - row['ci95_lower']], [row['ci95_upper'] - row['b_SMR']]]), fmt='o', color=color, markerfacecolor=color, markeredgecolor='white', markeredgewidth=0.8, ecolor=color, elinewidth=1.6, capsize=3.5, capthick=1.3, markersize=7.5, alpha=0.98, zorder=3)
        else:
            forest_ax.text(x_min + 0.02 * span, y, 'Not estimable', color=grey, fontsize=8.2, va='center', ha='left')
    forest_ax.set_ylim(-0.55, n - 0.45)
    forest_ax.set_yticks([])
    forest_ax.set_xlabel('SMR effect (beta_SMR, 95% CI)', fontweight='bold')
    forest_ax.spines['top'].set_visible(False)
    forest_ax.spines['right'].set_visible(False)
    forest_ax.grid(axis='x', color='#E5E7EB', linewidth=0.8, zorder=0)
    forest_ax.legend(handles=[Line2D([0], [0], marker='o', color=red, markerfacecolor=red, markeredgecolor='white', markersize=7.5, linewidth=1.6, label='Strict positive'), Line2D([0], [0], marker='o', color=grey, markerfacecolor=grey, markeredgecolor='white', markersize=7.5, linewidth=1.6, label='Not strict')], frameon=False, loc='center left', bbox_to_anchor=(1.015, 0.5))
    fig.text(0.012, 0.965, 'B', fontsize=42, va='top', ha='left')
    for extension in ('png', 'pdf', 'svg'):
        fig.savefig(base.FIGURES / f'{stem}.{extension}', dpi=320 if extension == 'png' else None, bbox_inches='tight', facecolor='white')
    plt.close(fig)

def write_outputs(frame: pd.DataFrame, strict: pd.DataFrame, overview: pd.DataFrame, coverage: pd.DataFrame, status: pd.DataFrame) -> None:
    frame.to_csv(base.RESULTS / '02_11candidate_combined_all_results_recalculated.csv', index=False, encoding='utf-8-sig')
    strict.to_csv(base.RESULTS / '03_11candidate_strict_positive_all_GWAS.csv', index=False, encoding='utf-8-sig')
    strict.loc[strict['primary_eur']].to_csv(base.RESULTS / '04_11candidate_strict_positive_primary_EUR.csv', index=False, encoding='utf-8-sig')
    overview.to_csv(base.RESULTS / '05_11candidate_one_best_result_per_gene.csv', index=False, encoding='utf-8-sig')
    coverage.to_csv(base.RESULTS / '06_11candidate_xQTL_probe_coverage.csv', index=False, encoding='utf-8-sig')
    summary_rows = []
    for gene in CANDIDATE_GENES:
        subset = strict.loc[strict['gene'].eq(gene)]
        selected = overview.loc[overview['gene'].eq(gene)].iloc[0]
        summary_rows.append({'candidate_gene': gene, 'strict_positive': not subset.empty, 'n_strict_associations': len(subset), 'selected_status': selected['status'], 'selected_outcome': selected['outcome_label'], 'selected_qtl': selected['qtl_display'], 'selected_p_SMR': selected.get('p_SMR', np.nan), 'selected_p_HEIDI': selected.get('p_HEIDI', np.nan)})
    pd.DataFrame(summary_rows).to_csv(base.RESULTS / '07_11candidate_gene_summary.csv', index=False, encoding='utf-8-sig')
    validation = {'candidate_gene_n': len(CANDIDATE_GENES), 'candidate_genes': CANDIDATE_GENES, 'strict_P_SMR_threshold': STRICT_P, 'instrument_P_threshold': INSTRUMENT_P, 'F_minimum': F_MIN, 'P_HEIDI_threshold': HEIDI_P, 'pre_HEIDI_row_n': int(frame['SMR_pre_HEIDI_pass'].sum()), 'targeted_HEIDI_group_n': int(len(status)), 'strict_association_n': int(len(strict)), 'strict_gene_n': int(strict['gene'].nunique()), 'strict_genes': sorted(strict['gene'].unique().tolist()), 'all_strict_P_SMR_pass': bool((strict['p_SMR'] < STRICT_P).all()), 'all_strict_P_HEIDI_pass': bool((strict['p_HEIDI'] > HEIDI_P).all()), 'all_strict_QTL_P_pass': bool((strict['p_eQTL'] <= INSTRUMENT_P).all()), 'all_strict_F_pass': bool((strict['F_instrument'] >= F_MIN).all()), 'overview_has_exactly_11_rows': len(overview) == len(CANDIDATE_GENES), 'overview_gene_order_matches_request': overview['gene'].tolist() == CANDIDATE_GENES, 'overview_selection_rule': 'Minimum P_SMR means strongest statistical evidence; no effect was fabricated for non-estimable genes.', 'source_result_file': str(SOURCE_ROOT / '04_results' / '13_combined_previous_plus_new_SMR_HEIDI_all_results.csv'), 'no_prior_output_overwritten': True, 'no_fabrication': True}
    if not all((validation[key] for key in ('all_strict_P_SMR_pass', 'all_strict_P_HEIDI_pass', 'all_strict_QTL_P_pass', 'all_strict_F_pass', 'overview_has_exactly_11_rows', 'overview_gene_order_matches_request', 'no_prior_output_overwritten', 'no_fabrication'))):
        raise RuntimeError(f'Validation failed: {validation}')
    (base.RESULTS / '08_validation_checks.json').write_text(json.dumps(validation, ensure_ascii=False, indent=2), encoding='utf-8')
    readme = f"# Periodontal SMR/HEIDI reanalysis with 11 prespecified Vitamin D candidate genes\n\n## Candidate universe\n\n{', '.join(CANDIDATE_GENES)}\n\n## Prespecified filters\n\n- P_SMR < 0.05/11 = {STRICT_P:.12f}\n- P_HEIDI > 0.05\n- QTL P <= 1.6e-3\n- F >= 10\n- HEIDI LD upper r2 = 0.9\n\nThe prior and newly supplied periodontal GWAS results were combined and then filtered to the revised 11-gene universe. Associations newly crossing P_SMR < 0.05/11 were rerun through targeted HEIDI in this independent output directory.\n\nFor the 11-gene overview, the strongest statistical evidence is defined as the minimum P_SMR for each gene. Strict positives are red and non-strict estimates are grey. Genes without an analyzable estimate remain listed as not estimable; no zero effect was inserted.\n\nStrict genes: {(', '.join(sorted(strict['gene'].unique())) if not strict.empty else 'none')}.\n"
    (base.RESULTS / 'README_11gene_reanalysis.md').write_text(readme, encoding='utf-8')

def main() -> None:
    base.ensure_dirs()
    base.require(BASE_SCRIPT)
    (base.INVENTORY / '00_candidate_genes_N11.txt').write_text('\n'.join(CANDIDATE_GENES) + '\n', encoding='utf-8')
    (base.PREPARED / 'SOURCE_README.txt').write_text(f"Prepared GWAS inputs were reused read-only from: {SOURCE_ROOT / '02_prepared_GWAS'}\n", encoding='utf-8')
    panels, coverage = build_nonempty_panels()
    outcomes = relevant_new_outcomes()
    for outcome in outcomes:
        base.require(outcome.prepared_path)
    frame = load_and_recalculate()
    merged, status = run_targeted_heidi(frame, panels, outcomes)
    strict = merged.loc[merged['strict_SMR_HEIDI']].copy()
    overview = select_one_row_per_candidate(merged)
    write_outputs(merged, strict, overview, coverage, status)
    make_overview_forest(overview, 'Figure_B_11_candidate_genes_all_red_positive_gray_nonpositive')
    base.make_forest(strict, 'Figure_B_strict_positive_genes_only_red', 'Strict-positive Vitamin D candidate genes', 'Prespecified 11-gene periodontal SMR/HEIDI analysis')
    shutil.copy2(Path(__file__).resolve(), base.SCRIPT_COPY / Path(__file__).name)
    completion = {'completed_utc': base.now_utc(), 'output_root': str(OUTPUT_ROOT), 'candidate_gene_n': len(CANDIDATE_GENES), 'strict_P_SMR_threshold': STRICT_P, 'strict_association_n': int(len(strict)), 'strict_gene_n': int(strict['gene'].nunique()), 'strict_genes': sorted(strict['gene'].unique().tolist())}
    (OUTPUT_ROOT / 'RUN_COMPLETE.json').write_text(json.dumps(completion, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(completion, ensure_ascii=False, indent=2), flush=True)
if __name__ == '__main__':
    main()
