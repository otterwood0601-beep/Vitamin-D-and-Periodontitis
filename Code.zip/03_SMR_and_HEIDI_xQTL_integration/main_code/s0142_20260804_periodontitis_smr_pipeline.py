from __future__ import annotations
import csv
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D
CANDIDATE_GENES = ['VDR', 'PLAU', 'TG', 'MYC', 'BTF3P11', 'PHEX', 'GDF15', 'CYP24A1', 'AR', 'GMNN', 'IL2', 'RORC', 'MAPT', 'ESR1', 'EHMT2', 'CYP3A4', 'NFE2L2', 'ALOX15']
N_CANDIDATES = len(CANDIDATE_GENES)
STRICT_P = 0.05 / N_CANDIDATES
INSTRUMENT_P = 0.0016
HEIDI_P = 0.05
LD_UPPER = 0.9
F_MIN = 10.0
CODE_ROOT = Path(__file__).resolve().parents[3]
ARCHIVE_ROOT = Path(os.environ.get('SERUM_VITAMIN_ARCHIVE_ROOT', 'G:\\\u8840\u6e05\u7ef4\u751f\u7d20\\E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2\\E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784'))
RUN_OUTPUT_ROOT = Path(os.environ.get('SERUM_VITAMIN_OUTPUT_ROOT', str(CODE_ROOT / '\u8fd0\u884c\u8f93\u51fa')))
OUTPUT_ROOT = RUN_OUTPUT_ROOT / '20260804-\u7ef4\u751f\u7d20D\u5019\u9009\u57fa\u56e0-\u7259\u5468\u75c5GWAS-SMR_HEIDI-Figure1\u590d\u7b97'
INVENTORY = OUTPUT_ROOT / '01_input_inventory'
PREPARED = OUTPUT_ROOT / '02_prepared_GWAS'
RUNS = OUTPUT_ROOT / '03_SMR_runs'
RESULTS = OUTPUT_ROOT / '04_results'
FIGURES = OUTPUT_ROOT / '05_figures'
QA = OUTPUT_ROOT / '06_QA'
SCRIPT_COPY = OUTPUT_ROOT / 'scripts'
RESOURCE_ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u539f\u59cb\u6570\u636e\\03_xQTL\u4e0e\u53c2\u8003\u9762\u677f')
EXACT = RESOURCE_ROOT / '\u7cbe\u786e\u5019\u9009\u9762\u677f' / '11_DGIdb18_exact_xQTL_Figure1'
RUNTIME_ROOT = Path(os.environ.get('SERUM_VITAMIN_RUNTIME_ROOT', str(ARCHIVE_ROOT / '\u4ee3\u7801' / '\u8fd0\u884c\u73af\u5883')))
SMR_EXE = RUNTIME_ROOT / 'SMR' / 'smr-1.3.1-win.exe'
PLINK_EXE = RUNTIME_ROOT / 'PLINK' / 'plink.exe'
LD_DIR = RESOURCE_ROOT / '1000G_EUR'
LD_COMBINED = LD_DIR / 'g1000_eur'
XQTL = RESOURCE_ROOT / 'xQTL\u9762\u677f'
MC_RAE = RESOURCE_ROOT / 'mQTL_McRae' / 'LBC_BSGS_meta_lite'
OLD_EQTL_RAW = ARCHIVE_ROOT / '\u539f\u59cb\u6570\u636e' / '03_xQTL\u4e0e\u53c2\u8003\u9762\u677f' / '\u5386\u53f2\u63a2\u9488\u6e05\u5355' / 'raw_e_sqtl'
RAW_GWAS_ROOT = ARCHIVE_ROOT / '\u539f\u59cb\u6570\u636e' / '02_\u7259\u5468\u75c5GWAS'

@dataclass(frozen=True)
class Panel:
    panel_id: str
    qtl_type: str
    source: str
    tissue: str
    chromosome: int
    prefix: Path
    probe_file: Path
    manifest_file: Path
    qtl_display: str

@dataclass(frozen=True)
class Outcome:
    outcome_id: str
    label: str
    source_path: Path
    prepared_path: Path
    converter: str
    ancestry: str
    primary_eur: bool
    sample_note: str
    overlap_note: str

def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()

def with_ext(prefix: Path, extension: str) -> Path:
    return Path(str(prefix) + extension)

def ensure_dirs() -> None:
    for path in (OUTPUT_ROOT, INVENTORY, PREPARED, RUNS, RESULTS, FIGURES, QA, SCRIPT_COPY):
        path.mkdir(parents=True, exist_ok=True)

def require(path: Path) -> None:
    if not path.exists() or (path.is_file() and path.stat().st_size == 0):
        raise FileNotFoundError(path)

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def run_command(args: list[str], log_path: Path) -> int:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    completed = subprocess.run(args, capture_output=True, text=True, encoding='utf-8', errors='replace')
    log_path.write_text('COMMAND\n' + subprocess.list2cmdline(args) + '\n\nSTDOUT\n' + completed.stdout + '\nSTDERR\n' + completed.stderr, encoding='utf-8')
    return completed.returncode

def write_probe_manifest(panel_id: str, frame: pd.DataFrame) -> tuple[Path, Path]:
    directory = INVENTORY / 'panels' / panel_id
    directory.mkdir(parents=True, exist_ok=True)
    frame = frame[['probeID', 'gene']].dropna().drop_duplicates('probeID').copy()
    frame['probeID'] = frame['probeID'].astype(str)
    frame['gene'] = frame['gene'].astype(str).str.upper()
    frame = frame.loc[frame['gene'].isin(CANDIDATE_GENES)]
    manifest = directory / 'target_probe_manifest.tsv'
    probe_file = directory / 'target_probes.txt'
    frame.to_csv(manifest, sep='\t', index=False, encoding='utf-8')
    probe_file.write_text('\n'.join(frame['probeID'].tolist()) + ('\n' if not frame.empty else ''), encoding='utf-8')
    return (probe_file, manifest)

def read_epi(prefix: Path) -> pd.DataFrame:
    return pd.read_csv(with_ext(prefix, '.epi'), sep='\\s+', header=None, names=['probe_chr', 'probeID', 'gd', 'probe_bp', 'gene', 'strand'], dtype={'probeID': str, 'gene': str}, engine='python')

def build_panels() -> tuple[list[Panel], pd.DataFrame]:
    panels: list[Panel] = []
    coverage_rows: list[dict[str, object]] = []
    eqtl_prefix = XQTL / 'eQTLGen_47candidate_cis'
    old_manifest = OLD_EQTL_RAW / 'eQTL_eQTLGen_Blood' / 'target_probe_manifest.tsv'
    eqtl_manifest = pd.read_csv(old_manifest, sep='\t', dtype=str)
    eqtl_manifest['probe_chr'] = pd.to_numeric(eqtl_manifest['probe_chr'], errors='coerce')
    for chrom, group in eqtl_manifest.groupby('probe_chr'):
        if pd.isna(chrom) or int(chrom) > 22:
            continue
        panel_id = f'eQTL_eQTLGen_Whole_Blood_chr{int(chrom)}'
        probe_file, manifest = write_probe_manifest(panel_id, group)
        panels.append(Panel(panel_id, 'eQTL', 'eQTLGen', 'Whole blood', int(chrom), eqtl_prefix, probe_file, manifest, 'eQTLGen whole-blood eQTL'))
    sqtl_root = XQTL / 'GTEx_V8_cis_sqtl_summary_lite' / 'sQTL_besd_lite'
    tissue_specs = [('Cells_Cultured_fibroblasts', 'Cultured fibroblasts', 'GTEx v8 cultured-fibroblast sQTL'), ('Whole_Blood', 'Whole blood', 'GTEx v8 whole-blood sQTL')]
    for token, tissue, display in tissue_specs:
        pattern = f'sQTL_GTEx_{token}_chr*'
        for old_directory in sorted(OLD_EQTL_RAW.glob(pattern)):
            match = re.search('_chr(\\d+)$', old_directory.name)
            if not match:
                continue
            chrom = int(match.group(1))
            if chrom > 22:
                continue
            old_target = old_directory / 'target_probe_manifest.tsv'
            if not old_target.exists():
                continue
            frame = pd.read_csv(old_target, sep='\t', dtype=str)
            panel_id = f'sQTL_GTEx_{token}_chr{chrom}'
            probe_file, manifest = write_probe_manifest(panel_id, frame)
            prefix = sqtl_root / f'sQTL_{token}.lite.chr{chrom}'
            panels.append(Panel(panel_id, 'sQTL', 'GTEx v8', tissue, chrom, prefix, probe_file, manifest, display))
    mqtl_mapping = pd.read_csv(EXACT / 'mQTL_McRae_official_annotation' / '02_McRae_candidate_CpG_official_mapping.csv', dtype=str)
    mqtl_raw = EXACT / 'mQTL_McRae_official_annotation' / 'raw'
    for directory in sorted(mqtl_raw.glob('chr*'), key=lambda p: int(p.name[3:])):
        chrom = int(directory.name[3:])
        target_file = directory / 'target_cpg_probes.txt'
        if chrom > 22 or not target_file.exists():
            continue
        probes = {line.strip() for line in target_file.read_text(encoding='utf-8').splitlines() if line.strip()}
        frame = mqtl_mapping.loc[mqtl_mapping['probeID'].isin(probes), ['probeID', 'gene']]
        panel_id = f'mQTL_McRae_Whole_Blood_chr{chrom}'
        probe_file, manifest = write_probe_manifest(panel_id, frame)
        panels.append(Panel(panel_id, 'mQTL', 'McRae LBC/BSGS', 'Whole blood', chrom, MC_RAE / f'bl_mqtl_lite_chr{chrom}', probe_file, manifest, 'McRae whole-blood mQTL'))
    for prefix, source, display in [(EXACT / 'pQTL_INTERVAL' / 'raw' / 'INTERVAL_DGIdb18_candidate', 'INTERVAL', 'INTERVAL plasma pQTL'), (EXACT / 'pQTL_SCALLOP' / 'raw' / 'SCALLOP_GDF15', 'SCALLOP', 'SCALLOP plasma pQTL')]:
        epi = read_epi(prefix)
        epi['probe_chr'] = pd.to_numeric(epi['probe_chr'], errors='coerce')
        epi['gene'] = epi['gene'].astype(str).str.upper()
        epi = epi.loc[epi['gene'].isin(CANDIDATE_GENES)]
        for chrom, group in epi.groupby('probe_chr'):
            if pd.isna(chrom) or int(chrom) > 22:
                continue
            chrom = int(chrom)
            panel_id = f'pQTL_{source}_chr{chrom}'
            probe_file, manifest = write_probe_manifest(panel_id, group)
            panels.append(Panel(panel_id, 'pQTL', source, 'Plasma', chrom, prefix, probe_file, manifest, display))
    dedup: dict[str, Panel] = {panel.panel_id: panel for panel in panels}
    panels = sorted(dedup.values(), key=lambda p: (p.qtl_type, p.source, p.tissue, p.chromosome))
    for panel in panels:
        for extension in ('.besd', '.epi', '.esi'):
            require(with_ext(panel.prefix, extension))
        require(panel.probe_file)
        manifest = pd.read_csv(panel.manifest_file, sep='\t', dtype=str)
        for gene in CANDIDATE_GENES:
            coverage_rows.append({'panel_id': panel.panel_id, 'qtl_type': panel.qtl_type, 'source': panel.source, 'tissue': panel.tissue, 'chromosome': panel.chromosome, 'gene': gene, 'n_probes': int(manifest['gene'].eq(gene).sum()), 'qtl_display': panel.qtl_display, 'prefix': str(panel.prefix)})
    coverage = pd.DataFrame(coverage_rows)
    coverage.to_csv(INVENTORY / '01_candidate_panel_coverage.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame([{**asdict(panel), 'prefix': str(panel.prefix), 'probe_file': str(panel.probe_file), 'manifest_file': str(panel.manifest_file)} for panel in panels]).to_csv(INVENTORY / '02_panel_registry.csv', index=False, encoding='utf-8-sig')
    return (panels, coverage)

def query_panel_snps(panel: Panel) -> dict[str, object]:
    panel_dir = INVENTORY / 'panels' / panel.panel_id
    output_prefix = panel_dir / 'query_p1.6e-3'
    output = with_ext(output_prefix, '.txt')
    if not output.exists() or output.stat().st_size == 0:
        code = run_command([str(SMR_EXE), '--beqtl-summary', str(panel.prefix), '--extract-probe', str(panel.probe_file), '--query', str(INSTRUMENT_P), '--out', str(output_prefix)], panel_dir / 'query_p1.6e-3.console.log')
    else:
        code = 0
    snps: set[str] = set()
    if output.exists() and output.stat().st_size > 0:
        try:
            frame = pd.read_csv(output, sep='\\s+', engine='python', dtype=str)
            if 'SNP' in frame:
                snps = set(frame['SNP'].dropna().astype(str))
        except pd.errors.EmptyDataError:
            pass
    return {'panel_id': panel.panel_id, 'qtl_type': panel.qtl_type, 'chromosome': panel.chromosome, 'n_target_snps_p_le_1.6e-3': len(snps), 'exit_code': code, 'status': 'complete' if snps else 'no_target_instrument', 'snps': snps}

def build_target_snp_union(panels: list[Panel]) -> tuple[set[str], pd.DataFrame]:
    rows: list[dict[str, object]] = []
    union: set[str] = set()
    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = {executor.submit(query_panel_snps, panel): panel for panel in panels}
        for future in as_completed(futures):
            result = future.result()
            union.update(result.pop('snps'))
            rows.append(result)
            print(f"QTL query {result['panel_id']}: {result['n_target_snps_p_le_1.6e-3']}", flush=True)
    status = pd.DataFrame(rows).sort_values(['qtl_type', 'panel_id'])
    status.to_csv(INVENTORY / '03_QTL_query_status.csv', index=False, encoding='utf-8-sig')
    target_file = INVENTORY / '04_union_target_QTL_SNPs_p1.6e-3.txt'
    target_file.write_text('\n'.join(sorted(union)) + ('\n' if union else ''), encoding='utf-8')
    if not union:
        raise RuntimeError('No target QTL SNPs were obtained')
    return (union, status)

def load_reference_maps(target_snps: set[str]) -> tuple[dict[str, tuple[str, str, float]], dict[tuple[int, int], str], dict[str, object]]:
    target_file = INVENTORY / '04_union_target_QTL_SNPs_p1.6e-3.txt'
    freq_prefix = INVENTORY / '1000G_EUR_target_frequencies'
    freq_file = with_ext(freq_prefix, '.frq')
    if not freq_file.exists() or freq_file.stat().st_size == 0:
        code = run_command([str(PLINK_EXE), '--bfile', str(LD_COMBINED), '--extract', str(target_file), '--freq', '--out', str(freq_prefix)], INVENTORY / '1000G_EUR_target_frequencies.console.log')
        if code != 0:
            raise RuntimeError('PLINK frequency extraction failed')
    freq = pd.read_csv(freq_file, sep='\\s+', engine='python', dtype=str)
    freq['MAF'] = pd.to_numeric(freq['MAF'], errors='coerce')
    freq_map: dict[str, tuple[str, str, float]] = {}
    for row in freq.dropna(subset=['SNP', 'A1', 'A2', 'MAF']).itertuples(index=False):
        freq_map[str(row.SNP)] = (str(row.A1).upper(), str(row.A2).upper(), float(row.MAF))
    position_map: dict[tuple[int, int], str | None] = {}
    valid_bim_rows = 0
    ambiguous_positions = 0
    bim = with_ext(LD_COMBINED, '.bim')
    with bim.open('r', encoding='utf-8', errors='replace') as handle:
        for line in handle:
            fields = line.split()
            if len(fields) < 6 or fields[1] not in target_snps:
                continue
            try:
                chrom = int(fields[0])
                pos = int(fields[3])
            except ValueError:
                continue
            valid_bim_rows += 1
            key = (chrom, pos)
            if key in position_map and position_map[key] != fields[1]:
                position_map[key] = None
                ambiguous_positions += 1
            else:
                position_map[key] = fields[1]
    unambiguous = {key: value for key, value in position_map.items() if value is not None}
    audit = {'ld_reference': str(LD_COMBINED), 'ld_ancestry': '1000 Genomes Phase 3 European', 'target_snp_count': len(target_snps), 'target_snp_with_reference_frequency': len(freq_map), 'target_snp_bim_rows': valid_bim_rows, 'unambiguous_target_positions': len(unambiguous), 'ambiguous_target_positions': ambiguous_positions, 'chromosome_X_available': False}
    (INVENTORY / '05_LD_reference_mapping_audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
    return (freq_map, unambiguous, audit)
COMPLEMENT = str.maketrans('ACGT', 'TGCA')

def effect_allele_frequency(snp: str, a1: str, a2: str, freq_map: dict[str, tuple[str, str, float]]) -> float | None:
    if snp not in freq_map:
        return None
    ref_a1, ref_a2, maf = freq_map[snp]
    a1 = a1.upper()
    a2 = a2.upper()
    pairs = [(a1, a2), (a1.translate(COMPLEMENT), a2.translate(COMPLEMENT))]
    for left, right in pairs:
        if (left, right) == (ref_a1, ref_a2):
            return maf
        if (left, right) == (ref_a2, ref_a1):
            return 1.0 - maf
    return None

def valid_float(value: str) -> bool:
    try:
        return math.isfinite(float(value))
    except (ValueError, TypeError, OverflowError):
        return False

def clamp_p(value: str) -> str:
    number = float(value)
    if number <= 0:
        return '1e-300'
    return f'{number:.12g}'

def outcome_definitions() -> list[Outcome]:
    autosomal = RAW_GWAS_ROOT / 'GLIDE' / '\u5e38\u67d3\u8272\u4f53_\u7259\u5468\u708e'
    loose_root = RAW_GWAS_ROOT / 'UKB' / '\u5e03\u91cc\u65af\u6258\u5927\u5b66\u6570\u636e\u96c6'
    combined_root = RAW_GWAS_ROOT / 'GLIDE_UKB' / '\u7259\u5468\u708e\u4e0e\u7259\u9f7f\u677e\u52a8'
    return [Outcome('GLIDE_EUR_periodontitis_excl_HCHSSOL', 'Clinical periodontitis\n(EUR; HCHS/SOL excluded)', autosomal / '\u6392\u9664HCHS-SOL\u6b27\u6d32\u4eba\u7fa4' / 'EUR_perio_excl_HCHSSOL.txt', PREPARED / 'GLIDE_EUR_periodontitis_excl_HCHSSOL.ma', 'position', 'European', True, 'N=34,611; cases=12,289; controls=22,326', 'Primary ancestry-matched clinical outcome'), Outcome('GLIDE_EUR_periodontitis_incl_HCHSSOL', 'Clinical periodontitis\n(EUR set; HCHS/SOL included)', autosomal / '\u5168\u90e8\u6b27\u6d32\u4eba\u7fa4' / 'EUR_perio_incl_HCHSSOL.txt', PREPARED / 'GLIDE_EUR_periodontitis_incl_HCHSSOL.ma', 'position', 'Predominantly European; includes HCHS/SOL', False, 'N=45,561; cases=17,353; controls=28,210', 'Overlaps the HCHS/SOL-excluded EUR outcome'), Outcome('UKB_EUR_loose_teeth', 'Loose teeth\n(UK Biobank EUR)', loose_root / '\u539f\u59cb\u6570\u636e' / 'EUR_looseteeth.txt', PREPARED / 'UKB_EUR_loose_teeth.ma', 'ukb_loose', 'European', True, 'total N=461,031; effective N=72,791', 'Common periodontal symptom/proxy'), Outcome('GLIDE_UKB_periodontitis_loose_teeth', 'Periodontitis + loose teeth\n(GLIDE/UKB combined)', combined_root / 'perio_looseteeth_combined.txt', PREPARED / 'GLIDE_UKB_periodontitis_loose_teeth.ma', 'combined', 'GLIDE/UKB meta-analysis', True, 'Per-variant effective weight supplied by source', 'Composite clinical/symptom outcome; partly overlaps component datasets'), Outcome('GLIDE_EAA_EUR_periodontitis', 'Clinical periodontitis\n(EAA + EUR meta-analysis)', autosomal / '\u4e1c\u4e9a\u4e0e\u6b27\u6d32\u8054\u5408\u4eba\u7fa4' / 'EAA_EUR_perio_combined.txt', PREPARED / 'GLIDE_EAA_EUR_periodontitis.ma', 'position', 'Trans-ancestry EAA+EUR', False, 'N=62,848; cases=19,033; controls=43,817', 'Exploratory with EUR LD; ancestry mismatch for EAA component'), Outcome('GLIDE_EAA_periodontitis', 'Clinical periodontitis\n(EAA; EUR-LD sensitivity)', autosomal / '\u5168\u90e8\u4e1c\u4e9a\u4eba\u7fa4' / 'EAA_perio.txt', PREPARED / 'GLIDE_EAA_periodontitis.ma', 'position', 'East Asian', False, 'N=17,287; cases=1,680; controls=15,607', 'Sensitivity only: no matched EAS LD panel was locally available')]

def convert_position_outcome(outcome: Outcome, target_snps: set[str], position_map: dict[tuple[int, int], str], freq_map: dict[str, tuple[str, str, float]]) -> dict[str, object]:
    seen: set[str] = set()
    total = retained = invalid = not_target = allele_mismatch = duplicate = 0
    outcome.prepared_path.parent.mkdir(parents=True, exist_ok=True)
    with outcome.source_path.open('r', encoding='utf-8', errors='replace') as src, outcome.prepared_path.open('w', encoding='utf-8', newline='') as dst:
        header = src.readline().split()
        index = {name: i for i, name in enumerate(header)}
        required = ['MarkerName', 'Allele1', 'Allele2', 'Effect', 'StdErr', 'P-value', 'N']
        missing = [name for name in required if name not in index]
        if missing:
            raise RuntimeError(f'Missing columns {missing} in {outcome.source_path}')
        dst.write('SNP\tA1\tA2\tfreq\tb\tse\tp\tn\n')
        for line in src:
            total += 1
            fields = line.split()
            if len(fields) < len(header):
                invalid += 1
                continue
            marker = fields[index['MarkerName']].split(':')
            if len(marker) != 2:
                invalid += 1
                continue
            try:
                key = (int(marker[0]), int(marker[1]))
            except ValueError:
                invalid += 1
                continue
            snp = position_map.get(key)
            if snp is None or snp not in target_snps:
                not_target += 1
                continue
            a1 = fields[index['Allele1']].upper()
            a2 = fields[index['Allele2']].upper()
            beta = fields[index['Effect']]
            se = fields[index['StdErr']]
            p = fields[index['P-value']]
            n = fields[index['N']]
            if a1 not in {'A', 'C', 'G', 'T'} or a2 not in {'A', 'C', 'G', 'T'} or a1 == a2 or (not all((valid_float(value) for value in (beta, se, p, n)))) or (float(se) <= 0) or (float(n) <= 0):
                invalid += 1
                continue
            freq = effect_allele_frequency(snp, a1, a2, freq_map)
            if freq is None:
                allele_mismatch += 1
                continue
            if snp in seen:
                duplicate += 1
                continue
            seen.add(snp)
            dst.write(f'{snp}\t{a1}\t{a2}\t{freq:.8g}\t{float(beta):.12g}\t{float(se):.12g}\t{clamp_p(p)}\t{float(n):.12g}\n')
            retained += 1
    return {'outcome_id': outcome.outcome_id, 'label': outcome.label.replace('\n', ' '), 'source_path': str(outcome.source_path), 'prepared_path': str(outcome.prepared_path), 'converter': outcome.converter, 'ancestry': outcome.ancestry, 'primary_eur': outcome.primary_eur, 'total_rows': total, 'retained_target_rows': retained, 'not_target_or_not_in_EUR_LD': not_target, 'allele_mismatch': allele_mismatch, 'invalid_rows': invalid, 'duplicate_rows': duplicate, 'prepared_sha256': sha256(outcome.prepared_path)}

def convert_combined_outcome(outcome: Outcome, target_snps: set[str], freq_map: dict[str, tuple[str, str, float]]) -> dict[str, object]:
    seen: set[str] = set()
    total = retained = invalid = not_target = allele_mismatch = duplicate = 0
    with outcome.source_path.open('r', encoding='utf-8', errors='replace') as src, outcome.prepared_path.open('w', encoding='utf-8', newline='') as dst:
        header = src.readline().split()
        index = {name: i for i, name in enumerate(header)}
        required = ['Allele1', 'Allele2', 'Freq1', 'Weight', 'p', 'rsid', 'beta', 'se']
        missing = [name for name in required if name not in index]
        if missing:
            raise RuntimeError(f'Missing columns {missing} in {outcome.source_path}')
        dst.write('SNP\tA1\tA2\tfreq\tb\tse\tp\tn\n')
        for line in src:
            total += 1
            fields = line.split()
            if len(fields) < len(header):
                invalid += 1
                continue
            snp = fields[index['rsid']]
            if snp not in target_snps or snp not in freq_map:
                not_target += 1
                continue
            a1 = fields[index['Allele1']].upper()
            a2 = fields[index['Allele2']].upper()
            freq = fields[index['Freq1']]
            beta = fields[index['beta']]
            se = fields[index['se']]
            p = fields[index['p']]
            n = fields[index['Weight']]
            if a1 not in {'A', 'C', 'G', 'T'} or a2 not in {'A', 'C', 'G', 'T'} or a1 == a2 or (not all((valid_float(value) for value in (freq, beta, se, p, n)))) or (float(se) <= 0) or (float(n) <= 0):
                invalid += 1
                continue
            if effect_allele_frequency(snp, a1, a2, freq_map) is None:
                allele_mismatch += 1
                continue
            if snp in seen:
                duplicate += 1
                continue
            seen.add(snp)
            dst.write(f'{snp}\t{a1}\t{a2}\t{float(freq):.8g}\t{float(beta):.12g}\t{float(se):.12g}\t{clamp_p(p)}\t{float(n):.12g}\n')
            retained += 1
    return {'outcome_id': outcome.outcome_id, 'label': outcome.label.replace('\n', ' '), 'source_path': str(outcome.source_path), 'prepared_path': str(outcome.prepared_path), 'converter': outcome.converter, 'ancestry': outcome.ancestry, 'primary_eur': outcome.primary_eur, 'total_rows': total, 'retained_target_rows': retained, 'not_target_or_not_in_EUR_LD': not_target, 'allele_mismatch': allele_mismatch, 'invalid_rows': invalid, 'duplicate_rows': duplicate, 'prepared_sha256': sha256(outcome.prepared_path)}

def convert_ukb_loose_outcome(outcome: Outcome, target_snps: set[str], freq_map: dict[str, tuple[str, str, float]]) -> dict[str, object]:
    seen: set[str] = set()
    total = retained = invalid = not_target = allele_mismatch = duplicate = 0
    with outcome.source_path.open('r', encoding='utf-8', errors='replace') as src, outcome.prepared_path.open('w', encoding='utf-8', newline='') as dst:
        header = src.readline().split()
        index = {name: i for i, name in enumerate(header)}
        required = ['SNP', 'ALLELE1', 'ALLELE0', 'P_BOLT_LMM_INF', 'log_or', 'log_se', 'effective_n']
        missing = [name for name in required if name not in index]
        if missing:
            raise RuntimeError(f'Missing columns {missing} in {outcome.source_path}')
        dst.write('SNP\tA1\tA2\tfreq\tb\tse\tp\tn\n')
        for line in src:
            total += 1
            fields = line.split()
            if len(fields) < len(header):
                invalid += 1
                continue
            snp = fields[index['SNP']]
            if snp not in target_snps or snp not in freq_map:
                not_target += 1
                continue
            a1 = fields[index['ALLELE1']].upper()
            a2 = fields[index['ALLELE0']].upper()
            beta = fields[index['log_or']]
            se = fields[index['log_se']]
            p = fields[index['P_BOLT_LMM_INF']]
            n = fields[index['effective_n']]
            if a1 not in {'A', 'C', 'G', 'T'} or a2 not in {'A', 'C', 'G', 'T'} or a1 == a2 or (not all((valid_float(value) for value in (beta, se, p, n)))) or (float(se) <= 0) or (float(n) <= 0):
                invalid += 1
                continue
            freq = effect_allele_frequency(snp, a1, a2, freq_map)
            if freq is None:
                allele_mismatch += 1
                continue
            if snp in seen:
                duplicate += 1
                continue
            seen.add(snp)
            dst.write(f'{snp}\t{a1}\t{a2}\t{freq:.8g}\t{float(beta):.12g}\t{float(se):.12g}\t{clamp_p(p)}\t{float(n):.12g}\n')
            retained += 1
    return {'outcome_id': outcome.outcome_id, 'label': outcome.label.replace('\n', ' '), 'source_path': str(outcome.source_path), 'prepared_path': str(outcome.prepared_path), 'converter': outcome.converter, 'ancestry': outcome.ancestry, 'primary_eur': outcome.primary_eur, 'total_rows': total, 'retained_target_rows': retained, 'not_target_or_not_in_EUR_LD': not_target, 'allele_mismatch': allele_mismatch, 'invalid_rows': invalid, 'duplicate_rows': duplicate, 'prepared_sha256': sha256(outcome.prepared_path)}

def prepare_outcomes(outcomes: list[Outcome], target_snps: set[str], position_map: dict[tuple[int, int], str], freq_map: dict[str, tuple[str, str, float]]) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for outcome in outcomes:
        require(outcome.source_path)
        print(f'Preparing {outcome.outcome_id} from {outcome.source_path.name}', flush=True)
        if outcome.converter == 'position':
            row = convert_position_outcome(outcome, target_snps, position_map, freq_map)
        elif outcome.converter == 'combined':
            row = convert_combined_outcome(outcome, target_snps, freq_map)
        elif outcome.converter == 'ukb_loose':
            row = convert_ukb_loose_outcome(outcome, target_snps, freq_map)
        else:
            raise ValueError(outcome.converter)
        rows.append(row)
        print(f"  retained {row['retained_target_rows']:,} target variants", flush=True)
    audit = pd.DataFrame(rows)
    audit.to_csv(PREPARED / '01_GWAS_preparation_audit.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame([{**asdict(outcome), 'source_path': str(outcome.source_path), 'prepared_path': str(outcome.prepared_path)} for outcome in outcomes]).to_csv(PREPARED / '02_outcome_registry.csv', index=False, encoding='utf-8-sig')
    if (audit['retained_target_rows'] <= 0).any():
        bad = audit.loc[audit['retained_target_rows'] <= 0, 'outcome_id'].tolist()
        raise RuntimeError(f'No target variants retained for outcomes: {bad}')
    return audit

def bfile_for_chromosome(chromosome: int) -> Path:
    prefix = LD_COMBINED
    for extension in ('.bed', '.bim', '.fam'):
        require(with_ext(prefix, extension))
    return prefix

def run_smr_only(panel: Panel, outcome: Outcome) -> dict[str, object]:
    directory = RUNS / panel.panel_id / outcome.outcome_id
    directory.mkdir(parents=True, exist_ok=True)
    output_prefix = directory / 'SMR_only'
    result = with_ext(output_prefix, '.smr')
    if not result.exists() or result.stat().st_size == 0:
        code = run_command([str(SMR_EXE), '--bfile', str(bfile_for_chromosome(panel.chromosome)), '--gwas-summary', str(outcome.prepared_path), '--beqtl-summary', str(panel.prefix), '--extract-probe', str(panel.probe_file), '--peqtl-smr', str(INSTRUMENT_P), '--heidi-off', '--thread-num', '1', '--out', str(output_prefix)], directory / 'SMR_only.console.log')
    else:
        code = 0
    return {'panel_id': panel.panel_id, 'outcome_id': outcome.outcome_id, 'chromosome': panel.chromosome, 'exit_code': code, 'result_exists': result.exists() and result.stat().st_size > 0, 'status': 'complete' if result.exists() and result.stat().st_size > 0 else 'no_analyzable_result'}

def parse_smr_only(panels: list[Panel], outcomes: list[Outcome]) -> pd.DataFrame:
    frames: list[pd.DataFrame] = []
    outcome_lookup = {outcome.outcome_id: outcome for outcome in outcomes}
    for panel in panels:
        manifest = pd.read_csv(panel.manifest_file, sep='\t', dtype=str)
        for outcome in outcomes:
            path = RUNS / panel.panel_id / outcome.outcome_id / 'SMR_only.smr'
            if not path.exists() or path.stat().st_size == 0:
                continue
            try:
                frame = pd.read_csv(path, sep='\\s+', engine='python', dtype={'probeID': str})
            except pd.errors.EmptyDataError:
                continue
            if frame.empty or 'probeID' not in frame:
                continue
            if 'Gene' in frame.columns:
                frame = frame.rename(columns={'Gene': 'SMR_Gene_annotation'})
            frame = frame.merge(manifest, on='probeID', how='inner')
            frame = frame.loc[frame['gene'].isin(CANDIDATE_GENES)].copy()
            if frame.empty:
                continue
            item = outcome_lookup[outcome.outcome_id]
            frame['outcome_id'] = item.outcome_id
            frame['outcome_label'] = item.label
            frame['outcome_ancestry'] = item.ancestry
            frame['primary_eur'] = item.primary_eur
            frame['panel_id'] = panel.panel_id
            frame['qtl_type'] = panel.qtl_type
            frame['qtl_source'] = panel.source
            frame['tissue'] = panel.tissue
            frame['qtl_display_base'] = panel.qtl_display
            frame['chromosome'] = panel.chromosome
            frames.append(frame)
    if not frames:
        return pd.DataFrame()
    result = pd.concat(frames, ignore_index=True)
    numeric = ['b_GWAS', 'se_GWAS', 'p_GWAS', 'b_eQTL', 'se_eQTL', 'p_eQTL', 'b_SMR', 'se_SMR', 'p_SMR']
    for column in numeric:
        if column in result:
            result[column] = pd.to_numeric(result[column], errors='coerce')
    result['F_instrument'] = (result['b_eQTL'] / result['se_eQTL']) ** 2
    result['instrument_pass'] = (result['p_eQTL'] <= INSTRUMENT_P) & (result['F_instrument'] >= F_MIN)
    result['SMR_pre_HEIDI_pass'] = (result['p_SMR'] < STRICT_P) & result['instrument_pass']
    result['ci95_lower'] = result['b_SMR'] - 1.96 * result['se_SMR']
    result['ci95_upper'] = result['b_SMR'] + 1.96 * result['se_SMR']
    return result.sort_values(['p_SMR', 'outcome_id', 'gene'])

def run_heidi(panel: Panel, outcome: Outcome, probe_ids: list[str]) -> dict[str, object]:
    directory = RUNS / panel.panel_id / outcome.outcome_id
    probe_file = directory / 'strict_probes_for_HEIDI.txt'
    probe_file.write_text('\n'.join(sorted(set(probe_ids))) + '\n', encoding='utf-8')
    output_prefix = directory / 'targeted_HEIDI'
    result = with_ext(output_prefix, '.smr')
    if not result.exists() or result.stat().st_size == 0:
        code = run_command([str(SMR_EXE), '--bfile', str(bfile_for_chromosome(panel.chromosome)), '--gwas-summary', str(outcome.prepared_path), '--beqtl-summary', str(panel.prefix), '--extract-probe', str(probe_file), '--peqtl-smr', str(INSTRUMENT_P), '--peqtl-heidi', str(INSTRUMENT_P), '--ld-upper-limit', str(LD_UPPER), '--heidi-min-m', '3', '--heidi-max-m', '20', '--thread-num', '1', '--out', str(output_prefix)], directory / 'targeted_HEIDI.console.log')
    else:
        code = 0
    return {'panel_id': panel.panel_id, 'outcome_id': outcome.outcome_id, 'n_probes': len(set(probe_ids)), 'exit_code': code, 'result_exists': result.exists() and result.stat().st_size > 0, 'status': 'complete' if result.exists() and result.stat().st_size > 0 else 'no_HEIDI_result'}

def parse_heidi(panels: list[Panel], outcomes: list[Outcome]) -> pd.DataFrame:
    frames: list[pd.DataFrame] = []
    for panel in panels:
        for outcome in outcomes:
            path = RUNS / panel.panel_id / outcome.outcome_id / 'targeted_HEIDI.smr'
            if not path.exists() or path.stat().st_size == 0:
                continue
            try:
                frame = pd.read_csv(path, sep='\\s+', engine='python', dtype={'probeID': str})
            except pd.errors.EmptyDataError:
                continue
            keep = [column for column in ('probeID', 'p_HEIDI', 'nsnp_HEIDI') if column in frame]
            if 'probeID' not in keep:
                continue
            frame = frame[keep].copy()
            frame['panel_id'] = panel.panel_id
            frame['outcome_id'] = outcome.outcome_id
            frames.append(frame)
    if not frames:
        return pd.DataFrame(columns=['probeID', 'p_HEIDI', 'nsnp_HEIDI', 'panel_id', 'outcome_id'])
    result = pd.concat(frames, ignore_index=True)
    result['p_HEIDI'] = pd.to_numeric(result.get('p_HEIDI'), errors='coerce')
    result['nsnp_HEIDI'] = pd.to_numeric(result.get('nsnp_HEIDI'), errors='coerce')
    return result.drop_duplicates(['panel_id', 'outcome_id', 'probeID'])

def run_all_smr(panels: list[Panel], outcomes: list[Outcome]) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    statuses: list[dict[str, object]] = []
    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = [executor.submit(run_smr_only, panel, outcome) for panel in panels for outcome in outcomes]
        for future in as_completed(futures):
            row = future.result()
            statuses.append(row)
            print(f"SMR {row['outcome_id']} x {row['panel_id']}: {row['status']}", flush=True)
    status = pd.DataFrame(statuses).sort_values(['outcome_id', 'panel_id'])
    status.to_csv(RESULTS / '01_SMR_run_status.csv', index=False, encoding='utf-8-sig')
    smr = parse_smr_only(panels, outcomes)
    if smr.empty:
        raise RuntimeError('No analyzable SMR results were produced')
    smr.to_csv(RESULTS / '02_SMR_only_all_results.csv', index=False, encoding='utf-8-sig')
    panel_lookup = {panel.panel_id: panel for panel in panels}
    outcome_lookup = {outcome.outcome_id: outcome for outcome in outcomes}
    heidi_rows: list[dict[str, object]] = []
    queue = smr.loc[smr['SMR_pre_HEIDI_pass']]
    with ThreadPoolExecutor(max_workers=3) as executor:
        futures = [executor.submit(run_heidi, panel_lookup[panel_id], outcome_lookup[outcome_id], group['probeID'].astype(str).tolist()) for (panel_id, outcome_id), group in queue.groupby(['panel_id', 'outcome_id'])]
        for future in as_completed(futures):
            row = future.result()
            heidi_rows.append(row)
            print(f"HEIDI {row['outcome_id']} x {row['panel_id']}: {row['status']}", flush=True)
    heidi_status = pd.DataFrame(heidi_rows)
    heidi_status.to_csv(RESULTS / '03_HEIDI_run_status.csv', index=False, encoding='utf-8-sig')
    heidi = parse_heidi(panels, outcomes)
    smr_for_merge = smr.drop(columns=['p_HEIDI', 'nsnp_HEIDI'], errors='ignore')
    merged = smr_for_merge.merge(heidi, on=['panel_id', 'outcome_id', 'probeID'], how='left', validate='many_to_one')
    merged['HEIDI_pass'] = merged['p_HEIDI'] > HEIDI_P
    merged['strict_SMR_HEIDI'] = merged['SMR_pre_HEIDI_pass'] & merged['HEIDI_pass']
    merged['effect_ci'] = merged.apply(lambda row: f'{row.b_SMR:.3f} ({row.ci95_lower:.3f}, {row.ci95_upper:.3f})', axis=1)
    merged['qtl_display'] = merged.apply(lambda row: f'{row.qtl_display_base}\n{row.probeID}' if row.qtl_type == 'mQTL' else row.qtl_display_base, axis=1)
    merged.to_csv(RESULTS / '04_SMR_HEIDI_all_results.csv', index=False, encoding='utf-8-sig')
    strict = merged.loc[merged['strict_SMR_HEIDI']].copy()
    strict.to_csv(RESULTS / '05_strict_positive_all_GWAS.csv', index=False, encoding='utf-8-sig')
    strict_primary = strict.loc[strict['primary_eur']].copy()
    strict_primary.to_csv(RESULTS / '06_strict_positive_primary_EUR.csv', index=False, encoding='utf-8-sig')
    return (merged, strict, strict_primary, status)

def format_p(value: float) -> str:
    if pd.isna(value):
        return 'NA'
    if value < 0.001:
        return f'{value:.2e}'
    return f'{value:.3f}'

def set_plot_style() -> None:
    available = {font.name for font in mpl.font_manager.fontManager.ttflist}
    family = next((name for name in ['Arial', 'Microsoft YaHei', 'Microsoft JhengHei', 'DejaVu Sans'] if name in available), 'DejaVu Sans')
    mpl.rcParams.update({'font.family': family, 'axes.unicode_minus': False, 'font.size': 10, 'axes.labelsize': 11, 'pdf.fonttype': 42, 'ps.fonttype': 42})

def select_figure_rows(frame: pd.DataFrame) -> pd.DataFrame:
    if frame.empty:
        return frame.copy()
    keys = ['outcome_id', 'gene', 'qtl_display_base']
    selected = frame.sort_values(['p_SMR', 'p_HEIDI'], ascending=[True, False]).groupby(keys, as_index=False, sort=False).first()
    return selected.sort_values(['outcome_id', 'gene', 'qtl_type', 'p_SMR'])

def make_forest(frame: pd.DataFrame, stem: str, title: str, subtitle: str) -> None:
    set_plot_style()
    frame = select_figure_rows(frame)
    source_path = RESULTS / f'{stem}_source_data.csv'
    frame.to_csv(source_path, index=False, encoding='utf-8-sig')
    red = '#F8766D'
    if frame.empty:
        fig, ax = plt.subplots(figsize=(12, 5.6), facecolor='white')
        ax.axis('off')
        ax.text(0.02, 0.92, 'A', fontsize=44, fontweight='normal', va='top')
        ax.text(0.12, 0.92, title, fontsize=18, fontweight='bold', va='top')
        ax.text(0.12, 0.84, subtitle, fontsize=11, color='#4B5563', va='top')
        ax.text(0.5, 0.47, 'No association passed the prespecified SMR/HEIDI filters', ha='center', va='center', fontsize=16, color='#374151')
        ax.text(0.5, 0.37, f'P_SMR < 0.05/{N_CANDIDATES} ({STRICT_P:.4g}); P_HEIDI > 0.05; QTL P \u2264 1.6\xd710\u207b\xb3; F \u2265 10', ha='center', va='center', fontsize=11, color='#6B7280')
        for extension in ('png', 'pdf', 'svg'):
            fig.savefig(FIGURES / f'{stem}.{extension}', dpi=320 if extension == 'png' else None, bbox_inches='tight')
        plt.close(fig)
        return
    outcome_order = list(dict.fromkeys(frame['outcome_id'].tolist()))
    order_map = {value: i for i, value in enumerate(outcome_order)}
    frame = frame.assign(_order=frame['outcome_id'].map(order_map)).sort_values(['_order', 'gene', 'qtl_type', 'p_SMR'])
    n = len(frame)
    frame = frame.reset_index(drop=True)
    frame['y'] = np.arange(n)[::-1]
    fig_height = max(3.4, 0.64 * n + 2.75)
    fig = plt.figure(figsize=(15.5, fig_height), facecolor='white')
    grid = fig.add_gridspec(1, 2, width_ratios=[5.45, 2.2], left=0.045, right=0.955, top=0.78, bottom=0.25, wspace=0.025)
    table_ax = fig.add_subplot(grid[0, 0])
    forest_ax = fig.add_subplot(grid[0, 1], sharey=table_ax)
    table_ax.set_xlim(0, 1)
    table_ax.set_ylim(-0.55, n - 0.45)
    table_ax.axis('off')
    headers = [('Outcomes', 0.0, 'left'), ('Genes', 0.27, 'left'), ('QTL name', 0.37, 'left'), ('SMR effect (95% CI)', 0.69, 'center'), ('P_SMR', 0.86, 'center'), ('P_HEIDI', 0.97, 'center')]
    for label, x, alignment in headers:
        table_ax.text(x, 1.055, label, transform=table_ax.transAxes, ha=alignment, va='bottom', fontsize=11, fontweight='bold')
    last_outcome: str | None = None
    for row in frame.itertuples(index=False):
        if row.outcome_id != last_outcome:
            table_ax.text(0.0, row.y, row.outcome_label, ha='left', va='center', fontsize=9.5, linespacing=1.2)
            last_outcome = row.outcome_id
        table_ax.text(0.27, row.y, row.gene, ha='left', va='center', fontsize=10, fontweight='bold')
        table_ax.text(0.37, row.y, row.qtl_display, ha='left', va='center', fontsize=8.8, linespacing=1.15)
        table_ax.text(0.69, row.y, row.effect_ci, ha='center', va='center', fontsize=9.2)
        table_ax.text(0.86, row.y, format_p(row.p_SMR), ha='center', va='center', fontsize=9.2)
        table_ax.text(0.97, row.y, format_p(row.p_HEIDI), ha='center', va='center', fontsize=9.2)
    boundaries: list[float] = []
    ids = frame['outcome_id'].tolist()
    ys = frame['y'].tolist()
    for index in range(1, n):
        if ids[index] != ids[index - 1]:
            boundaries.append((ys[index - 1] + ys[index]) / 2)
    for boundary in boundaries:
        table_ax.axhline(boundary, color='#999999', linestyle=(0, (2, 3)), linewidth=1)
        forest_ax.axhline(boundary, color='#999999', linestyle=(0, (2, 3)), linewidth=1)
    forest_ax.axvline(0, color='#222222', linestyle=(0, (5, 4)), linewidth=1.5, zorder=1)
    xerr = np.vstack([frame['b_SMR'] - frame['ci95_lower'], frame['ci95_upper'] - frame['b_SMR']])
    forest_ax.errorbar(frame['b_SMR'], frame['y'], xerr=xerr, fmt='o', color=red, markerfacecolor=red, markeredgecolor='white', markeredgewidth=0.9, ecolor=red, elinewidth=1.8, capsize=4, capthick=1.5, markersize=8, alpha=0.98, zorder=3)
    x_min = min(float(frame['ci95_lower'].min()), 0.0)
    x_max = max(float(frame['ci95_upper'].max()), 0.0)
    span = max(x_max - x_min, 0.02)
    forest_ax.set_xlim(x_min - 0.07 * span, x_max + 0.07 * span)
    forest_ax.set_ylim(-0.55, n - 0.45)
    forest_ax.set_yticks([])
    forest_ax.set_xlabel('SMR effect (beta_SMR, 95% CI)', fontweight='bold')
    forest_ax.spines['top'].set_visible(False)
    forest_ax.spines['right'].set_visible(False)
    forest_ax.grid(axis='x', color='#E5E7EB', linewidth=0.8, zorder=0)
    forest_ax.legend(handles=[Line2D([0], [0], marker='o', color=red, markerfacecolor=red, markeredgecolor='white', markersize=8, linewidth=1.8, label='Vitamin D')], title=None, frameon=False, loc='center left', bbox_to_anchor=(1.02, 0.5))
    fig.text(0.012, 0.965, 'B', fontsize=42, va='top', ha='left')
    for extension in ('png', 'pdf', 'svg'):
        fig.savefig(FIGURES / f'{stem}.{extension}', dpi=320 if extension == 'png' else None, bbox_inches='tight', facecolor='white')
    plt.close(fig)

def write_summaries(panels: list[Panel], outcomes: list[Outcome], coverage: pd.DataFrame, query_status: pd.DataFrame, preparation: pd.DataFrame, merged: pd.DataFrame, strict: pd.DataFrame, strict_primary: pd.DataFrame, ld_audit: dict[str, object]) -> None:
    gene_rows: list[dict[str, object]] = []
    for gene in CANDIDATE_GENES:
        subset = strict.loc[strict['gene'].eq(gene)]
        primary = strict_primary.loc[strict_primary['gene'].eq(gene)]
        gene_rows.append({'candidate_gene': gene, 'strict_positive_any_GWAS': not subset.empty, 'strict_positive_primary_EUR': not primary.empty, 'n_strict_associations_all': int(len(subset)), 'n_strict_associations_primary_EUR': int(len(primary)), 'outcomes_all': '; '.join(sorted(subset['outcome_label'].str.replace('\n', ' ').unique())), 'qtl_types_all': ';'.join(sorted(subset['qtl_type'].unique()))})
    gene_summary = pd.DataFrame(gene_rows)
    gene_summary.to_csv(RESULTS / '07_candidate_gene_intersection_summary.csv', index=False, encoding='utf-8-sig')
    outcome_rows: list[dict[str, object]] = []
    for outcome in outcomes:
        subset = strict.loc[strict['outcome_id'].eq(outcome.outcome_id)]
        outcome_rows.append({'outcome_id': outcome.outcome_id, 'outcome_label': outcome.label.replace('\n', ' '), 'ancestry': outcome.ancestry, 'primary_eur': outcome.primary_eur, 'sample_note': outcome.sample_note, 'overlap_or_limitation': outcome.overlap_note, 'strict_gene_n': int(subset['gene'].nunique()), 'strict_genes': ';'.join(sorted(subset['gene'].unique())), 'strict_association_n': int(len(subset))})
    pd.DataFrame(outcome_rows).to_csv(RESULTS / '08_strict_genes_by_periodontal_outcome.csv', index=False, encoding='utf-8-sig')
    fenland_status = pd.read_csv(EXACT / 'pQTL_FENLAND' / '00_FENLAND_candidate_coverage_and_status.csv', dtype=str)
    fenland_status.to_csv(INVENTORY / '06_FENLAND_candidate_status.csv', index=False, encoding='utf-8-sig')
    audit = {'analysis_time_utc': now_utc(), 'analysis': 'Summary-data-based Mendelian randomization (SMR) with HEIDI', 'candidate_universe_n': N_CANDIDATES, 'candidate_genes': CANDIDATE_GENES, 'strict_thresholds': {'P_SMR': f'< 0.05/{N_CANDIDATES} = {STRICT_P}', 'P_HEIDI': '> 0.05', 'QTL_P': f'<= {INSTRUMENT_P}', 'F': f'>= {F_MIN}', 'HEIDI_LD_upper_r2': LD_UPPER}, 'xQTL_scope_completed': ['eQTLGen whole-blood eQTL', 'GTEx v8 whole-blood sQTL', 'GTEx v8 cultured-fibroblast sQTL', 'McRae LBC/BSGS whole-blood mQTL with official GPL13534 mapping', 'INTERVAL plasma pQTL', 'SCALLOP plasma pQTL (GDF15)'], 'xQTL_scope_not_completed': {'FENLAND': 'Official downloadable candidate summary statistics remain unavailable locally; no value was imputed.', 'McRae_fibroblast_mQTL': 'No distinct McRae fibroblast mQTL BESD exists in the specified SMR Portal resource; the available panel is blood-based.'}, 'ld_reference': ld_audit, 'AR_limitation': 'AR is on chromosome X, but the available 1000 Genomes EUR LD panel contains chromosomes 1-22 only; AR was not HEIDI-analyzable and was not substituted.', 'outcome_count': len(outcomes), 'primary_eur_outcome_count': sum((outcome.primary_eur for outcome in outcomes)), 'panel_subanalysis_count': len(panels), 'all_SMR_rows': int(len(merged)), 'strict_association_count_all_GWAS': int(len(strict)), 'strict_gene_count_all_GWAS': int(strict['gene'].nunique()), 'strict_genes_all_GWAS': sorted(strict['gene'].unique().tolist()), 'strict_association_count_primary_EUR': int(len(strict_primary)), 'strict_gene_count_primary_EUR': int(strict_primary['gene'].nunique()), 'strict_genes_primary_EUR': sorted(strict_primary['gene'].unique().tolist()), 'overlap_warning': 'Several GLIDE/UKB outcomes share participants or phenotype components and must not be interpreted as independent replications.', 'ancestry_warning': 'EAA-only and EAA+EUR results use the locally available EUR LD reference and are labelled exploratory/sensitivity analyses.', 'no_fabrication': True}
    (RESULTS / '09_analysis_audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
    validation = {'all_strict_P_SMR_pass': bool((strict['p_SMR'] < STRICT_P).all()), 'all_strict_P_HEIDI_pass': bool((strict['p_HEIDI'] > HEIDI_P).all()), 'all_strict_QTL_P_pass': bool((strict['p_eQTL'] <= INSTRUMENT_P).all()), 'all_strict_F_pass': bool((strict['F_instrument'] >= F_MIN).all()), 'all_strict_genes_in_candidate_universe': bool(strict['gene'].isin(CANDIDATE_GENES).all()), 'all_CI_contains_beta': bool(((strict['ci95_lower'] <= strict['b_SMR']) & (strict['b_SMR'] <= strict['ci95_upper'])).all()), 'prepared_GWAS_all_have_target_rows': bool((preparation['retained_target_rows'] > 0).all()), 'query_panels_with_instrument': int((query_status['n_target_snps_p_le_1.6e-3'] > 0).sum()), 'query_panel_count': int(len(query_status)), 'candidate_panel_coverage_rows': int(len(coverage))}
    (RESULTS / '10_validation_checks.json').write_text(json.dumps(validation, ensure_ascii=False, indent=2), encoding='utf-8')
    if not all((value for key, value in validation.items() if key.startswith('all_') or key.startswith('prepared_'))):
        raise RuntimeError(f'Validation failed: {validation}')
    readme = f"# Vitamin D candidate genes \xd7 periodontal-disease GWAS: SMR/HEIDI\n\n## Prespecified method\n\n- Candidate genes (N={N_CANDIDATES}): {', '.join(CANDIDATE_GENES)}\n- P_SMR < 0.05/{N_CANDIDATES} = {STRICT_P:.12f}\n- P_HEIDI > 0.05\n- QTL P <= 1.6e-3 and F >= 10\n- HEIDI excludes variants with r\xb2 > 0.9 relative to the lead QTL\n\n## Primary and expanded outcomes\n\nThe primary ancestry-matched set contains GLIDE European clinical periodontitis (HCHS/SOL excluded), UK Biobank European loose teeth, and the requested combined GLIDE/UKB periodontitis\u2013loose-teeth endpoint. The expanded audit additionally includes overlapping GLIDE European, EAA+EUR, and EAA sensitivity datasets. These endpoints are not independent replications.\n\n## Strict results\n\n- All tested GWAS: {len(strict)} associations; {strict['gene'].nunique()} genes ({(', '.join(sorted(strict['gene'].unique())) if not strict.empty else 'none')}).\n- Primary EUR set: {len(strict_primary)} associations; {strict_primary['gene'].nunique()} genes ({(', '.join(sorted(strict_primary['gene'].unique())) if not strict_primary.empty else 'none')}).\n\n## Important boundaries\n\n- AR is on chromosome X and could not be tested with the available autosomal 1000 Genomes EUR LD panel.\n- The EAA-only and trans-ancestry outcomes use EUR LD only as explicitly labelled sensitivity analyses.\n- FENLAND candidate summary statistics were unavailable for an auditable local run; no value was inferred.\n- The specified McRae resource is whole-blood based; no separate McRae fibroblast mQTL panel was substituted.\n- No missing SMR, HEIDI, or QTL value was fabricated.\n"
    (RESULTS / 'README_results.md').write_text(readme, encoding='utf-8')

def copy_script() -> None:
    source = Path(__file__).resolve()
    destination = SCRIPT_COPY / source.name
    if source != destination:
        shutil.copy2(source, destination)

def main() -> None:
    ensure_dirs()
    for path in (SMR_EXE, PLINK_EXE, with_ext(LD_COMBINED, '.bed'), with_ext(LD_COMBINED, '.bim'), with_ext(LD_COMBINED, '.fam')):
        require(path)
    (INVENTORY / '00_candidate_genes.txt').write_text('\n'.join(CANDIDATE_GENES) + '\n', encoding='utf-8')
    panels, coverage = build_panels()
    target_snps, query_status = build_target_snp_union(panels)
    freq_map, position_map, ld_audit = load_reference_maps(target_snps)
    outcomes = outcome_definitions()
    preparation_audit = PREPARED / '01_GWAS_preparation_audit.csv'
    if preparation_audit.exists() and preparation_audit.stat().st_size > 0 and all((outcome.prepared_path.exists() and outcome.prepared_path.stat().st_size > 0 for outcome in outcomes)):
        preparation = pd.read_csv(preparation_audit)
        print('Reusing completed target-only GWAS preparation files', flush=True)
    else:
        preparation = prepare_outcomes(outcomes, target_snps, position_map, freq_map)
    merged, strict, strict_primary, _ = run_all_smr(panels, outcomes)
    write_summaries(panels, outcomes, coverage, query_status, preparation, merged, strict, strict_primary, ld_audit)
    make_forest(strict, 'Figure1_periodontal_SMR_HEIDI_all_GWAS_red', 'Vitamin D candidate genes and periodontal-disease outcomes: SMR/HEIDI', 'Expanded set of available GLIDE/UKB periodontal GWAS; all estimates are shown in red and the Drug column is omitted')
    make_forest(strict_primary, 'Figure1_periodontal_SMR_HEIDI_primary_EUR_red', 'Vitamin D candidate genes and periodontal-disease outcomes: SMR/HEIDI', 'Primary EUR/clinically interpretable endpoints; all estimates are shown in red and the Drug column is omitted')
    copy_script()
    completion = {'completed_utc': now_utc(), 'output_root': str(OUTPUT_ROOT), 'strict_all_rows': int(len(strict)), 'strict_all_genes': sorted(strict['gene'].unique().tolist()), 'strict_primary_rows': int(len(strict_primary)), 'strict_primary_genes': sorted(strict_primary['gene'].unique().tolist())}
    (OUTPUT_ROOT / 'RUN_COMPLETE.json').write_text(json.dumps(completion, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(completion, ensure_ascii=False, indent=2), flush=True)
if __name__ == '__main__':
    main()
