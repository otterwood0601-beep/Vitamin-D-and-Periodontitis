from __future__ import annotations
import make_v4_whole_blood_ymax4 as previous
STEM = 'A_SMR\u6563\u70b9\u56fe_Whole_blood_QTL_GTEx_\u7eb5\u8f74\u4e0a\u96504_GDF15_PLAU\u6807\u6ce8\u53f3\u79fb_20260825'
LABEL_POSITIONS = {'GDF15': (0.22, 3.2), 'PLAU': (0.4, 2.3)}
if __name__ == '__main__':
    previous.main(stem=STEM, label_positions=LABEL_POSITIONS)
