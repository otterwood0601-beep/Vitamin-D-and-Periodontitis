from __future__ import annotations
import pandas as pd
import make_two_legend_revisions as base
STEM = 'A_SMR\u6563\u70b9\u56fe_Whole_blood_QTL_GTEx_\u8840\u6d46\u5408\u5e76_\u6210\u7ea4\u7ef4\u6df1\u84dd_\u56fe\u4f8b\u5185\u79fb_20260825'

def main() -> None:
    frame, labels = base.load_data()
    fig, ax = base.base_axes()
    visible = base.draw_common(ax, frame)
    merged_group = {'Blood QTL': 'Whole blood QTL/GTEx', 'Plasma pQTL': 'Whole blood QTL/GTEx', 'Fibroblast GTEx': 'Cultured fibroblasts'}
    palette = {'Whole blood QTL/GTEx': base.TEAL, 'Cultured fibroblasts': base.BLUE}
    plotted = visible.loc[visible['candidate_highlight'] & visible['source_group'].notna()].copy()
    plotted['plot_group_v3'] = plotted['source_group'].map(merged_group)
    for group in ('Whole blood QTL/GTEx', 'Cultured fibroblasts'):
        part = plotted.loc[plotted['plot_group_v3'].eq(group)]
        ax.scatter(part['b_SMR'], part['minus_log10_p_SMR'], s=38, c=palette[group], alpha=0.92, linewidths=0, zorder=3)
    base.draw_annotations(ax, labels, {'Blood QTL': base.TEAL, 'Plasma pQTL': base.TEAL, 'Fibroblast GTEx': base.BLUE})
    base.add_legend(ax, [('Whole blood QTL/GTEx', base.TEAL), ('Cultured fibroblasts', base.BLUE)])
    export = frame.copy()
    export['plot_group_v3'] = export['source_group'].map(merged_group)
    export.to_csv(base.OUT_DIR / f'{STEM}_source_data.csv', index=False, encoding='utf-8-sig')
    base.save(fig, STEM)
    print(base.OUT_DIR / f'{STEM}.pdf')
if __name__ == '__main__':
    main()
