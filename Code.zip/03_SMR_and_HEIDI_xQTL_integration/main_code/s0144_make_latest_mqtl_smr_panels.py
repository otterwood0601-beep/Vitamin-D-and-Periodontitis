from __future__ import annotations
import argparse
import math
from pathlib import Path
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D
COLORS = {'blue': '#2F6FB0', 'salmon': '#ED7D73', 'dark': '#25364A', 'grey': '#7E8792', 'light': '#E8EDF3', 'red': '#D84A3A', 'purple': '#8172B2', 'green': '#5B8E6B'}

def p_two_sided(beta: np.ndarray | float, se: np.ndarray | float) -> np.ndarray:
    beta_arr = np.asarray(beta, dtype=float)
    se_arr = np.asarray(se, dtype=float)
    z = np.abs(beta_arr / se_arr)
    return np.asarray([math.erfc(float(v) / math.sqrt(2.0)) for v in z])

def neglog10(p: np.ndarray) -> np.ndarray:
    return -np.log10(np.clip(np.asarray(p, dtype=float), 1e-300, 1.0))

def parse_smr_plot(path: Path) -> dict[str, pd.DataFrame | str]:
    lines = path.read_text(encoding='utf-8').splitlines()
    i = 0
    if not lines or not lines[i].startswith('$probe '):
        raise ValueError(f'Not an SMR --plot export: {path}')
    _, n_probe, target_probe = lines[i].split()
    i += 1
    rows = [lines[j].split() for j in range(i, i + int(n_probe))]
    i += int(n_probe)
    probes = pd.DataFrame(rows, columns=['probe', 'chr', 'probe_bp', 'gene', 'gene_start', 'gene_end', 'strand', 'p_smr', 'p_heidi'])
    for col in ['chr', 'probe_bp']:
        probes[col] = pd.to_numeric(probes[col])
    for col in ['gene_start', 'gene_end']:
        probes[col] = pd.to_numeric(probes[col], errors='coerce')
    for col in ['p_smr', 'p_heidi']:
        probes[col] = pd.to_numeric(probes[col], errors='coerce')
    _, n_snp = lines[i].split()[:2]
    i += 1
    rows = [lines[j].split() for j in range(i, i + int(n_snp))]
    i += int(n_snp)
    snps = pd.DataFrame(rows, columns=['snp', 'chr', 'bp', 'a1', 'a2'])
    snps[['chr', 'bp']] = snps[['chr', 'bp']].apply(pd.to_numeric)
    _, n_gwas = lines[i].split()[:2]
    i += 1
    rows = [lines[j].split() for j in range(i, i + int(n_gwas))]
    i += int(n_gwas)
    gwas = pd.DataFrame(rows, columns=['snp', 'b_gwas', 'se_gwas'])
    gwas[['b_gwas', 'se_gwas']] = gwas[['b_gwas', 'se_gwas']].apply(pd.to_numeric)
    _, n_qtl_probes = lines[i].split()[:2]
    i += 1
    qtl_frames: list[pd.DataFrame] = []
    for _ in range(int(n_qtl_probes)):
        probe, n_rows = lines[i].split()
        i += 1
        rows = [lines[j].split() for j in range(i, i + int(n_rows))]
        i += int(n_rows)
        frame = pd.DataFrame(rows, columns=['snp', 'b_mqtl', 'se_mqtl', 'r_top'])
        frame.insert(0, 'probe', probe)
        frame[['b_mqtl', 'se_mqtl']] = frame[['b_mqtl', 'se_mqtl']].apply(pd.to_numeric)
        frame['r_top'] = pd.to_numeric(frame['r_top'], errors='coerce')
        qtl_frames.append(frame)
    mqtl = pd.concat(qtl_frames, ignore_index=True)
    _, n_gene = lines[i].split()[:2]
    i += 1
    rows = [lines[j].split() for j in range(i, i + int(n_gene))]
    genes = pd.DataFrame(rows, columns=['chr', 'start', 'end', 'gene', 'strand'])
    genes[['chr', 'start', 'end']] = genes[['chr', 'start', 'end']].apply(pd.to_numeric)
    return {'target_probe': target_probe, 'probes': probes, 'snps': snps, 'gwas': gwas, 'mqtl': mqtl, 'genes': genes}

def read_smr_row(smr_only: Path, heidi: Path, probe: str) -> pd.Series:
    smr = pd.read_csv(smr_only, sep='\t', dtype=str)
    heidi_df = pd.read_csv(heidi, sep='\t', dtype=str)
    hit = smr.loc[smr['probeID'].eq(probe)]
    hhit = heidi_df.loc[heidi_df['probeID'].eq(probe)]
    if len(hit) != 1 or len(hhit) != 1:
        raise ValueError(f'Expected exactly one SMR and HEIDI row for {probe}; got {len(hit)} and {len(hhit)}')
    row = hit.iloc[0].astype(object).copy()
    hrow = hhit.iloc[0]
    row['p_HEIDI'] = hrow['p_HEIDI']
    row['nsnp_HEIDI'] = hrow['nsnp_HEIDI']
    for col in ['ProbeChr', 'Probe_bp', 'topSNP_chr', 'topSNP_bp', 'Freq', 'b_GWAS', 'se_GWAS', 'p_GWAS', 'b_eQTL', 'se_eQTL', 'p_eQTL', 'b_SMR', 'se_SMR', 'p_SMR', 'p_HEIDI', 'nsnp_HEIDI']:
        row[col] = pd.to_numeric(row[col], errors='coerce')
    return row

def build_plot_tables(data: dict, result: pd.Series) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    snps = data['snps'].drop_duplicates('snp')
    gwas = data['gwas'].drop_duplicates('snp').merge(snps[['snp', 'chr', 'bp', 'a1', 'a2']], on='snp', how='inner', validate='one_to_one')
    gwas = gwas.loc[gwas['se_gwas'].gt(0)].copy()
    gwas['p_gwas'] = p_two_sided(gwas['b_gwas'].values, gwas['se_gwas'].values)
    gwas['minus_log10_p'] = neglog10(gwas['p_gwas'].values)
    target = data['mqtl'].loc[data['mqtl']['probe'].eq(data['target_probe'])].copy()
    target = target.drop_duplicates('snp').merge(snps[['snp', 'chr', 'bp', 'a1', 'a2']], on='snp', how='inner', validate='one_to_one')
    target = target.loc[target['se_mqtl'].gt(0)].copy()
    target['p_mqtl'] = p_two_sided(target['b_mqtl'].values, target['se_mqtl'].values)
    target['minus_log10_p'] = neglog10(target['p_mqtl'].values)
    target['r2_top'] = target['r_top'].pow(2)
    scatter = target.merge(gwas[['snp', 'b_gwas', 'se_gwas', 'p_gwas']], on='snp', how='inner', validate='one_to_one')
    scatter['is_top'] = scatter['snp'].eq(result['topSNP'])
    if scatter.empty:
        raise ValueError('The SMR plot export contains no LD-selected SNPs shared by mQTL and GWAS')
    return (gwas, target, scatter)

def fmt_p(value: float) -> str:
    if not np.isfinite(value):
        return 'not run'
    if value < 0.001:
        return f'{value:.2e}'
    return f'{value:.4f}'.rstrip('0').rstrip('.')

def panel_label(ax: mpl.axes.Axes, label: str, x: float, y: float) -> None:
    ax.text(x, y, label, transform=ax.transAxes, fontsize=22, fontweight='bold', va='top')

def plot_gene_track(ax: mpl.axes.Axes, genes: pd.DataFrame, xmin: float, xmax: float, chromosome: int, target_gene: str) -> None:
    genes = genes.loc[genes['end'].div(1000000.0).ge(xmin) & genes['start'].div(1000000.0).le(xmax)].sort_values(['start', 'end']).copy()
    span = xmax - xmin
    char_width_mb = span / 125.0
    layout_rows: list[tuple[object, float, float, float]] = []
    for row in genes.itertuples():
        start = max(row.start / 1000000.0, xmin)
        end = min(row.end / 1000000.0, xmax)
        half_label = 0.5 * max(4, len(str(row.gene))) * char_width_mb
        edge_pad = 0.01 * span
        label_x = min(max((start + end) / 2, xmin + half_label + edge_pad), xmax - half_label - edge_pad)
        interval_start = min(start, label_x - half_label) - 0.006 * span
        interval_end = max(end, label_x + half_label) + 0.006 * span
        layout_rows.append((row, label_x, interval_start, interval_end))
    layout_rows.sort(key=lambda item: item[2])
    lanes: list[float] = []
    assignments: list[int] = []
    for _, _, interval_start, interval_end in layout_rows:
        lane = next((j for j, last in enumerate(lanes) if interval_start > last), None)
        if lane is None:
            lane = len(lanes)
            lanes.append(interval_end)
        else:
            lanes[lane] = interval_end
        assignments.append(lane)
    max_lanes = max(assignments) + 1 if assignments else 1
    for (row, label_x, _, _), lane in zip(layout_rows, assignments):
        start = max(row.start / 1000000.0, xmin)
        end = min(row.end / 1000000.0, xmax)
        y = max_lanes - lane
        is_target = str(row.gene).upper() == target_gene.upper()
        color = COLORS['red'] if is_target else '#83917F'
        lw = 2.1 if is_target else 1.0
        left, right = (min(start, end), max(start, end))
        if row.strand == '+':
            xy, xytext = ((right, y), (left, y))
        else:
            xy, xytext = ((left, y), (right, y))
        ax.annotate('', xy=xy, xytext=xytext, arrowprops=dict(arrowstyle='-|>', mutation_scale=7, color=color, lw=lw))
        txt = ax.text(label_x, y + 0.2, row.gene, ha='center', va='bottom', fontsize=6.0, color=color, fontweight='bold' if is_target else 'normal', clip_on=True)
        txt.set_gid('gene_track_label')
    ax.set_xlim(xmin, xmax)
    ax.margins(x=0)
    ax.set_ylim(0.25, max_lanes + 0.85)
    ax.set_yticks([])
    ax.set_xlabel(f'Chromosome {chromosome} position (Mb)')
    ax.spines[['left', 'right', 'top']].set_visible(False)
    ax.grid(False)

def audit_gene_labels(ax: mpl.axes.Axes, tolerance_px: float=1.0) -> dict[str, int]:
    ax.figure.canvas.draw()
    renderer = ax.figure.canvas.get_renderer()
    axis_box = ax.get_window_extent(renderer=renderer)
    labels = [txt for txt in ax.texts if txt.get_gid() == 'gene_track_label']
    boxes = [(txt, txt.get_window_extent(renderer=renderer)) for txt in labels]
    boundary_violations: list[str] = []
    for txt, box in boxes:
        if box.x0 < axis_box.x0 + tolerance_px or box.x1 > axis_box.x1 - tolerance_px:
            boundary_violations.append(txt.get_text())
    overlaps: list[tuple[str, str]] = []
    for i, (left_txt, left_box) in enumerate(boxes):
        expanded = mpl.transforms.Bbox.from_extents(left_box.x0 - tolerance_px, left_box.y0 - tolerance_px, left_box.x1 + tolerance_px, left_box.y1 + tolerance_px)
        for right_txt, right_box in boxes[i + 1:]:
            if expanded.overlaps(right_box):
                overlaps.append((left_txt.get_text(), right_txt.get_text()))
    if boundary_violations or overlaps:
        raise RuntimeError(f'Gene-track label audit failed: boundary={boundary_violations}; overlaps={overlaps}')
    return {'gene_labels_rendered': len(labels), 'gene_label_boundary_violations': 0, 'gene_label_overlaps': 0}

def plot_regional(axes: tuple[mpl.axes.Axes, mpl.axes.Axes, mpl.axes.Axes], gwas: pd.DataFrame, mqtl: pd.DataFrame, genes: pd.DataFrame, result: pd.Series, gene: str, chromosome: int, threshold: float, gwas_label: str, qtl_display: str, qtl_short_label: str) -> None:
    ax_g, ax_q, ax_gene = axes
    probe_mb = float(result['Probe_bp']) / 1000000.0
    top_snp = str(result['topSNP'])
    xmin = probe_mb - 1.0
    xmax = probe_mb + 1.0
    ax_g.scatter(gwas['bp'] / 1000000.0, gwas['minus_log10_p'], s=14, c=COLORS['grey'], alpha=0.75, edgecolors='none', rasterized=True)
    gtop = gwas.loc[gwas['snp'].eq(top_snp)]
    if not gtop.empty:
        ax_g.scatter(gtop['bp'] / 1000000.0, gtop['minus_log10_p'], marker='^', s=82, facecolor='white', edgecolor=COLORS['red'], linewidth=1.7, zorder=4)
    ax_g.axvline(probe_mb, color='#C5CBD3', lw=1, ls='--')
    ax_g.set_ylabel('GWAS  $-\\log_{10}(P)$')
    ax_g.set_xlim(xmin, xmax)
    ax_g.set_ylim(bottom=0)
    ax_g.tick_params(labelbottom=False)
    ax_q.scatter(mqtl['bp'] / 1000000.0, mqtl['minus_log10_p'], s=18, c=COLORS['salmon'], alpha=0.84, edgecolors='none', rasterized=True)
    qtop = mqtl.loc[mqtl['snp'].eq(top_snp)]
    if not qtop.empty:
        ax_q.scatter(qtop['bp'] / 1000000.0, qtop['minus_log10_p'], marker='^', s=88, facecolor='white', edgecolor=COLORS['red'], linewidth=1.7, zorder=4)
        ax_q.annotate(top_snp, (float(qtop['bp'].iloc[0]) / 1000000.0, float(qtop['minus_log10_p'].iloc[0])), xytext=(7, -14), textcoords='offset points', fontsize=8, color=COLORS['dark'])
    ax_q.axvline(probe_mb, color='#C5CBD3', lw=1, ls='--')
    ax_q.set_ylabel(f'{gene} {qtl_short_label}  $-\\log_{{10}}(P)$')
    ax_q.set_xlim(xmin, xmax)
    ax_q.set_ylim(bottom=0)
    ax_q.tick_params(labelbottom=False)
    plot_gene_track(ax_gene, genes, xmin, xmax, chromosome, gene)
    for ax in (ax_g, ax_q):
        ax.grid(axis='y', color=COLORS['light'], linewidth=0.8)
        ax.spines[['top', 'right']].set_visible(False)
        ax.tick_params(labelsize=8.5)
    ax_g.set_title(f'{gene} regional SMR association\n{gwas_label} GWAS x {qtl_display}', loc='left', fontsize=13, fontweight='bold', pad=9)
    badge = f"$P_{{SMR}}$={fmt_p(float(result['p_SMR']))}   $P_{{HEIDI}}$={fmt_p(float(result['p_HEIDI']))}" + '\n' + f'Bonferroni threshold={threshold:.2e}'
    ax_g.text(0.995, 0.95, badge, transform=ax_g.transAxes, ha='right', va='top', fontsize=8.5, bbox=dict(boxstyle='round,pad=0.30', fc='white', ec='#D9DEE5', alpha=0.96))
    panel_label(ax_g, 'A', -0.075, 1.24)

def plot_effect(ax: mpl.axes.Axes, scatter: pd.DataFrame, result: pd.Series, gene: str, threshold: float, gwas_label: str, qtl_display: str, qtl_short_label: str) -> None:
    ordered = scatter.assign(r2_display=scatter['r2_top'].fillna(0.0)).sort_values('r2_display')
    norm = mpl.colors.Normalize(vmin=0, vmax=1)
    cmap = mpl.colormaps['Blues']
    for row in ordered.itertuples():
        color = cmap(norm(row.r2_display))
        ax.errorbar(row.b_mqtl, row.b_gwas, xerr=row.se_mqtl, yerr=row.se_gwas, fmt='o', ms=5.2, mfc=color, mec='#5B6570', mew=0.6, ecolor='#A6ADB5', elinewidth=0.8, capsize=0, alpha=0.92, zorder=2)
    top = scatter.loc[scatter['is_top']]
    if not top.empty:
        row = top.iloc[0]
        ax.errorbar(row['b_mqtl'], row['b_gwas'], xerr=row['se_mqtl'], yerr=row['se_gwas'], fmt='^', ms=11, mfc='white', mec=COLORS['red'], mew=1.8, ecolor=COLORS['red'], elinewidth=1.2, capsize=0, zorder=5)
        ax.annotate(str(result['topSNP']), (row['b_mqtl'], row['b_gwas']), xytext=(7, 8), textcoords='offset points', fontsize=8, color=COLORS['red'])
    slope = float(result['b_SMR'])
    x_min = float((scatter['b_mqtl'] - scatter['se_mqtl']).min())
    x_max = float((scatter['b_mqtl'] + scatter['se_mqtl']).max())
    x_pad = max(0.015, 0.08 * (x_max - x_min))
    xlo, xhi = (min(0.0, x_min) - x_pad, max(0.0, x_max) + x_pad)
    xline = np.linspace(xlo, xhi, 200)
    ax.plot(xline, slope * xline, ls=(0, (5, 4)), lw=1.8, color=COLORS['purple'], label=f'SMR slope = {slope:.3f}')
    ax.axhline(0, color='#D5D9DE', lw=0.8)
    ax.axvline(0, color='#D5D9DE', lw=0.8)
    ax.set_xlim(xlo, xhi)
    ax.set_xlabel(f'{qtl_short_label} effect size')
    ax.set_ylabel('GWAS effect size (log odds)')
    ax.spines[['top', 'right']].set_visible(False)
    ax.grid(color=COLORS['light'], linewidth=0.75)
    ax.set_title(f'{gene} SMR effect-size plot\n{gwas_label} GWAS\n{qtl_display}', loc='left', fontsize=12, fontweight='bold', pad=9)
    handles = [Line2D([0], [0], marker='^', color='none', markerfacecolor='white', markeredgecolor=COLORS['red'], markeredgewidth=1.5, markersize=9, label=f'top cis-{qtl_short_label}'), Line2D([0], [0], marker='o', color='none', markerfacecolor='#8FB8DB', markeredgecolor='#5B6570', markersize=6, label=f'shared cis-{qtl_short_label}s (n={len(scatter)})'), Line2D([0], [0], color=COLORS['purple'], lw=1.8, ls=(0, (5, 4)), label=f'SMR slope={slope:.3f}')]
    ax.legend(handles=handles, frameon=False, fontsize=8.5, loc='upper left')
    badge = f"$P_{{SMR}}$={fmt_p(float(result['p_SMR']))}" + '\n' + f"$P_{{HEIDI}}$={fmt_p(float(result['p_HEIDI']))}" + '\n' + f'threshold={threshold:.2e}'
    ax.text(0.98, 0.04, badge, transform=ax.transAxes, ha='right', va='bottom', fontsize=8.5, bbox=dict(boxstyle='round,pad=0.30', fc='white', ec='#D9DEE5', alpha=0.96))
    panel_label(ax, 'B', -0.14, 1.1)

def save_figure(fig: mpl.figure.Figure, stem: Path) -> None:
    stem.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(stem.with_suffix('.pdf'), bbox_inches='tight')
    fig.savefig(stem.with_suffix('.png'), dpi=320, bbox_inches='tight')
    fig.savefig(stem.with_suffix('.svg'), bbox_inches='tight')
    plt.close(fig)

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--gene', required=True)
    ap.add_argument('--probe', required=True)
    ap.add_argument('--result-probe')
    ap.add_argument('--chromosome', type=int, required=True)
    ap.add_argument('--smr-plot', type=Path, required=True)
    ap.add_argument('--smr-only', type=Path, required=True)
    ap.add_argument('--heidi', type=Path, required=True)
    ap.add_argument('--outdir', type=Path, required=True)
    ap.add_argument('--gwas-id', required=True)
    ap.add_argument('--gwas-label', required=True)
    ap.add_argument('--filename-tag', required=True)
    ap.add_argument('--qtl-display', default='McRae whole-blood mQTL')
    ap.add_argument('--qtl-short-label', default='mQTL')
    ap.add_argument('--qtl-filename-tag', default='McRae_mQTL')
    ap.add_argument('--candidate-count', type=int, default=11)
    ap.add_argument('--allow-nonstrict', action='store_true')
    args = ap.parse_args()
    mpl.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9.5, 'axes.labelcolor': COLORS['dark'], 'axes.edgecolor': COLORS['dark'], 'xtick.color': COLORS['dark'], 'ytick.color': COLORS['dark'], 'text.color': COLORS['dark'], 'pdf.fonttype': 42, 'svg.fonttype': 'none'})
    args.outdir.mkdir(parents=True, exist_ok=True)
    figure_dir = args.outdir / 'individual_panels'
    table_dir = args.outdir / 'source_tables'
    figure_dir.mkdir(exist_ok=True)
    table_dir.mkdir(exist_ok=True)
    data = parse_smr_plot(args.smr_plot)
    if str(data['target_probe']) != args.probe:
        raise ValueError(f"Plot target is {data['target_probe']}, expected {args.probe}")
    result_probe = args.result_probe or args.probe
    result = read_smr_row(args.smr_only, args.heidi, result_probe)
    gwas, mqtl, scatter = build_plot_tables(data, result)
    genes = data['genes']
    threshold = 0.05 / args.candidate_count
    p_smr_pass = float(result['p_SMR']) < threshold
    p_heidi_available = np.isfinite(float(result['p_HEIDI']))
    p_heidi_pass = p_heidi_available and float(result['p_HEIDI']) > 0.05
    if not args.allow_nonstrict and (not p_smr_pass):
        raise ValueError(f'{args.gene} does not pass P_SMR < 0.05/{args.candidate_count}')
    if not args.allow_nonstrict and (not p_heidi_pass):
        raise ValueError(f'{args.gene} does not pass P_HEIDI > 0.05')
    stem_prefix = f'{args.gene}_{args.filename_tag}_{args.qtl_filename_tag}'
    gwas.to_csv(table_dir / f'{stem_prefix}_regional_GWAS.tsv', sep='\t', index=False)
    mqtl.to_csv(table_dir / f'{stem_prefix}_regional_QTL.tsv', sep='\t', index=False)
    scatter.to_csv(table_dir / f'{stem_prefix}_SMR_effect_scatter.tsv', sep='\t', index=False)
    fig = plt.figure(figsize=(13.4, 9.4), constrained_layout=True)
    gs = fig.add_gridspec(3, 1, height_ratios=[1.0, 1.0, 2.45])
    axes = (fig.add_subplot(gs[0]), fig.add_subplot(gs[1]), fig.add_subplot(gs[2]))
    plot_regional(axes, gwas, mqtl, genes, result, args.gene, args.chromosome, threshold, args.gwas_label, args.qtl_display, args.qtl_short_label)
    label_audit = audit_gene_labels(axes[2])
    save_figure(fig, figure_dir / f'Figure_A_{stem_prefix}_regional')
    fig, ax = plt.subplots(figsize=(7.2, 5.9), constrained_layout=True)
    plot_effect(ax, scatter, result, args.gene, threshold, args.gwas_label, args.qtl_display, args.qtl_short_label)
    save_figure(fig, figure_dir / f'Figure_B_{stem_prefix}_effect_scatter')
    summary = pd.DataFrame([{'gene': args.gene, 'probe': result_probe, 'plot_probe_alias': args.probe, 'GWAS_id': args.gwas_id, 'GWAS': args.gwas_label, 'QTL': args.qtl_display, 'QTL_short_label': args.qtl_short_label, 'top_snp': result['topSNP'], 'b_SMR': float(result['b_SMR']), 'se_SMR': float(result['se_SMR']), 'p_SMR': float(result['p_SMR']), 'p_HEIDI': float(result['p_HEIDI']), 'candidate_count': args.candidate_count, 'bonferroni_threshold': threshold, 'passes_p_SMR': p_smr_pass, 'HEIDI_available': p_heidi_available, 'passes_p_HEIDI': p_heidi_pass, 'HEIDI_SNPs_reported': int(result['nsnp_HEIDI']) if np.isfinite(float(result['nsnp_HEIDI'])) else pd.NA, 'regional_GWAS_SNPs': len(gwas), 'regional_QTL_SNPs': len(mqtl), 'effect_plot_SNPs': len(scatter), 'duplicate_GWAS_SNPs': int(gwas['snp'].duplicated().sum()), 'duplicate_QTL_SNPs': int(mqtl['snp'].duplicated().sum()), 'missing_effect_values': int(scatter[['b_mqtl', 'se_mqtl', 'b_gwas', 'se_gwas']].isna().sum().sum()), **label_audit}])
    summary.to_csv(table_dir / f'{stem_prefix}_analysis_summary.csv', index=False)
    print(summary.to_string(index=False))
if __name__ == '__main__':
    main()
