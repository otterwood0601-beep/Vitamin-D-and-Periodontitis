from pathlib import Path
import zipfile, xml.etree.ElementTree as ET, json, sys, io, collections
import pandas as pd
sys.stdout.reconfigure(encoding='utf-8')
HERE = Path(__file__).resolve().parent
SOURCE = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u539f\u59cb\u6570\u636e\\03_xQTL\u4e0e\u53c2\u8003\u9762\u677f\\Neavin_Tsuchiya_\u6210\u7ea4\u7ef4\u7ec6\u80de_20261024')
ROOT = HERE / 'Neavin_Tsuchiya_SMR_20261024'
for p in ['tables', 'audit', 'inputs', 'code']:
    (ROOT / p).mkdir(parents=True, exist_ok=True)
GENES = ['VDR', 'PLAU', 'TG', 'MYC', 'BTF3P11', 'PHEX', 'GDF15', 'CYP24A1', 'AR', 'GMNN', 'IL2']
SUBTYPES = ['SIX5+', 'HOXC6+', 'ATF1+', 'TEAD2+', 'KLF10+', 'RXRB+']
ns = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}

def colidx(s):
    n = 0
    for a in s:
        if not a.isalpha():
            break
        n = n * 26 + ord(a) - 64
    return n - 1

def rows(f, sheet):
    with zipfile.ZipFile(f) as z:
        ss = [''.join(t.itertext()) for t in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si', ns)] if 'xl/sharedStrings.xml' in z.namelist() else []
        with z.open(sheet) as h:
            for _, e in ET.iterparse(h, events=['end']):
                if e.tag.endswith('}row'):
                    r = {}
                    for c in e.findall('s:c', ns):
                        v = c.find('s:v', ns)
                        val = v.text if v is not None else ''.join(c.find('s:is', ns).itertext()) if c.find('s:is', ns) is not None else ''
                        if c.get('t') == 's':
                            val = ss[int(val)]
                        r[colidx(c.get('r'))] = val
                    yield r
                    e.clear()
f = SOURCE / 'Neavin2021/13059_2021_2293_MOESM6_ESM.xlsx'
iterator = rows(f, 'xl/worksheets/sheet1.xml')
head = next(iterator)
header = [head.get(i, '') for i in range(max(head) + 1)]
selected = []
counts = collections.Counter()
total = 0
for raw in iterator:
    gene = raw.get(1, '')
    if not gene or not raw.get(0, ''):
        continue
    total += 1
    counts[gene] += 1
    if gene in GENES:
        selected.append({h: raw.get(i, '') for i, h in enumerate(header)})
d = pd.DataFrame(selected, columns=header)
for c in header:
    if c not in ['rsID', 'Gene', 'ENSG_ID', 'Strand', 'Allele 1', 'Allele 2']:
        d[c] = pd.to_numeric(d[c], errors='coerce')
d.to_csv(ROOT / 'tables/Neavin_11genes_original_rows.csv', index=False, encoding='utf-8-sig')
print('NEAVIN_TOTAL', total, 'TARGET_COUNTS', json.dumps({g: counts[g] for g in GENES}), flush=True)
profiles = []
for gene in GENES:
    for st in SUBTYPES:
        q = d[d.Gene == gene]
        p = q[st + '_p-value']
        b = q[st + '_beta']
        t = q[st + '_t-stat']
        profiles.append(dict(dataset='Neavin2021', condition=st, gene=gene, source_rows=len(q), n_P0016_F10=int(((p < 0.0016) & (t * t >= 10)).sum()), min_source_P=float(p.min()) if len(p) else None, source_has_beta=True, source_has_se=False, source_has_t=True, source_has_alleles=True, status='SE can be exactly recovered as abs(beta/t); effect-reference and frequency require verification'))
with zipfile.ZipFile(SOURCE / 'hum0207.v1.eQTL.v1.zip') as z:
    eligible = [n for n in z.namelist() if n.endswith('.bed') and Path(n).name.split('_')[0] not in ['B', 'CD4', 'CD8', 'Mo', 'NK']]
    meta = []
    allrows = []
    for name in eligible:
        with z.open(name) as h:
            q = pd.read_csv(h, sep='\t', dtype=str)
        condition = Path(name).name.replace('_Mvalue09.bed', '')
        qq = q[q.GNAME.isin(GENES)].copy()
        qq['condition'] = condition
        allrows.append(qq)
        meta.append(dict(file=name, rows=len(q), columns=list(q.columns), candidate_rows=len(qq)))
        for gene in GENES:
            r = qq[qq.GNAME == gene]
            profiles.append(dict(dataset='Tsuchiya2020', condition=condition, gene=gene, source_rows=len(r), n_P0016_F10=None, min_source_P=float(pd.to_numeric(r.TBT_P, errors='coerce').min()) if len(r) else None, source_has_beta=False, source_has_se=False, source_has_t=False, source_has_alleles=False, status='Cannot run standard SMR: missing per-allele beta, SE, effect allele, other allele and allele frequency; MVALUE is not effect size'))
    pd.concat(allrows).to_csv(ROOT / 'tables/Tsuchiya_fibroblast_11genes_original_rows.csv', index=False, encoding='utf-8-sig')
    (ROOT / 'audit/Tsuchiya_file_schema.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')
pd.DataFrame(profiles).to_csv(ROOT / 'tables/11genes_input_profile.csv', index=False, encoding='utf-8-sig')
(ROOT / 'audit/source_field_summary.json').write_text(json.dumps(dict(Neavin_total_rows=total, Neavin_candidate_rows=len(d), Neavin_gene_counts={g: counts[g] for g in GENES}, Tsuchiya_fibroblast_files=eligible, Neavin_header=header, Tsuchiya_header=meta[0]['columns'], Neavin_SE_recovery='abs(beta/t-stat), not invented; P-calibrated SE may be needed for small N; original fields preserved', Neavin_effect_allele='Paper states beta counts reference allele; resolve GRCh37 reference before any direction-dependent analysis', Neavin_frequency='MAF is unoriented; cannot use as effect allele frequency without validation'), ensure_ascii=False, indent=2), encoding='utf-8')
print(pd.DataFrame(profiles).query("dataset=='Neavin2021'")[['condition', 'gene', 'source_rows', 'n_P0016_F10', 'min_source_P']].to_string(index=False), flush=True)
print('TSUCHIYA_SCHEMA', json.dumps(meta), flush=True)
print('[DONE]', ROOT, flush=True)
