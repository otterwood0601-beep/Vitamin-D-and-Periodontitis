from pathlib import Path
import importlib.util, json, sys, dataclasses, concurrent.futures as cf, hashlib, shutil
import pandas as pd
from scipy.stats import chi2
sys.stdout.reconfigure(encoding='utf-8')
HERE = Path(__file__).resolve().parent
ROOT = HERE / 'Neavin_Tsuchiya_SMR_20261024'
BASE = HERE / 'GENCORD_SMR_20261023'
PUBLIC = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u8f93\u51fa\\20261024_Neavin_Tsuchiya_\u6210\u7ea4\u7ef4\u7ec6\u80de_SMR')
for p in ['runs', 'audit', 'tables', 'code']:
    (ROOT / p).mkdir(parents=True, exist_ok=True)
spec = importlib.util.spec_from_file_location('neavin_run_reuse', HERE / 'run_gencord_smr_20261023.py')
runner = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = runner
spec.loader.exec_module(runner)
runner.ROOT = ROOT
base, merge, outcomes = runner.modules()
panels = pd.read_csv(ROOT / 'audit/panels.csv').to_dict('records')
q = pd.read_csv(ROOT / 'tables/Neavin_mapped_SMR_inputs.csv')
protocol = json.loads((HERE / 'Fibroblast_SMR_manuscript_standard_20261024/audit/fixed_protocol_before_run.json').read_text(encoding='utf-8'))
protocol.update(scope='Neavin six dermal fibroblast subtypes, 11 genes,14 outcomes; Tsuchiya10 fibroblast conditions assessed but cannot calculate without beta/SE/alleles', caveats=['Neavin79 donors; public significant eQTL union only, not full nominal summary', 'Unoriented source MAF retained separately; QTL effect allele frequency missing; native frequency checks use available pairs only', 'Beta is effect per reference allele, as stated in the original model; reference base verified independently', 'No GDF15 rows in Neavin public eQTL table; missing is not null association', 'Bonferroni denominator11 follows manuscript, not adjustment of all subtype-outcome tests', 'Not gingival-specific'])
(ROOT / 'audit/fixed_protocol_before_run.json').write_text(json.dumps(protocol, ensure_ascii=False, indent=2), encoding='utf-8')
records = {r['outcome_id']: r for r in pd.read_csv(BASE / 'audit/GWAS_source_inventory.csv').to_dict('records')}
coverage = {r['outcome_id']: r for r in json.loads((ROOT / 'audit/GWAS_coverage.json').read_text())}
wanted = set(q.SNP)
freq = {}
position = {}
for gene in q.gene.unique():
    prefix = HERE / 'GENCORD_SMR_relaxed_grid_20261023/inputs/ld' / gene
    for r in pd.read_csv(str(prefix) + '.frq', sep='\\s+').itertuples():
        if str(r.SNP) in wanted:
            freq[str(r.SNP)] = (r.A1, r.A2, float(r.MAF))
    b = pd.read_csv(str(prefix) + '.bim', sep='\\s+', header=None)
    for r in b.itertuples(index=False, name=None):
        if r[1] in wanted:
            position[int(r[0]), int(r[3])] = r[1]

def prep(o):
    mark = ROOT / f'audit/{o.outcome_id}_neavin_full_source.json'
    if mark.exists():
        return json.loads(mark.read_text())
    c = coverage[o.outcome_id]
    if not c['missing'] and (not c['conflicting_cached_variants']):
        result = dict(outcome_id=o.outcome_id, status='complete', method='Reused verified caches with all11 required variants', n_rows=c['covered'])
    else:
        record = records[o.outcome_id]
        source = Path(record['source_path'])
        err = runner.source_precheck(source)
        if err:
            raise RuntimeError(f'{o.outcome_id}: {err}')
        adjusted = dataclasses.replace(o, source_path=source)
        if adjusted.converter == 'gwas_vcf':
            result = merge.convert_gwas_vcf(adjusted, wanted, position, freq)
        elif adjusted.converter == 'position':
            result = base.convert_position_outcome(adjusted, wanted, position, freq)
        elif adjusted.converter == 'combined':
            result = base.convert_combined_outcome(adjusted, wanted, freq)
        elif adjusted.converter == 'ukb_loose':
            result = base.convert_ukb_loose_outcome(adjusted, wanted, freq)
        else:
            raise RuntimeError(o.converter)
        result.update(outcome_id=o.outcome_id, status='complete', method='Original complete GWAS source streamed to add new GMNN variants; absent variants not replaced with proxies')
    mark.write_text(json.dumps(result, indent=2, ensure_ascii=False, default=str), encoding='utf-8')
    print('PREPARED', o.outcome_id, json.dumps(result, ensure_ascii=False, default=str), flush=True)
    return result
with cf.ThreadPoolExecutor(max_workers=2) as pool:
    prepared = list(pool.map(prep, outcomes))
pd.DataFrame(prepared).to_csv(ROOT / 'audit/GWAS_full_source_preparation.csv', index=False, encoding='utf-8-sig')

def run(p, o):
    dest = ROOT / 'runs' / o.outcome_id / p['label']
    dest.mkdir(parents=True, exist_ok=True)
    out = dest / 'SMR_HEIDI'
    log = dest / 'SMR_HEIDI.console.log'
    mark = dest / 'exit.json'
    if mark.exists():
        code = json.loads(mark.read_text())['code']
    else:
        code = runner.cmd([BASE / 'inputs/software/smr.exe', '--bfile', p['ld'], '--gwas-summary', o.prepared_path, '--beqtl-summary', p['prefix'], '--probe', p['probe'], '--peqtl-smr', '.0016', '--peqtl-heidi', '.00157', '--cis-wind', '2000', '--ld-upper-limit', '.9', '--heidi-min-m', '3', '--heidi-max-m', '20', '--thread-num', '1', '--out', out], log)
        mark.write_text(json.dumps({'code': code}), encoding='utf-8')
    file = out.with_suffix('.smr')
    rows = pd.read_csv(file, sep='\\s+', na_values=['NA', '-9']).to_dict('records') if file.exists() and code == 0 else []
    text = log.read_text(encoding='utf-8', errors='replace')
    status = 'estimated' if rows else 'frequency_QC_failed' if code and 'allele frequency' in text.lower() else 'native_error' if code else 'no_usable_common_instrument'
    for r in rows:
        r.update(dataset='Neavin2021', gene=p['gene'], subtype=p['subtype'], outcome_id=o.outcome_id, outcome=o.label.replace('\n', ' '), ancestry=o.ancestry, limitation=o.overlap_note, result_file=str(file), eQTL_donors=79, frequency_check_disabled=False)
        raw = q[(q.gene == p['gene']) & (q.subtype == p['subtype']) & (q.SNP == r['topSNP'])]
        assert len(raw) == 1
        rr = raw.iloc[0]
        r['source_F'] = float(rr.source_F)
        r['F_instrument'] = (r['b_eQTL'] / r['se_eQTL']) ** 2
        r['source_SE'] = float(rr.source_se)
        r['instrument_pass'] = r['p_eQTL'] < 0.0016 and r['source_F'] >= 10 and (r['F_instrument'] >= 10)
        r['HEIDI_available'] = pd.notna(r.get('p_HEIDI'))
        r['HEIDI_pass'] = r['HEIDI_available'] and r['p_HEIDI'] > 0.05
        r['nominal_P_lt_005'] = r['p_SMR'] < 0.05
        r['manuscript_SMR_pass'] = r['p_SMR'] < 0.05 / 11
        r['manuscript_all_pass'] = r['instrument_pass'] and r['HEIDI_pass'] and r['manuscript_SMR_pass']
        assert abs(abs(r['b_eQTL']) - abs(rr.Beta)) < 1e-05 and abs(r['p_eQTL'] - rr.p) < 1e-06
    print('COMPLETE', p['label'], o.outcome_id, status, len(rows), flush=True)
    return (dict(dataset='Neavin2021', gene=p['gene'], subtype=p['subtype'], outcome_id=o.outcome_id, exit_code=code, status=status, n_rows=len(rows), log=str(log)), rows)
statuses = []
rows = []
with cf.ThreadPoolExecutor(max_workers=2) as pool:
    for status, rr in pool.map(lambda x: run(*x), [(p, o) for p in panels for o in outcomes]):
        statuses.append(status)
        rows += rr
        pd.DataFrame(statuses).to_csv(ROOT / 'audit/native_status.csv', index=False, encoding='utf-8-sig')
d = pd.DataFrame(rows)
if len(d):
    d = d.sort_values(['gene', 'subtype', 'outcome_id'])
    assert not d.duplicated(['probeID', 'outcome_id']).any()
    err = float((chi2.sf((d.b_SMR / d.se_SMR) ** 2, 1) - d.p_SMR).abs().max())
    assert err < 1e-05
    assert d.instrument_pass.all()
else:
    err = None
d.to_csv(ROOT / 'tables/Neavin_\u5168\u90e8SMR\u7ed3\u679c.csv', index=False, encoding='utf-8-sig')
if len(d):
    d[d.manuscript_all_pass].to_csv(ROOT / 'tables/Neavin_\u7a3f\u4ef6\u6807\u51c6\u663e\u8457\u7ed3\u679c.csv', index=False, encoding='utf-8-sig')
    d[d.nominal_P_lt_005].to_csv(ROOT / 'tables/Neavin_RAW_P005_\u4ec5\u4f9b\u53c2\u8003.csv', index=False, encoding='utf-8-sig')
profile = pd.read_csv(ROOT / 'tables/11genes_input_profile.csv')
complete = []
for rr in profile.to_dict('records'):
    for o in outcomes:
        hits = [s for s in statuses if rr['dataset'] == 'Neavin2021' and s['gene'] == rr['gene'] and (s['subtype'] == rr['condition']) and (s['outcome_id'] == o.outcome_id)]
        status = hits[0]['status'] if hits else 'missing_beta_SE_alleles' if rr['dataset'] == 'Tsuchiya2020' else 'gene_not_in_public_table' if rr['source_rows'] == 0 else 'no_eligible_P0016_F10_instrument'
        complete.append(dict(dataset=rr['dataset'], condition=rr['condition'], gene=rr['gene'], outcome_id=o.outcome_id, outcome=o.label.replace('\n', ' '), status=status, source_rows=rr['source_rows']))
pd.DataFrame(complete).to_csv(ROOT / 'tables/\u4e24\u6765\u6e90_11\u57fa\u56e0_\u5404\u7ec6\u80de\u6761\u4ef6_14\u7ed3\u5c40_\u5b8c\u6574\u72b6\u6001.csv', index=False, encoding='utf-8-sig')
summary = []
if len(d):
    for (gene, st), sub in d.groupby(['gene', 'subtype']):
        summary.append(dict(gene=gene, subtype=st, estimates=len(sub), min_P=float(sub.p_SMR.min()), nominal=int(sub.nominal_P_lt_005.sum()), manuscript_SMR_pass=int(sub.manuscript_SMR_pass.sum()), HEIDI_available=int(sub.HEIDI_available.sum()), manuscript_all_pass=int(sub.manuscript_all_pass.sum())))
qa = dict(n_native_tasks=len(statuses), n_estimates=len(d), summary=summary, max_P_recompute_error=err, GDF15='Not estimable: absent from Neavin public eQTL table; Tsuchiya lacks beta/SE/alleles', Tsuchiya='Downloaded and scanned10 fibroblast conditions; standard SMR cannot run from released9 columns', complete_status_slots=len(complete), protocol=protocol)
(ROOT / 'audit/QA.json').write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding='utf-8')
pd.DataFrame(summary).to_csv(ROOT / 'tables/\u7ed3\u679c\u6c47\u603b.csv', index=False, encoding='utf-8-sig')
for f in ['acquire_neavin_tsuchiya_20261024.py', 'profile_neavin_tsuchiya_20261024.py', 'prepare_neavin_smr_20261024.py', 'run_neavin_smr_20261024.py']:
    shutil.copy2(HERE / f, ROOT / 'code' / f)
shutil.copytree(ROOT, PUBLIC, dirs_exist_ok=True)
print('[DONE]', json.dumps(qa, ensure_ascii=False), flush=True)
