from pathlib import Path
import importlib.util, sys, json, urllib.request, zipfile, hashlib, concurrent.futures as cf, time
sys.stdout.reconfigure(encoding='utf-8')
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u539f\u59cb\u6570\u636e\\03_xQTL\u4e0e\u53c2\u8003\u9762\u677f\\Neavin_Tsuchiya_\u6210\u7ea4\u7ef4\u7ec6\u80de_20261024')
ROOT.mkdir(parents=True, exist_ok=True)
SOURCES = [('Neavin2021', 'https://www.ebi.ac.uk/europepmc/webservices/rest/PMC7934233/supplementaryFiles', 'Neavin2021_supplementary.zip'), ('Tsuchiya2020', 'https://humandbs-production.ddbj.nig.ac.jp/files/hum0207/hum0207.v1.eQTL.v1.zip', 'hum0207.v1.eQTL.v1.zip'), ('Tsuchiya_dictionary', 'https://humandbs-production.ddbj.nig.ac.jp/files/hum0207/hum0207.v1_header.xlsx', 'hum0207.v1_header.xlsx')]

def one(source):
    label, url, name = source
    dest = ROOT / name
    result = dict(label=label, url=url, destination=str(dest))
    try:
        if not dest.exists():
            part = dest.with_suffix(dest.suffix + '.part')
            if part.exists():
                raise RuntimeError('Existing partial download retained; investigate before resume')
            with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'Research-data-download/1.0'}), timeout=60) as src:
                declared = src.headers.get('Content-Length')
                result['declared_length'] = declared
                first = src.read(4096)
                if not first.startswith(b'PK'):
                    raise RuntimeError('Response is not ZIP/XLSX')
                with part.open('xb') as dst:
                    dst.write(first)
                    total = len(first)
                    last = time.monotonic()
                    while (block := src.read(1024 * 1024)):
                        dst.write(block)
                        total += len(block)
                        if total > 200 * 1024 * 1024:
                            raise RuntimeError('Unexpected archive size exceeds200MB')
                        if time.monotonic() - last > 15:
                            print('DOWNLOAD', label, total, '/', declared, flush=True)
                            last = time.monotonic()
            if declared and total != int(declared):
                raise RuntimeError('Byte-count mismatch')
            with zipfile.ZipFile(part) as z:
                assert z.testzip() is None
            part.rename(dest)
        with zipfile.ZipFile(dest) as z:
            assert z.testzip() is None
            members = [dict(name=m.filename, bytes=m.file_size) for m in z.infolist()]
            result.update(status='verified', bytes=dest.stat().st_size, sha256=hashlib.sha256(dest.read_bytes()).hexdigest(), members=members)
            if dest.suffix == '.zip':
                folder = ROOT / label
                folder.mkdir(exist_ok=True)
                for m in z.infolist():
                    if m.is_dir() or Path(m.filename).suffix.lower() not in ['.xlsx', '.csv', '.txt', '.tsv', '.gz', '.zip', '.xml']:
                        continue
                    target = (folder / m.filename).resolve()
                    assert target.is_relative_to(folder.resolve()) and m.file_size < 300 * 1024 * 1024
                    target.parent.mkdir(parents=True, exist_ok=True)
                    if not target.exists():
                        with z.open(m) as src, target.open('xb') as dst:
                            while (block := src.read(1024 * 1024)):
                                dst.write(block)
        print('VERIFIED', label, result['bytes'], json.dumps(members, ensure_ascii=False), flush=True)
    except Exception as e:
        result.update(status='failed', error=str(e))
        print('ERROR', label, str(e), flush=True)
    return result
records = []
with cf.ThreadPoolExecutor(max_workers=3) as pool:
    for r in pool.map(one, SOURCES):
        records.append(r)
        (ROOT / 'download_manifest.json').write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding='utf-8')
print('[DONE]', ROOT, flush=True)
