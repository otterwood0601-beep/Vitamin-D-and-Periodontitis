from pathlib import Path
import pandas as pd, numpy as np, json, urllib.request, importlib.util, sys, concurrent.futures as cf, math, hashlib
from scipy.stats import norm
sys.stdout.reconfigure(encoding='utf-8')
HERE = Path(__file__).resolve().parent
ROOT = HERE / 'Neavin_Tsuchiya_SMR_20261024'
BASE = HERE / 'GENCORD_SMR_20261023'
LD = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u539f\u59cb\u6570\u636e\\03_xQTL\u4e0e\u53c2\u8003\u9762\u677f\\1000G_EUR\\g1000_eur.bim')
for f in ['inputs/esd', 'inputs/panels', 'inputs/gwas', 'inputs/ld']:
    (ROOT / f).mkdir(parents=True, exist_ok=True)
spec = importlib.util.spec_from_file_location('neavin_runner', HERE / 'run_gencord_smr_20261023.py')
runner = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = runner
spec.loader.exec_module(runner)
d = pd.read_csv(ROOT / 'tables/Neavin_11genes_original_rows.csv')
wanted = set(d.rsID)
mapping = {}
ambiguous = set()
with LD.open() as h:
    for line in h:
        a = line.split()
        if a[1] not in wanted:
            continue
        value = (int(a[0]), int(a[3]), a[4], a[5])
        if a[1] in mapping and mapping[a[1]] != value:
            ambiguous.add(a[1])
        mapping[a[1]] = value
for k in ambiguous:
    mapping.pop(k, None)
refdoc = ROOT / 'audit/GRCh37_reference_sequences.json'
if refdoc.exists():
    reference = json.loads(refdoc.read_text())
else:
    reference = {}
    for gene, q in d.groupby('Gene'):
        chrom = int(q.Chromosome.iloc[0])
        lo = int(q['SNP Location (bp)'].min())
        hi = int(q['SNP Location (bp)'].max())
        url = f'https://grch37.rest.ensembl.org/sequence/region/human/{chrom}:{lo}..{hi}:1?content-type=text/plain'
        req = urllib.request.Request(url, headers={'Accept': 'text/plain', 'User-Agent': 'Scientific-data-verification/1.0'})
        with urllib.request.urlopen(req, timeout=60) as h:
            seq = h.read().decode().strip().upper()
        assert len(seq) == hi - lo + 1 and set(seq) <= set('ACGTN'), (gene, len(seq), lo, hi)
        reference[gene] = dict(chromosome=chrom, start=lo, end=hi, sequence=seq, url=url)
    refdoc.write_text(json.dumps(reference, indent=2), encoding='utf-8')
records = []
excluded = []
for r in d.to_dict('records'):
    rs = r['rsID']
    gene = r['Gene']
    c = int(r['Chromosome'])
    bp = int(r['SNP Location (bp)'])
    if rs not in mapping:
        excluded.append(dict(rsid=rs, reason='Absent or ambiguous LD rsID'))
        continue
    lc, lbp, la1, la2 = mapping[rs]
    if (lc, lbp) != (c, bp):
        excluded.append(dict(rsid=rs, reason='GRCh37 coordinate mismatch'))
        continue
    a1, a2 = (r['Allele 1'], r['Allele 2'])
    ref = reference[gene]['sequence'][bp - reference[gene]['start']]
    if len(a1) != 1 or len(a2) != 1 or {a1, a2} != {la1, la2} or (ref not in {a1, a2}):
        excluded.append(dict(rsid=rs, reason='Allele mismatch or unresolved reference'))
        continue
    other = next((a for a in [a1, a2] if a != ref))
    for st in ['SIX5+', 'HOXC6+', 'ATF1+', 'TEAD2+', 'KLF10+', 'RXRB+']:
        beta = r[st + '_beta']
        t = r[st + '_t-stat']
        p = r[st + '_p-value']
        se = abs(beta / t)
        z = norm.isf(p / 2)
        se_smr = abs(beta) / z
        records.append(dict(gene=gene, subtype=st, probe=r['ENSG_ID'] + '_' + st.replace('+', 'pos'), gene_id=r['ENSG_ID'], SNP=rs, Chr=c, Bp=bp, A1=ref, A2=other, Freq='NA', Beta=beta, se=se_smr, p=p, source_se=se, source_t=t, source_F=t * t, F_SMR=z * z, source_MAF=r['MAF'], source_A1=a1, source_A2=a2, ProbeBp=int(r['Gene Start (bp)']) if r['Strand'] == '+' else int(r['Gene End (bp)']), Strand=r['Strand']))
m = pd.DataFrame(records)
m.to_csv(ROOT / 'tables/Neavin_mapped_SMR_inputs.csv', index=False, encoding='utf-8-sig')
panels = []
for (gene, st), q in m.groupby(['gene', 'subtype']):
    strong = q[(q.p < 0.0016) & (q.source_F >= 10) & (q.F_SMR >= 10)]
    if strong.empty:
        continue
    label = 'Neavin_' + gene + '_' + st.replace('+', 'pos')
    esd = ROOT / 'inputs/esd' / (label + '.esd')
    q[['Chr', 'SNP', 'Bp', 'A1', 'A2', 'Freq', 'Beta', 'se', 'p']].to_csv(esd, sep='\t', index=False)
    probe = q.probe.iloc[0]
    flist = ROOT / 'inputs/panels' / (label + '.flist')
    prefix = flist.with_suffix('')
    pd.DataFrame([[q.Chr.iloc[0], probe, 0, q.ProbeBp.iloc[0], gene, q.Strand.iloc[0], str(esd)]], columns=['Chr', 'ProbeID', 'GeneticDistance', 'ProbeBp', 'Gene', 'Orientation', 'PathOfEsd']).to_csv(flist, sep='\t', index=False)
    if not prefix.with_suffix('.besd').exists():
        assert runner.cmd([BASE / 'inputs/software/smr.exe', '--eqtl-flist', flist, '--make-besd', '--add-n', '79', '--out', prefix], ROOT / f'audit/{label}_build.log') == 0
    panels.append(dict(label=label, gene=gene, subtype=st, probe=probe, prefix=str(prefix), n_QTL=len(q), n_strong=len(strong), ld=str(HERE / 'GENCORD_SMR_relaxed_grid_20261023/inputs/ld' / gene)))
pd.DataFrame(panels).to_csv(ROOT / 'audit/panels.csv', index=False, encoding='utf-8-sig')
audit = dict(n_source_variants=len(d), n_LD_mapped=m.SNP.nunique(), excluded=excluded, panels=panels, effect_allele='Reference allele, as counted by original model; independently retrieved GRCh37 reference base at every SNP; source hg19 position equals LD position', frequency='MAF orientation not provided. Freq=NA; not guessed or replaced with MAF. Native QC remains enabled for available frequency pairs.', SE='Source SE=abs(beta/t). BESD SE=abs(beta)/norm.isf(P/2) to preserve original small-N P values; both saved.', N='79 independent donors, not 64018 independent samples', gene_set_scope='Public significant fibroblast-eQTL union, not full nominal regional results')
(ROOT / 'audit/Neavin_input_QA.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
print('PANELS', json.dumps(panels), flush=True)
variants = set(m.loc[m.gene.isin([x['gene'] for x in panels]), 'SNP'])
base, merge, outcomes = runner.modules()
caches = []
for o in outcomes:
    candidates = [HERE / 'GENCORD_SMR_relaxed_grid_20261023/inputs/gwas' / (o.outcome_id + '.ma'), HERE / 'Fibroblast_xQTL_P005_20261023/inputs/gwas' / (o.outcome_id + '.ma'), runner.PREVIOUS / 'inputs/gwas' / (o.outcome_id + '.ma')]
    union = pd.concat([pd.read_csv(f, sep='\t') for f in candidates if f.exists()], ignore_index=True)
    union = union[union.SNP.isin(variants)].copy()
    bad = []
    for snp, g in union.groupby('SNP'):
        if len(g.drop_duplicates()) > 1:
            bad.append(snp)
    union = union.drop_duplicates('SNP')
    missing = variants - set(union.SNP)
    union.to_csv(ROOT / f'inputs/gwas/{o.outcome_id}.ma', sep='\t', index=False)
    caches.append(dict(outcome_id=o.outcome_id, required_variants=len(variants), covered=len(union), missing=sorted(missing), conflicting_cached_variants=bad))
    print('CACHE', o.outcome_id, len(union), 'MISSING', sorted(missing), 'CONFLICTS', bad, flush=True)
(ROOT / 'audit/GWAS_coverage.json').write_text(json.dumps(caches, indent=2), encoding='utf-8')
print('[DONE]', flush=True)
