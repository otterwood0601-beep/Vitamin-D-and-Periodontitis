from pathlib import Path
import concurrent.futures as cf, importlib.util, json, sys, hashlib, shutil, math
import pandas as pd
from scipy.stats import chi2
sys.stdout.reconfigure(encoding='utf-8')
HERE = Path(__file__).resolve().parent
BASE = HERE / 'GENCORD_SMR_20261023'
GT = HERE / 'Fibroblast_xQTL_P005_20261023'
GC = HERE / 'GENCORD_SMR_relaxed_grid_20261023'
ROOT = HERE / 'Fibroblast_SMR_manuscript_standard_20261024'
PUBLIC = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u8f93\u51fa\\20261024_\u6210\u7ea4\u7ef4\u7ec6\u80de_SMR_\u6062\u590d\u7a3f\u4ef6\u6807\u51c6')
GENES = ['VDR', 'PLAU', 'TG', 'MYC', 'BTF3P11', 'PHEX', 'GDF15', 'CYP24A1', 'AR', 'GMNN', 'IL2']
spec = importlib.util.spec_from_file_location('restore_reuse_runner', HERE / 'run_gencord_smr_20261023.py')
runner = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = runner
spec.loader.exec_module(runner)
for p in ['audit', 'runs', 'tables', 'code']:
    (ROOT / p).mkdir(parents=True, exist_ok=True)
protocol = dict(top_QTL_P_lt=0.0016, top_F_ge=10, SMR_P_lt=0.05 / 11, HEIDI_P_gt=0.05, HEIDI_QTL_P_le=0.00157, LD_r2_lower=0.05, LD_r2_upper=0.9, cis_window_kb=2000, HEIDI_min_SNPs=3, HEIDI_max_SNPs=20, frequency_check='Native default restored: diff>0.20; abort if proportion>0.05', scope='11 genes; 14 legacy periodontal-related outcomes; cultured fibroblasts only; not gingiva-specific', decision_source='Manuscript-10.20.docx and Translation_VitaminD_Clean_EN_20261022.docx; user confirmed top-QTL P<0.0016', caveats=['Bonferroni denominator11 follows manuscript; does not correct entire multi-source multi-outcome screen', 'GTEx lite is not full regional summary statistics', 'Missing HEIDI is not pass', 'AR chromosome X separately interpreted', 'GENCORD186 cord-derived fibroblasts; GTEx cultured fibroblasts; neither gingival-specific'])
(ROOT / 'audit/fixed_protocol_before_run.json').write_text(json.dumps(protocol, indent=2, ensure_ascii=False), encoding='utf-8')
outcomes = pd.read_csv(BASE / 'audit/GWAS_source_inventory.csv').to_dict('records')
panels = pd.read_csv(GT / 'audit/staged_panel_inventory.csv').to_dict('records')
for p in panels:
    p['dataset'] = p['kind']
    p['gwas_root'] = str(GT / 'inputs/gwas')
    p['ld'] = str(GT / 'inputs/ld' / p['gene'])
profile = pd.read_csv(BASE / 'tables/GENCORD_11gene_input_profile.csv')
for gene in GENES:
    if int(profile.loc[profile.gene == gene, 'n_P_lt_0016_F10'].iloc[0]) > 0:
        panels.append(dict(panel='GENCORD_eQTL_' + gene, dataset='GENCORD_eQTL', gene=gene, prefix=str(BASE / 'inputs/GENCORD_11'), probe=str(pd.read_csv(BASE / 'inputs/GENCORD_11.epi', sep='\\s+', header=None).set_index(4).loc[gene, 1]), gwas_root=str(GC / 'inputs/gwas'), ld=str(GC / 'inputs/ld' / gene)))
inputs = []
for p in panels:
    for suffix in ['.besd', '.epi', '.esi']:
        f = Path(p['prefix'] + suffix)
        inputs.append(f)
    for suffix in ['.bed', '.bim', '.fam']:
        inputs.append(Path(p['ld'] + suffix))
    for o in outcomes:
        inputs.append(Path(p['gwas_root']) / (o['outcome_id'] + '.ma'))
snap = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in set(inputs)}
(ROOT / 'audit/input_hashes_before.json').write_text(json.dumps(snap, ensure_ascii=False, indent=2), encoding='utf-8')

def run(p, o):
    dest = ROOT / 'runs' / o['outcome_id'] / p['panel']
    dest.mkdir(parents=True, exist_ok=True)
    out = dest / 'SMR_HEIDI'
    log = dest / 'SMR_HEIDI.console.log'
    marker = dest / 'exit.json'
    args = [BASE / 'inputs/software/smr.exe', '--bfile', p['ld'], '--gwas-summary', Path(p['gwas_root']) / (o['outcome_id'] + '.ma'), '--beqtl-summary', p['prefix']]
    args += ['--probe', p['probe']] if 'probe' in p else ['--extract-probe', p['probes']]
    args += ['--peqtl-smr', '.0016', '--peqtl-heidi', '.00157', '--cis-wind', '2000', '--ld-upper-limit', '.9', '--heidi-min-m', '3', '--heidi-max-m', '20', '--thread-num', '1', '--out', out]
    code = json.loads(marker.read_text())['code'] if marker.exists() else runner.cmd(args, log)
    marker.write_text(json.dumps({'code': code}), encoding='utf-8')
    text = log.read_text(encoding='utf-8', errors='replace')
    f = out.with_suffix('.smr')
    rows = pd.read_csv(f, sep='\\s+', na_values=['NA', '-9']).to_dict('records') if f.exists() else []
    error = 'frequency_QC_failed' if 'allele frequency' in text.lower() and ('stop' in text.lower() or code) else 'native_error' if code else 'no_estimate'
    if code:
        rows = []
    for r in rows:
        r.update(dataset=p['dataset'], gene=p['gene'], outcome_id=o['outcome_id'], outcome=o['label'].replace('\n', ' '), ancestry=o['ancestry'], limitation=o['overlap_note'], result_file=str(f), frequency_check_disabled=False)
        r['F_instrument'] = (r['b_eQTL'] / r['se_eQTL']) ** 2
        r['instrument_pass'] = r['p_eQTL'] < 0.0016 and r['F_instrument'] >= 10
        r['raw_P_lt_005'] = r['p_SMR'] < 0.05
        r['manuscript_SMR_pass'] = r['p_SMR'] < 0.05 / 11
        r['HEIDI_available'] = pd.notna(r.get('p_HEIDI'))
        r['HEIDI_pass'] = r['HEIDI_available'] and r['p_HEIDI'] > 0.05
        r['manuscript_all_pass'] = r['instrument_pass'] and r['manuscript_SMR_pass'] and r['HEIDI_pass']
    status = dict(dataset=p['dataset'], gene=p['gene'], outcome_id=o['outcome_id'], exit_code=code, n_rows=len(rows), status='estimated' if rows else error, log=str(log))
    print('COMPLETE', p['panel'], o['outcome_id'], code, len(rows), flush=True)
    return (status, rows)
rows = []
statuses = []
with cf.ThreadPoolExecutor(max_workers=2) as pool:
    futures = [pool.submit(run, p, o) for p in panels for o in outcomes]
    for f in cf.as_completed(futures):
        s, r = f.result()
        statuses.append(s)
        rows += r
        pd.DataFrame(statuses).to_csv(ROOT / 'audit/native_status.csv', index=False, encoding='utf-8-sig')
d = pd.DataFrame(rows).sort_values(['dataset', 'gene', 'outcome_id', 'probeID'])
assert not d.duplicated(['dataset', 'outcome_id', 'probeID']).any()
assert (d.p_eQTL < 0.0016).all()
maxerr = float((chi2.sf((d.b_SMR / d.se_SMR) ** 2, 1) - d.p_SMR).abs().max())
assert maxerr < 1e-05
assert all((hashlib.sha256(Path(p).read_bytes()).hexdigest() == h for p, h in snap.items()))
d.to_csv(ROOT / 'tables/SMR_\u7a3f\u4ef6\u6807\u51c6_\u5168\u90e8\u4f30\u8ba1.csv', index=False, encoding='utf-8-sig')
valid = d[d.instrument_pass].copy()
valid.to_csv(ROOT / 'tables/SMR_\u7a3f\u4ef6\u6807\u51c6_F10\u5408\u683c\u4f30\u8ba1.csv', index=False, encoding='utf-8-sig')
valid[valid.gene == 'GDF15'].to_csv(ROOT / 'tables/GDF15_\u7a3f\u4ef6\u6807\u51c6.csv', index=False, encoding='utf-8-sig')
valid[valid.manuscript_all_pass].to_csv(ROOT / 'tables/SMR_\u7a3f\u4ef6\u6807\u51c6_\u663e\u8457\u7ed3\u679c.csv', index=False, encoding='utf-8-sig')
all_status = []
for dataset in ['GENCORD_eQTL', 'GTEx_V8_eQTL', 'GTEx_V8_sQTL']:
    for gene in GENES:
        for o in outcomes:
            hit = [s for s in statuses if s['dataset'] == dataset and s['gene'] == gene and (s['outcome_id'] == o['outcome_id'])]
            sub = valid[(valid.dataset == dataset) & (valid.gene == gene) & (valid.outcome_id == o['outcome_id'])]
            status = hit[0]['status'] if hit else 'no_P0016_F10_instrument' if dataset == 'GENCORD_eQTL' and int(profile.loc[profile.gene == gene, 'source_rows'].iloc[0]) else 'no_source_probe'
            all_status.append(dict(dataset=dataset, gene=gene, outcome_id=o['outcome_id'], outcome=o['label'].replace('\n', ' '), status=status, estimates_F10=len(sub), HEIDI_available=int(sub.HEIDI_available.sum()), manuscript_significant=int(sub.manuscript_all_pass.sum()), min_SMR_P=float(sub.p_SMR.min()) if len(sub) else None))
pd.DataFrame(all_status).to_csv(ROOT / 'tables/11\u57fa\u56e0_14\u7ed3\u5c40_3\u6765\u6e90_\u5b8c\u6574\u72b6\u6001.csv', index=False, encoding='utf-8-sig')
summary = []
for dataset, sub in valid.groupby('dataset'):
    summary.append(dict(dataset=dataset, estimates=len(sub), genes=sub.gene.nunique(), nominal=int(sub.raw_P_lt_005.sum()), manuscript_SMR_pass=int(sub.manuscript_SMR_pass.sum()), manuscript_all_pass=int(sub.manuscript_all_pass.sum()), HEIDI_missing=int((~sub.HEIDI_available).sum()), GDF15_min_P=float(sub.loc[sub.gene == 'GDF15', 'p_SMR'].min())))
qa = dict(summary=summary, n_native_tasks=len(statuses), n_native_nonzero=sum((s['exit_code'] != 0 for s in statuses)), estimates_before_F10=len(d), estimates_F10=len(valid), SMR_P_max_recompute_error=maxerr, input_hashes_unchanged=True, protocol=protocol)
(ROOT / 'audit/QA.json').write_text(json.dumps(qa, indent=2, ensure_ascii=False), encoding='utf-8')
pd.DataFrame(summary).to_csv(ROOT / 'tables/\u7ed3\u679c\u6c47\u603b.csv', index=False, encoding='utf-8-sig')
shutil.copy2(__file__, ROOT / 'code' / Path(__file__).name)
shutil.copytree(ROOT, PUBLIC, dirs_exist_ok=True)
print('[DONE]', json.dumps(qa, ensure_ascii=False), flush=True)
