$ErrorActionPreference = 'Stop'
$taskPython = 'C:\Python314\python.exe'
$taskScripts = 'C:\Users\Lin\Documents\Codex\2026-10-22\d-ecm\output'
& $taskPython -X utf8 (Join-Path $taskScripts 'run_gencord_smr_20261023.py') --phase run
if ($LASTEXITCODE -ne 0) { throw 'SMR workflow failed. Inspect the native logs.' }
& $taskPython -X utf8 (Join-Path $taskScripts 'finalize_gencord_results_20261023.py')
if ($LASTEXITCODE -ne 0) { throw 'Numerical validation or result collation failed.' }
