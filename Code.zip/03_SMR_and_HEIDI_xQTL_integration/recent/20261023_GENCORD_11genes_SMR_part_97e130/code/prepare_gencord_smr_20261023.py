from pathlib import Path
import concurrent.futures as cf
import csv, gzip, hashlib, json, re, struct, urllib.request
ROOT = Path(__file__).parent / 'GENCORD_SMR_20261023'
ROOT.mkdir(exist_ok=True)
(ROOT / 'audit').mkdir(exist_ok=True)
(ROOT / 'inputs').mkdir(exist_ok=True)
GENES = ['VDR', 'PLAU', 'TG', 'MYC', 'BTF3P11', 'PHEX', 'GDF15', 'CYP24A1', 'AR', 'GMNN', 'IL2']

def download(url, path):
    if not path.exists():
        with urllib.request.urlopen(url, timeout=90) as src, path.open('wb') as dst:
            while (block := src.read(1024 * 1024)):
                dst.write(block)
    return path

def gene_lookup(gene):
    url = f'https://rest.ensembl.org/lookup/symbol/homo_sapiens/{gene}?content-type=application/json'
    try:
        with urllib.request.urlopen(url, timeout=45) as h:
            result = json.load(h)
        return (gene, result)
    except Exception as error:
        return (gene, {'error': str(error), 'url': url})

def main():
    meta = download('https://raw.githubusercontent.com/eQTL-Catalogue/eQTL-Catalogue-resources/master/data_tables/dataset_metadata_r7.tsv', ROOT / 'audit/dataset_metadata_r7.tsv')
    with meta.open(encoding='utf-8', newline='') as h:
        m = [r for r in csv.DictReader(h, delimiter='\t') if r['dataset_id'] == 'QTD000100']
    (ROOT / 'audit/GENCORD_metadata.json').write_text(json.dumps(m, indent=2), encoding='utf-8')
    print('METADATA', json.dumps(m), flush=True)
    idx = download('https://ftp.ebi.ac.uk/pub/databases/spot/eQTL/sumstats/QTS000012/QTD000100/QTD000100.all.tsv.gz.tbi', ROOT / 'inputs/QTD000100.all.tsv.gz.tbi')
    print('INDEX_BYTES', idx.stat().st_size, flush=True)
    with cf.ThreadPoolExecutor(max_workers=3) as pool:
        genes = dict(pool.map(gene_lookup, GENES))
    (ROOT / 'audit/ensembl_GRCh38_genes.json').write_text(json.dumps(genes, indent=2), encoding='utf-8')
    for name, record in genes.items():
        print('GENE', name, record.get('id'), record.get('seq_region_name'), record.get('start'), record.get('end'), record.get('error'), flush=True)
    scan = json.loads((ROOT.parent / 'eqtl-history-scan-20261023/scan_results.json').read_text(encoding='utf-8'))
    files = [Path(r['path']) for r in scan['matches'] if r['path'].lower().endswith('.smr') and 'fibroblast' in r['path'].lower()]

    def read_result(path):
        try:
            with path.open(encoding='utf-8-sig', errors='replace') as h:
                header = h.readline().split()
                records = []
                for line in h:
                    if 'GDF15' in line or 'ENSG00000130513' in line:
                        row = dict(zip(header, line.split()))
                        row['source_file'] = str(path)
                        records.append(row)
            return (records, None)
        except Exception as error:
            return ([], {'file': str(path), 'error': str(error)})
    records, errors = ([], [])
    with cf.ThreadPoolExecutor(max_workers=4) as pool:
        for rows, error in pool.map(read_result, files):
            records.extend(rows)
            if error:
                errors.append(error)
    history = {'n_smr_files_read': len(files), 'GDF15_records': records, 'errors': errors, 'scope': 'Existing raw SMR results whose path identifies cultured fibroblasts; other outcomes retained but must not be labelled periodontitis.'}
    (ROOT / 'audit/GTEx_GDF15_raw_SMR_history.json').write_text(json.dumps(history, ensure_ascii=False, indent=2), encoding='utf-8')
    print('HISTORY', len(files), len(records), 'errors', len(errors), flush=True)
    print('[DONE]', flush=True)
if __name__ == '__main__':
    main()
