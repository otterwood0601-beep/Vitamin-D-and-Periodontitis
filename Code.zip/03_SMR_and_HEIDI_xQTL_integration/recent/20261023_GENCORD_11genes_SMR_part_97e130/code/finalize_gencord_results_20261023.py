from pathlib import Path
import hashlib, json, math, re, shutil
import numpy as np
import pandas as pd
from scipy.stats import chi2
ROOT = Path(__file__).parent / 'GENCORD_SMR_20261023'
PUBLIC = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u8f93\u51fa\\20261023_GENCORD_11\u57fa\u56e0_SMR_\u5168\u90e8\u7259\u5468\u7ed3\u5c40')
GENES = ['VDR', 'PLAU', 'TG', 'MYC', 'BTF3P11', 'PHEX', 'GDF15', 'CYP24A1', 'AR', 'GMNN', 'IL2']
LABELS = {'GLIDE_EUR_periodontitis_excl_HCHSSOL': ('\u6b27\u6d32\u4e34\u5e8a\u7259\u5468\u708e\uff08\u6392\u9664HCHS/SOL\uff09', '\u4e34\u5e8a\u7259\u5468\u708e'), 'GLIDE_EUR_periodontitis_incl_HCHSSOL': ('\u6b27\u6d32\u4e34\u5e8a\u7259\u5468\u708e\uff08\u542bHCHS/SOL\uff09', '\u4e34\u5e8a\u7259\u5468\u708e'), 'GLIDE_EAA_EUR_periodontitis': ('\u4e1c\u4e9a\u53ca\u6b27\u6d32\u4e34\u5e8a\u7259\u5468\u708e', '\u4e34\u5e8a\u7259\u5468\u708e'), 'GLIDE_EAA_periodontitis': ('\u4e1c\u4e9a\u4e34\u5e8a\u7259\u5468\u708e', '\u4e34\u5e8a\u7259\u5468\u708e'), 'GLIDE_UKB_periodontitis_loose_teeth': ('\u7259\u5468\u708e\u4e0e\u7259\u9f7f\u677e\u52a8\u590d\u5408\u7ed3\u5c40', '\u590d\u5408\u7ed3\u5c40'), 'UKB_EUR_loose_teeth': ('UKB\u7259\u9f7f\u677e\u52a8', '\u75c7\u72b6'), 'OGWAS_UKB_Neale_painful_gums': ('UKB\u7259\u9f88\u75bc\u75db\uff08Neale\uff09', '\u75c7\u72b6'), 'OGWAS_UKB_Neale_bleeding_gums': ('UKB\u7259\u9f88\u51fa\u8840\uff08Neale\uff09', '\u75c7\u72b6'), 'OGWAS_UKB_MRCIEU_painful_gums': ('UKB\u7259\u9f88\u75bc\u75db\uff08MRC-IEU\uff09', '\u75c7\u72b6'), 'OGWAS_UKB_MRCIEU_bleeding_gums': ('UKB\u7259\u9f88\u51fa\u8840\uff08MRC-IEU\uff09', '\u75c7\u72b6'), 'OGWAS_FinnGen_acute_periodontitis': ('FinnGen\u6025\u6027\u7259\u5468\u708e', '\u4e34\u5e8a\u7259\u5468\u708e'), 'OGWAS_FinnGen_chronic_periodontitis': ('FinnGen\u6162\u6027\u7259\u5468\u708e', '\u4e34\u5e8a\u7259\u5468\u708e'), 'OGWAS_EBI_GCF_IL1beta': ('\u9f88\u6c9f\u6db2IL-1\u03b2\u5347\u9ad8', '\u708e\u75c7\u4ee3\u7406\u6307\u6807'), 'OGWAS_BBJ_periodontal_disease': ('\u65e5\u672cBBJ\u7259\u5468\u75c5', '\u4e34\u5e8a\u7259\u5468\u75c5')}

def main():
    d = pd.read_csv(ROOT / 'tables/GENCORD_all_estimable_SMR_HEIDI.csv')
    full = pd.read_csv(ROOT / 'tables/GENCORD_11genes_14outcomes_complete_status.csv')
    assert len(full) == 154 and len(full[['gene', 'outcome_id']].drop_duplicates()) == 154
    assert len(d) == 49 and len(d[['gene', 'outcome_id']].drop_duplicates()) == 49
    pcheck = chi2.sf((d.b_SMR / d.se_SMR) ** 2, 1)
    bcheck = d.b_GWAS / d.b_eQTL
    secheck = np.sqrt(d.se_GWAS ** 2 / d.b_eQTL ** 2 + d.b_GWAS ** 2 * d.se_eQTL ** 2 / d.b_eQTL ** 4)
    assert np.max(np.abs(pcheck - d.p_SMR)) < 1e-05
    assert np.max(np.abs(bcheck - d.b_SMR)) < 1e-05
    assert np.max(np.abs(secheck - d.se_SMR)) < 1e-05

    def status(r):
        if pd.notna(r.get('p_SMR')):
            return '\u53ef\u4f30\u8ba1\uff1b\u539f\u59cbP\u4e0d\u663e\u8457' if r['p_SMR'] >= 0.05 else '\u539f\u59cbP\u663e\u8457\uff08\u9700\u53e6\u770bHEIDI\uff09'
        t = str(r.get('status', ''))
        if 'frequency' in t:
            return '\u9891\u7387\u4e00\u81f4\u6027\u6838\u9a8c\u5931\u8d25\uff1b\u672a\u4f30\u8ba1'
        if 'chromosome X' in t:
            return '\u6e90\u6570\u636e\u672a\u63d0\u4f9bX\u67d3\u8272\u4f53QTL\uff1b\u672a\u4f30\u8ba1'
        if 'No source QTL' in t:
            return '\u6e90\u6570\u636e\u65e0\u8be5\u57fa\u56e0QTL\u8bb0\u5f55\uff1b\u672a\u4f30\u8ba1'
        if 'legacy P' in t:
            return '\u65e0\u6ee1\u8db3P<0.0016\u3001F>=10\u4e14\u517c\u5bb9LD\u7684\u5de5\u5177\uff1b\u672a\u4f30\u8ba1'
        log = ROOT / f"runs/{r['outcome_id']}/{r['gene']}/SMR_HEIDI.console.log"
        if log.exists() and 'no SNPs in common' in log.read_text(encoding='utf-8', errors='replace'):
            return '\u8be5\u7ed3\u5c40\u4e0eLD\u9762\u677f\u65e0\u5171\u540c\u5de5\u5177\u4f4d\u70b9\uff1b\u672a\u4f30\u8ba1'
        return '\u672a\u4f30\u8ba1\uff1b\u8be6\u89c1\u65e5\u5fd7'
    rows = []
    for r in full.to_dict('records'):
        name, typ = LABELS[r['outcome_id']]
        rows.append({'\u57fa\u56e0': r['gene'], '\u7ed3\u5c40': name, '\u7ed3\u5c40\u7c7b\u522b': typ, '\u72b6\u6001': status(r), 'SMR_P': r.get('p_SMR'), 'HEIDI_P': r.get('p_HEIDI'), 'HEIDI\u4f4d\u70b9\u6570': r.get('nsnp_HEIDI'), 'SMR\u6548\u5e94': r.get('b_SMR'), 'SMR\u6807\u51c6\u8bef': r.get('se_SMR'), '\u5de5\u5177rsID': r.get('topSNP'), '\u5de5\u5177eQTL_P': r.get('p_eQTL'), '\u5de5\u5177F': r.get('F_instrument'), '\u7ed3\u5c40ID': r['outcome_id']})
    human = pd.DataFrame(rows)
    human.to_csv(ROOT / 'tables/GENCORD_11\u57fa\u56e0_14\u7ed3\u5c40_\u7b80\u8868.csv', index=False, encoding='utf-8-sig')
    human[getattr(human, '\u57fa\u56e0') == 'GDF15'].to_csv(ROOT / 'tables/GENCORD_GDF15_\u5168\u90e8\u7259\u5468\u7ed3\u5c40.csv', index=False, encoding='utf-8-sig')
    profile = pd.read_csv(ROOT / 'tables/GENCORD_11gene_input_profile.csv').set_index('gene')
    summary = []
    for gene in GENES:
        sub = d[d.gene == gene]
        row = {'\u57fa\u56e0': gene, '\u53ef\u4f30\u8ba1\u7ed3\u5c40\u6570': len(sub), '\u539f\u59cbP\u5c0f\u4e8e0.05\u7684\u7ed3\u5c40\u6570': int((sub.p_SMR < 0.05).sum()), '\u6700\u4f4eSMR_P': sub.p_SMR.min() if len(sub) else None, '\u72b6\u6001': '; '.join(human.loc[(getattr(human, '\u57fa\u56e0') == gene) & human.SMR_P.isna(), '\u72b6\u6001'].drop_duplicates())}
        summary.append(row)
    pd.DataFrame(summary).to_csv(ROOT / 'tables/GENCORD_11\u57fa\u56e0_\u6c47\u603b.csv', index=False, encoding='utf-8-sig')
    oldpath = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u539f\u59cb\u6570\u636e\\06_\u6700\u7ec8\u6295\u7a3f\u51fa\u56fe\u6e90\u8868\\03_\u6b63\u6587\u56fe3_SMR\u4e0eBulkRNA\\SMR\\04_results\\02_11candidate_combined_all_results_recalculated.csv')
    old = pd.read_csv(oldpath)
    old = old[(old.gene == 'GDF15') & old.panel_id.str.contains('fibroblast', case=False)]
    h = []
    for r in old.to_dict('records'):
        h.append({'\u7248\u672c': 'GTEx V8', 'QTL\u7c7b\u578b': r['qtl_type'], '\u7ed3\u5c40ID': r['outcome_id'], '\u7ed3\u5c40': LABELS.get(r['outcome_id'], (r['outcome_label'], ''))[0], 'SMR_P': r['p_SMR'], 'HEIDI_P': r['p_HEIDI'], '\u72b6\u6001': '\u539f\u59cbP\u4e0d\u663e\u8457\uff1bHEIDI\u7f3a\u5931\uff0c\u4e0d\u7b49\u4e8eHEIDI\u901a\u8fc7', '\u6765\u6e90': str(oldpath)})
    history = json.loads((ROOT / 'audit/GTEx_GDF15_raw_SMR_history.json').read_text(encoding='utf-8'))
    seen = set()
    for r in history['GDF15_records']:
        if not any((part.startswith('eQTL_') and 'fibroblast' in part.lower() for part in r['source_file'].split('\\'))):
            continue
        parts = r['source_file'].split('\\')
        if '04_SMR_runs' in parts:
            outcome = parts[parts.index('04_SMR_runs') + 1]
        else:
            outcome = parts[-2]
        key = (outcome, r['probeID'], r['p_SMR'])
        if key in seen:
            continue
        seen.add(key)
        h.append({'\u7248\u672c': 'GTEx V8\uff0f\u65e7\u7248GTEx\u57f9\u517b\u6210\u7ea4\u7ef4\u7ec6\u80de\u8bb0\u5f55', 'QTL\u7c7b\u578b': 'eQTL', '\u7ed3\u5c40ID': outcome, '\u7ed3\u5c40': outcome, 'SMR_P': float(r['p_SMR']), 'HEIDI_P': None, '\u72b6\u6001': '\u5176\u4ed6\u8bfe\u9898\uff0f\u7ed3\u5c40\uff1b\u4e0d\u80fd\u4ee3\u4f5c\u4e34\u5e8a\u7259\u5468\u708e\u8bc1\u636e\uff1bHEIDI\u7f3a\u5931', '\u6765\u6e90': r['source_file']})
    pd.DataFrame(h).to_csv(ROOT / 'tables/GTEx_GDF15_\u65e2\u5f80SMR\u7ed3\u679c_\u5206\u7ed3\u5c40.csv', index=False, encoding='utf-8-sig')
    scan = json.loads((ROOT.parent / 'eqtl-history-scan-20261023/scan_results.json').read_text(encoding='utf-8'))
    v10 = [r['path'] for r in scan['matches'] if r['path'].lower().endswith('.smr') and 'fibroblast' in r['path'].lower() and ('v10' in r['path'].lower())]
    qa = {'complete_status_rows': len(full), 'native_estimate_rows': len(d), 'nominal_positive_rows': int((d.p_SMR < 0.05).sum()), 'frequency_check_failed': int(getattr(human, '\u72b6\u6001').str.contains('\u9891\u7387\u4e00\u81f4\u6027').sum()), 'no_common_variants': int(getattr(human, '\u72b6\u6001').str.contains('\u65e0\u5171\u540c\u5de5\u5177').sum()), 'max_abs_P_recomputation_error': float(np.max(np.abs(pcheck - d.p_SMR))), 'max_abs_beta_ratio_error': float(np.max(np.abs(bcheck - d.b_SMR))), 'max_abs_delta_method_SE_error': float(np.max(np.abs(secheck - d.se_SMR))), 'historical_GTEx_fibroblast_smr_files_checked': history['n_smr_files_read'], 'historical_GTEx_v10_fibroblast_named_smr_files_found': len(v10), 'GTEx_v10_scope_limit': 'No completed named output found in accessible file inventory. Protected directories and unexpanded archives are outside the lookup.', 'GENCORD_source': 'QTD000100; GENCORD fibroblast; gene expression; N=186; not gingival-specific', 'GENCORD_QTL_P_threshold': 0.0016, 'F_min': 10, 'multiple_testing': 'Raw P requested; no adjusted cutoff used', 'allele_frequency_default_guard': 'Unchanged. More than 5 percent of variants differing by more than 0.20 causes native SMR to stop; no bypass.', 'GWAS_preparation_retry': 'Three initial reads returned transient errno 22. Repeating sequentially read full sources successfully, including gzip EOF/CRC, without changing source data.'}
    (ROOT / 'audit/independent_numerical_validation.json').write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding='utf-8')
    text = '# GENCORD 11\u57fa\u56e0SMR\u4e0eGTEx GDF15\u65e2\u5f80\u7ed3\u679c\u6838\u67e5\n\n\u672c\u8f6e\u6cbf\u7528\u7528\u6237\u786e\u8ba4\u768414\u9879\u7259\u5468\u76f8\u5173\u7ed3\u5c40\uff0c\u5206\u522b\u4fdd\u7559\u4e34\u5e8a\u8bca\u65ad\u3001\u75c7\u72b6\u3001\u590d\u5408\u7ec8\u70b9\u548c\u708e\u75c7\u4ee3\u7406\u6307\u6807\u3002GENCORD\u6837\u672c\u91cf\u4e3a186\uff0c\u6e90\u6587\u4ef6\u662f\u57f9\u517b\u6210\u7ea4\u7ef4\u7ec6\u80degene-expression eQTL\uff0c\u4e0d\u662f\u7259\u9f88\u7279\u5f02eQTL\uff0c\u4e5f\u4e0d\u662fsQTL\u3002\n\n## \u672c\u8f6e\u7ed3\u679c\n\n11\u4e2a\u57fa\u56e0\u5168\u90e8\u6838\u67e5\uff1bVDR\u3001MYC\u3001GDF15\u3001CYP24A1\u53ef\u8fdb\u5165\u539f\u6d41\u7a0b\u95e8\u69db\u7684\u63a2\u7d22\u6027SMR\u300256\u4e2a\u57fa\u56e0-\u7ed3\u5c40\u7ec4\u5408\u5b9e\u9645\u8c03\u7528SMR 1.3.1\uff0c49\u4e2a\u4ea7\u751f\u4f30\u8ba1\uff0c\u539f\u59cbP<0.05\u4e3a0\u30025\u4e2a\u56e0\u9891\u7387\u6838\u9a8c\u5931\u8d25\u4e2d\u6b62\uff0c2\u4e2a\u65e0\u5171\u540c\u5de5\u5177\u4f4d\u70b9\u3002\u6ca1\u6709\u628a\u5931\u8d25\u3001\u7f3a\u5931\u6216\u672a\u68c0\u6d4b\u7684\u7ed3\u679c\u586b\u6210P=1\u3002\n\nGDF15\u5728\u6b27\u6d32\u4e34\u5e8a\u7259\u5468\u708e\u4e2d\u7684SMR P\u7ea60.514\uff1b\u7259\u5468\u708e\u4e0e\u677e\u52a8\u590d\u5408\u7ec8\u70b9\u7ea60.545\uff1bUKB\u7259\u9f7f\u677e\u52a8\u7ea60.264\uff1b\u4e24\u4efd\u7259\u9f88\u51fa\u8840\u7ed3\u5c40\u7ea60.654\u53ca0.495\uff1b\u4e24\u4efd\u7259\u9f88\u75bc\u75db\u7ed3\u5c40\u7ea60.121\u53ca0.976\u3002\u4ee5\u4e0a\u5747\u4e0d\u663e\u8457\u3002FinnGen\u6025\u6027\u3001\u6162\u6027\u53caBBJ\u7259\u5468\u75c5\u56e0\u9891\u7387\u6838\u9a8c\u5931\u8d25\u800c\u672a\u4f30\u8ba1\uff0c\u4e0d\u80fd\u5199\u6210\u9634\u6027\u7ed3\u679c\u3002\n\nPLAU\u548cGMNN\u6ca1\u6709\u540c\u65f6\u6ee1\u8db3\u65e2\u5b9a\u95e8\u69db\u53ca\u73b0\u6709LD\u5339\u914d\u7684\u5de5\u5177\u3002TG\u3001BTF3P11\u3001IL2\u6ca1\u6709\u5bf9\u5e94\u6e90QTL\u8bb0\u5f55\u3002AR\u548cPHEX\u672a\u80fd\u5206\u6790\uff0c\u56e0\u4e3a\u8be5\u6587\u4ef6\u6ca1\u6709X\u67d3\u8272\u4f53QTL\u3002\n\n## \u56fa\u5b9a\u65b9\u6cd5\u4e0e\u6838\u9a8c\n\neQTL P<0.0016\u3001F>=10\uff1b\u7ed3\u679c\u5224\u65ad\u4f7f\u7528\u539f\u59cbSMR P<0.05\uff0c\u4e0d\u4f7f\u75285e-8\u4f5c\u4e3a\u672c\u8f6e\u7b5b\u9009\u95e8\u69db\uff0c\u4e5f\u4e0d\u4f7f\u7528FDR\u95e8\u69db\u3002HEIDI P>0.05\uff1b3\u201320\u4e2a\u4f4d\u70b9\uff0cLD r\xb2\u57280.05\u20130.90\u8303\u56f4\u3002\u5404\u961f\u5217\u5355\u4f4d\u548c\u7ec8\u70b9\u542b\u4e49\u4e0d\u540c\uff0c\u4e0d\u5408\u5e76SMR\u6548\u5e94\u3002\n\n\u590d\u7528\u65e2\u6709GWAS\u8f6c\u6362\u4ee3\u7801\u548c1000 Genomes\u6b27\u6d32LD\u9762\u677f\uff08503\u4eba\uff09\u3002\u65e7GWAS\u7f13\u5b58\u53ea\u8986\u76d6\u65b0\u9700\u6c42178\u4e2a\u4f4d\u70b9\u4e2d\u76847\u201312\u4e2a\uff0c\u56e0\u6b64\u6ca1\u6709\u628a\u65e7\u7f13\u5b58\u76f4\u63a5\u5f53\u5b8c\u6574\u8f93\u5165\uff1b\u672c\u8f6e\u91cd\u65b0\u8bfb\u53d614\u4e2a\u539f\u59cbGWAS\u6587\u4ef6\u3002\u5b9e\u9645\u53ef\u6d4b\u8bd5\u56db\u4e2a\u57fa\u56e0\u7684\u5171\u540c\u9700\u6c42\u4e3a177\u4e2a\u4f4d\u70b9\u3002\u4e1c\u4e9a\u548c\u8de8\u7956\u6e90\u7ed3\u5c40\u4f7f\u7528\u6b27\u6d32LD\uff0c\u4ec5\u53ef\u89c6\u4e3a\u654f\u611f\u6027\u7ed3\u679c\uff1b\u591a\u4e2aUKB\u53caGLIDE\u7ec8\u70b9\u91cd\u53e0\uff0c\u4e0d\u662f14\u6b21\u72ec\u7acb\u9a8c\u8bc1\u3002\n\nGENCORD\u6e90\u5750\u6807\u4e3aGRCh38\u3002\u5148\u6838\u5bf9rsID\u3001\u67d3\u8272\u4f53\u3001\u7b49\u4f4d\u57fa\u56e0\u53cacis\u533a\u57df\uff0c\u518d\u9644\u52a0GRCh37 LD\u4f4d\u7f6e\uff1b\u539f\u59cb\u5750\u6807\u548c\u5168\u90e8\u6392\u9664\u660e\u7ec6\u4fdd\u7559\u3002ALT\u4e3a\u6548\u5e94\u7b49\u4f4d\u57fa\u56e0\uff0c\u9891\u7387\u53d6\u6e90AC/AN\u3002\u539fbeta\u548cSE\u4fdd\u7559\uff1b\u6309SMR\u5bf9\u5c0f\u6837\u672ceQTL\u7684\u5b98\u65b9\u5efa\u8bae\uff0c\u7528\u6e90P\u6362\u7b97\u6b63\u6001\u5c3a\u5ea6SE\uff0c\u907f\u514d\u8f6f\u4ef6\u91cd\u65b0\u8ba1\u7b97\u7684eQTL P\u504f\u79bb\u539f\u503c\uff1b\u8fd9\u4e0d\u662f\u8865\u9020\u7f3a\u5931\u7edf\u8ba1\u91cf\u3002\n\n\u6240\u670949\u6761SMR\u4f30\u8ba1\u5747\u72ec\u7acb\u6838\u5bf9beta\u6bd4\u503c\u3001delta-method\u6807\u51c6\u8bef\u53caP\u503c\uff1b\u5dee\u5f02\u5728\u8f93\u51fa\u820d\u5165\u8bef\u5dee\u8303\u56f4\u3002\u539f\u59cb\u8f93\u5165\u3001\u65e7\u7ed3\u679c\u548c\u56fe\u672a\u8986\u76d6\u3002\n\n## GTEx\u65e2\u5f80\u7ed3\u679c\n\nGDF15\u7684GTEx V8\u57f9\u517b\u6210\u7ea4\u7ef4\u7ec6\u80desQTL\u670910\u6761\u65e2\u5f80\u7259\u5468\u76f8\u5173\u8bb0\u5f55\uff0c\u5747\u672a\u8fbe\u5230\u539f\u59cbP<0.05\uff0c\u6700\u4f4e\u4e34\u5e8a\u7259\u5468\u708eP=0.09304161\uff1bFinnGen\u6162\u6027P=0.893453\uff0c\u6025\u6027P=0.5030792\uff1b\u8fd9\u4e9b\u65e7\u8bb0\u5f55HEIDI\u7f3a\u5931\uff0c\u4e0d\u7b49\u4e8eHEIDI\u901a\u8fc7\u3002\u66f4\u65e9\u7684eQTL-SMR\u8bb0\u5f55\u89c1\u9f8b\u75c5\u548cCOPD\u8bfe\u9898\uff0c\u4e0d\u80fd\u5f53\u4f5c\u7259\u5468\u708eSMR\u8bc1\u636e\u300210\u670820\u65e5\u7259\u5468\u708eeQTL\u5206\u6790\u662f\u4e24\u6837\u672cMR\uff0c\u4e0d\u662fSMR\uff1bGDF15\u6ca1\u6709\u5728\u8be5\u8f6e\u5f62\u6210\u4f30\u8ba1\u3002\u672a\u627e\u5230\u5df2\u5b8c\u6210\u7684GTEx V10\u6210\u7ea4\u7ef4\u7ec6\u80deSMR\u8bb0\u5f55\u3002\n\n## \u6587\u4ef6\n\n- tables/GENCORD_11\u57fa\u56e0_14\u7ed3\u5c40_\u7b80\u8868.csv\uff1a154\u4e2a\u7ec4\u5408\u7684\u6570\u503c\u4e0e\u672a\u4f30\u8ba1\u539f\u56e0\u3002\n- tables/GENCORD_11\u57fa\u56e0_\u6c47\u603b.csv\uff1a11\u4e2a\u57fa\u56e0\u7684\u6c47\u603b\uff0c\u4e0d\u628a\u7f3a\u5931\u5f53\u9634\u6027\u3002\n- tables/GENCORD_GDF15_\u5168\u90e8\u7259\u5468\u7ed3\u5c40.csv\uff1aGDF15\u768414\u4e2a\u7ec8\u70b9\u3002\n- tables/GTEx_GDF15_\u65e2\u5f80SMR\u7ed3\u679c_\u5206\u7ed3\u5c40.csv\uff1aGTEx\u65e2\u5f80\u6570\u503c\u53ca\u539f\u59cb\u8def\u5f84\u3002\n- runs/\uff1a\u6bcf\u9879\u539f\u751fSMR\u8f93\u51fa\u4e0e\u547d\u4ee4\u65e5\u5fd7\uff1baudit/\uff1a\u6765\u6e90\u3001\u8986\u76d6\u7387\u3001\u6392\u9664\u4e0e\u6570\u503c\u6838\u9a8c\uff1bcode/\uff1a\u91cd\u73b0\u4ee3\u7801\u3002\n\n## \u5b98\u65b9\u65b9\u6cd5\u4e0e\u6570\u636e\u8bf4\u660e\n\n- https://www.ebi.ac.uk/eqtl/Data_access/\n- https://github.com/eQTL-Catalogue/eQTL-Catalogue-resources/blob/master/data_tables/dataset_metadata_r7.tsv\n- https://github.com/eQTL-Catalogue/eQTL-Catalogue-resources/blob/master/tabix/Columns.md\n- https://yanglab.westlake.edu.cn/software/smr\n'
    (ROOT / '\u7ed3\u679c\u4e0e\u65b9\u6cd5\u8bf4\u660e.md').write_text(text, encoding='utf-8')
    shutil.copytree(ROOT, PUBLIC, dirs_exist_ok=True)
    shutil.copy2(Path(__file__), PUBLIC / 'code' / Path(__file__).name)
    print(json.dumps(qa, ensure_ascii=False, indent=2), flush=True)
    print(pd.DataFrame(summary).to_string(index=False), flush=True)
    print('[DONE]', PUBLIC, flush=True)
if __name__ == '__main__':
    main()
