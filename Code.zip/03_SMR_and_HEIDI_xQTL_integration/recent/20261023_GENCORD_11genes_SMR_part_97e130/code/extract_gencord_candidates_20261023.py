from pathlib import Path
import collections, csv, gzip, io, json, math, struct, urllib.request
import pandas as pd
from Bio import bgzf
from scipy.stats import norm
ROOT = Path(__file__).parent / 'GENCORD_SMR_20261023'
SOURCE = Path('C:\\Users\\Lin\\Downloads\\QTD000100.all.tsv.gz')
GENE_META = {'VDR': ('ENSG00000111424', '12', 48235320, 48336831, '-'), 'PLAU': ('ENSG00000122861', '10', 75668935, 75677255, '+'), 'TG': ('ENSG00000042832', '8', 133879203, 134147147, '+'), 'MYC': ('ENSG00000136997', '8', 128747680, 128753674, '+'), 'BTF3P11': ('ENSG00000118903', '13', 77502200, 77502970, '+'), 'PHEX': ('ENSG00000102174', 'X', 22050559, 22269427, '+'), 'GDF15': ('ENSG00000130513', '19', 18485541, 18499986, '+'), 'CYP24A1': ('ENSG00000019186', '20', 52769988, 52790512, '-'), 'AR': ('ENSG00000169083', 'X', 66764465, 66950461, '+'), 'GMNN': ('ENSG00000112312', '6', 24775159, 24786327, '+'), 'IL2': ('ENSG00000109471', '4', 123372625, 123377880, '-')}
LD = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u539f\u59cb\u6570\u636e\\03_xQTL\u4e0e\u53c2\u8003\u9762\u677f\\1000G_EUR\\g1000_eur.bim')

class TBI:

    def __init__(self, path):
        raw = gzip.open(path, 'rb').read()
        b = io.BytesIO(raw)
        assert b.read(4) == b'TBI\x01'
        n, fmt, cs, cb, ce, meta, skip, ln = struct.unpack('<8i', b.read(32))
        self.names = b.read(ln).rstrip(b'\x00').decode().split('\x00')
        self.refs = {}
        self.columns = (fmt, cs, cb, ce, meta, skip)
        for name in self.names:
            nb = struct.unpack('<i', b.read(4))[0]
            bins = {}
            for _ in range(nb):
                bn, nc = struct.unpack('<Ii', b.read(8))
                bins[bn] = [struct.unpack('<QQ', b.read(16)) for j in range(nc)]
            ni = struct.unpack('<i', b.read(4))[0]
            linear = struct.unpack('<' + 'Q' * ni, b.read(8 * ni))
            self.refs[name] = (bins, linear)

    def chunks(self, chrom, start, end):
        bins, linear = self.refs[chrom]
        beg = max(0, start - 1)
        end0 = end - 1
        wanted = [0]
        for shift, offset in [(26, 1), (23, 9), (20, 73), (17, 585), (14, 4681)]:
            wanted.extend(range(offset + (beg >> shift), offset + (end0 >> shift) + 1))
        minimum = linear[beg >> 14] if beg >> 14 < len(linear) else 0
        chunks = sorted(((max(s, minimum), e) for bn in wanted for s, e in bins.get(bn, []) if e > minimum))
        merged = []
        for s, e in chunks:
            if merged and s <= merged[-1][1]:
                merged[-1] = (merged[-1][0], max(e, merged[-1][1]))
            else:
                merged.append((s, e))
        return merged

def main():
    (ROOT / 'tables').mkdir(exist_ok=True)
    (ROOT / 'inputs/esd').mkdir(exist_ok=True)
    genes = json.loads((ROOT / 'audit/ensembl_GRCh38_genes.json').read_text())
    if genes.get('GDF15', {}).get('error'):
        url = 'https://rest.ensembl.org/lookup/id/ENSG00000130513?content-type=application/json'
        with urllib.request.urlopen(url, timeout=45) as f:
            genes['GDF15'] = json.load(f)
        (ROOT / 'audit/ensembl_GRCh38_genes.json').write_text(json.dumps(genes, indent=2), encoding='utf-8')
    tbi = TBI(ROOT / 'inputs/QTD000100.all.tsv.gz.tbi')
    print('TBI_CONTIGS', tbi.names, 'COLUMNS', tbi.columns, flush=True)
    stat0 = (SOURCE.stat().st_size, SOURCE.stat().st_mtime_ns)
    with gzip.open(SOURCE, 'rt') as f:
        columns = f.readline().strip().split('\t')
    frames = []
    audit = []
    for gene, (gid, chrom, lo, hi, strand) in GENE_META.items():
        dest = ROOT / f'tables/GENCORD_{gene}_source_rows.tsv'
        if dest.exists():
            frame = pd.read_csv(dest, sep='\t', dtype={'chromosome': str})
            frames.append(frame)
            print('REUSE', gene, len(frame), flush=True)
            continue
        lookup = genes[gene]
        if lookup.get('error'):
            raise RuntimeError(f'No GRCh38 lookup for {gene}')
        assert lookup['id'] == gid and lookup['seq_region_name'] == chrom
        frame = []
        scanned = 0
        chrom_key = chrom if chrom in tbi.names else 'chr' + chrom
        if chrom_key in tbi.refs:
            start = max(1, lookup['start'] - 2100000)
            end = lookup['end'] + 2100000
            chunks = tbi.chunks(chrom_key, start, end)
            with bgzf.BgzfReader(str(SOURCE), 'rb') as reader:
                for begin, finish in chunks:
                    reader.seek(begin)
                    while reader.tell() < finish:
                        line = reader.readline()
                        if not line:
                            break
                        scanned += 1
                        if gid.encode() not in line:
                            continue
                        row = line.decode().rstrip().split('\t')
                        if len(row) == len(columns) and row[0].split('.')[0] == gid and (start <= int(row[2]) <= end):
                            frame.append(row)
        d = pd.DataFrame(frame, columns=columns)
        d['Gene'] = gene
        d = d.drop_duplicates(['gene_id', 'variant', 'rsid'])
        d.to_csv(dest, sep='\t', index=False)
        frames.append(d)
        audit.append({'gene': gene, 'source_rows': len(d), 'regional_rows_examined': scanned, 'chromosome_present': chrom_key in tbi.refs})
        print('EXTRACT', gene, len(d), 'rows examined', scanned, flush=True)
    allrows = pd.concat(frames, ignore_index=True)
    if stat0 != (SOURCE.stat().st_size, SOURCE.stat().st_mtime_ns):
        raise RuntimeError('Source changed while reading')
    wanted = set(allrows.rsid.dropna().astype(str))
    mapping = {}
    ambiguous = set()
    with LD.open() as f:
        for line in f:
            a = line.split()
            if a[1] not in wanted:
                continue
            value = (a[0], int(a[3]), a[4], a[5])
            if a[1] in mapping and mapping[a[1]] != value:
                ambiguous.add(a[1])
            else:
                mapping[a[1]] = value
    for rsid in ambiguous:
        mapping.pop(rsid, None)
    counts = collections.Counter()
    mapped = []
    comp = str.maketrans('ACGT', 'TGCA')
    for r in allrows.to_dict('records'):
        gene = r['Gene']
        rsid = str(r['rsid'])
        meta = GENE_META[gene]
        if rsid not in mapping:
            counts[gene, 'absent_or_ambiguous_LD'] += 1
            continue
        c, bp, a, b = mapping[rsid]
        chrnum = '23' if meta[1] == 'X' else meta[1]
        if c != chrnum or not meta[2] - 2100000 <= bp <= meta[3] + 2100000:
            counts[gene, 'coordinate_mismatch'] += 1
            continue
        alt, ref = (str(r['alt']), str(r['ref']))
        if len(alt) != 1 or len(ref) != 1 or alt not in 'ACGT' or (ref not in 'ACGT'):
            counts[gene, 'non_SNP'] += 1
            continue
        if {alt, ref} != {a, b}:
            alt, ref = (alt.translate(comp), ref.translate(comp))
            if {alt, ref} != {a, b}:
                counts[gene, 'allele_mismatch'] += 1
                continue
        try:
            beta = float(r['beta'])
            source_se = float(r['se'])
            p = float(r['pvalue'])
            af = float(r['ac']) / float(r['an'])
            z = norm.isf(p / 2)
            se = abs(beta) / z
            assert math.isfinite(se) and se > 0 and (source_se > 0) and (0 < af < 1) and (0 < p <= 1)
        except (ValueError, ZeroDivisionError, AssertionError):
            counts[gene, 'invalid_stats'] += 1
            continue
        mapped.append(dict(r, Chr=c, BP_hg19=bp, A1=alt, A2=ref, Freq=af, beta=beta, se_source=source_se, se_SMR=se, F_source=(beta / source_se) ** 2, F_SMR=z * z))
    m = pd.DataFrame(mapped)
    if not m.empty:
        m = m.sort_values(['Gene', 'variant', 'rsid']).drop_duplicates(['Gene', 'variant'])
        conflict = m.duplicated(['Gene', 'rsid'], keep=False)
        m.loc[conflict].to_csv(ROOT / 'audit/ambiguous_gene_rsid_rows.csv', index=False)
        m = m.loc[~conflict].copy()
    m.to_csv(ROOT / 'tables/GENCORD_mapped_GRCh37_QTL.csv', index=False)
    profile = []
    flist = []
    for gene, meta in GENE_META.items():
        d = m[m.Gene == gene] if len(m) else m
        s = allrows[allrows.Gene == gene]
        profile.append({'gene': gene, 'source_rows': len(s), 'LD_compatible_unique_variants': len(d), 'min_source_P': pd.to_numeric(s.pvalue, errors='coerce').min() if len(s) else None, 'min_compatible_P': pd.to_numeric(d.pvalue, errors='coerce').min() if len(d) else None, 'n_P_lt_5e8': int((pd.to_numeric(d.pvalue) < 5e-08).sum()) if len(d) else 0, 'n_P_lt_0016_F10': int(((pd.to_numeric(d.pvalue) < 0.0016) & (d.F_SMR >= 10)).sum()) if len(d) else 0})
        if len(d):
            esd = ROOT / f'inputs/esd/{gene}.esd'
            esd_rows = pd.DataFrame({'Chr': d.Chr, 'SNP': d.rsid, 'Bp': d.BP_hg19, 'A1': d.A1, 'A2': d.A2, 'Freq': d.Freq, 'Beta': d.beta, 'se': d.se_SMR, 'p': d.pvalue})
            esd_rows.to_csv(esd, sep='\t', index=False)
            tss = meta[2] if meta[4] == '+' else meta[3]
            flist.append(['23' if meta[1] == 'X' else meta[1], meta[0], 0, tss, gene, meta[4], str(esd)])
    pd.DataFrame(profile).to_csv(ROOT / 'tables/GENCORD_11gene_input_profile.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(flist, columns=['Chr', 'ProbeID', 'GeneticDistance', 'ProbeBp', 'Gene', 'Orientation', 'PathOfEsd']).to_csv(ROOT / 'inputs/GENCORD_11.flist', sep='\t', index=False)
    (ROOT / 'inputs/GENCORD_LD_variants.txt').write_text('\n'.join(sorted(set(m.rsid))) + '\n', encoding='ascii')
    audit_doc = {'extraction': audit, 'LD_mapping_exclusions': [{'gene': g, 'reason': r, 'n': n} for (g, r), n in counts.items()], 'source_stat': stat0, 'index_contigs': tbi.names, 'rows_after_mapping': len(m), 'SE_handling': 'Original beta and SE retained. BESD SE recalibrated as abs(beta)/Phi_inverse(1-p/2), as recommended by SMR for small eQTL cohorts, to preserve source p-values.', 'coordinate_handling': 'Source GRCh38 positions retained in source rows; GRCh37 LD position attached only after unique rsID, chromosome, cis-region and allele compatibility checks. No unverified position shift.'}
    (ROOT / 'audit/GENCORD_input_QA.json').write_text(json.dumps(audit_doc, indent=2), encoding='utf-8')
    print(pd.DataFrame(profile).to_string(index=False), flush=True)
    print('[DONE]', flush=True)
if __name__ == '__main__':
    main()
