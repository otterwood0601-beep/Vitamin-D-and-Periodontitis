from pathlib import Path
import argparse, concurrent.futures as cf, dataclasses, hashlib, importlib.util, json, math, os, shutil, subprocess, sys, traceback
import pandas as pd
from scipy.stats import chi2
ROOT = Path(__file__).parent / 'GENCORD_SMR_20261023'
CORE = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\03_\u6b63\u6587\u56fe3_SMR\u4e0eBulkRNA\\SMR_HEIDI\u590d\u7b97\\scripts\\20260804_periodontitis_smr_pipeline.py')
MERGE = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\03_\u6b63\u6587\u56fe3_SMR\u4e0eBulkRNA\\SMR_OpenGWAS\u5408\u5e76\\scripts\\20260804_periodontitis_opengwas_merge_pipeline.py')
PREVIOUS = Path('E:\\\u767d\u8272\u5ff5\u73e0\u83cc\\Agent\u6587\u4ef6\u5939\\\u8fd0\u884c\u73af\u5883\u4e0e\u5de5\u4f5c\u533a\\\u4e34\u65f6\u5de5\u4f5c\u533a\\_codex_tmp\\smr_recalc_all_20260924')
SOFTWARE = Path('E:\\\u767d\u8272\u5ff5\u73e0\u83cc\\Agent\u6587\u4ef6\u5939\\\u8fd0\u884c\u73af\u5883\u4e0e\u5de5\u4f5c\u533a\\\u4e34\u65f6\u5de5\u4f5c\u533a\\_codex_tmp\\smr_recalc_20260923\\software')
PUBLIC = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u8f93\u51fa\\20261023_GENCORD_11\u57fa\u56e0_SMR_\u5168\u90e8\u7259\u5468\u7ed3\u5c40')
GENES = ['VDR', 'PLAU', 'TG', 'MYC', 'BTF3P11', 'PHEX', 'GDF15', 'CYP24A1', 'AR', 'GMNN', 'IL2']
PEQTL = 0.0016

def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m

def cmd(args, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8') as h:
        h.write(json.dumps([str(x) for x in args], ensure_ascii=False) + '\n')
        h.flush()
        try:
            p = subprocess.run([str(x) for x in args], stdout=h, stderr=subprocess.STDOUT, timeout=300)
            h.write(f'\nEXIT_CODE={p.returncode}\n')
            return p.returncode
        except subprocess.TimeoutExpired:
            h.write('\nTIMEOUT_AFTER_300S\n')
            return -1

def modules():
    base = load(CORE, 'gencord_reuse_base')
    merge = load(MERGE, 'gencord_reuse_merge')
    base.PREPARED = ROOT / 'inputs/gwas'
    merge.base = base
    outcomes = base.outcome_definitions() + merge.outcome_definitions()
    revised = []
    for outcome in outcomes:
        revised.append(dataclasses.replace(outcome, prepared_path=ROOT / f'inputs/gwas/{outcome.outcome_id}.ma'))
    return (base, merge, revised)

def inventory():
    base, merge, outcomes = modules()
    for folder in ['inputs/gwas', 'inputs/ld', 'inputs/software', 'runs', 'audit', 'tables']:
        (ROOT / folder).mkdir(parents=True, exist_ok=True)
    q = pd.read_csv(ROOT / 'tables/GENCORD_mapped_GRCh37_QTL.csv')
    strong = q[pd.to_numeric(q.pvalue) < PEQTL]
    wanted = set(strong.rsid)
    rows = []
    for o in outcomes:
        path = o.source_path
        if o.outcome_id == 'OGWAS_FinnGen_chronic_periodontitis':
            alt = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u5f52\u6863\\\u3010\u6682\u65f6\u4e0d\u6295\u7a3f\uff0c\u6700\u65b0\u7248Revez 2020 \u2192 FinnGen\u6162\u6027\u7259\u5468\u708e\uff0892  SNP\uff09  \u3011MR\\GWAS\\\u7259\u5468\u75c5 GWAS\\finn-b-K11_PERIODON_CHRON\\finn-b-K11_PERIODON_CHRON.vcf.gz')
            if alt.exists():
                path = alt
        if o.outcome_id == 'GLIDE_UKB_periodontitis_loose_teeth' and (not path.exists()):
            alt = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u5f52\u6863\\\u3010\u6682\u65f6\u4e0d\u6295\u7a3f\uff0c\u6700\u65b0\u7248Revez 2020 \u2192 FinnGen\u6162\u6027\u7259\u5468\u708e\uff0892  SNP\uff09  \u3011MR\\GWAS\\\u7259\u5468\u75c5 GWAS\\GLIDE_UKB_combined\\perio_looseteeth_combined.txt')
            if alt.exists():
                path = alt
        cache = PREVIOUS / f'inputs/gwas/{o.outcome_id}.ma'
        d = pd.read_csv(cache, sep='\t') if cache.exists() else pd.DataFrame(columns=['SNP'])
        covered = wanted & set(d.SNP)
        row = {**dataclasses.asdict(o), 'source_path': str(path), 'prepared_path': str(o.prepared_path), 'source_exists': path.exists(), 'source_bytes': path.stat().st_size if path.exists() else None, 'cache_rows': len(d), 'new_required_variants': len(wanted), 'new_variants_in_old_cache': len(covered), 'missing_from_old_cache': len(wanted - covered)}
        rows.append(row)
    pd.DataFrame(rows).to_csv(ROOT / 'audit/GWAS_source_inventory.csv', index=False, encoding='utf-8-sig')
    print(pd.DataFrame(rows)[['outcome_id', 'source_exists', 'source_bytes', 'new_required_variants', 'new_variants_in_old_cache', 'missing_from_old_cache']].to_string(index=False), flush=True)
    return (base, merge, outcomes, rows, q, strong)

def stage_native(q, strong):
    plink = ROOT / 'inputs/software/plink.exe'
    smr = ROOT / 'inputs/software/smr.exe'
    for src, dst in [(SOFTWARE / 'plink.exe', plink), (SOFTWARE / 'smr/smr-1.3.1-win-x86_64/smr-1.3.1-win.exe', smr)]:
        if not dst.exists():
            shutil.copy2(src, dst)
    profile = pd.read_csv(ROOT / 'tables/GENCORD_11gene_input_profile.csv')
    eligible = list(profile.loc[profile.n_P_lt_0016_F10 > 0, 'gene'])
    ld = {}
    freq = {}
    position = {}
    for gene in eligible:
        found = list((PREVIOUS / 'inputs/ld_regions').glob(f'*_{gene}_*.bed'))
        if len(found) != 1:
            raise RuntimeError(f'LD region {gene}: {found}')
        src = found[0].with_suffix('')
        dst = ROOT / f'inputs/ld/{gene}'
        for ext in ['.bed', '.bim', '.fam']:
            if not dst.with_suffix(ext).exists():
                shutil.copy2(src.with_suffix(ext), dst.with_suffix(ext))
        ld[gene] = dst
        frq = dst.with_suffix('.frq')
        if not frq.exists():
            if cmd([plink, '--bfile', dst, '--freq', '--out', dst], ROOT / f'audit/plink_freq_{gene}.log') != 0:
                raise RuntimeError('PLINK frequency failed')
        f = pd.read_csv(frq, sep='\\s+')
        for r in f.itertuples():
            freq[str(r.SNP)] = (r.A1, r.A2, float(r.MAF))
        with dst.with_suffix('.bim').open() as h:
            for line in h:
                a = line.split()
                key = (int(a[0]), int(a[3]))
                position[key] = a[1]
    panel = ROOT / 'inputs/GENCORD_11'
    if not panel.with_suffix('.besd').exists():
        code = cmd([smr, '--eqtl-flist', ROOT / 'inputs/GENCORD_11.flist', '--make-besd', '--add-n', '186', '--out', panel], ROOT / 'audit/SMR_build_BESD.log')
        if code != 0:
            raise RuntimeError('BESD conversion failed; inspect log')
    return (smr, ld, freq, position, eligible)

def source_precheck(path):
    if not path.exists():
        return 'missing'
    if path.suffix == '.gz':
        return None
    size = path.stat().st_size
    with path.open('rb') as h:
        for at in [0, size // 4, size // 2, 3 * size // 4, max(0, size - 65536)]:
            h.seek(at)
            if b'\x00' in h.read(min(65536, size - at)):
                return 'NUL bytes in source; incomplete/corrupt file'
    return None

def prepare_one(base, merge, o, record, wanted, position, freq):
    out = o.prepared_path
    status = ROOT / f'audit/{o.outcome_id}_preparation.json'
    if out.exists() and status.exists():
        previous = json.loads(status.read_text(encoding='utf-8'))
        if previous.get('status') == 'complete' and previous.get('target_signature') == hashlib.sha256('\n'.join(sorted(wanted)).encode()).hexdigest():
            return previous
    signature = hashlib.sha256('\n'.join(sorted(wanted)).encode()).hexdigest()
    cache = PREVIOUS / f'inputs/gwas/{o.outcome_id}.ma'
    result = {'outcome_id': o.outcome_id, 'target_signature': signature}
    try:
        if record['missing_from_old_cache'] == 0:
            d = pd.read_csv(cache, sep='\t')
            d[d.SNP.isin(wanted)].to_csv(out, sep='\t', index=False)
            result.update(status='complete', method='Reused verified old cache with 100 percent coverage of every newly required QTL variant', retained_target_rows=len(wanted), source=str(cache))
        else:
            source = Path(record['source_path'])
            error = source_precheck(source)
            if error:
                raise RuntimeError(error)
            o = dataclasses.replace(o, source_path=source)
            if o.converter == 'gwas_vcf':
                r = merge.convert_gwas_vcf(o, wanted, position, freq)
            elif o.converter == 'position':
                r = base.convert_position_outcome(o, wanted, position, freq)
            elif o.converter == 'combined':
                r = base.convert_combined_outcome(o, wanted, freq)
            elif o.converter == 'ukb_loose':
                r = base.convert_ukb_loose_outcome(o, wanted, freq)
            else:
                raise RuntimeError(f'Unknown converter {o.converter}')
            result.update(r)
            result.update(status='complete', method='Full original source streamed for new GENCORD QTL variants; no old-cache substitution')
    except Exception as error:
        result.update(status='blocked', error=str(error), traceback=traceback.format_exc())
    status.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print('PREPARED', o.outcome_id, result['status'], result.get('retained_target_rows'), result.get('error', ''), flush=True)
    return result

def run_one(smr, ld, o, gene):
    dest = ROOT / f'runs/{o.outcome_id}/{gene}'
    dest.mkdir(parents=True, exist_ok=True)
    profile = pd.read_csv(ROOT / 'tables/GENCORD_mapped_GRCh37_QTL.csv')
    probe = str(profile.loc[profile.Gene == gene, 'gene_id'].iloc[0])
    out = dest / 'SMR_HEIDI'
    log = dest / 'SMR_HEIDI.console.log'
    if not out.with_suffix('.smr').exists():
        code = cmd([smr, '--bfile', ld[gene], '--gwas-summary', o.prepared_path, '--beqtl-summary', ROOT / 'inputs/GENCORD_11', '--probe', probe, '--peqtl-smr', str(PEQTL), '--peqtl-heidi', str(PEQTL), '--cis-wind', '2000', '--ld-upper-limit', '0.9', '--heidi-min-m', '3', '--heidi-max-m', '20', '--thread-num', '1', '--out', out], log)
    else:
        code = 0
    path = out.with_suffix('.smr')
    rows = []
    if path.exists():
        d = pd.read_csv(path, sep='\\s+', na_values=['NA', '-9'])
        rows = d.to_dict('records')
    for r in rows:
        r.update(gene=gene, outcome_id=o.outcome_id, outcome=o.label.replace('\n', ' '), ancestry=o.ancestry, limitation=o.overlap_note, analysis='GENCORD fibroblast eQTL; legacy instrument threshold; exploratory', eQTL_N=186)
        r['F_instrument'] = (float(r['b_eQTL']) / float(r['se_eQTL'])) ** 2
        r['instrument_pass'] = float(r['p_eQTL']) < PEQTL and r['F_instrument'] >= 10
        r['raw_P_lt_005'] = float(r['p_SMR']) < 0.05
        h = r.get('p_HEIDI')
        r['HEIDI_available'] = pd.notna(h)
        r['HEIDI_pass'] = pd.notna(h) and float(h) > 0.05
        r['SMR_and_HEIDI_pass'] = r['instrument_pass'] and r['raw_P_lt_005'] and r['HEIDI_pass']
        r['strong_5e8_instrument'] = float(r['p_eQTL']) < 5e-08
        r['result_file'] = str(path)
        p_check = chi2.sf((float(r['b_SMR']) / float(r['se_SMR'])) ** 2, 1)
        r['p_SMR_recomputed_from_beta_se'] = p_check
    return ({'gene': gene, 'outcome_id': o.outcome_id, 'exit_code': code, 'n_rows': len(rows), 'log': str(log)}, rows)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase', choices=['inventory', 'prepare', 'run'], default='run')
    args = parser.parse_args()
    base, merge, outcomes, records, q, strong = inventory()
    if args.phase == 'inventory':
        return
    smr, ld, freq, position, eligible = stage_native(q, strong)
    wanted = set(strong.loc[strong.Gene.isin(eligible), 'rsid']) & set(freq)
    print('LOCKED_ELIGIBLE', eligible, 'GWAS_TARGETS', len(wanted), flush=True)
    for record in records:
        cache = PREVIOUS / f"inputs/gwas/{record['outcome_id']}.ma"
        d = pd.read_csv(cache, sep='\t')
        record['missing_from_old_cache'] = len(wanted - set(d.SNP))
    with cf.ThreadPoolExecutor(max_workers=1) as pool:
        prep = list(pool.map(lambda pair: prepare_one(base, merge, pair[0], pair[1], wanted, position, freq), zip(outcomes, records)))
    pd.DataFrame(prep).to_csv(ROOT / 'audit/GWAS_preparation_all_outcomes.csv', index=False, encoding='utf-8-sig')
    if args.phase == 'prepare':
        return
    ready = {r['outcome_id'] for r in prep if r['status'] == 'complete'}
    tasks = [(o, g) for o in outcomes if o.outcome_id in ready for g in eligible]
    results = []
    statuses = []
    with cf.ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(run_one, smr, ld, o, g) for o, g in tasks]
        for future in cf.as_completed(futures):
            status, rows = future.result()
            statuses.append(status)
            results.extend(rows)
            print('SMR', status['outcome_id'], status['gene'], 'exit', status['exit_code'], 'rows', len(rows), flush=True)
    frame = pd.DataFrame(results)
    frame.to_csv(ROOT / 'tables/GENCORD_all_estimable_SMR_HEIDI.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(statuses).to_csv(ROOT / 'audit/native_SMR_run_status.csv', index=False, encoding='utf-8-sig')
    input_profile = pd.read_csv(ROOT / 'tables/GENCORD_11gene_input_profile.csv').set_index('gene')
    full = []
    for o in outcomes:
        for gene in GENES:
            d = frame[(frame.gene == gene) & (frame.outcome_id == o.outcome_id)] if len(frame) else frame
            if len(d):
                full.extend(d.to_dict('records'))
                continue
            p = input_profile.loc[gene]
            if p.source_rows == 0:
                reason = 'No source QTL records; chromosome X absent' if gene in ['AR', 'PHEX'] else 'No source QTL records for gene'
            elif p.n_P_lt_0016_F10 == 0:
                reason = 'No LD-compatible eQTL meeting legacy P<0.0016 and F>=10'
            elif o.outcome_id not in ready:
                reason = 'GWAS preparation blocked; see source audit'
            else:
                log = ROOT / f'runs/{o.outcome_id}/{gene}/SMR_HEIDI.console.log'
                txt = log.read_text(encoding='utf-8', errors='replace') if log.exists() else ''
                if 'allele frequency difference check' in txt:
                    reason = 'Allele-frequency consistency check failed; native SMR stopped without an estimate'
                elif 'no data are included' in txt.lower():
                    reason = 'No usable common variants after native harmonization'
                else:
                    reason = 'Native SMR returned no estimate; inspect log'
            full.append({'gene': gene, 'outcome_id': o.outcome_id, 'outcome': o.label.replace('\n', ' '), 'status': reason})
    pd.DataFrame(full).to_csv(ROOT / 'tables/GENCORD_11genes_14outcomes_complete_status.csv', index=False, encoding='utf-8-sig')
    if len(frame):
        frame[frame.gene == 'GDF15'].to_csv(ROOT / 'tables/GENCORD_GDF15_all_outcomes.csv', index=False, encoding='utf-8-sig')
    qa = {'n_outcomes_requested': len(outcomes), 'n_outcomes_ready': len(ready), 'n_eligible_genes': len(eligible), 'eligible_genes': eligible, 'n_native_tasks': len(statuses), 'n_native_failures': sum((s['exit_code'] != 0 for s in statuses)), 'n_SMR_estimates': len(frame), 'instrument_P_threshold': PEQTL, 'instrument_F_min': 10, 'SMR_significance': 'Raw P<0.05, uncorrected, as requested; no claim of genomewide significance', 'HEIDI_P_threshold': 0.05, 'HEIDI_min_SNPs': 3, 'HEIDI_max_SNPs': 20, 'same_subject_overlap': 'Several GLIDE and UKB outcomes overlap; not independent replications', 'ancestry': 'European LD; East-Asian and trans-ancestry outcomes sensitivity only', 'code_reused': [str(CORE), str(MERGE)], 'QTL_build': 'Provider GRCh38; mapped by validated rsID/alleles to LD GRCh37', 'blocked_outcomes': [r for r in prep if r['status'] != 'complete']}
    (ROOT / 'audit/final_analysis_QA.json').write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding='utf-8')
    PUBLIC.mkdir(parents=True, exist_ok=True)
    shutil.copytree(ROOT, PUBLIC, dirs_exist_ok=True)
    for code in ['prepare_gencord_smr_20261023.py', 'extract_gencord_candidates_20261023.py', 'run_gencord_smr_20261023.py']:
        (PUBLIC / 'code').mkdir(exist_ok=True)
        shutil.copy2(ROOT.parent / code, PUBLIC / 'code' / code)
    print(json.dumps(qa, ensure_ascii=False, indent=2), flush=True)
    print('[DONE]', PUBLIC, flush=True)
if __name__ == '__main__':
    main()
