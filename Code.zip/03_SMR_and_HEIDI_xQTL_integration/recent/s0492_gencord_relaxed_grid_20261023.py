from pathlib import Path
import concurrent.futures as cf
import dataclasses
import hashlib
import importlib.util
import json
import math
import shutil
import sys
import time
import traceback
import pandas as pd
from scipy.stats import chi2
HERE = Path(__file__).resolve().parent
BASE = HERE / 'GENCORD_SMR_20261023'
PREV = HERE / 'GENCORD_SMR_no_frequency_check_20261023'
ROOT = HERE / 'GENCORD_SMR_relaxed_grid_20261023'
PUBLIC = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u8f93\u51fa\\20261023_GENCORD_11\u57fa\u56e0_SMR_\u5168\u90e8\u7259\u5468\u7ed3\u5c40\\\u654f\u611f\u6027\u5206\u6790_\u56fa\u5b9a\u4e09\u6863\u653e\u5bbd\u5de5\u5177')
TIERS = [dict(tier='baseline', peqtl=0.0016, F_min=10.0, reuse=True), dict(tier='exploratory_001', peqtl=0.01, F_min=float(chi2.isf(0.01, 1)), reuse=False), dict(tier='exploratory_005', peqtl=0.05, F_min=float(chi2.isf(0.05, 1)), reuse=False)]

def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def write_json(path, doc):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding='utf-8')

def run_one(runner, smr, ld, outcome, gene, probe, tier):
    dest = ROOT / 'runs' / tier['tier'] / outcome.outcome_id / gene
    dest.mkdir(parents=True, exist_ok=True)
    out = dest / 'SMR_HEIDI'
    log = dest / 'SMR_HEIDI.console.log'
    args = [smr, '--bfile', ld[gene], '--gwas-summary', outcome.prepared_path, '--beqtl-summary', BASE / 'inputs/GENCORD_11', '--probe', probe, '--peqtl-smr', str(tier['peqtl']), '--peqtl-heidi', str(tier['peqtl']), '--cis-wind', '2000', '--ld-upper-limit', '0.9', '--heidi-min-m', '3', '--heidi-max-m', '20', '--thread-num', '1', '--disable-freq-ck', '--out', out]
    marker = dest / 'completion.json'
    if marker.exists():
        saved = json.loads(marker.read_text(encoding='utf-8'))
        code = saved['exit_code']
    else:
        code = runner.cmd(args, log)
        write_json(marker, dict(exit_code=code))
    path = out.with_suffix('.smr')
    rows = pd.read_csv(path, sep='\\s+', na_values=['NA', '-9']).to_dict('records') if path.exists() else []
    for row in rows:
        row.update(gene=gene, outcome_id=outcome.outcome_id, outcome=outcome.label.replace('\n', ' '), ancestry=outcome.ancestry, limitation=outcome.overlap_note, tier=tier['tier'], peqtl_smr=tier['peqtl'], peqtl_heidi=tier['peqtl'], F_min=tier['F_min'], frequency_check_disabled=True, origin='new_native_run', result_file=str(path))
        row['F_instrument'] = (row['b_eQTL'] / row['se_eQTL']) ** 2
        row['instrument_pass'] = row['p_eQTL'] < tier['peqtl'] and row['F_instrument'] >= tier['F_min'] - 0.001
        row['weak_F_lt_10'] = row['F_instrument'] < 10
        row['raw_P_lt_005'] = row['p_SMR'] < 0.05
        row['HEIDI_pass'] = pd.notna(row['p_HEIDI']) and row['p_HEIDI'] > 0.05
        row['SMR_and_HEIDI_pass'] = row['instrument_pass'] and row['raw_P_lt_005'] and row['HEIDI_pass']
    text = log.read_text(encoding='utf-8', errors='replace') if log.exists() else ''
    status = 'estimated' if rows else 'no_common_SNPs' if 'no SNPs in common' in text else 'no_usable_instrument'
    record = dict(tier=tier['tier'], gene=gene, outcome_id=outcome.outcome_id, status=status, exit_code=code, n_rows=len(rows), log=str(log))
    print('SMR', tier['tier'], outcome.outcome_id, gene, code, status, flush=True)
    return (record, rows)

def main():
    ROOT.mkdir(parents=True, exist_ok=True)
    for folder in ['audit', 'tables', 'inputs/ld', 'inputs/gwas', 'code']:
        (ROOT / folder).mkdir(parents=True, exist_ok=True)
    registry = ROOT / 'audit/fixed_grid_before_analysis.json'
    plan = dict(tiers=TIERS, genes=['VDR', 'PLAU', 'TG', 'MYC', 'BTF3P11', 'PHEX', 'GDF15', 'CYP24A1', 'AR', 'GMNN', 'IL2'], outcome_count=14, planned_slots=462, significance='RAW SMR P<0.05, unchanged', interpretation='All relaxed tiers are weak-instrument exploratory sensitivity analyses; no choosing successful configurations.', unchanged='GENCORD N186; European LD N503; cis 2000kb; HEIDI min3 max20; LD lower0.05 upper0.9.', frequency_check='Disabled as already explicitly requested, in every tier.', stopping_rule='Run exactly these three tiers and all14 outcomes; do not optimize thresholds or select target SNPs by GWAS results.')
    if registry.exists():
        assert json.loads(registry.read_text(encoding='utf-8')) == plan
    else:
        write_json(registry, plan)
    runner = load(HERE / 'run_gencord_smr_20261023.py', 'relaxed_reuse_runner')
    runner.ROOT = ROOT
    base, merge, outcomes = runner.modules()
    records = pd.read_csv(BASE / 'audit/GWAS_source_inventory.csv').to_dict('records')
    by_id = {r['outcome_id']: r for r in records}
    outcomes = [dataclasses.replace(o, source_path=Path(by_id[o.outcome_id]['source_path'])) for o in outcomes]
    q = pd.read_csv(BASE / 'tables/GENCORD_mapped_GRCh37_QTL.csv')
    profile = pd.read_csv(BASE / 'tables/GENCORD_11gene_input_profile.csv').set_index('gene')
    baseline = pd.read_csv(PREV / 'tables/\u5168\u90e8\u53ef\u8ba1\u7b97\u7ed3\u679c.csv')
    watched = [p for p in BASE.rglob('*') if p.is_file()] + [p for p in PREV.rglob('*') if p.is_file()]
    initial = {str(p): sha(p) for p in watched}
    write_json(ROOT / 'audit/original_files_SHA256.json', initial)
    genes = sorted(q.Gene.unique())
    ld = {}
    freq = {}
    position = {}
    ambiguous = set()
    plink = BASE / 'inputs/software/plink.exe'
    smr = BASE / 'inputs/software/smr.exe'
    for gene in genes:
        found = list((runner.PREVIOUS / 'inputs/ld_regions').glob(f'*_{gene}_*.bed'))
        assert len(found) == 1, (gene, found)
        src = found[0].with_suffix('')
        dst = ROOT / 'inputs/ld' / gene
        for ext in ['.bed', '.bim', '.fam']:
            if not dst.with_suffix(ext).exists():
                shutil.copy2(src.with_suffix(ext), dst.with_suffix(ext))
        ld[gene] = dst
        if not dst.with_suffix('.frq').exists():
            assert runner.cmd([plink, '--bfile', dst, '--freq', '--out', dst], ROOT / f'audit/PLINK_{gene}.log') == 0
        for row in pd.read_csv(dst.with_suffix('.frq'), sep='\\s+').itertuples():
            val = (row.A1, row.A2, float(row.MAF))
            if row.SNP in freq:
                assert freq[row.SNP] == val
            freq[row.SNP] = val
        with dst.with_suffix('.bim').open() as f:
            for line in f:
                a = line.split()
                key = (int(a[0]), int(a[3]))
                if key in position and position[key] != a[1]:
                    ambiguous.add(key)
                else:
                    position[key] = a[1]
    for key in ambiguous:
        position.pop(key, None)
    wanted = set(q.loc[q.pvalue < 0.05, 'rsid']) & set(freq)
    signature = hashlib.sha256('\n'.join(sorted(wanted)).encode()).hexdigest()
    write_json(ROOT / 'audit/widened_variant_universe.json', dict(n_variants=len(wanted), signature=signature, ambiguous_positions_removed=len(ambiguous)))
    eligibility = []
    eligible = {}
    for tier in TIERS:
        eligible[tier['tier']] = []
        for gene in plan['genes']:
            d = q[(q.Gene == gene) & (q.pvalue < tier['peqtl']) & (q.F_SMR >= tier['F_min'])]
            n = len(d)
            if n:
                eligible[tier['tier']].append(gene)
            eligibility.append(dict(tier=tier['tier'], gene=gene, n_eligible_QTL=n, min_F=tier['F_min'], peqtl=tier['peqtl'], source_rows=int(profile.loc[gene, 'source_rows'])))
    pd.DataFrame(eligibility).to_csv(ROOT / 'tables/\u5404\u6863\u5de5\u5177\u53ef\u7528\u6027.csv', index=False, encoding='utf-8-sig')
    print('FIXED_PLAN', json.dumps(plan, ensure_ascii=False), flush=True)
    print('ELIGIBLE', eligible, 'WIDENED_GWAS_VARIANTS', len(wanted), flush=True)
    prep = []
    for o in outcomes:
        record = dict(by_id[o.outcome_id])
        record['missing_from_old_cache'] = 1
        result = runner.prepare_one(base, merge, o, record, wanted, position, freq)
        if result['status'] != 'complete':
            print('RETRY_SEQUENTIAL', o.outcome_id, flush=True)
            result = runner.prepare_one(base, merge, o, record, wanted, position, freq)
        prep.append(result)
        pd.DataFrame(prep).to_csv(ROOT / 'audit/widened_GWAS_preparation.csv', index=False, encoding='utf-8-sig')
    if any((r['status'] != 'complete' for r in prep)):
        raise RuntimeError('Some GWAS preparation blocked; do not silently omit requested outcomes')
    for o in outcomes:
        old = pd.read_csv(BASE / 'inputs/gwas' / f'{o.outcome_id}.ma', sep='\t')
        new = pd.read_csv(o.prepared_path, sep='\t')
        check = old.merge(new, on='SNP', how='left', suffixes=('_old', '_new'), validate='one_to_one')
        assert not check.b_new.isna().any(), o.outcome_id
        for col in ['b', 'se', 'p', 'freq']:
            assert (check[col + '_old'] - check[col + '_new']).abs().max() < 1e-09, (o.outcome_id, col)
        assert (check.A1_old == check.A1_new).all() and (check.A2_old == check.A2_new).all()
    rows = baseline.to_dict('records')
    for row in rows:
        row.update(tier='baseline', peqtl_smr=0.0016, peqtl_heidi=0.0016, F_min=10.0, origin='reused_identical_completed_baseline')
        row['weak_F_lt_10'] = row['F_instrument'] < 10
    statuses = []
    tasks = [(o, g, t) for t in TIERS if not t['reuse'] for o in outcomes for g in eligible[t['tier']]]
    with cf.ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(run_one, runner, smr, ld, o, g, str(q.loc[q.Gene == g, 'gene_id'].iloc[0]), t) for o, g, t in tasks]
        for f in cf.as_completed(futures):
            status, result = f.result()
            statuses.append(status)
            rows.extend(result)
            pd.DataFrame(statuses).to_csv(ROOT / 'audit/native_run_status.csv', index=False, encoding='utf-8-sig')
    frame = pd.DataFrame(rows)
    assert all((s['exit_code'] == 0 for s in statuses))
    assert frame.instrument_pass.all()
    assert not frame.duplicated(['tier', 'gene', 'outcome_id']).any()
    err = (chi2.sf((frame.b_SMR / frame.se_SMR) ** 2, 1) - frame.p_SMR).abs().max()
    assert err < 1e-05, err
    assert (frame.b_SMR - frame.b_GWAS / frame.b_eQTL).abs().max() < 1e-05
    frame.to_csv(ROOT / 'tables/\u4e09\u6863\u5168\u90e8SMR\u4f30\u8ba1.csv', index=False, encoding='utf-8-sig')
    frame[frame.gene == 'GDF15'].to_csv(ROOT / 'tables/GDF15_\u4e09\u6863\u5168\u90e8\u7ed3\u679c.csv', index=False, encoding='utf-8-sig')
    positives = frame[frame.raw_P_lt_005].copy()
    positives.to_csv(ROOT / 'tables/RAW_P\u5c0f\u4e8e005_\u5168\u90e8\u63a2\u7d22\u6027\u7ed3\u679c.csv', index=False, encoding='utf-8-sig')
    full = []
    for tier in TIERS:
        for o in outcomes:
            for gene in plan['genes']:
                selected = frame[(frame.tier == tier['tier']) & (frame.gene == gene) & (frame.outcome_id == o.outcome_id)]
                if len(selected):
                    r = selected.iloc[0].to_dict()
                    r['status'] = 'estimated'
                else:
                    reason = 'No usable common instrument'
                    if profile.loc[gene, 'source_rows'] == 0:
                        reason = 'No source QTL; X absent' if gene in ['AR', 'PHEX'] else 'No source QTL records'
                    elif gene not in eligible[tier['tier']]:
                        reason = 'No QTL meeting tier instrument threshold'
                    r = dict(tier=tier['tier'], gene=gene, outcome_id=o.outcome_id, outcome=o.label.replace('\n', ' '), status=reason)
                full.append(r)
    assert len(full) == 462
    pd.DataFrame(full).to_csv(ROOT / 'tables/11\u57fa\u56e0_14\u7ed3\u5c40_\u4e09\u6863462\u7ec4\u5408\u72b6\u6001.csv', index=False, encoding='utf-8-sig')
    summary = []
    for t in TIERS:
        d = frame[frame.tier == t['tier']]
        summary.append(dict(tier=t['tier'], peqtl=t['peqtl'], F_min=t['F_min'], eligible_genes=len(eligible[t['tier']]), estimates=len(d), nominal_P_lt_005=int(d.raw_P_lt_005.sum()), SMR_and_HEIDI_pass=int(d.SMR_and_HEIDI_pass.sum()), weak_instrument_estimates=int(d.weak_F_lt_10.sum())))
    pd.DataFrame(summary).to_csv(ROOT / 'tables/\u4e09\u6863\u7ed3\u679c\u6c47\u603b.csv', index=False, encoding='utf-8-sig')
    unchanged = all((sha(Path(p)) == value for p, value in initial.items()))
    assert unchanged
    qa = dict(planned_slots=462, new_native_runs=len(statuses), reused_estimates=len(baseline), total_estimates=len(frame), nominal_raw_P_lt_005=len(positives), original_files_unchanged=unchanged, n_original_files=len(initial), independent_SMR_P_max_abs_error=float(err), all14_GWAS_ready=True, summary=summary, parameter_grid_SHA256=sha(registry), stop_rule='Exactly the three tiers fixed before recomputation; no outcome-driven optimization.')
    write_json(ROOT / 'audit/QA.json', qa)
    lines = ['# GENCORD SMR\uff1a\u56fa\u5b9a\u4e09\u6863\u653e\u5bbd\u5de5\u5177\u7684\u63a2\u7d22\u6027\u5206\u6790', '', '## \u56fa\u5b9a\u65b9\u6848', '\u5728\u8bfb\u53d6\u672c\u8f6e\u7ed3\u5c40\u7ed3\u679c\u4e4b\u524d\u56fa\u5b9a\u4e09\u6863\uff1a\u57fa\u7ebfeQTL P<0.0016\u4e14F\u226510\uff1b\u63a2\u7d22\u6863P<0.01\uff08\u5bf9\u5e94F\u7ea66.63\uff09\uff1b\u6781\u5bbd\u63a2\u7d22\u6863P<0.05\uff08\u5bf9\u5e94F\u7ea63.84\uff09\u3002', '\u6240\u6709\u6863SMR\u663e\u8457\u6807\u51c6\u4ecd\u662fRAW P<0.05\uff1b\u672a\u628a0.05\u6539\u4e3a0.10\u3002HEIDI eQTL\u7b5b\u9009P\u968f\u6863\u4f4d\u6539\u53d8\uff0c\u5176\u4f59HEIDI\u53c2\u6570\u53ca2Mb\u7a97\u53e3\u4e0d\u53d8\u3002', '\u7ee7\u7eed\u6cbf\u7528\u7528\u6237\u5df2\u6388\u6743\u5173\u95ed\u9891\u7387\u6838\u9a8c\u7684\u8bbe\u7f6e\uff1b\u672a\u5f3a\u5236\u9009\u62e9GWAS\u66f4\u663e\u8457\u7684SNP\uff0c\u4ecd\u4f7f\u7528\u539f\u751fSMR\u7684\u6700\u5f3a\u53ef\u7528cis-eQTL\u3002', '\u590d\u7528\u539fGENCORD\u516d\u57fa\u56e0BESD\u3001\u539f\u811a\u672c\u53ca1000G EUR LD\uff1b\u91cd\u65b0\u4ece14\u4e2a\u539f\u59cbGWAS\u63d0\u53d6\u653e\u5bbd\u540e\u7684\u5168\u90e8\u5019\u9009\u4f4d\u70b9\uff0c\u672a\u4f7f\u7528\u8986\u76d6\u4e0d\u8db3\u7684\u65e7GWAS\u7f13\u5b58\u3002', '\u5df2\u5b8c\u6210\u4e14\u8f93\u5165\u4e00\u81f4\u7684\u57fa\u7ebf54\u6761\u4f30\u8ba1\u590d\u7528\uff0c\u4e0d\u91cd\u590d\u8ba1\u7b97\u3002\u65b0\u589e\u6863\u4f4d\u5b8c\u6574\u8ba1\u7b97\uff0c\u4e0d\u53ea\u4fdd\u7559\u663e\u8457\u9879\u3002', '', '## \u7ed3\u679c']
    for s in summary:
        lines.append(f"- {s['tier']}: {s['eligible_genes']}\u4e2a\u6709\u5de5\u5177\u57fa\u56e0\uff0c{s['estimates']}\u6761\u4f30\u8ba1\uff0cRAW P<0.05\u5171{s['nominal_P_lt_005']}\u6761\uff0c\u540c\u65f6HEIDI P>0.05\u5171{s['SMR_and_HEIDI_pass']}\u6761\u3002")
    lines += ['', '## \u6240\u6709\u540d\u4e49\u663e\u8457\u9879']
    if positives.empty:
        lines.append('\u65e0RAW SMR P<0.05\u7ed3\u679c\u3002')
    for r in positives.itertuples():
        lines.append(f'- {r.tier} / {r.gene} / {r.outcome_id}: SMR P={r.p_SMR:.8g}, HEIDI P={r.p_HEIDI:.8g}, F={r.F_instrument:.6g}, beta={r.b_SMR:.8g}, SNP={r.topSNP}')
    lines += ['', '## \u89e3\u91ca\u9650\u5236', '\u540e\u4e24\u6863\u5141\u8bb8\u5f31\u5de5\u5177\uff08F<10\uff09\uff0c\u53ea\u7528\u4e8e\u53c2\u6570\u654f\u611f\u6027\u63a2\u7d22\u3002\u591a\u57fa\u56e0\u3001\u591a\u7ed3\u5c40\u3001\u591a\u6863\u6bd4\u8f83\u589e\u52a0\u5076\u7136\u9633\u6027\u673a\u4f1a\uff1bRAW P<0.05\u4e0d\u7b49\u540c\u4e8e\u7a33\u5065\u8bc1\u636e\u6216\u56e0\u679c\u5df2\u8bc1\u5b9e\u3002', 'GENCORD\u662f\u57f9\u517b\u6210\u7ea4\u7ef4\u7ec6\u80de\uff0c\u975e\u7259\u9f88\u7279\u5f02\u3002BBJ\u7b49\u975e\u6b27\u6d32\u7ed3\u5c40\u4f7f\u7528\u6b27\u6d32LD\uff0c\u4ec5\u4f5c\u654f\u611f\u6027\u89e3\u91ca\uff1b\u90e8\u5206GLIDE/UKB\u7ed3\u5c40\u4eba\u7fa4\u91cd\u53e0\uff0c\u4e0d\u80fd\u7b97\u72ec\u7acb\u91cd\u590d\u9a8c\u8bc1\u3002', 'TG\u3001BTF3P11\u3001IL2\u6ca1\u6709\u76f8\u5e94\u6e90QTL\u8bb0\u5f55\uff1bAR\u3001PHEX\u56e0\u6e90\u6570\u636e\u4e0d\u542bX\u67d3\u8272\u4f53\u4ecd\u4e0d\u53ef\u8ba1\u7b97\u3002\u7f3a\u5931\u7ed3\u679c\u4e0d\u6309P=1\u6216\u9634\u6027\u5904\u7406\u3002', '\u4e34\u5e8a\u7259\u5468\u708e\u3001\u7259\u9f7f\u677e\u52a8\u3001\u7259\u9f88\u75bc\u75db\u3001\u7259\u9f88\u51fa\u8840\u53ca\u9f88\u6c9f\u6db2IL1\u03b2\u7ed3\u5c40\u5206\u522b\u62a5\u544a\uff0c\u4e0d\u6df7\u79f0\u7259\u5468\u708e\u3002', '\u539f\u7248\u53ca\u4e0a\u4e00\u8f6e\u5173\u95ed\u9891\u7387\u6838\u9a8c\u7248\u5747\u4fdd\u7559\u3001\u54c8\u5e0c\u9a8c\u8bc1\u672a\u6539\u53d8\u3002', 'SMR\u5b98\u65b9\u53c2\u6570\u8bf4\u660e\uff1ahttps://yanglab.westlake.edu.cn/software/smr']
    (ROOT / '\u7ed3\u679c\u4e0e\u65b9\u6cd5\u8bf4\u660e.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    shutil.copy2(Path(__file__), ROOT / 'code' / Path(__file__).name)
    PUBLIC.mkdir(parents=True, exist_ok=True)
    shutil.copytree(ROOT, PUBLIC, dirs_exist_ok=True)
    assert all((sha(p) == sha(PUBLIC / p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()))
    print(json.dumps(qa, ensure_ascii=False, indent=2), flush=True)
    print('POSITIVES', positives[['tier', 'gene', 'outcome_id', 'p_SMR', 'p_HEIDI', 'F_instrument']].to_string(index=False), flush=True)
    print('[DONE]', PUBLIC, flush=True)
if __name__ == '__main__':
    main()
