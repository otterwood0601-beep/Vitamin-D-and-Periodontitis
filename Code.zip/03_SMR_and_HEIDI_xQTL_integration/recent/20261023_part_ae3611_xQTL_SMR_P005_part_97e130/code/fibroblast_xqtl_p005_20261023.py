from pathlib import Path
import argparse
import concurrent.futures as cf
import dataclasses
import hashlib
import importlib.util
import inspect
import json
import shutil
import sys
import pandas as pd
from scipy.stats import chi2
HERE = Path(__file__).resolve().parent
BASE = HERE / 'GENCORD_SMR_20261023'
ROOT = HERE / 'Fibroblast_xQTL_P005_20261023'
PUBLIC = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u8f93\u51fa\\20261023_\u6210\u7ea4\u7ef4\u7ec6\u80de_xQTL_SMR_P005_\u5168\u90e8\u7259\u5468\u7ed3\u5c40')
RESOURCE = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u539f\u59cb\u6570\u636e\\03_xQTL\u4e0e\u53c2\u8003\u9762\u677f')
GENES = ['VDR', 'PLAU', 'TG', 'MYC', 'BTF3P11', 'PHEX', 'GDF15', 'CYP24A1', 'AR', 'GMNN', 'IL2']

def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m

def js(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

def inventory(runner):
    panels = []
    coverage = []
    eq = RESOURCE / 'xQTL\u9762\u677f/GTEx_V8_cis_eqtl_summary_lite/eQTL_besd_lite/Cells_Cultured_fibroblasts.lite'
    sq = RESOURCE / 'xQTL\u9762\u677f/GTEx_V8_cis_sqtl_summary_lite/sQTL_besd_lite'
    prefixes = [('GTEx_V8_eQTL', eq)] + [('GTEx_V8_sQTL', p.with_suffix('')) for p in sorted(sq.glob('*Cells_Cultured_fibroblasts*.epi'))]
    for kind, prefix in prefixes:
        epi = pd.read_csv(str(prefix) + '.epi', sep='\\s+', header=None, names=['chr', 'probe', 'gd', 'bp', 'gene', 'strand'])
        selected = epi[epi.gene.isin(GENES)].copy()
        if selected.empty:
            continue
        for gene, d in selected.groupby('gene'):
            panel = f'{kind}_{gene}'
            dest = ROOT / 'inputs/panels' / panel
            dest.mkdir(parents=True, exist_ok=True)
            probes = dest / 'probes.txt'
            probes.write_text('\n'.join(d.probe) + '\n', encoding='ascii')
            d.to_csv(dest / 'manifest.csv', index=False, encoding='utf-8-sig')
            query = dest / 'query_p005'
            if not query.with_suffix('.txt').exists():
                code = runner.cmd([BASE / 'inputs/software/smr.exe', '--beqtl-summary', prefix, '--extract-probe', probes, '--query', '.05', '--out', query], dest / 'query.console.log')
                if code:
                    raise RuntimeError(f'Query failed {panel}')
            query_file = query.with_suffix('.txt')
            q = pd.read_csv(query_file, sep='\\s+') if query_file.exists() and query_file.stat().st_size else pd.DataFrame()
            panels.append(dict(panel=panel, kind=kind, gene=gene, prefix=str(prefix), probes=str(probes), chromosome=int(d.chr.iloc[0]), probe_bp_min=int(d.bp.min()), probe_bp_max=int(d.bp.max()), n_probes=len(d), query_file=str(query_file), n_query_rows=len(q)))
            print('PANEL', panel, 'PROBES', len(d), 'QUERY_ROWS', len(q), flush=True)
    for kind in ['GTEx_V8_eQTL', 'GTEx_V8_sQTL']:
        for gene in GENES:
            p = [p for p in panels if p['kind'] == kind and p['gene'] == gene]
            coverage.append(dict(dataset=kind, gene=gene, n_probes=sum((r['n_probes'] for r in p)), source='GTEx V8 cultured fibroblasts lite; not gingiva-specific'))
    pd.DataFrame(panels).to_csv(ROOT / 'audit/panel_inventory.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(coverage).to_csv(ROOT / 'tables/GTEx_11\u57fa\u56e0\u63a2\u9488\u8986\u76d6.csv', index=False, encoding='utf-8-sig')
    targets = set()
    for p in panels:
        path = Path(p['query_file'])
        if path.exists() and path.stat().st_size:
            q = pd.read_csv(path, sep='\\s+')
            if 'SNP' in q:
                targets.update(q.SNP)
    caches = []
    for path in sorted((runner.PREVIOUS / 'inputs/gwas').glob('*.ma')):
        d = pd.read_csv(path, sep='\t')
        caches.append(dict(outcome_id=path.stem, cache=str(path), n_rows=len(d), n_targets=len(targets), n_targets_covered=len(targets & set(d.SNP)), n_missing=len(targets - set(d.SNP))))
    pd.DataFrame(caches).to_csv(ROOT / 'audit/old_GWAS_cache_coverage.csv', index=False, encoding='utf-8-sig')
    print('TARGETS', len(targets), 'COVERAGE', json.dumps(caches, ensure_ascii=False), flush=True)
    return (panels, targets, caches)

def run_one(runner, panel, o, ld):
    dest = ROOT / 'runs' / o.outcome_id / panel['panel']
    dest.mkdir(parents=True, exist_ok=True)
    out = dest / 'SMR_HEIDI'
    log = dest / 'SMR_HEIDI.console.log'
    marker = dest / 'exit.json'
    if marker.exists():
        code = json.loads(marker.read_text())['code']
    else:
        code = runner.cmd([BASE / 'inputs/software/smr.exe', '--bfile', ld, '--gwas-summary', o.prepared_path, '--beqtl-summary', panel['prefix'], '--extract-probe', panel['probes'], '--peqtl-smr', '.05', '--peqtl-heidi', '.05', '--cis-wind', '2000', '--ld-upper-limit', '.9', '--heidi-min-m', '3', '--heidi-max-m', '20', '--thread-num', '1', '--disable-freq-ck', '--out', out], log)
        js(marker, dict(code=code))
    path = out.with_suffix('.smr')
    rows = pd.read_csv(path, sep='\\s+', na_values=['NA', '-9']).to_dict('records') if path.exists() else []
    for r in rows:
        r.update(gene=panel['gene'], dataset=panel['kind'], panel=panel['panel'], outcome_id=o.outcome_id, outcome=o.label.replace('\n', ' '), ancestry=o.ancestry, limitation=o.overlap_note, QTL_P_threshold=0.05, frequency_check_disabled=True, result_file=str(path))
        r['F_instrument'] = (r['b_eQTL'] / r['se_eQTL']) ** 2
        r['weak_F_lt_10'] = r['F_instrument'] < 10
        r['raw_P_lt_005'] = r['p_SMR'] < 0.05
        r['HEIDI_available'] = pd.notna(r['p_HEIDI'])
        r['HEIDI_pass'] = r['HEIDI_available'] and r['p_HEIDI'] > 0.05
        r['SMR_and_HEIDI_pass'] = r['raw_P_lt_005'] and r['HEIDI_pass']
    txt = log.read_text(encoding='utf-8', errors='replace')
    status = 'estimated' if rows else 'No usable common QTL in native SMR; see log'
    if code:
        status = 'Native execution failed; inspect log'
    record = dict(dataset=panel['kind'], gene=panel['gene'], outcome_id=o.outcome_id, code=code, n_rows=len(rows), status=status, log=str(log))
    print('SMR', panel['panel'], o.outcome_id, code, len(rows), flush=True)
    return (record, rows)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--inventory-only', action='store_true')
    args = parser.parse_args()
    for name in ['audit', 'tables', 'inputs/panels', 'inputs/ld', 'inputs/gwas', 'code']:
        (ROOT / name).mkdir(parents=True, exist_ok=True)
    js(ROOT / 'audit/fixed_scope.json', dict(genes=GENES, QTL_P=0.05, SMR_P=0.05, scope='Cultured fibroblasts only; exclude whole-blood mQTL and plasma pQTL', frequency_check='disabled as previously authorized', no_outcome_based_SNP_selection=True, all14_outcomes=True, caveat='GTEx lite contains only retained associations, not complete regional summary statistics.'))
    runner = load(HERE / 'run_gencord_smr_20261023.py', 'xqtl_reuse_runner')
    panels, targets, caches = inventory(runner)
    if args.inventory_only:
        return
    runner.ROOT = ROOT
    base, merge, outcomes = runner.modules()

    def parse_chromosome(token):
        token = str(token).removeprefix('chr')
        return 23 if token.upper() == 'X' else int(token)
    base.parse_chromosome = parse_chromosome
    merge.parse_chromosome = parse_chromosome
    position_code = inspect.getsource(base.convert_position_outcome).replace('int(marker[0])', 'parse_chromosome(marker[0])')
    vcf_code = inspect.getsource(merge.convert_gwas_vcf).replace('int(chrom_token.removeprefix("chr"))', 'parse_chromosome(chrom_token)')
    exec(compile(position_code, 'reused_position_converter_with_explicit_X_support', 'exec'), base.__dict__)
    exec(compile(vcf_code, 'reused_vcf_converter_with_explicit_X_support', 'exec'), merge.__dict__)
    js(ROOT / 'audit/chromosome_parser_adaptation.json', dict(change='Only normalize X chromosome token to 23; all other source conversion logic unchanged', position_converter=position_code, vcf_converter=vcf_code))
    records = pd.read_csv(BASE / 'audit/GWAS_source_inventory.csv').to_dict('records')
    rec = {r['outcome_id']: r for r in records}
    cache = {r['outcome_id']: r for r in caches}
    ld = {}
    freq = {}
    position = {}
    ambiguous = set()
    ld_audit = []
    for p in panels:
        gene = p['gene']
        if gene in ld:
            continue
        dest = ROOT / 'inputs/ld' / gene
        previous = list((runner.PREVIOUS / 'inputs/ld_regions').glob(f'*_{gene}_*.bed'))
        if previous:
            assert len(previous) == 1
            src = previous[0].with_suffix('')
            for ext in ['.bed', '.bim', '.fam']:
                if not dest.with_suffix(ext).exists():
                    shutil.copy2(src.with_suffix(ext), dest.with_suffix(ext))
            method = 'Reused existing gene-region LD'
        else:
            if not dest.with_suffix('.bed').exists():
                code = runner.cmd([BASE / 'inputs/software/plink.exe', '--bfile', RESOURCE / '1000G_EUR/g1000_eur', '--chr', str(p['chromosome']), '--from-bp', str(max(1, p['probe_bp_min'] - 2100000)), '--to-bp', str(p['probe_bp_max'] + 2100000), '--make-bed', '--out', dest], ROOT / f'audit/LD_extract_{gene}.log')
                if code:
                    raise RuntimeError(f'LD extraction failed: {gene}')
            method = 'Extracted exact gene-region from existing European reference; chromosome X retained as separate sensitivity'
        ld[gene] = dest
        if not dest.with_suffix('.frq').exists():
            assert runner.cmd([BASE / 'inputs/software/plink.exe', '--bfile', dest, '--freq', '--out', dest], ROOT / f'audit/LD_freq_{gene}.log') == 0
        for r in pd.read_csv(dest.with_suffix('.frq'), sep='\\s+').itertuples():
            freq[str(r.SNP)] = (r.A1, r.A2, float(r.MAF))
        b = pd.read_csv(dest.with_suffix('.bim'), sep='\\s+', header=None)
        for r in b.itertuples(index=False, name=None):
            key = (int(r[0]), int(r[3]))
            if key in position and position[key] != r[1]:
                ambiguous.add(key)
            else:
                position[key] = r[1]
        fam = pd.read_csv(dest.with_suffix('.fam'), sep='\\s+', header=None)
        if p['chromosome'] == 23:
            assert fam[4].isin([1, 2]).all(), 'Unknown sex in X chromosome LD reference'
        ld_audit.append(dict(gene=gene, method=method, n_reference=len(fam), chromosome=p['chromosome'], sex_counts=fam[4].value_counts().to_dict()))
    for key in ambiguous:
        position.pop(key, None)
    js(ROOT / 'audit/LD_audit.json', ld_audit)
    targets &= set(freq)
    for p in panels:
        narrow = ROOT / 'inputs/panels' / p['panel'] / 'candidate_besd'
        source_prefix = p['prefix']
        if not narrow.with_suffix('.besd').exists():
            qq = pd.read_csv(p['query_file'], sep='\\s+')
            snp_file = narrow.parent / 'all_queried_snps.txt'
            snp_file.write_text('\n'.join(sorted(set(qq.SNP))) + '\n', encoding='ascii')
            code = runner.cmd([BASE / 'inputs/software/smr.exe', '--beqtl-summary', source_prefix, '--extract-probe', p['probes'], '--extract-snp', snp_file, '--make-besd', '--out', narrow], narrow.parent / 'subset_BESD.console.log')
            if code:
                raise RuntimeError(f"Candidate BESD staging failed: {p['panel']}")
        p['source_prefix'] = source_prefix
        p['prefix'] = str(narrow)
    pd.DataFrame(panels).to_csv(ROOT / 'audit/staged_panel_inventory.csv', index=False, encoding='utf-8-sig')
    for o in outcomes:
        c = cache[o.outcome_id]
        d = pd.read_csv(c['cache'], sep='\t')
        missing = targets - set(d.SNP)
        if not missing:
            d[d.SNP.isin(targets)].to_csv(o.prepared_path, sep='\t', index=False)
            js(ROOT / f'audit/{o.outcome_id}_GWAS_reuse.json', dict(method='Existing full xQTL cache covers 100 percent of required variants', n_targets=len(targets), n_missing=0, source=c['cache']))
        else:
            record = dict(rec[o.outcome_id])
            record['missing_from_old_cache'] = len(missing)
            revised = dataclasses.replace(o, source_path=Path(record['source_path']))
            prepared = runner.prepare_one(base, merge, revised, record, targets, position, freq)
            if prepared['status'] != 'complete':
                raise RuntimeError(prepared)
    tasks = [(p, o) for p in panels for o in outcomes]
    statuses = []
    rows = []
    with cf.ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(run_one, runner, p, o, ld[p['gene']]) for p, o in tasks]
        for f in cf.as_completed(futures):
            s, r = f.result()
            statuses.append(s)
            rows.extend(r)
            pd.DataFrame(statuses).to_csv(ROOT / 'audit/native_status.csv', index=False, encoding='utf-8-sig')
    frame = pd.DataFrame(rows)
    assert not frame.duplicated(['dataset', 'probeID', 'outcome_id']).any()
    assert (frame.p_eQTL < 0.05).all()
    error = (chi2.sf((frame.b_SMR / frame.se_SMR) ** 2, 1) - frame.p_SMR).abs().max()
    assert error < 1e-05
    frame.to_csv(ROOT / 'tables/GTEx_eQTL_sQTL_\u5168\u90e8\u7ed3\u679c.csv', index=False, encoding='utf-8-sig')
    positive = frame[frame.raw_P_lt_005]
    positive.to_csv(ROOT / 'tables/GTEx_RAW_P\u5c0f\u4e8e005_\u5168\u90e8\u540d\u4e49\u5173\u8054.csv', index=False, encoding='utf-8-sig')
    frame[frame.gene == 'GDF15'].to_csv(ROOT / 'tables/GDF15_GTEx_eQTL_sQTL_\u5168\u90e8\u7ed3\u679c.csv', index=False, encoding='utf-8-sig')
    gencord = pd.read_csv(HERE / 'GENCORD_SMR_relaxed_grid_20261023/tables/\u4e09\u6863\u5168\u90e8SMR\u4f30\u8ba1.csv')
    gencord = gencord[gencord.tier == 'exploratory_005'].copy()
    gencord['dataset'] = 'GENCORD_eQTL'
    combined = pd.concat([frame, gencord], ignore_index=True)
    combined.to_csv(ROOT / 'tables/\u6210\u7ea4\u7ef4\u7ec6\u80de\u5168\u90e8xQTL_P005_\u5408\u5e76\u660e\u7ec6.csv', index=False, encoding='utf-8-sig')
    summary = []
    for dataset, d in combined.groupby('dataset'):
        summary.append(dict(dataset=dataset, estimated_genes=d.gene.nunique(), probe_outcome_estimates=len(d), raw_P_lt_005=int((d.p_SMR < 0.05).sum()), SMR_and_HEIDI_pass=int(d.SMR_and_HEIDI_pass.sum()), GDF15_min_raw_P=float(d.loc[d.gene == 'GDF15', 'p_SMR'].min())))
    pd.DataFrame(summary).to_csv(ROOT / 'tables/\u6210\u7ea4\u7ef4\u7ec6\u80dexQTL_\u7ed3\u679c\u6c47\u603b.csv', index=False, encoding='utf-8-sig')
    full = []
    for dataset in ['GENCORD_eQTL', 'GTEx_V8_eQTL', 'GTEx_V8_sQTL']:
        for gene in GENES:
            for o in outcomes:
                d = combined[(combined.dataset == dataset) & (combined.gene == gene) & (combined.outcome_id == o.outcome_id)]
                full.append(dict(dataset=dataset, gene=gene, outcome_id=o.outcome_id, n_estimates=len(d), status='estimated' if len(d) else 'Not estimable; no candidate probe or usable common QTL'))
    assert len(full) == 462
    pd.DataFrame(full).to_csv(ROOT / 'tables/\u4e09\u6765\u6e9011\u57fa\u56e014\u7ed3\u5c40_\u5168\u90e8\u72b6\u6001.csv', index=False, encoding='utf-8-sig')
    qa = dict(n_native_tasks=len(statuses), native_nonzero_exit=sum((s['code'] != 0 for s in statuses)), n_GTEx_estimates=len(frame), n_GTEx_nominal=len(positive), summary=summary, SMR_P_recompute_max_abs_error=float(error), threshold='QTL P<0.05; RAW SMR P<0.05; no outcome-directed target SNP selection', X_chromosome='AR uses sex-annotated European X LD; separate exploratory interpretation', missing_HEIDI='Missing HEIDI is not counted as pass', local_fibroblast_mQTL_or_pQTL='No verified source in local inventory; whole-blood/plasma sources excluded by user request')
    js(ROOT / 'audit/QA.json', qa)
    lines = ['# \u6210\u7ea4\u7ef4\u7ec6\u80dexQTL SMR\uff1a\u7edf\u4e00QTL P<0.05', '', '## \u8303\u56f4\u4e0e\u65b9\u6cd5', '\u9650\u5b9a\u57f9\u517b\u6210\u7ea4\u7ef4\u7ec6\u80de\uff1a\u590d\u7528\u5df2\u5b8c\u6210\u7684GENCORD eQTL P<0.05\u7ed3\u679c\uff0c\u65b0\u589eGTEx V8\u6210\u7ea4\u7ef4\u7ec6\u80deeQTL\u4e0esQTL\uff0c\u6cbf\u7528\u539f14\u4e2a\u7259\u5468\u76f8\u5173\u7ed3\u5c40\u3002', '\u6240\u6709\u6765\u6e90QTL\u5de5\u5177P<0.05\uff0cSMR\u663e\u8457\u6807\u51c6RAW P<0.05\uff1b\u7ee7\u7eed\u5173\u95ed\u9891\u7387\u6838\u9a8c\uff0c\u5176\u4f59cis 2Mb\u3001LD 0.05\u20130.9\u3001HEIDI\u6700\u5c113\u6700\u591a20\u4e2a\u4f4d\u70b9\u3002', '\u6bcf\u4e2a\u526a\u63a5\u63a2\u9488\u5206\u522b\u62a5\u544a\uff0c\u4e0d\u628a\u540c\u4e00\u57fa\u56e0\u7684\u591a\u4e2a\u63a2\u9488\u6216\u91cd\u53e0\u7ed3\u5c40\u89c6\u4e3a\u72ec\u7acb\u9a8c\u8bc1\u3002\u9ed8\u8ba4\u6700\u5f3a\u53ef\u7528cis\u5de5\u5177\uff0c\u4e0d\u6309GWAS P\u503c\u6311\u5de5\u5177\u3002', 'GTEx\u672c\u5730\u4e3alite\u9762\u677f\uff0c\u5e76\u975e\u5b8c\u6574\u533a\u57df\u7edf\u8ba1\uff1b\u7f3a\u5c11HEIDI\u4e0d\u80fd\u89c6\u4e3aHEIDI\u901a\u8fc7\u3002AR\u5c5e\u4e8eX\u67d3\u8272\u4f53\uff0c\u5355\u72ec\u4f5c\u4e3a\u63a2\u7d22\u6027\u89e3\u91ca\u3002', '\u672c\u5730\u6ca1\u6709\u5df2\u6838\u5b9e\u7684\u6210\u7ea4\u7ef4\u7ec6\u80demQTL\u6216pQTL\uff1b\u8840\u6db2mQTL\u3001\u8840\u6d46pQTL\u672a\u7eb3\u5165\u3002GENCORD/GTEx\u5747\u4e0d\u662f\u7259\u9f88\u7279\u5f02\u6210\u7ea4\u7ef4\u7ec6\u80de\u3002', '', '## \u6c47\u603b']
    for s in summary:
        lines.append(f"- {s['dataset']}: {s['estimated_genes']}\u57fa\u56e0\uff0c{s['probe_outcome_estimates']}\u6761\u4f30\u8ba1\uff0cRAW P<0.05\u5171{s['raw_P_lt_005']}\u6761\uff0cSMR\u53caHEIDI\u5747\u901a\u8fc7{s['SMR_and_HEIDI_pass']}\u6761\uff1bGDF15\u6700\u4f4eSMR P={s['GDF15_min_raw_P']:.8g}\u3002")
    lines += ['', '## GTEx\u6240\u6709\u540d\u4e49\u5173\u8054']
    for r in positive.itertuples():
        lines.append(f'- {r.dataset} / {r.gene} / {r.probeID} / {r.outcome_id}: SMR P={r.p_SMR:.8g}, HEIDI P={r.p_HEIDI:.8g}, F={r.F_instrument:.5g}, beta={r.b_SMR:.8g}')
    if positive.empty:
        lines.append('\u65e0\u3002')
    (ROOT / '\u7ed3\u679c\u4e0e\u65b9\u6cd5\u8bf4\u660e.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    shutil.copy2(Path(__file__), ROOT / 'code' / Path(__file__).name)
    shutil.copytree(ROOT, PUBLIC, dirs_exist_ok=True)
    print(json.dumps(qa, ensure_ascii=False, indent=2), flush=True)
    print('POSITIVES', positive[['dataset', 'gene', 'probeID', 'outcome_id', 'p_SMR', 'p_HEIDI', 'F_instrument']].to_string(index=False), flush=True)
    print('[DONE]', PUBLIC, flush=True)
if __name__ == '__main__':
    main()
