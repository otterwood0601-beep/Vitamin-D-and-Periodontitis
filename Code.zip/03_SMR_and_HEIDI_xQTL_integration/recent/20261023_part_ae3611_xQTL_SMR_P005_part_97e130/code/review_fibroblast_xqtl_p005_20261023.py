from pathlib import Path
import hashlib
import json
import shutil
import numpy as np
import pandas as pd
from scipy.stats import chi2
HERE = Path(__file__).resolve().parent
ROOT = HERE / 'Fibroblast_xQTL_P005_20261023'
PUBLIC = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u8f93\u51fa\\20261023_\u6210\u7ea4\u7ef4\u7ec6\u80de_xQTL_SMR_P005_\u5168\u90e8\u7259\u5468\u7ed3\u5c40')

def main():
    d = pd.read_csv(ROOT / 'tables/GTEx_eQTL_sQTL_\u5168\u90e8\u7ed3\u679c.csv')
    panels = pd.read_csv(ROOT / 'audit/staged_panel_inventory.csv').set_index('panel')
    queries = {p: pd.read_csv(row.query_file, sep='\\s+') for p, row in panels.iterrows()}
    checks = []
    for r in d.itertuples():
        q = queries[r.panel]
        match = q[(q.Probe == r.probeID) & (q.SNP == r.topSNP)]
        assert len(match) == 1, (r.panel, r.probeID, r.topSNP)
        s = match.iloc[0]
        assert {r.A1, r.A2} == {s.A1, s.A2}
        sign = 1 if r.A1 == s.A1 else -1
        assert np.isclose(r.b_eQTL, sign * s.b, rtol=2e-05, atol=2e-06)
        assert np.isclose(r.se_eQTL, s.SE, rtol=2e-05, atol=2e-06)
        assert np.isclose(r.p_eQTL, s.p, rtol=2e-05, atol=1e-10)
        assert np.isclose(r.b_SMR, r.b_GWAS / r.b_eQTL, rtol=2e-05, atol=2e-06)
        se = ((r.se_GWAS / r.b_eQTL) ** 2 + (r.b_GWAS * r.se_eQTL / r.b_eQTL ** 2) ** 2) ** 0.5
        assert np.isclose(r.se_SMR, se, rtol=2e-05, atol=2e-06)
        checks.append(dict(dataset=r.dataset, gene=r.gene, probe=r.probeID, outcome=r.outcome_id, source_effect_verified=True))
    p_error = float(np.max(np.abs(chi2.sf((d.b_SMR / d.se_SMR) ** 2, 1) - d.p_SMR)))
    assert p_error < 1e-05
    pd.DataFrame(checks).to_csv(ROOT / 'audit/independent_source_check.csv', index=False, encoding='utf-8-sig')
    combined = pd.read_csv(ROOT / 'tables/\u6210\u7ea4\u7ef4\u7ec6\u80de\u5168\u90e8xQTL_P005_\u5408\u5e76\u660e\u7ec6.csv')
    pos = combined[combined.p_SMR < 0.05]
    unique = pos.groupby(['dataset', 'gene', 'outcome_id', 'outcome']).agg(n_nominal_probes=('probeID', 'nunique'), min_raw_P=('p_SMR', 'min'), any_HEIDI_pass=('HEIDI_pass', 'any'), min_F=('F_instrument', 'min')).reset_index()
    unique.to_csv(ROOT / 'tables/\u540d\u4e49\u5173\u8054_\u6309\u6765\u6e90\u57fa\u56e0\u7ed3\u5c40\u6c47\u603b.csv', index=False, encoding='utf-8-sig')
    simple = combined[['dataset', 'gene', 'probeID', 'outcome_id', 'outcome', 'topSNP', 'b_SMR', 'se_SMR', 'p_SMR', 'p_HEIDI', 'F_instrument', 'HEIDI_pass']].rename(columns={'dataset': 'QTL\u6765\u6e90', 'gene': '\u57fa\u56e0', 'probeID': '\u63a2\u9488', 'outcome_id': '\u7ed3\u5c40\u7f16\u53f7', 'outcome': '\u7ed3\u5c40\u540d\u79f0', 'topSNP': '\u5de5\u5177\u4f4d\u70b9', 'b_SMR': 'SMR\u6548\u5e94', 'se_SMR': 'SMR\u6807\u51c6\u8bef', 'p_SMR': 'RAW_P', 'p_HEIDI': 'HEIDI_P', 'F_instrument': '\u5de5\u5177F\u503c', 'HEIDI_pass': 'HEIDI\u901a\u8fc7'})
    simple.to_csv(ROOT / 'tables/\u7b80\u8868_\u6240\u6709\u6210\u7ea4\u7ef4\u7ec6\u80dexQTL.csv', index=False, encoding='utf-8-sig')
    summary = pd.read_csv(ROOT / 'tables/\u6210\u7ea4\u7ef4\u7ec6\u80dexQTL_\u7ed3\u679c\u6c47\u603b.csv')
    qa = dict(n_GTEx_estimates_checked=len(d), max_abs_SMR_P_recompute_error=p_error, nominal_unique_dataset_gene_outcomes=len(unique), nominal_probe_outcome_records=len(pos), missing_HEIDI_not_pass=bool(not combined.loc[combined.p_HEIDI.isna(), 'HEIDI_pass'].any()))
    (ROOT / 'audit/independent_QA.json').write_text(json.dumps(qa, indent=2, ensure_ascii=False), encoding='utf-8')
    receipt = {'schemaVersion': 1, 'items': [{'id': 'fibroblast-xqtl-p005', 'title': '\u6210\u7ea4\u7ef4\u7ec6\u80deeQTL\u4e0esQTL\u7684SMR\u7ed3\u679c', 'queries': [{'id': 'fibroblast-three-sources', 'source': {'label': '\u672c\u8f6e\u9650\u5b9a\u6210\u7ea4\u7ef4\u7ec6\u80de\u7684SMR\u8f93\u51fa', 'files': ['\u6210\u7ea4\u7ef4\u7ec6\u80dexQTL_\u7ed3\u679c\u6c47\u603b.csv', 'GTEx_eQTL_sQTL_\u5168\u90e8\u7ed3\u679c.csv', '\u7b80\u8868_\u6240\u6709\u6210\u7ea4\u7ef4\u7ec6\u80dexQTL.csv', 'independent_QA.json'], 'filters': ['\u57f9\u517b\u6210\u7ea4\u7ef4\u7ec6\u80de\u6765\u6e90\uff1b\u4e0d\u542b\u5168\u8840\u6216\u8840\u6d46', '11\u4e2a\u9884\u5b9a\u57fa\u56e0\u300114\u9879\u539f\u5b9a\u7259\u5468\u76f8\u5173\u7ed3\u5c40', 'QTL\u5de5\u5177P<0.05', 'SMR\u663e\u8457\u6807\u51c6\uff1aRAW P<0.05', '\u7ee7\u7eed\u5173\u95ed\u5df2\u83b7\u6388\u6743\u7684\u7b49\u4f4d\u57fa\u56e0\u9891\u7387\u68c0\u67e5'], 'caveats': ['\u57f9\u517b\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e0d\u7b49\u4e8e\u7259\u9f88\u7279\u5f02\u6210\u7ea4\u7ef4\u7ec6\u80de\u3002', 'GTEx\u672c\u5730\u662flite\u7cbe\u7b80\u9762\u677f\uff0cHEIDI\u7f3a\u5931\u4e0d\u89c6\u4e3a\u901a\u8fc7\u3002', '\u591a\u4e2a\u526a\u63a5\u63a2\u9488\u53ca\u91cd\u53e0\u7ed3\u5c40\u4e0d\u5c5e\u4e8e\u72ec\u7acb\u9a8c\u8bc1\uff0c\u540d\u4e49\u5173\u8054\u4e0d\u7b49\u4e8e\u7a33\u5065\u56e0\u679c\u8bc1\u636e\u3002', '\u672c\u5730\u6ca1\u6709\u6838\u5b9e\u5230\u6210\u7ea4\u7ef4\u7ec6\u80demQTL\u6216pQTL\uff0c\u672a\u4f7f\u7528\u8840\u6db2\u6216\u8840\u6d46\u66ff\u4ee3\u3002'], 'evidenceFlow': [{'kind': 'validation', 'title': '\u6e90\u6548\u5e94\u4e0e\u8ba1\u7b97\u6838\u5bf9', 'detail': f'\u672c\u8f6e{len(d)}\u6761GTEx\u4f30\u8ba1\u5747\u4e0e\u539fBESD\u67e5\u8be2\u7684\u5de5\u5177\u6548\u5e94\u3001\u6807\u51c6\u8bef\u53caP\u503c\u6838\u5bf9\uff0c\u5e76\u72ec\u7acb\u590d\u7b97SMR\u6548\u5e94\u53ca\u6807\u51c6\u8bef\u3002'}]}, 'columns': ['dataset', 'estimated_genes', 'probe_outcome_estimates', 'raw_P_lt_005', 'SMR_and_HEIDI_pass', 'GDF15_min_raw_P'], 'rows': summary.to_dict('records'), 'preview': {'kind': 'aggregate', 'note': '\u4e09\u4e2a\u6765\u6e90\u5206\u522b\u6c47\u603b\uff1b\u540c\u4e00\u57fa\u56e0\u7684\u591a\u4e2a\u63a2\u9488\u548c\u4e0d\u540cQTL\u6765\u6e90\u4e0d\u8ba1\u4e3a\u72ec\u7acb\u961f\u5217\u91cd\u590d\u9a8c\u8bc1\u3002', 'totalRows': len(combined)}}]}]}
    (HERE / 'fibroblast-xqtl-p005-reviewed-sources.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
    shutil.copy2(Path(__file__), ROOT / 'code' / Path(__file__).name)
    shutil.copytree(ROOT, PUBLIC, dirs_exist_ok=True)
    assert all((hashlib.sha256(p.read_bytes()).digest() == hashlib.sha256((PUBLIC / p.relative_to(ROOT)).read_bytes()).digest() for p in ROOT.rglob('*') if p.is_file()))
    print(summary.to_string(index=False))
    print('UNIQUE_NOMINAL', unique.to_string(index=False))
    print('GDF15', combined[combined.gene == 'GDF15'][['dataset', 'outcome_id', 'p_SMR', 'p_HEIDI', 'topSNP']].to_string(index=False))
    print(json.dumps(qa, ensure_ascii=False, indent=2))
    print('[REVIEW_DONE]')
if __name__ == '__main__':
    main()
