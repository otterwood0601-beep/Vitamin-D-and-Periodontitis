from pathlib import Path
import hashlib
import json
import shutil
import numpy as np
import pandas as pd
from scipy.stats import chi2
HERE = Path(__file__).resolve().parent
ROOT = HERE / 'GENCORD_SMR_relaxed_grid_20261023'
BASE = HERE / 'GENCORD_SMR_20261023'
PUBLIC = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u8f93\u51fa\\20261023_GENCORD_11\u57fa\u56e0_SMR_\u5168\u90e8\u7259\u5468\u7ed3\u5c40\\\u654f\u611f\u6027\u5206\u6790_\u56fa\u5b9a\u4e09\u6863\u653e\u5bbd\u5de5\u5177')

def main():
    d = pd.read_csv(ROOT / 'tables/\u4e09\u6863\u5168\u90e8SMR\u4f30\u8ba1.csv')
    summary = pd.read_csv(ROOT / 'tables/\u4e09\u6863\u7ed3\u679c\u6c47\u603b.csv')
    q = pd.read_csv(BASE / 'tables/GENCORD_mapped_GRCh37_QTL.csv')
    assert len(d) == int(summary.estimates.sum())
    assert int((d.p_SMR < 0.05).sum()) == int(summary.nominal_P_lt_005.sum())
    source_qa = []
    for r in d.itertuples():
        row = q[(q.Gene == r.gene) & (q.rsid == r.topSNP)]
        assert len(row) == 1, (r.gene, r.topSNP)
        row = row.iloc[0]
        assert {r.A1, r.A2} == {row.A1, row.A2}
        sign = 1 if r.A1 == row.A1 else -1
        assert np.isclose(r.b_eQTL, sign * row.beta, rtol=1e-05, atol=1e-06)
        assert np.isclose(r.se_eQTL, row.se_SMR, rtol=1e-05, atol=1e-06)
        assert np.isclose(r.p_eQTL, row.pvalue, rtol=1e-05, atol=1e-09)
        expected_se = np.sqrt((r.se_GWAS / r.b_eQTL) ** 2 + (r.b_GWAS * r.se_eQTL / r.b_eQTL ** 2) ** 2)
        assert np.isclose(r.se_SMR, expected_se, rtol=1e-05, atol=1e-06)
        source_qa.append(dict(tier=r.tier, gene=r.gene, outcome_id=r.outcome_id, topSNP=r.topSNP, source_effect_and_P_verified=True, F=r.F_instrument))
    g = d[d.gene == 'GDF15']
    changes = g.groupby('outcome_id').agg(tiers=('tier', 'nunique'), lead_SNPs=('topSNP', 'nunique'), p_values=('p_SMR', 'nunique'))
    positives = d[d.p_SMR < 0.05]
    unique = positives.groupby(['gene', 'outcome_id']).agg(tiers_with_nominal_P_lt_005=('tier', lambda s: ','.join(sorted(s))), min_raw_P=('p_SMR', 'min'), max_raw_P=('p_SMR', 'max'), min_F=('F_instrument', 'min'), any_HEIDI_pass=('HEIDI_pass', 'any')).reset_index()
    simplified = d[['tier', 'gene', 'outcome_id', 'outcome', 'topSNP', 'b_SMR', 'se_SMR', 'p_SMR', 'p_HEIDI', 'F_instrument', 'weak_F_lt_10']].rename(columns={'tier': '\u53c2\u6570\u6863\u4f4d', 'gene': '\u57fa\u56e0', 'outcome_id': '\u7ed3\u5c40\u7f16\u53f7', 'outcome': '\u7ed3\u5c40\u540d\u79f0', 'topSNP': '\u5de5\u5177\u4f4d\u70b9', 'b_SMR': 'SMR\u6548\u5e94', 'se_SMR': 'SMR\u6807\u51c6\u8bef', 'p_SMR': 'RAW_P', 'p_HEIDI': 'HEIDI_P', 'F_instrument': '\u5de5\u5177F\u503c', 'weak_F_lt_10': 'F\u5c0f\u4e8e10\u5f31\u5de5\u5177'})
    simplified.to_csv(ROOT / 'tables/\u7b80\u8868_\u5168\u90e8\u4e09\u6863\u7ed3\u679c.csv', index=False, encoding='utf-8-sig')
    unique.to_csv(ROOT / 'tables/\u540d\u4e49\u663e\u8457\u9879_\u6309\u57fa\u56e0\u7ed3\u5c40\u53bb\u91cd.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(source_qa).to_csv(ROOT / 'audit/independent_source_effect_check.csv', index=False, encoding='utf-8-sig')
    receipt = {'schemaVersion': 1, 'items': [{'id': 'gencord-fixed-relaxed-grid', 'title': 'GENCORD\u56fa\u5b9a\u4e09\u6863SMR\u654f\u611f\u6027\u5206\u6790', 'queries': [{'id': 'fixed-grid-summary', 'source': {'label': '\u672c\u8f6eSMR\u7ed3\u679c\u53ca\u72ec\u7acb\u6838\u5bf9', 'files': ['\u4e09\u6863\u7ed3\u679c\u6c47\u603b.csv', '\u4e09\u6863\u5168\u90e8SMR\u4f30\u8ba1.csv', 'GDF15_\u4e09\u6863\u5168\u90e8\u7ed3\u679c.csv', 'QA.json'], 'filters': ['GENCORD\u57f9\u517b\u6210\u7ea4\u7ef4\u7ec6\u80deeQTL', '11\u4e2a\u9884\u5b9a\u57fa\u56e0\u4e0e\u539f14\u9879\u7ed3\u5c40', '\u56fa\u5b9a\u5de5\u5177P\u95e8\u69db\uff1a0.0016\u30010.01\u30010.05', 'SMR\u663e\u8457\u6807\u51c6\uff1aRAW P<0.05', '\u6cbf\u7528\u5df2\u6388\u6743\u5173\u95ed\u9891\u7387\u6838\u9a8c\u8bbe\u7f6e'], 'caveats': ['\u653e\u5bbd\u6863\u5141\u8bb8F<10\u7684\u5f31\u5de5\u5177\uff0c\u53ea\u4f5c\u63a2\u7d22\u6027\u654f\u611f\u6027\u7ed3\u679c\u3002', 'GENCORD\u4e0d\u662f\u7259\u9f88\u7279\u5f02\u6210\u7ea4\u7ef4\u7ec6\u80de\uff1b\u975e\u6b27\u6d32\u7ed3\u5c40\u4ecd\u6cbf\u7528\u6b27\u6d32LD\u53c2\u8003\u3002', '\u591a\u53c2\u6570\u3001\u591a\u7ed3\u5c40\u63a2\u7d22\u589e\u52a0\u5076\u7136\u9633\u6027\u673a\u4f1a\uff1b\u540d\u4e49\u663e\u8457\u4e0d\u7b49\u540c\u4e8e\u7a33\u5065\u56e0\u679c\u8bc1\u636e\u3002', '\u540c\u4e00\u57fa\u56e0\u7ed3\u5c40\u8de8\u6863\u91cd\u590d\u51fa\u73b0\u4e0d\u7b97\u72ec\u7acb\u53d1\u73b0\uff0c\u90e8\u5206GWAS\u53c2\u4e0e\u8005\u4e5f\u6709\u91cd\u53e0\u3002'], 'evidenceFlow': [{'kind': 'validation', 'title': '\u7ed3\u679c\u4e0e\u6e90\u6570\u636e\u6838\u5bf9', 'detail': f'{len(d)}\u6761\u4f30\u8ba1\u5747\u6838\u5bf9\u539f\u59cbQTL\u6548\u5e94\u3001\u6807\u51c6\u8bef\u53caP\u503c\uff0cSMR\u6807\u51c6\u8bef\u6309\u6bd4\u503c\u516c\u5f0f\u53e6\u7b97\u5e76\u4e00\u81f4\u3002'}, {'kind': 'method', 'title': '\u56fa\u5b9a\u6bd4\u8f83\u65b9\u6848', 'detail': '\u4e09\u6863\u65b9\u6848\u5728\u672c\u8f6e\u7ed3\u679c\u4ea7\u751f\u524d\u4fdd\u5b58\uff1b\u5b8c\u6574\u4fdd\u7559\u5168\u90e8\u6863\u4f4d\u3001\u9634\u6027\u53ca\u4e0d\u53ef\u4f30\u8ba1\u8bb0\u5f55\uff0c\u4e0d\u6309\u7ed3\u679c\u6311\u9009\u5de5\u5177\u4f4d\u70b9\u3002'}]}, 'columns': ['tier', 'peqtl', 'eligible_genes', 'estimates', 'nominal_P_lt_005', 'SMR_and_HEIDI_pass'], 'rows': summary.to_dict('records'), 'preview': {'kind': 'aggregate', 'note': '\u5404\u56fa\u5b9a\u6863\u4f4d\u5b8c\u6574\u6c47\u603b\uff1b\u540c\u4e00\u57fa\u56e0\u7ed3\u5c40\u8de8\u6863\u91cd\u590d\u8ba1\u7b97\u4e0d\u4ee3\u8868\u72ec\u7acb\u9a8c\u8bc1\u3002', 'totalRows': len(d)}}]}]}
    (HERE / 'gencord-relaxed-grid-reviewed-sources.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
    qa = {'n_estimates_source_verified': len(d), 'nominal_rows': len(positives), 'nominal_unique_gene_outcomes': len(unique), 'GDF15_min_raw_P': float(g.p_SMR.min()), 'GDF15_all_lead_SNPs_unchanged_across_tiers': bool((changes.lead_SNPs == 1).all()), 'GDF15_all_SMR_P_unchanged_across_tiers': bool((changes.p_values == 1).all())}
    (ROOT / 'audit/independent_review.json').write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding='utf-8')
    shutil.copy2(Path(__file__), ROOT / 'code' / Path(__file__).name)
    shutil.copytree(ROOT, PUBLIC, dirs_exist_ok=True)
    for p in ROOT.rglob('*'):
        if p.is_file():
            assert hashlib.sha256(p.read_bytes()).digest() == hashlib.sha256((PUBLIC / p.relative_to(ROOT)).read_bytes()).digest()
    print(summary.to_string(index=False))
    print('UNIQUE_NOMINAL', unique.to_string(index=False))
    print('GDF15', g[['tier', 'outcome_id', 'p_SMR', 'p_HEIDI', 'F_instrument']].to_string(index=False))
    print(json.dumps(qa, ensure_ascii=False, indent=2))
    print('[REVIEW_DONE]')
if __name__ == '__main__':
    main()
