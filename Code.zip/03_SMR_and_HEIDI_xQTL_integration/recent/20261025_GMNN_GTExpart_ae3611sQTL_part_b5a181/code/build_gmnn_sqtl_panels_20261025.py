from pathlib import Path
import concurrent.futures as cf
import gzip
import hashlib
import importlib.util
import json
import math
import shutil
import subprocess
import sys
import numpy as np
import pandas as pd
sys.stdout.reconfigure(encoding='utf-8')
HERE = Path(__file__).resolve().parent
ROOT = HERE / 'GMNN_GTEx_sQTL_panels_20261025'
for d in ['inputs', 'runs', 'figures', 'tables', 'QA']:
    (ROOT / d).mkdir(parents=True, exist_ok=True)
PREV = HERE / 'Fibroblast_xQTL_P005_20261023'
STANDARD = HERE / 'Fibroblast_SMR_manuscript_standard_20261024'
SOFT = HERE / 'GENCORD_SMR_20261023/inputs/software'
PANEL = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u539f\u59cb\u6570\u636e\\03_xQTL\u4e0e\u53c2\u8003\u9762\u677f\\xQTL\u9762\u677f\\GTEx_V8_cis_sqtl_summary_lite\\sQTL_besd_lite\\sQTL_Cells_Cultured_fibroblasts.lite.chr6')
PLOT_CODE = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\03_\u6b63\u6587\u56fe3_SMR\u4e0eBulkRNA\\SMR_11\u5019\u9009\u57fa\u56e0\u6700\u7ec8\u94fe\\07_\u533a\u57df\u56fe\u4e0e\u6563\u70b9\u56fe_\u65b0\u7248\u4e0d\u8986\u76d6\u539f\u56fe\\scripts\\make_latest_mqtl_smr_panels.py')
ARCHIVE = Path('G:\\\u8840\u6e05\u7ef4\u751f\u7d20\\E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2\\E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784\\\u539f\u59cb\u6570\u636e\\02_\u7259\u5468\u75c5GWAS\\OpenGWAS\u7259\u5468\u708e\u7ed3\u5c40')
PROBE = 'chr6:24775112:24777222:clu_28328:ENSG00000112312.9'
ALIAS = 'GMNN_sQTL_clu28328_junction24775112'
LOC = 24775159
URL = 'https://api.genome.ucsc.edu/getData/track?genome=hg19;track=ncbiRefSeq;chrom=chr6;start=23775159;end=25775159'
OUTCOMES = [('UKB_Neale_bleeding_gums', 'ukb-a-430', 336138), ('UKB_MRCIEU_bleeding_gums', 'ukb-b-7872', 461113)]

def run(args, log, cwd=None):
    with log.open('w', encoding='utf-8') as h:
        h.write(json.dumps([str(x) for x in args], ensure_ascii=False) + '\n')
        h.flush()
        p = subprocess.run([str(x) for x in args], stdout=h, stderr=subprocess.STDOUT, cwd=cwd, timeout=180)
    if p.returncode:
        raise RuntimeError(f'Native operation failed: {log}')

def prepare_panel():
    out = ROOT / 'inputs/GMNN_chr6_plot_alias'
    for ext in ['.besd', '.esi']:
        if not Path(str(out) + ext).exists():
            shutil.copy2(Path(str(PANEL) + ext), Path(str(out) + ext))
    d = pd.read_csv(str(PANEL) + '.epi', sep='\\s+', header=None, dtype=str)
    assert d[1].eq(PROBE).sum() == 1
    d.loc[d[1].eq(PROBE), 1] = ALIAS
    d.to_csv(str(out) + '.epi', sep='\t', header=False, index=False)
    for ext in ['.besd', '.esi']:
        assert hashlib.sha256(Path(str(PANEL) + ext).read_bytes()).digest() == hashlib.sha256(Path(str(out) + ext).read_bytes()).digest()
    return out

def gene_list():
    raw = ROOT / 'inputs/UCSC_hg19_ncbiRefSeq_region.json'
    if not raw.exists():
        cmd = f"$r=Invoke-RestMethod -Uri '{URL}' -TimeoutSec 40; $r | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath '{raw}' -Encoding utf8"
        p = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', cmd], capture_output=True, text=True, timeout=50)
        if p.returncode:
            raise RuntimeError(p.stderr)
    obj = json.loads(raw.read_text(encoding='utf-8-sig'))
    d = pd.DataFrame(obj['ncbiRefSeq'])
    assert d.chrom.eq('chr6').all() and d.name2.eq('GMNN').any()
    g = d.groupby(['name2', 'strand'], as_index=False).agg(start=('txStart', 'min'), end=('txEnd', 'max'))
    g['start'] = g.start + 1
    g['chr'] = 6
    g = g.rename(columns={'name2': 'gene'})
    g = g[['chr', 'start', 'end', 'gene', 'strand']].sort_values(['start', 'end'])
    g.to_csv(ROOT / 'inputs/gene_list_hg19.txt', sep='\t', index=False, header=False)
    return ROOT / 'inputs/gene_list_hg19.txt'

def regional_gwas(tag, accession, n):
    dest = ROOT / 'inputs' / f'{tag}_region.ma'
    if dest.exists():
        return dest
    source = ARCHIVE / (accession + '.vcf.gz')
    rows = {}
    seen6 = False
    records = 0
    with gzip.open(source, 'rt', encoding='utf-8') as h:
        for line in h:
            if line.startswith('#'):
                continue
            first = line.split('\t', 2)
            chrom = first[0].removeprefix('chr')
            if chrom != '6':
                if seen6:
                    break
                continue
            seen6 = True
            pos = int(first[1])
            if pos < LOC - 1000000:
                continue
            if pos > LOC + 1000000:
                break
            a = line.rstrip().split('\t')
            records += 1
            if len(a) < 10 or len(a[3]) != 1 or len(a[4]) != 1:
                continue
            v = dict(zip(a[8].split(':'), a[9].split(':')))
            try:
                b = float(v['ES'])
                se = float(v['SE'])
                p = 10 ** (-float(v['LP']))
                af = float(v.get('AF', '.'))
                nn = float(v.get('SS', n))
            except (ValueError, KeyError):
                continue
            if not (se > 0 and 0 <= af <= 1 and (p > 0)):
                continue
            row = {'SNP': a[2], 'A1': a[4], 'A2': a[3], 'freq': af, 'b': b, 'se': se, 'p': p, 'n': nn}
            if a[2] not in rows:
                rows[a[2]] = row
    d = pd.DataFrame(rows.values())
    assert len(d) > 1000
    d.to_csv(dest, sep='\t', index=False)
    (ROOT / 'inputs' / f'{tag}_GWAS_provenance.json').write_text(json.dumps(dict(source=str(source), region='GRCh37 chr6:23775159-25775159', retained=len(d), scanned_region_records=records, effect_allele='VCF ALT', effect_units='Original GWAS beta; not assumed log odds', frequency='Original GWAS FORMAT AF; no substituted frequencies'), indent=2), encoding='utf-8')
    print('[GWAS REGION]', tag, len(d), flush=True)
    return dest

def native_plot(tag, gwas, panel, genes):
    out = ROOT / 'runs' / tag
    out.mkdir(exist_ok=True)
    prefix = out / tag
    file = out / 'plot' / f'{tag}.{ALIAS}.txt'
    if not file.exists():
        args = [SOFT / 'smr.exe', '--bfile', PREV / 'inputs/ld/GMNN', '--gwas-summary', gwas, '--beqtl-summary', panel, '--out', tag, '--plot', '--probe', ALIAS, '--probe-wind', '1000', '--gene-list', genes, '--peqtl-smr', '.0016', '--peqtl-heidi', '.00157', '--heidi-min-m', '3', '--heidi-max-m', '20', '--ld-upper-limit', '.9', '--thread-num', '1']
        run(args, out / 'native_plot.log', cwd=out)
    assert file.exists()
    return file

def draw(tag, path, plot):
    data = plot.parse_smr_plot(path)
    native = STANDARD / 'runs' / ('OGWAS_' + tag) / 'GTEx_V8_sQTL_GMNN/SMR_HEIDI.smr'
    result = plot.read_smr_row(native, native, PROBE)
    g, q, s = plot.build_plot_tables(data, result)
    assert s.is_top.sum() == 1 and (not s.snp.duplicated().any())
    top = s.loc[s.is_top].iloc[0]
    assert np.isclose(top.b_gwas / top.b_mqtl, result.b_SMR, rtol=1e-05)
    assert np.isclose(top.b_mqtl, result.b_eQTL, rtol=1e-05)
    for name, d in [('regional_GWAS', g), ('regional_sQTL', q), ('effect_scatter', s)]:
        d.to_csv(ROOT / 'tables' / f'{tag}_{name}.tsv', sep='\t', index=False)
    mpl = plot.mpl
    plt = plot.plt
    mpl.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9.5, 'axes.labelcolor': plot.COLORS['dark'], 'axes.edgecolor': plot.COLORS['dark'], 'xtick.color': plot.COLORS['dark'], 'ytick.color': plot.COLORS['dark'], 'text.color': plot.COLORS['dark'], 'pdf.fonttype': 42})
    stem = 'GMNN_' + tag + '_GTEx_fibroblast_sQTL'
    fig = plt.figure(figsize=(13.4, 9.4), constrained_layout=True)
    gs = fig.add_gridspec(3, 1, height_ratios=[1, 1, 2.45])
    axes = tuple((fig.add_subplot(gs[i]) for i in range(3)))
    plot.plot_regional(axes, g, q, data['genes'], result, 'GMNN', 6, 0.05 / 11, 'Bleeding gums (' + tag.split('_')[1] + ')', 'GTEx V8 cultured-fibroblast sQTL', 'sQTL')
    axes[0].set_title('GMNN', loc='left', fontsize=13, fontweight='bold', pad=15)
    for t in list(axes[0].texts):
        if t.get_text() == 'A':
            t.remove()
        elif 'not run' in t.get_text():
            t.set_text(t.get_text().replace('not run', 'NA'))
    qa = plot.audit_gene_labels(axes[2])
    a = ROOT / 'figures' / f'Figure_A_{stem}_regional.pdf'
    fig.savefig(a, bbox_inches='tight')
    fig.savefig(ROOT / 'QA' / f'{tag}_A.png', dpi=130, bbox_inches='tight')
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(7.2, 5.9), constrained_layout=True)
    plot.plot_effect(ax, s, result, 'GMNN', 0.05 / 11, 'Bleeding gums', 'GTEx fibroblast sQTL', 'sQTL')
    ax.set_title('GMNN', loc='left', fontsize=13, fontweight='bold', pad=35)
    ax.set_ylabel('GWAS effect size')
    for t in list(ax.texts):
        if t.get_text() == 'B':
            t.remove()
        elif 'not run' in t.get_text():
            t.set_text(t.get_text().replace('not run', 'NA'))
    ax.legend_.set_loc('upper right')
    if len(s) == 1:
        lo, hi = ax.get_ylim()
        ax.set_ylim(lo, hi + 0.22 * (hi - lo))
    b = ROOT / 'figures' / f'Figure_B_{stem}_effect_scatter.pdf'
    fig.savefig(b, bbox_inches='tight')
    fig.savefig(ROOT / 'QA' / f'{tag}_B.png', dpi=150, bbox_inches='tight')
    plt.close(fig)
    return dict(outcome=tag, probe=PROBE, topSNP=str(result.topSNP), b_SMR=float(result.b_SMR), p_SMR=float(result.p_SMR), p_HEIDI=float(result.p_HEIDI) if pd.notna(result.p_HEIDI) else None, n_GWAS=len(g), n_sQTL=len(q), n_shared=len(s), figures=[str(a), str(b)], **qa)
if __name__ == '__main__':
    panel = prepare_panel()
    genes = gene_list()
    with cf.ThreadPoolExecutor(max_workers=2) as pool:
        gwas = list(pool.map(lambda v: regional_gwas(*v), OUTCOMES))
    spec = importlib.util.spec_from_file_location('same_reference_plotter', PLOT_CODE)
    plot = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(plot)
    results = []
    for (tag, accession, n), g in zip(OUTCOMES, gwas):
        p = native_plot(tag, g, panel, genes)
        results.append(draw(tag, p, plot))
        print('[FIGURES]', tag, flush=True)
    audit = dict(selected_probe=PROBE, selection='Fixed junction with stronger QTL signal; same probe for both outcomes; no outcome-P selection', qtl='GTEx V8 cultured fibroblast sQTL lite; selected retained associations, not complete nominal regional QTL', limits=['Cultured fibroblasts, not gingiva-specific', 'Two UKB GWAS analyses overlap; not independent replications', 'Missing HEIDI remains unavailable; no invented value', 'GWAS beta retained in original units, not assumed log odds'], gene_annotation_source=URL, reference_plot_code=str(PLOT_CODE), results=results)
    (ROOT / 'audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
    print('[DONE]', json.dumps(audit, ensure_ascii=False), flush=True)
