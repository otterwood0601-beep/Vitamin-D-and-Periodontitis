from pathlib import Path
import concurrent.futures as cf
import hashlib
import json
import math
import shutil
import subprocess
import sys
import pandas as pd
from scipy.stats import chi2
BASE = Path(__file__).resolve().parent / 'GENCORD_SMR_20261023'
ROOT = BASE.parent / 'GENCORD_SMR_no_frequency_check_20261023'
PUBLIC = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u8f93\u51fa\\20261023_GENCORD_11\u57fa\u56e0_SMR_\u5168\u90e8\u7259\u5468\u7ed3\u5c40\\\u654f\u611f\u6027\u5206\u6790_\u5173\u95ed\u9891\u7387\u6838\u9a8c')

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def run(task):
    old_log = Path(task['log'])
    args = json.loads(old_log.open(encoding='utf-8').readline())
    assert '--disable-freq-ck' not in args
    dest = ROOT / 'runs' / task['outcome_id'] / task['gene']
    dest.mkdir(parents=True, exist_ok=True)
    out = dest / 'SMR_HEIDI'
    args[args.index('--out') + 1] = str(out)
    args.append('--disable-freq-ck')
    log = dest / 'SMR_HEIDI.console.log'
    with log.open('w', encoding='utf-8') as f:
        f.write(json.dumps(args, ensure_ascii=False) + '\n')
        f.flush()
        proc = subprocess.run(args, stdout=f, stderr=subprocess.STDOUT, timeout=300)
        f.write(f'\nEXIT_CODE={proc.returncode}\n')
    result_file = out.with_suffix('.smr')
    rows = []
    if result_file.exists():
        rows = pd.read_csv(result_file, sep='\\s+', na_values=['NA', '-9']).to_dict('records')
    for row in rows:
        row.update(gene=task['gene'], outcome_id=task['outcome_id'], analysis='Sensitivity only: allele-frequency check disabled by user request', frequency_check_disabled=True, eQTL_N=186, result_file=str(result_file))
        row['F_instrument'] = (row['b_eQTL'] / row['se_eQTL']) ** 2
        row['instrument_pass'] = row['p_eQTL'] < 0.0016 and row['F_instrument'] >= 10
        row['raw_P_lt_005'] = row['p_SMR'] < 0.05
        row['HEIDI_pass'] = pd.notna(row['p_HEIDI']) and row['p_HEIDI'] > 0.05
        row['SMR_and_HEIDI_pass'] = row['instrument_pass'] and row['raw_P_lt_005'] and row['HEIDI_pass']
        row['p_SMR_recomputed'] = chi2.sf((row['b_SMR'] / row['se_SMR']) ** 2, 1)
    text = log.read_text(encoding='utf-8', errors='replace')
    status = 'estimated' if rows else 'no_estimate'
    if not rows and 'no SNPs in common' in text:
        status = 'no_common_SNPs'
    print(task['outcome_id'], task['gene'], proc.returncode, status, flush=True)
    return (dict(gene=task['gene'], outcome_id=task['outcome_id'], exit_code=proc.returncode, n_rows=len(rows), status=status, log=str(log)), rows)

def main():
    if ROOT.exists() or PUBLIC.exists():
        raise RuntimeError('Sensitivity destination already exists; refuse to overwrite')
    for sub in ['tables', 'audit', 'code']:
        (ROOT / sub).mkdir(parents=True)
    old = pd.read_csv(BASE / 'tables/GENCORD_all_estimable_SMR_HEIDI.csv')
    tasks = pd.read_csv(BASE / 'audit/native_SMR_run_status.csv').to_dict('records')
    old_full = pd.read_csv(BASE / 'tables/GENCORD_11genes_14outcomes_complete_status.csv')
    monitored = list((BASE / 'inputs').rglob('*')) + list((BASE / 'runs').rglob('*'))
    monitored = [p for p in monitored if p.is_file()]
    initial = {str(p): sha(p) for p in monitored}
    statuses, results = ([], [])
    with cf.ThreadPoolExecutor(max_workers=2) as pool:
        for status, rows in pool.map(run, tasks):
            statuses.append(status)
            results.extend(rows)
    frame = pd.DataFrame(results)
    labels = old[['outcome_id', 'outcome', 'ancestry', 'limitation']].drop_duplicates('outcome_id')
    frame = frame.merge(labels, on='outcome_id', how='left', validate='many_to_one')
    assert not frame.duplicated(['gene', 'outcome_id']).any()
    assert frame['instrument_pass'].all()
    assert all((s['exit_code'] == 0 for s in statuses)), statuses
    assert all(('--disable-freq-ck' in Path(s['log']).read_text(encoding='utf-8').splitlines()[0] for s in statuses))
    checked = frame.assign(beta_check=frame.b_GWAS / frame.b_eQTL, se_check=((frame.se_GWAS / frame.b_eQTL) ** 2 + (frame.b_GWAS * frame.se_eQTL / frame.b_eQTL ** 2) ** 2) ** 0.5)
    errors = {'p_max_abs_error': float((checked.p_SMR_recomputed - checked.p_SMR).abs().max()), 'beta_max_abs_error': float((checked.beta_check - checked.b_SMR).abs().max()), 'se_max_abs_error': float((checked.se_check - checked.se_SMR).abs().max())}
    assert errors['p_max_abs_error'] < 1e-05
    assert errors['beta_max_abs_error'] < 1e-05
    assert errors['se_max_abs_error'] < 1e-05
    full = []
    for record in old_full.to_dict('records'):
        selected = frame[(frame.gene == record['gene']) & (frame.outcome_id == record['outcome_id'])]
        if len(selected):
            row = selected.iloc[0].to_dict()
            row['status'] = 'Estimated with frequency check disabled; sensitivity only'
        else:
            row = {key: record.get(key) for key in ['gene', 'outcome_id', 'outcome', 'status']}
            if pd.isna(row.get('status')):
                row['status'] = 'No usable common variants; no estimate'
        full.append(row)
    assert len(full) == 154
    frame.to_csv(ROOT / 'tables/\u5168\u90e8\u53ef\u8ba1\u7b97\u7ed3\u679c.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(full).to_csv(ROOT / 'tables/11\u57fa\u56e0_14\u7ed3\u5c40_\u5168\u90e8\u72b6\u6001.csv', index=False, encoding='utf-8-sig')
    frame[frame.gene == 'GDF15'].to_csv(ROOT / 'tables/GDF15_\u5168\u90e8\u7259\u5468\u7ed3\u5c40.csv', index=False, encoding='utf-8-sig')
    compare = frame.merge(old[['gene', 'outcome_id', 'p_SMR', 'p_HEIDI', 'topSNP', 'b_SMR']], on=['gene', 'outcome_id'], how='left', suffixes=('_no_freq_check', '_original'), indicator=True)
    compare.to_csv(ROOT / 'tables/\u4e0e\u539f\u9891\u7387\u6838\u9a8c\u7248\u5bf9\u7167.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(statuses).to_csv(ROOT / 'audit/native_run_status.csv', index=False, encoding='utf-8-sig')
    assert all((sha(Path(path)) == value for path, value in initial.items())), 'Original input/output changed'
    (ROOT / 'audit/original_files_SHA256_unchanged.json').write_text(json.dumps(initial, indent=2, ensure_ascii=False), encoding='utf-8')
    qa = dict(n_tasks=len(tasks), n_estimates=len(frame), n_original_estimates=len(old), n_new_estimates=int((compare['_merge'] == 'left_only').sum()), nominal_raw_P_lt_005=int(frame.raw_P_lt_005.sum()), SMR_and_HEIDI_pass=int(frame.SMR_and_HEIDI_pass.sum()), original_inputs_and_outputs_unchanged=True, n_original_files_verified=len(initial), frequency_check_disabled=True, only_parameter_change='--disable-freq-ck', peqtl_smr=0.0016, F_min=10, peqtl_heidi=0.0016, heidi_min_m=3, heidi_max_m=20, LD_reference='1000G Phase3 EUR 503; East Asian outcomes ancestry mismatch sensitivity only', numerical_validation=errors)
    (ROOT / 'audit/QA.json').write_text(json.dumps(qa, indent=2, ensure_ascii=False), encoding='utf-8')
    lines = ['# GENCORD SMR\uff1a\u5173\u95ed\u9891\u7387\u6838\u9a8c\u7684\u654f\u611f\u6027\u5206\u6790', '', '\u7528\u6237\u660e\u786e\u8981\u6c42\u53bb\u6389\u9891\u7387\u6838\u9a8c\u540e\u91cd\u7b97\u3002\u539f\u7248\u53ca\u5176\u7ed3\u8bba\u5b8c\u6574\u4fdd\u7559\uff0c\u672c\u8f6e\u4e0d\u662f\u901a\u8fc7\u539f\u8d28\u91cf\u68c0\u67e5\u7684\u4e3b\u5206\u6790\u3002', '\u590d\u7528\u539f\u724856\u6761\u547d\u4ee4\u53ca\u76f8\u540c\u8f93\u5165\uff0c\u4ec5\u589e\u52a0 --disable-freq-ck \u5e76\u6539\u53d8\u8f93\u51fa\u4f4d\u7f6e\u3002\u672a\u4fee\u6539\u7b49\u4f4d\u57fa\u56e0\u3001\u9891\u7387\u3001\u6548\u5e94\u503c\u6216P\u503c\u3002', '\u5de5\u5177\u6761\u4ef6\u4ecd\u4e3a eQTL P<0.0016\u3001F\u226510\uff0cSMR\u62a5\u544aRAW P\uff1bHEIDI\u53c2\u6570\u672a\u53d8\u3002', 'GENCORD\u4e3a\u57f9\u517b\u6210\u7ea4\u7ef4\u7ec6\u80de\uff08\u975e\u7259\u9f88\u7279\u5f02\uff09\uff0cN=186\uff1b\u6b27\u6d32LD\u53c2\u8003503\u4eba\u3002BBJ\u53ca\u5176\u4ed6\u975e\u6b27\u6d32\u7ed3\u5c40\u9650\u654f\u611f\u6027\u89e3\u91ca\u3002', '\u6ca1\u6709\u5408\u683c\u5de5\u5177\u76847\u4e2a\u57fa\u56e0\u4ecd\u4e0d\u53ef\u4f30\u8ba1\uff1b\u7f3a\u5c11\u5171\u540c\u4f4d\u70b9\u4e5f\u4e0d\u56e0\u5173\u95ed\u9891\u7387\u6838\u9a8c\u800c\u89e3\u51b3\u3002', '\u90e8\u5206GWAS\u4eba\u7fa4\u91cd\u53e0\uff0c\u4e0d\u5c5e\u4e8e14\u6b21\u72ec\u7acb\u9a8c\u8bc1\u3002\u5173\u95ed\u6838\u9a8c\u53ef\u80fd\u4fdd\u7559\u4eba\u7fa4\u9891\u7387\u4e0d\u5339\u914d\u4f4d\u70b9\uff0c\u4e0d\u80fd\u636e\u6b64\u58f0\u79f0\u56e0\u679c\u5df2\u8bc1\u5b9e\u3002', '', f"\u8fd0\u884c{len(tasks)}\u7ec4\uff1b\u5f97\u5230{len(frame)}\u6761\u4f30\u8ba1\uff0c\u8f83\u539f\u7248\u65b0\u589e{qa['n_new_estimates']}\u6761\uff1bRAW P<0.05\u5171{qa['nominal_raw_P_lt_005']}\u6761\u3002", '', '## GDF15\u7ed3\u679c']
    for r in frame[frame.gene == 'GDF15'].itertuples():
        lines.append(f'- {r.outcome_id}: SMR P={r.p_SMR:.8g}; HEIDI P={r.p_HEIDI:.8g}; beta={r.b_SMR:.8g}; topSNP={r.topSNP}')
    (ROOT / '\u7ed3\u679c\u4e0e\u65b9\u6cd5\u8bf4\u660e.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    shutil.copy2(Path(__file__), ROOT / 'code' / Path(__file__).name)
    shutil.copytree(ROOT, PUBLIC)
    for p in ROOT.rglob('*'):
        if p.is_file():
            assert sha(p) == sha(PUBLIC / p.relative_to(ROOT))
    print(json.dumps(qa, ensure_ascii=False, indent=2), flush=True)
    print(frame[frame.gene == 'GDF15'][['outcome_id', 'p_SMR', 'p_HEIDI']].to_string(index=False), flush=True)
    print('[DONE]', PUBLIC, flush=True)
if __name__ == '__main__':
    main()
