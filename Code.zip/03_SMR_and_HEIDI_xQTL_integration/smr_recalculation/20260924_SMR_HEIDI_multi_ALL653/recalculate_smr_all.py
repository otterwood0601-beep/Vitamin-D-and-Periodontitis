from __future__ import annotations
import importlib.util
import json
import shutil
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import numpy as np
import pandas as pd
BASE_SCRIPT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u91cd\u7b97\u7ed3\u679c\\20260923_SMR_HEIDI_multi_PSMR005\\recalculate_smr_47.py')
spec = importlib.util.spec_from_file_location('smr47', BASE_SCRIPT)
smr = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(smr)
ROOT = Path('E:\\_codex_tmp\\smr_recalc_all_20260924')
smr.TMP = ROOT
smr.STAGE = ROOT / 'inputs'
smr.RUNS = ROOT / 'runs'
smr.AUDIT = ROOT / 'audit'
smr.PUBLIC_ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u91cd\u7b97\u7ed3\u679c\\20260924_SMR_HEIDI_multi_ALL653')
smr.FINAL_CSV = smr.PUBLIC_ROOT / 'SMR_653_records_all_recalculated_full_schema.csv'
smr.SMR_EXE = Path('E:\\_codex_tmp\\smr_recalc_20260923\\software\\smr\\smr-1.3.1-win-x86_64\\smr-1.3.1-win.exe')
smr.PLINK_EXE = Path('E:\\_codex_tmp\\smr_recalc_20260923\\software\\plink.exe')
OLD_SPLIT_LD = Path('E:\\_codex_tmp\\smr_recalc_20260923\\inputs\\ld')

def basename_for_panel(panel_id: str) -> str:
    if panel_id.startswith('pQTL_SCALLOP'):
        return 'SCALLOP_GDF15'
    return ORIGINAL_BASENAME_FOR_PANEL(panel_id)
ORIGINAL_BASENAME_FOR_PANEL = smr.basename_for_panel
smr.basename_for_panel = basename_for_panel

def ensure_chromosome_ld(selected: pd.DataFrame) -> None:
    stage_ld = smr.STAGE / 'ld'
    stage_ld.mkdir(parents=True, exist_ok=True)
    chromosomes = sorted(selected['chromosome'].astype(int).astype(str).unique(), key=int)
    for chromosome in chromosomes:
        target = stage_ld / f'g1000_eur_chr{chromosome}'
        if all((Path(str(target) + ext).exists() for ext in ('.bed', '.bim', '.fam'))):
            continue
        old = OLD_SPLIT_LD / f'g1000_eur_chr{chromosome}'
        if all((Path(str(old) + ext).exists() for ext in ('.bed', '.bim', '.fam'))):
            for ext in ('.bed', '.bim', '.fam'):
                smr.link_or_copy(Path(str(old) + ext), Path(str(target) + ext))
            continue
        code = smr.run_command([str(smr.PLINK_EXE), '--bfile', str(smr.LD_PREFIX_SOURCE), '--chr', chromosome, '--make-bed', '--out', str(target)], smr.AUDIT / f'plink_split_chr{chromosome}.log')
        if code != 0:
            raise RuntimeError(f'PLINK chromosome extraction failed for chr{chromosome}')
        for ext in ('.bed', '.bim', '.fam'):
            smr.require(Path(str(target) + ext))
ORIGINAL_STAGE_INPUTS = smr.stage_inputs

def stage_inputs(selected: pd.DataFrame):
    ensure_chromosome_ld(selected)
    return ORIGINAL_STAGE_INPUTS(selected)
smr.stage_inputs = stage_inputs

def process_group(index: int, total: int, panel_id: str, outcome_id: str, gene: str, group: pd.DataFrame, ld_prefixes: dict, panel_prefixes: dict, gwas_files: dict):
    directory = smr.RUNS / f'g{index:03d}'
    directory.mkdir(parents=True, exist_ok=True)
    probes = sorted(group['probeID'].astype(str).unique())
    chromosomes = group['chromosome'].astype(int).astype(str).unique().tolist()
    if len(chromosomes) != 1:
        raise RuntimeError(f'Group has multiple chromosomes: {panel_id}, {outcome_id}, {gene}')
    chromosome = chromosomes[0]
    ld_prefix = ld_prefixes[chromosome, gene]
    probe_file = directory / 'probes.txt'
    probe_file.write_text('\n'.join(probes) + '\n', encoding='ascii')
    manifest = {'group_index': index, 'panel_id': panel_id, 'outcome_id': outcome_id, 'gene': gene, 'n_requested': len(probes), 'probes': probes}
    (directory / 'group_manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    common = [str(smr.SMR_EXE), '--bfile', str(ld_prefix), '--gwas-summary', str(gwas_files[outcome_id]), '--beqtl-summary', str(panel_prefixes[panel_id]), '--extract-probe', str(probe_file), '--peqtl-smr', str(smr.PEQTL), '--cis-wind', '2000', '--thread-num', '1']
    heidi_prefix = directory / 'targeted_HEIDI'
    heidi_path = Path(str(heidi_prefix) + '.smr')
    heidi_code = 0
    if not heidi_path.exists() or heidi_path.stat().st_size == 0:
        heidi_code = smr.run_command(common + ['--peqtl-heidi', str(smr.PEQTL), '--ld-upper-limit', str(smr.LD_UPPER), '--heidi-min-m', '3', '--heidi-max-m', '20', '--out', str(heidi_prefix)], directory / 'targeted_HEIDI.console.log')
    h = smr.read_smr(heidi_path)
    if not h.empty and 'probeID' in h.columns:
        keep = [c for c in ['probeID', 'p_HEIDI', 'nsnp_HEIDI', 'b_SMR', 'se_SMR', 'p_SMR'] if c in h.columns]
        h = h[keep].copy()
        h['panel_id'] = panel_id
        h['outcome_id'] = outcome_id
    else:
        h = pd.DataFrame()
    multi_prefix = directory / 'SMR_multi'
    multi_path = Path(str(multi_prefix) + '.msmr')
    multi_code = 0
    if not multi_path.exists() or multi_path.stat().st_size == 0:
        multi_code = smr.run_command(common + ['--smr-multi', '--ld-multi-snp', str(smr.LD_MULTI), '--heidi-off', '--out', str(multi_prefix)], directory / 'SMR_multi.console.log')
    m = smr.read_smr(multi_path)
    if not m.empty and 'probeID' in m.columns:
        candidates = [c for c in m.columns if c.lower() in {'p_smr_multi', 'p_multi', 'p_smr-multi'}]
        if candidates:
            m = m[['probeID', candidates[0]]].rename(columns={candidates[0]: 'p_SMR_multi'})
            m['panel_id'] = panel_id
            m['outcome_id'] = outcome_id
        else:
            m.to_csv(directory / 'SMR_multi_unrecognized_columns.csv', index=False, encoding='utf-8-sig')
            m = pd.DataFrame()
    else:
        m = pd.DataFrame()
    status = {'group_index': index, 'panel_id': panel_id, 'outcome_id': outcome_id, 'gene': gene, 'n_requested': len(probes), 'heidi_exit_code': heidi_code, 'heidi_rows': len(h), 'multi_exit_code': multi_code, 'multi_rows': len(m), 'heidi_result': str(heidi_path), 'multi_result': str(multi_path)}
    return (index, total, status, h, m)

def run_all_parallel(selected, ld_prefixes, panel_prefixes, gwas_files):
    groups = list(selected.groupby(['panel_id', 'outcome_id', 'gene'], sort=True))
    statuses, heidi_frames, multi_frames = ([], [], [])
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = []
        for index, ((panel_id, outcome_id, gene), group) in enumerate(groups, start=1):
            futures.append(pool.submit(process_group, index, len(groups), panel_id, outcome_id, gene, group.copy(), ld_prefixes, panel_prefixes, gwas_files))
        completed = 0
        for future in as_completed(futures):
            index, total, status, h, m = future.result()
            completed += 1
            statuses.append(status)
            if not h.empty:
                heidi_frames.append(h)
            if not m.empty:
                multi_frames.append(m)
            print(f"[{completed:03d}/{total:03d}] finished g{index:03d}: HEIDI {len(h)}/{status['n_requested']}, multi {len(m)}/{status['n_requested']}", flush=True)
    status_frame = pd.DataFrame(statuses).sort_values('group_index')
    heidi = pd.concat(heidi_frames, ignore_index=True) if heidi_frames else pd.DataFrame(columns=['probeID', 'p_HEIDI', 'nsnp_HEIDI', 'panel_id', 'outcome_id'])
    multi = pd.concat(multi_frames, ignore_index=True) if multi_frames else pd.DataFrame(columns=['probeID', 'p_SMR_multi', 'panel_id', 'outcome_id'])
    return (status_frame, heidi, multi)

def main() -> None:
    smr.require(smr.SMR_EXE)
    smr.require(smr.SOURCE_CSV)
    smr.require(smr.PLINK_EXE)
    smr.TMP.mkdir(parents=True, exist_ok=True)
    smr.RUNS.mkdir(parents=True, exist_ok=True)
    smr.AUDIT.mkdir(parents=True, exist_ok=True)
    smr.PUBLIC_ROOT.mkdir(parents=True, exist_ok=True)
    source = pd.read_csv(smr.SOURCE_CSV)
    source['p_SMR'] = pd.to_numeric(source['p_SMR'], errors='coerce')
    selected = source.copy()
    if len(selected) != 653:
        raise RuntimeError(f'Expected 653 analyzable records, found {len(selected)}')
    key = ['panel_id', 'outcome_id', 'probeID']
    if selected.duplicated(key).any():
        duplicated = selected.loc[selected.duplicated(key, keep=False), key + ['gene']]
        raise RuntimeError(f'Rows are not unique by panel/outcome/probe:\n{duplicated}')
    ld_prefixes, panel_prefixes, gwas_files, panel_manifest = smr.stage_inputs(selected)
    panel_manifest.to_csv(smr.AUDIT / 'input_panel_manifest.csv', index=False, encoding='utf-8-sig')
    selected.to_csv(smr.AUDIT / 'selected_653_source_rows.csv', index=False, encoding='utf-8-sig')
    status, heidi, multi = run_all_parallel(selected, ld_prefixes, panel_prefixes, gwas_files)
    status.to_csv(smr.AUDIT / 'run_status.csv', index=False, encoding='utf-8-sig')
    heidi.to_csv(smr.AUDIT / 'combined_HEIDI_results.csv', index=False, encoding='utf-8-sig')
    multi.to_csv(smr.AUDIT / 'combined_SMR_multi_results.csv', index=False, encoding='utf-8-sig')
    for frame, columns in [(heidi, ['p_HEIDI', 'nsnp_HEIDI', 'b_SMR', 'se_SMR', 'p_SMR']), (multi, ['p_SMR_multi'])]:
        for column in columns:
            if column in frame:
                frame[column] = pd.to_numeric(frame[column], errors='coerce')
    heidi_merge = heidi[[c for c in key + ['p_HEIDI', 'nsnp_HEIDI', 'b_SMR', 'se_SMR', 'p_SMR'] if c in heidi]].copy()
    heidi_merge = heidi_merge.rename(columns={'b_SMR': 'b_SMR_rerun', 'se_SMR': 'se_SMR_rerun', 'p_SMR': 'p_SMR_rerun'})
    multi_merge = multi[[c for c in key + ['p_SMR_multi'] if c in multi]].copy()
    merged = selected.drop(columns=['p_HEIDI', 'nsnp_HEIDI'], errors='ignore').merge(heidi_merge, on=key, how='left', validate='one_to_one')
    merged = merged.merge(multi_merge, on=key, how='left', validate='one_to_one')
    for column in ['b_SMR', 'se_SMR', 'p_SMR']:
        rerun_column = column + '_rerun'
        merged[column + '_absdiff'] = (pd.to_numeric(merged[column], errors='coerce') - pd.to_numeric(merged[rerun_column], errors='coerce')).abs()
    out = pd.DataFrame()
    out['trait'] = merged['outcome_label'].astype(str).str.replace('\n', ' ', regex=False)
    out['drug'] = 'VITAMIN D'
    out['gene'] = merged['gene']
    out['qtl_name'] = merged['panel_id'].map(smr.qtl_name)
    for column in ['probeID', 'ProbeChr', 'Probe_bp', 'topSNP', 'topSNP_chr', 'topSNP_bp', 'A1', 'A2', 'Freq', 'b_GWAS', 'se_GWAS', 'p_GWAS', 'b_eQTL', 'se_eQTL', 'p_eQTL', 'b_SMR', 'se_SMR', 'p_SMR']:
        out[column] = merged[column]
    out['p_SMR_multi'] = merged['p_SMR_multi']
    out['p_HEIDI'] = merged['p_HEIDI']
    out['nsnp_HEIDI'] = merged['nsnp_HEIDI']
    out[['gene_id', 'chr', 'start', 'end', 'strand']] = pd.DataFrame([smr.GENE_META[g] for g in out['gene']], index=out.index)
    out['GWAS_LOCUS'] = np.nan
    out['Lead_SNP'] = np.nan
    out['Lead_SNP_BP'] = np.nan
    out = out.sort_values(['gene', 'p_SMR', 'trait', 'qtl_name', 'probeID'], kind='stable')
    if len(out) != 653:
        raise RuntimeError(f'Expected 653 output rows, found {len(out)}')
    smr.write_title_csv(out, smr.FINAL_CSV)
    merged.to_csv(smr.PUBLIC_ROOT / 'SMR_HEIDI_multi_653_records_recalculated_raw.csv', index=False, encoding='utf-8-sig')
    for filename in ['run_status.csv', 'input_panel_manifest.csv', 'combined_HEIDI_results.csv', 'combined_SMR_multi_results.csv']:
        shutil.copy2(smr.AUDIT / filename, smr.PUBLIC_ROOT / filename)
    shutil.copy2(Path(__file__), smr.PUBLIC_ROOT / Path(__file__).name)
    validation = {'source_csv': str(smr.SOURCE_CSV), 'source_sha256': smr.file_sha256(smr.SOURCE_CSV), 'smr_executable': str(smr.SMR_EXE), 'smr_executable_sha256': smr.file_sha256(smr.SMR_EXE), 'n_records': int(len(out)), 'n_groups': int(len(status)), 'n_heidi_available': int(out['p_HEIDI'].notna().sum()), 'n_heidi_missing': int(out['p_HEIDI'].isna().sum()), 'n_multi_available': int(out['p_SMR_multi'].notna().sum()), 'n_multi_missing': int(out['p_SMR_multi'].isna().sum()), 'n_rerun_single_smr_available': int(merged['p_SMR_rerun'].notna().sum()), 'max_absdiff_b_SMR': float(merged['b_SMR_absdiff'].max(skipna=True)), 'max_absdiff_se_SMR': float(merged['se_SMR_absdiff'].max(skipna=True)), 'max_absdiff_p_SMR': float(merged['p_SMR_absdiff'].max(skipna=True)), 'parameters': {'p_record_filter': 'none; all 653 analyzable records', 'peqtl_smr': smr.PEQTL, 'peqtl_heidi': smr.PEQTL, 'ld_upper_limit': smr.LD_UPPER, 'heidi_min_m': 3, 'heidi_max_m': 20, 'ld_multi_snp': smr.LD_MULTI, 'parallel_workers': 4}, 'final_csv': str(smr.FINAL_CSV)}
    (smr.PUBLIC_ROOT / 'validation.json').write_text(json.dumps(validation, indent=2, ensure_ascii=False), encoding='utf-8')
    print('VALIDATION_JSON')
    print(json.dumps(validation, indent=2, ensure_ascii=False), flush=True)
if __name__ == '__main__':
    try:
        main()
    except Exception:
        import traceback
        traceback.print_exc()
        sys.exit(1)
