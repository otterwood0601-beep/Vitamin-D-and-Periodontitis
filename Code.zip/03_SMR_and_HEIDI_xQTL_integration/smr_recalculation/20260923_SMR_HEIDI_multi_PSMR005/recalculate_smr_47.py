from __future__ import annotations
import csv
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
import numpy as np
import pandas as pd
TMP = Path('E:\\_codex_tmp\\smr_recalc_20260923')
STAGE = TMP / 'inputs'
RUNS = TMP / 'runs'
AUDIT = TMP / 'audit'
PUBLIC_ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u91cd\u7b97\u7ed3\u679c\\20260923_SMR_HEIDI_multi_PSMR005')
FINAL_CSV = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u8865\u5145\u6570\u636e\\\u8865\u5145\u6570\u636e_SMR\u5206\u6790\u7ed3\u679c_PSMR\u4e0d\u5927\u4e8e0.05_HEIDI\u4e0eSMRmulti\u91cd\u7b97_\u975e\u7cbe\u7b80\u7248.csv')
SOURCE_CSV = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u539f\u59cb\u6570\u636e\\06_\u6700\u7ec8\u6295\u7a3f\u51fa\u56fe\u6e90\u8868\\03_\u6b63\u6587\u56fe3_SMR\u4e0eBulk-RNA\\SMR\\04_results\\02_11candidate_combined_all_results_recalculated.csv')
if not SOURCE_CSV.exists():
    SOURCE_CSV = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u539f\u59cb\u6570\u636e\\06_\u6700\u7ec8\u6295\u7a3f\u51fa\u56fe\u6e90\u8868\\03_\u6b63\u6587\u56fe3_SMR\u4e0eBulkRNA\\SMR\\04_results\\02_11candidate_combined_all_results_recalculated.csv')
XQTL_ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u539f\u59cb\u6570\u636e\\03_xQTL\u4e0e\u53c2\u8003\u9762\u677f')
GWAS_ROOT = Path('E:\\\u767d\u8272\u5ff5\u73e0\u83cc\\\u7ed3\u679c\u8f93\u51fa\\20260827_\u9f8b\u75c5_\u7259\u5468\u75c5_ProteoNexus_AZ_pQTL_SMR_HEIDI_\u8865\u5145_V1\\03_periodontitis_pQTL_to_GWAS\\03_prepared_GWAS')
LD_PREFIX_SOURCE = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u539f\u59cb\u6570\u636e\\03_xQTL\u4e0e\u53c2\u8003\u9762\u677f\\1000G_EUR\\g1000_eur')
SMR_EXE = TMP / 'software' / 'smr' / 'smr-1.3.1-win-x86_64' / 'smr-1.3.1-win.exe'
PLINK_EXE = TMP / 'software' / 'plink.exe'
P_CUTOFF = 0.05
PEQTL = 0.0016
LD_UPPER = 0.9
LD_MULTI = 0.1
GENE_ORDER = ['VDR', 'PLAU', 'TG', 'MYC', 'BTF3P11', 'PHEX', 'GDF15', 'CYP24A1', 'AR', 'GMNN', 'IL2']
GENE_META = {'VDR': ('ENSG00000111424', '12', 48235320, 48336831, '-'), 'PLAU': ('ENSG00000122861', '10', 75668935, 75677255, '+'), 'TG': ('ENSG00000042832', '8', 133879203, 134147147, '+'), 'MYC': ('ENSG00000136997', '8', 128747680, 128753674, '+'), 'BTF3P11': ('ENSG00000118903', '13', 77502200, 77502970, '+'), 'PHEX': ('ENSG00000102174', 'X', 22050559, 22269427, '+'), 'GDF15': ('ENSG00000130513', '19', 18485541, 18499986, '+'), 'CYP24A1': ('ENSG00000019186', '20', 52769988, 52790512, '-'), 'AR': ('ENSG00000169083', 'X', 66764465, 66950461, '+'), 'GMNN': ('ENSG00000112312', '6', 24775159, 24786327, '+'), 'IL2': ('ENSG00000109471', '4', 123372625, 123377880, '-')}
FULL_COLUMNS = ['trait', 'drug', 'gene', 'qtl_name', 'probeID', 'ProbeChr', 'Probe_bp', 'topSNP', 'topSNP_chr', 'topSNP_bp', 'A1', 'A2', 'Freq', 'b_GWAS', 'se_GWAS', 'p_GWAS', 'b_eQTL', 'se_eQTL', 'p_eQTL', 'b_SMR', 'se_SMR', 'p_SMR', 'p_SMR_multi', 'p_HEIDI', 'nsnp_HEIDI', 'gene_id', 'chr', 'start', 'end', 'strand', 'GWAS_LOCUS', 'Lead_SNP', 'Lead_SNP_BP']

def require(path: Path) -> Path:
    if not path.exists():
        raise FileNotFoundError(path)
    return path

def link_or_copy(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        return
    try:
        os.link(source, target)
    except OSError:
        shutil.copy2(source, target)

def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def basename_for_panel(panel_id: str) -> str:
    chromosome = re.search('_chr(\\d+)$', panel_id).group(1)
    if panel_id.startswith('eQTL_eQTLGen'):
        return 'eQTLGen_47candidate_cis'
    if panel_id.startswith('mQTL_McRae'):
        return f'bl_mqtl_lite_chr{chromosome}'
    if panel_id.startswith('pQTL_INTERVAL'):
        return 'INTERVAL_DGIdb18_candidate'
    if panel_id.startswith('sQTL_GTEx_Cells_Cultured_fibroblasts'):
        return f'sQTL_Cells_Cultured_fibroblasts.lite.chr{chromosome}'
    if panel_id.startswith('sQTL_GTEx_Whole_Blood'):
        return f'sQTL_Whole_Blood.lite.chr{chromosome}'
    raise ValueError(f'Unmapped panel: {panel_id}')

def find_prefix(basename: str) -> Path:
    matches = [p for p in XQTL_ROOT.rglob(f'{basename}.besd')]
    if len(matches) != 1:
        raise RuntimeError(f'Expected one BESD for {basename}, found {len(matches)}: {matches}')
    p = matches[0]
    prefix = p.parent / basename
    for ext in ('.besd', '.epi', '.esi'):
        require(Path(str(prefix) + ext))
    return prefix

def stage_inputs(selected: pd.DataFrame) -> tuple[dict[tuple[str, str], Path], dict[str, Path], dict[str, Path], pd.DataFrame]:
    stage_ld = STAGE / 'ld' / 'g1000_eur'
    for ext in ('.bed', '.bim', '.fam'):
        link_or_copy(require(Path(str(LD_PREFIX_SOURCE) + ext)), Path(str(stage_ld) + ext))
    panel_prefixes: dict[str, Path] = {}
    panel_rows = []
    for panel_id in sorted(selected['panel_id'].unique()):
        basename = basename_for_panel(panel_id)
        source = find_prefix(basename)
        target = STAGE / 'xqtl' / basename
        for ext in ('.besd', '.epi', '.esi'):
            link_or_copy(Path(str(source) + ext), Path(str(target) + ext))
        panel_prefixes[panel_id] = target
        panel_rows.append({'panel_id': panel_id, 'source_prefix': str(source), 'staged_prefix': str(target), 'basename': basename})
    gwas_files: dict[str, Path] = {}
    for outcome_id in sorted(selected['outcome_id'].unique()):
        source = require(GWAS_ROOT / f'{outcome_id}.ma')
        target = STAGE / 'gwas' / source.name
        link_or_copy(source, target)
        gwas_files[outcome_id] = target
    require(PLINK_EXE)
    ld_prefixes: dict[tuple[str, str], Path] = {}
    for (chromosome, gene), group in selected.groupby([selected['chromosome'].astype(int).astype(str), 'gene'], sort=True):
        chromosome_prefix = STAGE / 'ld' / f'g1000_eur_chr{chromosome}'
        for ext in ('.bed', '.bim', '.fam'):
            require(Path(str(chromosome_prefix) + ext))
        start_bp = max(1, int(pd.to_numeric(group['Probe_bp']).min()) - 2100000)
        end_bp = int(pd.to_numeric(group['Probe_bp']).max()) + 2100000
        region_prefix = STAGE / 'ld_regions' / f'chr{chromosome}_{gene}_{start_bp}_{end_bp}'
        region_prefix.parent.mkdir(parents=True, exist_ok=True)
        if not Path(str(region_prefix) + '.bed').exists():
            code = run_command([str(PLINK_EXE), '--bfile', str(chromosome_prefix), '--chr', chromosome, '--from-bp', str(start_bp), '--to-bp', str(end_bp), '--make-bed', '--out', str(region_prefix)], AUDIT / f'plink_region_chr{chromosome}_{gene}.log')
            if code != 0:
                raise RuntimeError(f'PLINK regional extraction failed for {gene} chr{chromosome}')
        for ext in ('.bed', '.bim', '.fam'):
            require(Path(str(region_prefix) + ext))
        ld_prefixes[chromosome, gene] = region_prefix
    return (ld_prefixes, panel_prefixes, gwas_files, pd.DataFrame(panel_rows))

def run_command(command: list[str], log_path: Path) -> int:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    completed = subprocess.run(command, text=True, capture_output=True, encoding='utf-8', errors='replace')
    log_path.write_text('COMMAND\n' + subprocess.list2cmdline(command) + '\n\nSTDOUT\n' + completed.stdout + '\n\nSTDERR\n' + completed.stderr + f'\n\nEXIT_CODE\n{completed.returncode}\n', encoding='utf-8')
    return completed.returncode

def read_smr(path: Path) -> pd.DataFrame:
    if not path.exists() or path.stat().st_size == 0:
        return pd.DataFrame()
    try:
        frame = pd.read_csv(path, sep='\\s+', engine='python', dtype=str)
    except pd.errors.EmptyDataError:
        return pd.DataFrame()
    return frame

def run_all(selected: pd.DataFrame, ld_prefixes: dict[tuple[str, str], Path], panel_prefixes: dict[str, Path], gwas_files: dict[str, Path]) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    statuses = []
    heidi_frames = []
    multi_frames = []
    groups = list(selected.groupby(['panel_id', 'outcome_id'], sort=True))
    for index, ((panel_id, outcome_id), group) in enumerate(groups, start=1):
        directory = RUNS / f'g{index:03d}'
        directory.mkdir(parents=True, exist_ok=True)
        probes = sorted(group['probeID'].astype(str).unique())
        chromosomes = group['chromosome'].astype(int).astype(str).unique().tolist()
        if len(chromosomes) != 1:
            raise RuntimeError(f'Group has multiple chromosomes: {panel_id}, {outcome_id}, {chromosomes}')
        genes = group['gene'].astype(str).unique().tolist()
        if len(genes) != 1:
            raise RuntimeError(f'Group has multiple genes: {panel_id}, {outcome_id}, {genes}')
        ld_prefix = ld_prefixes[chromosomes[0], genes[0]]
        probe_file = directory / 'probes.txt'
        probe_file.write_text('\n'.join(probes) + '\n', encoding='ascii')
        manifest = {'group_index': index, 'panel_id': panel_id, 'outcome_id': outcome_id, 'n_requested': len(probes), 'probes': probes}
        (directory / 'group_manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
        common = [str(SMR_EXE), '--bfile', str(ld_prefix), '--gwas-summary', str(gwas_files[outcome_id]), '--beqtl-summary', str(panel_prefixes[panel_id]), '--extract-probe', str(probe_file), '--peqtl-smr', str(PEQTL), '--cis-wind', '2000', '--thread-num', '1']
        heidi_prefix = directory / 'targeted_HEIDI'
        heidi_path = Path(str(heidi_prefix) + '.smr')
        heidi_code = 0
        if not heidi_path.exists() or heidi_path.stat().st_size == 0:
            heidi_code = run_command(common + ['--peqtl-heidi', str(PEQTL), '--ld-upper-limit', str(LD_UPPER), '--heidi-min-m', '3', '--heidi-max-m', '20', '--out', str(heidi_prefix)], directory / 'targeted_HEIDI.console.log')
        h = read_smr(heidi_path)
        if not h.empty and 'probeID' in h.columns:
            keep = [c for c in ['probeID', 'p_HEIDI', 'nsnp_HEIDI', 'b_SMR', 'se_SMR', 'p_SMR'] if c in h.columns]
            h = h[keep].copy()
            h['panel_id'] = panel_id
            h['outcome_id'] = outcome_id
            heidi_frames.append(h)
        multi_prefix = directory / 'SMR_multi'
        multi_path = Path(str(multi_prefix) + '.msmr')
        multi_code = 0
        if not multi_path.exists() or multi_path.stat().st_size == 0:
            multi_code = run_command(common + ['--smr-multi', '--ld-multi-snp', str(LD_MULTI), '--heidi-off', '--out', str(multi_prefix)], directory / 'SMR_multi.console.log')
        m = read_smr(multi_path)
        if not m.empty and 'probeID' in m.columns:
            p_multi_candidates = [c for c in m.columns if c.lower() in {'p_smr_multi', 'p_multi', 'p_smr-multi'}]
            if p_multi_candidates:
                m = m[['probeID', p_multi_candidates[0]]].rename(columns={p_multi_candidates[0]: 'p_SMR_multi'})
            else:
                m.to_csv(directory / 'SMR_multi_unrecognized_columns.csv', index=False, encoding='utf-8-sig')
                m = pd.DataFrame(columns=['probeID', 'p_SMR_multi'])
            if not m.empty:
                m['panel_id'] = panel_id
                m['outcome_id'] = outcome_id
                multi_frames.append(m)
        statuses.append({'group_index': index, 'panel_id': panel_id, 'outcome_id': outcome_id, 'n_requested': len(probes), 'heidi_exit_code': heidi_code, 'heidi_rows': len(h), 'multi_exit_code': multi_code, 'multi_rows': len(m), 'heidi_result': str(heidi_path), 'multi_result': str(multi_path)})
        print(f'[{index:02d}/{len(groups):02d}] {panel_id} \xd7 {outcome_id}: HEIDI {len(h)}/{len(probes)}, multi {len(m)}/{len(probes)}', flush=True)
    heidi = pd.concat(heidi_frames, ignore_index=True) if heidi_frames else pd.DataFrame(columns=['probeID', 'p_HEIDI', 'nsnp_HEIDI', 'panel_id', 'outcome_id'])
    multi = pd.concat(multi_frames, ignore_index=True) if multi_frames else pd.DataFrame(columns=['probeID', 'p_SMR_multi', 'panel_id', 'outcome_id'])
    return (pd.DataFrame(statuses), heidi, multi)

def qtl_name(panel_id: str) -> str:
    base = re.sub('_chr\\d+$', '', panel_id)
    return {'mQTL_McRae_Whole_Blood': 'mQTL_McRae'}.get(base, base)

def write_title_csv(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    title = 'SMR analysis results of 11 vitamin D-related candidate genes associated with periodontal traits'
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.writer(f, lineterminator='\n')
        writer.writerow([title] + [''] * (len(FULL_COLUMNS) - 1))
        writer.writerow(FULL_COLUMNS)
        for row in frame[FULL_COLUMNS].itertuples(index=False, name=None):
            writer.writerow(['NA' if pd.isna(v) or v == '' else v for v in row])

def main() -> None:
    require(SMR_EXE)
    require(SOURCE_CSV)
    TMP.mkdir(parents=True, exist_ok=True)
    RUNS.mkdir(parents=True, exist_ok=True)
    AUDIT.mkdir(parents=True, exist_ok=True)
    PUBLIC_ROOT.mkdir(parents=True, exist_ok=True)
    source = pd.read_csv(SOURCE_CSV)
    source['p_SMR'] = pd.to_numeric(source['p_SMR'], errors='coerce')
    selected = source.loc[source['p_SMR'].le(P_CUTOFF)].copy()
    if len(selected) != 47:
        raise RuntimeError(f'Expected exactly 47 records with p_SMR <= 0.05, found {len(selected)}')
    key = ['panel_id', 'outcome_id', 'probeID']
    if selected.duplicated(key).any():
        raise RuntimeError('Selected rows are not unique by panel/outcome/probe')
    ld_prefixes, panel_prefixes, gwas_files, panel_manifest = stage_inputs(selected)
    panel_manifest.to_csv(AUDIT / 'input_panel_manifest.csv', index=False, encoding='utf-8-sig')
    selected.to_csv(AUDIT / 'selected_47_source_rows.csv', index=False, encoding='utf-8-sig')
    status, heidi, multi = run_all(selected, ld_prefixes, panel_prefixes, gwas_files)
    status.to_csv(AUDIT / 'run_status.csv', index=False, encoding='utf-8-sig')
    heidi.to_csv(AUDIT / 'combined_HEIDI_results.csv', index=False, encoding='utf-8-sig')
    multi.to_csv(AUDIT / 'combined_SMR_multi_results.csv', index=False, encoding='utf-8-sig')
    for frame, cols in [(heidi, ['p_HEIDI', 'nsnp_HEIDI', 'b_SMR', 'se_SMR', 'p_SMR']), (multi, ['p_SMR_multi'])]:
        for c in cols:
            if c in frame:
                frame[c] = pd.to_numeric(frame[c], errors='coerce')
    heidi_merge = heidi[[c for c in key + ['p_HEIDI', 'nsnp_HEIDI', 'b_SMR', 'se_SMR', 'p_SMR'] if c in heidi]].copy()
    heidi_merge = heidi_merge.rename(columns={'b_SMR': 'b_SMR_rerun', 'se_SMR': 'se_SMR_rerun', 'p_SMR': 'p_SMR_rerun'})
    multi_merge = multi[[c for c in key + ['p_SMR_multi'] if c in multi]].copy()
    merged = selected.drop(columns=['p_HEIDI', 'nsnp_HEIDI'], errors='ignore').merge(heidi_merge, on=key, how='left', validate='one_to_one')
    merged = merged.merge(multi_merge, on=key, how='left', validate='one_to_one')
    for c in ['b_SMR', 'se_SMR', 'p_SMR']:
        rc = c + '_rerun'
        if rc in merged:
            merged[c + '_absdiff'] = (pd.to_numeric(merged[c], errors='coerce') - pd.to_numeric(merged[rc], errors='coerce')).abs()
    out = pd.DataFrame()
    out['trait'] = merged['outcome_label'].astype(str).str.replace('\n', ' ', regex=False)
    out['drug'] = 'VITAMIN D'
    out['gene'] = merged['gene']
    out['qtl_name'] = merged['panel_id'].map(qtl_name)
    for c in ['probeID', 'ProbeChr', 'Probe_bp', 'topSNP', 'topSNP_chr', 'topSNP_bp', 'A1', 'A2', 'Freq', 'b_GWAS', 'se_GWAS', 'p_GWAS', 'b_eQTL', 'se_eQTL', 'p_eQTL', 'b_SMR', 'se_SMR', 'p_SMR']:
        out[c] = merged[c]
    out['p_SMR_multi'] = merged.get('p_SMR_multi')
    out['p_HEIDI'] = merged.get('p_HEIDI')
    out['nsnp_HEIDI'] = merged.get('nsnp_HEIDI')
    out[['gene_id', 'chr', 'start', 'end', 'strand']] = pd.DataFrame([GENE_META[g] for g in out['gene']], index=out.index)
    out['GWAS_LOCUS'] = np.nan
    out['Lead_SNP'] = np.nan
    out['Lead_SNP_BP'] = np.nan
    out = out.sort_values(['gene', 'p_SMR', 'trait', 'qtl_name', 'probeID'], kind='stable')
    if len(out) != 47:
        raise RuntimeError(f'Final output should have 47 rows, found {len(out)}')
    write_title_csv(out, FINAL_CSV)
    raw_path = PUBLIC_ROOT / 'SMR_HEIDI_multi_47_records_recalculated.csv'
    merged.to_csv(raw_path, index=False, encoding='utf-8-sig')
    shutil.copy2(AUDIT / 'run_status.csv', PUBLIC_ROOT / 'run_status.csv')
    shutil.copy2(AUDIT / 'input_panel_manifest.csv', PUBLIC_ROOT / 'input_panel_manifest.csv')
    shutil.copy2(AUDIT / 'combined_HEIDI_results.csv', PUBLIC_ROOT / 'combined_HEIDI_results.csv')
    shutil.copy2(AUDIT / 'combined_SMR_multi_results.csv', PUBLIC_ROOT / 'combined_SMR_multi_results.csv')
    shutil.copy2(Path(__file__), PUBLIC_ROOT / Path(__file__).name)
    validation = {'source_csv': str(SOURCE_CSV), 'source_sha256': file_sha256(SOURCE_CSV), 'smr_executable': str(SMR_EXE), 'smr_executable_sha256': file_sha256(SMR_EXE), 'n_records': int(len(out)), 'n_groups': int(len(status)), 'n_heidi_available': int(out['p_HEIDI'].notna().sum()), 'n_heidi_missing': int(out['p_HEIDI'].isna().sum()), 'n_multi_available': int(out['p_SMR_multi'].notna().sum()), 'n_multi_missing': int(out['p_SMR_multi'].isna().sum()), 'max_absdiff_b_SMR': float(merged['b_SMR_absdiff'].max(skipna=True)), 'max_absdiff_se_SMR': float(merged['se_SMR_absdiff'].max(skipna=True)), 'max_absdiff_p_SMR': float(merged['p_SMR_absdiff'].max(skipna=True)), 'parameters': {'p_record_filter': 'p_SMR <= 0.05', 'peqtl_smr': PEQTL, 'peqtl_heidi': PEQTL, 'ld_upper_limit': LD_UPPER, 'heidi_min_m': 3, 'heidi_max_m': 20, 'ld_multi_snp': LD_MULTI}, 'final_csv': str(FINAL_CSV)}
    (PUBLIC_ROOT / 'validation.json').write_text(json.dumps(validation, indent=2, ensure_ascii=False), encoding='utf-8')
    print(json.dumps(validation, indent=2, ensure_ascii=False), flush=True)
if __name__ == '__main__':
    try:
        main()
    except Exception:
        import traceback
        traceback.print_exc()
        sys.exit(1)
