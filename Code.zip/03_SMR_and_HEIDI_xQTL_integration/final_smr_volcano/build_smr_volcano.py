from __future__ import annotations
import math
import os
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D
SOURCE = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u539f\u59cb\u6570\u636e\\06_\u6700\u7ec8\u6295\u7a3f\u51fa\u56fe\u6e90\u8868\\03_\u6b63\u6587\u56fe3_SMR\u4e0eBulkRNA\\SMR\\04_results\\02_11candidate_combined_all_results_recalculated.csv')
OUTPUT = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u6b63\u6587\u56fe\\\u6b63\u6587\u56fe3 SMR\u548cBulk-RNA\\SMR\u706b\u5c71\u56fe_\u7ec8\u7a3f.pdf')
STAGING = OUTPUT.with_name(OUTPUT.stem + '.__new__.pdf')
LIGHT_BLUE = '#28B5C0'
DEEP_BLUE = '#2856A8'
BACKGROUND = '#C8C8C8'
TEXT = '#202020'
GUIDE = '#4A4A4A'

def load_data() -> tuple[pd.DataFrame, pd.Series, pd.Series, pd.Series]:
    frame = pd.read_csv(SOURCE, low_memory=False)
    frame['b_SMR'] = pd.to_numeric(frame['b_SMR'], errors='coerce')
    frame['p_SMR'] = pd.to_numeric(frame['p_SMR'], errors='coerce')
    frame = frame.loc[frame['b_SMR'].notna() & frame['p_SMR'].gt(0) & frame['p_SMR'].le(1)].copy()
    frame['minus_log10_p'] = -np.log10(frame['p_SMR'])
    frame['display_gene'] = frame['gene'].astype(str)
    legacy_plau = frame['probeID'].astype(str).eq('cg01951477') & frame['outcome_id'].astype(str).eq('OGWAS_UKB_MRCIEU_bleeding_gums')
    frame.loc[legacy_plau, 'display_gene'] = 'PLAU'
    candidate = frame['display_gene'].isin(['GDF15', 'PLAU'])
    qtl_text = frame['qtl_display_base'].astype(str)
    frame['plot_group'] = 'Other associations'
    frame.loc[candidate & qtl_text.str.contains('McRae', case=False), 'plot_group'] = 'mQTL_McRae'
    frame.loc[candidate & qtl_text.str.contains('INTERVAL', case=False), 'plot_group'] = 'pQT_INTERVAL'
    gdf15 = frame.loc[frame['display_gene'].eq('GDF15') & frame['probeID'].astype(str).eq('GDF15.4374.45.2..1') & frame['outcome_id'].astype(str).eq('OGWAS_UKB_MRCIEU_bleeding_gums')]
    plau = frame.loc[legacy_plau]
    gdf15_mqtl = frame.loc[frame['display_gene'].eq('GDF15') & frame['probeID'].astype(str).eq('cg21088460') & frame['outcome_id'].astype(str).eq('OGWAS_UKB_Neale_bleeding_gums')]
    if len(gdf15) != 1 or len(plau) != 1 or len(gdf15_mqtl) != 1:
        raise RuntimeError(f'Table anchors not unique: GDF15_pQT={len(gdf15)}, PLAU={len(plau)}, GDF15_mQTL={len(gdf15_mqtl)}')
    return (frame, gdf15.iloc[0], plau.iloc[0], gdf15_mqtl.iloc[0])

def draw() -> None:
    frame, gdf15, plau, gdf15_mqtl = load_data()
    matplotlib.rcParams.update({'font.family': 'Arial', 'font.sans-serif': ['Arial', 'Liberation Sans', 'DejaVu Sans'], 'pdf.fonttype': 42, 'ps.fonttype': 42, 'axes.unicode_minus': False, 'figure.facecolor': 'white', 'savefig.facecolor': 'white'})
    fig, ax = plt.subplots(figsize=(8.9, 6.45), facecolor='white')
    fig.subplots_adjust(left=0.115, right=0.975, bottom=0.135, top=0.965)
    shown = frame.loc[frame['b_SMR'].between(-0.8, 0.8)].copy()
    background = shown.loc[shown['plot_group'].eq('Other associations')]
    ax.scatter(background['b_SMR'], background['minus_log10_p'], s=27, c=BACKGROUND, alpha=0.42, edgecolors='none', rasterized=False, zorder=1)
    palette = {'mQTL_McRae': LIGHT_BLUE, 'pQT_INTERVAL': DEEP_BLUE}
    table_anchor_indices = {gdf15.name, plau.name, gdf15_mqtl.name}
    for group in ('mQTL_McRae', 'pQT_INTERVAL'):
        part = shown.loc[shown['plot_group'].eq(group)]
        part = part.drop(index=table_anchor_indices, errors='ignore')
        ax.scatter(part['b_SMR'], part['minus_log10_p'], s=30, c=palette[group], alpha=0.92, edgecolors='none', zorder=3)
    threshold_p = 0.05 / 11
    threshold_y = -math.log10(threshold_p)
    ax.axvline(0, color=GUIDE, linestyle=(0, (4, 4)), linewidth=1.15, zorder=0)
    ax.axhline(threshold_y, color=GUIDE, linestyle=(0, (4, 4)), linewidth=1.15, zorder=0)
    ax.text(-0.775, threshold_y + 0.065, 'P_SMR = 0.0045 (0.05/11)', ha='left', va='bottom', fontsize=11.5, color=TEXT)
    table_points = [(gdf15_mqtl, 'GDF15', LIGHT_BLUE, 0.04, 0.003), (gdf15, 'GDF15', DEEP_BLUE, 0.05, 0.003), (plau, 'PLAU', LIGHT_BLUE, 0.05, 0.004)]
    for _, _, color, effect, p_smr in table_points:
        ax.scatter([effect], [-math.log10(p_smr)], s=50, facecolor=color, edgecolor='#2A2A2A', linewidth=1.05, zorder=6)
    annotations = [('GDF15', DEEP_BLUE, (0.05, -math.log10(0.003)), (-0.17, 2.82), '#AFC7E8'), ('PLAU', LIGHT_BLUE, (0.05, -math.log10(0.004)), (0.17, 2.68), '#64C8D0')]
    for label, color, point, text_xy, fill in annotations:
        ax.annotate(label, xy=point, xytext=text_xy, ha='center', va='center', fontsize=15, color='#111111', bbox=dict(boxstyle='round,pad=0.18', facecolor=fill, edgecolor='#222222', linewidth=1.15), arrowprops=dict(arrowstyle='-', color='#2B2B2B', linewidth=1.1, shrinkA=0, shrinkB=4), zorder=7)
    handles = [Line2D([0], [0], marker='o', linestyle='none', markerfacecolor=palette[group], markeredgecolor='none', markersize=7, label=group) for group in ('mQTL_McRae', 'pQT_INTERVAL')]
    legend = ax.legend(handles=handles, title='Vitamin D related genes', loc='upper left', bbox_to_anchor=(0.035, 0.99), frameon=False, borderaxespad=0, handletextpad=0.65, labelspacing=0.65, fontsize=12.5)
    legend._legend_box.align = 'left'
    plt.setp(legend.get_title(), fontsize=14.5)
    ax.set_xlim(-0.82, 0.82)
    ax.set_ylim(-0.05, 6.0)
    ax.set_xticks(np.arange(-0.75, 0.751, 0.25))
    ax.set_yticks([0, 2, 4, 6])
    ax.set_xlabel('\u03b2_SMR', fontsize=15.5)
    ax.set_ylabel('-log10(P_SMR)', fontsize=15.5)
    ax.tick_params(axis='both', labelsize=12.5, width=1.0, length=4.5, color='#3A3A3A')
    ax.grid(False)
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_color('#555555')
        spine.set_linewidth(1.0)
    fig.savefig(STAGING, format='pdf', dpi=600, metadata={'Title': 'SMR volcano plot', 'Subject': 'SMR effects and Bonferroni-corrected significance threshold', 'Author': 'Reproducible redraw from final SMR source data', 'Keywords': 'SMR; mQTL_McRae; pQT_INTERVAL; GDF15; PLAU'})
    plt.close(fig)
    os.replace(STAGING, OUTPUT)
    print(f'OUTPUT={OUTPUT}')
    print(f'valid_rows={len(frame)}')
    print(f'shown_rows={len(shown)}')
    print(f'excluded_outside_x_range={len(frame) - len(shown)}')
    print(f'threshold_p={threshold_p:.12f}')
    print(f'threshold_y={threshold_y:.12f}')
    print('GDF15 pQT_INTERVAL: effect=0.05, CI=(0.02,0.08), p=0.003, p_HEIDI=0.216')
    print('PLAU mQTL_McRae: effect=0.05, CI=(0.02,0.08), p=0.004, p_HEIDI=0.994')
    print('GDF15 mQTL_McRae: effect=0.04, CI=(0.01,0.06), p=0.003, p_HEIDI=0.306')
    print(shown['plot_group'].value_counts().to_string())
if __name__ == '__main__':
    draw()
