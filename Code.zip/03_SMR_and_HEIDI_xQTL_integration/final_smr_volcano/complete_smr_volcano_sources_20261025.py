from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import shutil
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd
BASE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--solid-gencord', action='store_true', help='User-approved filled orange GENCORD markers, separate revision')
parser.add_argument('--no-exploratory-note', action='store_true', help='Remove visible note and legend asterisk; retain provenance qualifications')
cli = parser.parse_args()
ROOT = BASE / ('SMR_volcano_all_requested_sources_20261025_solid_clean' if cli.no_exploratory_note else 'SMR_volcano_all_requested_sources_20261025_solid' if cli.solid_gencord else 'SMR_volcano_all_requested_sources_20261025')
ROOT.mkdir(exist_ok=True)
DEST = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u6b63\u6587\u56fe\\\u6b63\u6587\u56fe3 SMR\u548cBulk-RNA')
NEW = DEST / ('SMR\u706b\u5c71\u56fe_\u8865\u9f50\u6210\u7ea4\u7ef4\u7ec6\u80de_GENCORD_GTEx_\u5b9e\u5fc3\u65e0\u8bf4\u660e_20261025.pdf' if cli.no_exploratory_note else 'SMR\u706b\u5c71\u56fe_\u8865\u9f50\u6210\u7ea4\u7ef4\u7ec6\u80de_GENCORD_GTEx_\u5b9e\u5fc3\u70b9_20261025.pdf' if cli.solid_gencord else 'SMR\u706b\u5c71\u56fe_\u8865\u9f50\u6210\u7ea4\u7ef4\u7ec6\u80de_GENCORD_GTEx_20261025.pdf')
FINAL = ROOT / NEW.name
assert not NEW.exists() and (not FINAL.exists())
OLD = DEST / 'SMR\u706b\u5c71\u56fe_\u7ec8\u7a3f.pdf'
old_hash = hashlib.sha256(OLD.read_bytes()).hexdigest()
OLD_CODE = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u5f52\u6863\\20260913_SMR\u706b\u5c71\u56fe\u65e7\u7248\u4e0e\u8fd0\u7b97\u8fc7\u7a0b\\\u8fd0\u7b97\u8fc7\u7a0b\\smr_redo\\build_smr_volcano.py')
spec = importlib.util.spec_from_file_location('legacy_volcano', OLD_CODE)
legacy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(legacy)
frame, *_ = legacy.load_data()
sqtl = frame.loc[frame.gene.isin(['GDF15', 'GMNN']) & frame.qtl_type.eq('sQTL') & frame.tissue.eq('Cultured fibroblasts')].copy()
assert sqtl.groupby('gene').size().to_dict() == {'GDF15': 10, 'GMNN': 24}
GEN_SOURCE = BASE / 'Fibroblast_xQTL_P005_20261023/tables/\u6210\u7ea4\u7ef4\u7ec6\u80de\u5168\u90e8xQTL_P005_\u5408\u5e76\u660e\u7ec6.csv'
gen = pd.read_csv(GEN_SOURCE)
gen = gen.loc[gen.gene.eq('GMNN') & gen.dataset.eq('GENCORD_eQTL')].copy()
assert len(gen) == 14 and gen.outcome_id.nunique() == 14
assert gen.weak_F_lt_10.all() and gen.frequency_check_disabled.all()
assert gen.tier.eq('exploratory_005').all()
gen['minus_log10_p'] = -np.log10(gen.p_SMR)
for part in (gen, sqtl):
    assert part.p_SMR.between(0, 1, inclusive='right').all()
    assert not part[['gene', 'probeID', 'outcome_id']].duplicated().any()
    assert np.isfinite(part[['b_SMR', 'minus_log10_p']]).all().all()
sqtl['figure_source'] = 'sQTL_GTEx - fibroblasts'
sqtl['interpretation'] = 'Original source-table results; no rerun'
gen['figure_source'] = 'eQTL_GENCORD - fibroblasts'
gen['interpretation'] = 'Exploratory: F=9.997174<10 and frequency check disabled'
added = pd.concat([sqtl, gen], ignore_index=True)
added.to_csv(ROOT / 'added_or_highlighted_exact_statistics.csv', index=False, encoding='utf-8-sig')
GREEN = '#91C63A'
ORANGE = '#E99C15'
REFERENCE = Path('C:\\Users\\Lin\\Desktop\\\u53c2\u8003\u6587\u732e\\\u665a\u95f4\u663c\u591c\u8282\u5f8b\u504f\u597d\u4f5c\u4e3a\u764c\u75c7-\u6291\u90c1\u5171\u75c5\u7684\u6f5c\u5728\u5371\u9669\u56e0\u7d20_\u8865\u5145\u6750\u6599\\\u6587\u7ae0\u56fe\u7247_\u9ad8\u6e05\\Figure_3_gr3_lrg.jpg')
original_subplots = plt.subplots
qa = {}

def hooked_subplots(*args, **kwargs):
    fig, ax = original_subplots(*args, **kwargs)
    original_save = fig.savefig

    def save_completed(path, *a, **kw):
        legacy_offsets = [np.asarray(c.get_offsets(), dtype=float).copy() for c in ax.collections]
        ax.scatter(sqtl.b_SMR, sqtl.minus_log10_p, s=35, c=GREEN, edgecolors='none', alpha=0.94, zorder=4)
        gen_marks = ax.scatter(gen.b_SMR, gen.minus_log10_p, s=43, facecolors=ORANGE if cli.solid_gencord else 'none', edgecolors=ORANGE, linewidths=1.2, alpha=1, zorder=5)
        if cli.solid_gencord:
            assert len(gen_marks.get_facecolors()) > 0
            assert np.allclose(gen_marks.get_facecolors()[:, :3], matplotlib.colors.to_rgb(ORANGE))
            assert np.all(gen_marks.get_facecolors()[:, 3] == 1)
        for c, old in zip(ax.collections, legacy_offsets):
            assert np.array_equal(np.asarray(c.get_offsets(), dtype=float), old, equal_nan=True)
        ax.set_xlim(-2.15, 2.15)
        ticks = np.arange(-2, 2.001, 0.5)
        ax.set_xticks(ticks)
        ax.set_xticklabels([f'{x:.2f}' for x in ticks])
        for text in ax.texts:
            if text.get_text() == 'GDF15':
                text.set_position((-0.4, 2.82))
            elif text.get_text() == 'PLAU':
                text.set_position((0.4, 2.68))
            elif text.get_text().startswith('P_SMR ='):
                text.set_x(-2.02)
        handles = [Line2D([0], [0], marker='o', linestyle='none', markerfacecolor=c, markeredgecolor='none', markersize=7, label=l) for l, c in [('mQTL_McRae - blood', legacy.LIGHT_BLUE), ('pQTL_INTERVAL - plasma', legacy.DEEP_BLUE), ('sQTL_GTEx - fibroblasts', GREEN)]]
        handles.append(Line2D([0], [0], marker='o', linestyle='none', markerfacecolor=ORANGE if cli.solid_gencord else 'none', markeredgecolor=ORANGE, markeredgewidth=1.2, markersize=7, label='eQTL_GENCORD - fibroblasts' + ('' if cli.no_exploratory_note else '*')))
        leg = ax.legend(handles=handles, title='Vitamin D related genes', loc='upper left', bbox_to_anchor=(0.035, 0.99), frameon=False, borderaxespad=0, handletextpad=0.65, labelspacing=0.65, fontsize=11.8)
        leg._legend_box.align = 'left'
        plt.setp(leg.get_title(), fontsize=14.5)
        assert not any((t.get_text() == 'GMNN' for t in ax.texts))
        note = None
        if not cli.no_exploratory_note:
            fig.subplots_adjust(bottom=0.18)
            note = fig.text(0.115, 0.025, '*GENCORD: exploratory (F=9.997 < 10; allele-frequency check disabled).', fontsize=8.2, color='#555555', ha='left', va='bottom')
        assert added.b_SMR.between(*ax.get_xlim()).all()
        assert added.minus_log10_p.between(*ax.get_ylim()).all()
        fig.canvas.draw()
        renderer = fig.canvas.get_renderer()
        boxes = [leg.get_window_extent(renderer)]
        if note is not None:
            boxes.append(note.get_window_extent(renderer))
        fig_box = fig.bbox
        assert all((fig_box.contains(b.x0, b.y0) and fig_box.contains(b.x1, b.y1) for b in boxes))
        qa.update(legacy_mark_coordinates_unchanged=True, all_added_statistics_visible=True, new_GMNN_name_annotations=0, legend_and_note_inside_canvas=True, legacy_mark_count=sum((len(x) for x in legacy_offsets)))
        kw['metadata'].update(Title='SMR volcano - requested fibroblast sources completed', Subject='Legacy marks retained; GDF15/GMNN GTEx sQTL and exploratory GMNN GENCORD eQTL included')
        original_save(path, *a, **kw)
        original_save(ROOT / 'preview.png', dpi=180)
    fig.savefig = save_completed
    return (fig, ax)
legacy.plt.subplots = hooked_subplots
legacy.OUTPUT = FINAL
legacy.STAGING = FINAL.with_name(FINAL.stem + '.__new__.pdf')
legacy.draw()
assert hashlib.sha256(OLD.read_bytes()).hexdigest() == old_hash
shutil.copy2(FINAL, NEW)
audit = dict(original_sha256_unchanged=old_hash, outputs=[str(FINAL), str(NEW)], original_source=str(legacy.SOURCE), GENCORD_source=str(GEN_SOURCE), reference_palette=str(REFERENCE), palette={'GTEx_sQTL': GREEN, 'GENCORD_eQTL': ORANGE}, counts={'GDF15_GTEx_sQTL': 10, 'GMNN_GTEx_sQTL': 24, 'GMNN_GENCORD_eQTL': 14}, GENCORD_min_F=float(gen.F_instrument.min()), GENCORD_min_P=float(gen.p_SMR.min()), GENCORD_manuscript_eligible=False, GENCORD_marker='solid orange circle' if cli.solid_gencord else 'hollow orange circle', inclusion_approved_by_user=cli.solid_gencord, visible_exploratory_note=not cli.no_exploratory_note, caveats=['GENCORD exploratory estimates are not manuscript-standard eligible.', 'Original PLAU annotation points to TG probe cg01951477, retained by explicit user request.', 'Original highlighted coordinates retain the legacy rounding; not a scientific precision repair.', 'Original non-GMNN background selection remains unchanged.', 'No new SMR calculation or threshold relaxation performed.'], **qa)
(ROOT / 'audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
notes = '# \u8865\u9f50\u622a\u56fe\u6240\u5217\u6765\u6e90\n\n- \u4fdd\u7559\u539f\u56fe\u5168\u90e8\u70b9\u7684\u6570\u503c\u53ca\u65e7\u6807\u6ce8\uff0c\u539fPDF\u53ca\u4e0a\u4e00\u7248PDF\u4e0d\u8986\u76d6\u3002\n- \u8840\u6db2McRae mQTL\u548c\u8840\u6d46INTERVAL pQTL\u4fdd\u7559\u3002INTERVAL\u5b9e\u9645\u7ec4\u7ec7\u662f\u8840\u6d46\uff0c\u56fe\u4f8b\u636e\u5b9e\u5199plasma\u3002\n- \u7eff\u8272\u4e3aGTEx\u57f9\u517b\u6210\u7ea4\u7ef4\u7ec6\u80desQTL\uff1aGDF15 10\u6761\u3001GMNN 24\u6761\uff0c\u6765\u81ea\u539f\u56fe\u540c\u4e00\u4efd\u7ed3\u679c\u8868\u3002\n- \u7a7a\u5fc3\u6a59\u8272\u4e3aGENCORD\u57f9\u517b\u6210\u7ea4\u7ef4\u7ec6\u80deeQTL\uff1aGMNN 14\u6761\uff0c\u6765\u81ea\u65e2\u5f80P<0.05\u63a2\u7d22\u6027\u7ed3\u679c\u3002\n- GENCORD\u5de5\u5177F=9.997174\uff0c\u4e25\u683c\u4f4e\u4e8e10\uff0c\u4e14\u5173\u95ed\u8fc7\u9891\u7387\u68c0\u67e5\uff0c\u56e0\u6b64\u4e0d\u662f\u7a3f\u4ef6\u6807\u51c6\u5408\u683c\u7ed3\u679c\uff1b\u5df2\u5728\u56fe\u4e2d\u663e\u5f0f\u8bf4\u660e\u3002\n- \u672a\u8ffd\u52a0\u65b0\u7684\u57fa\u56e0\u540d\u79f0\u6216\u7bad\u5934\uff0c\u6ca1\u6709\u66f4\u6539SMR\u7edf\u8ba1\u91cf\uff0c\u4e5f\u6ca1\u6709\u65b0\u8ba1\u7b97/\u653e\u677e\u9608\u503c\u3002\n- \u65e7\u56fePLAU\u6807\u6ce8\u5bf9\u5e94\u7684cg01951477\u5b9e\u9645\u5c5e\u4e8eTG\uff1b\u6309\u7528\u6237\u4fdd\u7559\u539f\u70b9\u8981\u6c42\u672a\u4fee\u6b63\uff0c\u4e0d\u80fd\u4f5c\u4e3aPLAU\u8bc1\u636e\u3002\n- \u65e7\u7a81\u51fa\u70b9\u7684\u56db\u820d\u4e94\u5165\u5c55\u793a\u503c\u539f\u6837\u4fdd\u7559\uff1b\u672c\u6b21\u4ec5\u8865\u9f50\u56fe\u5f62\u6765\u6e90\uff0c\u4e0d\u4ee3\u8868\u5b8c\u6210\u5386\u53f2\u6570\u636e\u4fee\u590d\u3002\n'
if cli.solid_gencord:
    notes = notes.replace('\u7a7a\u5fc3\u6a59\u8272', '\u5b9e\u5fc3\u6a59\u8272')
    notes += '\n\u7528\u6237\u672c\u8f6e\u660e\u786e\u540c\u610f\u7eb3\u5165GENCORD\uff0c\u5e76\u6388\u6743\u6307\u5b9a\u70b9\u578b\u3001\u914d\u8272\u548c\u8bf4\u660e\uff0c\u8981\u6c42\u4e0d\u8981\u7a7a\u5fc3\uff1b\u4f7f\u7528\u5b9e\u5fc3\u6a59\u8272\u5706\u70b9\uff0c\u4fdd\u7559\u63a2\u7d22\u6027\u8bf4\u660e\u3002\n'
if cli.no_exploratory_note:
    notes = notes.replace('\u5df2\u5728\u56fe\u4e2d\u663e\u5f0f\u8bf4\u660e', '\u5206\u6790\u6761\u4ef6\u4ec5\u4fdd\u7559\u5728\u672c\u6765\u6e90\u8bf4\u660e\u548c\u5ba1\u8ba1\u8bb0\u5f55\u4e2d')
    notes += '\n\u6309\u7528\u6237\u6700\u540e\u8981\u6c42\u79fb\u9664\u56fe\u5185\u63a2\u7d22\u6027\u8bf4\u660e\u548c\u56fe\u4f8b\u661f\u53f7\uff1b\u6570\u636e\u4e0e\u5b9e\u9645\u5206\u6790\u6761\u4ef6\u672a\u6539\u53d8\uff0c\u4e0d\u80fd\u5c06\u5176\u89e3\u91ca\u4e3a\u901a\u8fc7F>=10\u3002\n'
(ROOT / '\u8bf4\u660e.md').write_text(notes, encoding='utf-8')
print(json.dumps(audit, ensure_ascii=True, indent=2))
