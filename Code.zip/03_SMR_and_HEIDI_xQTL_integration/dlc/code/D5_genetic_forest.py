import os, sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from style_npj import set_npj_style, save_npj, NPJ_CASE, NPJ_CTRL, MM
set_npj_style()
DER = 'C:\\wb_links\\dlc_derived'
OUTDIR = 'C:\\wb_links\\dlc_out\\\u7b2c5\u9879_\u9057\u4f20\u9a8c\u8bc1'
os.makedirs(OUTDIR, exist_ok=True)
r = pd.read_csv('C:\\wb_links\\serum_vit\\\u539f\u59cb\u6570\u636e\\06_\u6700\u7ec8\u6295\u7a3f\u51fa\u56fe\u6e90\u8868\\03_\u6b63\u6587\u56fe3_SMR\u4e0eBulkRNA\\SMR\\04_results\\02_11candidate_combined_all_results_recalculated.csv')
g = r[r['gene'] == 'GDF15'].copy()

def outcome_cat(s):
    s = str(s)
    if 'Bleeding gums' in s:
        return 'Bleeding gums (symptom)'
    if 'Painful gums' in s:
        return 'Painful gums (symptom)'
    if 'Clinical periodontitis' in s or ('periodontitis' in s.lower() and 'FinnGen' in s):
        return 'Clinical periodontitis'
    if 'Periodontitis + loose teeth' in s:
        return 'Clinical periodontitis'
    if 'Loose teeth' in s:
        return 'Loose teeth (symptom)'
    if 'GCF IL-1beta' in s:
        return 'GCF IL-1\u03b2 (proxy)'
    return 'Other'
g['outcome_cat'] = g['outcome_label'].map(outcome_cat)
g['layer'] = g['qtl_type'].map({'pQTL': 'Protein (pQTL)', 'mQTL': 'Methylation (mQTL)', 'eQTL': 'Expression (eQTL)', 'sQTL': 'Splicing (sQTL)'}).fillna(g['qtl_type'])
best = g.loc[g.groupby(['layer', 'outcome_cat'])['p_SMR'].idxmin()].copy()
best['log'] = -np.log10(best['p_SMR'])
best = best.sort_values(['outcome_cat', 'layer'])
best['heidi'] = best['HEIDI_pass'].map({True: 'HEIDI pass', False: 'HEIDI fail'}).fillna('no HEIDI')
best.to_csv(os.path.join(DER, 'D5_GDF15_best_SMR_per_layer_outcome.csv'), index=False)
print(best[['layer', 'outcome_cat', 'outcome_label', 'b_SMR', 'ci95_lower', 'ci95_upper', 'p_SMR', 'p_HEIDI', 'heidi']].to_string())
cats = ['Bleeding gums (symptom)', 'Painful gums (symptom)', 'Loose teeth (symptom)', 'GCF IL-1\u03b2 (proxy)', 'Clinical periodontitis']
cat_col = {'Bleeding gums (symptom)': '#C9403B', 'Painful gums (symptom)': '#E6862E', 'Loose teeth (symptom)': '#E5C832', 'GCF IL-1\u03b2 (proxy)': '#8AA87E', 'Clinical periodontitis': '#4A8FD4'}
rows = best[best.outcome_cat.isin(cats)].reset_index(drop=True)
fig = plt.figure(figsize=(180 * MM, 105 * MM))
gs = fig.add_gridspec(1, 1, left=0.205, right=0.6, top=0.88, bottom=0.14)
ax = fig.add_subplot(gs[0, 0])
ypos = []
ylab = []
y = 0
for cat in cats:
    sub = rows[rows.outcome_cat == cat]
    if not len(sub):
        continue
    for _, rw in sub.iterrows():
        y -= 1
        heidi_ok = rw['heidi'] == 'HEIDI pass'
        c = cat_col[cat] if heidi_ok else '#9E9E9E'
        lo, hi = (rw['ci95_lower'], rw['ci95_upper'])
        ax.plot([lo, hi], [y, y], lw=1.2, c=c)
        ax.scatter([rw['b_SMR']], [y], s=42 if heidi_ok else 26, c=c, marker='D' if heidi_ok else 'o', ec='black', lw=0.4, zorder=3)
        sig = '*' if rw['p_SMR'] < 0.05 else ''
        info = f"{rw['layer']} | {rw['qtl_source']} {rw['tissue']} | p={rw['p_SMR']:.3f}{sig}" + (f" | HEIDI p={rw['p_HEIDI']:.2f}" if not pd.isna(rw['p_HEIDI']) else ' | no HEIDI')
        ax.text(0.0116, y, info, fontsize=5.6, va='center', clip_on=False)
    y -= 0.8
    ypos.append((y + 0.4, cat))
for yy, cat in ypos:
    ax.text(-0.0218, yy, cat, fontsize=7.5, fontweight='bold', color=cat_col[cat], va='center', ha='right', clip_on=False)
ax.axvline(0, c='black', lw=0.6, ls='--')
ax.set_ylim(y - 1, 0.5)
ax.set_yticks([])
ax.set_xlim(-0.0215, 0.0112)
ax.set_xlabel('b_SMR (effect on outcome per unit molecular trait)')
handles = [Line2D([], [], marker='D', ls='', mfc='white', mec='black', ms=6, label='HEIDI pass (strict)'), Line2D([], [], marker='o', ls='', mfc='#9E9E9E', mec='black', ms=5, label='HEIDI fail / not run')]
ax.legend(handles=handles, loc='upper left', bbox_to_anchor=(1.02, -0.08), fontsize=6.5, frameon=False)
ax.set_title('GDF15 molecular QTL \u2192 periodontal outcomes (best probe per layer \xd7 outcome)', fontsize=8, fontweight='bold', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=0.35'))
fig.text(0.035, 0.94, 'A', fontsize=12, fontweight='bold')
save_npj(fig, os.path.join(OUTDIR, '\u7b2c5\u9879_GDF15\u9057\u4f20\u68ee\u6797\u56fe'), width_mm=180, height_mm=105, dpi=600)
print('FIG SAVED')
