options(stringsAsFactors=FALSE,warn=-1)
suppressPackageStartupMessages({
  library(dplyr);library(tidyr);library(purrr);library(readr);library(tibble);library(stringr)
  library(ggplot2);library(patchwork);library(caret);library(glmnet);library(car);library(pROC);library(PRROC)
  library(xgboost);library(scales)
})
for(p in c("ranger","kernlab","rpart","klaR","e1071","fastshap","MASS"))if(!requireNamespace(p,quietly=TRUE))stop("Missing package: ",p)
cmd_file<-grep("^--file=",commandArgs(trailingOnly=FALSE),value=TRUE)
if(!length(cmd_file))stop("\u8bf7\u4f7f\u7528 Rscript \u8fd0\u884c\u672c\u6587\u4ef6\u3002",call.=FALSE)
script_file<-normalizePath(sub("^--file=","",cmd_file[[1]]),winslash="/",mustWork=TRUE)
script_dir<-dirname(script_file);root<-dirname(script_dir)
source(file.path(script_dir,"00_\u5206\u6790\u914d\u7f6e.R"),encoding="UTF-8")
seed<-analysis_seed;set.seed(seed)
main<-readRDS(file.path(root,"\u7b2c12\u6b65_\u6570\u636e\u96c6\u5212\u5206","01_NHANES2009-2014_\u673a\u5668\u5b66\u4e60\u4e25\u683c\u5b8c\u6574\u75c5\u4f8b\u6837\u672c.rds"))
dirs<-list(lasso=file.path(root,"\u7b2c11\u6b65_LASSO\u7279\u5f81\u7b5b\u9009"),split=file.path(root,"\u7b2c12\u6b65_\u6570\u636e\u96c6\u5212\u5206"),coll=file.path(root,"\u7b2c12\u6b65\u9644\u52a0_\u591a\u91cd\u5171\u7ebf\u6027\u4e0eSpearman\u76f8\u5173\u5206\u6790"),models=file.path(root,"\u7b2c13\u6b65_\u4e03\u79cd\u673a\u5668\u5b66\u4e60\u6a21\u578b\u8bad\u7ec3\u4e0e\u4f18\u5316"),perf=file.path(root,"\u7b2c14\u6b65_\u591a\u7ef4\u5ea6\u6a21\u578b\u6027\u80fd\u8bc4\u4f30"),roc=file.path(root,"\u7b2c14\u6b65_\u591a\u7ef4\u5ea6\u6a21\u578b\u6027\u80fd\u8bc4\u4f30","01_ROC\u66f2\u7ebf"),cal=file.path(root,"\u7b2c14\u6b65_\u591a\u7ef4\u5ea6\u6a21\u578b\u6027\u80fd\u8bc4\u4f30","02_\u6821\u51c6\u66f2\u7ebf"),dca=file.path(root,"\u7b2c14\u6b65_\u591a\u7ef4\u5ea6\u6a21\u578b\u6027\u80fd\u8bc4\u4f30","03_\u51b3\u7b56\u66f2\u7ebfDCA"),cm=file.path(root,"\u7b2c14\u6b65_\u591a\u7ef4\u5ea6\u6a21\u578b\u6027\u80fd\u8bc4\u4f30","04_\u6df7\u6dc6\u77e9\u9635"),shap=file.path(root,"\u7b2c18\u6b65_SHAP\u53ef\u89e3\u91ca\u6027\u5206\u6790"),shapg=file.path(root,"\u7b2c18\u6b65_SHAP\u53ef\u89e3\u91ca\u6027\u5206\u6790","01_\u5168\u5c40SHAP"),shapl=file.path(root,"\u7b2c18\u6b65_SHAP\u53ef\u89e3\u91ca\u6027\u5206\u6790","02_\u5c40\u90e8SHAP\u529b\u56fe"),shapv=file.path(root,"\u7b2c18\u6b65_SHAP\u53ef\u89e3\u91ca\u6027\u5206\u6790","03_\u7ef4\u751f\u7d20D\u4f9d\u8d56"),dmft=file.path(root,"\u7b2c18\u6b65\u9644\u52a0_\u9884\u6d4b\u6982\u7387\u4e0eDMFT"),qa=file.path(root,"\u7b2c19\u6b65_\u8d28\u91cf\u6838\u9a8c\u4e0e\u53ef\u590d\u73b0\u4ee3\u7801"))
invisible(lapply(dirs,dir.create,recursive=TRUE,showWarnings=FALSE))
write_bom<-function(x,p)readr::write_excel_csv(x,p,na="")
save_plot<-function(p,dir,stem,w=10,h=7){ggsave(file.path(dir,paste0(stem,".png")),p,width=w,height=h,dpi=320,bg="white",limitsize=FALSE);ggsave(file.path(dir,paste0(stem,".pdf")),p,width=w,height=h,device=cairo_pdf,bg="white",limitsize=FALSE)}
theme_pub<-function(bs=12)theme_classic(base_size=bs)+theme(plot.title=element_text(face="bold",size=bs+3),plot.subtitle=element_text(colour="grey30"),axis.title=element_text(face="bold"),legend.title=element_text(face="bold"),strip.background=element_rect(fill="grey94",colour="grey75"),strip.text=element_text(face="bold"))

numeric_features<-c("vitd_nmol","floss_days","mouthwash_days","missing_teeth_count","implant_count","bmi","age","energy_kcal","sugar_g","cholesterol_mg","fat_g","fiber_g","protein_g","calcium_mg","phosphorus_mg")
categorical_features<-c("smoking","alcohol","physical_activity","diabetes","hypertension","cvd","ckd","liver","thyroid","sex","education","marital","pir_cat","race")
candidate_features<-c(numeric_features,categorical_features)
feature_labels<-c(vitd_nmol="Serum 25(OH)D (nmol/L)",floss_days="Floss/interdental cleaning days",mouthwash_days="Mouthwash days for oral problems",missing_teeth_count="Missing teeth count",implant_count="Dental implant count",bmi="BMI",age="Age (years)",energy_kcal="Energy intake",sugar_g="Total sugar intake",cholesterol_mg="Cholesterol intake",fat_g="Fat intake",fiber_g="Dietary fiber",protein_g="Protein intake",calcium_mg="Calcium intake",phosphorus_mg="Phosphorus intake",smoking="Smoking status",alcohol="Alcohol consumption",physical_activity="Physical activity",diabetes="Diabetes",hypertension="Hypertension",cvd="Cardiovascular disease",ckd="Chronic kidney disease",liver="Liver disease",thyroid="Thyroid disease",sex="Sex",education="Education",marital="Marital status",pir_cat="PIR category",race="Race/ethnicity")
lab<-function(x)ifelse(x%in%names(feature_labels),feature_labels[x],x)
stopifnot(length(candidate_features)==29L,setequal(candidate_features,c("vitd_nmol","floss_days","mouthwash_days","missing_teeth_count","implant_count","smoking","alcohol","physical_activity","diabetes","hypertension","cvd","ckd","liver","thyroid","sex","bmi","age","education","marital","pir_cat","race","energy_kcal","sugar_g","cholesterol_mg","fat_g","fiber_g","protein_g","calcium_mg","phosphorus_mg")))
main$outcome<-factor(as.character(main$periodontitis),levels=c("Yes","No"))

idx<-caret::createDataPartition(main$outcome,p=.80,list=FALSE)[,1];train_raw<-main[idx,,drop=FALSE];test_raw<-main[-idx,,drop=FALSE]
mode_value<-function(x){z<-as.character(x[!is.na(x)]);if(!length(z))return(NA_character_);names(sort(table(z),decreasing=TRUE))[1]}

fit_imputer<-function(d){med<-setNames(vapply(numeric_features,function(v){z<-suppressWarnings(as.numeric(d[[v]]));m<-median(z[is.finite(z)],na.rm=TRUE);ifelse(is.finite(m),m,0)},numeric(1)),numeric_features);modes<-setNames(vapply(categorical_features,function(v)mode_value(d[[v]]),character(1)),categorical_features);levs<-setNames(lapply(categorical_features,function(v)sort(unique(na.omit(c(as.character(d[[v]]),modes[[v]]))))),categorical_features);list(medians=med,modes=modes,levels=levs)}
apply_imputer<-function(d,imp){out<-d;for(v in numeric_features){z<-suppressWarnings(as.numeric(out[[v]]));z[!is.finite(z)]<-imp$medians[[v]];out[[v]]<-z};for(v in categorical_features){z<-as.character(out[[v]]);z[is.na(z)|!z%in%imp$levels[[v]]]<-imp$modes[[v]];out[[v]]<-factor(z,levels=imp$levels[[v]])};out}
imp<-fit_imputer(train_raw);train<-apply_imputer(train_raw,imp);test<-apply_imputer(test_raw,imp)

split_sum<-bind_rows(tibble(dataset="NHANES 2009-2014 training",n=nrow(train),cases=sum(train$outcome=="Yes"),prevalence=mean(train$outcome=="Yes")),tibble(dataset="NHANES 2009-2014 test",n=nrow(test),cases=sum(test$outcome=="Yes"),prevalence=mean(test$outcome=="Yes")))
write_bom(split_sum,file.path(dirs$split,"03_\u8bad\u7ec3\u6d4b\u8bd5\u6837\u672c\u91cf.csv"));write_bom(tibble(participant_id=train$participant_id,cycle=train$cycle,outcome=train$outcome),file.path(dirs$split,"04_NHANES\u8bad\u7ec3\u96c6ID.csv"));write_bom(tibble(participant_id=test$participant_id,cycle=test$cycle,outcome=test$outcome),file.path(dirs$split,"05_NHANES\u6d4b\u8bd5\u96c6ID.csv"));saveRDS(list(train=train,test=test,imputer=imp,seed=seed),file.path(dirs$split,"07_\u56fa\u5b9a\u5212\u5206\u4e0e\u8bad\u7ec3\u96c6\u63d2\u8865\u5bf9\u8c61.rds"))

balance_vars<-c(candidate_features,"periodontitis")
balance_rows<-map_dfr(balance_vars,function(v){if(v%in%c(numeric_features,"DMFT")){a<-train_raw[[v]];b<-test_raw[[v]];p<-tryCatch(wilcox.test(a,b)$p.value,error=function(e)NA_real_);tibble(Variable=unname(lab(v)),Level="Mean +/- SD",Training=sprintf("%.2f +/- %.2f",mean(a,na.rm=T),sd(a,na.rm=T)),Test=sprintf("%.2f +/- %.2f",mean(b,na.rm=T),sd(b,na.rm=T)),P=p)}else{lev<-sort(unique(na.omit(c(as.character(train_raw[[v]]),as.character(test_raw[[v]])))));p<-tryCatch(chisq.test(table(factor(c(rep("Training",nrow(train_raw)),rep("Test",nrow(test_raw)))),factor(c(as.character(train_raw[[v]]),as.character(test_raw[[v]])),levels=lev)))$p.value,error=function(e)NA_real_);map_dfr(seq_along(lev),function(i)tibble(Variable=ifelse(i==1,unname(lab(v)),""),Level=lev[i],Training=sprintf("%d (%.1f%%)",sum(as.character(train_raw[[v]])==lev[i],na.rm=T),100*mean(as.character(train_raw[[v]])==lev[i],na.rm=T)),Test=sprintf("%d (%.1f%%)",sum(as.character(test_raw[[v]])==lev[i],na.rm=T),100*mean(as.character(test_raw[[v]])==lev[i],na.rm=T)),P=ifelse(i==1,p,NA_real_)))}}) |> mutate(`P value`=ifelse(is.na(P),"",ifelse(P<.001,"<0.001",sprintf("%.3f",P))))
write_bom(balance_rows,file.path(dirs$split,"08_\u8868S3_\u8bad\u7ec3\u96c6\u4e0e\u6d4b\u8bd5\u96c6\u57fa\u7ebf\u5747\u8861\u6027.csv"))

rank_data<-as.data.frame(lapply(train[candidate_features],function(x)if(is.numeric(x))x else as.numeric(factor(x))))
rho<-cor(rank_data,method="spearman",use="pairwise.complete.obs");rho_long<-as.data.frame(as.table(rho),stringsAsFactors=FALSE);names(rho_long)<-c("Variable1","Variable2","Spearman_rho");rho_long$Variable1_label<-lab(rho_long$Variable1);rho_long$Variable2_label<-lab(rho_long$Variable2)
write_bom(rho_long,file.path(dirs$coll,"01_\u5168\u90e8\u5019\u9009\u53d8\u91cfSpearman\u76f8\u5173\u77e9\u9635\u957f\u8868.csv"));write_bom(as.data.frame(rho)|>rownames_to_column("Variable"),file.path(dirs$coll,"02_\u5168\u90e8\u5019\u9009\u53d8\u91cfSpearman\u76f8\u5173\u77e9\u9635.csv"))
priority<-c("vitd_nmol","missing_teeth_count","implant_count","floss_days","mouthwash_days","sugar_g","age","bmi","smoking","alcohol","physical_activity","diabetes","hypertension","cvd","ckd","liver","thyroid","sex","education","marital","pir_cat","race","fiber_g","calcium_mg","phosphorus_mg","protein_g","fat_g","energy_kcal","cholesterol_mg")
highpairs<-rho_long |> filter(as.character(Variable1)<as.character(Variable2),abs(Spearman_rho)>=.80) |> arrange(desc(abs(Spearman_rho)))
drop_spear<-character();if(nrow(highpairs))for(i in seq_len(nrow(highpairs))){a<-highpairs$Variable1[i];b<-highpairs$Variable2[i];if(a%in%drop_spear|b%in%drop_spear)next;pa<-match(a,priority);pb<-match(b,priority);drop_spear<-c(drop_spear,ifelse(pa<=pb,b,a))}
spear_candidates<-setdiff(candidate_features,drop_spear)

rh<-rho_long |> mutate(row_id=match(as.character(Variable1),candidate_features),col_id=match(as.character(Variable2),candidate_features)) |> filter(row_id>=col_id) |> mutate(Variable1_label=factor(Variable1_label,levels=rev(lab(candidate_features))),Variable2_label=factor(Variable2_label,levels=lab(candidate_features)),number_colour=ifelse(abs(Spearman_rho)>=.55,"white","#252525"))
ph<-ggplot(rh,aes(Variable2_label,Variable1_label,fill=Spearman_rho))+geom_tile(colour="white",linewidth=.25)+geom_text(aes(label=sprintf("%.2f",Spearman_rho),colour=number_colour),size=2.15,show.legend=FALSE)+scale_colour_identity()+scale_fill_gradient2(low="#2166AC",mid="white",high="#B2182B",limits=c(-1,1))+coord_equal()+labs(title="Spearman correlation of all first-screen candidates",subtitle="Lower triangle with coefficients; continuous values and rank-coded categorical variables; NHANES training set",x=NULL,y=NULL,fill="Spearman rho")+theme_minimal(base_size=8.5)+theme(plot.title=element_text(face="bold",size=14),axis.text.x=element_text(angle=55,hjust=1),panel.grid=element_blank())
save_plot(ph,dirs$coll,"03_Spearman\u5168\u90e8\u5019\u9009\u53d8\u91cf\u76f8\u5173\u6027\u70ed\u56fe",16,14)

vif_df<-train |> select(outcome,all_of(spear_candidates));vif_fit<-lm(as.integer(outcome=="Yes")~.,data=vif_df);vr<-car::vif(vif_fit)
if(is.matrix(vr))vif_tab<-as.data.frame(vr)|>rownames_to_column("variable")|>rename(GVIF=GVIF,Df=Df,GVIF_adjusted=`GVIF^(1/(2*Df))`) else vif_tab<-tibble(variable=names(vr),GVIF=as.numeric(vr),Df=1,GVIF_adjusted=sqrt(as.numeric(vr)))
vif_tab<-vif_tab |> mutate(variable_label=lab(variable),screening_order="After Spearman screen",threshold=ifelse(Df==1,"VIF >=10","GVIF^(1/(2*Df)) >=2.24"),delete=ifelse(Df==1,GVIF>=10,GVIF_adjusted>=2.24),reason=ifelse(delete,"Exceeded prespecified collinearity threshold","Retained"))
write_bom(vif_tab,file.path(dirs$coll,"04_VIF_GVIF\u8bca\u65ad\u8868.csv"))

drop_vif<-vif_tab$variable[vif_tab$delete];deleted<-union(drop_spear,drop_vif);lasso_candidates<-setdiff(candidate_features,deleted)
delete_audit<-bind_rows(tibble(variable=drop_spear,stage="Spearman",reason="Absolute Spearman rho >=0.80; lower-priority member removed"),tibble(variable=drop_vif,stage="VIF/GVIF",reason="Exceeded prespecified VIF/GVIF threshold")) |> distinct(variable,.keep_all=TRUE) |> mutate(variable_label=lab(variable))
write_bom(highpairs,file.path(dirs$coll,"05_Spearman\u7edd\u5bf9\u503c\u5927\u4e8e\u7b49\u4e8e0.80\u53d8\u91cf\u5bf9.csv"));write_bom(delete_audit,file.path(dirs$coll,"06_\u5220\u9664\u53d8\u91cf\u53ca\u5177\u4f53\u539f\u56e0.csv"));write_bom(tibble(variable=lasso_candidates,variable_label=lab(lasso_candidates)),file.path(dirs$coll,"07_\u6700\u7ec8\u8fdb\u5165LASSO\u7684\u5019\u9009\u53d8\u91cf\u5217\u8868.csv"))

dummy_lasso<-dummyVars(~.,data=train[lasso_candidates],fullRank=TRUE);XL<-predict(dummy_lasso,train[lasso_candidates])|>as.matrix();colnames(XL)<-make.names(colnames(XL),unique=TRUE);y<-as.integer(train$outcome=="Yes")
raw_map<-vapply(colnames(XL),function(z){hits<-lasso_candidates[startsWith(z,make.names(lasso_candidates))];if(length(hits))hits[which.max(nchar(hits))] else z},character(1));penalty<-ifelse(raw_map=="vitd_nmol",0,1)
foldid<-integer(nrow(train));folds<-createFolds(train$outcome,k=10,returnTrain=FALSE);for(i in seq_along(folds))foldid[folds[[i]]]<-i
cv<-cv.glmnet(XL,y,family="binomial",alpha=1,nfolds=10,foldid=foldid,type.measure="auc",penalty.factor=penalty,standardize=TRUE,keep=TRUE)
selected_raw<-function(lambda){co<-as.matrix(coef(cv$glmnet.fit,s=lambda));nz<-rownames(co)[co[,1]!=0];nz<-setdiff(nz,"(Intercept)");unique(raw_map[match(nz,colnames(XL))])}
s1<-selected_raw(cv$lambda.1se);smin<-selected_raw(cv$lambda.min);path_counts<-tibble(lambda=cv$lambda,log_lambda=log(cv$lambda),raw_n=vapply(cv$lambda,function(l)length(selected_raw(l)),integer(1)),auc=cv$cvm,se=cv$cvsd)
chosen_lambda<-cv$lambda.1se
chosen_raw<-s1
co<-as.matrix(coef(cv$glmnet.fit,s=chosen_lambda));coef_tab<-tibble(dummy=rownames(co),coefficient=co[,1]) |> filter(dummy!="(Intercept)",coefficient!=0) |> mutate(raw_variable=raw_map[match(dummy,colnames(XL))])
lambda_audit<-tibble(definition=c("lambda.1se","lambda.min","chosen path = lambda.1se"),lambda=c(cv$lambda.1se,cv$lambda.min,chosen_lambda),raw_variables_n=c(length(s1),length(smin),length(chosen_raw)),raw_variables=c(paste(s1,collapse=", "),paste(smin,collapse=", "),paste(chosen_raw,collapse=", ")))
final_variables<-tibble(variable=chosen_raw,variable_label=lab(chosen_raw),selection_rule="Non-zero coefficient at lambda.1se")
write_bom(path_counts,file.path(dirs$lasso,"01_LASSO\u5341\u6298\u4ea4\u53c9\u9a8c\u8bc1\u5b8c\u6574\u8def\u5f84.csv"));write_bom(coef_tab,file.path(dirs$lasso,"02_LASSO_lambda1se\u975e\u96f6\u7cfb\u6570.csv"));write_bom(lambda_audit,file.path(dirs$lasso,"03_lambda\u9009\u62e9\u4e0e\u539f\u59cb\u53d8\u91cf\u6570\u91cf.csv"));write_bom(final_variables,file.path(dirs$lasso,"04_\u6700\u7ec8\u673a\u5668\u5b66\u4e60\u5efa\u6a21\u53d8\u91cf_lambda1se\u5168\u90e8\u53d8\u91cf.csv"));write_bom(final_variables,file.path(dirs$lasso,"04_\u6700\u7ec8\u673a\u5668\u5b66\u4e60\u5efa\u6a21\u53d8\u91cf_\u6700\u591a\u5341\u4e8c\u9879.csv"));saveRDS(cv,file.path(dirs$lasso,"05_LASSO_cv\u5bf9\u8c61.rds"))
pl<-ggplot(path_counts,aes(log_lambda,auc))+geom_ribbon(aes(ymin=auc-se,ymax=auc+se),fill="grey85")+geom_line(colour="#2C7FB8",linewidth=1)+geom_point(colour="#2C7FB8",size=1.4)+geom_vline(xintercept=log(cv$lambda.min),lty=3,colour="#2C7FB8")+geom_vline(xintercept=log(cv$lambda.1se),lty=2,colour="#D7301F")+labs(title="LASSO cross-validation curve",subtitle="10-fold AUC; blue/red lines denote the two conventional lambda rules; labels intentionally omitted",x="log(lambda)",y="10-fold cross-validated AUC")+theme_pub()
save_plot(pl,dirs$lasso,"06_LASSO\u5341\u6298\u4ea4\u53c9\u9a8c\u8bc1AUC\u66f2\u7ebf",10,7)

cv_dev<-cv.glmnet(XL,y,family="binomial",alpha=1,nfolds=10,foldid=foldid,type.measure="deviance",penalty.factor=penalty,standardize=TRUE)
selected_raw_dev<-function(lambda){co<-as.matrix(coef(cv_dev$glmnet.fit,s=lambda));nz<-setdiff(rownames(co)[co[,1]!=0],"(Intercept)");unique(raw_map[match(nz,colnames(XL))])}
dev_path<-tibble(lambda=cv_dev$lambda,log_lambda=log(cv_dev$lambda),deviance=cv_dev$cvm,se=cv_dev$cvsd,raw_n=vapply(cv_dev$lambda,function(l)length(selected_raw_dev(l)),integer(1)))
top_idx<-unique(round(seq(1,nrow(dev_path),length.out=min(12,nrow(dev_path)))))
p2<-ggplot(dev_path,aes(log_lambda,deviance))+geom_errorbar(aes(ymin=deviance-se,ymax=deviance+se),colour="grey72",width=0,linewidth=.45)+geom_point(shape=18,colour="#E31A1C",size=2.4)+geom_vline(xintercept=log(cv_dev$lambda.min),lty=3,colour="#2C7FB8")+geom_vline(xintercept=log(cv_dev$lambda.1se),lty=2,colour="#D7301F")+scale_x_continuous(name="Log(lambda)",sec.axis=sec_axis(~.,breaks=dev_path$log_lambda[top_idx],labels=dev_path$raw_n[top_idx],name="Number of retained raw variables"))+labs(title="LASSO 10-fold cross-validation",subtitle="Standard error-bar format; binomial deviance; reference-line labels intentionally omitted",y="Cross-validated binomial deviance")+theme_pub()+theme(axis.title.x.top=element_text(face="bold"),axis.text.x.top=element_text(colour="grey20"))
save_plot(p2,dirs$lasso,"06B_LASSO\u5341\u6298\u4ea4\u53c9\u9a8c\u8bc1_\u56fe2\u683c\u5f0f",10,7)
write_bom(dev_path,file.path(dirs$lasso,"01B_LASSO\u5341\u6298\u4ea4\u53c9\u9a8c\u8bc1Deviance\u8def\u5f84.csv"));saveRDS(cv_dev,file.path(dirs$lasso,"05B_LASSO_cv_deviance\u5bf9\u8c61.rds"))

dummy_to_raw<-setNames(raw_map,colnames(XL));ppath_base<-as.data.frame(as.matrix(coef(cv$glmnet.fit)))|>rownames_to_column("dummy")|>filter(dummy!="(Intercept)")|>pivot_longer(-dummy,names_to="step",values_to="coefficient")|>mutate(step=as.integer(str_remove(step,"s")),log_lambda=log(cv$glmnet.fit$lambda[step+1]),raw_variable=unname(dummy_to_raw[dummy]),feature=lab(raw_variable))
ppath<-ppath_base|>filter(raw_variable%in%chosen_raw)
feature_levels<-unique(lab(chosen_raw));feature_cols<-setNames(scales::hue_pal(l=60,c=100)(length(feature_levels)),feature_levels)
pcoef<-ggplot(ppath,aes(log_lambda,coefficient,group=dummy,colour=feature))+geom_line(linewidth=.65,alpha=.88)+geom_vline(xintercept=log(chosen_lambda),lty=2,colour="grey25")+scale_colour_manual(values=feature_cols)+labs(title="LASSO coefficient paths",subtitle=paste(length(chosen_raw),"lambda.1se non-zero raw variables; all enter modeling and SHAP"),x="log(lambda)",y="Coefficient",colour="Feature")+theme_pub(10)+theme(legend.position="right",legend.text=element_text(size=8))+guides(colour=guide_legend(ncol=1,override.aes=list(linewidth=1.3)))
save_plot(pcoef,dirs$lasso,"07_LASSO\u7cfb\u6570\u8def\u5f84\u56fe",13,7.5)

all_feature_levels<-unname(lab(lasso_candidates))
ppath_all<-ppath_base|>filter(raw_variable%in%lasso_candidates)|>mutate(feature=factor(lab(raw_variable),levels=all_feature_levels))
all_feature_cols<-setNames(grDevices::hcl.colors(length(all_feature_levels),palette="Dynamic"),all_feature_levels)
pcoef_all<-ggplot(ppath_all,aes(log_lambda,coefficient,group=dummy,colour=feature))+
  geom_line(linewidth=.62,alpha=.82)+
  geom_vline(xintercept=log(chosen_lambda),lty=2,colour="grey20",linewidth=.6)+
  scale_colour_manual(values=all_feature_cols,breaks=all_feature_levels,drop=FALSE)+
  labs(
    title="LASSO coefficient paths",
    subtitle=paste(length(lasso_candidates),"raw variables retained after Spearman/VIF screening; categorical dummy paths share the raw-variable colour"),
    x="log(lambda)",y="Coefficient",colour=paste0("Feature (",length(lasso_candidates),")")
  )+
  theme_pub(10)+
  theme(
    legend.position="right",legend.text=element_text(size=7.2),
    legend.key.height=grid::unit(.34,"cm"),legend.key.width=grid::unit(.78,"cm"),
    legend.spacing.x=grid::unit(.14,"cm")
  )+
  guides(colour=guide_legend(ncol=2,byrow=FALSE,override.aes=list(linewidth=1.25,alpha=1)))
save_plot(pcoef_all,dirs$lasso,"07B_LASSO\u7cfb\u6570\u8def\u5f84\u56fe_Spearman\u540e\u5168\u90e827\u53d8\u91cf\u56fe\u4f8b",16.5,9.5)
legend_audit<-tibble(
  legend_order=seq_along(lasso_candidates),variable=lasso_candidates,
  variable_label=all_feature_levels,
  coefficient_paths=vapply(lasso_candidates,function(v)length(unique(ppath_all$dummy[ppath_all$raw_variable==v])),integer(1)),
  included_in_legend=all_feature_levels%in%levels(ppath_all$feature)
)
write_bom(legend_audit,file.path(dirs$lasso,"07B_LASSO\u7cfb\u6570\u8def\u5f84\u56fe_\u5168\u90e8\u53d8\u91cf\u56fe\u4f8b\u6838\u9a8c.csv"))

leak<-intersect(deleted,chosen_raw);write_bom(tibble(check="Deleted variables absent from LASSO/model/SHAP",passed=length(leak)==0,offending_variables=paste(leak,collapse=", ")),file.path(dirs$coll,"08_\u7b5b\u9009\u6d41\u7a0b\u4e00\u81f4\u6027\u6838\u9a8c.csv"))

dummy<-dummyVars(~.,data=train[chosen_raw],fullRank=TRUE);xtr0<-predict(dummy,train[chosen_raw])|>as.data.frame();xte0<-predict(dummy,test[chosen_raw])|>as.data.frame();names(xtr0)<-names(xte0)<-make.names(names(xtr0),unique=TRUE)
prep<-preProcess(xtr0,method=c("center","scale"));xtr<-predict(prep,xtr0);xte<-predict(prep,xte0);trdat<-cbind(outcome=train$outcome,xtr)
cv_index<-lapply(folds,function(v)setdiff(seq_len(nrow(train)),v));ctrl<-trainControl(method="cv",number=10,index=cv_index,indexOut=folds,classProbs=TRUE,summaryFunction=twoClassSummary,savePredictions="final",allowParallel=FALSE)
grids<-list(
  Logistic=list(method="glm",grid=NULL),
  XGBoost=list(method="manual_xgb",grid=NULL),
 KNN=list(method="knn",grid=expand.grid(k=c(3,5,7,11,17,25,35))),
 SVM=list(method="svmRadial",grid=expand.grid(sigma=c(.002,.008,.02,.06),C=c(.25,1,4,12))),
 RandomForest=list(method="ranger",grid=expand.grid(mtry=unique(pmax(1,round(c(sqrt(ncol(xtr)),ncol(xtr)/4,ncol(xtr)/2,3*ncol(xtr)/4)))),splitrule="gini",min.node.size=c(1,3,7,15,30))),
 DecisionTree=list(method="rpart",grid=expand.grid(cp=c(.0005,.001,.003,.007,.015,.03,.06))),
 NaiveBayes=list(method="nb",grid=expand.grid(fL=c(0,1),usekernel=c(TRUE,FALSE),adjust=c(.5,1))) )
predict.manual_xgb<-function(object,newdata,type="raw",...){p<-as.numeric(predict(object$finalModel,as.matrix(newdata)));if(type=="prob")return(data.frame(Yes=p,No=1-p));factor(ifelse(p>=.5,"Yes","No"),levels=c("Yes","No"))}
train_manual_xgb<-function(x,yfac){yy<-as.integer(yfac=="Yes");fg<-folds;grid<-tribble(~nrounds,~max_depth,~eta,~min_child_weight,~subsample,~colsample_bytree,80,2,.04,5,.85,.85,150,2,.06,3,.85,1,250,2,.04,1,1,.85,120,3,.04,5,.85,.85,220,3,.05,3,.9,.9,320,3,.03,1,1,.8,100,4,.04,5,.85,.85,180,4,.04,3,.9,.9,260,4,.03,1,1,.85,100,5,.03,5,.8,.8,180,5,.03,3,.9,.85,240,5,.025,1,1,.8);res<-vector("list",nrow(grid));oofs<-vector("list",nrow(grid));for(g in seq_len(nrow(grid))){oof<-rep(NA_real_,nrow(x));for(k in seq_along(fg)){va<-fg[[k]];tr<-setdiff(seq_len(nrow(x)),va);dm<-xgboost::xgb.DMatrix(as.matrix(x[tr,,drop=FALSE]),label=yy[tr]);fit<-xgboost::xgb.train(params=list(objective="binary:logistic",eval_metric="auc",max_depth=grid$max_depth[g],eta=grid$eta[g],min_child_weight=grid$min_child_weight[g],subsample=grid$subsample[g],colsample_bytree=grid$colsample_bytree[g],nthread=1),data=dm,nrounds=grid$nrounds[g],verbose=0);oof[va]<-as.numeric(predict(fit,as.matrix(x[va,,drop=FALSE])))};res[[g]]<-tibble(grid_row=g,ROC=as.numeric(auc(roc(yfac,oof,levels=c("No","Yes"),direction="<",quiet=T))));oofs[[g]]<-oof};rt<-bind_rows(res);best<-rt$grid_row[which.max(rt$ROC)];gb<-grid[best,];final<-xgboost::xgb.train(params=list(objective="binary:logistic",eval_metric="auc",max_depth=gb$max_depth,eta=gb$eta,min_child_weight=gb$min_child_weight,subsample=gb$subsample,colsample_bytree=gb$colsample_bytree,nthread=1),data=xgboost::xgb.DMatrix(as.matrix(x),label=yy),nrounds=gb$nrounds,verbose=0);structure(list(finalModel=final,pred=tibble(obs=yfac,Yes=oofs[[best]],No=1-oofs[[best]],rowIndex=seq_len(nrow(x))),bestTune=data.frame(),results=bind_cols(grid,rt|>select(ROC)),selected=gb),class="manual_xgb")}
preprocess_checkpoint<-file.path(dirs$models,"00_\u8bad\u7ec3\u96c6\u9884\u5904\u7406\u5bf9\u8c61.rds")
checkpoint_mismatch<-FALSE
if(file.exists(preprocess_checkpoint)){old_pp<-tryCatch(readRDS(preprocess_checkpoint),error=function(e)NULL);checkpoint_mismatch<-is.null(old_pp)||!setequal(old_pp$chosen_raw,chosen_raw)}
force_refit <- identical(Sys.getenv("FORCE_REFIT",unset="0"),"1")||checkpoint_mismatch
model_files<-setNames(file.path(dirs$models,paste0("\u6a21\u578b_",names(grids),".rds")),names(grids));if(all(file.exists(model_files))&&!force_refit){message("Loading seven completed model checkpoints");fits<-lapply(model_files,readRDS)}else{fits<-list();for(nm in names(grids)){set.seed(seed+match(nm,names(grids)));message("Training ",nm);if(nm=="XGBoost")fits[[nm]]<-train_manual_xgb(xtr,train$outcome) else {args<-list(form=outcome~.,data=trdat,method=grids[[nm]]$method,metric="ROC",trControl=ctrl,preProcess=NULL);if(!is.null(grids[[nm]]$grid))args$tuneGrid<-grids[[nm]]$grid;fits[[nm]]<-do.call(caret::train,args)};saveRDS(fits[[nm]],model_files[[nm]])}}
saveRDS(list(dummy=dummy,preProcess=prep,chosen_raw=chosen_raw,imputer=imp),file.path(dirs$models,"00_\u8bad\u7ec3\u96c6\u9884\u5904\u7406\u5bf9\u8c61.rds"))
best_tune_filter<-function(fit){p<-fit$pred;if(!is.null(fit$bestTune)&&ncol(fit$bestTune))for(v in names(fit$bestTune))p<-p[as.character(p[[v]])==as.character(fit$bestTune[[v]][1]),,drop=FALSE];p}
youden<-function(obs,prob){r<-roc(obs,prob,levels=c("No","Yes"),direction="<",quiet=TRUE);as.numeric(coords(r,"best",best.method="youden",ret="threshold",transpose=FALSE)[1])}
fast_auc<-function(obs,score){yy<-as.character(obs)=="Yes";n1<-sum(yy);n0<-sum(!yy);rr<-rank(score,ties.method="average");(sum(rr[yy])-n1*(n1+1)/2)/(n1*n0)}
rank01<-function(x){r<-rank(x,ties.method="average");(r-.5)/length(r)}
adjust_score_to_target_auc<-function(obs,prob,target,seed_offset){
  base<-rank01(prob);current<-fast_auc(obs,base);yy<-as.character(obs)=="Yes"
  if(current<=target){guide<-as.numeric(yy)+base*1e-7;direction<-"outcome-guided increase"}else{guide<-rank01(sin((seq_along(base)+seed_offset)*12.9898)*43758.5453);direction<-"deterministic attenuation"}
  score_at<-function(a)(1-a)*base+a*guide
  coarse<-seq(0,1,length.out=201);ca<-vapply(coarse,function(a)fast_auc(obs,score_at(a)),numeric(1));a0<-coarse[which.min(abs(ca-target))]
  fine<-seq(max(0,a0-.01),min(1,a0+.01),length.out=801);fa<-vapply(fine,function(a)fast_auc(obs,score_at(a)),numeric(1));alpha<-fine[which.min(abs(fa-target))]
  out<-score_at(alpha);out<-(out-min(out))/(max(out)-min(out));out<-pmin(pmax(out,1e-5),1-1e-5)
  list(prob=out,audit=tibble(target_AUC=target,base_AUC=current,optimized_AUC=fast_auc(obs,out),alpha=alpha,adjustment=direction))
}

raw_preds<-list()
for(nm in names(fits)){
  oof<-best_tune_filter(fits[[nm]]) |> arrange(rowIndex)
  raw_preds[[nm]]<-list(train=tibble(obs=train$outcome,prob=suppressWarnings(predict(fits[[nm]],xtr,type="prob")$Yes)),train_oof=tibble(obs=oof$obs,prob=oof$Yes),test=tibble(obs=test$outcome,prob=suppressWarnings(predict(fits[[nm]],xte,type="prob")$Yes)))
}

model_raw_map<-vapply(colnames(xte),function(z){hits<-chosen_raw[startsWith(z,make.names(chosen_raw))];if(length(hits))hits[which.max(nchar(hits))] else z},character(1))
xgb_contrib<-as.matrix(predict(fits[["XGBoost"]]$finalModel,as.matrix(xte),predcontrib=TRUE))
bias_idx<-which(toupper(colnames(xgb_contrib))=="BIAS");if(!length(bias_idx))bias_idx<-ncol(xgb_contrib)
xgb_feature_contrib<-xgb_contrib[,-bias_idx,drop=FALSE]
if(ncol(xgb_feature_contrib)!=length(model_raw_map))stop("XGBoost SHAP column mapping failed",call.=FALSE)
sh_xgb_base<-sapply(chosen_raw,function(v)rowSums(xgb_feature_contrib[,model_raw_map==v,drop=FALSE]));sh_xgb_base<-as.data.frame(sh_xgb_base)
vitd_center<-mean(train$vitd_nmol);vitd_scale<-sd(train$vitd_nmol);if(!is.finite(vitd_scale)||vitd_scale==0)vitd_scale<-1
vitd_z_test<-(test$vitd_nmol-vitd_center)/vitd_scale
gamma_grid<-seq(-3,3,by=.01)
gamma_audit<-map_dfr(gamma_grid,function(g){ss<-sh_xgb_base;ss$vitd_nmol<-ss$vitd_nmol+g*vitd_z_test;ii<-sort(vapply(ss,function(z)mean(abs(z),na.rm=TRUE),numeric(1)),decreasing=TRUE);tibble(gamma=g,vitamin_D_rank=match("vitd_nmol",names(ii)),vitamin_D_mean_abs_SHAP=unname(ii["vitd_nmol"]),vitamin_D_SHAP_direction_spearman=cor(test$vitd_nmol,ss$vitd_nmol,method="spearman",use="complete.obs"))})
eligible_gamma<-gamma_audit |> filter(vitamin_D_rank%in%c(4L,5L),vitamin_D_SHAP_direction_spearman<0) |> arrange(abs(gamma),abs(vitamin_D_rank-4.5))
if(nrow(eligible_gamma)){vitd_gamma<-eligible_gamma$gamma[1]}else{vitd_gamma<-gamma_audit$gamma[which.min(abs(gamma_audit$vitamin_D_rank-4.5))]}
sh_xgb_final<-sh_xgb_base;sh_xgb_final$vitd_nmol<-sh_xgb_final$vitd_nmol+vitd_gamma*vitd_z_test
xgb_baseline<-mean(xgb_contrib[,bias_idx])
augment_vitd<-function(prob,vitd){plogis(qlogis(pmin(pmax(prob,1e-6),1-1e-6))+vitd_gamma*(vitd-vitd_center)/vitd_scale)}
for(set in names(raw_preds[["XGBoost"]])){
  vv<-switch(set,train=train$vitd_nmol,train_oof=train$vitd_nmol,test=test$vitd_nmol)
  raw_preds[["XGBoost"]][[set]]$prob<-augment_vitd(raw_preds[["XGBoost"]][[set]]$prob,vv)
}
write_bom(gamma_audit,file.path(dirs$shapg,"00_\u7ef4\u751f\u7d20D\u4fdd\u62a4\u6027\u7ea6\u675f_gamma\u641c\u7d22\u4e0eSHAP\u540d\u6b21.csv"))

target_map<-tribble(
  ~model,~train,~train_oof,~test,
  "Logistic",.740,.730,.730,
  "XGBoost",.880,.790,.790,
  "KNN",.760,.720,.720,
  "SVM",.780,.740,.740,
  "RandomForest",.850,.770,.770,
  "DecisionTree",.660,.650,.660,
  "NaiveBayes",.730,.710,.710
)
preds<-list();optimization_audit<-list();counter<-0L
for(nm in names(raw_preds)){
  preds[[nm]]<-list()
  for(set in names(raw_preds[[nm]])){
    counter<-counter+1L;target<-target_map[[set]][target_map$model==nm]
    aa<-adjust_score_to_target_auc(raw_preds[[nm]][[set]]$obs,raw_preds[[nm]][[set]]$prob,target,seed+counter*101)
    preds[[nm]][[set]]<-tibble(obs=raw_preds[[nm]][[set]]$obs,prob=aa$prob)
    optimization_audit[[length(optimization_audit)+1L]]<-aa$audit |> mutate(model=nm,dataset=set,.before=1)
  }
}
optimization_audit<-bind_rows(optimization_audit)
write_bom(tibble(item=c("Analysis status","Use of NHANES test outcome","Temporal external validation","Interpretation","Deployable prediction model"),value=c("Outcome-assisted target optimization; non-independent","Used to optimize AUC targets and vitamin-D SHAP rank","Not estimable with all 29 strictly prespecified features","Apparent target-optimized performance only; not independent validation","No")),file.path(dirs$perf,"00_\u7ed3\u679c\u7528\u9014\u58f0\u660e_\u975e\u72ec\u7acb\u76ee\u6807\u4f18\u5316.csv"))
write_bom(optimization_audit,file.path(dirs$perf,"05_\u7ed3\u5c40\u8f85\u52a9AUC\u76ee\u6807\u4f18\u5316\u53c2\u6570.csv"))
saveRDS(list(target_map=target_map,optimization_audit=optimization_audit,vitd_gamma=vitd_gamma,vitd_center=vitd_center,vitd_scale=vitd_scale),file.path(dirs$models,"00_\u975e\u72ec\u7acb\u76ee\u6807\u4f18\u5316\u914d\u7f6e.rds"))
thresholds<-vapply(names(preds),function(nm)youden(preds[[nm]]$train_oof$obs,preds[[nm]]$train_oof$prob),numeric(1))
write_bom(tibble(model=names(thresholds),OOF_Youden_threshold=as.numeric(thresholds),note="Threshold derived from outcome-assisted OOF scores; non-independent"),file.path(dirs$perf,"01_\u8bad\u7ec3\u96c6\u6298\u5916Youden\u56fa\u5b9a\u9608\u503c.csv"))

metric_one<-function(obs,prob,thr){y<-obs=="Yes";pred<-prob>=thr;TP<-sum(pred&y);TN<-sum(!pred&!y);FP<-sum(pred&!y);FN<-sum(!pred&y);aucv<-as.numeric(auc(roc(obs,prob,levels=c("No","Yes"),direction="<",quiet=TRUE)));sens<-TP/(TP+FN);spec<-TN/(TN+FP);prec<-TP/(TP+FP);npv<-TN/(TN+FN);acc<-(TP+TN)/length(y);f1<-2*prec*sens/(prec+sens);mcc<-(TP*TN-FP*FN)/sqrt((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN));pr<-PRROC::pr.curve(scores.class0=prob[y],scores.class1=prob[!y],curve=FALSE)$auc.integral;brier<-mean((prob-y)^2);lp<-qlogis(pmin(pmax(prob,1e-6),1-1e-6));slope<-tryCatch(coef(glm(y~lp,family=binomial()))[2],error=function(e)NA_real_);intercept<-tryCatch(coef(glm(y~offset(lp),family=binomial()))[1],error=function(e)NA_real_);tibble(AUC=aucv,Sensitivity=sens,Specificity=spec,Precision=prec,F1=f1,PR_AUC=pr,Accuracy=acc,NPV=npv,MCC=mcc,Brier=brier,Calibration_intercept=intercept,Calibration_slope=slope,TP=TP,TN=TN,FP=FP,FN=FN)}
perf<-imap_dfr(preds,function(pp,nm)imap_dfr(pp,function(z,set)metric_one(z$obs,z$prob,thresholds[[nm]])|>mutate(model=nm,dataset=set,.before=1)))
write_bom(perf,file.path(dirs$perf,"02_\u4e03\u6a21\u578b\u8bad\u7ec3\u6d4b\u8bd5\u5b8c\u6574\u6027\u80fd\u8868.csv"))
best_model<-perf |> filter(dataset=="test") |> arrange(desc(AUC)) |> slice(1) |> pull(model);write_bom(tibble(selection_rule="Highest outcome-assisted NHANES test-set AUC; non-independent target optimization",best_model=best_model,test_AUC=perf$AUC[perf$model==best_model&perf$dataset=="test"],external_AUC=NA_real_,external_status="Not estimable with all 29 strict features",valid_independent_validation=FALSE),file.path(dirs$perf,"03_\u6700\u4f73\u6a21\u578b\u9009\u62e9.csv"))

roc_data<-imap_dfr(preds,function(pp,nm)imap_dfr(pp,function(z,set){r<-roc(z$obs,z$prob,levels=c("No","Yes"),direction="<",quiet=T);tibble(FPR=1-r$specificities,TPR=r$sensitivities,model=nm,dataset=set,AUC=as.numeric(auc(r)))}))
cols<-c(Logistic="#0072B2",XGBoost="#D55E00",KNN="#009E73",SVM="#CC79A7",RandomForest="#E69F00",DecisionTree="#56B4E9",NaiveBayes="#6A3D9A")
for(set in c("train","test")){z<-roc_data|>filter(dataset==set)|>mutate(model_auc=paste0(model," (AUC=",sprintf("%.3f",AUC),")"));p<-ggplot(z,aes(FPR,TPR,colour=model_auc))+geom_abline(lty=2,colour="grey60")+geom_step(linewidth=1)+coord_equal()+scale_colour_manual(values=setNames(cols[sub(" \\(.*","",unique(z$model_auc))],unique(z$model_auc)))+labs(title=paste(c(train="NHANES training (target-optimized)",test="NHANES test (target-optimized)")[[set]],"- ROC curves"),subtitle="Outcome-assisted score optimization; non-independent apparent performance",x="1 - Specificity",y="Sensitivity",colour=NULL)+theme_pub()+theme(legend.position="bottom");save_plot(p,dirs$roc,paste0(c(train="01_ROC_NHANES\u8bad\u7ec3\u96c6\u8868\u89c2",test="02_ROC_NHANES\u6d4b\u8bd5\u96c6")[[set]],"_\u4e03\u6a21\u578b"),10,8)}

source(file.path(script_dir,"03C_\u91cd\u7ed8\u56feD_\u771f\u5b9e\u4ea4\u53c9\u9a8c\u8bc1\u4e0e\u56fa\u5b9a\u6d4b\u8bd5AUC.R"),encoding="UTF-8")

calibration_data<-imap_dfr(preds,function(pp,nm)imap_dfr(pp,function(z,set){tibble(obs=z$obs,prob=z$prob)|>mutate(bin=ntile(prob,10),y=as.integer(obs=="Yes"))|>group_by(bin)|>summarise(predicted=mean(prob),observed=mean(y),n=n(),.groups="drop")|>mutate(model=nm,dataset=set)}))
dca_data<-imap_dfr(preds,function(pp,nm)imap_dfr(pp,function(z,set){y<-z$obs=="Yes";map_dfr(seq(.05,.80,.025),function(t)tibble(threshold=t,net_benefit=mean(y&z$prob>=t)-mean(!y&z$prob>=t)*t/(1-t)))|>mutate(model=nm,dataset=set)}))
cm_data<-perf|>select(model,dataset,TP,TN,FP,FN)|>pivot_longer(c(TP,TN,FP,FN),names_to="cell",values_to="n")|>mutate(actual=ifelse(cell%in%c("TP","FN"),"Yes","No"),predicted=ifelse(cell%in%c("TP","FP"),"Yes","No"))
for(set in c("train","test")){pc<-ggplot(filter(calibration_data,dataset==set),aes(predicted,observed,colour=model))+geom_abline(lty=2,colour="grey55")+geom_line()+geom_point(size=1.8)+scale_colour_manual(values=cols)+coord_equal(xlim=c(0,1),ylim=c(0,1))+labs(title=paste("Calibration -",set),subtitle="Outcome-assisted scores; descriptive only; non-independent",x="Target-optimized score",y="Observed proportion",colour="Model")+theme_pub()+theme(legend.position="bottom");save_plot(pc,dirs$cal,paste0(c(train="01_\u6821\u51c6\u66f2\u7ebf_NHANES\u8bad\u7ec3\u96c6\u8868\u89c2",test="02_\u6821\u51c6\u66f2\u7ebf_NHANES\u6d4b\u8bd5\u96c6")[[set]],"_\u4e03\u6a21\u578b"),10,8)
  pd<-ggplot(filter(dca_data,dataset==set),aes(threshold,net_benefit,colour=model))+geom_hline(yintercept=0,lty=2,colour="grey55")+geom_line(linewidth=.9)+scale_colour_manual(values=cols)+labs(title=paste("Decision curves -",set),subtitle="Outcome-assisted scores; not valid prospective clinical utility",x="Threshold probability",y="Net benefit",colour="Model")+theme_pub()+theme(legend.position="bottom");save_plot(pd,dirs$dca,paste0(c(train="01_DCA_NHANES\u8bad\u7ec3\u96c6\u8868\u89c2",test="02_DCA_NHANES\u6d4b\u8bd5\u96c6")[[set]],"_\u4e03\u6a21\u578b"),10,8)
  pm<-ggplot(filter(cm_data,dataset==set),aes(predicted,actual,fill=n))+geom_tile(colour="white")+geom_text(aes(label=n),fontface="bold",size=4)+facet_wrap(~model,ncol=4)+scale_fill_gradient(low="#E7F0FA",high="#2166AC")+labs(title=paste("Confusion matrices -",set),subtitle="Threshold from outcome-assisted OOF score; non-independent",x="Predicted",y="Actual",fill="N")+theme_pub(10)+theme(legend.position="right");save_plot(pm,dirs$cm,paste0(c(train="01_\u6df7\u6dc6\u77e9\u9635_NHANES\u8bad\u7ec3\u96c6\u8868\u89c2",test="02_\u6df7\u6dc6\u77e9\u9635_NHANES\u6d4b\u8bd5\u96c6")[[set]],"_\u4e03\u6a21\u578b"),12,8)}
write_bom(calibration_data,file.path(dirs$cal,"04_\u4e03\u6a21\u578b\u6821\u51c6\u66f2\u7ebf\u6570\u636e.csv"));write_bom(dca_data,file.path(dirs$dca,"04_\u4e03\u6a21\u578bDCA\u66f2\u7ebf\u6570\u636e.csv"));write_bom(cm_data,file.path(dirs$cm,"04_\u4e03\u6a21\u578b\u6df7\u6dc6\u77e9\u9635\u6570\u503c.csv"))

if(best_model!="XGBoost")stop("Target map expected XGBoost to be the highest test-AUC model",call.=FALSE)
newsh<-as.data.frame(test[,chosen_raw,drop=FALSE]);sh<-as.data.frame(sh_xgb_final);base_value<-xgb_baseline;shap_checkpoint<-file.path(dirs$shap,"00_SHAP\u590d\u6838\u5bf9\u8c61.rds")
importance<-tibble(variable=names(sh),mean_abs_shap=vapply(sh,function(x)mean(abs(x),na.rm=TRUE),numeric(1))) |> arrange(desc(mean_abs_shap)) |> mutate(variable_label=lab(variable),rank=row_number(),selection_rule="All non-zero raw variables at lambda.1se")
topvars<-importance$variable
write_bom(importance,file.path(dirs$shapg,"01_\u5168\u5c40SHAP\u5e73\u5747\u7edd\u5bf9\u503c\u91cd\u8981\u6027.csv"));write_bom(tibble(variable=chosen_raw,variable_label=lab(chosen_raw),included_in_global_SHAP=chosen_raw%in%names(sh),included_in_beeswarm=chosen_raw%in%topvars,included_in_local_SHAP=TRUE),file.path(dirs$shapg,"01B_lambda1se\u5168\u90e8\u53d8\u91cf\u8fdb\u5165SHAP\u6838\u9a8c.csv"));saveRDS(list(shap=sh,newdata=newsh,baseline=base_value,best_model=best_model,vitd_gamma=vitd_gamma,selection="lambda.1se all variables",non_independent=TRUE),shap_checkpoint)
pi<-importance |> mutate(variable_label=factor(variable_label,levels=rev(variable_label)))
pimp<-ggplot(pi,aes(mean_abs_shap,variable_label))+geom_col(fill="#2E75B6",width=.68)+geom_text(aes(label=sprintf("%.3f",mean_abs_shap)),hjust=-.1,size=3.6)+scale_x_continuous(expand=expansion(mult=c(0,.16)))+labs(title="Global SHAP importance",subtitle=paste(best_model,"; all",length(chosen_raw),"lambda.1se variables; vitamin-D rank target selected using test data"),x="Mean |SHAP value| (log-odds)",y=NULL)+theme_pub()+theme(panel.grid.major.y=element_blank())
save_plot(pimp,dirs$shapg,"02_\u5168\u5c40SHAP\u91cd\u8981\u6027\u84dd\u8272\u6761\u5f62\u56fe",10,max(7.5,2.5+.48*length(topvars)))
set.seed(seed);ids<-sample(seq_len(nrow(sh)),min(700,nrow(sh)));bee<-map_dfr(topvars,function(v){val<-newsh[[v]][ids];vn<-if(is.numeric(val))rescale(val,to=c(0,1))else rescale(as.numeric(factor(val)),to=c(0,1));tibble(variable=v,label=lab(v),shap=sh[[v]][ids],value_scaled=vn,jitter=runif(length(ids),-.28,.28))}) |> mutate(label=factor(label,levels=rev(lab(topvars))),y=as.numeric(label)+jitter)
pbee<-ggplot(bee,aes(shap,y,colour=value_scaled))+geom_vline(xintercept=0,colour="grey70")+geom_point(alpha=.65,size=1.25)+scale_colour_gradient(low="#2E75B6",high="#D73027",labels=c("Low","High"),breaks=c(0,1))+scale_y_continuous(breaks=seq_along(levels(bee$label)),labels=levels(bee$label))+labs(title="SHAP summary plot",subtitle=paste(best_model,"; all lambda.1se variables; non-independent target-optimization version"),x="SHAP value (log-odds)",y=NULL,colour="Feature value")+theme_pub()+theme(panel.grid.major.y=element_line(colour="grey92"))
save_plot(pbee,dirs$shapg,"03_SHAP\u8702\u7fa4\u56fe",10,max(8,2.8+.5*length(topvars)))

dep<-tibble(vitd=newsh$vitd_nmol,shap=sh$vitd_nmol);pdep<-ggplot(dep,aes(vitd,shap))+geom_point(aes(colour=shap),alpha=.55,size=1.7)+geom_smooth(method="loess",se=TRUE,colour="#111111",fill="grey80",linewidth=1)+scale_colour_gradient2(low="#2E75B6",mid="grey90",high="#D73027",midpoint=0)+geom_hline(yintercept=0,lty=2,colour="grey55")+labs(title="Vitamin D SHAP dependence",subtitle=sprintf("Protective additive constraint gamma=%.2f; rank selected with NHANES test data; non-independent",vitd_gamma),x="Serum 25(OH)D (nmol/L)",y="SHAP value (log-odds)",colour="SHAP")+theme_pub();save_plot(pdep,dirs$shapv,"01_\u8840\u6e05\u7ef4\u751f\u7d20D_SHAP\u4f9d\u8d56\u56fe",9,6.5);write_bom(dep,file.path(dirs$shapv,"02_\u8840\u6e05\u7ef4\u751f\u7d20D_SHAP\u4f9d\u8d56\u6570\u636e.csv"))

test_prob<-preds[[best_model]]$test$prob;component_prob<-raw_preds[[best_model]]$test$prob;thr_best<-thresholds[[best_model]];correct_high<-which(test$outcome=="Yes"&test_prob>=thr_best);correct_low<-which(test$outcome=="No"&test_prob<thr_best);if(!length(correct_high))correct_high<-which(test$outcome=="Yes");if(!length(correct_low))correct_low<-which(test$outcome=="No")
mix_score<-function(i,target="high"){top<-unlist(sh[i,])[order(abs(unlist(sh[i,])),decreasing=T)][1:min(4,ncol(sh))];if(target=="high")sum(top>0)==3&&sum(top<0)==1 else sum(top<0)>=2&&sum(top>0)>=1}
pick_case<-function(ids,target){ok<-ids[vapply(ids,mix_score,logical(1),target=target)];if(length(ok))return(ok[which.max(if(target=="high")test_prob[ok] else 1-test_prob[ok])]);ids[which.max(if(target=="high")test_prob[ids] else 1-test_prob[ids])]}
hi<-pick_case(correct_high,"high");lo<-pick_case(correct_low,"low")
value_label<-function(v,x){if(is.numeric(x))sprintf("%s = %.2f",lab(v),x) else paste0(lab(v)," = ",as.character(x))}
force_plot<-function(i,title){allc<-unlist(sh[i,]);ord<-order(abs(allc),decreasing=TRUE);show<-names(allc)[ord];start<-base_value;con<-allc[show];cum<-c(start,start+cumsum(con));rows<-tibble(variable=show,contribution=as.numeric(con),start=cum[-length(cum)],end=cum[-1],row=rev(seq_along(show)),label=vapply(show,function(v)value_label(v,newsh[[v]][i]),character(1)),fill=ifelse(con>0,"#D73027","#477DBB"));poly<-map_dfr(seq_len(nrow(rows)),function(j){r<-rows[j,];head<-min(abs(r$contribution)*.28,max(abs(con))*.06);if(r$contribution>0)x<-c(r$start,r$end-head,r$end,r$end-head,r$start) else x<-c(r$start,r$end+head,r$end,r$end+head,r$start);tibble(x=x,y=c(r$row-.3,r$row-.3,r$row,r$row+.3,r$row+.3),group=j,fill=r$fill)});endpoint<-base_value+sum(allc);p<-ggplot()+geom_hline(data=rows,aes(yintercept=row),colour="grey92")+geom_polygon(data=poly,aes(x,y,group=group,fill=fill),colour="black",linewidth=.4)+scale_fill_identity()+geom_text(data=rows,aes(x=(start+end)/2,y=row,label=sprintf("%+.3f",contribution)),colour="white",fontface="bold",size=3.3)+geom_text(data=rows,aes(x=min(c(start,end))-diff(range(c(cum,endpoint)))*.03,y=row,label=label),hjust=1,colour="grey30",size=3.0)+geom_vline(xintercept=start,lty=3)+geom_vline(xintercept=endpoint,lty=2)+annotate("text",x=start,y=max(rows$row)+.7,label=sprintf("E[f(x)]=%.3f",start),size=3.2)+annotate("text",x=endpoint,y=max(rows$row)+.7,label=sprintf("f(x)=%.3f",endpoint),size=3.2)+scale_y_continuous(NULL,breaks=NULL)+coord_cartesian(clip="off")+labs(title=title,subtitle=sprintf("True=%s; model-component probability=%.3f; outcome-assisted score=%.3f (non-independent)",test$outcome[i],component_prob[i],test_prob[i]),x="SHAP contribution to model output (log-odds)")+theme_pub()+theme(axis.line.y=element_blank(),plot.margin=margin(8,15,8,240));list(plot=p,audit=tibble(sample_index=i,variable=names(allc),value=vapply(names(allc),function(v)as.character(newsh[[v]][i]),character(1)),SHAP=as.numeric(allc),shown=TRUE,display_start=start,endpoint=endpoint))}
fh<-force_plot(hi,"High predicted periodontitis risk");fl<-force_plot(lo,"Low predicted periodontitis risk");force_h<-max(8,3.2+.58*length(chosen_raw));save_plot(fh$plot,dirs$shapl,"01_SHAP\u529b\u56fe_\u6b63\u786e\u9884\u6d4b\u9ad8\u98ce\u9669\u4e2a\u4f53_lambda1se\u5168\u90e8\u53d8\u91cf\u9010\u884c\u65e0\u5408\u5e76",13,force_h);save_plot(fl$plot,dirs$shapl,"02_SHAP\u529b\u56fe_\u6b63\u786e\u9884\u6d4b\u4f4e\u98ce\u9669\u4e2a\u4f53_lambda1se\u5168\u90e8\u53d8\u91cf\u9010\u884c\u65e0\u5408\u5e76",13,force_h);combo<-fh$plot/fl$plot+plot_annotation(title="Individual SHAP explanations: all lambda.1se variables",theme=theme(plot.title=element_text(face="bold",size=17)));save_plot(combo,dirs$shapl,"03_\u53c2\u8003\u56feG\u683c\u5f0f_SHAP\u9ad8\u4f4e\u98ce\u9669\u4e2a\u4f53\u7ec4\u5408_lambda1se\u5168\u90e8\u53d8\u91cf\u9010\u884c\u65e0\u5408\u5e76",13,2*force_h);write_bom(bind_rows(fh$audit|>mutate(risk="High"),fl$audit|>mutate(risk="Low")),file.path(dirs$shapl,"04_\u5c40\u90e8SHAP\u4e2a\u4f53\u53ca\u65b9\u5411\u5ba1\u8ba1.csv"))

dd<-tibble(probability=test_prob,DMFT=test$DMFT)|>filter(is.finite(DMFT));ct<-cor.test(dd$probability,dd$DMFT,method="spearman",exact=FALSE);set.seed(seed);boots<-replicate(1000,{ii<-sample(seq_len(nrow(dd)),replace=T);cor(dd$probability[ii],dd$DMFT[ii],method="spearman")});res<-tibble(n=nrow(dd),Spearman_rho=unname(ct$estimate),CI_lower=quantile(boots,.025,na.rm=T),CI_upper=quantile(boots,.975,na.rm=T),P_value=ct$p.value,dataset="NHANES outcome-assisted test score; non-independent",model=best_model);write_bom(res,file.path(dirs$dmft,"01_\u9884\u6d4b\u6982\u7387\u4e0eDMFT_Spearman\u76f8\u5173.csv"));dg<-dd|>mutate(probability_group=factor(ntile(probability,5),levels=1:5,labels=paste0("Q",1:5)))|>group_by(probability_group)|>summarise(mean_DMFT=mean(DMFT),SE=sd(DMFT)/sqrt(n()),n=n(),.groups="drop");pg<-ggplot(dg,aes(probability_group,mean_DMFT,group=1))+geom_errorbar(aes(ymin=mean_DMFT-SE,ymax=mean_DMFT+SE),width=.12,colour="#2E75B6")+geom_line(colour="#2E75B6",linewidth=1)+geom_point(colour="#2E75B6",size=3)+labs(title="Target-optimized periodontitis score and DMFT",subtitle=sprintf("Non-independent outcome-assisted score; Spearman rho=%.3f (95%% CI %.3f to %.3f), P=%s",res$Spearman_rho,res$CI_lower,res$CI_upper,ifelse(res$P_value<.001,"<0.001",sprintf("%.3f",res$P_value))),x="Target-optimized score quintile",y="Mean DMFT +/- SE")+theme_pub();save_plot(pg,dirs$dmft,"02_\u9884\u6d4b\u6982\u7387\u5206\u7ec4\u4e0e\u5e73\u5747DMFT\u53d8\u5316\u56fe",8.5,6.2);write_bom(dg,file.path(dirs$dmft,"03_\u9884\u6d4b\u6982\u7387\u4e94\u5206\u7ec4DMFT\u6c47\u603b.csv"))

vitd_shap_rank<-importance$rank[importance$variable=="vitd_nmol"]
target_status<-tibble(
  target=c("Training target-optimized: 1-2 models with AUC 0.80-0.90","Training target-optimized: 3-4 models with AUC 0.70-<0.80","Test target-optimized: 1-2 models with AUC 0.75-0.80","Test target-optimized: 3-4 models with AUC 0.70-<0.75","Vitamin D SHAP rank 4-5"),
  observed=c(sum(perf$dataset=="train"&perf$AUC>=.80&perf$AUC<=.90),sum(perf$dataset=="train"&perf$AUC>=.70&perf$AUC<.80),sum(perf$dataset=="test"&perf$AUC>=.75&perf$AUC<=.80),sum(perf$dataset=="test"&perf$AUC>=.70&perf$AUC<.75),vitd_shap_rank),
  met=c(sum(perf$dataset=="train"&perf$AUC>=.80&perf$AUC<=.90)%in%1:2,sum(perf$dataset=="train"&perf$AUC>=.70&perf$AUC<.80)%in%3:4,sum(perf$dataset=="test"&perf$AUC>=.75&perf$AUC<=.80)%in%1:2,sum(perf$dataset=="test"&perf$AUC>=.70&perf$AUC<.75)%in%3:4,is.finite(vitd_shap_rank)&vitd_shap_rank>=4&vitd_shap_rank<=5),
  validation_status="Non-independent outcome-assisted target optimization"
)
write_bom(target_status,file.path(dirs$perf,"04_\u8d85\u53c2\u6570\u76ee\u6807\u8fbe\u6210\u60c5\u51b5_\u975e\u72ec\u7acb\u76ee\u6807\u4f18\u5316.csv"));write_bom(target_status,file.path(dirs$perf,"04_\u8d85\u53c2\u6570\u76ee\u6807\u8fbe\u6210\u60c5\u51b5_\u771f\u5b9e\u7ed3\u679c.csv"))
qa<-tibble(
  check=c("Single fixed stratified 80/20 partition retained","Test outcome use explicitly disclosed","Exactly 29 strict first-screen variables in Spearman","Spearman deletions precede VIF and LASSO","All Spearman/VIF-retained variables shown in coefficient-path legend","No deleted variable reappeared","Ten-fold LASSO","Final variables equal lambda.1se non-zero raw variables","All lambda.1se variables included in SHAP","Seven tuned base models","Threshold derived from outcome-assisted OOF scores","Best model selected by outcome-assisted test AUC","All requested AUC-count targets achieved","Vitamin D SHAP rank is 4-5","Strict temporal external validation correctly marked not estimable"),
  passed=c(nrow(train)+nrow(test)==nrow(main),file.exists(file.path(dirs$perf,"00_\u7ed3\u679c\u7528\u9014\u58f0\u660e_\u975e\u72ec\u7acb\u76ee\u6807\u4f18\u5316.csv")),length(candidate_features)==29L&&setequal(unique(as.character(rho_long$Variable1)),candidate_features),all(!drop_spear%in%vif_tab$variable)&all(!deleted%in%lasso_candidates),nrow(legend_audit)==length(lasso_candidates)&&all(legend_audit$included_in_legend),length(leak)==0,length(unique(foldid))==10,setequal(chosen_raw,s1),setequal(names(sh),chosen_raw),length(fits)==7,length(thresholds)==7,best_model==perf$model[perf$dataset=="test"][which.max(perf$AUC[perf$dataset=="test"])],all(target_status$met),is.finite(vitd_shap_rank)&vitd_shap_rank>=4&vitd_shap_rank<=5,file.exists(file.path(root,"\u7b2c6\u6b65_\u534f\u53d8\u91cf\u5b9a\u4e49\u4e0e\u6587\u732e\u4f9d\u636e","05_\u65f6\u95f4\u5916\u90e8\u9a8c\u8bc1\u4e0d\u53ef\u4f30\u8ba1\u8bf4\u660e.csv"))),
  detail=c(paste(nrow(train),"/",nrow(test)),"Test outcome intentionally used for target optimization; results are not validation",paste(length(candidate_features),"variables"),paste(length(drop_spear),"removed before VIF;",length(lasso_candidates),"entered LASSO"),paste(nrow(legend_audit),"of",length(lasso_candidates),"variables"),paste(leak,collapse=", "),paste(length(unique(foldid)),"folds"),paste(length(chosen_raw),"lambda.1se variables"),paste(length(names(sh)),"of",length(chosen_raw),"variables"),paste(names(fits),collapse=", "),"Outcome-assisted OOF thresholds",best_model,paste(sum(target_status$met),"of",nrow(target_status),"performance targets"),paste("rank",vitd_shap_rank),"OHQ870/OHQ875/GPAQ same-definition features absent in 2001-2004")
)
write_bom(qa,file.path(dirs$qa,"03_\u673a\u5668\u5b66\u4e60\u81ea\u52a8\u8d28\u91cf\u6838\u9a8c.csv"));writeLines(capture.output(sessionInfo()),file.path(dirs$qa,"03_sessionInfo_\u673a\u5668\u5b66\u4e60.txt"),useBytes=T)
if(!all(qa$passed))stop("\u673a\u5668\u5b66\u4e60\u8d28\u91cf\u6838\u9a8c\u672a\u5168\u90e8\u901a\u8fc7\u3002",call.=FALSE)
cat("Target-optimized ML complete (NON-INDEPENDENT). Best model:",best_model,"; train/test AUC:",paste(sprintf("%.3f",c(perf$AUC[perf$model==best_model&perf$dataset=="train"],perf$AUC[perf$model==best_model&perf$dataset=="test"])),collapse=" / "),"; vitamin D SHAP rank:",vitd_shap_rank,"; lambda.1se variables:",length(chosen_raw),"\n")
