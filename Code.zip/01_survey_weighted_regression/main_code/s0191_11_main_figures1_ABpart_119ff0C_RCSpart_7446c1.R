options(stringsAsFactors = FALSE)

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(purrr)
  library(readr)
  library(tibble)
})

forest_source_file <- paste0(
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u9879\u76ee\u811a\u672c/",
  "20260802-\u7259\u5468\u708e\u4e2d\u91cdvs\u65e0\u8f7b_VitD\u4e09\u5206\u7c7b_\u4e25\u683c\u53d8\u91cf_DLC/",
  "\u7b2c19\u6b65_\u8d28\u91cf\u6838\u9a8c\u4e0e\u53ef\u590d\u73b0\u4ee3\u7801/",
  "02_\u4e24\u5957DLC\u65b0VitD\u4e09\u5206\u7c7b\u4e9a\u7ec4\u4e0e\u4ea4\u4e92\u4f5c\u7528.R"
)

source_expressions <- parse(forest_source_file, keep.source = FALSE)
render_environment <- new.env(parent = globalenv())
for (expression in source_expressions) {
  is_main_loop_start <-
    is.call(expression) &&
    identical(expression[[1]], as.name("<-")) &&
    identical(as.character(expression[[2]]), "all_summaries")
  if (is_main_loop_start) break
  eval(expression, envir = render_environment)
}

subgroup_csv <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/",
  "20260802-\u7259\u5468\u708e\u4e2d\u91cdvs\u65e0\u8f7b_VitD\u4e09\u5206\u7c7b_\u4e25\u683c\u53d8\u91cf_DLC/",
  "\u7b2c10\u6b65_\u4e9a\u7ec4\u4e0e\u4ea4\u4e92\u4f5c\u7528/",
  "01_NHANES2009-2014_\u7ef4\u751f\u7d20D\u4e09\u5206\u7c7b_\u5168\u90e820\u9879\u4e9a\u7ec4\u4e0e\u4ea4\u4e92.csv"
)
rcs_summary_csv <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/",
  "20260802-\u7259\u5468\u708e\u4e2d\u91cdvs\u65e0\u8f7b_VitD\u4e09\u5206\u7c7b_\u4e25\u683c\u53d8\u91cf_\u6700\u7ec8/",
  "\u7b2c10\u6b65\u9644\u52a0_\u9650\u5236\u6027\u7acb\u65b9\u6837\u6761/",
  "01_NHANES2009-2014_Model1\u81f33_RCS\u603b\u4f53\u4e0e\u975e\u7ebf\u6027P\u503c.csv"
)
rcs_curve_csv <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/",
  "20260802-\u7259\u5468\u708e\u4e2d\u91cdvs\u65e0\u8f7b_VitD\u4e09\u5206\u7c7b_\u4e25\u683c\u53d8\u91cf_\u6700\u7ec8/",
  "\u7b2c10\u6b65\u9644\u52a0_\u9650\u5236\u6027\u7acb\u65b9\u6837\u6761/",
  "02_NHANES2009-2014_Model1\u81f33_RCS\u66f2\u7ebf\u6570\u636e.csv"
)

output_dir <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/\u5f53\u524d\u6295\u7a3f\u9879\u76ee/\u4f20\u7edf\u5206\u6790/\u683c\u5f0f\u5ba1\u8ba1/",
  "\u5b57\u4f53\u653e\u5927_\u7559\u767d\u538b\u7f29_RCS\u53bb\u6807\u9898_QA/\u5019\u9009\u7ec8\u7a3f"
)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

subgroup_results <- read_csv(subgroup_csv, show_col_types = FALSE)
forest_targets <- tribble(
  ~contrast, ~stem,
  "Insufficient (50-<75 nmol/L) vs Sufficient (>=75 nmol/L)",
  "A.Model3_50-\u5c0f\u4e8e75nmol_Lvs\u5927\u4e8e\u7b49\u4e8e75nmol_L_\u4e03\u680f\u4e9a\u7ec4\u68ee\u6797\u56fe",
  "Deficient (<50 nmol/L) vs Sufficient (>=75 nmol/L)",
  "B.Model3_\u5c0f\u4e8e50nmol_Lvs\u5927\u4e8e\u7b49\u4e8e75nmol_L_\u4e03\u680f\u4e9a\u7ec4\u68ee\u6797\u56fe"
)

pwalk(forest_targets, function(contrast, stem) {
  plot <- render_environment$seven_column_plot(
    subgroup_results,
    "Model 3",
    contrast,
    subtitle = NULL
  )
  render_environment$save_plot(
    plot,
    output_dir,
    stem,
    width = 15,
    height = 18
  )
})

rcs_summary <- read_csv(rcs_summary_csv, show_col_types = FALSE) |>
  filter(model == "Model 3")
rcs_curve <- read_csv(rcs_curve_csv, show_col_types = FALSE) |>
  filter(model == "Model 3")
stopifnot(nrow(rcs_summary) == 1L, nrow(rcs_curve) > 100L)

p_nonlinearity <- rcs_summary$P_nonlinear[[1]]
reference_median <- rcs_summary$reference_median[[1]]
p_text <- ifelse(
  p_nonlinearity < 0.001,
  "<0.001",
  sprintf("%.3f", p_nonlinearity)
)

rcs_plot <- ggplot(rcs_curve, aes(vitd_nmol, OR)) +
  geom_ribbon(
    aes(ymin = lower, ymax = upper),
    fill = "#B7D8D4",
    alpha = 0.55
  ) +
  geom_line(colour = "#155D59", linewidth = 1.1) +
  geom_hline(yintercept = 1, linetype = 2, colour = "grey45") +
  geom_vline(
    xintercept = reference_median,
    linetype = 3,
    colour = "#E67E22"
  ) +
  annotate(
    "text",
    x = Inf,
    y = Inf,
    label = paste0("P for nonlinearity = ", p_text),
    hjust = 1.06,
    vjust = 1.30,
    size = 5.0
  ) +
  labs(
    title = NULL,
    subtitle = NULL,
    x = "Serum 25(OH)D (nmol/L)",
    y = "Odds ratio"
  ) +
  theme_classic(base_size = 14) +
  theme(
    axis.title = element_text(size = 15),
    axis.text = element_text(size = 12.5),
    plot.margin = margin(8, 10, 8, 8)
  )

ggsave(
  file.path(output_dir, "C.Model3_RCS.png"),
  rcs_plot,
  width = 9.5,
  height = 6.5,
  dpi = 320,
  bg = "white",
  limitsize = FALSE
)
ggsave(
  file.path(output_dir, "C.Model3_RCS.pdf"),
  rcs_plot,
  width = 9.5,
  height = 6.5,
  device = cairo_pdf,
  bg = "white",
  limitsize = FALSE
)

message("Rendered revised Figure 1 panels A-C to: ", output_dir)
