variant_id <- "\u4e2d\u91cd\u5ea6\u7259\u5468\u708evs\u65e0/\u8f7b\u5ea6\u7259\u5468\u708e + \u7ef4\u751f\u7d20D\u4e09\u5206\u7c7b\uff08\u4e25\u683c\u53d8\u91cf\u6700\u7ec8\u7248\uff09"
outcome_mode <- "moderate_severe"
outcome_label <- "Moderate/severe periodontitis"
outcome_definition_cn <- "\u4e2d\u5ea6\u6216\u91cd\u5ea6\u7259\u5468\u708e=Yes\uff1b\u65e0\u6216\u8f7b\u5ea6\u7259\u5468\u708e=No"
vitd_scheme <- "three"
vitd_scheme_cn <- "\u4e09\u5206\u7c7b"
vitd_reference <- ">=50 nmol/L"
vitd_levels <- c(">=50 nmol/L", "30-<50 nmol/L", "<30 nmol/L")
vitd_definition_cn <- "<30、30-<50、>=50 nmol/L"
analysis_seed <- 20260802L
analysis_version <- "strict_covariates_final"
validation_status <- "NHANES 2009-2014 internal 80/20 validation; temporal external validation is not estimable when every prespecified feature is required"
source_root <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/01_NHANES/\u6d3e\u751f\u8f93\u5165/2009-2014\u4e3b\u5206\u6790_2001-2004\u5916\u90e8\u9a8c\u8bc1"
