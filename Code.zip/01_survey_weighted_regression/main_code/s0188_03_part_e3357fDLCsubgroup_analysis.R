options(stringsAsFactors = FALSE, survey.lonely.psu = "adjust")

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(tibble)
  library(survey)
})

input_rds <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/",
  "20260802-\u7259\u5468\u708e\u4e2d\u91cdvs\u65e0\u8f7b_VitD\u4e09\u5206\u7c7b_\u4e25\u683c\u53d8\u91cf_\u6700\u7ec8/",
  "\u7b2c3\u6b65_\u6837\u672c\u6392\u9664\u4e0e\u8d28\u91cf\u63a7\u5236/",
  "01_NHANES2009-2014_Model3\u4e25\u683c\u5b8c\u6574\u75c5\u4f8b.rds"
)

variants <- list(
  moderate_severe = list(
    target = "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260802-\u7259\u5468\u708e\u4e2d\u91cdvs\u65e0\u8f7b_VitD\u4e09\u5206\u7c7b_\u4e25\u683c\u53d8\u91cf_DLC",
    positive_severity = c("Moderate", "Severe")
  ),
  any_periodontitis = list(
    target = "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260802-\u7259\u5468\u708e\u8f7b\u4e2d\u91cdvs\u65e0_VitD\u4e09\u5206\u7c7b_\u4e25\u683c\u53d8\u91cf_DLC",
    positive_severity = c("Mild", "Moderate", "Severe")
  )
)

oral_covariates <- c(
  "floss_days", "mouthwash_days", "missing_teeth_count", "implant_count"
)
clinical_behavioral <- c(
  "smoking", "alcohol", "physical_activity", "diabetes", "hypertension",
  "cvd", "ckd", "liver", "thyroid"
)
demographic <- c(
  "sex", "bmi", "age", "education", "marital", "pir_cat", "race"
)
nutrition <- c(
  "energy_kcal", "sugar_g", "cholesterol_mg", "fat_g", "fiber_g",
  "protein_g", "calcium_mg", "phosphorus_mg"
)
model3_covariates <- c(
  oral_covariates,
  clinical_behavioral,
  demographic,
  nutrition
)

subgroups <- c(
  "floss_group", "mouthwash_group", "missing_teeth_group", "implant_group",
  clinical_behavioral,
  "sex", "bmi_cat", "age_group", "education", "marital", "pir_cat", "race"
)

counterpart <- c(
  floss_group = "floss_days",
  mouthwash_group = "mouthwash_days",
  missing_teeth_group = "missing_teeth_count",
  implant_group = "implant_count",
  bmi_cat = "bmi",
  age_group = "age"
)

vitd_reference <- "Sufficient (>=75 nmol/L)"
vitd_levels <- c(
  vitd_reference,
  "Insufficient (50-<75 nmol/L)",
  "Deficient (<50 nmol/L)"
)
exposure_levels <- vitd_levels[-1]
contrast_lookup <- setNames(
  paste(exposure_levels, "vs", vitd_reference),
  exposure_levels
)

make_design <- function(data) {
  svydesign(
    id = ~psu_pool,
    strata = ~strata_pool,
    weights = ~analysis_weight,
    nest = TRUE,
    data = data
  )
}

derive_analysis_data <- function(source, positive_severity) {
  source |>
    mutate(
      vitd_cat = cut(
        vitd_nmol,
        c(-Inf, 50, 75, Inf),
        right = FALSE,
        labels = c(
          "Deficient (<50 nmol/L)",
          "Insufficient (50-<75 nmol/L)",
          "Sufficient (>=75 nmol/L)"
        )
      ),
      vitd_cat = factor(as.character(vitd_cat), levels = vitd_levels),
      outcome_bin = as.integer(periodontitis_severity %in% positive_severity),
      age_group = factor(
        ifelse(
          age < 65,
          "60-64",
          ifelse(age < 70, "65-69", ifelse(age < 75, "70-74", ">=75"))
        ),
        levels = c("60-64", "65-69", "70-74", ">=75")
      ),
      bmi_cat = factor(
        ifelse(bmi < 25, "<25", ifelse(bmi < 30, "25-<30", ">=30")),
        levels = c("<25", "25-<30", ">=30")
      ),
      floss_group = factor(
        ifelse(floss_days == 0, "0 days", "1-7 days"),
        levels = c("0 days", "1-7 days")
      ),
      mouthwash_group = factor(
        ifelse(mouthwash_days == 0, "0 days", "1-7 days"),
        levels = c("0 days", "1-7 days")
      ),
      missing_teeth_group = factor(
        ifelse(
          missing_teeth_count == 0,
          "0",
          ifelse(missing_teeth_count <= 5, "1-5", ">=6")
        ),
        levels = c("0", "1-5", ">=6")
      ),
      implant_group = factor(
        ifelse(implant_count == 0, "0", ">=1"),
        levels = c("0", ">=1")
      )
    )
}

minimum_cell <- function(data, subgroup_variable, subgroup_level, exposure_level) {
  keep <- as.character(data[[subgroup_variable]]) == subgroup_level &
    as.character(data$vitd_cat) %in% c(exposure_level, vitd_reference)
  cells <- table(
    factor(
      as.character(data$vitd_cat[keep]),
      levels = c(exposure_level, vitd_reference)
    ),
    factor(data$outcome_bin[keep], levels = c(0, 1))
  )
  min(cells)
}

fallback_interaction_p <- function(fit, subgroup_variable) {
  coefficient_names <- names(coef(fit))
  indices <- which(
    grepl(":", coefficient_names, fixed = TRUE) &
      grepl("vitd_cat", coefficient_names, fixed = TRUE) &
      grepl(subgroup_variable, coefficient_names, fixed = TRUE)
  )
  if (!length(indices)) return(NA_real_)
  beta <- coef(fit)[indices]
  covariance <- vcov(fit)[indices, indices, drop = FALSE]
  keep <- is.finite(beta) & is.finite(diag(covariance))
  beta <- beta[keep]
  covariance <- covariance[keep, keep, drop = FALSE]
  if (!length(beta)) return(NA_real_)
  statistic <- tryCatch(
    drop(t(beta) %*% MASS::ginv(covariance) %*% beta),
    error = function(e) NA_real_
  )
  if (
    is.finite(statistic)
  ) {
    pchisq(statistic, df = length(beta), lower.tail = FALSE)
  } else {
    NA_real_
  }
}

refit_model3 <- function(data) {
  design <- make_design(data)
  output <- vector("list", length(subgroups) * 8L)
  cursor <- 0L

  for (subgroup_variable in subgroups) {
    removed <- if (subgroup_variable %in% names(counterpart)) {
      counterpart[[subgroup_variable]]
    } else {
      subgroup_variable
    }
    covariates <- setdiff(model3_covariates, removed)

    interaction_formula <- as.formula(
      paste(
        "outcome_bin ~",
        paste(
          c(paste0("vitd_cat * ", subgroup_variable), covariates),
          collapse = " + "
        )
      )
    )
    interaction_fit <- tryCatch(
      svyglm(interaction_formula, design = design, family = quasibinomial()),
      error = function(e) NULL
    )
    interaction_p <- if (is.null(interaction_fit)) {
      NA_real_
    } else {
      direct_p <- tryCatch(
        suppressWarnings(
          as.numeric(
            regTermTest(
              interaction_fit,
              as.formula(paste0("~vitd_cat:", subgroup_variable))
            )$p
          )
        ),
        error = function(e) NA_real_
      )
      if (length(direct_p) && is.finite(direct_p)) {
        direct_p
      } else {
        fallback_interaction_p(interaction_fit, subgroup_variable)
      }
    }

    subgroup_levels <- levels(droplevels(data[[subgroup_variable]]))
    for (subgroup_level in subgroup_levels) {
      level_index <- as.character(data[[subgroup_variable]]) == subgroup_level
      level_design <- design[level_index, ]
      level_formula <- reformulate(
        c("vitd_cat", covariates),
        response = "outcome_bin"
      )
      level_fit <- tryCatch(
        svyglm(level_formula, design = level_design, family = quasibinomial()),
        error = function(e) NULL
      )

      for (exposure_level in exposure_levels) {
        cursor <- cursor + 1L
        term <- paste0("vitd_cat", exposure_level)
        if (is.null(level_fit) || !term %in% names(coef(level_fit))) {
          odds_ratio <- lower <- upper <- p_value <- NA_real_
        } else {
          beta <- coef(level_fit)[[term]]
          standard_error <- sqrt(vcov(level_fit)[term, term])
          odds_ratio <- exp(beta)
          lower <- exp(beta - 1.96 * standard_error)
          upper <- exp(beta + 1.96 * standard_error)
          p_value <- 2 * pnorm(-abs(beta / standard_error))
        }
        log_or_se <- if (
          is.finite(lower) && is.finite(upper) && lower > 0 && upper > 0
        ) {
          (log(upper) - log(lower)) / (2 * 1.96)
        } else {
          NA_real_
        }
        min_cell <- minimum_cell(
          data,
          subgroup_variable,
          subgroup_level,
          exposure_level
        )
        estimability <- if (
          min_cell < 5 ||
            !is.finite(odds_ratio) ||
            !is.finite(lower) ||
            !is.finite(upper) ||
            odds_ratio <= 0 ||
            lower <= 0 ||
            log_or_se > 2 ||
            odds_ratio > 100 ||
            odds_ratio < 0.01 ||
            upper > 1000 ||
            lower < 0.001
        ) {
          "Not estimable: sparse/unstable subgroup fit"
        } else {
          "Estimable"
        }

        output[[cursor]] <- tibble(
          model = "Model 3",
          variable = subgroup_variable,
          subgroup = subgroup_level,
          contrast = unname(contrast_lookup[[exposure_level]]),
          independent_N = sum(level_index),
          independent_OR = odds_ratio,
          independent_CI_lower = lower,
          independent_CI_upper = upper,
          independent_P = p_value,
          independent_P_interaction = interaction_p,
          independent_min_2x2_cell_n = min_cell,
          independent_estimability = estimability,
          independent_present = TRUE
        )
      }
    }
  }
  bind_rows(output[seq_len(cursor)])
}

scaled_numeric_difference <- function(left, right) {
  if (is.na(left) && is.na(right)) return(0)
  if (is.na(left) || is.na(right)) return(Inf)
  abs(left - right) / max(1, abs(left), abs(right))
}

source_data <- readRDS(input_rds)
summaries <- list()

for (variant_name in names(variants)) {
  spec <- variants[[variant_name]]
  data <- derive_analysis_data(source_data, spec$positive_severity)
  independent <- refit_model3(data)

  reported_path <- file.path(
    spec$target,
    "\u7b2c10\u6b65_\u4e9a\u7ec4\u4e0e\u4ea4\u4e92\u4f5c\u7528",
    "01_NHANES2009-2014_\u7ef4\u751f\u7d20D\u4e09\u5206\u7c7b_\u5168\u90e820\u9879\u4e9a\u7ec4\u4e0e\u4ea4\u4e92.csv"
  )
  reported <- suppressMessages(read_csv(reported_path, show_col_types = FALSE)) |>
    filter(model == "Model 3") |>
    transmute(
      model,
      variable,
      subgroup,
      contrast,
      reported_N = N,
      reported_OR = OR,
      reported_CI_lower = CI_lower,
      reported_CI_upper = CI_upper,
      reported_P = P,
      reported_P_interaction = P_interaction,
      reported_min_2x2_cell_n = min_2x2_cell_n,
      reported_estimability = estimability,
      reported_present = TRUE
    )

  comparison <- full_join(
    reported,
    independent,
    by = c("model", "variable", "subgroup", "contrast")
  ) |>
    rowwise() |>
    mutate(
      max_scaled_difference = max(
        scaled_numeric_difference(reported_OR, independent_OR),
        scaled_numeric_difference(reported_CI_lower, independent_CI_lower),
        scaled_numeric_difference(reported_CI_upper, independent_CI_upper),
        scaled_numeric_difference(reported_P, independent_P),
        scaled_numeric_difference(
          reported_P_interaction,
          independent_P_interaction
        )
      ),
      passed = isTRUE(reported_present) &&
        isTRUE(independent_present) &&
        identical(as.integer(reported_N), as.integer(independent_N)) &&
        identical(
          as.integer(reported_min_2x2_cell_n),
          as.integer(independent_min_2x2_cell_n)
        ) &&
        identical(reported_estimability, independent_estimability) &&
        is.finite(max_scaled_difference) &&
        max_scaled_difference < 1e-10
    ) |>
    ungroup() |>
    arrange(match(variable, subgroups), subgroup, match(contrast, unname(contrast_lookup)))

  output_path <- file.path(
    spec$target,
    "\u7b2c19\u6b65_\u8d28\u91cf\u6838\u9a8c\u4e0e\u53ef\u590d\u73b0\u4ee3\u7801",
    "07_\u72ec\u7acb\u91cd\u7b97_Model3\u4e9a\u7ec4\u4e0e\u4ea4\u4e92\u4f5c\u7528\u590d\u6838.csv"
  )
  write_excel_csv(comparison, output_path, na = "")

  summaries[[variant_name]] <- tibble(
    variant = variant_name,
    rows = nrow(comparison),
    passed_rows = sum(comparison$passed),
    failed_rows = sum(!comparison$passed),
    maximum_scaled_difference = max(comparison$max_scaled_difference)
  )
}

summary_table <- bind_rows(summaries)
print(summary_table)
if (any(summary_table$failed_rows > 0L)) {
  stop("Independent Model 3 subgroup recomputation did not fully match.", call. = FALSE)
}
cat("Independent Model 3 subgroup recomputation passed for both outcomes.\n")
