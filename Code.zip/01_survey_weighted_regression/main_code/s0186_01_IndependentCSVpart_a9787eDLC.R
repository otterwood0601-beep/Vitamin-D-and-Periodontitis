options(stringsAsFactors = FALSE, survey.lonely.psu = "adjust")

suppressPackageStartupMessages({
  library(dplyr)
  library(purrr)
  library(readr)
  library(survey)
  library(tibble)
})

source_csv <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/",
  "20260802-\u7259\u5468\u708e\u4e2d\u91cdvs\u65e0\u8f7b_VitD\u4e09\u5206\u7c7b_\u4e25\u683c\u53d8\u91cf_\u6700\u7ec8/",
  "\u7b2c3\u6b65_\u6837\u672c\u6392\u9664\u4e0e\u8d28\u91cf\u63a7\u5236/",
  "07_NHANES2009-2014_\u6e05\u6d17\u540e\u4e25\u683c\u5b8c\u6574\u6837\u672c.csv"
)

variants <- list(
  moderate_severe = list(
    target = "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260802-\u7259\u5468\u708e\u4e2d\u91cdvs\u65e0\u8f7b_VitD\u4e09\u5206\u7c7b_\u4e25\u683c\u53d8\u91cf_DLC",
    positive_severity = c("Moderate", "Severe")
  ),
  any_periodontitis = list(
    target = "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260802-\u7259\u5468\u708e\u8f7b\u4e2d\u91cdvs\u65e0_VitD\u4e09\u5206\u7c7b_\u4e25\u683c\u53d8\u91cf_DLC",
    positive_severity = c("Mild", "Moderate", "Severe")
  )
)

model2_covariates <- c(
  "floss_days", "mouthwash_days", "missing_teeth_count", "implant_count",
  "smoking", "alcohol", "physical_activity", "diabetes", "hypertension",
  "cvd", "ckd", "liver", "thyroid", "sex", "bmi", "age", "education",
  "marital", "pir_cat", "race"
)
model3_covariates <- c(
  model2_covariates,
  "energy_kcal", "sugar_g", "cholesterol_mg", "fat_g", "fiber_g",
  "protein_g", "calcium_mg", "phosphorus_mg"
)
models <- list(
  `Model 1` = character(),
  `Model 2` = model2_covariates,
  `Model 3` = model3_covariates
)
categorical_covariates <- c(
  "smoking", "alcohol", "physical_activity", "diabetes", "hypertension",
  "cvd", "ckd", "liver", "thyroid", "sex", "education", "marital",
  "pir_cat", "race"
)

data_csv <- readr::read_csv(source_csv, show_col_types = FALSE)
data_csv[categorical_covariates] <- lapply(
  data_csv[categorical_covariates],
  factor
)
data_csv$strata_pool <- factor(data_csv$strata_pool)
data_csv$psu_pool <- factor(data_csv$psu_pool)
data_csv$vitd_cat <- cut(
  data_csv$vitd_nmol,
  breaks = c(-Inf, 50, 75, Inf),
  right = FALSE,
  labels = c(
    "Deficient (<50 nmol/L)",
    "Insufficient (50-<75 nmol/L)",
    "Sufficient (>=75 nmol/L)"
  )
)
data_csv$vitd_cat <- factor(
  as.character(data_csv$vitd_cat),
  levels = c(
    "Sufficient (>=75 nmol/L)",
    "Insufficient (50-<75 nmol/L)",
    "Deficient (<50 nmol/L)"
  )
)
data_csv$vitd_per10 <- data_csv$vitd_nmol / 10

exposure_levels <- c(
  "Insufficient (50-<75 nmol/L)",
  "Deficient (<50 nmol/L)"
)
reference <- "Sufficient (>=75 nmol/L)"

for (variant_name in names(variants)) {
  spec <- variants[[variant_name]]
  data_variant <- data_csv |>
    mutate(
      outcome_bin = as.integer(
        periodontitis_severity %in% spec$positive_severity
      )
    )
  design <- svydesign(
    ids = ~psu_pool,
    strata = ~strata_pool,
    weights = ~analysis_weight,
    nest = TRUE,
    data = data_variant
  )

  independent_results <- imap_dfr(models, function(covariates, model_name) {
    categorical_fit <- svyglm(
      reformulate(c("vitd_cat", covariates), "outcome_bin"),
      design,
      family = quasibinomial()
    )
    continuous_fit <- svyglm(
      reformulate(c("vitd_per10", covariates), "outcome_bin"),
      design,
      family = quasibinomial()
    )
    categorical_rows <- map_dfr(exposure_levels, function(level) {
      term <- paste0("vitd_cat", level)
      beta <- coef(categorical_fit)[[term]]
      se <- sqrt(vcov(categorical_fit)[term, term])
      tibble(
        model = model_name,
        exposure_type = "Three-category",
        contrast = paste(level, "vs", reference),
        independent_OR = exp(beta),
        independent_CI_lower = exp(beta - 1.96 * se),
        independent_CI_upper = exp(beta + 1.96 * se),
        independent_P = 2 * pnorm(-abs(beta / se))
      )
    })
    beta <- coef(continuous_fit)[["vitd_per10"]]
    se <- sqrt(vcov(continuous_fit)["vitd_per10", "vitd_per10"])
    bind_rows(
      categorical_rows,
      tibble(
        model = model_name,
        exposure_type = "Continuous",
        contrast = "Per 10 nmol/L increase",
        independent_OR = exp(beta),
        independent_CI_lower = exp(beta - 1.96 * se),
        independent_CI_upper = exp(beta + 1.96 * se),
        independent_P = 2 * pnorm(-abs(beta / se))
      )
    )
  })

  primary_path <- file.path(
    spec$target,
    "\u7b2c9\u6b65_\u591a\u53d8\u91cfLogistic\u56de\u5f52\u4e3b\u6548\u5e94",
    "01_NHANES2009-2014_\u7ef4\u751f\u7d20D\u4e09\u5206\u7c7b\u53ca\u8fde\u7eed\u53d8\u91cfModel1\u81f33_OR95CI.csv"
  )
  primary <- readr::read_csv(primary_path, show_col_types = FALSE)
  comparison <- primary |>
    select(model, exposure_type, contrast, OR, CI_lower, CI_upper, P) |>
    left_join(
      independent_results,
      by = c("model", "exposure_type", "contrast")
    ) |>
    mutate(
      max_absolute_difference = pmax(
        abs(OR - independent_OR),
        abs(CI_lower - independent_CI_lower),
        abs(CI_upper - independent_CI_upper),
        abs(P - independent_P)
      ),
      passed = max_absolute_difference < 1e-10
    )

  category_levels <- levels(data_variant$vitd_cat)
  unweighted <- table(data_variant$vitd_cat, data_variant$outcome_bin)
  prevalence_raw <- svyby(
    ~outcome_bin,
    ~vitd_cat,
    design,
    svymean,
    na.rm = TRUE,
    vartype = c("se", "ci"),
    keep.names = FALSE
  )
  weight_share <- 100 * tapply(
    data_variant$analysis_weight,
    data_variant$vitd_cat,
    sum
  ) / sum(data_variant$analysis_weight)
  independent_groups <- tibble(
    vitamin_D_category = category_levels,
    independent_N = as.integer(rowSums(unweighted)[category_levels]),
    independent_Yes_N = as.integer(unweighted[category_levels, "1"]),
    independent_No_N = as.integer(unweighted[category_levels, "0"]),
    independent_weighted_share = as.numeric(weight_share[category_levels]),
    independent_weighted_Yes_percent = 100 * prevalence_raw$outcome_bin
  )
  primary_groups <- readr::read_csv(
    file.path(
      spec$target,
      "\u7b2c7\u6b65_\u63cf\u8ff0\u6027\u7edf\u8ba1\u4e0e\u57fa\u7ebf\u6bd4\u8f83",
      "04_NHANES2009-2014_\u7ef4\u751f\u7d20D\u4e09\u5206\u7c7b\u6837\u672c\u91cf\u4e0e\u52a0\u6743\u7ed3\u5c40\u7387.csv"
    ),
    show_col_types = FALSE
  )
  group_comparison <- primary_groups |>
    select(
      vitamin_D_category,
      unweighted_N,
      outcome_Yes_N,
      outcome_No_N,
      weighted_sample_share_percent,
      weighted_outcome_Yes_percent
    ) |>
    left_join(independent_groups, by = "vitamin_D_category") |>
    mutate(
      max_absolute_difference = pmax(
        abs(unweighted_N - independent_N),
        abs(outcome_Yes_N - independent_Yes_N),
        abs(outcome_No_N - independent_No_N),
        abs(weighted_sample_share_percent - independent_weighted_share),
        abs(weighted_outcome_Yes_percent - independent_weighted_Yes_percent)
      ),
      passed = max_absolute_difference < 1e-10
    )

  qa_dir <- file.path(spec$target, "\u7b2c19\u6b65_\u8d28\u91cf\u6838\u9a8c\u4e0e\u53ef\u590d\u73b0\u4ee3\u7801")
  readr::write_excel_csv(
    comparison,
    file.path(qa_dir, "04_\u72ec\u7acbCSV\u91cd\u7b97_Model1\u81f33\u590d\u6838.csv"),
    na = ""
  )
  readr::write_excel_csv(
    group_comparison,
    file.path(qa_dir, "05_\u72ec\u7acbCSV\u91cd\u7b97_\u5206\u7ec4\u4e0e\u52a0\u6743\u7ed3\u5c40\u7387\u590d\u6838.csv"),
    na = ""
  )
  writeLines(
    capture.output(sessionInfo()),
    file.path(qa_dir, "06_sessionInfo_\u72ec\u7acbCSV\u590d\u6838.txt"),
    useBytes = TRUE
  )

  if (!all(comparison$passed) || !all(group_comparison$passed)) {
    stop("Independent CSV verification failed for ", variant_name, call. = FALSE)
  }
}

cat("Independent CSV verification passed for both DLC analyses.\n")
