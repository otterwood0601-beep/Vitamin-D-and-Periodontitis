from __future__ import annotations
import csv
import hashlib
import re
import shutil
from dataclasses import dataclass
from pathlib import Path
from PIL import Image
from pypdf import PdfReader
VITD_ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20')
CANDIDATE_DIR = VITD_ROOT / '\u8f93\u51fa\u7ed3\u679c' / '\u5f53\u524d\u6295\u7a3f\u9879\u76ee' / '\u4f20\u7edf\u5206\u6790' / '\u683c\u5f0f\u5ba1\u8ba1' / '\u53bb\u6807\u9898\u4e0e\u7d27\u51d1\u7559\u767d_QA' / '\u5019\u9009\u7ec8\u7a3f'
FINAL_E_DIR = VITD_ROOT / '\u8f93\u51fa\u7ed3\u679c' / '\u5f53\u524d\u6295\u7a3f\u9879\u76ee' / '\u4f20\u7edf\u5206\u6790' / '\u6b63\u6587\u56fe1 \u903b\u8f91\u56de\u5f52'
BACKUP_DIR = VITD_ROOT / '\u8f93\u51fa\u7ed3\u679c' / '\u5f53\u524d\u6295\u7a3f\u9879\u76ee' / '\u4f20\u7edf\u5206\u6790' / '\u683c\u5f0f\u4fee\u6539\u524d\u5907\u4efd_\u53bb\u6807\u9898\u4e0e\u538b\u7f29\u7559\u767d'
LEGACY_BACKUP_DIR = VITD_ROOT / '\u8f93\u51fa\u7ed3\u679c' / '\u5f53\u524d\u6295\u7a3f\u9879\u76ee' / '\u4f20\u7edf\u5206\u6790' / '\u683c\u5f0f\u4fee\u6539\u524d\u5907\u4efd_\u7d2b\u8272\u4ea4\u4e92\u5217'
DLC_DIR = VITD_ROOT / '\u8f93\u51fa\u7ed3\u679c' / '20260802-\u7259\u5468\u708e\u4e2d\u91cdvs\u65e0\u8f7b_VitD\u4e09\u5206\u7c7b_\u4e25\u683c\u53d8\u91cf_DLC' / '\u7b2c10\u6b65_\u4e9a\u7ec4\u4e0e\u4ea4\u4e92\u4f5c\u7528'
C_FINAL_DIR = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u6b63\u6587\u56fe\\\u6b63\u6587\u56fe1 \u903b\u8f91\u56de\u5f52')
AUDIT_PATH = CANDIDATE_DIR.parent / 'format_change_audit.csv'
SUBTITLE = 'Moderate/severe periodontitis vs none/mild; survey-weighted logistic regression'

@dataclass(frozen=True)
class Target:
    label: str
    stem: str
    dlc_stem: str
    title: str
TARGETS = (Target('VitD_A', 'A.Model3_50-\u5c0f\u4e8e75nmol_Lvs\u5927\u4e8e\u7b49\u4e8e75nmol_L_\u4e03\u680f\u4e9a\u7ec4\u68ee\u6797\u56fe', 'NHANES2009-2014_Model3_50-\u5c0f\u4e8e75nmol_Lvs\u5927\u4e8e\u7b49\u4e8e75nmol_L_\u4e03\u680f\u4e9a\u7ec4\u68ee\u6797\u56fe', 'NHANES 2009-2014 - Model 3 - Insufficient (50-<75 nmol/L) vs Sufficient (>=75 nmol/L)'), Target('VitD_B', 'B.Model3_\u5c0f\u4e8e50nmol_Lvs\u5927\u4e8e\u7b49\u4e8e75nmol_L_\u4e03\u680f\u4e9a\u7ec4\u68ee\u6797\u56fe', 'NHANES2009-2014_Model3_\u5c0f\u4e8e50nmol_Lvs\u5927\u4e8e\u7b49\u4e8e75nmol_L_\u4e03\u680f\u4e9a\u7ec4\u68ee\u6797\u56fe', 'NHANES 2009-2014 - Model 3 - Deficient (<50 nmol/L) vs Sufficient (>=75 nmol/L)'))

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def pdf_text(path: Path) -> str:
    reader = PdfReader(str(path))
    return ' '.join((page.extract_text() or '' for page in reader.pages))

def normalize_text(value: str) -> str:
    return re.sub('\\s+', ' ', value).strip()

def pdf_geometry(path: Path) -> tuple[int, float, float]:
    reader = PdfReader(str(path))
    page = reader.pages[0]
    return (len(reader.pages), float(page.mediabox.width), float(page.mediabox.height))

def ensure_expected_path(path: Path, root: Path) -> None:
    resolved = path.resolve()
    resolved.relative_to(root.resolve())

def backup_once(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not destination.exists():
        shutil.copy2(source, destination)

def publish(target: Target) -> dict[str, object]:
    candidate_pdf = CANDIDATE_DIR / f'{target.stem}.pdf'
    candidate_png = CANDIDATE_DIR / f'{target.stem}.png'
    final_c_pdf = C_FINAL_DIR / f'{target.stem}.pdf'
    final_e_pdf = FINAL_E_DIR / f'{target.stem}.pdf'
    final_e_png = FINAL_E_DIR / f'{target.stem}.png'
    dlc_pdf = DLC_DIR / f'{target.dlc_stem}.pdf'
    dlc_png = DLC_DIR / f'{target.dlc_stem}.png'
    for path in (candidate_pdf, candidate_png, final_c_pdf, dlc_pdf, dlc_png):
        if not path.exists():
            raise FileNotFoundError(path)
    ensure_expected_path(candidate_pdf, VITD_ROOT)
    ensure_expected_path(candidate_png, VITD_ROOT)
    ensure_expected_path(final_c_pdf, C_FINAL_DIR)
    ensure_expected_path(final_e_pdf, VITD_ROOT)
    ensure_expected_path(final_e_png, VITD_ROOT)
    ensure_expected_path(dlc_pdf, VITD_ROOT)
    ensure_expected_path(dlc_png, VITD_ROOT)
    backup_c_pdf = BACKUP_DIR / '\u6b63\u5f0f\u6295\u7a3fPDF' / final_c_pdf.name
    backup_dlc_pdf = BACKUP_DIR / '\u5185\u90e8\u6e90\u56fe' / dlc_pdf.name
    backup_dlc_png = BACKUP_DIR / '\u5185\u90e8\u6e90\u56fe' / dlc_png.name
    if not backup_c_pdf.exists():
        current_text = normalize_text(pdf_text(final_c_pdf))
        if target.title in current_text:
            backup_once(final_c_pdf, backup_c_pdf)
        else:
            legacy_backup = LEGACY_BACKUP_DIR / final_c_pdf.name
            if not legacy_backup.exists():
                raise FileNotFoundError(legacy_backup)
            backup_once(legacy_backup, backup_c_pdf)
    backup_once(dlc_pdf, backup_dlc_pdf)
    backup_once(dlc_png, backup_dlc_png)
    old_text = normalize_text(pdf_text(backup_c_pdf).replace(target.title, '').replace(SUBTITLE, ''))
    new_text = normalize_text(pdf_text(candidate_pdf))
    if old_text != new_text:
        raise RuntimeError(f'Non-heading PDF content changed for {target.label}')
    if target.title in new_text or SUBTITLE in new_text:
        raise RuntimeError(f'Title/subtitle still present for {target.label}')
    old_geometry = pdf_geometry(backup_c_pdf)
    new_geometry = pdf_geometry(candidate_pdf)
    if old_geometry != new_geometry or new_geometry != (1, 1080.0, 1296.0):
        raise RuntimeError(f'Unexpected PDF geometry for {target.label}: {old_geometry} -> {new_geometry}')
    with Image.open(candidate_png) as image:
        png_size = image.size
    if png_size != (4800, 5760):
        raise RuntimeError(f'Unexpected PNG size for {target.label}: {png_size}')
    FINAL_E_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copy2(candidate_pdf, final_e_pdf)
    shutil.copy2(candidate_pdf, dlc_pdf)
    shutil.copy2(candidate_png, final_e_png)
    shutil.copy2(candidate_png, dlc_png)
    formal_pdf_c_status = 'updated'
    try:
        shutil.copy2(candidate_pdf, final_c_pdf)
    except PermissionError:
        formal_pdf_c_status = 'locked_pending'
    candidate_pdf_hash = sha256(candidate_pdf)
    candidate_png_hash = sha256(candidate_png)
    published_paths = (final_e_pdf, dlc_pdf)
    published_pngs = (final_e_png, dlc_png)
    if any((sha256(path) != candidate_pdf_hash for path in published_paths)):
        raise RuntimeError(f'Published PDF hash mismatch for {target.label}')
    if any((sha256(path) != candidate_png_hash for path in published_pngs)):
        raise RuntimeError(f'Published PNG hash mismatch for {target.label}')
    if sha256(final_c_pdf) == candidate_pdf_hash:
        formal_pdf_c_status = 'updated'
    return {'label': target.label, 'formal_pdf_c': str(final_c_pdf), 'formal_pdf_c_status': formal_pdf_c_status, 'formal_pdf_e': str(final_e_pdf), 'formal_png_e': str(final_e_png), 'source_pdf_e': str(dlc_pdf), 'source_png_e': str(dlc_png), 'backup_formal_pdf_e': str(backup_c_pdf), 'backup_source_pdf_e': str(backup_dlc_pdf), 'backup_source_png_e': str(backup_dlc_png), 'title_removed': True, 'subtitle_removed': True, 'non_heading_text_unchanged': True, 'page_count': new_geometry[0], 'page_width_pt': new_geometry[1], 'page_height_pt': new_geometry[2], 'png_width_px': png_size[0], 'png_height_px': png_size[1], 'pdf_sha256': candidate_pdf_hash, 'png_sha256': candidate_png_hash}

def main() -> None:
    rows = [publish(target) for target in TARGETS]
    AUDIT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with AUDIT_PATH.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(AUDIT_PATH)
if __name__ == '__main__':
    main()
