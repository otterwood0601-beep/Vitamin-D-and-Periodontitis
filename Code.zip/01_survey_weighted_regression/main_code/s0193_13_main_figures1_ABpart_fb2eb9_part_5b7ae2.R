options(stringsAsFactors = FALSE)

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(purrr)
  library(readr)
  library(tibble)
})

forest_source_file <- paste0(
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u9879\u76ee\u811a\u672c/",
  "20260802-\u7259\u5468\u708e\u4e2d\u91cdvs\u65e0\u8f7b_VitD\u4e09\u5206\u7c7b_\u4e25\u683c\u53d8\u91cf_DLC/",
  "\u7b2c19\u6b65_\u8d28\u91cf\u6838\u9a8c\u4e0e\u53ef\u590d\u73b0\u4ee3\u7801/",
  "02_\u4e24\u5957DLC\u65b0VitD\u4e09\u5206\u7c7b\u4e9a\u7ec4\u4e0e\u4ea4\u4e92\u4f5c\u7528.R"
)

source_text <- paste(
  readLines(forest_source_file, warn = FALSE, encoding = "UTF-8"),
  collapse = "\n"
)

replace_exactly_once <- function(text, old, new) {
  locations <- gregexpr(old, text, fixed = TRUE)[[1]]
  count <- if (length(locations) == 1L && locations[[1]] == -1L) {
    0L
  } else {
    length(locations)
  }
  if (count != 1L) {
    stop(
      sprintf("Expected exactly one occurrence of [%s], found %d.", old, count),
      call. = FALSE
    )
  }
  sub(old, new, text, fixed = TRUE)
}

replacements <- list(
  c("forest_right <- 0.640", "forest_right <- 0.488333333333"),
  c("xmin = 0.648", "xmin = 0.496333333333"),
  c("xmax = 0.76425", "xmax = 0.612583333333"),
  c("xmin = 0.76425", "xmin = 0.612583333333"),
  c("xmax = 0.83175", "xmax = 0.680083333333"),
  c(
    "geom_text(aes(x = 0.650, label = or_text)",
    "geom_text(aes(x = 0.498333333333, label = or_text)"
  ),
  c(
    "geom_text(aes(x = 0.751, label = p_text)",
    "geom_text(aes(x = 0.599333333333, label = p_text)"
  ),
  c("aes(x = 0.798, label = pi_text)", "aes(x = 0.646333333333, label = pi_text)"),
  c(
    "x = c(0.003, 0.168, 0.650, 0.751, 0.798)",
    "x = c(0.003, 0.168, 0.498333333333, 0.599333333333, 0.646333333333)"
  ),
  c(
    "scale_x_continuous(limits = c(0, 0.83175), expand = expansion(mult = 0))",
    "scale_x_continuous(limits = c(0, 0.680083333333), expand = expansion(mult = 0))"
  )
)

for (replacement in replacements) {
  source_text <- replace_exactly_once(
    source_text,
    replacement[[1]],
    replacement[[2]]
  )
}

source_expressions <- parse(text = source_text, keep.source = FALSE)
render_environment <- new.env(parent = globalenv())
for (expression in source_expressions) {
  is_main_loop_start <-
    is.call(expression) &&
    identical(expression[[1]], as.name("<-")) &&
    identical(as.character(expression[[2]]), "all_summaries")
  if (is_main_loop_start) break
  eval(expression, envir = render_environment)
}

old_total_width <- 0.83175
new_total_width <- 0.680083333333
old_forest_width <- 0.640 - 0.185
new_forest_width <- 0.488333333333 - 0.185
stopifnot(abs(new_forest_width / old_forest_width - 2 / 3) < 1e-10)

new_device_width <- 15 * new_total_width / old_total_width

subgroup_csv <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/",
  "20260802-\u7259\u5468\u708e\u4e2d\u91cdvs\u65e0\u8f7b_VitD\u4e09\u5206\u7c7b_\u4e25\u683c\u53d8\u91cf_DLC/",
  "\u7b2c10\u6b65_\u4e9a\u7ec4\u4e0e\u4ea4\u4e92\u4f5c\u7528/",
  "01_NHANES2009-2014_\u7ef4\u751f\u7d20D\u4e09\u5206\u7c7b_\u5168\u90e820\u9879\u4e9a\u7ec4\u4e0e\u4ea4\u4e92.csv"
)
output_dir <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/\u5f53\u524d\u6295\u7a3f\u9879\u76ee/\u4f20\u7edf\u5206\u6790/\u683c\u5f0f\u5ba1\u8ba1/",
  "\u68ee\u6797\u56fe\u533a\u5bbd\u5ea62_3_\u5019\u9009\u7ec8\u7a3f"
)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

subgroup_results <- read_csv(subgroup_csv, show_col_types = FALSE)
forest_targets <- tribble(
  ~contrast, ~stem,
  "Insufficient (50-<75 nmol/L) vs Sufficient (>=75 nmol/L)",
  paste0(
    "A.Model3_50-\u5c0f\u4e8e75nmol_Lvs\u5927\u4e8e\u7b49\u4e8e75nmol_L_",
    "\u4e03\u680f\u4e9a\u7ec4\u68ee\u6797\u56fe_\u68ee\u6797\u56fe\u533a\u5bbd\u5ea62_3"
  ),
  "Deficient (<50 nmol/L) vs Sufficient (>=75 nmol/L)",
  paste0(
    "B.Model3_\u5c0f\u4e8e50nmol_Lvs\u5927\u4e8e\u7b49\u4e8e75nmol_L_",
    "\u4e03\u680f\u4e9a\u7ec4\u68ee\u6797\u56fe_\u68ee\u6797\u56fe\u533a\u5bbd\u5ea62_3"
  )
)

pwalk(forest_targets, function(contrast, stem) {
  plot <- render_environment$seven_column_plot(
    subgroup_results,
    "Model 3",
    contrast,
    subtitle = NULL
  )
  render_environment$save_plot(
    plot,
    output_dir,
    stem,
    width = new_device_width,
    height = 18
  )
})

message(
  "Rendered separate two-thirds-width forest panels A-B to: ",
  output_dir,
  "; device width = ",
  sprintf("%.6f in", new_device_width)
)
