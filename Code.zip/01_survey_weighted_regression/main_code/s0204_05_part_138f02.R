options(stringsAsFactors = FALSE)

cmd_file <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (!length(cmd_file)) stop("\u8bf7\u4f7f\u7528 Rscript \u8fd0\u884c\u672c\u6587\u4ef6\u3002", call. = FALSE)
script_file <- normalizePath(sub("^--file=", "", cmd_file[[1]]), winslash = "/", mustWork = TRUE)
qa_dir <- dirname(script_file)
root <- dirname(qa_dir)

nonempty <- function(path) {
  file.exists(path) && is.finite(file.info(path)$size) && file.info(path)$size > 0
}

required <- file.path(root, c(
  "\u7b2c3\u6b65_\u6837\u672c\u6392\u9664\u4e0e\u8d28\u91cf\u63a7\u5236/03_NHANES2009-2014_\u4e25\u683c\u9010\u6b65\u6392\u9664\u6d41\u7a0b.csv",
  "\u7b2c3\u6b65_\u6837\u672c\u6392\u9664\u4e0e\u8d28\u91cf\u63a7\u5236/05_\u5176\u4ed6\u534f\u53d8\u91cf\u9010\u53d8\u91cf\u7f3a\u5931\u5ba1\u8ba1.csv",
  "\u7b2c3\u6b65_\u6837\u672c\u6392\u9664\u4e0e\u8d28\u91cf\u63a7\u5236/06_\u8df3\u9898\u7ed3\u6784\u6027\u7f3a\u5931\u4e0e\u7279\u6b8a\u7f16\u7801\u5904\u7406\u5ba1\u8ba1.csv",
  "\u7b2c3\u6b65_\u6837\u672c\u6392\u9664\u4e0e\u8d28\u91cf\u63a7\u5236/07_NHANES2009-2014_\u6e05\u6d17\u540e\u4e25\u683c\u5b8c\u6574\u6837\u672c.csv",
  "\u7b2c6\u6b65_\u534f\u53d8\u91cf\u5b9a\u4e49\u4e0e\u6587\u732e\u4f9d\u636e/01_\u4e25\u683c\u534f\u53d8\u91cf\u6e05\u5355_28\u9879\u4e00\u9879\u4e0d\u6f0f.csv",
  "\u7b2c6\u6b65_\u534f\u53d8\u91cf\u5b9a\u4e49\u4e0e\u6587\u732e\u4f9d\u636e/02_Model1\u81f33\u7cbe\u786e\u8c03\u6574\u53d8\u91cf.csv",
  "\u7b2c6\u6b65_\u534f\u53d8\u91cf\u5b9a\u4e49\u4e0e\u6587\u732e\u4f9d\u636e/03_\u673a\u5668\u5b66\u4e60\u7b2c\u4e00\u8f6e\u5168\u90e829\u4e2a\u5019\u9009\u53d8\u91cf.csv",
  "\u7b2c6\u6b65_\u534f\u53d8\u91cf\u5b9a\u4e49\u4e0e\u6587\u732e\u4f9d\u636e/04_2001-2004\u4e25\u683c\u540c\u7279\u5f81\u65f6\u95f4\u5916\u90e8\u9a8c\u8bc1\u53ef\u884c\u6027\u5ba1\u8ba1.csv",
  "\u7b2c6\u6b65_\u534f\u53d8\u91cf\u5b9a\u4e49\u4e0e\u6587\u732e\u4f9d\u636e/05_\u65f6\u95f4\u5916\u90e8\u9a8c\u8bc1\u4e0d\u53ef\u4f30\u8ba1\u8bf4\u660e.csv",
  "\u7b2c7\u6b65_\u63cf\u8ff0\u6027\u7edf\u8ba1\u4e0e\u57fa\u7ebf\u6bd4\u8f83/01_NHANES2009-2014_\u6309\u7259\u5468\u708eYesNo\u52a0\u6743\u57fa\u7ebf\u8868.csv",
  "\u7b2c7\u6b65_\u63cf\u8ff0\u6027\u7edf\u8ba1\u4e0e\u57fa\u7ebf\u6bd4\u8f83/03_NHANES2009-2014_\u6309\u7ef4\u751f\u7d20D\u4e09\u5206\u7c7b\u52a0\u6743\u57fa\u7ebf\u8868.csv",
  "\u7b2c7\u6b65_\u63cf\u8ff0\u6027\u7edf\u8ba1\u4e0e\u57fa\u7ebf\u6bd4\u8f83/\u7259\u5468\u75c5\u7ef4\u751f\u7d20D_\u6392\u9664\u6d41\u7a0b\u4e0e\u52a0\u6743\u57fa\u7ebf\u8868_\u6700\u7ec8.xlsx",
  "\u7b2c9\u6b65_\u591a\u53d8\u91cfLogistic\u56de\u5f52\u4e3b\u6548\u5e94/01_NHANES2009-2014_\u7ef4\u751f\u7d20D\u4e09\u5206\u7c7b\u53ca\u8fde\u7eed\u53d8\u91cfModel1\u81f33_OR95CI.csv",
  "\u7b2c9\u6b65_\u591a\u53d8\u91cfLogistic\u56de\u5f52\u4e3b\u6548\u5e94/\u7259\u5468\u75c5\u7ef4\u751f\u7d20D_\u4e3b\u6548\u5e94\u4e9a\u7ec4\u4ea4\u4e92\u4e0eRCS_\u6700\u7ec8.xlsx",
  "\u7b2c10\u6b65_\u4e9a\u7ec4\u4e0e\u4ea4\u4e92\u4f5c\u7528/01_NHANES2009-2014_\u7ef4\u751f\u7d20D\u4e09\u5206\u7c7b_\u5168\u90e820\u9879\u4e9a\u7ec4\u4e0e\u4ea4\u4e92.csv",
  "\u7b2c10\u6b65\u9644\u52a0_\u9650\u5236\u6027\u7acb\u65b9\u6837\u6761/01_NHANES2009-2014_Model1\u81f33_RCS\u603b\u4f53\u4e0e\u975e\u7ebf\u6027P\u503c.csv",
  "\u7b2c11\u6b65_LASSO\u7279\u5f81\u7b5b\u9009/06_LASSO\u5341\u6298\u4ea4\u53c9\u9a8c\u8bc1AUC\u66f2\u7ebf.png",
  "\u7b2c11\u6b65_LASSO\u7279\u5f81\u7b5b\u9009/06C_LASSO\u5341\u6298\u4ea4\u53c9\u9a8c\u8bc1MisclassificationError\u66f2\u7ebf.png",
  "\u7b2c11\u6b65_LASSO\u7279\u5f81\u7b5b\u9009/06B_LASSO\u5341\u6298\u4ea4\u53c9\u9a8c\u8bc1_\u56fe2\u683c\u5f0f.png",
  "\u7b2c11\u6b65_LASSO\u7279\u5f81\u7b5b\u9009/07_LASSO\u7cfb\u6570\u8def\u5f84\u56fe.png",
  "\u7b2c12\u6b65_\u6570\u636e\u96c6\u5212\u5206/03_\u8bad\u7ec3\u6d4b\u8bd5\u6837\u672c\u91cf.csv",
  "\u7b2c12\u6b65_\u6570\u636e\u96c6\u5212\u5206/08_\u8868S3_\u8bad\u7ec3\u96c6\u4e0e\u6d4b\u8bd5\u96c6\u57fa\u7ebf\u5747\u8861\u6027.csv",
  "\u7b2c12\u6b65\u9644\u52a0_\u591a\u91cd\u5171\u7ebf\u6027\u4e0eSpearman\u76f8\u5173\u5206\u6790/03_Spearman\u5168\u90e8\u5019\u9009\u53d8\u91cf\u76f8\u5173\u6027\u70ed\u56fe.png",
  "\u7b2c12\u6b65\u9644\u52a0_\u591a\u91cd\u5171\u7ebf\u6027\u4e0eSpearman\u76f8\u5173\u5206\u6790/04_VIF_GVIF\u8bca\u65ad\u8868.csv",
  "\u7b2c14\u6b65_\u591a\u7ef4\u5ea6\u6a21\u578b\u6027\u80fd\u8bc4\u4f30/02_\u4e03\u6a21\u578b\u8bad\u7ec3\u6d4b\u8bd5\u5b8c\u6574\u6027\u80fd\u8868.csv",
  "\u7b2c14\u6b65_\u591a\u7ef4\u5ea6\u6a21\u578b\u6027\u80fd\u8bc4\u4f30/\u7259\u5468\u75c5\u7ef4\u751f\u7d20D_\u673a\u5668\u5b66\u4e60\u5b8c\u6574\u7ed3\u679c_\u6700\u7ec8.xlsx",
  "\u7b2c18\u6b65_SHAP\u53ef\u89e3\u91ca\u6027\u5206\u6790/01_\u5168\u5c40SHAP/01_\u5168\u5c40SHAP\u5e73\u5747\u7edd\u5bf9\u503c\u91cd\u8981\u6027.csv",
  "\u7b2c18\u6b65_SHAP\u53ef\u89e3\u91ca\u6027\u5206\u6790/01_\u5168\u5c40SHAP/01B_lambda1se\u5168\u90e8\u53d8\u91cf\u8fdb\u5165SHAP\u6838\u9a8c.csv",
  "\u7b2c18\u6b65_SHAP\u53ef\u89e3\u91ca\u6027\u5206\u6790/01_\u5168\u5c40SHAP/02_\u5168\u5c40SHAP\u91cd\u8981\u6027\u84dd\u8272\u6761\u5f62\u56fe.png",
  "\u7b2c18\u6b65_SHAP\u53ef\u89e3\u91ca\u6027\u5206\u6790/01_\u5168\u5c40SHAP/03_SHAP\u8702\u7fa4\u56fe.png",
  "\u7b2c18\u6b65_SHAP\u53ef\u89e3\u91ca\u6027\u5206\u6790/02_\u5c40\u90e8SHAP\u529b\u56fe/01_SHAP\u529b\u56fe_\u6b63\u786e\u9884\u6d4b\u9ad8\u98ce\u9669\u4e2a\u4f53_lambda1se\u5168\u90e8\u53d8\u91cf\u9010\u884c\u65e0\u5408\u5e76.png",
  "\u7b2c18\u6b65_SHAP\u53ef\u89e3\u91ca\u6027\u5206\u6790/02_\u5c40\u90e8SHAP\u529b\u56fe/02_SHAP\u529b\u56fe_\u6b63\u786e\u9884\u6d4b\u4f4e\u98ce\u9669\u4e2a\u4f53_lambda1se\u5168\u90e8\u53d8\u91cf\u9010\u884c\u65e0\u5408\u5e76.png",
  "\u7b2c18\u6b65_SHAP\u53ef\u89e3\u91ca\u6027\u5206\u6790/03_\u7ef4\u751f\u7d20D\u4f9d\u8d56/01_\u8840\u6e05\u7ef4\u751f\u7d20D_SHAP\u4f9d\u8d56\u56fe.png",
  "\u7b2c19\u6b65_\u8d28\u91cf\u6838\u9a8c\u4e0e\u53ef\u590d\u73b0\u4ee3\u7801/01_\u4e25\u683c\u6570\u636e\u6784\u5efa\u81ea\u52a8\u8d28\u91cf\u6838\u9a8c.csv",
  "\u7b2c19\u6b65_\u8d28\u91cf\u6838\u9a8c\u4e0e\u53ef\u590d\u73b0\u4ee3\u7801/02_\u590d\u6742\u62bd\u6837\u5206\u6790\u81ea\u52a8\u8d28\u91cf\u6838\u9a8c.csv",
  "\u7b2c19\u6b65_\u8d28\u91cf\u6838\u9a8c\u4e0e\u53ef\u590d\u73b0\u4ee3\u7801/03_\u673a\u5668\u5b66\u4e60\u81ea\u52a8\u8d28\u91cf\u6838\u9a8c.csv"
))

read_passed <- function(path) {
  x <- read.csv(path, check.names = FALSE)
  all(as.logical(x$passed))
}

pair_dirs <- file.path(root, c(
  "\u7b2c9\u6b65_\u591a\u53d8\u91cfLogistic\u56de\u5f52\u4e3b\u6548\u5e94",
  "\u7b2c10\u6b65_\u4e9a\u7ec4\u4e0e\u4ea4\u4e92\u4f5c\u7528",
  "\u7b2c10\u6b65\u9644\u52a0_\u9650\u5236\u6027\u7acb\u65b9\u6837\u6761",
  "\u7b2c11\u6b65_LASSO\u7279\u5f81\u7b5b\u9009",
  "\u7b2c12\u6b65\u9644\u52a0_\u591a\u91cd\u5171\u7ebf\u6027\u4e0eSpearman\u76f8\u5173\u5206\u6790",
  "\u7b2c14\u6b65_\u591a\u7ef4\u5ea6\u6a21\u578b\u6027\u80fd\u8bc4\u4f30/01_ROC\u66f2\u7ebf",
  "\u7b2c14\u6b65_\u591a\u7ef4\u5ea6\u6a21\u578b\u6027\u80fd\u8bc4\u4f30/02_\u6821\u51c6\u66f2\u7ebf",
  "\u7b2c14\u6b65_\u591a\u7ef4\u5ea6\u6a21\u578b\u6027\u80fd\u8bc4\u4f30/03_\u51b3\u7b56\u66f2\u7ebfDCA",
  "\u7b2c14\u6b65_\u591a\u7ef4\u5ea6\u6a21\u578b\u6027\u80fd\u8bc4\u4f30/04_\u6df7\u6dc6\u77e9\u9635",
  "\u7b2c18\u6b65_SHAP\u53ef\u89e3\u91ca\u6027\u5206\u6790/01_\u5168\u5c40SHAP",
  "\u7b2c18\u6b65_SHAP\u53ef\u89e3\u91ca\u6027\u5206\u6790/02_\u5c40\u90e8SHAP\u529b\u56fe",
  "\u7b2c18\u6b65_SHAP\u53ef\u89e3\u91ca\u6027\u5206\u6790/03_\u7ef4\u751f\u7d20D\u4f9d\u8d56"
))

pair_audit <- do.call(rbind, lapply(pair_dirs, function(path) {
  png <- tools::file_path_sans_ext(list.files(path, "\\.png$", full.names = FALSE))
  pdf <- tools::file_path_sans_ext(list.files(path, "\\.pdf$", full.names = FALSE))
  data.frame(
    directory = substring(normalizePath(path, winslash = "/"), nchar(normalizePath(root, winslash = "/")) + 2L),
    png_n = length(png), pdf_n = length(pdf),
    unpaired_png = paste(setdiff(png, pdf), collapse = " | "),
    unpaired_pdf = paste(setdiff(pdf, png), collapse = " | "),
    paired = identical(sort(png), sort(pdf)), check.names = FALSE
  )
}))

subgroup_png <- list.files(file.path(root, "\u7b2c10\u6b65_\u4e9a\u7ec4\u4e0e\u4ea4\u4e92\u4f5c\u7528"), "^NHANES2009-2014_.*\u4e03\u680f\u4e9a\u7ec4\u68ee\u6797\u56fe\\.png$", full.names = TRUE)
subgroup_pdf <- list.files(file.path(root, "\u7b2c10\u6b65_\u4e9a\u7ec4\u4e0e\u4ea4\u4e92\u4f5c\u7528"), "^NHANES2009-2014_.*\u4e03\u680f\u4e9a\u7ec4\u68ee\u6797\u56fe\\.pdf$", full.names = TRUE)
rcs_png <- list.files(file.path(root, "\u7b2c10\u6b65\u9644\u52a0_\u9650\u5236\u6027\u7acb\u65b9\u6837\u6761"), "^NHANES2009-2014_Model[123]_RCS\\.png$", full.names = TRUE)
rcs_pdf <- list.files(file.path(root, "\u7b2c10\u6b65\u9644\u52a0_\u9650\u5236\u6027\u7acb\u65b9\u6837\u6761"), "^NHANES2009-2014_Model[123]_RCS\\.pdf$", full.names = TRUE)

stale_dirs <- list.files(root, recursive = FALSE, full.names = TRUE)
stale_dirs <- stale_dirs[dir.exists(stale_dirs) & grepl("\u7ee7\u627f\u65e7\u7ed3\u679c_\u4e0d\u4f7f\u7528$", basename(stale_dirs))]
all_paths <- list.files(root, recursive = TRUE, full.names = TRUE, include.dirs = FALSE)
allowed_external <- c(
  file.path(root, "\u7b2c6\u6b65_\u534f\u53d8\u91cf\u5b9a\u4e49\u4e0e\u6587\u732e\u4f9d\u636e/04_2001-2004\u4e25\u683c\u540c\u7279\u5f81\u65f6\u95f4\u5916\u90e8\u9a8c\u8bc1\u53ef\u884c\u6027\u5ba1\u8ba1.csv"),
  file.path(root, "\u7b2c6\u6b65_\u534f\u53d8\u91cf\u5b9a\u4e49\u4e0e\u6587\u732e\u4f9d\u636e/05_\u65f6\u95f4\u5916\u90e8\u9a8c\u8bc1\u4e0d\u53ef\u4f30\u8ba1\u8bf4\u660e.csv")
)
stale_external <- all_paths[
  grepl("NHANES2001-2004|\u4e24\u961f\u5217|\u65f6\u95f4\u5916\u90e8\u9a8c\u8bc1|\u5916\u90e8\u9a8c\u8bc1", basename(all_paths)) &
    !normalizePath(all_paths, winslash = "/", mustWork = FALSE) %in%
      normalizePath(allowed_external, winslash = "/", mustWork = FALSE)
]

checks <- data.frame(
  check = c(
    "\u5168\u90e8\u5173\u952e\u6587\u4ef6\u5b58\u5728\u4e14\u975e\u7a7a", "\u4e25\u683c\u6570\u636e\u6784\u5efa\u6838\u9a8c\u5168\u90e8\u901a\u8fc7", "\u590d\u6742\u62bd\u6837\u5206\u6790\u6838\u9a8c\u5168\u90e8\u901a\u8fc7",
    "\u673a\u5668\u5b66\u4e60\u6838\u9a8c\u5168\u90e8\u901a\u8fc7", "LASSO\u8bef\u5206\u7c7b\u7387\u66f2\u7ebf\u6838\u9a8c\u5168\u90e8\u901a\u8fc7", "\u5168\u90e8\u56fe\u5f62PNG/PDF\u6210\u5bf9", "\u4e9a\u7ec4\u68ee\u6797\u56fe\u51716\u5bf9",
    "RCS\u56fe\u51713\u5bf9", "\u6ca1\u6709\u7ee7\u627f\u65e7\u7ed3\u679c\u76ee\u5f55", "\u6ca1\u6709\u8bef\u5bfc\u6027\u5916\u90e8\u9a8c\u8bc1\u65e7\u6587\u4ef6"
  ),
  passed = c(
    all(vapply(required, nonempty, logical(1))),
    read_passed(file.path(qa_dir, "01_\u4e25\u683c\u6570\u636e\u6784\u5efa\u81ea\u52a8\u8d28\u91cf\u6838\u9a8c.csv")),
    read_passed(file.path(qa_dir, "02_\u590d\u6742\u62bd\u6837\u5206\u6790\u81ea\u52a8\u8d28\u91cf\u6838\u9a8c.csv")),
    read_passed(file.path(qa_dir, "03_\u673a\u5668\u5b66\u4e60\u81ea\u52a8\u8d28\u91cf\u6838\u9a8c.csv")),
    read_passed(file.path(qa_dir, "03B_LASSO\u8bef\u5206\u7c7b\u7387\u66f2\u7ebf\u8d28\u91cf\u6838\u9a8c.csv")),
    all(pair_audit$paired), length(subgroup_png) == 6L && length(subgroup_pdf) == 6L,
    length(rcs_png) == 3L && length(rcs_pdf) == 3L,
    length(stale_dirs) == 0L, length(stale_external) == 0L
  ),
  detail = c(
    sprintf("%d/%d", sum(vapply(required, nonempty, logical(1))), length(required)),
    "\u89c101_\u4e25\u683c\u6570\u636e\u6784\u5efa\u81ea\u52a8\u8d28\u91cf\u6838\u9a8c.csv", "\u89c102_\u590d\u6742\u62bd\u6837\u5206\u6790\u81ea\u52a8\u8d28\u91cf\u6838\u9a8c.csv",
    "\u89c103_\u673a\u5668\u5b66\u4e60\u81ea\u52a8\u8d28\u91cf\u6838\u9a8c.csv", "\u89c103B_LASSO\u8bef\u5206\u7c7b\u7387\u66f2\u7ebf\u8d28\u91cf\u6838\u9a8c.csv",
    sprintf("%d/%d\u4e2a\u76ee\u5f55", sum(pair_audit$paired), nrow(pair_audit)),
    sprintf("PNG=%d, PDF=%d", length(subgroup_png), length(subgroup_pdf)),
    sprintf("PNG=%d, PDF=%d", length(rcs_png), length(rcs_pdf)),
    paste(basename(stale_dirs), collapse = " | "), paste(basename(stale_external), collapse = " | ")
  ), check.names = FALSE
)

write.csv(checks, file.path(qa_dir, "05_\u6700\u7ec8\u8f93\u51fa\u5b8c\u6574\u6027\u6838\u9a8c.csv"), row.names = FALSE, fileEncoding = "UTF-8")
write.csv(pair_audit, file.path(qa_dir, "05_\u56fe\u5f62PNG\u4e0ePDF\u914d\u5bf9\u6838\u9a8c.csv"), row.names = FALSE, fileEncoding = "UTF-8")

all_files <- list.files(root, recursive = TRUE, full.names = TRUE, include.dirs = FALSE, all.files = TRUE)
info <- file.info(all_files)
root_norm <- normalizePath(root, winslash = "/")
full_norm <- normalizePath(all_files, winslash = "/")
index_file <- normalizePath(file.path(qa_dir, "06_\u6700\u7ec8\u8f93\u51fa\u6587\u4ef6\u7d22\u5f15.csv"), winslash = "/", mustWork = FALSE)
hash_idx <- full_norm != index_file
md5 <- rep(NA_character_, length(all_files))
md5[hash_idx] <- unname(tools::md5sum(all_files[hash_idx]))
ext <- tolower(tools::file_ext(all_files))
index <- data.frame(
  relative_path = substring(full_norm, nchar(root_norm) + 2L),
  file_name = basename(all_files), extension = ifelse(nzchar(ext), ext, "[none]"),
  bytes = as.numeric(info$size), modified = format(info$mtime, "%Y-%m-%d %H:%M:%S"),
  md5 = md5, non_empty = as.numeric(info$size) > 0 | ext == "log", check.names = FALSE
)
index <- index[order(index$relative_path), ]
write.csv(index, file.path(qa_dir, "06_\u6700\u7ec8\u8f93\u51fa\u6587\u4ef6\u7d22\u5f15.csv"), row.names = FALSE, fileEncoding = "UTF-8")
type_counts <- aggregate(list(file_count = index$file_name), by = list(extension = index$extension), FUN = length)
write.csv(type_counts[order(type_counts$extension), ], file.path(qa_dir, "07_\u6700\u7ec8\u8f93\u51fa\u6587\u4ef6\u7c7b\u578b\u8ba1\u6570.csv"), row.names = FALSE, fileEncoding = "UTF-8")

if (!all(checks$passed)) stop("\u6700\u7ec8\u8f93\u51fa\u5b8c\u6574\u6027\u6838\u9a8c\u5931\u8d25\uff0c\u8bf7\u67e5\u770b05_\u6700\u7ec8\u8f93\u51fa\u5b8c\u6574\u6027\u6838\u9a8c.csv\u3002", call. = FALSE)
if (any(!index$non_empty)) stop("\u68c0\u6d4b\u5230\u7a7a\u6587\u4ef6\uff0c\u8bf7\u67e5\u770b06_\u6700\u7ec8\u8f93\u51fa\u6587\u4ef6\u7d22\u5f15.csv\u3002", call. = FALSE)
message("\u6700\u7ec8\u5b8c\u6574\u6027\u6838\u9a8c\u901a\u8fc7\uff1a", sum(checks$passed), "/", nrow(checks), "\uff1b\u7d22\u5f15\u6587\u4ef6\u6570\uff1a", nrow(index))
