options(stringsAsFactors = FALSE)

source_file <- paste0(
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u9879\u76ee\u811a\u672c/",
  "20260802-\u7259\u5468\u708e\u4e2d\u91cdvs\u65e0\u8f7b_VitD\u4e09\u5206\u7c7b_\u4e25\u683c\u53d8\u91cf_DLC/",
  "\u7b2c19\u6b65_\u8d28\u91cf\u6838\u9a8c\u4e0e\u53ef\u590d\u73b0\u4ee3\u7801/",
  "02_\u4e24\u5957DLC\u65b0VitD\u4e09\u5206\u7c7b\u4e9a\u7ec4\u4e0e\u4ea4\u4e92\u4f5c\u7528.R"
)

source_expressions <- parse(source_file, keep.source = FALSE)
render_environment <- new.env(parent = globalenv())

for (expression in source_expressions) {
  is_main_loop_start <-
    is.call(expression) &&
    identical(expression[[1]], as.name("<-")) &&
    identical(as.character(expression[[2]]), "all_summaries")
  if (is_main_loop_start) break
  eval(expression, envir = render_environment)
}

input_csv <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/",
  "20260802-\u7259\u5468\u708e\u4e2d\u91cdvs\u65e0\u8f7b_VitD\u4e09\u5206\u7c7b_\u4e25\u683c\u53d8\u91cf_DLC/",
  "\u7b2c10\u6b65_\u4e9a\u7ec4\u4e0e\u4ea4\u4e92\u4f5c\u7528/",
  "01_NHANES2009-2014_\u7ef4\u751f\u7d20D\u4e09\u5206\u7c7b_\u5168\u90e820\u9879\u4e9a\u7ec4\u4e0e\u4ea4\u4e92.csv"
)

output_dir <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/\u5f53\u524d\u6295\u7a3f\u9879\u76ee/\u4f20\u7edf\u5206\u6790/",
  "\u683c\u5f0f\u5ba1\u8ba1/\u53bb\u6807\u9898\u4e0e\u7d27\u51d1\u7559\u767d_QA/\u5019\u9009\u7ec8\u7a3f"
)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

subgroup_results <- readr::read_csv(input_csv, show_col_types = FALSE)

targets <- tibble::tribble(
  ~label, ~contrast, ~stem,
  "VitD_A", "Insufficient (50-<75 nmol/L) vs Sufficient (>=75 nmol/L)",
  "A.Model3_50-\u5c0f\u4e8e75nmol_Lvs\u5927\u4e8e\u7b49\u4e8e75nmol_L_\u4e03\u680f\u4e9a\u7ec4\u68ee\u6797\u56fe",
  "VitD_B", "Deficient (<50 nmol/L) vs Sufficient (>=75 nmol/L)",
  "B.Model3_\u5c0f\u4e8e50nmol_Lvs\u5927\u4e8e\u7b49\u4e8e75nmol_L_\u4e03\u680f\u4e9a\u7ec4\u68ee\u6797\u56fe"
)

purrr::pwalk(targets, function(label, contrast, stem) {
  plot <- render_environment$seven_column_plot(
    subgroup_results,
    "Model 3",
    contrast,
    subtitle = NULL
  )
  render_environment$save_plot(plot, output_dir, stem, width = 15, height = 18)
})

message("Rendered two title-free, compact Model 3 forest plots to: ", output_dir)
