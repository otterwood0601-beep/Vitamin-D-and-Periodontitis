options(stringsAsFactors = FALSE, survey.lonely.psu = "adjust")
suppressPackageStartupMessages({
  library(haven); library(dplyr); library(tidyr); library(purrr)
  library(stringr); library(readr); library(tibble)
})

cmd_file <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (!length(cmd_file)) stop("\u8bf7\u4f7f\u7528 Rscript \u8fd0\u884c\u672c\u6587\u4ef6\u3002", call. = FALSE)
script_file <- normalizePath(sub("^--file=", "", cmd_file[[1]]), winslash = "/", mustWork = TRUE)
script_dir <- dirname(script_file)
root <- dirname(script_dir)
source(file.path(script_dir, "00_\u5206\u6790\u914d\u7f6e.R"), encoding = "UTF-8")
set.seed(analysis_seed)

dirs <- list(
  step1 = file.path(root, "\u7b2c1\u6b65_\u6570\u636e\u8bfb\u53d6\u4e0b\u8f7d\u4e0e\u5468\u671f\u5408\u5e76"),
  step3 = file.path(root, "\u7b2c3\u6b65_\u6837\u672c\u6392\u9664\u4e0e\u8d28\u91cf\u63a7\u5236"),
  step4 = file.path(root, "\u7b2c4\u6b65_\u7ed3\u5c40\u53d8\u91cf\u5b9a\u4e49"),
  step5 = file.path(root, "\u7b2c5\u6b65_\u66b4\u9732\u53d8\u91cf\u5b9a\u4e49"),
  step6 = file.path(root, "\u7b2c6\u6b65_\u534f\u53d8\u91cf\u5b9a\u4e49\u4e0e\u6587\u732e\u4f9d\u636e"),
  step12 = file.path(root, "\u7b2c12\u6b65_\u6570\u636e\u96c6\u5212\u5206"),
  qa = script_dir
)
invisible(lapply(dirs, dir.create, recursive = TRUE, showWarnings = FALSE))
write_bom <- function(x, p) readr::write_excel_csv(x, p, na = "")
num <- function(x) suppressWarnings(as.numeric(x))
yn <- function(x) factor(x, levels = c("No", "Yes"))

raw_new <- file.path(source_root, "\u7b2c1\u6b65_\u6570\u636e\u8bfb\u53d6\u4e0b\u8f7d\u4e0e\u5468\u671f\u5408\u5e76", "\u539f\u59cb\u5b98\u65b9\u8865\u5145\u6570\u636e")
raw_main_old <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/01_NHANES/NHANES\u539f\u59cb\u6570\u636e"
raw_f <- file.path(raw_new, "\u4e3b\u5206\u6790_2009-2014")
source_main <- file.path(source_root, "\u7b2c1\u6b65_\u6570\u636e\u8bfb\u53d6\u4e0b\u8f7d\u4e0e\u5468\u671f\u5408\u5e76", "01_NHANES2009-2014_\u6392\u9664\u524d\u6d3e\u751f\u6570\u636e.rds")
source_ext <- file.path(source_root, "\u7b2c1\u6b65_\u6570\u636e\u8bfb\u53d6\u4e0b\u8f7d\u4e0e\u5468\u671f\u5408\u5e76", "02_NHANES2001-2004_\u6392\u9664\u524d\u6d3e\u751f\u6570\u636e.rds")
if (!file.exists(source_main)) stop("\u7f3a\u5c11\u5df2\u6838\u9a8c\u7684NHANES 2009-2014\u6392\u9664\u524d\u6d3e\u751f\u6570\u636e\u3002", call. = FALSE)

loc_chinese <- function(suffix, table) {
  pat <- paste0("（", table, "_", suffix, "）\\.XPT$")
  z <- list.files(raw_main_old, full.names = TRUE)
  hit <- z[str_detect(basename(z), regex(pat, ignore_case = TRUE))]
  if (!length(hit)) stop("Missing local raw file: ", table, "_", suffix)
  hit[[1]]
}
file_cycle <- function(cycle, table) {
  suffix <- c(`2009-2010` = "F", `2011-2012` = "G", `2013-2014` = "H")[[cycle]]
  supplemental <- file.path(raw_new, "\u4e3b\u5206\u6790_2009-2014", paste0(table, "_", suffix, ".XPT"))
  if (file.exists(supplemental)) return(supplemental)
  if (suffix == "F") {
    candidate <- file.path(raw_f, paste0(table, "_F.XPT"))
    if (file.exists(candidate)) return(candidate)
  }
  loc_chinese(suffix, table)
}
read_keep <- function(file, vars) {
  h <- haven::read_xpt(file, n_max = 0)
  miss <- setdiff(vars, names(h))
  if (length(miss)) warning("Missing fields in ", basename(file), ": ", paste(miss, collapse = ", "))
  haven::read_xpt(file, col_select = dplyr::all_of(intersect(vars, names(h))))
}
first_num <- function(d, variable) {
  if (!variable %in% names(d)) return(rep(NA_real_, nrow(d)))
  num(d[[variable]])
}
valid_binary <- function(x) {
  z <- num(x)
  yn(case_when(z == 1 ~ "Yes", z == 2 ~ "No", TRUE ~ NA_character_))
}

activity_component <- function(indicator, days, minutes) {
  i <- num(indicator); d <- num(days); m <- num(minutes)
  case_when(
    i == 2 ~ 0,
    i == 1 & d %in% 1:7 & is.finite(m) & m > 0 & m < 1440 ~ d * m,
    TRUE ~ NA_real_
  )
}

teeth28 <- sprintf("%02d", c(2:15, 18:31))
derive_strict_cycle <- function(cycle) {
  demo <- read_keep(file_cycle(cycle, "DEMO"), c("SEQN", "RIAGENDR", "DMDEDUC2"))
  smq <- read_keep(file_cycle(cycle, "SMQ"), c("SEQN", "SMQ020", "SMQ040"))
  alq <- read_keep(file_cycle(cycle, "ALQ"), c("SEQN", "ALQ101", "ALQ110", "ALQ120Q", "ALQ120U", "ALQ130"))
  paq <- read_keep(file_cycle(cycle, "PAQ"), c("SEQN", "PAQ605", "PAQ610", "PAD615", "PAQ620", "PAQ625", "PAD630", "PAQ635", "PAQ640", "PAD645", "PAQ650", "PAQ655", "PAD660", "PAQ665", "PAQ670", "PAD675"))
  mcq <- read_keep(file_cycle(cycle, "MCQ"), c("SEQN", "MCQ160L"))
  den <- read_keep(file_cycle(cycle, "OHXDEN"), c("SEQN", "OHDDESTS", paste0("OHX", teeth28, "TC")))

  raw <- reduce(list(demo, smq, alq, paq, mcq), full_join, by = "SEQN")
  q <- first_num(raw, "ALQ120Q"); u <- first_num(raw, "ALQ120U"); drinks_day <- first_num(raw, "ALQ130")
  alq101 <- first_num(raw, "ALQ101")
  frequency_week <- case_when(
    alq101 == 2 ~ 0,
    alq101 == 1 & q == 0 ~ 0,
    alq101 == 1 & q >= 0 & q <= 366 & u == 1 ~ q,
    alq101 == 1 & q >= 0 & q <= 366 & u == 2 ~ q * 12 / 52,
    alq101 == 1 & q >= 0 & q <= 366 & u == 3 ~ q / 52,
    TRUE ~ NA_real_
  )
  drinks_week <- case_when(
    frequency_week == 0 ~ 0,
    is.finite(frequency_week) & drinks_day >= 1 & drinks_day <= 95 ~ frequency_week * drinks_day,
    TRUE ~ NA_real_
  )
  sex_code <- first_num(raw, "RIAGENDR")
  alcohol <- factor(case_when(
    drinks_week == 0 ~ "None",
    sex_code == 1 & drinks_week > 0 & drinks_week <= 14 ~ "Light to moderate",
    sex_code == 2 & drinks_week > 0 & drinks_week <= 7 ~ "Light to moderate",
    sex_code == 1 & drinks_week >= 15 ~ "Heavy",
    sex_code == 2 & drinks_week >= 8 ~ "Heavy",
    TRUE ~ NA_character_
  ), levels = c("None", "Light to moderate", "Heavy"))

  vig_work <- activity_component(raw$PAQ605, raw$PAQ610, raw$PAD615)
  mod_work <- activity_component(raw$PAQ620, raw$PAQ625, raw$PAD630)
  walk_bike <- activity_component(raw$PAQ635, raw$PAQ640, raw$PAD645)
  vig_rec <- activity_component(raw$PAQ650, raw$PAQ655, raw$PAD660)
  mod_rec <- activity_component(raw$PAQ665, raw$PAQ670, raw$PAD675)
  mvpa_week <- 2 * vig_work + mod_work + walk_bike + 2 * vig_rec + mod_rec
  physical_activity <- factor(case_when(
    is.finite(mvpa_week) & mvpa_week < 150 ~ "<150 min/week",
    is.finite(mvpa_week) & mvpa_week >= 150 ~ ">=150 min/week",
    TRUE ~ NA_character_
  ), levels = c("<150 min/week", ">=150 min/week"))

  oral_status <- first_num(den, "OHDDESTS")
  tooth_vars <- intersect(paste0("OHX", teeth28, "TC"), names(den))
  tooth_mat <- as.matrix(data.frame(lapply(den[tooth_vars], num), check.names = FALSE))
  dentition_complete <- oral_status == 1 & rowSums(is.finite(tooth_mat)) == length(teeth28)
  oral <- tibble(
    SEQN = num(den$SEQN),
    missing_teeth_count_strict = ifelse(dentition_complete, rowSums(tooth_mat == 4), NA_real_),
    implant_count_strict = ifelse(dentition_complete, rowSums(tooth_mat == 3), NA_real_)
  )

  base <- raw |>
    transmute(
      SEQN = num(SEQN), cycle = cycle,
      education_strict = factor(case_when(
        num(DMDEDUC2) == 1 ~ "Below 9th grade",
        num(DMDEDUC2) %in% 2:5 ~ ">=9th grade",
        TRUE ~ NA_character_
      ), levels = c("Below 9th grade", ">=9th grade")),
      smoking_strict = factor(case_when(
        num(SMQ020) == 2 ~ "Never smoker",
        num(SMQ020) == 1 & num(SMQ040) == 3 ~ "Former smoker",
        num(SMQ020) == 1 & num(SMQ040) %in% 1:2 ~ "Current smoker",
        TRUE ~ NA_character_
      ), levels = c("Never smoker", "Former smoker", "Current smoker")),
      alcohol_strict = alcohol,
      alcohol_drinks_week = drinks_week,
      physical_activity_strict = physical_activity,
      mvpa_minutes_week = mvpa_week,
      liver_strict = valid_binary(MCQ160L),
      alcohol_skip_to_zero = alq101 == 2 & is.na(q),
      pa_skip_to_zero = (num(PAQ605) == 2 & is.na(num(PAQ610))) |
        (num(PAQ620) == 2 & is.na(num(PAQ625))) |
        (num(PAQ635) == 2 & is.na(num(PAQ640))) |
        (num(PAQ650) == 2 & is.na(num(PAQ655))) |
        (num(PAQ665) == 2 & is.na(num(PAQ670)))
    )
  left_join(base, oral, by = "SEQN")
}

cycles <- c("2009-2010", "2011-2012", "2013-2014")
strict_raw <- map_dfr(cycles, derive_strict_cycle)
main_source <- readRDS(source_main)
main_all <- main_source |>
  select(-any_of(c("education", "smoking", "alcohol", "physical_activity", "liver", "implant_count"))) |>
  left_join(strict_raw, by = c("SEQN", "cycle")) |>
  mutate(
    education = education_strict,
    smoking = smoking_strict,
    alcohol = alcohol_strict,
    physical_activity = physical_activity_strict,
    liver = liver_strict,
    missing_teeth_count = missing_teeth_count_strict,
    implant_count = implant_count_strict,
    floss_days = ifelse(num(floss_days) %in% 0:7, num(floss_days), NA_real_),
    mouthwash_days = ifelse(num(mouthwash_days) %in% 0:7, num(mouthwash_days), NA_real_),
    periodontitis = yn(case_when(
      as.character(periodontitis_severity) %in% c("Moderate", "Severe") ~ "Yes",
      as.character(periodontitis_severity) %in% c("None", "Mild") ~ "No",
      TRUE ~ NA_character_
    )),
    periodontitis_bin = as.integer(periodontitis == "Yes"),
    vitd_nmol = ifelse(is.finite(num(vitd_nmol)) & num(vitd_nmol) > 0, num(vitd_nmol), NA_real_),
    vitd_cat = factor(case_when(
      vitd_nmol < 30 ~ "<30 nmol/L",
      vitd_nmol < 50 ~ "30-<50 nmol/L",
      vitd_nmol >= 50 ~ ">=50 nmol/L",
      TRUE ~ NA_character_
    ), levels = vitd_levels),
    vitd_per10 = vitd_nmol / 10,
    pir_cat = factor(case_when(
      is.finite(num(pir)) & num(pir) < 1 ~ "<1",
      is.finite(num(pir)) & num(pir) <= 3.5 ~ "1-3.5",
      is.finite(num(pir)) & num(pir) > 3.5 ~ ">3.5",
      TRUE ~ NA_character_
    ), levels = c("<1", "1-3.5", ">3.5")),
    bmi = ifelse(is.finite(num(bmi)) & num(bmi) > 0 & num(bmi) < 100, num(bmi), NA_real_),
    age = ifelse(is.finite(num(age)) & num(age) >= 0 & num(age) <= 150, num(age), NA_real_),
    race = droplevels(factor(as.character(race))),
    sex = factor(as.character(sex), levels = c("Male", "Female")),
    marital = factor(as.character(marital), levels = c("Married/cohabiting", "Never married", "Widowed/divorced/separated"))
  ) |>
  select(-ends_with("_strict"))

oral_covariates <- c("floss_days", "mouthwash_days", "missing_teeth_count", "implant_count")
clinical_behavioral <- c("smoking", "alcohol", "physical_activity", "diabetes", "hypertension", "cvd", "ckd", "liver", "thyroid")
demographic <- c("sex", "bmi", "age", "education", "marital", "pir_cat", "race")
nutrition <- c("energy_kcal", "sugar_g", "cholesterol_mg", "fat_g", "fiber_g", "protein_g", "calcium_mg", "phosphorus_mg")
model2_covariates <- c(oral_covariates, clinical_behavioral, demographic)
model3_covariates <- c(model2_covariates, nutrition)
ml_candidates <- c("vitd_nmol", model3_covariates)
stopifnot(length(model2_covariates) == 20L, length(model3_covariates) == 28L, length(ml_candidates) == 29L)
stopifnot(length(setdiff(model3_covariates, names(main_all))) == 0L)

make_flow <- function(d) {
  d_age <- d |> filter(is.finite(age) & age >= 60)
  d_periodontal <- d_age |> filter(!is.na(periodontitis))
  d_vitd <- d_periodontal |> filter(is.finite(vitd_nmol) & !is.na(vitd_cat))
  required <- unique(c(model3_covariates, "analysis_weight", "strata_pool", "psu_pool"))
  ok <- complete.cases(d_vitd[, required, drop = FALSE]) & is.finite(d_vitd$analysis_weight) & d_vitd$analysis_weight > 0
  d_complete <- droplevels(d_vitd[ok, , drop = FALSE])
  flow <- tibble(
    step_order = 0:4,
    step = c("Merged NHANES 2009-2014 participants", "Age <60 years or missing age", "Missing periodontal assessment", "Missing serum 25(OH)D", "Missing other prespecified covariates/design variables"),
    before_n = c(nrow(d), nrow(d), nrow(d_age), nrow(d_periodontal), nrow(d_vitd)),
    removed_n = c(0L, nrow(d) - nrow(d_age), nrow(d_age) - nrow(d_periodontal), nrow(d_periodontal) - nrow(d_vitd), nrow(d_vitd) - nrow(d_complete)),
    remaining_n = c(nrow(d), nrow(d_age), nrow(d_periodontal), nrow(d_vitd), nrow(d_complete))
  )
  list(data = d_complete, flow = flow, post_vitd = d_vitd)
}

flow_result <- make_flow(main_all)
main_cc <- flow_result$data
post_vitd <- flow_result$post_vitd

saveRDS(main_all, file.path(dirs$step1, "01_NHANES2009-2014_\u6392\u9664\u524d\u4e25\u683c\u6d3e\u751f\u6570\u636e.rds"))
saveRDS(main_cc, file.path(dirs$step3, "01_NHANES2009-2014_Model3\u4e25\u683c\u5b8c\u6574\u75c5\u4f8b.rds"))
saveRDS(main_cc, file.path(dirs$step12, "01_NHANES2009-2014_\u673a\u5668\u5b66\u4e60\u4e25\u683c\u5b8c\u6574\u75c5\u4f8b\u6837\u672c.rds"))
write_bom(flow_result$flow, file.path(dirs$step3, "03_NHANES2009-2014_\u4e25\u683c\u9010\u6b65\u6392\u9664\u6d41\u7a0b.csv"))
write_bom(main_cc |> count(cycle, periodontitis, name = "n"), file.path(dirs$step3, "04_\u6700\u7ec8\u6837\u672c\u5206\u5468\u671f\u4e0e\u7ed3\u5c40\u8ba1\u6570.csv"))

missing_audit <- tibble(
  variable = model3_covariates,
  missing_n_after_age_outcome_vitd = vapply(model3_covariates, function(v) sum(is.na(post_vitd[[v]])), integer(1)),
  available_n_after_age_outcome_vitd = vapply(model3_covariates, function(v) sum(!is.na(post_vitd[[v]])), integer(1)),
  denominator_n = nrow(post_vitd)
) |> mutate(available_percent = 100 * available_n_after_age_outcome_vitd / denominator_n)
write_bom(missing_audit, file.path(dirs$step3, "05_\u5176\u4ed6\u534f\u53d8\u91cf\u9010\u53d8\u91cf\u7f3a\u5931\u5ba1\u8ba1.csv"))

skip_audit <- main_all |> group_by(cycle) |> summarise(
  n = n(),
  alcohol_followup_structural_NA_recoded_zero_n = sum(alcohol_skip_to_zero %in% TRUE, na.rm = TRUE),
  physical_activity_followup_structural_NA_recoded_zero_n = sum(pa_skip_to_zero %in% TRUE, na.rm = TRUE),
  floss_invalid_77_99_or_missing_n = sum(is.na(floss_days)),
  mouthwash_invalid_77_99_or_missing_n = sum(is.na(mouthwash_days)),
  .groups = "drop"
)
write_bom(skip_audit, file.path(dirs$step3, "06_\u8df3\u9898\u7ed3\u6784\u6027\u7f3a\u5931\u4e0e\u7279\u6b8a\u7f16\u7801\u5904\u7406\u5ba1\u8ba1.csv"))

export_vars <- c("participant_id", "SEQN", "cycle", "periodontitis", "periodontitis_severity", "vitd_nmol", "vitd_cat", model3_covariates, "analysis_weight", "strata_pool", "psu_pool")
write_bom(main_cc |> select(all_of(export_vars)), file.path(dirs$step3, "07_NHANES2009-2014_\u6e05\u6d17\u540e\u4e25\u683c\u5b8c\u6574\u6837\u672c.csv"))

write_bom(tibble(
  outcome = "Periodontitis", positive = "Yes", negative = "No",
  definition = "\u4e2d\u5ea6\u6216\u91cd\u5ea6\u7259\u5468\u708e=Yes\uff1b\u65e0\u6216\u8f7b\u5ea6\u7259\u5468\u708e=No",
  source = "CDC/AAP site-level AL/PD definition applied to NHANES full-mouth six-site examinations"
), file.path(dirs$step4, "01_\u7259\u5468\u708e\u4e8c\u5206\u7c7b\u5b9a\u4e49.csv"))
write_bom(tibble(
  exposure = "Serum 25(OH)D", source_variable = "LBXVIDMS", unit = "nmol/L",
  category = c("<30 nmol/L", "30-<50 nmol/L", ">=50 nmol/L"),
  IOM_interpretation = c("Deficiency/risk", "Insufficiency/risk", "Sufficiency"),
  continuous_analysis = "Per 10 nmol/L increase"
), file.path(dirs$step5, "01_\u8840\u6e05\u7ef4\u751f\u7d20D\u4e09\u5206\u7c7b\u4e0e\u8fde\u7eed\u53d8\u91cf\u5b9a\u4e49.csv"))

labels <- c(
  floss_days = "Floss/interdental cleaning days (past 7 days)", mouthwash_days = "Mouthwash days for oral problems (past 7 days)",
  missing_teeth_count = "Missing teeth count", implant_count = "Dental implant count", smoking = "Smoking status",
  alcohol = "Alcohol consumption", physical_activity = "Physical activity", diabetes = "Diabetes", hypertension = "Hypertension",
  cvd = "Cardiovascular disease", ckd = "Chronic kidney disease", liver = "Liver disease", thyroid = "Thyroid disease",
  sex = "Sex", bmi = "BMI", age = "Age", education = "Education", marital = "Marital status", pir_cat = "PIR category",
  race = "Race/ethnicity (RIDRETH1 original categories)", energy_kcal = "Energy intake", sugar_g = "Total sugar intake",
  cholesterol_mg = "Cholesterol intake", fat_g = "Total fat intake", fiber_g = "Dietary fiber intake",
  protein_g = "Protein intake", calcium_mg = "Calcium intake", phosphorus_mg = "Phosphorus intake"
)
definition_table <- tibble(
  order = seq_along(model3_covariates),
  variable = model3_covariates,
  label = unname(labels[model3_covariates]),
  role = c(rep("Oral clinical/behavioral", length(oral_covariates)), rep("General clinical/behavioral", length(clinical_behavioral)), rep("Demographic", length(demographic)), rep("Nutrition", length(nutrition))),
  model2 = model3_covariates %in% model2_covariates,
  model3 = TRUE,
  initial_machine_learning_candidate = TRUE
)
write_bom(definition_table, file.path(dirs$step6, "01_\u4e25\u683c\u534f\u53d8\u91cf\u6e05\u5355_28\u9879\u4e00\u9879\u4e0d\u6f0f.csv"))
write_bom(tibble(
  model = c("Model 1", "Model 2", "Model 3"),
  adjustment = c("Unadjusted", paste(unname(labels[model2_covariates]), collapse = ", "), paste(unname(labels[model3_covariates]), collapse = ", ")),
  covariate_n = c(0L, length(model2_covariates), length(model3_covariates))
), file.path(dirs$step6, "02_Model1\u81f33\u7cbe\u786e\u8c03\u6574\u53d8\u91cf.csv"))
write_bom(tibble(order = seq_along(ml_candidates), variable = ml_candidates, label = c("Serum 25(OH)D (nmol/L)", unname(labels[model3_covariates]))), file.path(dirs$step6, "03_\u673a\u5668\u5b66\u4e60\u7b2c\u4e00\u8f6e\u5168\u90e829\u4e2a\u5019\u9009\u53d8\u91cf.csv"))

external_audit <- tibble(
  required_feature = ml_candidates,
  measurable_in_NHANES_2001_2004 = !ml_candidates %in% c("floss_days", "mouthwash_days", "physical_activity"),
  reason = ifelse(ml_candidates %in% c("floss_days", "mouthwash_days", "physical_activity"), "Not collected with the same questionnaire definition in NHANES 2001-2004", "Potentially measurable")
)
write_bom(external_audit, file.path(dirs$step6, "04_2001-2004\u4e25\u683c\u540c\u7279\u5f81\u65f6\u95f4\u5916\u90e8\u9a8c\u8bc1\u53ef\u884c\u6027\u5ba1\u8ba1.csv"))
write_bom(tibble(
  conclusion = "Not estimable under the strict complete-case specification",
  detail = "NHANES 2001-2004 did not collect OHQ870, OHQ875, or the 2009-2014 GPAQ-derived physical-activity variables. Treating design-missing fields as zero or imputing an entire cohort would violate the prespecified definitions."
), file.path(dirs$step6, "05_\u65f6\u95f4\u5916\u90e8\u9a8c\u8bc1\u4e0d\u53ef\u4f30\u8ba1\u8bf4\u660e.csv"))

source_files <- unique(c(source_main, unlist(lapply(cycles, function(cy) vapply(c("DEMO", "SMQ", "ALQ", "PAQ", "MCQ", "OHXDEN"), function(tab) file_cycle(cy, tab), character(1))))))
source_files <- source_files[file.exists(source_files)]
write_bom(tibble(
  source_file = normalizePath(source_files, winslash = "/"),
  bytes = file.info(source_files)$size,
  md5 = unname(tools::md5sum(source_files)),
  source_type = "Local copy of official CDC/NCHS NHANES file"
), file.path(dirs$step1, "03_\u672c\u5730\u5b98\u65b9\u539f\u59cb\u6570\u636e\u6765\u6e90\u4e0e\u5b8c\u6574\u6027\u6e05\u5355.csv"))

qa <- tibble(
  check = c("Strict covariate count", "Initial ML candidate count including vitamin D", "No unrequested covariates", "PIR cut points", "All final records complete for all 28 covariates", "All oral day variables within 0-7", "Implant count is continuous count"),
  passed = c(length(model3_covariates) == 28, length(ml_candidates) == 29, setequal(model3_covariates, c(oral_covariates, clinical_behavioral, demographic, nutrition)), identical(levels(main_all$pir_cat), c("<1", "1-3.5", ">3.5")), all(complete.cases(main_cc[, model3_covariates])), all(main_cc$floss_days %in% 0:7 & main_cc$mouthwash_days %in% 0:7), is.numeric(main_cc$implant_count)),
  detail = c(as.character(length(model3_covariates)), as.character(length(ml_candidates)), paste(model3_covariates, collapse = ", "), paste(levels(main_all$pir_cat), collapse = " | "), paste(nrow(main_cc), "complete records"), "0-7", paste0("range ", paste(range(main_cc$implant_count), collapse = "-")))
)
write_bom(qa, file.path(dirs$qa, "01_\u4e25\u683c\u6570\u636e\u6784\u5efa\u81ea\u52a8\u8d28\u91cf\u6838\u9a8c.csv"))
writeLines(capture.output(sessionInfo()), file.path(dirs$qa, "01_sessionInfo_\u6570\u636e\u6784\u5efa.txt"), useBytes = TRUE)
if (!all(qa$passed)) stop("\u4e25\u683c\u6570\u636e\u6784\u5efa\u8d28\u91cf\u6838\u9a8c\u672a\u5168\u90e8\u901a\u8fc7\u3002", call. = FALSE)

cat("Strict final project prepared.\n")
cat("Merged N:", nrow(main_all), "\n")
cat("Final complete-case N:", nrow(main_cc), "\n")
cat("Model 2 covariates:", length(model2_covariates), "\n")
cat("Model 3 covariates:", length(model3_covariates), "\n")
cat("Initial ML candidates:", length(ml_candidates), "\n")
