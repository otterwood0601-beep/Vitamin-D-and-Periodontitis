cmd_file <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (!length(cmd_file)) stop("\u8bf7\u4f7f\u7528 Rscript \u8fd0\u884c\u672c\u6587\u4ef6\u3002", call. = FALSE)
script_file <- normalizePath(sub("^--file=", "", cmd_file[[1]]), winslash = "/", mustWork = TRUE)
script_dir <- dirname(script_file)
root <- dirname(script_dir)
source(file.path(script_dir, "00_\u5206\u6790\u914d\u7f6e.R"), encoding = "UTF-8")

r_scripts <- c(
  "01_\u6784\u5efa\u7259\u5468\u5206\u6790\u53d8\u4f53\u4e0e\u6392\u9664\u6d41\u7a0b.R",
  "02_\u590d\u6742\u62bd\u6837\u57fa\u7ebf\u4e3b\u6548\u5e94\u4e9a\u7ec4\u4e0eRCS.R",
  "03_\u4f20\u7edf\u673a\u5668\u5b66\u4e60_LASSO_\u4e03\u6a21\u578b_SHAP.R",
  "03B_\u751f\u6210LASSO\u8bef\u5206\u7c7b\u7387\u66f2\u7ebf.R"
)

for (script_name in r_scripts) {
  script_path <- file.path(script_dir, script_name)
  message("\n===== Running: ", script_name, " =====")
  status <- system2(file.path(R.home("bin"), "Rscript"), script_path)
  if (!identical(status, 0L)) {
    stop("\u5206\u6790\u4e2d\u6b62\uff0c\u5931\u8d25\u811a\u672c\uff1a", script_path, call. = FALSE)
  }
}

node_candidates <- c(
  "C:/Users/Lin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe",
  Sys.which("node")
)
node_candidates <- node_candidates[nzchar(node_candidates) & file.exists(node_candidates)]
excel_script <- file.path(script_dir, "04_\u751f\u6210\u6700\u7ec8Excel\u6c47\u603b.js")
if (!length(node_candidates)) stop("\u672a\u627e\u5230 Node.js\uff0c\u65e0\u6cd5\u751f\u6210\u6700\u7ec8 Excel \u6c47\u603b\u3002", call. = FALSE)

message("\n===== Running: 04_\u751f\u6210\u6700\u7ec8Excel\u6c47\u603b.js =====")
old_analysis_root <- Sys.getenv("ANALYSIS_ROOT", unset = NA_character_)
Sys.setenv(ANALYSIS_ROOT = normalizePath(root, winslash = "/"))
status <- system2(node_candidates[[1]], excel_script)
if (is.na(old_analysis_root)) Sys.unsetenv("ANALYSIS_ROOT") else Sys.setenv(ANALYSIS_ROOT = old_analysis_root)
if (!identical(status, 0L)) stop("Excel \u6c47\u603b\u751f\u6210\u5931\u8d25\u3002", call. = FALSE)

qa_script <- file.path(script_dir, "05_\u751f\u6210\u6700\u7ec8\u8f93\u51fa\u7d22\u5f15\u4e0e\u5b8c\u6574\u6027\u6838\u9a8c.R")
message("\n===== Running: 05_\u751f\u6210\u6700\u7ec8\u8f93\u51fa\u7d22\u5f15\u4e0e\u5b8c\u6574\u6027\u6838\u9a8c.R =====")
status <- system2(file.path(R.home("bin"), "Rscript"), qa_script)
if (!identical(status, 0L)) stop("\u6700\u7ec8\u5b8c\u6574\u6027\u6838\u9a8c\u5931\u8d25\u3002", call. = FALSE)

message("\n\u5168\u90e8\u5206\u6790\u5b8c\u6210\uff1a", variant_id)
