options(stringsAsFactors = FALSE, survey.lonely.psu = "adjust")

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(purrr)
  library(readr)
  library(tibble)
  library(stringr)
  library(survey)
  library(ggplot2)
  library(patchwork)
})

input_rds <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/",
  "20260802-\u7259\u5468\u708e\u4e2d\u91cdvs\u65e0\u8f7b_VitD\u4e09\u5206\u7c7b_\u4e25\u683c\u53d8\u91cf_\u6700\u7ec8/",
  "\u7b2c3\u6b65_\u6837\u672c\u6392\u9664\u4e0e\u8d28\u91cf\u63a7\u5236/",
  "01_NHANES2009-2014_Model3\u4e25\u683c\u5b8c\u6574\u75c5\u4f8b.rds"
)

variants <- list(
  moderate_severe = list(
    target = "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260802-\u7259\u5468\u708e\u4e2d\u91cdvs\u65e0\u8f7b_VitD\u4e09\u5206\u7c7b_\u4e25\u683c\u53d8\u91cf_DLC",
    outcome_title = "Moderate/severe periodontitis vs none/mild",
    forest_subtitle = "Moderate/severe periodontitis vs none/mild; survey-weighted logistic regression",
    outcome_definition = "Moderate or severe = Yes; none or mild = No",
    positive_severity = c("Moderate", "Severe")
  ),
  any_periodontitis = list(
    target = "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260802-\u7259\u5468\u708e\u8f7b\u4e2d\u91cdvs\u65e0_VitD\u4e09\u5206\u7c7b_\u4e25\u683c\u53d8\u91cf_DLC",
    outcome_title = "Any periodontitis vs none",
    forest_subtitle = "Mild/moderate/severe periodontitis vs none; survey-weighted logistic regression",
    outcome_definition = "Mild, moderate or severe = Yes; none = No",
    positive_severity = c("Mild", "Moderate", "Severe")
  )
)

write_bom <- function(x, path) {
  readr::write_excel_csv(x, path, na = "")
}

p_fmt <- function(x) {
  ifelse(is.na(x), "", ifelse(x < 0.001, "<0.001", sprintf("%.3f", x)))
}

or_fmt <- function(or, low, high) {
  ifelse(is.finite(or), sprintf("%.2f (%.2f-%.2f)", or, low, high), "")
}

save_plot <- function(plot, directory, stem, width = 15, height = 18) {
  ggsave(
    file.path(directory, paste0(stem, ".png")),
    plot,
    width = width,
    height = height,
    dpi = 320,
    bg = "white",
    limitsize = FALSE
  )
  ggsave(
    file.path(directory, paste0(stem, ".pdf")),
    plot,
    width = width,
    height = height,
    device = cairo_pdf,
    bg = "white",
    limitsize = FALSE
  )
}

safe_regp <- function(model, term) {
  p <- tryCatch(
    as.numeric(regTermTest(model, as.formula(paste0("~", term)))$p),
    error = function(e) NA_real_
  )
  if (length(p) && is.finite(p)) return(p)

  coefficient_names <- names(coef(model))
  pieces <- trimws(str_split(term, "\\+", simplify = TRUE))
  pieces <- pieces[pieces != ""]
  indices <- integer()
  for (piece in pieces) {
    if (str_detect(piece, fixed(":"))) {
      parts <- str_split(piece, fixed(":"), simplify = TRUE)
      hits <- which(
        str_detect(coefficient_names, fixed(":")) &
          vapply(
            coefficient_names,
            function(name) all(vapply(parts, function(part) str_detect(name, fixed(part)), logical(1))),
            logical(1)
          )
      )
    } else {
      hits <- which(coefficient_names == piece | startsWith(coefficient_names, piece))
    }
    indices <- union(indices, hits)
  }
  if (!length(indices)) return(NA_real_)

  beta <- coef(model)[indices]
  covariance <- vcov(model)[indices, indices, drop = FALSE]
  keep <- is.finite(beta) & is.finite(diag(covariance))
  beta <- beta[keep]
  covariance <- covariance[keep, keep, drop = FALSE]
  if (!length(beta)) return(NA_real_)
  statistic <- tryCatch(
    drop(t(beta) %*% MASS::ginv(covariance) %*% beta),
    error = function(e) NA_real_
  )
  ifelse(
    is.finite(statistic),
    pchisq(statistic, df = length(beta), lower.tail = FALSE),
    NA_real_
  )
}

design_of <- function(data) {
  svydesign(
    ids = ~psu_pool,
    strata = ~strata_pool,
    weights = ~analysis_weight,
    nest = TRUE,
    data = data
  )
}

extract_effect <- function(fit, term) {
  coefficients <- coef(fit)
  covariance <- vcov(fit)
  if (!term %in% names(coefficients)) {
    return(tibble(
      OR = NA_real_,
      CI_lower = NA_real_,
      CI_upper = NA_real_,
      P = NA_real_
    ))
  }
  beta <- coefficients[[term]]
  standard_error <- sqrt(covariance[term, term])
  tibble(
    OR = exp(beta),
    CI_lower = exp(beta - 1.96 * standard_error),
    CI_upper = exp(beta + 1.96 * standard_error),
    P = 2 * pnorm(-abs(beta / standard_error))
  )
}

oral_covariates <- c(
  "floss_days", "mouthwash_days", "missing_teeth_count", "implant_count"
)
clinical_behavioral <- c(
  "smoking", "alcohol", "physical_activity", "diabetes", "hypertension",
  "cvd", "ckd", "liver", "thyroid"
)
demographic <- c(
  "sex", "bmi", "age", "education", "marital", "pir_cat", "race"
)
nutrition <- c(
  "energy_kcal", "sugar_g", "cholesterol_mg", "fat_g", "fiber_g",
  "protein_g", "calcium_mg", "phosphorus_mg"
)
model2_covariates <- c(oral_covariates, clinical_behavioral, demographic)
model3_covariates <- c(model2_covariates, nutrition)
models_main <- list(
  `Model 1` = character(),
  `Model 2` = model2_covariates,
  `Model 3` = model3_covariates
)
stopifnot(length(model2_covariates) == 20L, length(model3_covariates) == 28L)

labels <- c(
  floss_group = "Floss/interdental cleaning",
  mouthwash_group = "Mouthwash for oral problems",
  missing_teeth_group = "Missing teeth",
  implant_group = "Dental implants",
  smoking = "Smoking status",
  alcohol = "Alcohol consumption",
  physical_activity = "Physical activity",
  diabetes = "Diabetes",
  hypertension = "Hypertension",
  cvd = "Cardiovascular disease",
  ckd = "Chronic kidney disease",
  liver = "Liver disease",
  thyroid = "Thyroid disease",
  sex = "Sex",
  bmi_cat = "BMI",
  age_group = "Age",
  education = "Education",
  marital = "Marital status",
  pir_cat = "PIR category",
  race = "Race/ethnicity"
)

lab <- function(variable) {
  if (variable %in% names(labels)) unname(labels[[variable]]) else variable
}

subgroups <- c(
  "floss_group", "mouthwash_group", "missing_teeth_group", "implant_group",
  clinical_behavioral,
  "sex", "bmi_cat", "age_group", "education", "marital", "pir_cat", "race"
)

counterpart <- c(
  floss_group = "floss_days",
  mouthwash_group = "mouthwash_days",
  missing_teeth_group = "missing_teeth_count",
  implant_group = "implant_count",
  bmi_cat = "bmi",
  age_group = "age"
)

vitd_reference <- "Sufficient (>=75 nmol/L)"
vitd_levels <- c(
  vitd_reference,
  "Insufficient (50-<75 nmol/L)",
  "Deficient (<50 nmol/L)"
)
exposure_levels <- setdiff(vitd_levels, vitd_reference)
contrast_lookup <- setNames(
  paste(exposure_levels, "vs", vitd_reference),
  exposure_levels
)
contrast_file_tokens <- setNames(
  c(
    "50-\u5c0f\u4e8e75nmol_Lvs\u5927\u4e8e\u7b49\u4e8e75nmol_L",
    "\u5c0f\u4e8e50nmol_Lvs\u5927\u4e8e\u7b49\u4e8e75nmol_L"
  ),
  unname(contrast_lookup)
)

if (!file.exists(input_rds)) {
  stop("Input strict complete-case RDS was not found: ", input_rds, call. = FALSE)
}

base_data <- readRDS(input_rds)
required <- unique(c(
  "SEQN", "cycle", "periodontitis_severity", "vitd_nmol",
  model3_covariates, "analysis_weight", "strata_pool", "psu_pool"
))
missing_columns <- setdiff(required, names(base_data))
if (length(missing_columns)) {
  stop("Missing required columns: ", paste(missing_columns, collapse = ", "), call. = FALSE)
}
if (anyNA(base_data[, required, drop = FALSE])) {
  stop("Strict complete-case input unexpectedly contains missing required values.", call. = FALSE)
}

base_data <- base_data |>
  mutate(
    vitd_cat = cut(
      vitd_nmol,
      breaks = c(-Inf, 50, 75, Inf),
      right = FALSE,
      labels = c(
        "Deficient (<50 nmol/L)",
        "Insufficient (50-<75 nmol/L)",
        "Sufficient (>=75 nmol/L)"
      )
    ),
    vitd_cat = factor(as.character(vitd_cat), levels = vitd_levels),
    age_group = factor(
      case_when(
        age < 65 ~ "60-64",
        age < 70 ~ "65-69",
        age < 75 ~ "70-74",
        TRUE ~ ">=75"
      ),
      levels = c("60-64", "65-69", "70-74", ">=75")
    ),
    bmi_cat = factor(
      case_when(
        bmi < 25 ~ "<25",
        bmi < 30 ~ "25-<30",
        TRUE ~ ">=30"
      ),
      levels = c("<25", "25-<30", ">=30")
    ),
    floss_group = factor(
      ifelse(floss_days == 0, "0 days", "1-7 days"),
      levels = c("0 days", "1-7 days")
    ),
    mouthwash_group = factor(
      ifelse(mouthwash_days == 0, "0 days", "1-7 days"),
      levels = c("0 days", "1-7 days")
    ),
    missing_teeth_group = factor(
      case_when(
        missing_teeth_count == 0 ~ "0",
        missing_teeth_count <= 5 ~ "1-5",
        TRUE ~ ">=6"
      ),
      levels = c("0", "1-5", ">=6")
    ),
    implant_group = factor(
      ifelse(implant_count == 0, "0", ">=1"),
      levels = c("0", ">=1")
    )
  )

fit_subgroups <- function(data, design) {
  imap_dfr(models_main, function(covariates, model_name) {
    map_dfr(subgroups, function(subgroup_variable) {
      remove_variable <- if (subgroup_variable %in% names(counterpart)) {
        counterpart[[subgroup_variable]]
      } else {
        subgroup_variable
      }
      covariates_used <- setdiff(covariates, remove_variable)

      interaction_fit <- tryCatch(
        svyglm(
          as.formula(
            paste(
              "outcome_bin~",
              paste(
                c(paste0("vitd_cat*", subgroup_variable), covariates_used),
                collapse = "+"
              )
            )
          ),
          design,
          family = quasibinomial()
        ),
        error = function(e) NULL
      )
      interaction_p <- if (is.null(interaction_fit)) {
        NA_real_
      } else {
        safe_regp(interaction_fit, paste0("vitd_cat:", subgroup_variable))
      }

      subgroup_levels <- levels(droplevels(factor(data[[subgroup_variable]])))
      map_dfr(subgroup_levels, function(subgroup_level) {
        in_level <- as.character(data[[subgroup_variable]]) == subgroup_level
        subgroup_design <- design[in_level, ]
        subgroup_n <- sum(in_level, na.rm = TRUE)
        subgroup_fit <- tryCatch(
          svyglm(
            as.formula(
              paste(
                "outcome_bin~",
                paste(c("vitd_cat", covariates_used), collapse = "+")
              )
            ),
            subgroup_design,
            family = quasibinomial()
          ),
          error = function(e) NULL
        )

        map_dfr(exposure_levels, function(exposure_level) {
          effect <- if (is.null(subgroup_fit)) {
            tibble(
              OR = NA_real_,
              CI_lower = NA_real_,
              CI_upper = NA_real_,
              P = NA_real_
            )
          } else {
            extract_effect(
              subgroup_fit,
              paste0("vitd_cat", exposure_level)
            )
          }
          bind_cols(
            tibble(
              cohort = "NHANES 2009-2014",
              model = model_name,
              variable = subgroup_variable,
              variable_label = lab(subgroup_variable),
              subgroup = subgroup_level,
              N = subgroup_n,
              contrast = unname(contrast_lookup[[exposure_level]])
            ),
            effect,
            tibble(P_interaction = interaction_p)
          )
        })
      })
    })
  })
}

subgroup_cell_min <- function(data, subgroup_variable, subgroup_level, contrast) {
  exposure_level <- names(contrast_lookup)[
    match(contrast, unname(contrast_lookup))
  ]
  subset_data <- data[
    as.character(data[[subgroup_variable]]) == subgroup_level &
      as.character(data$vitd_cat) %in% c(exposure_level, vitd_reference),
    c("vitd_cat", "outcome_bin")
  ]
  cell_table <- table(
    factor(subset_data$vitd_cat, levels = c(exposure_level, vitd_reference)),
    factor(subset_data$outcome_bin, levels = c(0, 1))
  )
  min(cell_table)
}

seven_column_plot <- function(data, model_value, contrast_value, subtitle) {
  filtered <- data |>
    filter(model == model_value, contrast == contrast_value)
  variable_order <- unique(filtered$variable)

  blocks <- map_dfr(seq_along(variable_order), function(index) {
    current_variable <- variable_order[[index]]
    body <- filtered |>
      filter(.data$variable == .env$current_variable)
    bind_rows(
      tibble(
        variable = current_variable,
        variable_label = unique(body$variable_label)[1],
        subgroup = "",
        N = NA_integer_,
        OR = NA_real_,
        CI_lower = NA_real_,
        CI_upper = NA_real_,
        P = NA_real_,
        P_interaction = unique(body$P_interaction)[1],
        estimability = NA_character_,
        header = TRUE,
        block = index
      ),
      body |> mutate(header = FALSE, block = index)
    )
  }) |>
    mutate(
      row = rev(row_number()),
      fill = ifelse(block %% 2, "#D4D9DD", "#EEF1F4"),
      point_col = ifelse(block %% 2, "#111111", "#2E75B6"),
      or_text = case_when(
        header ~ "",
        estimability != "Estimable" ~ "Not estimable",
        TRUE ~ or_fmt(OR, CI_lower, CI_upper)
      ),
      p_text = case_when(
        header ~ "",
        estimability != "Estimable" ~ "",
        TRUE ~ p_fmt(P)
      ),
      pi_text = ifelse(header, p_fmt(P_interaction), ""),
      var_text = ifelse(header, variable_label, ""),
      sub_text = ifelse(
        header,
        "",
        str_replace_all(
          subgroup,
          c(">=" = "≥", "<=" = "≤")
        )
      ),
      n_text = ifelse(header, "", as.character(N))
    )

  if (
    nrow(filtered) != 52L ||
      length(variable_order) != 20L ||
      nrow(blocks) != 72L ||
      sum(blocks$header) != 20L ||
      sum(!blocks$header) != 52L
  ) {
    stop(
      "Seven-column plot row structure is invalid: expected 20 headers and 52 subgroup rows.",
      call. = FALSE
    )
  }

  forest_limit <- c(0.1, 8)

  forest_left <- 0.185
  forest_right <- 0.640
  map_forest_x <- function(value) {
    forest_left +
      (log10(value) - log10(forest_limit[1])) /
        diff(log10(forest_limit)) *
        (forest_right - forest_left)
  }

  plot_rows <- blocks |>
    filter(
      !header,
      estimability == "Estimable",
      is.finite(OR),
      is.finite(CI_lower),
      is.finite(CI_upper),
      OR > 0,
      CI_lower > 0,
      CI_upper > 0
    ) |>
    mutate(
      ci_left_truncated = CI_lower < forest_limit[1],
      ci_right_truncated = CI_upper > forest_limit[2],
      ci_xmin = map_forest_x(pmax(CI_lower, forest_limit[1])),
      ci_xmax = map_forest_x(pmin(CI_upper, forest_limit[2])),
      point_x = map_forest_x(pmin(pmax(OR, forest_limit[1]), forest_limit[2]))
    )

  left_arrows <- plot_rows |>
    filter(ci_left_truncated) |>
    mutate(
      arrow_x = forest_left + 0.025,
      arrow_xend = forest_left + 0.002
    )
  right_arrows <- plot_rows |>
    filter(ci_right_truncated) |>
    mutate(
      arrow_x = forest_right - 0.025,
      arrow_xend = forest_right - 0.002
    )
  left_caps <- plot_rows |> filter(!ci_left_truncated)
  right_caps <- plot_rows |> filter(!ci_right_truncated)

  tick_values <- c(0.1, 0.3, 1, 3)
  tick_x <- map_forest_x(tick_values)
  header_y <- max(blocks$row) + 1.1
  axis_y <- min(blocks$row) - 1.55
  axis_tick_bottom <- axis_y - 0.20
  axis_label_y <- axis_y - 0.55
  axis_title_y <- axis_y - 1.05

  ggplot(blocks, aes(y = row)) +
    
    geom_rect(
      aes(
        xmin = 0.000,
        xmax = 0.175,
        ymin = row - 0.5,
        ymax = row + 0.5,
        fill = fill
      ),
      show.legend = FALSE
    ) +
    geom_rect(
      aes(
        xmin = 0.648,
        xmax = 0.76425,
        ymin = row - 0.5,
        ymax = row + 0.5,
        fill = fill
      ),
      show.legend = FALSE
    ) +
    geom_rect(
      aes(
        xmin = 0.76425,
        xmax = 0.83175,
        ymin = row - 0.5,
        ymax = row + 0.5
      ),
      fill = "#C9C7E8",
      show.legend = FALSE
    ) +
    scale_fill_identity() +
    
    geom_segment(
      x = map_forest_x(1),
      xend = map_forest_x(1),
      y = min(blocks$row) - 0.5,
      yend = max(blocks$row) + 0.5,
      colour = "grey45",
      linewidth = 0.45,
      inherit.aes = FALSE
    ) +
    geom_segment(
      data = plot_rows,
      aes(
        x = ci_xmin,
        xend = ci_xmax,
        y = row,
        yend = row,
        colour = point_col
      ),
      linewidth = 0.55,
      lineend = "butt",
      inherit.aes = FALSE
    ) +
    geom_segment(
      data = left_caps,
      aes(
        x = ci_xmin,
        xend = ci_xmin,
        y = row - 0.12,
        yend = row + 0.12,
        colour = point_col
      ),
      linewidth = 0.55,
      inherit.aes = FALSE
    ) +
    geom_segment(
      data = right_caps,
      aes(
        x = ci_xmax,
        xend = ci_xmax,
        y = row - 0.12,
        yend = row + 0.12,
        colour = point_col
      ),
      linewidth = 0.55,
      inherit.aes = FALSE
    ) +
    geom_segment(
      data = left_arrows,
      aes(
        x = arrow_x,
        xend = arrow_xend,
        y = row,
        yend = row,
        colour = point_col
      ),
      linewidth = 0.65,
      arrow = grid::arrow(
        angle = 24,
        length = grid::unit(0.085, "inches"),
        ends = "last",
        type = "closed"
      ),
      inherit.aes = FALSE
    ) +
    geom_segment(
      data = right_arrows,
      aes(
        x = arrow_x,
        xend = arrow_xend,
        y = row,
        yend = row,
        colour = point_col
      ),
      linewidth = 0.65,
      arrow = grid::arrow(
        angle = 24,
        length = grid::unit(0.085, "inches"),
        ends = "last",
        type = "closed"
      ),
      inherit.aes = FALSE
    ) +
    geom_point(
      data = plot_rows,
      aes(x = point_x, y = row, colour = point_col),
      size = 2.30,
      inherit.aes = FALSE
    ) +
    scale_colour_identity() +
    
    geom_text(
      aes(x = 0.003, label = var_text),
      hjust = 0,
      fontface = ifelse(blocks$header, "bold", "plain"),
      size = 4.05
    ) +
    geom_text(aes(x = 0.012, label = sub_text), hjust = 0, size = 3.80) +
    geom_text(aes(x = 0.168, label = n_text), hjust = 1, size = 3.80) +
    
    geom_text(aes(x = 0.650, label = or_text), hjust = 0, size = 3.65) +
    geom_text(aes(x = 0.751, label = p_text), hjust = 1, size = 3.65) +
    geom_text(
      aes(x = 0.798, label = pi_text),
      hjust = 0.5,
      fontface = ifelse(blocks$header, "bold", "plain"),
      size = 3.65
    ) +
    annotate(
      "text",
      x = c(0.003, 0.168, 0.650, 0.751, 0.798),
      y = header_y,
      label = c("Variables", "N", "OR (95% CI)", "P", "P interaction"),
      hjust = c(0, 1, 0, 1, 0.5),
      fontface = "bold",
      size = 4.30
    ) +
    
    geom_segment(
      x = forest_left,
      xend = forest_right,
      y = axis_y,
      yend = axis_y,
      colour = "black",
      linewidth = 0.55,
      inherit.aes = FALSE
    ) +
    geom_segment(
      data = tibble(x = tick_x),
      aes(x = x, xend = x, y = axis_y, yend = axis_tick_bottom),
      colour = "black",
      linewidth = 0.45,
      inherit.aes = FALSE
    ) +
    annotate(
      "text",
      x = tick_x,
      y = axis_label_y,
      label = c("0.1", "0.3", "1.0", "3.0"),
      size = 3.55
    ) +
    annotate(
      "text",
      x = (forest_left + forest_right) / 2,
      y = axis_title_y,
      label = "Stratification analysis",
      size = 4.00
    ) +
    scale_x_continuous(limits = c(0, 0.83175), expand = expansion(mult = 0)) +
    scale_y_continuous(
      limits = c(axis_title_y - 0.6, max(blocks$row) + 1.6),
      expand = expansion(mult = 0)
    ) +
    coord_cartesian(clip = "off") +
    theme_void() +
    theme(plot.margin = margin(4, 0, 4, 2))
}

all_summaries <- list()

for (variant_name in names(variants)) {
  spec <- variants[[variant_name]]
  step10 <- file.path(spec$target, "\u7b2c10\u6b65_\u4e9a\u7ec4\u4e0e\u4ea4\u4e92\u4f5c\u7528")
  qa_directory <- file.path(spec$target, "\u7b2c19\u6b65_\u8d28\u91cf\u6838\u9a8c\u4e0e\u53ef\u590d\u73b0\u4ee3\u7801")
  dir.create(step10, recursive = TRUE, showWarnings = FALSE)
  dir.create(qa_directory, recursive = TRUE, showWarnings = FALSE)

  analysis_data <- base_data |>
    mutate(
      outcome = factor(
        ifelse(
          periodontitis_severity %in% spec$positive_severity,
          "Yes",
          "No"
        ),
        levels = c("No", "Yes")
      ),
      outcome_bin = as.integer(outcome == "Yes")
    )
  analysis_design <- design_of(analysis_data)

  subgroup_raw <- fit_subgroups(analysis_data, analysis_design)
  subgroup_results <- subgroup_raw |>
    rowwise() |>
    mutate(
      min_2x2_cell_n = subgroup_cell_min(
        analysis_data,
        variable,
        subgroup,
        contrast
      ),
      log_or_se = ifelse(
        is.finite(CI_lower) & is.finite(CI_upper) &
          CI_lower > 0 & CI_upper > 0,
        (log(CI_upper) - log(CI_lower)) / (2 * 1.96),
        NA_real_
      ),
      estimability = ifelse(
        min_2x2_cell_n < 5 |
          !is.finite(OR) |
          !is.finite(CI_lower) |
          !is.finite(CI_upper) |
          OR <= 0 |
          CI_lower <= 0 |
          log_or_se > 2 |
          OR > 100 |
          OR < 0.01 |
          CI_upper > 1000 |
          CI_lower < 0.001,
        "Not estimable: sparse/unstable subgroup fit",
        "Estimable"
      )
    ) |>
    ungroup()

  formatted_results <- subgroup_results |>
    mutate(
      `OR (95% CI)` = ifelse(
        estimability == "Estimable",
        or_fmt(OR, CI_lower, CI_upper),
        "Not estimable"
      ),
      `P value` = ifelse(
        estimability == "Estimable",
        p_fmt(P),
        ""
      ),
      `P interaction` = p_fmt(P_interaction)
    )

  write_bom(
    formatted_results,
    file.path(
      step10,
      "01_NHANES2009-2014_\u7ef4\u751f\u7d20D\u4e09\u5206\u7c7b_\u5168\u90e820\u9879\u4e9a\u7ec4\u4e0e\u4ea4\u4e92.csv"
    )
  )
  write_bom(
    subgroup_raw,
    file.path(step10, "02_\u4e9a\u7ec4\u539f\u59cb\u6a21\u578b\u4f30\u8ba1_\u4ec5\u4f9b\u5ba1\u8ba1.csv")
  )

  plot_manifest <- list()
  for (model_name in names(models_main)) {
    for (contrast in unname(contrast_lookup)) {
      plot <- seven_column_plot(
        subgroup_results,
        model_name,
        contrast,
        spec$forest_subtitle
      )
      stem <- paste0(
        "NHANES2009-2014_",
        str_replace_all(model_name, " ", ""),
        "_",
        contrast_file_tokens[[contrast]],
        "_\u4e03\u680f\u4e9a\u7ec4\u68ee\u6797\u56fe"
      )
      save_plot(plot, step10, stem, 15, 18)
      plot_manifest[[length(plot_manifest) + 1L]] <- tibble(
        model = model_name,
        contrast = contrast,
        png = file.path(step10, paste0(stem, ".png")),
        pdf = file.path(step10, paste0(stem, ".pdf"))
      )
    }
  }
  plot_manifest <- bind_rows(plot_manifest)

  variable_level_count <- subgroup_results |>
    distinct(variable, subgroup) |>
    nrow()
  rows_by_model <- table(subgroup_results$model)
  rows_by_contrast <- table(subgroup_results$contrast)
  interaction_consistency <- subgroup_results |>
    group_by(model, variable) |>
    summarise(n_p = n_distinct(P_interaction), .groups = "drop") |>
    summarise(ok = all(n_p == 1L)) |>
    pull(ok)
  n_consistency <- subgroup_results |>
    group_by(variable, subgroup) |>
    summarise(n_n = n_distinct(N), .groups = "drop") |>
    summarise(ok = all(n_n == 1L)) |>
    pull(ok)
  exact_50_ok <- all(
    as.character(analysis_data$vitd_cat[analysis_data$vitd_nmol == 50]) ==
      "Insufficient (50-<75 nmol/L)"
  )
  exact_75_ok <- all(
    as.character(analysis_data$vitd_cat[analysis_data$vitd_nmol == 75]) ==
      "Sufficient (>=75 nmol/L)"
  )
  expected_plot_files <- c(plot_manifest$png, plot_manifest$pdf)

  qa <- tribble(
    ~check, ~passed, ~detail,
    "Source strict complete-case N", nrow(analysis_data) == 2698L, as.character(nrow(analysis_data)),
    "SEQN unique", !anyDuplicated(analysis_data$SEQN), paste("duplicates", sum(duplicated(analysis_data$SEQN))),
    "Three requested vitamin D categories", identical(levels(analysis_data$vitd_cat), vitd_levels), paste(levels(analysis_data$vitd_cat), collapse = " | "),
    "50 nmol/L assigned to Insufficient", exact_50_ok, paste("exact 50 n", sum(analysis_data$vitd_nmol == 50)),
    "75 nmol/L assigned to Sufficient", exact_75_ok, paste("exact 75 n", sum(analysis_data$vitd_nmol == 75)),
    "All 20 requested subgroup variables included", length(unique(subgroup_results$variable)) == 20L, paste(length(unique(subgroup_results$variable)), "variables"),
    "All 52 subgroup levels included", variable_level_count == 52L, paste(variable_level_count, "variable-level pairs"),
    "All 312 Model-by-level-by-contrast rows included", nrow(subgroup_results) == 312L, paste(nrow(subgroup_results), "rows"),
    "Each model has 104 rows", all(rows_by_model == 104L), paste(names(rows_by_model), rows_by_model, collapse = " | "),
    "Each contrast has 156 rows", all(rows_by_contrast == 156L), paste(names(rows_by_contrast), rows_by_contrast, collapse = " | "),
    "Interaction P values finite", all(is.finite(subgroup_results$P_interaction)), paste("nonfinite", sum(!is.finite(subgroup_results$P_interaction))),
    "Interaction P constant within each model and subgroup variable", interaction_consistency, "Checked across levels and contrasts",
    "Subgroup N constant across models and contrasts", n_consistency, "Checked within every variable-level pair",
    "All minimum 2x2 cell counts nonnegative", all(subgroup_results$min_2x2_cell_n >= 0), paste("minimum", min(subgroup_results$min_2x2_cell_n)),
    "Exactly 12 subgroup forest files generated", length(expected_plot_files) == 12L && all(file.exists(expected_plot_files)), paste(sum(file.exists(expected_plot_files)), "files present"),
    "Model 3 contrast figures generated", all(file.exists(expected_plot_files[str_detect(expected_plot_files, fixed("Model3"))])), paste(sum(str_detect(expected_plot_files, fixed("Model3"))), "Model 3 files")
  )

  write_bom(
    qa,
    file.path(qa_directory, "06_\u4e9a\u7ec4\u5206\u6790\u81ea\u52a8\u8d28\u91cf\u6838\u9a8c.csv")
  )
  writeLines(
    capture.output(sessionInfo()),
    file.path(qa_directory, "08_sessionInfo_\u4e9a\u7ec4\u5206\u6790.txt"),
    useBytes = TRUE
  )
  write_bom(
    tibble(
      source_file = normalizePath(input_rds, winslash = "/"),
      bytes = file.info(input_rds)$size,
      modified_time = format(file.info(input_rds)$mtime, "%Y-%m-%d %H:%M:%S %Z"),
      md5 = unname(tools::md5sum(input_rds)),
      analysis_N = nrow(analysis_data),
      outcome_definition = spec$outcome_definition,
      vitd_definition = "Deficient <50; Insufficient 50-<75; Sufficient >=75 nmol/L (reference)"
    ),
    file.path(qa_directory, "09_\u4e9a\u7ec4\u5206\u6790\u8f93\u5165\u6765\u6e90\u4e0e\u5b8c\u6574\u6027.csv")
  )

  if (!all(qa$passed)) {
    failed <- qa |> filter(!passed) |> pull(check)
    stop(
      "Subgroup analysis QA failed for ",
      variant_name,
      ": ",
      paste(failed, collapse = "; "),
      call. = FALSE
    )
  }

  all_summaries[[variant_name]] <- tibble(
    variant = variant_name,
    outcome = spec$outcome_title,
    N = nrow(analysis_data),
    subgroup_variables = length(unique(subgroup_results$variable)),
    subgroup_levels = variable_level_count,
    result_rows = nrow(subgroup_results),
    estimable_rows = sum(subgroup_results$estimability == "Estimable"),
    not_estimable_rows = sum(subgroup_results$estimability != "Estimable"),
    output_directory = step10
  )
}

print(bind_rows(all_summaries))
cat("Completed both DLC subgroup and interaction analyses.\n")
