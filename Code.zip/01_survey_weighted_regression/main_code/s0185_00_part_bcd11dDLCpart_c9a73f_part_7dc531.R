options(stringsAsFactors = FALSE, survey.lonely.psu = "adjust")

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(purrr)
  library(readr)
  library(tibble)
  library(stringr)
  library(survey)
  library(ggplot2)
})

input_rds <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/",
  "20260802-\u7259\u5468\u708e\u4e2d\u91cdvs\u65e0\u8f7b_VitD\u4e09\u5206\u7c7b_\u4e25\u683c\u53d8\u91cf_\u6700\u7ec8/",
  "\u7b2c3\u6b65_\u6837\u672c\u6392\u9664\u4e0e\u8d28\u91cf\u63a7\u5236/",
  "01_NHANES2009-2014_Model3\u4e25\u683c\u5b8c\u6574\u75c5\u4f8b.rds"
)

variants <- list(
  moderate_severe = list(
    target = "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260802-\u7259\u5468\u708e\u4e2d\u91cdvs\u65e0\u8f7b_VitD\u4e09\u5206\u7c7b_\u4e25\u683c\u53d8\u91cf_DLC",
    outcome_title = "Moderate/severe periodontitis vs none/mild",
    outcome_definition = "Moderate or severe = Yes; none or mild = No",
    outcome_cn = "\u4e2d\u5ea6\u6216\u91cd\u5ea6\u7259\u5468\u708e=Yes\uff1b\u65e0\u6216\u8f7b\u5ea6\u7259\u5468\u708e=No",
    positive_severity = c("Moderate", "Severe")
  ),
  any_periodontitis = list(
    target = "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260802-\u7259\u5468\u708e\u8f7b\u4e2d\u91cdvs\u65e0_VitD\u4e09\u5206\u7c7b_\u4e25\u683c\u53d8\u91cf_DLC",
    outcome_title = "Any periodontitis vs none",
    outcome_definition = "Mild, moderate or severe = Yes; none = No",
    outcome_cn = "\u8f7b\u5ea6\u3001\u4e2d\u5ea6\u6216\u91cd\u5ea6\u7259\u5468\u708e=Yes\uff1b\u65e0\u7259\u5468\u708e=None=No",
    positive_severity = c("Mild", "Moderate", "Severe")
  )
)

write_bom <- function(x, path) {
  readr::write_excel_csv(x, path, na = "")
}

p_fmt <- function(x) {
  ifelse(is.na(x), "", ifelse(x < 0.001, "<0.001", sprintf("%.3f", x)))
}

or_fmt <- function(or, low, high) {
  ifelse(is.finite(or), sprintf("%.2f (%.2f-%.2f)", or, low, high), "")
}

safe_regp <- function(model, term) {
  p <- tryCatch(
    as.numeric(regTermTest(model, as.formula(paste0("~", term)))$p),
    error = function(e) NA_real_
  )
  if (length(p) && is.finite(p)) return(p)
  cn <- names(coef(model))
  pieces <- trimws(str_split(term, "\\+", simplify = TRUE))
  pieces <- pieces[pieces != ""]
  idx <- integer()
  for (piece in pieces) {
    idx <- union(idx, which(cn == piece | startsWith(cn, piece)))
  }
  if (!length(idx)) return(NA_real_)
  b <- coef(model)[idx]
  v <- vcov(model)[idx, idx, drop = FALSE]
  ok <- is.finite(b) & is.finite(diag(v))
  b <- b[ok]
  v <- v[ok, ok, drop = FALSE]
  if (!length(b)) return(NA_real_)
  statistic <- tryCatch(
    drop(t(b) %*% MASS::ginv(v) %*% b),
    error = function(e) NA_real_
  )
  ifelse(
    is.finite(statistic),
    pchisq(statistic, df = length(b), lower.tail = FALSE),
    NA_real_
  )
}

design_of <- function(data) {
  svydesign(
    ids = ~psu_pool,
    strata = ~strata_pool,
    weights = ~analysis_weight,
    nest = TRUE,
    data = data
  )
}

oral_covariates <- c(
  "floss_days", "mouthwash_days", "missing_teeth_count", "implant_count"
)
clinical_behavioral <- c(
  "smoking", "alcohol", "physical_activity", "diabetes", "hypertension",
  "cvd", "ckd", "liver", "thyroid"
)
demographic <- c(
  "sex", "bmi", "age", "education", "marital", "pir_cat", "race"
)
nutrition <- c(
  "energy_kcal", "sugar_g", "cholesterol_mg", "fat_g", "fiber_g",
  "protein_g", "calcium_mg", "phosphorus_mg"
)
model2_covariates <- c(oral_covariates, clinical_behavioral, demographic)
model3_covariates <- c(model2_covariates, nutrition)
models_main <- list(
  `Model 1` = character(),
  `Model 2` = model2_covariates,
  `Model 3` = model3_covariates
)
stopifnot(length(model2_covariates) == 20L, length(model3_covariates) == 28L)

labels <- c(
  age = "Age (years)",
  bmi = "BMI (kg/m2)",
  floss_days = "Floss/interdental cleaning (days/7 days)",
  mouthwash_days = "Mouthwash for oral problems (days/7 days)",
  missing_teeth_count = "Missing teeth (n)",
  implant_count = "Dental implants (n)",
  energy_kcal = "Energy intake (kcal/day)",
  sugar_g = "Total sugar intake (g/day)",
  cholesterol_mg = "Cholesterol intake (mg/day)",
  fat_g = "Total fat intake (g/day)",
  fiber_g = "Dietary fiber (g/day)",
  protein_g = "Protein intake (g/day)",
  calcium_mg = "Calcium intake (mg/day)",
  phosphorus_mg = "Phosphorus intake (mg/day)",
  vitd_nmol = "Serum 25(OH)D (nmol/L)",
  outcome = "Periodontitis outcome",
  sex = "Sex",
  race = "Race/ethnicity",
  education = "Education",
  marital = "Marital status",
  pir_cat = "PIR category",
  smoking = "Smoking status",
  alcohol = "Alcohol consumption",
  physical_activity = "Physical activity",
  diabetes = "Diabetes",
  hypertension = "Hypertension",
  cvd = "Cardiovascular disease",
  ckd = "Chronic kidney disease",
  liver = "Liver disease",
  thyroid = "Thyroid disease"
)

lab <- function(variable) {
  if (variable %in% names(labels)) unname(labels[[variable]]) else variable
}

baseline_table <- function(data, design, group, continuous, categorical, title) {
  group_levels <- levels(droplevels(factor(data[[group]])))

  scalar_prop <- function(subdesign, variable, level) {
    quoted_level <- paste0("'", gsub("'", "\\\\'", level), "'")
    formula <- as.formula(
      paste0("~I(as.numeric(", variable, "==", quoted_level, "))")
    )
    tryCatch(
      as.numeric(coef(svymean(formula, subdesign, na.rm = TRUE))[1]) * 100,
      error = function(e) NA_real_
    )
  }

  continuous_rows <- map_dfr(continuous, function(variable) {
    formula <- as.formula(paste0("~", variable))
    by_group <- tryCatch(
      svyby(
        formula,
        as.formula(paste0("~", group)),
        design,
        svymean,
        na.rm = TRUE,
        vartype = "se",
        keep.names = FALSE
      ),
      error = function(e) NULL
    )
    overall <- svymean(formula, design, na.rm = TRUE)
    p_value <- tryCatch(
      safe_regp(svyglm(as.formula(paste0(variable, "~", group)), design), group),
      error = function(e) NA_real_
    )
    values <- setNames(rep("", length(group_levels)), group_levels)
    if (!is.null(by_group)) {
      se_col <- if (paste0("se.", variable) %in% names(by_group)) {
        paste0("se.", variable)
      } else {
        "se"
      }
      for (i in seq_len(nrow(by_group))) {
        values[as.character(by_group[[group]][i])] <- sprintf(
          "%.2f +/- %.2f",
          by_group[[variable]][i],
          by_group[[se_col]][i]
        )
      }
    }
    tibble(
      Variable = lab(variable),
      Level = "Weighted mean +/- SE",
      Overall = sprintf("%.2f +/- %.2f", coef(overall)[1], SE(overall)[1]),
      !!!as.list(values),
      P = p_fmt(p_value),
      row_type = "continuous"
    )
  })

  categorical_rows <- map_dfr(categorical, function(variable) {
    levels_present <- levels(droplevels(factor(data[[variable]])))
    p_value <- tryCatch(
      as.numeric(
        svychisq(
          as.formula(paste0("~", variable, "+", group)),
          design,
          statistic = "F"
        )$p.value
      ),
      error = function(e) NA_real_
    )
    map_dfr(seq_along(levels_present), function(index) {
      level <- levels_present[index]
      values <- setNames(rep("", length(group_levels)), group_levels)
      for (group_level in group_levels) {
        member <- as.character(data[[group]]) == group_level
        n <- sum(member & as.character(data[[variable]]) == level, na.rm = TRUE)
        subdesign <- design[member, ]
        values[group_level] <- sprintf(
          "%d (%.1f%%)",
          n,
          scalar_prop(subdesign, variable, level)
        )
      }
      overall_n <- sum(as.character(data[[variable]]) == level, na.rm = TRUE)
      tibble(
        Variable = if (index == 1) lab(variable) else "",
        Level = level,
        Overall = sprintf(
          "%d (%.1f%%)",
          overall_n,
          scalar_prop(design, variable, level)
        ),
        !!!as.list(values),
        P = if (index == 1) p_fmt(p_value) else "",
        row_type = "categorical"
      )
    })
  })

  bind_rows(continuous_rows, categorical_rows) |>
    mutate(Table = title, .before = 1)
}

baseline_pct_check <- function(table) {
  value_columns <- setdiff(
    names(table),
    c("Table", "Variable", "Level", "P", "row_type")
  )
  sums <- table |>
    filter(row_type == "categorical") |>
    mutate(Variable = na_if(Variable, "")) |>
    fill(Variable) |>
    mutate(
      across(
        all_of(value_columns),
        ~as.numeric(str_match(.x, "\\(([0-9.]+)%\\)")[, 2])
      )
    ) |>
    group_by(Variable) |>
    summarise(
      across(all_of(value_columns), ~sum(.x, na.rm = TRUE)),
      .groups = "drop"
    )
  all(abs(unlist(sums[value_columns]) - 100) <= 0.2)
}

extract_term <- function(fit, term, contrast, exposure_type, model_name) {
  coefficients <- coef(fit)
  covariance <- vcov(fit)
  if (!term %in% names(coefficients)) {
    return(tibble(
      cohort = "NHANES 2009-2014",
      model = model_name,
      exposure_type = exposure_type,
      contrast = contrast,
      beta = NA_real_,
      robust_SE = NA_real_,
      OR = NA_real_,
      CI_lower = NA_real_,
      CI_upper = NA_real_,
      P = NA_real_,
      CI_design_t_lower = NA_real_,
      CI_design_t_upper = NA_real_,
      P_design_t = NA_real_,
      design_residual_df = fit$df.residual
    ))
  }
  beta <- coefficients[[term]]
  se <- sqrt(covariance[term, term])
  residual_df <- fit$df.residual
  t_critical <- qt(0.975, df = residual_df)
  tibble(
    cohort = "NHANES 2009-2014",
    model = model_name,
    exposure_type = exposure_type,
    contrast = contrast,
    beta = beta,
    robust_SE = se,
    OR = exp(beta),
    CI_lower = exp(beta - 1.96 * se),
    CI_upper = exp(beta + 1.96 * se),
    P = 2 * pnorm(-abs(beta / se)),
    CI_design_t_lower = exp(beta - t_critical * se),
    CI_design_t_upper = exp(beta + t_critical * se),
    P_design_t = 2 * pt(-abs(beta / se), df = residual_df),
    design_residual_df = residual_df
  )
}

make_group_summary <- function(data, design) {
  category_levels <- levels(data$vitd_cat)
  unweighted <- table(data$vitd_cat, data$outcome_bin)
  prevalence_raw <- svyby(
    ~outcome_bin,
    ~vitd_cat,
    design,
    svymean,
    na.rm = TRUE,
    vartype = c("se", "ci"),
    keep.names = FALSE
  )
  prevalence <- setNames(
    prevalence_raw$outcome_bin,
    as.character(prevalence_raw$vitd_cat)
  )
  prevalence_se <- setNames(
    prevalence_raw$se,
    as.character(prevalence_raw$vitd_cat)
  )
  prevalence_low <- setNames(
    prevalence_raw$ci_l,
    as.character(prevalence_raw$vitd_cat)
  )
  prevalence_high <- setNames(
    prevalence_raw$ci_u,
    as.character(prevalence_raw$vitd_cat)
  )
  weight_share <- 100 * tapply(
    data$analysis_weight,
    data$vitd_cat,
    sum
  ) / sum(data$analysis_weight)

  tibble(
    vitamin_D_category = category_levels,
    unweighted_N = as.integer(rowSums(unweighted)[category_levels]),
    outcome_Yes_N = as.integer(unweighted[category_levels, "1"]),
    outcome_No_N = as.integer(unweighted[category_levels, "0"]),
    weighted_sample_share_percent = as.numeric(weight_share[category_levels]),
    weighted_outcome_Yes_percent = 100 * as.numeric(prevalence[category_levels]),
    weighted_outcome_Yes_SE_percent = 100 * as.numeric(prevalence_se[category_levels]),
    weighted_outcome_Yes_CI95_lower_percent = 100 * as.numeric(prevalence_low[category_levels]),
    weighted_outcome_Yes_CI95_upper_percent = 100 * as.numeric(prevalence_high[category_levels])
  )
}

if (!file.exists(input_rds)) {
  stop("Input strict complete-case RDS was not found: ", input_rds, call. = FALSE)
}

base_data <- readRDS(input_rds)
required <- unique(c(
  "SEQN", "cycle", "periodontitis_severity", "vitd_nmol",
  model3_covariates, "analysis_weight", "strata_pool", "psu_pool"
))
missing_columns <- setdiff(required, names(base_data))
if (length(missing_columns)) {
  stop("Missing required columns: ", paste(missing_columns, collapse = ", "), call. = FALSE)
}
if (anyNA(base_data[, required, drop = FALSE])) {
  stop("Strict complete-case input unexpectedly contains missing required values.", call. = FALSE)
}

base_data <- base_data |>
  mutate(
    vitd_cat = cut(
      vitd_nmol,
      breaks = c(-Inf, 50, 75, Inf),
      right = FALSE,
      labels = c(
        "Deficient (<50 nmol/L)",
        "Insufficient (50-<75 nmol/L)",
        "Sufficient (>=75 nmol/L)"
      )
    ),
    vitd_cat = factor(
      as.character(vitd_cat),
      levels = c(
        "Sufficient (>=75 nmol/L)",
        "Insufficient (50-<75 nmol/L)",
        "Deficient (<50 nmol/L)"
      )
    ),
    vitd_per10 = vitd_nmol / 10
  )

continuous_main <- c(
  "age", "bmi", "floss_days", "mouthwash_days", "missing_teeth_count",
  "implant_count", nutrition, "vitd_nmol"
)
categorical_main <- c(
  "sex", "race", "education", "marital", "pir_cat", "smoking", "alcohol",
  "physical_activity", "diabetes", "hypertension", "cvd", "ckd", "liver",
  "thyroid"
)
vitd_reference <- "Sufficient (>=75 nmol/L)"
vitd_levels <- levels(base_data$vitd_cat)
exposure_levels <- setdiff(vitd_levels, vitd_reference)
contrast_lookup <- setNames(
  paste(exposure_levels, "vs", vitd_reference),
  exposure_levels
)

for (variant_name in names(variants)) {
  spec <- variants[[variant_name]]
  dirs <- list(
    root = spec$target,
    step7 = file.path(spec$target, "\u7b2c7\u6b65_\u63cf\u8ff0\u6027\u7edf\u8ba1\u4e0e\u57fa\u7ebf\u6bd4\u8f83"),
    step9 = file.path(spec$target, "\u7b2c9\u6b65_\u591a\u53d8\u91cfLogistic\u56de\u5f52\u4e3b\u6548\u5e94"),
    qa = file.path(spec$target, "\u7b2c19\u6b65_\u8d28\u91cf\u6838\u9a8c\u4e0e\u53ef\u590d\u73b0\u4ee3\u7801")
  )
  invisible(lapply(dirs, dir.create, recursive = TRUE, showWarnings = FALSE))

  main <- base_data |>
    mutate(
      outcome = factor(
        ifelse(periodontitis_severity %in% spec$positive_severity, "Yes", "No"),
        levels = c("No", "Yes")
      ),
      outcome_bin = as.integer(outcome == "Yes")
    )
  main_design <- design_of(main)

  baseline_outcome <- baseline_table(
    main,
    main_design,
    "outcome",
    continuous_main,
    categorical_main,
    paste("NHANES 2009-2014 by outcome:", spec$outcome_title)
  )
  baseline_vitd <- baseline_table(
    main,
    main_design,
    "vitd_cat",
    setdiff(continuous_main, "vitd_nmol"),
    c("outcome", categorical_main),
    paste("NHANES 2009-2014 by vitamin D three categories; outcome:", spec$outcome_title)
  )
  group_summary <- make_group_summary(main, main_design)

  write_bom(
    select(baseline_outcome, -row_type),
    file.path(dirs$step7, "01_NHANES2009-2014_\u6309\u7259\u5468\u708eYesNo\u52a0\u6743\u57fa\u7ebf\u8868.csv")
  )
  write_bom(
    select(baseline_outcome, -Table, -row_type),
    file.path(dirs$step7, "01B_NHANES2009-2014_\u6309\u7259\u5468\u708eYesNo\u52a0\u6743\u57fa\u7ebf\u8868_\u5de5\u4f5c\u7c3f\u7b80\u8868.csv")
  )
  write_bom(
    select(baseline_vitd, -row_type),
    file.path(dirs$step7, "03_NHANES2009-2014_\u6309\u7ef4\u751f\u7d20D\u4e09\u5206\u7c7b\u52a0\u6743\u57fa\u7ebf\u8868.csv")
  )
  write_bom(
    select(baseline_vitd, -Table, -row_type),
    file.path(dirs$step7, "03B_NHANES2009-2014_\u6309\u7ef4\u751f\u7d20D\u4e09\u5206\u7c7b\u52a0\u6743\u57fa\u7ebf\u8868_\u5de5\u4f5c\u7c3f\u7b80\u8868.csv")
  )
  write_bom(
    group_summary,
    file.path(dirs$step7, "04_NHANES2009-2014_\u7ef4\u751f\u7d20D\u4e09\u5206\u7c7b\u6837\u672c\u91cf\u4e0e\u52a0\u6743\u7ed3\u5c40\u7387.csv")
  )

  fits_categorical <- list()
  fits_continuous <- list()
  effects <- imap_dfr(models_main, function(covariates, model_name) {
    categorical_fit <- svyglm(
      as.formula(
        paste(
          "outcome_bin~",
          paste(c("vitd_cat", covariates), collapse = "+")
        )
      ),
      main_design,
      family = quasibinomial()
    )
    continuous_fit <- svyglm(
      as.formula(
        paste(
          "outcome_bin~",
          paste(c("vitd_per10", covariates), collapse = "+")
        )
      ),
      main_design,
      family = quasibinomial()
    )
    fits_categorical[[model_name]] <<- categorical_fit
    fits_continuous[[model_name]] <<- continuous_fit
    categorical_rows <- map_dfr(exposure_levels, function(level) {
      extract_term(
        categorical_fit,
        paste0("vitd_cat", level),
        contrast_lookup[[level]],
        "Three-category",
        model_name
      )
    })
    bind_rows(
      categorical_rows,
      extract_term(
        continuous_fit,
        "vitd_per10",
        "Per 10 nmol/L increase",
        "Continuous",
        model_name
      )
    )
  }) |>
    mutate(
      `OR (95% CI)` = or_fmt(OR, CI_lower, CI_upper),
      `P value` = p_fmt(P),
      `OR (95% CI), design-t sensitivity` = or_fmt(
        OR,
        CI_design_t_lower,
        CI_design_t_upper
      ),
      `P value, design-t sensitivity` = p_fmt(P_design_t)
    )

  overall_tests <- imap_dfr(fits_categorical, function(fit, model_name) {
    design_test <- regTermTest(fit, ~vitd_cat, method = "Wald")
    terms <- paste0("vitd_cat", exposure_levels)
    beta <- coef(fit)[terms]
    covariance <- vcov(fit)[terms, terms, drop = FALSE]
    chi_square <- as.numeric(t(beta) %*% solve(covariance, beta))
    tibble(
      cohort = "NHANES 2009-2014",
      model = model_name,
      exposure = "Serum 25(OH)D: <50, 50-<75, >=75 nmol/L",
      reference = vitd_reference,
      design_Wald_F = as.numeric(design_test$Ftest),
      numerator_df = as.numeric(design_test$df),
      denominator_df = as.numeric(design_test$ddf),
      P_design_Wald_F = as.numeric(design_test$p),
      normal_Wald_chisq = chi_square,
      normal_Wald_df = length(terms),
      P_normal_Wald_chisq = pchisq(
        chi_square,
        df = length(terms),
        lower.tail = FALSE
      )
    )
  })

  model_definitions <- tibble(
    cohort = "NHANES 2009-2014",
    model = names(models_main),
    covariates = vapply(
      models_main,
      function(x) if (length(x)) paste(x, collapse = ", ") else "Unadjusted",
      character(1)
    ),
    adjusted_variables = vapply(
      models_main,
      function(x) {
        if (length(x)) paste(vapply(x, lab, character(1)), collapse = ", ") else "Unadjusted"
      },
      character(1)
    ),
    covariate_n = vapply(models_main, length, integer(1))
  )

  write_bom(
    effects,
    file.path(
      dirs$step9,
      "01_NHANES2009-2014_\u7ef4\u751f\u7d20D\u4e09\u5206\u7c7b\u53ca\u8fde\u7eed\u53d8\u91cfModel1\u81f33_OR95CI.csv"
    )
  )
  write_bom(
    effects |>
      select(
        cohort,
        model,
        exposure_type,
        contrast,
        `OR (95% CI)`,
        `P value`,
        `OR (95% CI), design-t sensitivity`,
        `P value, design-t sensitivity`
      ),
    file.path(
      dirs$step9,
      "01B_NHANES2009-2014_\u7ef4\u751f\u7d20D\u4e3b\u6548\u5e94Model1\u81f33_\u7b80\u8868.csv"
    )
  )
  write_bom(
    model_definitions,
    file.path(dirs$step9, "02_Model1\u81f33\u7cbe\u786e\u8c03\u6574\u53d8\u91cf.csv")
  )
  write_bom(
    overall_tests,
    file.path(dirs$step9, "04_Model1\u81f33_\u7ef4\u751f\u7d20D\u4e09\u5206\u7c7b\u603b\u4f53P\u503c.csv")
  )
  write_bom(
    overall_tests |>
      transmute(
        model,
        exposure,
        reference,
        `P, design-Wald F` = p_fmt(P_design_Wald_F),
        `P, normal-Wald chi-square` = p_fmt(P_normal_Wald_chisq)
      ),
    file.path(dirs$step9, "04B_Model1\u81f33_\u7ef4\u751f\u7d20D\u4e09\u5206\u7c7b\u603b\u4f53P\u503c_\u5de5\u4f5c\u7c3f\u7b80\u8868.csv")
  )
  saveRDS(
    list(categorical = fits_categorical, continuous = fits_continuous),
    file.path(dirs$step9, "05_Model1\u81f33_\u4e3b\u6548\u5e94svyglm\u6a21\u578b.rds")
  )

  plot_data <- effects |>
    filter(exposure_type == "Three-category") |>
    mutate(
      label = factor(
        paste(model, contrast, sep = " - "),
        levels = rev(unique(paste(model, contrast, sep = " - ")))
      )
    )
  main_plot <- ggplot(plot_data, aes(OR, label)) +
    geom_vline(xintercept = 1, linetype = 2, colour = "grey55") +
    geom_errorbar(
      aes(xmin = CI_lower, xmax = CI_upper),
      orientation = "y",
      width = 0.16,
      colour = "#1769AA"
    ) +
    geom_point(size = 2.5, colour = "#1769AA") +
    scale_x_log10() +
    labs(
      title = paste("Serum 25(OH)D and", spec$outcome_title),
      subtitle = paste("Survey-weighted logistic regression; reference:", vitd_reference),
      x = "Odds ratio (log scale)",
      y = NULL
    ) +
    theme_classic(base_size = 12) +
    theme(plot.title = element_text(face = "bold"))
  ggsave(
    file.path(dirs$step9, "03_NHANES2009-2014_Model1\u81f33\u4e3b\u6548\u5e94\u68ee\u6797\u56fe.png"),
    main_plot,
    width = 11,
    height = 6.8,
    dpi = 320,
    bg = "white"
  )
  ggsave(
    file.path(dirs$step9, "03_NHANES2009-2014_Model1\u81f33\u4e3b\u6548\u5e94\u68ee\u6797\u56fe.pdf"),
    main_plot,
    width = 11,
    height = 6.8,
    device = cairo_pdf,
    bg = "white"
  )

  psu_per_stratum <- tapply(
    main$psu_pool,
    main$strata_pool,
    function(x) length(unique(x))
  )
  boundary_50_correct <- all(
    as.character(main$vitd_cat[main$vitd_nmol == 50]) ==
      "Insufficient (50-<75 nmol/L)"
  )
  boundary_75_correct <- all(
    as.character(main$vitd_cat[main$vitd_nmol == 75]) ==
      "Sufficient (>=75 nmol/L)"
  )
  baseline_percentages_ok <- all(
    vapply(
      list(baseline_outcome, baseline_vitd),
      baseline_pct_check,
      logical(1)
    )
  )
  outcome_table <- table(main$outcome)
  category_outcome_table <- table(main$vitd_cat, main$outcome)

  qa <- tribble(
    ~check, ~passed, ~detail,
    "Source strict complete-case N", nrow(main) == 2698L, as.character(nrow(main)),
    "SEQN unique", !anyDuplicated(main$SEQN), paste("duplicates", sum(duplicated(main$SEQN))),
    "Three NHANES cycles", length(unique(main$cycle)) == 3L, paste(sort(unique(main$cycle)), collapse = " | "),
    "No missing model/design values", !anyNA(main[, c(required, "outcome", "outcome_bin", "vitd_cat")]), paste("missing cells", sum(is.na(main[, c(required, "outcome", "outcome_bin", "vitd_cat")]))) ,
    "Finite positive survey weights", all(is.finite(main$analysis_weight) & main$analysis_weight > 0), sprintf("range %.3f to %.3f", min(main$analysis_weight), max(main$analysis_weight)),
    "Vitamin D has exactly three requested categories", identical(levels(main$vitd_cat), c("Sufficient (>=75 nmol/L)", "Insufficient (50-<75 nmol/L)", "Deficient (<50 nmol/L)")), paste(levels(main$vitd_cat), collapse = " | "),
    "50 nmol/L assigned to Insufficient", boundary_50_correct, paste("exact 50 n", sum(main$vitd_nmol == 50)),
    "75 nmol/L assigned to Sufficient", boundary_75_correct, paste("exact 75 n", sum(main$vitd_nmol == 75)),
    "Outcome has No and Yes", identical(names(outcome_table), c("No", "Yes")) && all(outcome_table > 0), paste(names(outcome_table), outcome_table, collapse = " | "),
    "All vitamin-D-by-outcome cells nonempty", all(category_outcome_table > 0), paste("minimum cell n", min(category_outcome_table)),
    "Model 2 uses exactly 20 covariates", length(model2_covariates) == 20L, paste(model2_covariates, collapse = ", "),
    "Model 3 uses exactly 28 covariates", length(model3_covariates) == 28L, paste(model3_covariates, collapse = ", "),
    "All nine main-effect rows present", nrow(effects) == 9L, paste(nrow(effects), "rows"),
    "All main-effect estimates finite", all(is.finite(effects$OR) & is.finite(effects$CI_lower) & is.finite(effects$CI_upper) & is.finite(effects$P)), paste("nonfinite", sum(!is.finite(effects$OR))),
    "Categorical weighted percentages sum to 100%", baseline_percentages_ok, "Both baseline tables checked within 0.2 percentage point rounding tolerance",
    "No observed lonely strata", sum(psu_per_stratum < 2) == 0L, paste("lonely strata", sum(psu_per_stratum < 2)),
    "Survey design degrees of freedom positive", degf(main_design) > 0, paste("design df", degf(main_design)),
    "Model 3 residual design degrees of freedom positive", fits_categorical[["Model 3"]]$df.residual > 0, paste("residual df", fits_categorical[["Model 3"]]$df.residual),
    "Forest plot PNG and PDF generated", file.exists(file.path(dirs$step9, "03_NHANES2009-2014_Model1\u81f33\u4e3b\u6548\u5e94\u68ee\u6797\u56fe.png")) && file.exists(file.path(dirs$step9, "03_NHANES2009-2014_Model1\u81f33\u4e3b\u6548\u5e94\u68ee\u6797\u56fe.pdf")), "PNG/PDF pair"
  )
  write_bom(
    qa,
    file.path(dirs$qa, "01_\u4ec5\u4e3b\u5206\u6790\u4e0e\u57fa\u7ebf\u8868\u81ea\u52a8\u8d28\u91cf\u6838\u9a8c.csv")
  )
  writeLines(
    capture.output(sessionInfo()),
    file.path(dirs$qa, "02_sessionInfo_\u4ec5\u4e3b\u5206\u6790\u4e0e\u57fa\u7ebf\u8868.txt"),
    useBytes = TRUE
  )
  write_bom(
    tibble(
      source_file = normalizePath(input_rds, winslash = "/"),
      bytes = file.info(input_rds)$size,
      modified_time = format(file.info(input_rds)$mtime, "%Y-%m-%d %H:%M:%S %Z"),
      md5 = unname(tools::md5sum(input_rds)),
      analysis_N = nrow(main),
      outcome_definition = spec$outcome_definition
    ),
    file.path(dirs$qa, "03_\u8f93\u5165\u6570\u636e\u6765\u6e90\u4e0e\u5b8c\u6574\u6027.csv")
  )

  readme <- c(
    paste0("# ", spec$outcome_title, "\uff1a\u4ec5\u4e3b\u5206\u6790\u4e0e\u57fa\u7ebf\u8868\uff08DLC\uff09"),
    "",
    paste0("- \u5206\u6790\u961f\u5217\uff1aNHANES 2009-2014\uff0c\u5e74\u9f84 >=60 \u5c81\uff0c\u4e25\u683c\u5b8c\u6574\u75c5\u4f8b N=", nrow(main), "。"),
    paste0("- \u7ed3\u5c40\uff1a", spec$outcome_cn, "。"),
    "- \u7ef4\u751f\u7d20D\u5206\u7c7b\uff1aSufficient >=75 nmol/L\uff08>=30 ng/mL\uff0cRef\uff09\uff1bInsufficient 50-<75 nmol/L\uff0820-<30 ng/mL\uff09\uff1bDeficient <50 nmol/L\uff08<20 ng/mL\uff09\u3002",
    "- \u8fb9\u754c\uff1a50 nmol/L \u5f52\u5165 Insufficient\uff1b75 nmol/L \u5f52\u5165 Sufficient\u3002",
    "- Model 1\uff1a\u672a\u8c03\u6574\uff1bModel 2\uff1a20\u9879\u53e3\u8154\u3001\u4e34\u5e8a/\u884c\u4e3a\u548c\u4eba\u53e3\u5b66\u534f\u53d8\u91cf\uff1bModel 3\uff1a\u5728Model 2\u57fa\u7840\u4e0a\u589e\u52a08\u9879\u8425\u517b\u6444\u5165\uff0c\u517128\u9879\u3002",
    "- \u590d\u6742\u62bd\u6837\uff1aPSU=psu_pool\uff0cstrata=strata_pool\uff0cweight=analysis_weight\uff0cnest=TRUE\u3002",
    "- \u4e3b\u7ed3\u679c\u6cbf\u7528\u539f\u6d41\u7a0b\u7684\u6b63\u6001Wald 95% CI\u4e0eP\u503c\uff1b\u540c\u65f6\u4fdd\u7559design-t\u654f\u611f\u6027\u7ed3\u679c\u3002",
    "- \u672c\u76ee\u5f55\u4ec5\u542b\u7b2c7\u6b65\u57fa\u7ebf\u8868\u3001\u7b2c9\u6b65\u4e3b\u6548\u5e94\u548c\u7b2c19\u6b65\u590d\u73b0/\u8d28\u91cf\u6838\u9a8c\uff1b\u672a\u8fd0\u884c\u4e9a\u7ec4\u3001\u4ea4\u4e92\u3001RCS\u3001LASSO\u3001\u673a\u5668\u5b66\u4e60\u6216SHAP\u3002",
    "",
    "## \u8f93\u51fa",
    "",
    "- \u7b2c7\u6b65\uff1a\u6309\u7ed3\u5c40\u57fa\u7ebf\u8868\u3001\u6309\u7ef4\u751f\u7d20D\u4e09\u5206\u7c7b\u57fa\u7ebf\u8868\u3001\u5206\u7ec4\u6837\u672c\u91cf\u4e0e\u52a0\u6743\u7ed3\u5c40\u7387\u3002",
    "- \u7b2c9\u6b65\uff1aModel 1-3\u4e09\u5206\u7c7b\u53ca\u8fde\u7eed\u7ef4\u751f\u7d20D\u7ed3\u679c\u3001\u603b\u4f53P\u503c\u3001\u68ee\u6797\u56fe\u548c\u6a21\u578b\u5bf9\u8c61\u3002",
    "- Excel\u5de5\u4f5c\u7c3f\u7531\u5355\u72ec\u7684\u7535\u5b50\u8868\u683c\u6784\u5efa\u6b65\u9aa4\u751f\u6210\u3002"
  )
  writeLines(
    readme,
    file.path(dirs$root, "00_\u9879\u76ee\u8bf4\u660e_\u4ec5\u4e3b\u5206\u6790\u4e0e\u57fa\u7ebf\u8868.md"),
    useBytes = TRUE
  )
}

cat("Completed both DLC baseline and main-effect analyses.\n")
