options(stringsAsFactors = FALSE, survey.lonely.psu = "adjust")
suppressPackageStartupMessages({
  library(dplyr); library(tidyr); library(purrr); library(readr); library(tibble)
  library(stringr); library(survey); library(ggplot2); library(patchwork); library(scales)
})
cmd_file <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (!length(cmd_file)) stop("\u8bf7\u4f7f\u7528 Rscript \u8fd0\u884c\u672c\u6587\u4ef6\u3002", call. = FALSE)
script_file <- normalizePath(sub("^--file=", "", cmd_file[[1]]), winslash = "/", mustWork = TRUE)
script_dir <- dirname(script_file)
root <- dirname(script_dir)
source(file.path(script_dir, "00_\u5206\u6790\u914d\u7f6e.R"), encoding = "UTF-8")

main <- readRDS(file.path(root, "\u7b2c3\u6b65_\u6837\u672c\u6392\u9664\u4e0e\u8d28\u91cf\u63a7\u5236", "01_NHANES2009-2014_Model3\u4e25\u683c\u5b8c\u6574\u75c5\u4f8b.rds"))
pir_levels_expected <- c("<1", "1-3.5", ">3.5")
if (!identical(levels(main$pir_cat), pir_levels_expected)) stop("PIR category must be <1, 1-3.5, >3.5.", call. = FALSE)

dirs <- list(
  step7 = file.path(root, "\u7b2c7\u6b65_\u63cf\u8ff0\u6027\u7edf\u8ba1\u4e0e\u57fa\u7ebf\u6bd4\u8f83"),
  step9 = file.path(root, "\u7b2c9\u6b65_\u591a\u53d8\u91cfLogistic\u56de\u5f52\u4e3b\u6548\u5e94"),
  step10 = file.path(root, "\u7b2c10\u6b65_\u4e9a\u7ec4\u4e0e\u4ea4\u4e92\u4f5c\u7528"),
  rcs = file.path(root, "\u7b2c10\u6b65\u9644\u52a0_\u9650\u5236\u6027\u7acb\u65b9\u6837\u6761"),
  qa = script_dir
)
invisible(lapply(dirs, dir.create, recursive = TRUE, showWarnings = FALSE))
write_bom <- function(x, p) readr::write_excel_csv(x, p, na = "")
save_plot <- function(p, dir, stem, w = 12, h = 8) {
  ggsave(file.path(dir, paste0(stem, ".png")), p, width = w, height = h, dpi = 320, bg = "white", limitsize = FALSE)
  ggsave(file.path(dir, paste0(stem, ".pdf")), p, width = w, height = h, device = cairo_pdf, bg = "white", limitsize = FALSE)
}
p_fmt <- function(x) ifelse(is.na(x), "", ifelse(x < 0.001, "<0.001", sprintf("%.3f", x)))
or_fmt <- function(or, lo, hi) ifelse(is.finite(or), sprintf("%.2f (%.2f-%.2f)", or, lo, hi), "")
safe_regp <- function(model, term) {
  p <- tryCatch(as.numeric(regTermTest(model, as.formula(paste0("~", term)))$p), error = function(e) NA_real_)
  if (length(p) && is.finite(p)) return(p)
  cn <- names(coef(model)); pieces <- trimws(str_split(term, "\\+", simplify = TRUE)); pieces <- pieces[pieces != ""]
  idx <- integer()
  for (piece in pieces) {
    if (str_detect(piece, ":")) {
      parts <- str_split(piece, ":", simplify = TRUE)
      hit <- which(str_detect(cn, fixed(":")) & vapply(cn, function(z) all(vapply(parts, function(q) str_detect(z, fixed(q)), logical(1))), logical(1)))
    } else hit <- which(cn == piece | startsWith(cn, piece))
    idx <- union(idx, hit)
  }
  if (!length(idx)) return(NA_real_)
  b <- coef(model)[idx]; V <- vcov(model)[idx, idx, drop = FALSE]
  ok <- is.finite(b) & is.finite(diag(V)); b <- b[ok]; V <- V[ok, ok, drop = FALSE]
  if (!length(b)) return(NA_real_)
  stat <- tryCatch(drop(t(b) %*% MASS::ginv(V) %*% b), error = function(e) NA_real_)
  ifelse(is.finite(stat), pchisq(stat, df = length(b), lower.tail = FALSE), NA_real_)
}
design_of <- function(d) svydesign(ids = ~psu_pool, strata = ~strata_pool, weights = ~analysis_weight, nest = TRUE, data = d)

oral_covariates <- c("floss_days", "mouthwash_days", "missing_teeth_count", "implant_count")
clinical_behavioral <- c("smoking", "alcohol", "physical_activity", "diabetes", "hypertension", "cvd", "ckd", "liver", "thyroid")
demographic <- c("sex", "bmi", "age", "education", "marital", "pir_cat", "race")
nutrition <- c("energy_kcal", "sugar_g", "cholesterol_mg", "fat_g", "fiber_g", "protein_g", "calcium_mg", "phosphorus_mg")
model2_covariates <- c(oral_covariates, clinical_behavioral, demographic)
model3_covariates <- c(model2_covariates, nutrition)
models_main <- list(`Model 1` = character(), `Model 2` = model2_covariates, `Model 3` = model3_covariates)
stopifnot(length(model2_covariates) == 20L, length(model3_covariates) == 28L)

labels <- c(
  age = "Age (years)", bmi = "BMI (kg/m2)", floss_days = "Floss/interdental cleaning (days/7 days)",
  mouthwash_days = "Mouthwash for oral problems (days/7 days)", missing_teeth_count = "Missing teeth (n)",
  implant_count = "Dental implants (n)", energy_kcal = "Energy intake (kcal/day)", sugar_g = "Total sugar intake (g/day)",
  cholesterol_mg = "Cholesterol intake (mg/day)", fat_g = "Total fat intake (g/day)", fiber_g = "Dietary fiber (g/day)",
  protein_g = "Protein intake (g/day)", calcium_mg = "Calcium intake (mg/day)", phosphorus_mg = "Phosphorus intake (mg/day)",
  vitd_nmol = "Serum 25(OH)D (nmol/L)", sex = "Sex", race = "Race/ethnicity", education = "Education",
  marital = "Marital status", pir_cat = "PIR category", smoking = "Smoking status", alcohol = "Alcohol consumption",
  physical_activity = "Physical activity", diabetes = "Diabetes", hypertension = "Hypertension", cvd = "Cardiovascular disease",
  ckd = "Chronic kidney disease", liver = "Liver disease", thyroid = "Thyroid disease", periodontitis = outcome_label,
  vitd_cat = "Serum 25(OH)D category", age_group = "Age", bmi_cat = "BMI", floss_group = "Floss/interdental cleaning",
  mouthwash_group = "Mouthwash for oral problems", missing_teeth_group = "Missing teeth", implant_group = "Dental implants"
)
lab <- function(v) if (v %in% names(labels)) unname(labels[[v]]) else v

main <- main |> mutate(
  age_group = factor(case_when(age < 65 ~ "60-64", age < 70 ~ "65-69", age < 75 ~ "70-74", TRUE ~ ">=75"), levels = c("60-64", "65-69", "70-74", ">=75")),
  bmi_cat = factor(case_when(bmi < 25 ~ "<25", bmi < 30 ~ "25-<30", TRUE ~ ">=30"), levels = c("<25", "25-<30", ">=30")),
  floss_group = factor(ifelse(floss_days == 0, "0 days", "1-7 days"), levels = c("0 days", "1-7 days")),
  mouthwash_group = factor(ifelse(mouthwash_days == 0, "0 days", "1-7 days"), levels = c("0 days", "1-7 days")),
  missing_teeth_group = factor(case_when(missing_teeth_count == 0 ~ "0", missing_teeth_count <= 5 ~ "1-5", TRUE ~ ">=6"), levels = c("0", "1-5", ">=6")),
  implant_group = factor(ifelse(implant_count == 0, "0", ">=1"), levels = c("0", ">=1"))
)
main_design <- design_of(main)

continuous_main <- c("age", "bmi", "floss_days", "mouthwash_days", "missing_teeth_count", "implant_count", nutrition, "vitd_nmol")
categorical_main <- c("sex", "race", "education", "marital", "pir_cat", "smoking", "alcohol", "physical_activity", "diabetes", "hypertension", "cvd", "ckd", "liver", "thyroid")
baseline_table <- function(d, des, group, cont, cat, title) {
  glevels <- levels(droplevels(factor(d[[group]])))
  scalar_prop <- function(design, v, lv) {
    quoted_lv <- paste0("'", gsub("'", "\\\\'", lv), "'")
    ff <- as.formula(paste0("~I(as.numeric(", v, "==", quoted_lv, "))"))
    tryCatch(as.numeric(coef(svymean(ff, design, na.rm = TRUE))[1]) * 100, error = function(e) NA_real_)
  }
  cont_rows <- map_dfr(cont, function(v) {
    f <- as.formula(paste0("~", v))
    by <- tryCatch(svyby(f, as.formula(paste0("~", group)), des, svymean, na.rm = TRUE, vartype = "se", keep.names = FALSE), error = function(e) NULL)
    ov <- svymean(f, des, na.rm = TRUE)
    p <- tryCatch(safe_regp(svyglm(as.formula(paste0(v, "~", group)), des), group), error = function(e) NA_real_)
    vals <- setNames(rep("", length(glevels)), glevels)
    if (!is.null(by)) {
      se_col <- if (paste0("se.", v) %in% names(by)) paste0("se.", v) else "se"
      for (i in seq_len(nrow(by))) vals[as.character(by[[group]][i])] <- sprintf("%.2f +/- %.2f", by[[v]][i], by[[se_col]][i])
    }
    tibble(Variable = lab(v), Level = "Weighted mean +/- SE", Overall = sprintf("%.2f +/- %.2f", coef(ov)[1], SE(ov)[1]), !!!as.list(vals), P = p_fmt(p), row_type = "continuous")
  })
  cat_rows <- map_dfr(cat, function(v) {
    lev <- levels(droplevels(factor(d[[v]])))
    p <- tryCatch(as.numeric(svychisq(as.formula(paste0("~", v, "+", group)), des, statistic = "F")$p.value), error = function(e) NA_real_)
    map_dfr(seq_along(lev), function(j) {
      lv <- lev[j]; vals <- setNames(rep("", length(glevels)), glevels)
      for (g in glevels) {
        idx <- as.character(d[[group]]) == g
        n <- sum(idx & as.character(d[[v]]) == lv, na.rm = TRUE)
        dd <- subset(des, get(group) == g)
        vals[g] <- sprintf("%d (%.1f%%)", n, scalar_prop(dd, v, lv))
      }
      n0 <- sum(as.character(d[[v]]) == lv, na.rm = TRUE)
      tibble(Variable = if (j == 1) lab(v) else "", Level = lv, Overall = sprintf("%d (%.1f%%)", n0, scalar_prop(des, v, lv)), !!!as.list(vals), P = if (j == 1) p_fmt(p) else "", row_type = "categorical")
    })
  })
  bind_rows(cont_rows, cat_rows) |> mutate(Table = title, .before = 1)
}

b1 <- baseline_table(main, main_design, "periodontitis", continuous_main, categorical_main, "NHANES 2009-2014 by periodontitis")
b2 <- baseline_table(main, main_design, "vitd_cat", setdiff(continuous_main, "vitd_nmol"), c("periodontitis", categorical_main), "NHANES 2009-2014 by vitamin D three categories")
write_bom(b1, file.path(dirs$step7, "01_NHANES2009-2014_\u6309\u7259\u5468\u708eYesNo\u52a0\u6743\u57fa\u7ebf\u8868.csv"))
write_bom(b2, file.path(dirs$step7, "03_NHANES2009-2014_\u6309\u7ef4\u751f\u7d20D\u4e09\u5206\u7c7b\u52a0\u6743\u57fa\u7ebf\u8868.csv"))

baseline_pct_check <- function(tbl) {
  value_cols <- setdiff(names(tbl), c("Table", "Variable", "Level", "P", "row_type"))
  sums <- tbl |> filter(row_type == "categorical") |> mutate(Variable = na_if(Variable, "")) |> fill(Variable) |>
    mutate(across(all_of(value_cols), ~as.numeric(str_match(.x, "\\(([0-9.]+)%\\)")[, 2]))) |>
    group_by(Variable) |> summarise(across(all_of(value_cols), ~sum(.x, na.rm = TRUE)), .groups = "drop")
  all(abs(unlist(sums[value_cols]) - 100) <= 0.2)
}
baseline_pct_ok <- all(vapply(list(b1, b2), baseline_pct_check, logical(1)))

extract_term <- function(fit, term, contrast, type, model) {
  co <- coef(fit); vv <- vcov(fit)
  if (!term %in% names(co)) return(tibble(cohort = "NHANES 2009-2014", model, exposure_type = type, contrast, OR = NA_real_, CI_lower = NA_real_, CI_upper = NA_real_, P = NA_real_))
  b <- co[[term]]; se <- sqrt(vv[term, term])
  tibble(cohort = "NHANES 2009-2014", model, exposure_type = type, contrast, OR = exp(b), CI_lower = exp(b - 1.96 * se), CI_upper = exp(b + 1.96 * se), P = 2 * pnorm(-abs(b / se)))
}
exposure_levels <- setdiff(vitd_levels, vitd_reference)
contrast_lookup <- setNames(paste(exposure_levels, "vs", vitd_reference), exposure_levels)
effects <- imap_dfr(models_main, function(covs, mn) {
  fcat <- svyglm(as.formula(paste("periodontitis_bin~", paste(c("vitd_cat", covs), collapse = "+"))), main_design, family = quasibinomial())
  cat_rows <- map_dfr(exposure_levels, function(lv) extract_term(fcat, paste0("vitd_cat", lv), contrast_lookup[[lv]], "Three-category", mn))
  fcon <- svyglm(as.formula(paste("periodontitis_bin~", paste(c("vitd_per10", covs), collapse = "+"))), main_design, family = quasibinomial())
  bind_rows(cat_rows, extract_term(fcon, "vitd_per10", "Per 10 nmol/L increase", "Continuous", mn))
}) |> mutate(`OR (95% CI)` = or_fmt(OR, CI_lower, CI_upper), `P value` = p_fmt(P))
write_bom(effects, file.path(dirs$step9, "01_NHANES2009-2014_\u7ef4\u751f\u7d20D\u4e09\u5206\u7c7b\u53ca\u8fde\u7eed\u53d8\u91cfModel1\u81f33_OR95CI.csv"))
model_defs <- tibble(
  cohort = "NHANES 2009-2014", model = names(models_main),
  covariates = vapply(models_main, function(x) if (length(x)) paste(x, collapse = ", ") else "Unadjusted", character(1)),
  adjusted_variables = vapply(models_main, function(x) if (length(x)) paste(vapply(x, lab, character(1)), collapse = ", ") else "Unadjusted", character(1)),
  covariate_n = vapply(models_main, length, integer(1))
)
write_bom(model_defs, file.path(dirs$step9, "02_Model1\u81f33\u7cbe\u786e\u8c03\u6574\u53d8\u91cf.csv"))

pf <- effects |> filter(exposure_type != "Continuous") |> mutate(label = factor(paste(model, contrast, sep = " - "), levels = rev(unique(paste(model, contrast, sep = " - ")))))
p_main <- ggplot(pf, aes(OR, label)) + geom_vline(xintercept = 1, lty = 2, colour = "grey55") +
  geom_errorbarh(aes(xmin = CI_lower, xmax = CI_upper), height = .16, colour = "#1769AA") + geom_point(size = 2.5, colour = "#1769AA") +
  scale_x_log10() + labs(title = "Serum 25(OH)D and moderate/severe periodontitis", subtitle = paste("Survey-weighted logistic regression; reference:", vitd_reference), x = "Odds ratio (log scale)", y = NULL) + theme_classic(base_size = 12) + theme(plot.title = element_text(face = "bold"))
save_plot(p_main, dirs$step9, "03_NHANES2009-2014_Model1\u81f33\u4e3b\u6548\u5e94\u68ee\u6797\u56fe", 10.5, 6.5)

subgroups <- c("floss_group", "mouthwash_group", "missing_teeth_group", "implant_group", clinical_behavioral, "sex", "bmi_cat", "age_group", "education", "marital", "pir_cat", "race")
counterpart <- c(floss_group = "floss_days", mouthwash_group = "mouthwash_days", missing_teeth_group = "missing_teeth_count", implant_group = "implant_count", bmi_cat = "bmi", age_group = "age")
fit_subgroups <- function(d, des, sets, sgs) {
  imap_dfr(sets, function(covs, mn) map_dfr(sgs, function(sg) {
    remove_var <- if (sg %in% names(counterpart)) counterpart[[sg]] else sg
    cov_use <- setdiff(covs, remove_var)
    interfit <- tryCatch(svyglm(as.formula(paste("periodontitis_bin~", paste(c(paste0("vitd_cat*", sg), cov_use), collapse = "+"))), des, family = quasibinomial()), error = function(e) NULL)
    pint <- if (is.null(interfit)) NA_real_ else safe_regp(interfit, paste0("vitd_cat:", sg))
    levs <- levels(droplevels(factor(d[[sg]])))
    map_dfr(levs, function(lv) {
      subdes <- subset(des, as.character(get(sg)) == lv); n <- sum(as.character(d[[sg]]) == lv, na.rm = TRUE)
      fit <- tryCatch(svyglm(as.formula(paste("periodontitis_bin~", paste(c("vitd_cat", cov_use), collapse = "+"))), subdes, family = quasibinomial()), error = function(e) NULL)
      if (is.null(fit)) return(tibble(cohort = "NHANES 2009-2014", model = mn, variable = sg, variable_label = lab(sg), subgroup = lv, N = n, contrast = unname(contrast_lookup), OR = NA_real_, CI_lower = NA_real_, CI_upper = NA_real_, P = NA_real_, P_interaction = pint))
      map_dfr(exposure_levels, function(exposure_level) extract_term(fit, paste0("vitd_cat", exposure_level), contrast_lookup[[exposure_level]], "Subgroup", mn)) |>
        transmute(cohort, model = mn, variable = sg, variable_label = lab(sg), subgroup = lv, N = n, contrast, OR, CI_lower, CI_upper, P, P_interaction = pint)
    })
  }))
}
subgroup_cell_min <- function(d, sg, lv, contrast) {
  exposure_level <- names(contrast_lookup)[match(contrast, unname(contrast_lookup))]
  z <- d[as.character(d[[sg]]) == lv & as.character(d$vitd_cat) %in% c(exposure_level, vitd_reference), c("vitd_cat", "periodontitis_bin")]
  tab <- table(factor(z$vitd_cat, levels = c(exposure_level, vitd_reference)), factor(z$periodontitis_bin, levels = c(0, 1)))
  min(tab)
}
subres_raw <- fit_subgroups(main, main_design, models_main, subgroups)
subres <- subres_raw |> rowwise() |> mutate(
  min_2x2_cell_n = subgroup_cell_min(main, variable, subgroup, contrast),
  log_or_se = ifelse(is.finite(CI_lower) & is.finite(CI_upper) & CI_lower > 0 & CI_upper > 0, (log(CI_upper) - log(CI_lower)) / (2 * 1.96), NA_real_),
  estimability = ifelse(min_2x2_cell_n < 5 | !is.finite(OR) | !is.finite(CI_lower) | !is.finite(CI_upper) | OR <= 0 | CI_lower <= 0 | log_or_se > 2 | OR > 100 | OR < 0.01 | CI_upper > 1000 | CI_lower < 0.001, "Not estimable: sparse/unstable subgroup fit", "Estimable")
) |> ungroup()
write_bom(subres |> mutate(`OR (95% CI)` = ifelse(estimability == "Estimable", or_fmt(OR, CI_lower, CI_upper), "Not estimable"), `P value` = ifelse(estimability == "Estimable", p_fmt(P), ""), `P interaction` = p_fmt(P_interaction)), file.path(dirs$step10, "01_NHANES2009-2014_\u7ef4\u751f\u7d20D\u4e09\u5206\u7c7b_\u5168\u90e820\u9879\u4e9a\u7ec4\u4e0e\u4ea4\u4e92.csv"))
write_bom(subres_raw, file.path(dirs$step10, "02_\u4e9a\u7ec4\u539f\u59cb\u6a21\u578b\u4f30\u8ba1_\u4ec5\u4f9b\u5ba1\u8ba1.csv"))

seven_col_plot <- function(dat, model_value, contrast_value) {
  x <- dat |> filter(model == model_value, contrast == contrast_value)
  ord <- unique(x$variable)
  blocks <- map_dfr(seq_along(ord), function(i) {
    v <- ord[i]; b <- x |> filter(variable == v)
    bind_rows(tibble(variable = v, variable_label = unique(b$variable_label)[1], subgroup = "", N = NA_integer_, OR = NA_real_, CI_lower = NA_real_, CI_upper = NA_real_, P = NA_real_, P_interaction = unique(b$P_interaction)[1], estimability = NA_character_, header = TRUE, block = i), b |> mutate(header = FALSE, block = i))
  }) |> mutate(
    row = rev(row_number()), fill = ifelse(block %% 2, "#D4D9DD", "#EEF1F4"), point_col = ifelse(block %% 2, "#111111", "#2E75B6"),
    or_text = case_when(header ~ "", estimability != "Estimable" ~ "Not estimable", TRUE ~ or_fmt(OR, CI_lower, CI_upper)),
    p_text = case_when(header ~ "", estimability != "Estimable" ~ "", TRUE ~ p_fmt(P)), pi_text = ifelse(header, p_fmt(P_interaction), ""),
    var_text = ifelse(header, variable_label, ""), sub_text = ifelse(header, "", subgroup), n_text = ifelse(header, "", as.character(N))
  )
  plot_rows <- filter(blocks, !header, estimability == "Estimable", is.finite(OR))
  xr <- range(c(plot_rows$CI_lower, plot_rows$CI_upper), na.rm = TRUE); xr <- c(max(.1, min(.5, xr[1])), min(8, max(2, xr[2])))
  forest <- ggplot(blocks, aes(y = row)) + geom_rect(aes(xmin = -Inf, xmax = Inf, ymin = row - .5, ymax = row + .5, fill = fill), show.legend = FALSE) + scale_fill_identity() + geom_vline(xintercept = 1, colour = "grey45") + geom_errorbarh(data = plot_rows, aes(xmin = CI_lower, xmax = CI_upper, colour = point_col), height = .15, linewidth = .55) + geom_point(data = plot_rows, aes(x = OR, colour = point_col), size = 2.2) + scale_colour_identity() + scale_x_log10(limits = xr) + scale_y_continuous(NULL, breaks = NULL) + labs(x = "Stratification analysis") + theme_classic(base_size = 11) + theme(axis.line.y = element_blank(), plot.margin = margin(5, 2, 5, 2))
  left <- ggplot(blocks, aes(y = row)) + geom_rect(aes(xmin = 0, xmax = 1, ymin = row - .5, ymax = row + .5, fill = fill), show.legend = FALSE) + scale_fill_identity() + geom_text(aes(x = .01, label = var_text), hjust = 0, fontface = ifelse(blocks$header, "bold", "plain"), size = 3.4) + geom_text(aes(x = .38, label = sub_text), hjust = 0, size = 3.25) + geom_text(aes(x = .96, label = n_text), hjust = 1, size = 3.25) + annotate("text", x = c(.01, .38, .96), y = max(blocks$row) + 1.1, label = c("Variables", "Subgroup", "N"), hjust = c(0, 0, 1), fontface = "bold", size = 3.7) + coord_cartesian(xlim = c(0, 1), ylim = c(min(blocks$row) - .5, max(blocks$row) + 1.6), clip = "off") + theme_void() + theme(plot.margin = margin(5, 2, 5, 5))
  right <- ggplot(blocks, aes(y = row)) + geom_rect(aes(xmin = 0, xmax = .74, ymin = row - .5, ymax = row + .5, fill = fill), show.legend = FALSE) + geom_rect(data = filter(blocks, header), aes(xmin = .76, xmax = 1, ymin = row - .5, ymax = row + .5), fill = "#C9C7E8", inherit.aes = FALSE) + scale_fill_identity() + geom_text(aes(x = .01, label = or_text), hjust = 0, size = 3.2) + geom_text(aes(x = .58, label = p_text), hjust = .5, size = 3.2) + geom_text(aes(x = .88, label = pi_text), fontface = ifelse(blocks$header, "bold", "plain"), size = 3.2) + annotate("text", x = c(.01, .58, .88), y = max(blocks$row) + 1.1, label = c("OR (95% CI)", "P", "P interaction"), hjust = c(0, .5, .5), fontface = "bold", size = 3.7) + coord_cartesian(xlim = c(0, 1), ylim = c(min(blocks$row) - .5, max(blocks$row) + 1.6), clip = "off") + theme_void() + theme(plot.margin = margin(5, 5, 5, 2))
  (left + forest + right + plot_layout(widths = c(2.4, 2.2, 2.2))) + plot_annotation(title = paste("NHANES 2009-2014", model_value, contrast_value, sep = " - "), subtitle = "Moderate/severe periodontitis; survey-weighted logistic regression", theme = theme(plot.title = element_text(face = "bold", size = 15), plot.subtitle = element_text(size = 11)))
}
for (mn in c("Model 1", "Model 2", "Model 3")) for (ct in unname(contrast_lookup)) {
  pp <- seven_col_plot(subres, mn, ct)
  stem <- paste0("NHANES2009-2014_", str_replace_all(mn, " ", ""), "_", str_replace_all(ct, c("<" = "\u5c0f\u4e8e", ">=" = "\u5927\u4e8e\u7b49\u4e8e", " " = "", "/" = "_")), "_\u4e03\u680f\u4e9a\u7ec4\u68ee\u6797\u56fe")
  save_plot(pp, dirs$step10, stem, 15, 18)
}

wq <- function(x, w, p) { o <- order(x); x <- x[o]; w <- w[o]; approx(cumsum(w) / sum(w), x, xout = p, rule = 2, ties = "ordered")$y }
fit_rcs <- function(d, mn, covs) {
  kn <- wq(d$vitd_nmol, d$analysis_weight, c(.05, .35, .65, .95))
  B <- Hmisc::rcspline.eval(d$vitd_nmol, knots = kn, inclx = TRUE); colnames(B) <- paste0("rcs", seq_len(ncol(B)))
  dd <- bind_cols(d, as.data.frame(B)); des <- design_of(dd); terms <- colnames(B)
  fit <- svyglm(as.formula(paste("periodontitis_bin~", paste(c(terms, covs), collapse = "+"))), des, family = quasibinomial())
  pall <- safe_regp(fit, paste(terms, collapse = "+")); pnl <- safe_regp(fit, paste(terms[-1], collapse = "+"))
  grid <- seq(max(min(d$vitd_nmol), wq(d$vitd_nmol, d$analysis_weight, .01)), min(max(d$vitd_nmol), wq(d$vitd_nmol, d$analysis_weight, .99)), length.out = 220)
  G <- Hmisc::rcspline.eval(grid, knots = kn, inclx = TRUE); ref <- wq(d$vitd_nmol, d$analysis_weight, .5); R <- Hmisc::rcspline.eval(ref, knots = kn, inclx = TRUE)
  D <- sweep(G, 2, R); be <- coef(fit)[terms]; V <- vcov(fit)[terms, terms, drop = FALSE]
  eta <- drop(D %*% be); se <- sqrt(rowSums((D %*% V) * D)); cur <- tibble(vitd_nmol = grid, OR = exp(eta), lower = exp(eta - 1.96 * se), upper = exp(eta + 1.96 * se))
  p <- ggplot(cur, aes(vitd_nmol, OR)) + geom_ribbon(aes(ymin = lower, ymax = upper), fill = "#B7D8D4", alpha = .55) + geom_line(colour = "#155D59", linewidth = 1.1) + geom_hline(yintercept = 1, lty = 2, colour = "grey45") + geom_vline(xintercept = ref, lty = 3, colour = "#E67E22") + annotate("text", x = Inf, y = Inf, label = paste0("P for nonlinearity = ", p_fmt(pnl)), hjust = 1.05, vjust = 1.25, size = 5.0) + labs(title = NULL, subtitle = NULL, x = "Serum 25(OH)D (nmol/L)", y = "Odds ratio") + theme_classic(base_size = 14)
  list(summary = tibble(cohort = "NHANES 2009-2014", model = mn, knot_p5 = kn[1], knot_p35 = kn[2], knot_p65 = kn[3], knot_p95 = kn[4], reference_median = ref, P_overall = pall, P_nonlinear = pnl, interpretation = ifelse(pnl < .05, "Evidence of nonlinearity; segmented regression indicated", "No evidence of nonlinearity")), curve = cur |> mutate(cohort = "NHANES 2009-2014", model = mn), plot = p)
}
rcs_results <- imap(models_main, ~fit_rcs(main, .y, .x))
iwalk(rcs_results, ~save_plot(.x$plot, dirs$rcs, paste0("NHANES2009-2014_", str_replace_all(.y, " ", ""), "_RCS"), 9.5, 6.5))
write_bom(bind_rows(map(rcs_results, "summary")), file.path(dirs$rcs, "01_NHANES2009-2014_Model1\u81f33_RCS\u603b\u4f53\u4e0e\u975e\u7ebf\u6027P\u503c.csv"))
write_bom(bind_rows(map(rcs_results, "curve")), file.path(dirs$rcs, "02_NHANES2009-2014_Model1\u81f33_RCS\u66f2\u7ebf\u6570\u636e.csv"))

qa <- tribble(
  ~check, ~passed, ~detail,
  "Main complete-case N", nrow(main) == 2698L, paste(nrow(main)),
  "Vitamin D has exactly 3 categories", nlevels(droplevels(main$vitd_cat)) == 3L, paste(levels(main$vitd_cat), collapse = " | "),
  "Model 2 has exactly 20 requested covariates", length(models_main[["Model 2"]]) == 20L, paste(models_main[["Model 2"]], collapse = ", "),
  "Model 3 has exactly 28 requested covariates", length(models_main[["Model 3"]]) == 28L, paste(models_main[["Model 3"]], collapse = ", "),
  "All main-effect rows present", nrow(effects) == 9L, paste(nrow(effects), "rows"),
  "All 20 non-nutritional covariates used for subgrouping", length(unique(subres$variable)) == 20L, paste(length(unique(subres$variable)), "variables"),
  "Categorical weighted percentages sum to 100%", baseline_pct_ok, "Checked across both baseline tables",
  "PIR categories use <1, 1-3.5, >3.5", identical(levels(main$pir_cat), pir_levels_expected), paste(pir_levels_expected, collapse = " | "),
  "No unrequested variables in baseline or models", !any(c(categorical_main, continuous_main, model3_covariates) %in% c("untreated_caries", "sleep_hours", "arthritis", "gout", "dental_visit")), "Untreated caries, sleep, arthritis, gout and dental visit absent"
)
write_bom(qa, file.path(dirs$qa, "02_\u590d\u6742\u62bd\u6837\u5206\u6790\u81ea\u52a8\u8d28\u91cf\u6838\u9a8c.csv"))
writeLines(capture.output(sessionInfo()), file.path(dirs$qa, "02_sessionInfo_\u590d\u6742\u62bd\u6837\u5206\u6790.txt"), useBytes = TRUE)
if (!all(qa$passed)) stop("\u590d\u6742\u62bd\u6837\u5206\u6790\u8d28\u91cf\u6838\u9a8c\u672a\u5168\u90e8\u901a\u8fc7\u3002", call. = FALSE)
cat("Strict survey-weighted baseline, Models 1-3, 20 subgroup variables and RCS complete. N=", nrow(main), "\n")
