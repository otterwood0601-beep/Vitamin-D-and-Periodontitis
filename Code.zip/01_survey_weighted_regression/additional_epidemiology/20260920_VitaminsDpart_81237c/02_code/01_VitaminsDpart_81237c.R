options(stringsAsFactors = FALSE, survey.lonely.psu = "adjust")
suppressPackageStartupMessages({
  library(haven)
  library(dplyr)
  library(tidyr)
  library(purrr)
  library(readr)
  library(tibble)
  library(survey)
  library(Hmisc)
  library(ggplot2)
  library(scales)
})

cmd_file <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (!length(cmd_file)) stop("\u8bf7\u4f7f\u7528 Rscript \u8fd0\u884c\u672c\u6587\u4ef6\u3002", call. = FALSE)
script_file <- normalizePath(sub("^--file=", "", cmd_file[[1]]), winslash = "/", mustWork = TRUE)
analysis_root <- dirname(dirname(script_file))
raw_dir <- file.path(analysis_root, "01_\u5b98\u65b9\u539f\u59cb\u6587\u4ef6")
result_dir <- file.path(analysis_root, "03_\u7ed3\u679c")
figure_dir <- file.path(analysis_root, "04_\u56fe")
audit_dir <- file.path(analysis_root, "05_\u5ba1\u8ba1")
invisible(lapply(c(result_dir, figure_dir, audit_dir), dir.create, recursive = TRUE, showWarnings = FALSE))

source_rds <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/01-02_\u6b63\u6587\u56fe1-2_\u903b\u8f91\u56de\u5f52\u4e0e\u673a\u5668\u5b66\u4e60/",
  "20260802_\u4e25\u683c\u53d8\u91cf_\u6700\u7ec8/\u7b2c1\u6b65_\u6570\u636e\u8bfb\u53d6\u4e0b\u8f7d\u4e0e\u5468\u671f\u5408\u5e76/",
  "01_NHANES2009-2014_\u6392\u9664\u524d\u4e25\u683c\u6d3e\u751f\u6570\u636e.rds"
)
if (!file.exists(source_rds)) stop("\u7f3a\u5c11\u6392\u9664\u524d\u4e25\u683c\u6d3e\u751f\u6570\u636e\u96c6\u3002", call. = FALSE)

write_bom <- function(x, path) readr::write_excel_csv(x, path, na = "")
p_fmt <- function(x) ifelse(is.na(x), "", ifelse(x < 0.001, "<0.001", sprintf("%.3f", x)))
or_fmt <- function(or, lo, hi) sprintf("%.3f (%.3f-%.3f)", or, lo, hi)
wq <- function(x, w, probs) {
  keep <- is.finite(x) & is.finite(w) & w > 0
  x <- x[keep]
  w <- w[keep]
  o <- order(x)
  x <- x[o]
  w <- w[o]
  approx(cumsum(w) / sum(w), x, xout = probs, rule = 2, ties = "ordered")$y
}
design_of <- function(d) {
  svydesign(ids = ~psu_pool, strata = ~strata_pool, weights = ~analysis_weight,
            nest = TRUE, data = d)
}
safe_regp <- function(model, terms) {
  f <- as.formula(paste0("~", paste(terms, collapse = "+")))
  tryCatch(as.numeric(regTermTest(model, f)$p), error = function(e) NA_real_)
}

cycle_map <- c(F = "2009-2010", G = "2011-2012", H = "2013-2014")
read_supplement_cycle <- function(suffix) {
  path <- file.path(raw_dir, paste0("DSQTOT_", suffix, ".XPT"))
  if (!file.exists(path)) stop("\u7f3a\u5c11\u5b98\u65b9\u8865\u5145\u5242\u6587\u4ef6\uff1a", basename(path), call. = FALSE)
  read_xpt(path, col_select = c(SEQN, DSD010, DSDCOUNT, DSQTVD)) |>
    transmute(
      SEQN = as.numeric(SEQN),
      cycle = unname(cycle_map[[suffix]]),
      supplement_file_record = TRUE,
      any_supplement_code = as.numeric(DSD010),
      supplement_count = as.numeric(DSDCOUNT),
      vitd_supp_ug = case_when(
        any_supplement_code %in% c(1, 2) & is.finite(as.numeric(DSQTVD)) ~ as.numeric(DSQTVD),
        any_supplement_code %in% c(1, 2) & is.na(DSQTVD) ~ 0,
        TRUE ~ NA_real_
      )
    )
}

supp <- map_dfr(names(cycle_map), read_supplement_cycle)
if (anyDuplicated(supp[c("SEQN", "cycle")])) stop("\u8865\u5145\u5242\u6587\u4ef6\u5b58\u5728\u91cd\u590d SEQN-cycle\u3002", call. = FALSE)

main0 <- readRDS(source_rds)
merged <- main0 |>
  left_join(supp, by = c("SEQN", "cycle")) |>
  mutate(
    vitd_supp_per10 = vitd_supp_ug / 10,
    vitd_supp_user = as.integer(vitd_supp_ug > 0),
    log2_vitd_supp_plus1 = log2(vitd_supp_ug + 1)
  )

oral_covariates <- c("floss_days", "mouthwash_days", "missing_teeth_count", "implant_count")
clinical_behavioral <- c("smoking", "alcohol", "physical_activity", "diabetes", "hypertension", "cvd", "ckd", "liver", "thyroid")
demographic <- c("sex", "bmi", "age", "education", "marital", "pir_cat", "race")
nutrition <- c("energy_kcal", "sugar_g", "cholesterol_mg", "fat_g", "fiber_g", "protein_g", "calcium_mg", "phosphorus_mg")
model2_covariates <- c(oral_covariates, clinical_behavioral, demographic)
model3_covariates <- c(model2_covariates, nutrition)
models <- list(`Model 1` = character(), `Model 2` = model2_covariates, `Model 3` = model3_covariates)
stopifnot(length(model2_covariates) == 20L, length(model3_covariates) == 28L)

design_variables <- c("analysis_weight", "strata_pool", "psu_pool")
required <- unique(c("periodontitis_bin", model3_covariates, design_variables, "vitd_supp_ug"))
d_age <- merged |> filter(is.finite(age) & age >= 60)
d_outcome <- d_age |> filter(!is.na(periodontitis), periodontitis_bin %in% c(0, 1))
d_exposure <- d_outcome |> filter(!is.na(vitd_supp_ug))
complete_ok <- complete.cases(d_exposure[, required, drop = FALSE]) &
  is.finite(d_exposure$analysis_weight) & d_exposure$analysis_weight > 0
main <- droplevels(d_exposure[complete_ok, , drop = FALSE])
flow <- tibble(
  step_order = 0:4,
  step = c(
    "Merged NHANES 2009-2014 participants",
    "Age >=60 years",
    "Periodontal outcome available",
    "Valid supplement vitamin D exposure",
    "Complete Model 3 covariates and survey-design variables"
  ),
  remaining_n = c(nrow(merged), nrow(d_age), nrow(d_outcome), nrow(d_exposure), nrow(main)),
  removed_from_previous = c(0L, nrow(merged) - nrow(d_age), nrow(d_age) - nrow(d_outcome),
                            nrow(d_outcome) - nrow(d_exposure), nrow(d_exposure) - nrow(main))
)
main_design <- design_of(main)

extract_exposure <- function(fit, term, model, analysis, exposure_scale, n) {
  co <- coef(fit)
  vv <- vcov(fit)
  if (!term %in% names(co)) {
    return(tibble(model, analysis, exposure_scale, N = n, beta = NA_real_, SE = NA_real_,
                  OR = NA_real_, CI_lower = NA_real_, CI_upper = NA_real_, P = NA_real_))
  }
  b <- unname(co[[term]])
  se <- sqrt(vv[term, term])
  tibble(
    model, analysis, exposure_scale, N = n, beta = b, SE = se,
    OR = exp(b), CI_lower = exp(b - 1.96 * se), CI_upper = exp(b + 1.96 * se),
    P = 2 * pnorm(-abs(b / se))
  )
}

fit_linear <- function(design, model_name, covariates, exposure = "vitd_supp_per10",
                       analysis = "Primary: all valid participants",
                       exposure_scale = "Per 10 ug/day (400 IU/day)") {
  f <- as.formula(paste("periodontitis_bin~", paste(c(exposure, covariates), collapse = "+")))
  fit <- svyglm(f, design = design, family = quasibinomial())
  extract_exposure(fit, exposure, model_name, analysis, exposure_scale, nrow(model.frame(fit)))
}

linear_results <- imap_dfr(models, ~fit_linear(main_design, .y, .x)) |>
  mutate(`OR (95% CI)` = or_fmt(OR, CI_lower, CI_upper), `P value` = p_fmt(P))
write_bom(linear_results, file.path(result_dir, "01_\u8fde\u7eed\u5173\u8054_Model1\u81f33.csv"))

supp_user_est <- svymean(~vitd_supp_user, main_design, na.rm = TRUE)
weighted_mean_est <- svymean(~vitd_supp_ug, main_design, na.rm = TRUE)
all_probs <- c(0, .05, .25, .35, .50, .65, .75, .90, .95, .975, .99, 1)
all_quantiles <- wq(main$vitd_supp_ug, main$analysis_weight, all_probs)
positive <- main$vitd_supp_ug > 0
positive_probs <- c(0, .05, .25, .50, .75, .90, .95, .975, .99, 1)
positive_quantiles <- wq(main$vitd_supp_ug[positive], main$analysis_weight[positive], positive_probs)

descriptive <- bind_rows(
  tibble(metric = c("Source merged N", "Supplement-specific complete-case N", "Zero intake N", "Positive intake N"),
         value = c(nrow(main0), nrow(main), sum(main$vitd_supp_ug == 0), sum(main$vitd_supp_ug > 0)), unit = "participants"),
  tibble(metric = c("Weighted supplement vitamin D user prevalence", "Weighted mean supplement vitamin D intake"),
         value = c(coef(supp_user_est)[[1]], coef(weighted_mean_est)[[1]]), unit = c("proportion", "ug/day")),
  tibble(metric = paste0("Weighted quantile all: P", 100 * all_probs), value = all_quantiles, unit = "ug/day"),
  tibble(metric = paste0("Weighted quantile positive users: P", 100 * positive_probs), value = positive_quantiles, unit = "ug/day")
)
write_bom(descriptive, file.path(result_dir, "02_\u8865\u5145\u5242\u7ef4\u751f\u7d20D\u5206\u5e03\u4e0e\u96f6\u503c\u5ba1\u8ba1.csv"))

standard_probs <- c(.05, .35, .65, .95)
standard_knots <- wq(main$vitd_supp_ug, main$analysis_weight, standard_probs)
adaptive_probs <- c(0, .50, .75, .95)
adaptive_knots <- c(0, wq(main$vitd_supp_ug, main$analysis_weight, adaptive_probs[-1]))
if (length(unique(round(adaptive_knots, 10))) != 4L) stop("\u81ea\u9002\u5e94RCS\u8282\u70b9\u4e0d\u552f\u4e00\u3002", call. = FALSE)

fit_rcs <- function(d, model_name, covariates, knots = adaptive_knots,
                    analysis = "Primary: all valid participants") {
  B <- Hmisc::rcspline.eval(d$vitd_supp_ug, knots = knots, inclx = TRUE)
  colnames(B) <- paste0("rcs", seq_len(ncol(B)))
  dd <- bind_cols(d, as.data.frame(B))
  des <- design_of(dd)
  terms <- colnames(B)
  f <- as.formula(paste("periodontitis_bin~", paste(c(terms, covariates), collapse = "+")))
  fit <- svyglm(f, design = des, family = quasibinomial())
  p_overall <- safe_regp(fit, terms)
  p_nonlinear <- safe_regp(fit, terms[-1])

  upper <- wq(d$vitd_supp_ug, d$analysis_weight, .99)
  grid <- sort(unique(c(seq(0, upper, length.out = 260), knots[knots <= upper])))
  G <- Hmisc::rcspline.eval(grid, knots = knots, inclx = TRUE)
  R <- Hmisc::rcspline.eval(0, knots = knots, inclx = TRUE)
  D <- sweep(G, 2, R)
  be <- coef(fit)[terms]
  V <- vcov(fit)[terms, terms, drop = FALSE]
  eta <- drop(D %*% be)
  se <- sqrt(rowSums((D %*% V) * D))
  curve <- tibble(
    model = model_name, analysis, vitd_supp_ug = grid,
    OR = exp(eta), CI_lower = exp(eta - 1.96 * se), CI_upper = exp(eta + 1.96 * se)
  )
  summary <- tibble(
    model = model_name, analysis, N = nrow(d), reference_ug_day = 0,
    knot_1 = knots[1], knot_2 = knots[2], knot_3 = knots[3], knot_4 = knots[4],
    curve_upper_display_p99 = upper, P_overall = p_overall, P_nonlinear = p_nonlinear,
    nonlinearity_conclusion = ifelse(is.finite(p_nonlinear) & p_nonlinear < .05,
                                     "Supports nonlinearity", "Does not support nonlinearity")
  )
  list(fit = fit, curve = curve, summary = summary)
}

rcs_results <- imap(models, ~fit_rcs(main, .y, .x))
rcs_summary <- bind_rows(map(rcs_results, "summary")) |>
  mutate(`P overall` = p_fmt(P_overall), `P nonlinearity` = p_fmt(P_nonlinear))
rcs_curve <- bind_rows(map(rcs_results, "curve"))
write_bom(rcs_summary, file.path(result_dir, "03_RCS_Model1\u81f33_\u603b\u4f53\u4e0e\u975e\u7ebf\u6027P\u503c.csv"))
write_bom(rcs_curve, file.path(result_dir, "04_RCS_Model1\u81f33_\u66f2\u7ebf\u6570\u636e.csv"))

p99 <- unname(wq(main$vitd_supp_ug, main$analysis_weight, .99))
design_p99 <- subset(main_design, vitd_supp_ug <= p99)
design_users <- subset(main_design, vitd_supp_ug > 0)
design_serum_available <- subset(main_design, is.finite(vitd_nmol))
sensitivity_linear <- bind_rows(
  fit_linear(design_p99, "Model 3", model3_covariates,
             analysis = "Sensitivity: intake <= weighted P99",
             exposure_scale = "Per 10 ug/day (400 IU/day)"),
  fit_linear(design_users, "Model 3", model3_covariates,
             analysis = "Sensitivity: positive-dose users only",
             exposure_scale = "Per 10 ug/day (400 IU/day)"),
  fit_linear(main_design, "Model 3", model3_covariates, exposure = "log2_vitd_supp_plus1",
             analysis = "Sensitivity: log2(intake+1)",
             exposure_scale = "Per doubling of (intake+1)"),
  fit_linear(main_design, "Model 3", model3_covariates, exposure = "vitd_supp_user",
             analysis = "Sensitivity: any intake versus zero",
             exposure_scale = "Any intake vs zero"),
  fit_linear(design_serum_available, "Model 3", model3_covariates,
             analysis = "Sensitivity: serum 25(OH)D available cohort",
             exposure_scale = "Per 10 ug/day (400 IU/day)")
) |>
  mutate(`OR (95% CI)` = or_fmt(OR, CI_lower, CI_upper), `P value` = p_fmt(P))

trimmed <- main |> filter(vitd_supp_ug <= p99)
trimmed_knots <- c(0, wq(trimmed$vitd_supp_ug, trimmed$analysis_weight, c(.50, .75, .95)))
if (length(unique(round(trimmed_knots, 10))) != 4L) trimmed_knots <- adaptive_knots
rcs_trimmed <- fit_rcs(trimmed, "Model 3", model3_covariates, knots = trimmed_knots,
                       analysis = "Sensitivity: intake <= weighted P99")
sensitivity_rcs <- rcs_trimmed$summary |>
  mutate(`P overall` = p_fmt(P_overall), `P nonlinearity` = p_fmt(P_nonlinear))
write_bom(sensitivity_linear, file.path(result_dir, "05_\u7ebf\u6027\u654f\u611f\u6027\u5206\u6790.csv"))
write_bom(sensitivity_rcs, file.path(result_dir, "06_RCS_P99\u654f\u611f\u6027\u5206\u6790.csv"))

positive_knots <- c(
  0,
  wq(main$vitd_supp_ug[positive], main$analysis_weight[positive], c(.25, .50, .95))
)
knot_schemes <- list(
  `4 knots: 0/all-P50/all-P75/all-P95 (primary)` = adaptive_knots,
  `3 knots: 0/all-P65/all-P95` = c(0, wq(main$vitd_supp_ug, main$analysis_weight, c(.65, .95))),
  `5 knots: 0/all-P50/all-P65/all-P80/all-P95` = c(0, wq(main$vitd_supp_ug, main$analysis_weight, c(.50, .65, .80, .95))),
  `4 knots: 0/positive-P25/positive-P50/positive-P95` = positive_knots
)
knot_schemes <- keep(knot_schemes, ~length(unique(round(.x, 10))) == length(.x))
knot_sensitivity <- imap_dfr(knot_schemes, function(kn, scheme) {
  z <- fit_rcs(main, "Model 3", model3_covariates, knots = kn,
               analysis = paste0("Knot sensitivity: ", scheme))$summary
  z |>
    transmute(
      scheme, N, knots_ug_day = paste(round(kn, 4), collapse = ", "),
      P_overall, P_nonlinear,
      `P overall` = p_fmt(P_overall), `P nonlinearity` = p_fmt(P_nonlinear),
      nonlinearity_conclusion
    )
})
write_bom(knot_sensitivity, file.path(result_dir, "06B_RCS\u8282\u70b9\u89c4\u683c\u654f\u611f\u6027\u5206\u6790.csv"))

model_definition <- tibble(
  model = names(models),
  covariate_n = c(0L, length(model2_covariates), length(model3_covariates)),
  covariates = vapply(models, function(x) if (length(x)) paste(x, collapse = ", ") else "Unadjusted", character(1)),
  exposure = "DSQTVD-derived daily vitamin D intake from supplements",
  exposure_unit = "ug/day",
  reported_scale = "Per 10 ug/day (400 IU/day)",
  outcome = "Moderate/severe periodontitis vs none/mild",
  survey_design = "NHANES 2009-2014; strata_pool, psu_pool, analysis_weight"
)
write_bom(model_definition, file.path(result_dir, "07_\u53d8\u91cf\u7f16\u7801\u4e0e\u6a21\u578b\u5b9a\u4e49.csv"))

plot_curve <- rcs_curve |> filter(model %in% c("Model 1", "Model 3")) |>
  mutate(model = factor(model, levels = c("Model 1", "Model 3"),
                        labels = c("Model 1 (unadjusted)", "Model 3 (fully adjusted)")))
p_labels <- rcs_summary |>
  filter(model %in% c("Model 1", "Model 3")) |>
  transmute(
    model = factor(model, levels = c("Model 1", "Model 3"),
                   labels = c("Model 1 (unadjusted)", "Model 3 (fully adjusted)")),
    label = paste0("P overall = ", p_fmt(P_overall), "\nP nonlinear = ", p_fmt(P_nonlinear))
  )

p <- ggplot(plot_curve, aes(vitd_supp_ug, OR)) +
  geom_ribbon(aes(ymin = CI_lower, ymax = CI_upper), fill = "#B7D8D4", alpha = .58) +
  geom_line(colour = "#155D59", linewidth = 1.05) +
  geom_hline(yintercept = 1, linetype = 2, colour = "grey45") +
  geom_text(data = p_labels, aes(x = Inf, y = Inf, label = label),
            inherit.aes = FALSE, hjust = 1.08, vjust = 1.20, size = 4.0, lineheight = 1.05) +
  facet_wrap(~model, ncol = 2) +
  coord_cartesian(ylim = c(0, NA)) +
  labs(
    x = "Supplemental vitamin D (μg/day)",
    y = "Odds ratio (95% CI)",
    subtitle = "Reference: 0 μg/day; curves shown through the weighted 99th percentile"
  ) +
  theme_classic(base_size = 13) +
  theme(strip.text = element_text(face = "bold"), plot.subtitle = element_text(colour = "grey30"))

ggsave(file.path(figure_dir, "01_RCS_\u672a\u8c03\u6574\u4e0e\u5b8c\u5168\u8c03\u6574.png"), p, width = 11, height = 5.8, dpi = 320, bg = "white")
ggsave(file.path(figure_dir, "01_RCS_\u672a\u8c03\u6574\u4e0e\u5b8c\u5168\u8c03\u6574.pdf"), p, width = 11, height = 5.8, device = cairo_pdf, bg = "white")

source_files <- file.path(raw_dir, paste0("DSQTOT_", names(cycle_map), ".XPT"))
source_audit <- tibble(
  cycle = unname(cycle_map),
  file = normalizePath(source_files, winslash = "/"),
  bytes = file.info(source_files)$size,
  md5 = unname(tools::md5sum(source_files)),
  official_url = paste0("https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/", c(2009, 2011, 2013),
                        "/DataFiles/DSQTOT_", names(cycle_map), ".XPT")
)
write_bom(source_audit, file.path(audit_dir, "01_\u5b98\u65b9\u539f\u59cb\u6587\u4ef6\u6765\u6e90\u4e0e\u5b8c\u6574\u6027.csv"))

merge_audit <- main0 |>
  left_join(supp, by = c("SEQN", "cycle")) |>
  group_by(cycle) |>
  summarise(
    source_n = n(), matched_n = sum(supplement_file_record %in% TRUE),
    valid_exposure_n = sum(!is.na(vitd_supp_ug)), zero_n = sum(vitd_supp_ug == 0, na.rm = TRUE),
    positive_n = sum(vitd_supp_ug > 0, na.rm = TRUE), .groups = "drop"
  )
write_bom(merge_audit, file.path(audit_dir, "02_\u5408\u5e76\u4e0e\u7f3a\u5931\u5ba1\u8ba1.csv"))
write_bom(flow, file.path(audit_dir, "02B_\u8865\u5145\u5242\u4e13\u7528\u961f\u5217\u6392\u9664\u6d41\u7a0b.csv"))

knot_audit <- tibble(
  scheme = c(rep("Conventional weighted quantiles", 4), rep("Adaptive unique knots used", 4)),
  percentile = c(standard_probs, adaptive_probs),
  knot_ug_day = c(standard_knots, adaptive_knots)
)
write_bom(knot_audit, file.path(audit_dir, "03_RCS\u8282\u70b9\u5ba1\u8ba1.csv"))

qa <- tibble(
  check = c(
    "Source merged dataset size", "One supplement record per SEQN-cycle",
    "All source participants matched", "All final supplement exposures valid after documented recoding",
    "No negative supplement vitamin D values", "Model 2 has 20 covariates", "Model 3 has 28 covariates",
    "No serum 25(OH)D requirement in supplement-specific cohort", "Conventional knots contain duplicates",
    "Adaptive RCS knots are unique", "All primary models converged"
  ),
  passed = c(
    nrow(main0) == 30468L, !anyDuplicated(supp[c("SEQN", "cycle")]),
    all(merge_audit$matched_n == merge_audit$source_n), all(!is.na(main$vitd_supp_ug)),
    all(main$vitd_supp_ug >= 0), length(model2_covariates) == 20L, length(model3_covariates) == 28L,
    sum(is.na(main$vitd_nmol)) > 0,
    length(unique(round(standard_knots, 10))) < 4L, length(unique(round(adaptive_knots, 10))) == 4L,
    all(is.finite(linear_results$OR))
  ),
  detail = c(
    as.character(nrow(main0)), "No duplicates", paste(merge_audit$matched_n, collapse = "/"),
    paste(nrow(main), "valid records"), paste(range(main$vitd_supp_ug), collapse = " to "),
    as.character(length(model2_covariates)), as.character(length(model3_covariates)),
    paste(sum(is.na(main$vitd_nmol)), "participants retained despite missing serum 25(OH)D"),
    paste(round(standard_knots, 4), collapse = ", "), paste(round(adaptive_knots, 4), collapse = ", "),
    paste(round(linear_results$OR, 4), collapse = ", ")
  )
)
write_bom(qa, file.path(audit_dir, "04_\u81ea\u52a8\u8d28\u91cf\u6838\u9a8c.csv"))
writeLines(capture.output(sessionInfo()), file.path(audit_dir, "05_sessionInfo.txt"), useBytes = TRUE)
if (!all(qa$passed)) stop("\u81ea\u52a8\u8d28\u91cf\u6838\u9a8c\u672a\u5168\u90e8\u901a\u8fc7\u3002", call. = FALSE)

saveRDS(main, file.path(result_dir, "08_\u5408\u5e76\u8865\u5145\u5242\u66b4\u9732\u7684\u4e25\u683c\u5206\u6790\u6570\u636e.rds"))
cat("\u5206\u6790\u5b8c\u6210\u3002N=", nrow(main), "\n", sep = "")
print(linear_results |> select(model, `OR (95% CI)`, `P value`))
print(rcs_summary |> select(model, `P overall`, `P nonlinearity`, nonlinearity_conclusion))
