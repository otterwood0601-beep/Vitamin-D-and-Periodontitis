options(stringsAsFactors = FALSE, survey.lonely.psu = "adjust")

suppressPackageStartupMessages({
  library(dplyr)
  library(purrr)
  library(readr)
  library(tibble)
  library(survey)
  library(Hmisc)
  library(ggplot2)
})

cmd_file <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (!length(cmd_file)) stop("\u8bf7\u4f7f\u7528 Rscript \u8fd0\u884c\u672c\u6587\u4ef6\u3002", call. = FALSE)
script_file <- normalizePath(sub("^--file=", "", cmd_file[[1]]), winslash = "/", mustWork = TRUE)
analysis_root <- dirname(dirname(script_file))
result_dir <- file.path(analysis_root, "03_\u7ed3\u679c")
figure_dir <- file.path(analysis_root, "04_\u56fe")
audit_dir <- file.path(analysis_root, "05_\u5ba1\u8ba1")
invisible(lapply(c(result_dir, figure_dir, audit_dir), dir.create,
                 recursive = TRUE, showWarnings = FALSE))

source_30d <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u8865\u5145\u5206\u6790/20260920_\u7ef4\u751f\u7d20D\u8865\u5145\u5242\u8fde\u7eed\u53d8\u91cf\u4e0e\u7259\u5468\u708e/",
  "03_\u7ed3\u679c/08_\u5408\u5e76\u8865\u5145\u5242\u66b4\u9732\u7684\u4e25\u683c\u5206\u6790\u6570\u636e.rds"
)
source_24h <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u8865\u5145\u5206\u6790/20260920_\u7ef4\u751f\u7d20D\u8865\u5145\u524224\u5c0f\u65f6\u56de\u987e\u4e0e\u7259\u5468\u708e/",
  "03_\u7ed3\u679c/07_24\u5c0f\u65f6\u56de\u987e\u5206\u6790\u6570\u636e.rds"
)
stopifnot(file.exists(source_30d), file.exists(source_24h))

write_bom <- function(x, path) readr::write_excel_csv(x, path, na = "")
p_fmt <- function(x) ifelse(is.na(x), "", ifelse(x < .001, "<0.001", sprintf("%.3f", x)))
or_fmt <- function(or, lo, hi) sprintf("%.3f (%.3f-%.3f)", or, lo, hi)

wq <- function(x, w, probs) {
  keep <- is.finite(x) & is.finite(w) & w > 0
  x <- x[keep]
  w <- w[keep]
  o <- order(x)
  x <- x[o]
  w <- w[o]
  approx(cumsum(w) / sum(w), x, xout = probs, rule = 2, ties = "ordered")$y
}

design_of <- function(d) {
  svydesign(
    ids = ~psu_pool, strata = ~strata_pool, weights = ~analysis_weight,
    nest = TRUE, data = d
  )
}

safe_regp <- function(model, terms) {
  f <- as.formula(paste0("~", paste(terms, collapse = "+")))
  tryCatch(as.numeric(regTermTest(model, f)$p), error = function(e) NA_real_)
}

oral <- c("floss_days", "mouthwash_days", "missing_teeth_count", "implant_count")
clinical <- c(
  "smoking", "alcohol", "physical_activity", "diabetes", "hypertension",
  "cvd", "ckd", "liver", "thyroid"
)
demographic <- c("sex", "bmi", "age", "education", "marital", "pir_cat", "race")
nutrition <- c(
  "energy_kcal", "sugar_g", "cholesterol_mg", "fat_g", "fiber_g",
  "protein_g", "calcium_mg", "phosphorus_mg"
)
model2_covariates <- c(oral, clinical, demographic)
model3_covariates <- c(model2_covariates, nutrition)
models <- list(
  `Model 1` = character(),
  `Model 2` = model2_covariates,
  `Model 3` = model3_covariates
)
stopifnot(length(model2_covariates) == 20L, length(model3_covariates) == 28L)

extract_linear <- function(fit, term, exposure_label, model_name, n) {
  co <- coef(fit)
  vv <- vcov(fit)
  b <- unname(co[[term]])
  se <- sqrt(vv[term, term])
  tibble(
    exposure = exposure_label,
    population = "Positive-dose supplement users only (>0 ug/day)",
    model = model_name,
    N = n,
    beta = b,
    SE = se,
    OR = exp(b),
    CI_lower = exp(b - 1.96 * se),
    CI_upper = exp(b + 1.96 * se),
    P = 2 * pnorm(-abs(b / se)),
    exposure_scale = "Per 10 ug/day (400 IU/day)"
  )
}

analyse_exposure <- function(d, x_name, exposure_label) {
  required <- unique(c(
    "periodontitis_bin", "analysis_weight", "strata_pool", "psu_pool",
    model3_covariates, x_name
  ))
  if (!all(required %in% names(d))) {
    stop("\u5206\u6790\u6570\u636e\u7f3a\u5c11\u53d8\u91cf\uff1a", paste(setdiff(required, names(d)), collapse = ", "), call. = FALSE)
  }
  if (any(!complete.cases(d[, required, drop = FALSE]))) {
    stop(exposure_label, " \u7684\u4e25\u683c\u5206\u6790\u6570\u636e\u4ecd\u542b\u6a21\u578b\u5fc5\u9700\u53d8\u91cf\u7f3a\u5931\u3002", call. = FALSE)
  }

  dd <- d
  dd$x_ug <- as.numeric(dd[[x_name]])
  dd$x_per10 <- dd$x_ug / 10
  dd$positive_domain <- dd$x_ug > 0
  pos <- dd |> filter(positive_domain)
  n_pos <- nrow(pos)
  if (!n_pos) stop(exposure_label, " \u6ca1\u6709\u6b63\u503c\u8bb0\u5f55\u3002", call. = FALSE)

  des_pos <- subset(design_of(dd), positive_domain)
  linear <- imap_dfr(models, function(covariates, model_name) {
    f <- as.formula(paste(
      "periodontitis_bin~",
      paste(c("x_per10", covariates), collapse = "+")
    ))
    fit <- svyglm(f, design = des_pos, family = quasibinomial())
    extract_linear(fit, "x_per10", exposure_label, model_name, n_pos)
  })

  knot_probs <- c(.05, .35, .65, .95)
  knots <- unname(wq(pos$x_ug, pos$analysis_weight, knot_probs))
  if (length(unique(round(knots, 10))) != 4L) {
    stop(exposure_label, " \u7684\u6b63\u503c\u4eba\u7fa4RCS\u8282\u70b9\u4e0d\u552f\u4e00\u3002", call. = FALSE)
  }
  reference <- unname(wq(pos$x_ug, pos$analysis_weight, .50))
  display_limits <- unname(wq(pos$x_ug, pos$analysis_weight, c(.01, .99)))

  B <- Hmisc::rcspline.eval(dd$x_ug, knots = knots, inclx = TRUE)
  colnames(B) <- paste0("rcs", seq_len(ncol(B)))
  dd_rcs <- bind_cols(dd, as.data.frame(B))
  des_rcs_pos <- subset(design_of(dd_rcs), positive_domain)
  spline_terms <- colnames(B)

  rcs_objects <- imap(models, function(covariates, model_name) {
    f <- as.formula(paste(
      "periodontitis_bin~",
      paste(c(spline_terms, covariates), collapse = "+")
    ))
    fit <- svyglm(f, design = des_rcs_pos, family = quasibinomial())
    p_overall <- safe_regp(fit, spline_terms)
    p_nonlinear <- safe_regp(fit, spline_terms[-1])

    grid <- sort(unique(c(
      seq(display_limits[1], display_limits[2], length.out = 260),
      knots, reference
    )))
    grid <- grid[grid >= display_limits[1] & grid <= display_limits[2]]
    G <- Hmisc::rcspline.eval(grid, knots = knots, inclx = TRUE)
    R <- Hmisc::rcspline.eval(reference, knots = knots, inclx = TRUE)
    D <- sweep(G, 2, R)
    be <- coef(fit)[spline_terms]
    V <- vcov(fit)[spline_terms, spline_terms, drop = FALSE]
    eta <- drop(D %*% be)
    se <- sqrt(rowSums((D %*% V) * D))

    list(
      fit = fit,
      summary = tibble(
        exposure = exposure_label,
        population = "Positive-dose supplement users only (>0 ug/day)",
        model = model_name,
        N = n_pos,
        reference_ug_day = reference,
        knot_1 = knots[1], knot_2 = knots[2],
        knot_3 = knots[3], knot_4 = knots[4],
        display_P1 = display_limits[1], display_P99 = display_limits[2],
        P_overall = p_overall,
        P_nonlinear = p_nonlinear,
        nonlinearity_conclusion = ifelse(
          is.finite(p_nonlinear) & p_nonlinear < .05,
          "Supports nonlinearity", "Does not support nonlinearity"
        )
      ),
      curve = tibble(
        exposure = exposure_label,
        model = model_name,
        intake_ug_day = grid,
        reference_ug_day = reference,
        OR = exp(eta),
        CI_lower = exp(eta - 1.96 * se),
        CI_upper = exp(eta + 1.96 * se)
      )
    )
  })

  p99 <- display_limits[2]
  dd$p99_domain <- dd$positive_domain & dd$x_ug <= p99
  des_p99 <- subset(design_of(dd), p99_domain)
  f_p99 <- as.formula(paste(
    "periodontitis_bin~",
    paste(c("x_per10", model3_covariates), collapse = "+")
  ))
  fit_p99 <- svyglm(f_p99, design = des_p99, family = quasibinomial())
  p99_linear <- extract_linear(
    fit_p99, "x_per10", exposure_label, "Model 3; positive users <= weighted P99",
    sum(dd$p99_domain)
  )

  descriptive <- tibble(
    exposure = exposure_label,
    all_complete_case_N = nrow(dd),
    removed_zero_N = sum(dd$x_ug == 0),
    positive_N = n_pos,
    weighted_positive_median_ug_day = reference,
    weighted_positive_P1_ug_day = display_limits[1],
    weighted_positive_P99_ug_day = display_limits[2],
    knot_P5 = knots[1], knot_P35 = knots[2], knot_P65 = knots[3], knot_P95 = knots[4]
  )

  list(
    linear = linear,
    rcs_summary = bind_rows(map(rcs_objects, "summary")),
    rcs_curve = bind_rows(map(rcs_objects, "curve")),
    p99_linear = p99_linear,
    descriptive = descriptive
  )
}

res_30d <- analyse_exposure(
  readRDS(source_30d), "vitd_supp_ug",
  "30-day average supplemental vitamin D"
)
res_24h <- analyse_exposure(
  readRDS(source_24h), "vitd_supp_24h_ug",
  "24-hour Day 1 supplemental vitamin D"
)

linear <- bind_rows(res_30d$linear, res_24h$linear) |>
  mutate(`OR (95% CI)` = or_fmt(OR, CI_lower, CI_upper), `P value` = p_fmt(P))
rcs_summary <- bind_rows(res_30d$rcs_summary, res_24h$rcs_summary) |>
  mutate(`P overall` = p_fmt(P_overall), `P nonlinearity` = p_fmt(P_nonlinear))
rcs_curve <- bind_rows(res_30d$rcs_curve, res_24h$rcs_curve)
p99_sensitivity <- bind_rows(res_30d$p99_linear, res_24h$p99_linear) |>
  mutate(`OR (95% CI)` = or_fmt(OR, CI_lower, CI_upper), `P value` = p_fmt(P))
descriptive <- bind_rows(res_30d$descriptive, res_24h$descriptive)

write_bom(linear, file.path(result_dir, "01_\u53bb\u96640\u503c_\u8fde\u7eed\u5173\u8054_Model1\u81f33.csv"))
write_bom(rcs_summary, file.path(result_dir, "02_\u53bb\u96640\u503c_RCS\u603b\u4f53\u4e0e\u975e\u7ebf\u6027P\u503c.csv"))
write_bom(rcs_curve, file.path(result_dir, "03_\u53bb\u96640\u503c_RCS\u66f2\u7ebf\u6570\u636e.csv"))
write_bom(p99_sensitivity, file.path(result_dir, "04_\u53bb\u96640\u503c_P99\u654f\u611f\u6027\u5206\u6790.csv"))
write_bom(descriptive, file.path(result_dir, "05_\u6b63\u503c\u4eba\u7fa4\u5206\u5e03\u4e0eRCS\u53c2\u6570.csv"))

model_definition <- tibble(
  model = names(models),
  covariate_n = c(0L, length(model2_covariates), length(model3_covariates)),
  covariates = vapply(
    models,
    function(x) if (length(x)) paste(x, collapse = ", ") else "Unadjusted",
    character(1)
  ),
  estimand = "Dose association among participants with supplemental vitamin D intake >0 ug/day",
  reported_scale = "Per 10 ug/day (400 IU/day)",
  outcome = "Moderate/severe periodontitis vs none/mild"
)
write_bom(model_definition, file.path(result_dir, "06_\u6a21\u578b\u5b9a\u4e49.csv"))

plot_curve <- rcs_curve |>
  filter(model == "Model 3") |>
  mutate(
    exposure = factor(
      exposure,
      levels = c(
        "30-day average supplemental vitamin D",
        "24-hour Day 1 supplemental vitamin D"
      ),
      labels = c("30-day average", "24-hour Day 1")
    )
  )
plot_labels <- rcs_summary |>
  filter(model == "Model 3") |>
  mutate(
    exposure = factor(
      exposure,
      levels = c(
        "30-day average supplemental vitamin D",
        "24-hour Day 1 supplemental vitamin D"
      ),
      labels = c("30-day average", "24-hour Day 1")
    ),
    label = paste0(
      "Reference = ", sprintf("%.1f", reference_ug_day), " μg/day\n",
      "P overall = ", p_fmt(P_overall), "\n",
      "P nonlinear = ", p_fmt(P_nonlinear)
    )
  )

p <- ggplot(plot_curve, aes(intake_ug_day, OR)) +
  geom_ribbon(aes(ymin = CI_lower, ymax = CI_upper), fill = "#BFDDBE", alpha = .55) +
  geom_line(colour = "#2E6F40", linewidth = 1.05) +
  geom_hline(yintercept = 1, linetype = 2, colour = "grey45") +
  geom_text(
    data = plot_labels, aes(x = Inf, y = Inf, label = label),
    inherit.aes = FALSE, hjust = 1.08, vjust = 1.18, size = 3.8, lineheight = 1.05
  ) +
  facet_wrap(~exposure, scales = "free_x", ncol = 2) +
  labs(
    x = "Supplemental vitamin D among users (μg/day)",
    y = "Odds ratio (95% CI)",
    subtitle = "Model 3; zero-intake observations excluded; curves shown from weighted P1 to P99"
  ) +
  theme_classic(base_size = 13) +
  theme(strip.text = element_text(face = "bold"), plot.subtitle = element_text(colour = "grey30"))

ggsave(file.path(figure_dir, "01_\u53bb\u96640\u503c_Model3_RCS\u5bf9\u7167\u56fe.png"), p,
       width = 11, height = 5.8, dpi = 320, bg = "white")
ggsave(file.path(figure_dir, "01_\u53bb\u96640\u503c_Model3_RCS\u5bf9\u7167\u56fe.pdf"), p,
       width = 11, height = 5.8, device = cairo_pdf, bg = "white")

source_audit <- tibble(
  exposure = c("30-day average", "24-hour Day 1"),
  source_file = normalizePath(c(source_30d, source_24h), winslash = "/"),
  bytes = file.info(c(source_30d, source_24h))$size,
  md5 = unname(tools::md5sum(c(source_30d, source_24h)))
)
write_bom(source_audit, file.path(audit_dir, "01_\u8f93\u5165\u6570\u636e\u6765\u6e90\u4e0e\u5b8c\u6574\u6027.csv"))

qa <- tibble(
  check = c(
    "30-day positive N equals prior audited count",
    "24-hour positive N equals prior audited count",
    "All modeled doses are strictly positive",
    "Model 2 has 20 covariates",
    "Model 3 has 28 covariates",
    "All RCS knot sets contain four unique values",
    "All linear estimates are finite",
    "All RCS tests returned finite P values"
  ),
  passed = c(
    res_30d$descriptive$positive_N == 1434L,
    res_24h$descriptive$positive_N == 1281L,
    res_30d$descriptive$positive_N > 0L & res_24h$descriptive$positive_N > 0L,
    length(model2_covariates) == 20L,
    length(model3_covariates) == 28L,
    all(apply(descriptive[, c("knot_P5", "knot_P35", "knot_P65", "knot_P95")], 1,
              function(z) length(unique(round(as.numeric(z), 10))) == 4L)),
    all(is.finite(linear$OR)) & all(is.finite(linear$P)),
    all(is.finite(rcs_summary$P_overall)) & all(is.finite(rcs_summary$P_nonlinear))
  ),
  detail = c(
    as.character(res_30d$descriptive$positive_N),
    as.character(res_24h$descriptive$positive_N),
    "Exposure-domain definition: >0 ug/day",
    as.character(length(model2_covariates)),
    as.character(length(model3_covariates)),
    paste(apply(descriptive[, c("knot_P5", "knot_P35", "knot_P65", "knot_P95")], 1,
                function(z) paste(round(as.numeric(z), 3), collapse = ", ")), collapse = " | "),
    paste(round(linear$OR, 4), collapse = ", "),
    paste(round(rcs_summary$P_nonlinear, 4), collapse = ", ")
  )
)
write_bom(qa, file.path(audit_dir, "02_\u81ea\u52a8\u8d28\u91cf\u6838\u9a8c.csv"))
writeLines(capture.output(sessionInfo()), file.path(audit_dir, "03_sessionInfo.txt"), useBytes = TRUE)
if (!all(qa$passed)) stop("\u81ea\u52a8\u8d28\u91cf\u6838\u9a8c\u672a\u5168\u90e8\u901a\u8fc7\u3002", call. = FALSE)

cat("\u53bb\u96640\u503c\u540e\u7684\u4e24\u79cd\u8865\u5145\u5242\u66b4\u9732\u5206\u6790\u5b8c\u6210\u3002\n")
print(linear |> select(exposure, model, N, `OR (95% CI)`, `P value`))
print(rcs_summary |> select(exposure, model, reference_ug_day, `P overall`, `P nonlinearity`))
