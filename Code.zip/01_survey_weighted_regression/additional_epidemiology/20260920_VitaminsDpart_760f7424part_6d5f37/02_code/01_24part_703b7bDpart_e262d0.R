options(stringsAsFactors = FALSE, survey.lonely.psu = "adjust")
suppressPackageStartupMessages({
  library(haven); library(dplyr); library(purrr); library(readr); library(tibble)
  library(survey); library(Hmisc); library(ggplot2)
})

cmd_file <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (!length(cmd_file)) stop("\u8bf7\u4f7f\u7528Rscript\u8fd0\u884c\u672c\u6587\u4ef6\u3002", call. = FALSE)
script_file <- normalizePath(sub("^--file=", "", cmd_file[[1]]), winslash = "/", mustWork = TRUE)
root <- dirname(dirname(script_file))
raw_dir <- file.path(root, "01_\u5b98\u65b9\u539f\u59cb\u6587\u4ef6")
result_dir <- file.path(root, "03_\u7ed3\u679c")
figure_dir <- file.path(root, "04_\u56fe")
audit_dir <- file.path(root, "05_\u5ba1\u8ba1")
invisible(lapply(c(result_dir, figure_dir, audit_dir), dir.create, recursive = TRUE, showWarnings = FALSE))

source_rds <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/01-02_\u6b63\u6587\u56fe1-2_\u903b\u8f91\u56de\u5f52\u4e0e\u673a\u5668\u5b66\u4e60/",
  "20260802_\u4e25\u683c\u53d8\u91cf_\u6700\u7ec8/\u7b2c1\u6b65_\u6570\u636e\u8bfb\u53d6\u4e0b\u8f7d\u4e0e\u5468\u671f\u5408\u5e76/",
  "01_NHANES2009-2014_\u6392\u9664\u524d\u4e25\u683c\u6d3e\u751f\u6570\u636e.rds"
)
if (!file.exists(source_rds)) stop("\u7f3a\u5c11\u6392\u9664\u524d\u4e25\u683c\u6d3e\u751f\u6570\u636e\u3002", call. = FALSE)

write_bom <- function(x, path) readr::write_excel_csv(x, path, na = "")
p_fmt <- function(x) ifelse(is.na(x), "", ifelse(x < .001, "<0.001", sprintf("%.3f", x)))
or_fmt <- function(or, lo, hi) sprintf("%.3f (%.3f-%.3f)", or, lo, hi)
wq <- function(x, w, probs) {
  keep <- is.finite(x) & is.finite(w) & w > 0
  x <- x[keep]; w <- w[keep]
  o <- order(x); x <- x[o]; w <- w[o]
  approx(cumsum(w) / sum(w), x, xout = probs, rule = 2, ties = "ordered")$y
}
design_of <- function(d) svydesign(ids = ~psu_pool, strata = ~strata_pool,
                                    weights = ~analysis_weight, nest = TRUE, data = d)
safe_regp <- function(fit, terms) {
  tryCatch(as.numeric(regTermTest(fit, as.formula(paste0("~", paste(terms, collapse = "+"))))$p),
           error = function(e) NA_real_)
}

cycle_map <- c(F = "2009-2010", G = "2011-2012", H = "2013-2014")
read_cycle <- function(suffix) {
  path <- file.path(raw_dir, paste0("DS1TOT_", suffix, ".XPT"))
  read_xpt(path, col_select = c(SEQN, WTDRD1, DR1DRSTZ, DS1DS, DS1DSCNT, DS1TVD)) |>
    transmute(
      SEQN = as.numeric(SEQN), cycle = unname(cycle_map[[suffix]]), ds1_file_record = TRUE,
      day1_weight_file = as.numeric(WTDRD1), recall_status = as.numeric(DR1DRSTZ),
      any_supplement_24h = as.numeric(DS1DS), supplement_count_24h = as.numeric(DS1DSCNT),
      vitd_supp_24h_ug = case_when(
        recall_status == 1 & any_supplement_24h %in% c(1, 2) & is.finite(as.numeric(DS1TVD)) ~ as.numeric(DS1TVD),
        recall_status == 1 & any_supplement_24h %in% c(1, 2) & is.na(DS1TVD) ~ 0,
        TRUE ~ NA_real_
      )
    )
}
ds1 <- map_dfr(names(cycle_map), read_cycle)
if (anyDuplicated(ds1[c("SEQN", "cycle")])) stop("DS1TOT\u5b58\u5728\u91cd\u590dSEQN-cycle\u3002", call. = FALSE)

source <- readRDS(source_rds)
merged <- source |>
  left_join(ds1, by = c("SEQN", "cycle")) |>
  mutate(
    vitd_supp_24h_per10 = vitd_supp_24h_ug / 10,
    vitd_supp_24h_user = as.integer(vitd_supp_24h_ug > 0),
    log2_vitd_supp_24h_plus1 = log2(vitd_supp_24h_ug + 1)
  )

oral <- c("floss_days", "mouthwash_days", "missing_teeth_count", "implant_count")
clinical <- c("smoking", "alcohol", "physical_activity", "diabetes", "hypertension", "cvd", "ckd", "liver", "thyroid")
demographic <- c("sex", "bmi", "age", "education", "marital", "pir_cat", "race")
nutrition <- c("energy_kcal", "sugar_g", "cholesterol_mg", "fat_g", "fiber_g", "protein_g", "calcium_mg", "phosphorus_mg")
model2_covariates <- c(oral, clinical, demographic)
model3_covariates <- c(model2_covariates, nutrition)
models <- list(`Model 1` = character(), `Model 2` = model2_covariates, `Model 3` = model3_covariates)

required <- unique(c("periodontitis_bin", model3_covariates, "analysis_weight", "strata_pool", "psu_pool", "vitd_supp_24h_ug"))
d_age <- merged |> filter(is.finite(age) & age >= 60)
d_outcome <- d_age |> filter(!is.na(periodontitis), periodontitis_bin %in% c(0, 1))
d_exposure <- d_outcome |> filter(!is.na(vitd_supp_24h_ug))
ok <- complete.cases(d_exposure[, required, drop = FALSE]) &
  is.finite(d_exposure$analysis_weight) & d_exposure$analysis_weight > 0
main <- droplevels(d_exposure[ok, , drop = FALSE])
des <- design_of(main)

flow <- tibble(
  step = c("Merged NHANES 2009-2014", "Age >=60", "Periodontal outcome available",
           "Complete and reliable Day 1 supplement recall", "Complete Model 3 covariates/design"),
  remaining_n = c(nrow(merged), nrow(d_age), nrow(d_outcome), nrow(d_exposure), nrow(main)),
  removed_from_previous = c(0L, nrow(merged)-nrow(d_age), nrow(d_age)-nrow(d_outcome),
                            nrow(d_outcome)-nrow(d_exposure), nrow(d_exposure)-nrow(main))
)

extract_term <- function(fit, term, model, analysis, scale, n) {
  b <- coef(fit)[[term]]; se <- sqrt(vcov(fit)[term, term])
  tibble(model, analysis, exposure_scale = scale, N = n, beta = b, SE = se,
         OR = exp(b), CI_lower = exp(b - 1.96*se), CI_upper = exp(b + 1.96*se),
         P = 2*pnorm(-abs(b/se)))
}
fit_linear <- function(design, model_name, covariates, exposure = "vitd_supp_24h_per10",
                       analysis = "Primary: Day 1 24-hour supplement recall",
                       scale = "Per 10 ug/day (400 IU/day)") {
  f <- as.formula(paste("periodontitis_bin~", paste(c(exposure, covariates), collapse = "+")))
  fit <- svyglm(f, design, family = quasibinomial())
  extract_term(fit, exposure, model_name, analysis, scale, nrow(model.frame(fit)))
}

linear <- imap_dfr(models, ~fit_linear(des, .y, .x)) |>
  mutate(`OR (95% CI)` = or_fmt(OR, CI_lower, CI_upper), `P value` = p_fmt(P))
write_bom(linear, file.path(result_dir, "01_24\u5c0f\u65f6\u56de\u987e\u8fde\u7eed\u5173\u8054_Model1\u81f33.csv"))

probs <- c(0, .05, .25, .35, .50, .65, .75, .80, .90, .95, .99, 1)
quantiles <- wq(main$vitd_supp_24h_ug, main$analysis_weight, probs)
positive <- main$vitd_supp_24h_ug > 0
positive_probs <- c(0, .05, .25, .50, .75, .90, .95, .99, 1)
positive_quantiles <- wq(main$vitd_supp_24h_ug[positive], main$analysis_weight[positive], positive_probs)
knots <- c(0, wq(main$vitd_supp_24h_ug, main$analysis_weight, c(.50, .75, .95)))
if (length(unique(round(knots, 10))) != 4L) {
  knots <- c(0, wq(main$vitd_supp_24h_ug[positive], main$analysis_weight[positive], c(.25, .50, .95)))
}
if (length(unique(round(knots, 10))) != 4L) stop("RCS\u8282\u70b9\u4e0d\u552f\u4e00\u3002", call. = FALSE)

fit_rcs <- function(d, model_name, covariates, knot_values = knots,
                    analysis = "Primary: Day 1 24-hour supplement recall") {
  B <- Hmisc::rcspline.eval(d$vitd_supp_24h_ug, knots = knot_values, inclx = TRUE)
  colnames(B) <- paste0("rcs", seq_len(ncol(B)))
  dd <- bind_cols(d, as.data.frame(B)); ddes <- design_of(dd); terms <- colnames(B)
  fit <- svyglm(as.formula(paste("periodontitis_bin~", paste(c(terms, covariates), collapse = "+"))),
                ddes, family = quasibinomial())
  p_overall <- safe_regp(fit, terms); p_nonlinear <- safe_regp(fit, terms[-1])
  upper <- wq(d$vitd_supp_24h_ug, d$analysis_weight, .99)
  grid <- sort(unique(c(seq(0, upper, length.out = 260), knot_values[knot_values <= upper])))
  G <- Hmisc::rcspline.eval(grid, knots = knot_values, inclx = TRUE)
  R <- Hmisc::rcspline.eval(0, knots = knot_values, inclx = TRUE)
  D <- sweep(G, 2, R); be <- coef(fit)[terms]; V <- vcov(fit)[terms, terms, drop = FALSE]
  eta <- drop(D %*% be); se <- sqrt(rowSums((D %*% V) * D))
  list(
    summary = tibble(model = model_name, analysis, N = nrow(d), reference_ug_day = 0,
                     knots_ug_day = paste(round(knot_values, 4), collapse = ", "),
                     curve_upper_p99 = upper, P_overall = p_overall, P_nonlinear = p_nonlinear,
                     conclusion = ifelse(p_nonlinear < .05, "Supports nonlinearity", "Does not support nonlinearity")),
    curve = tibble(model = model_name, analysis, vitd_supp_24h_ug = grid,
                   OR = exp(eta), CI_lower = exp(eta-1.96*se), CI_upper = exp(eta+1.96*se))
  )
}
rcs_res <- imap(models, ~fit_rcs(main, .y, .x))
rcs_summary <- bind_rows(map(rcs_res, "summary")) |>
  mutate(`P overall` = p_fmt(P_overall), `P nonlinearity` = p_fmt(P_nonlinear))
rcs_curve <- bind_rows(map(rcs_res, "curve"))
write_bom(rcs_summary, file.path(result_dir, "02_24\u5c0f\u65f6\u56de\u987e_RCS\u603b\u4f53\u4e0e\u975e\u7ebf\u6027P\u503c.csv"))
write_bom(rcs_curve, file.path(result_dir, "03_24\u5c0f\u65f6\u56de\u987e_RCS\u66f2\u7ebf\u6570\u636e.csv"))

p99 <- wq(main$vitd_supp_24h_ug, main$analysis_weight, .99)
des_p99 <- subset(des, vitd_supp_24h_ug <= p99)
des_users <- subset(des, vitd_supp_24h_ug > 0)
sensitivity <- bind_rows(
  fit_linear(des_p99, "Model 3", model3_covariates,
             analysis = "Sensitivity: intake <= weighted P99"),
  fit_linear(des_users, "Model 3", model3_covariates,
             analysis = "Sensitivity: positive-dose users only"),
  fit_linear(des, "Model 3", model3_covariates, exposure = "vitd_supp_24h_user",
             analysis = "Sensitivity: any intake versus zero", scale = "Any intake vs zero"),
  fit_linear(des, "Model 3", model3_covariates, exposure = "log2_vitd_supp_24h_plus1",
             analysis = "Sensitivity: log2(intake+1)", scale = "Per doubling of (intake+1)")
) |>
  mutate(`OR (95% CI)` = or_fmt(OR, CI_lower, CI_upper), `P value` = p_fmt(P))
write_bom(sensitivity, file.path(result_dir, "04_24\u5c0f\u65f6\u56de\u987e\u654f\u611f\u6027\u5206\u6790.csv"))

knot_sets <- list(
  `4 knots: 0/all-P50/all-P75/all-P95` = knots,
  `3 knots: 0/all-P65/all-P95` = c(0, wq(main$vitd_supp_24h_ug, main$analysis_weight, c(.65, .95))),
  `5 knots: 0/all-P50/all-P65/all-P80/all-P95` = c(0, wq(main$vitd_supp_24h_ug, main$analysis_weight, c(.50, .65, .80, .95))),
  `4 knots: 0/positive-P25/positive-P50/positive-P95` = c(0, wq(main$vitd_supp_24h_ug[positive], main$analysis_weight[positive], c(.25, .50, .95)))
)
knot_sets <- keep(knot_sets, ~length(unique(round(.x, 10))) == length(.x))
knot_sensitivity <- imap_dfr(knot_sets, function(k, label) {
  z <- fit_rcs(main, "Model 3", model3_covariates, k, paste0("Knot sensitivity: ", label))$summary
  z |> transmute(scheme = label, knots_ug_day, P_overall, P_nonlinear,
                  `P overall` = p_fmt(P_overall), `P nonlinearity` = p_fmt(P_nonlinear), conclusion)
})
write_bom(knot_sensitivity, file.path(result_dir, "05_24\u5c0f\u65f6\u56de\u987e_RCS\u8282\u70b9\u654f\u611f\u6027.csv"))

descriptive <- bind_rows(
  tibble(metric = c("Analysis N", "Zero intake N", "Positive intake N", "Weighted positive-intake prevalence"),
         value = c(nrow(main), sum(main$vitd_supp_24h_ug == 0), sum(main$vitd_supp_24h_ug > 0),
                   coef(svymean(~vitd_supp_24h_user, des))[[1]]),
         unit = c("participants", "participants", "participants", "proportion")),
  tibble(metric = paste0("Weighted quantile all P", probs*100), value = quantiles, unit = "ug/day"),
  tibble(metric = paste0("Weighted quantile positive P", positive_probs*100), value = positive_quantiles, unit = "ug/day")
)
write_bom(descriptive, file.path(result_dir, "06_24\u5c0f\u65f6\u56de\u987e\u5206\u5e03\u7edf\u8ba1.csv"))

plot_data <- rcs_curve |> filter(model %in% c("Model 1", "Model 3")) |>
  mutate(model = factor(model, c("Model 1", "Model 3"), c("Model 1 (unadjusted)", "Model 3 (fully adjusted)")))
plot_labels <- rcs_summary |> filter(model %in% c("Model 1", "Model 3")) |>
  transmute(model = factor(model, c("Model 1", "Model 3"), c("Model 1 (unadjusted)", "Model 3 (fully adjusted)")),
            label = paste0("P overall = ", p_fmt(P_overall), "\nP nonlinear = ", p_fmt(P_nonlinear)))
p <- ggplot(plot_data, aes(vitd_supp_24h_ug, OR)) +
  geom_ribbon(aes(ymin = CI_lower, ymax = CI_upper), fill = "#B7D8D4", alpha = .58) +
  geom_line(colour = "#155D59", linewidth = 1.05) +
  geom_hline(yintercept = 1, linetype = 2, colour = "grey45") +
  geom_text(data = plot_labels, aes(x = Inf, y = Inf, label = label), inherit.aes = FALSE,
            hjust = 1.08, vjust = 1.2, size = 4) +
  facet_wrap(~model, ncol = 2) +
  labs(x = "Day 1 supplemental vitamin D (μg/day)", y = "Odds ratio (95% CI)",
       subtitle = "Reference: 0 μg/day; curves shown through the weighted 99th percentile") +
  theme_classic(base_size = 13) + theme(strip.text = element_text(face = "bold"))
ggsave(file.path(figure_dir, "01_24\u5c0f\u65f6\u56de\u987e_RCS_\u672a\u8c03\u6574\u4e0e\u5b8c\u5168\u8c03\u6574.png"), p,
       width = 11, height = 5.8, dpi = 320, bg = "white")
ggsave(file.path(figure_dir, "01_24\u5c0f\u65f6\u56de\u987e_RCS_\u672a\u8c03\u6574\u4e0e\u5b8c\u5168\u8c03\u6574.pdf"), p,
       width = 11, height = 5.8, device = cairo_pdf, bg = "white")

write_bom(flow, file.path(audit_dir, "01_24\u5c0f\u65f6\u56de\u987e\u6392\u9664\u6d41\u7a0b.csv"))
files <- file.path(raw_dir, paste0("DS1TOT_", names(cycle_map), ".XPT"))
write_bom(tibble(cycle = unname(cycle_map), file = normalizePath(files, winslash = "/"),
                 bytes = file.info(files)$size, md5 = unname(tools::md5sum(files)),
                 official_url = paste0("https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/", c(2009,2011,2013),
                                       "/DataFiles/DS1TOT_", names(cycle_map), ".XPT")),
          file.path(audit_dir, "02_\u5b98\u65b9\u539f\u59cb\u6587\u4ef6\u6765\u6e90.csv"))

qa <- tibble(
  check = c("DS1TOT join did not expand source rows", "All final records matched to DS1TOT", "No duplicate SEQN-cycle", "Day 1 dietary weights agree",
            "Only complete reliable recalls retained", "No negative exposure values", "Model 2 has 20 covariates",
            "Model 3 has 28 covariates", "RCS knots unique", "All primary models converged"),
  passed = c(nrow(merged) == nrow(source), all(main$ds1_file_record %in% TRUE), !anyDuplicated(ds1[c("SEQN","cycle")]),
             max(abs(main$analysis_weight - main$day1_weight_file/3), na.rm = TRUE) < 1e-8,
             all(main$recall_status == 1), all(main$vitd_supp_24h_ug >= 0),
             length(model2_covariates) == 20L, length(model3_covariates) == 28L,
             length(unique(round(knots,10))) == 4L, all(is.finite(linear$OR))),
  detail = c(paste(nrow(source), "source rows;", nrow(merged), "rows after join"), paste(nrow(main), "final records matched"), "No duplicates", "analysis_weight = WTDRD1/3",
             paste(nrow(main), "complete Day 1 recalls"), paste(range(main$vitd_supp_24h_ug), collapse = " to "),
             length(model2_covariates), length(model3_covariates), paste(round(knots,4), collapse = ", "),
             paste(round(linear$OR,4), collapse = ", "))
)
write_bom(qa, file.path(audit_dir, "03_\u81ea\u52a8\u8d28\u91cf\u6838\u9a8c.csv"))
writeLines(capture.output(sessionInfo()), file.path(audit_dir, "04_sessionInfo.txt"), useBytes = TRUE)
if (!all(qa$passed)) stop("\u81ea\u52a8\u8d28\u91cf\u6838\u9a8c\u672a\u5168\u90e8\u901a\u8fc7\u3002", call. = FALSE)
saveRDS(main, file.path(result_dir, "07_24\u5c0f\u65f6\u56de\u987e\u5206\u6790\u6570\u636e.rds"))

cat("24\u5c0f\u65f6\u56de\u987e\u5206\u6790\u5b8c\u6210\u3002N=", nrow(main), "\n", sep = "")
print(linear |> select(model, `OR (95% CI)`, `P value`))
print(rcs_summary |> select(model, `P overall`, `P nonlinearity`, conclusion))
