options(stringsAsFactors = FALSE)

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(patchwork)
  library(pROC)
  library(readr)
  library(jsonlite)
})

set.seed(20260914)

project_root <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20D DLC"
source_root <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/01_NHANES/\u6d3e\u751f\u8f93\u5165/2009-2014\u4e3b\u5206\u6790_2001-2004\u5916\u90e8\u9a8c\u8bc1/\u7b2c1\u6b65_\u6570\u636e\u8bfb\u53d6\u4e0b\u8f7d\u4e0e\u5468\u671f\u5408\u5e76"
out_root <- file.path(project_root, "P10_NHANES\u4e34\u5e8a\u652f\u6301", "outputs")
source_dir <- file.path(out_root, "02_source_data")
figure_dir <- file.path(out_root, "figures")
qa_dir <- file.path(out_root, "03_QA")
doc_dir <- file.path(project_root, "docs")
dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(qa_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(doc_dir, recursive = TRUE, showWarnings = FALSE)

main_path <- file.path(source_root, "01_NHANES2009-2014_\u6392\u9664\u524d\u6d3e\u751f\u6570\u636e.rds")
external_path <- file.path(source_root, "02_NHANES2001-2004_\u6392\u9664\u524d\u6d3e\u751f\u6570\u636e.rds")
stopifnot(file.exists(main_path), file.exists(external_path))

clinical_vars <- c(
  "age", "sex", "bmi", "race", "education", "pir", "smoking",
  "diabetes", "hypertension", "cvd", "ckd", "missing_teeth_count",
  "dental_visit"
)
factor_vars <- c("sex", "race", "education", "smoking", "diabetes", "hypertension", "cvd", "ckd", "dental_visit")
required <- c("participant_id", "cycle", "periodontitis_bin", "vitd_nmol", "analysis_weight", clinical_vars)

prepare_data <- function(path, main_levels = NULL) {
  d <- readRDS(path)
  stopifnot(all(required %in% names(d)))
  d <- d |>
    select(all_of(required)) |>
    mutate(
      outcome = as.integer(periodontitis_bin),
      analysis_weight = as.numeric(analysis_weight),
      vitd_nmol = as.numeric(vitd_nmol),
      age = as.numeric(age),
      bmi = as.numeric(bmi),
      pir = as.numeric(pir),
      missing_teeth_count = as.numeric(missing_teeth_count)
    ) |>
    filter(age >= 60, outcome %in% c(0L, 1L), is.finite(vitd_nmol), vitd_nmol > 0,
           is.finite(analysis_weight), analysis_weight > 0)

  if (is.null(main_levels)) {
    levels_map <- lapply(factor_vars, function(v) sort(unique(as.character(d[[v]][!is.na(d[[v]])]))))
    names(levels_map) <- factor_vars
  } else {
    levels_map <- main_levels
  }
  for (v in factor_vars) d[[v]] <- factor(as.character(d[[v]]), levels = levels_map[[v]])
  keep <- complete.cases(d[, c("outcome", "vitd_nmol", "analysis_weight", clinical_vars), drop = FALSE])
  list(data = droplevels(d[keep, , drop = FALSE]), levels = levels_map, excluded = sum(!keep), eligible = nrow(d))
}

main_prepared <- prepare_data(main_path)
external_prepared <- prepare_data(external_path, main_prepared$levels)
main <- main_prepared$data
external <- external_prepared$data

stopifnot(nrow(main) > 200, sum(main$outcome == 1) > 40)

formula_clinical <- as.formula(paste("outcome ~", paste(clinical_vars, collapse = " + ")))
formula_vitd <- update(formula_clinical, . ~ . + vitd_nmol)

fit_model <- function(formula, train) {
  train$.model_weight <- train$analysis_weight / mean(train$analysis_weight)
  suppressWarnings(glm(formula, data = train, family = binomial(), weights = .model_weight, control = glm.control(maxit = 100)))
}

predict_safe <- function(model, newdata) {
  p <- suppressWarnings(as.numeric(predict(model, newdata = newdata, type = "response")))
  pmin(pmax(p, 1e-6), 1 - 1e-6)
}

make_stratified_folds <- function(y, k = 5) {
  fold <- integer(length(y))
  for (g in sort(unique(y))) {
    idx <- which(y == g)
    fold[idx] <- sample(rep(seq_len(k), length.out = length(idx)))
  }
  fold
}

repeats <- 10L
k <- 5L
pred_sum_clinical <- numeric(nrow(main))
pred_sum_vitd <- numeric(nrow(main))
fold_manifest <- vector("list", repeats)

for (r in seq_len(repeats)) {
  set.seed(20260914 + r)
  fold <- make_stratified_folds(main$outcome, k)
  fold_manifest[[r]] <- tibble(participant_id = main$participant_id, repeat_id = r, fold = fold, outcome = main$outcome)
  for (f in seq_len(k)) {
    train <- main[fold != f, , drop = FALSE]
    test <- main[fold == f, , drop = FALSE]
    m0 <- fit_model(formula_clinical, train)
    m1 <- fit_model(formula_vitd, train)
    pred_sum_clinical[fold == f] <- pred_sum_clinical[fold == f] + predict_safe(m0, test)
    pred_sum_vitd[fold == f] <- pred_sum_vitd[fold == f] + predict_safe(m1, test)
  }
}

oof <- main |>
  transmute(
    participant_id, cycle, outcome, analysis_weight, vitd_nmol,
    clinical_probability = pred_sum_clinical / repeats,
    clinical_plus_vitd_probability = pred_sum_vitd / repeats
  )

weighted_brier <- function(y, p, w) weighted.mean((y - p)^2, w)

weighted_auc <- function(y, p, w) {
  case <- which(y == 1); ctrl <- which(y == 0)
  ord <- order(p)
  p2 <- p[ord]; y2 <- y[ord]; w2 <- w[ord]
  ctrl_cum <- cumsum(ifelse(y2 == 0, w2, 0))
  ctrl_before <- c(0, head(ctrl_cum, -1))
  tie_ctrl <- ave(ifelse(y2 == 0, w2, 0), p2, FUN = sum)
  num <- sum(ifelse(y2 == 1, w2 * (ctrl_before + 0.5 * tie_ctrl), 0))
  den <- sum(w[case]) * sum(w[ctrl])
  num / den
}

calibration_stats <- function(y, p, w, cohort, model) {
  lp <- qlogis(pmin(pmax(p, 1e-6), 1 - 1e-6))
  intercept_fit <- suppressWarnings(glm(y ~ 1 + offset(lp), family = binomial(), weights = w / mean(w)))
  slope_fit <- suppressWarnings(glm(y ~ lp, family = binomial(), weights = w / mean(w)))
  tibble(
    cohort = cohort, model = model,
    calibration_intercept = unname(coef(intercept_fit)[1]),
    calibration_slope = unname(coef(slope_fit)[2])
  )
}

metric_row <- function(d, p_col, cohort, model) {
  y <- d$outcome; p <- d[[p_col]]; w <- d$analysis_weight
  roc_obj <- suppressMessages(roc(y, p, quiet = TRUE, direction = "<"))
  ci_obj <- suppressMessages(ci.auc(roc_obj, method = "delong"))
  tibble(
    cohort = cohort, model = model, n = length(y), cases = sum(y == 1), controls = sum(y == 0),
    weighted_prevalence = weighted.mean(y, w),
    AUC_unweighted = as.numeric(auc(roc_obj)), AUC_CI_low = as.numeric(ci_obj[1]), AUC_CI_high = as.numeric(ci_obj[3]),
    AUC_weighted = weighted_auc(y, p, w), Brier_weighted = weighted_brier(y, p, w)
  ) |>
    left_join(calibration_stats(y, p, w, cohort, model), by = c("cohort", "model"))
}

metrics_internal <- bind_rows(
  metric_row(oof, "clinical_probability", "NHANES 2009-2014 repeated 5-fold OOF", "Clinical"),
  metric_row(oof, "clinical_plus_vitd_probability", "NHANES 2009-2014 repeated 5-fold OOF", "Clinical + 25(OH)D")
)

roc0 <- suppressMessages(roc(oof$outcome, oof$clinical_probability, quiet = TRUE, direction = "<"))
roc1 <- suppressMessages(roc(oof$outcome, oof$clinical_plus_vitd_probability, quiet = TRUE, direction = "<"))
delong <- suppressMessages(roc.test(roc0, roc1, paired = TRUE, method = "delong"))

set.seed(20260914)
boot_ids <- replicate(1000, sample(seq_len(nrow(oof)), replace = TRUE), simplify = FALSE)
boot_delta <- vapply(boot_ids, function(i) {
  d <- oof[i, , drop = FALSE]
  weighted_brier(d$outcome, d$clinical_plus_vitd_probability, d$analysis_weight) -
    weighted_brier(d$outcome, d$clinical_probability, d$analysis_weight)
}, numeric(1))

increment <- tibble(
  cohort = "NHANES 2009-2014 repeated 5-fold OOF",
  delta_AUC_unweighted = as.numeric(auc(roc1) - auc(roc0)),
  DeLong_p = delong$p.value,
  delta_Brier_weighted = metrics_internal$Brier_weighted[2] - metrics_internal$Brier_weighted[1],
  delta_Brier_CI_low = quantile(boot_delta, 0.025, na.rm = TRUE),
  delta_Brier_CI_high = quantile(boot_delta, 0.975, na.rm = TRUE)
)

full0 <- fit_model(formula_clinical, main)
full1 <- fit_model(formula_vitd, main)
external_pred <- external |>
  transmute(
    participant_id, cycle, outcome, analysis_weight, vitd_nmol,
    clinical_probability = predict_safe(full0, external),
    clinical_plus_vitd_probability = predict_safe(full1, external)
  ) |>
  filter(is.finite(clinical_probability), is.finite(clinical_plus_vitd_probability))

metrics_external <- bind_rows(
  metric_row(external_pred, "clinical_probability", "NHANES 2001-2004 temporal check", "Clinical"),
  metric_row(external_pred, "clinical_plus_vitd_probability", "NHANES 2001-2004 temporal check", "Clinical + 25(OH)D")
)

metrics <- bind_rows(metrics_internal, metrics_external)

roc_curve_data <- function(d, p_col, model, cohort) {
  ro <- suppressMessages(roc(d$outcome, d[[p_col]], quiet = TRUE, direction = "<"))
  tibble(fpr = 1 - ro$specificities, tpr = ro$sensitivities, model = model, cohort = cohort)
}
roc_data <- bind_rows(
  roc_curve_data(oof, "clinical_probability", "Clinical", "Internal"),
  roc_curve_data(oof, "clinical_plus_vitd_probability", "Clinical + 25(OH)D", "Internal"),
  roc_curve_data(external_pred, "clinical_probability", "Clinical", "Temporal"),
  roc_curve_data(external_pred, "clinical_plus_vitd_probability", "Clinical + 25(OH)D", "Temporal")
)

calibration_bins <- function(d, p_col, model, cohort) {
  d |>
    transmute(outcome, analysis_weight, probability = .data[[p_col]]) |>
    mutate(bin = ntile(probability, 10)) |>
    group_by(bin) |>
    summarise(
      predicted = weighted.mean(probability, analysis_weight),
      observed = weighted.mean(outcome, analysis_weight), n = n(),
      .groups = "drop"
    ) |>
    mutate(model = model, cohort = cohort)
}
calibration <- bind_rows(
  calibration_bins(oof, "clinical_probability", "Clinical", "Internal"),
  calibration_bins(oof, "clinical_plus_vitd_probability", "Clinical + 25(OH)D", "Internal"),
  calibration_bins(external_pred, "clinical_probability", "Clinical", "Temporal"),
  calibration_bins(external_pred, "clinical_plus_vitd_probability", "Clinical + 25(OH)D", "Temporal")
)

dca_one <- function(d, p_col, model, cohort) {
  thresholds <- seq(0.05, 0.50, by = 0.01)
  y <- d$outcome; p <- d[[p_col]]; w <- d$analysis_weight
  W <- sum(w); prev <- weighted.mean(y, w)
  bind_rows(lapply(thresholds, function(pt) {
    positive <- p >= pt
    tp <- sum(w * (positive & y == 1)); fp <- sum(w * (positive & y == 0))
    tibble(threshold = pt, net_benefit = tp / W - fp / W * pt / (1 - pt), strategy = model, cohort = cohort,
           treat_all = prev - (1 - prev) * pt / (1 - pt))
  }))
}
dca <- bind_rows(
  dca_one(oof, "clinical_probability", "Clinical", "Internal"),
  dca_one(oof, "clinical_plus_vitd_probability", "Clinical + 25(OH)D", "Internal"),
  dca_one(external_pred, "clinical_probability", "Clinical", "Temporal"),
  dca_one(external_pred, "clinical_plus_vitd_probability", "Clinical + 25(OH)D", "Temporal")
)

write_excel_csv(oof, file.path(source_dir, "01_NHANES2009-2014_\u91cd\u590d\u4e94\u6298\u4ea4\u53c9\u9a8c\u8bc1_\u6837\u672c\u5916\u9884\u6d4b.csv"), na = "")
write_excel_csv(bind_rows(fold_manifest), file.path(source_dir, "02_\u91cd\u590d\u4e94\u6298\u4ea4\u53c9\u9a8c\u8bc1_\u6298\u6b21\u6e05\u5355.csv"), na = "")
write_excel_csv(metrics, file.path(source_dir, "03_\u4e34\u5e8a\u6a21\u578b\u4e0e\u7ef4\u751f\u7d20D\u589e\u91cf\u4ef7\u503c_\u6027\u80fd\u6307\u6807.csv"), na = "")
write_excel_csv(increment, file.path(source_dir, "04_\u7ef4\u751f\u7d20D\u589e\u91cf\u4ef7\u503c_\u914d\u5bf9\u68c0\u9a8c.csv"), na = "")
write_excel_csv(calibration, file.path(source_dir, "05_\u6821\u51c6\u66f2\u7ebf\u6570\u636e.csv"), na = "")
write_excel_csv(dca, file.path(source_dir, "06_DCA\u51c0\u83b7\u76ca\u6570\u636e.csv"), na = "")
write_excel_csv(external_pred, file.path(source_dir, "07_NHANES2001-2004_\u65f6\u95f4\u5916\u90e8\u6838\u67e5\u9884\u6d4b.csv"), na = "")

colors <- c("Clinical" = "#4A8FD4", "Clinical + 25(OH)D" = "#C9403B")
theme_npj <- function() {
  theme_classic(base_family = "Arial", base_size = 8) +
    theme(
      strip.background = element_rect(fill = "#E4E6EB", colour = NA),
      strip.text = element_text(face = "bold", size = 9, colour = "black", margin = margin(3, 4, 3, 4)),
      axis.title = element_text(size = 8, colour = "black"),
      axis.text = element_text(size = 7, colour = "black"),
      legend.title = element_blank(), legend.text = element_text(size = 7),
      legend.position = "bottom", plot.margin = margin(8, 8, 8, 8)
    )
}

internal_aucs <- metrics |> filter(grepl("2009-2014", cohort))
roc_label <- sprintf(
  "Clinical AUC %.3f; +25(OH)D %.3f\nDelta AUC %.3f; DeLong p=%s",
  internal_aucs$AUC_unweighted[internal_aucs$model == "Clinical"],
  internal_aucs$AUC_unweighted[internal_aucs$model == "Clinical + 25(OH)D"],
  increment$delta_AUC_unweighted,
  ifelse(increment$DeLong_p < 0.001, "<0.001", sprintf("%.3f", increment$DeLong_p))
)

pA <- roc_data |>
  filter(cohort == "Internal") |>
  mutate(panel = "Internal discrimination") |>
  ggplot(aes(fpr, tpr, colour = model)) +
  geom_abline(slope = 1, intercept = 0, linetype = 2, colour = "grey65", linewidth = 0.35) +
  geom_line(linewidth = 0.8) +
  annotate("text", x = 0.05, y = 0.05, label = roc_label, hjust = 0, vjust = 0, size = 2.6) +
  facet_wrap(~panel) + coord_cartesian(xlim = c(0, 1), ylim = c(0, 1), expand = FALSE) +
  scale_colour_manual(values = colors, name = "Model") +
  labs(x = "1 - Specificity", y = "Sensitivity") + theme_npj()

pB <- calibration |>
  filter(cohort == "Internal") |>
  mutate(panel = "Internal calibration") |>
  ggplot(aes(predicted, observed, colour = model)) +
  geom_abline(slope = 1, intercept = 0, linetype = 2, colour = "grey65", linewidth = 0.35) +
  geom_line(linewidth = 0.65) + geom_point(size = 1.7, show.legend = FALSE) +
  facet_wrap(~panel) + coord_cartesian(xlim = c(0, 1), ylim = c(0, 1), expand = FALSE) +
  scale_colour_manual(values = colors, name = "Model") +
  guides(colour = "none") +
  labs(x = "Predicted probability", y = "Observed proportion") + theme_npj()

pC <- dca |>
  filter(cohort == "Internal") |>
  mutate(panel = "Internal decision curves") |>
  ggplot(aes(threshold, net_benefit, colour = strategy)) +
  geom_hline(yintercept = 0, colour = "grey65", linewidth = 0.35) +
  geom_line(aes(y = treat_all), colour = "grey40", linetype = 2, linewidth = 0.45) +
  geom_line(linewidth = 0.8) +
  facet_wrap(~panel) + scale_colour_manual(values = colors, name = "Model") +
  guides(colour = "none") +
  labs(x = "Threshold probability", y = "Net benefit") + theme_npj()

external_aucs <- metrics |> filter(grepl("2001-2004", cohort))
external_label <- sprintf(
  "Clinical AUC %.3f; +25(OH)D %.3f\nProtocol differs; transportability only",
  external_aucs$AUC_unweighted[external_aucs$model == "Clinical"],
  external_aucs$AUC_unweighted[external_aucs$model == "Clinical + 25(OH)D"]
)
pD <- roc_data |>
  filter(cohort == "Temporal") |>
  mutate(panel = "Temporal ROC (2001-2004)") |>
  ggplot(aes(fpr, tpr, colour = model)) +
  geom_abline(slope = 1, intercept = 0, linetype = 2, colour = "grey65", linewidth = 0.35) +
  geom_line(linewidth = 0.8) +
  annotate("text", x = 0.05, y = 0.05, label = external_label, hjust = 0, vjust = 0, size = 2.5) +
  facet_wrap(~panel) + coord_cartesian(xlim = c(0, 1), ylim = c(0, 1), expand = FALSE) + scale_colour_manual(values = colors, name = "Model") +
  guides(colour = "none") +
  labs(x = "1 - Specificity", y = "Sensitivity") + theme_npj()

combined <- wrap_plots(pA, pB, pC, pD, ncol = 2, widths = c(1, 1), heights = c(1, 1), guides = "collect") +
  plot_annotation(tag_levels = "A", theme = theme(plot.tag = element_text(family = "Arial", face = "bold", size = 12, colour = "black"))) &
  theme(legend.position = "bottom")

pdf_file <- file.path(figure_dir, "\u7b2c10\u9879_NHANES\u4e34\u5e8a\u6a21\u578b\u4e0e\u7ef4\u751f\u7d20D\u589e\u91cf\u4ef7\u503c_20260914.pdf")
png_file <- file.path(figure_dir, "\u7b2c10\u9879_NHANES\u4e34\u5e8a\u6a21\u578b\u4e0e\u7ef4\u751f\u7d20D\u589e\u91cf\u4ef7\u503c_20260914.png")
ggsave(pdf_file, combined, width = 7.09, height = 6.0, units = "in", device = cairo_pdf)
ragg::agg_png(png_file, width = 7.09, height = 6.0, units = "in", res = 600, background = "white")
print(combined)
dev.off()

qa <- list(
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
  source_files = c(main_path, external_path),
  clinical_predictors = clinical_vars,
  internal = list(n = nrow(main), cases = sum(main$outcome == 1), controls = sum(main$outcome == 0), repeats = repeats, folds = k),
  temporal = list(n = nrow(external_pred), cases = sum(external_pred$outcome == 1), controls = sum(external_pred$outcome == 0)),
  checks = list(
    participant_out_of_fold_once_per_repeat = nrow(bind_rows(fold_manifest)) == nrow(main) * repeats,
    probabilities_finite = all(is.finite(oof$clinical_probability)) && all(is.finite(oof$clinical_plus_vitd_probability)),
    no_outcome_assisted_model_selection = TRUE,
    figure_pdf_nonempty = file.exists(pdf_file) && file.info(pdf_file)$size > 0,
    figure_png_nonempty = file.exists(png_file) && file.info(png_file)$size > 0
  ),
  caution = "NHANES 2001-2004 used a different periodontal examination protocol; temporal results assess transportability only and are not a strict external validation."
)
write_json(qa, file.path(qa_dir, "P10_QA_report.json"), pretty = TRUE, auto_unbox = TRUE)

m_int <- metrics_internal
m_ext <- metrics_external
summary_lines <- c(
  "# \u7b2c10\u9879\uff1aNHANES \u4e34\u5e8a\u6a21\u578b\u4e0e\u7ef4\u751f\u7d20D\u589e\u91cf\u4ef7\u503c \u2014 \u7ed3\u679c\u6458\u8981",
  "",
  "> \u4e3b\u5206\u6790\uff1aNHANES 2009\u20132014\uff0c\u5e74\u9f84\u226560\u5c81\uff1b\u56fa\u5b9a\u4e34\u5e8a\u53d8\u91cf\u6a21\u578b\u4e0e\u5176\u52a0\u5165\u8840\u6e0525(OH)D\u540e\u7684\u6a21\u578b\u8fdb\u884c10\u6b21\u91cd\u590d5\u6298\u4ea4\u53c9\u9a8c\u8bc1\uff0c\u6240\u6709\u6027\u80fd\u5747\u6765\u81ea\u6837\u672c\u5916\u9884\u6d4b\u3002",
  "> \u65f6\u95f4\u6838\u67e5\uff1aNHANES 2001\u20132004\u4ec5\u4f5c\u53ef\u8fc1\u79fb\u6027\u6838\u67e5\uff1b\u7259\u5468\u68c0\u67e5\u65b9\u6848\u4e0d\u540c\uff0c\u4e0d\u80fd\u79f0\u4e3a\u4e25\u683c\u72ec\u7acb\u5916\u90e8\u9a8c\u8bc1\u3002",
  sprintf("> \u8f93\u51fa\u56fe\uff1a`P10_NHANES\u4e34\u5e8a\u652f\u6301/outputs/figures/%s`\uff08PDF\u77e2\u91cf + PNG 600 dpi\uff0cGe et al. npj Digital Medicine 2026\u7248\u5f0f\uff09", basename(pdf_file)),
  "",
  "## \u4e3b\u8981\u7ed3\u679c",
  "",
  "| \u6570\u636e | \u6a21\u578b | n\uff08\u75c5\u4f8b\uff09 | AUC\uff0895%CI\uff09 | \u52a0\u6743Brier | \u6821\u51c6\u622a\u8ddd | \u6821\u51c6\u659c\u7387 |",
  "|---|---|---:|---:|---:|---:|---:|",
  sprintf("| 2009\u20132014 \u91cd\u590d5\u6298\u6837\u672c\u5916 | \u4e34\u5e8a | %d\uff08%d\uff09 | %.3f\uff08%.3f\u2013%.3f\uff09 | %.3f | %.3f | %.3f |", m_int$n[1], m_int$cases[1], m_int$AUC_unweighted[1], m_int$AUC_CI_low[1], m_int$AUC_CI_high[1], m_int$Brier_weighted[1], m_int$calibration_intercept[1], m_int$calibration_slope[1]),
  sprintf("| 2009\u20132014 \u91cd\u590d5\u6298\u6837\u672c\u5916 | \u4e34\u5e8a+25(OH)D | %d\uff08%d\uff09 | %.3f\uff08%.3f\u2013%.3f\uff09 | %.3f | %.3f | %.3f |", m_int$n[2], m_int$cases[2], m_int$AUC_unweighted[2], m_int$AUC_CI_low[2], m_int$AUC_CI_high[2], m_int$Brier_weighted[2], m_int$calibration_intercept[2], m_int$calibration_slope[2]),
  sprintf("| 2001\u20132004 \u65f6\u95f4\u6838\u67e5 | \u4e34\u5e8a | %d\uff08%d\uff09 | %.3f\uff08%.3f\u2013%.3f\uff09 | %.3f | %.3f | %.3f |", m_ext$n[1], m_ext$cases[1], m_ext$AUC_unweighted[1], m_ext$AUC_CI_low[1], m_ext$AUC_CI_high[1], m_ext$Brier_weighted[1], m_ext$calibration_intercept[1], m_ext$calibration_slope[1]),
  sprintf("| 2001\u20132004 \u65f6\u95f4\u6838\u67e5 | \u4e34\u5e8a+25(OH)D | %d\uff08%d\uff09 | %.3f\uff08%.3f\u2013%.3f\uff09 | %.3f | %.3f | %.3f |", m_ext$n[2], m_ext$cases[2], m_ext$AUC_unweighted[2], m_ext$AUC_CI_low[2], m_ext$AUC_CI_high[2], m_ext$Brier_weighted[2], m_ext$calibration_intercept[2], m_ext$calibration_slope[2]),
  "",
  sprintf("\u5185\u90e8\u6837\u672c\u5916\u6bd4\u8f83\uff1a\u0394AUC=%.3f\uff08DeLong p=%s\uff09\uff1b\u0394\u52a0\u6743Brier=%.4f\uff0895%% bootstrap CI %.4f\u2013%.4f\uff1b\u8d1f\u503c\u8868\u793a\u52a0\u516525(OH)D\u540e\u6539\u5584\uff09\u3002", increment$delta_AUC_unweighted, ifelse(increment$DeLong_p < 0.001, "<0.001", sprintf("%.3f", increment$DeLong_p)), increment$delta_Brier_weighted, increment$delta_Brier_CI_low, increment$delta_Brier_CI_high),
  "",
  "## \u89e3\u91ca\u8fb9\u754c",
  "",
  "1. \u672c\u7ed3\u679c\u53ea\u68c0\u9a8c25(OH)D\u5728\u56fa\u5b9a\u4e34\u5e8a\u53d8\u91cf\u4e4b\u4e0a\u7684\u589e\u91cf\u9884\u6d4b\u4ef7\u503c\uff0c\u4e0d\u8bc1\u660e\u8865\u5145\u7ef4\u751f\u7d20D\u5177\u6709\u6cbb\u7597\u6548\u679c\u3002",
  "2. \u4e3b\u6027\u80fd\u6765\u81ea\u91cd\u590d\u4ea4\u53c9\u9a8c\u8bc1\u7684\u6837\u672c\u5916\u9884\u6d4b\uff1b\u672a\u4f7f\u7528\u6d4b\u8bd5\u7ed3\u5c40\u9009\u62e9\u6a21\u578b\u3001\u9608\u503c\u6216\u8d85\u53c2\u6570\u3002",
  "3. 2001\u20132004\u7259\u5468\u68c0\u67e5\u65b9\u6848\u4e0e2009\u20132014\u4e0d\u540c\uff0c\u56e0\u6b64\u53ea\u80fd\u4f5c\u4e3a\u65f6\u95f4\u53ef\u8fc1\u79fb\u6027\u6838\u67e5\u3002",
  "4. DCA\u51c0\u83b7\u76ca\u53ea\u8868\u793a\u9884\u6d4b\u51b3\u7b56\u5c42\u9762\u7684\u6f5c\u5728\u7528\u9014\uff0c\u4e0d\u7b49\u4e8e\u4e34\u5e8a\u7597\u6548\u3002",
  "",
  "## \u590d\u73b0",
  "",
  "```bash",
  "Rscript P10_NHANES\u4e34\u5e8a\u652f\u6301/scripts/P10_01_\u4e34\u5e8a\u6a21\u578b\u4e0e\u7ef4\u751f\u7d20D\u589e\u91cf\u4ef7\u503c.R",
  "```"
)
writeLines(summary_lines, file.path(doc_dir, "\u7b2c10\u9879_NHANES\u4e34\u5e8a\u652f\u6301_\u7ed3\u679c\u6458\u8981.md"), useBytes = TRUE)

cat("P10 complete\n")
print(metrics)
print(increment)
