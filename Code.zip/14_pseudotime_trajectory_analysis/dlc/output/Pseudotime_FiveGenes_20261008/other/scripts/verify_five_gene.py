import csv
import gzip
import hashlib
import json
import math
from pathlib import Path
from PIL import Image, ImageChops
import pymupdf
root = Path(__file__).resolve().parents[2]
figdir = root / '\u56fe'
data = root / '\u5176\u4ed6' / 'source_data'
qa = root / '\u5176\u4ed6' / 'QA'
oldroot = root.parent / 'Pseudotime_GO0070371_GO0022617_20261008'
stem = 'Williams_gingival_fibroblast_pseudotime_FiveGenes_20261008'
with Image.open(figdir / f'{stem}.png') as im:
    assert im.size == (7200, 8508)
    dpi = im.info['dpi']
    assert all((abs(v - 600) < 0.1 for v in dpi))
    with Image.open(oldroot / '\u56fe' / 'Williams_gingival_fibroblast_pseudotime_GO_20261008_EFG_equal_squares.png') as prior:
        region = (0, 0, 7200, 1807)
        assert ImageChops.difference(im.crop(region).convert('RGB'), prior.crop(region).convert('RGB')).getbbox() is None
with Image.open(figdir / f'{stem}.tiff') as im:
    assert im.size == (7200, 8508)
doc = pymupdf.open(figdir / f'{stem}.pdf')
assert len(doc) == 1
page = doc[0]
spans = [s for b in page.get_text('dict')['blocks'] for line in b.get('lines', []) for s in line['spans']]
text = page.get_text()
for term in ['GDF15', 'MMP1', 'MMP3', 'ERK1', 'ERK2', 'MAPK1', 'MAPK3', 'GO:0070371', 'GO:0022617']:
    assert term in text, term
assert not any((s['text'].strip() == 'H' for s in spans))
assert 'JUND' not in text and '-log10 FDR' not in text
for s in spans:
    x0, y0, x1, y1 = s['bbox']
    assert x0 >= -0.5 and y0 >= -0.5 and (x1 <= page.rect.width + 0.5) and (y1 <= page.rect.height + 0.5), s
fonts = page.get_fonts()
assert fonts and all(('Arial' in f[3] and doc.extract_font(f[0])[3] for f in fonts))
fdr_spans = [s for s in spans if s['text'].startswith(('L1 FDR', 'L2 FDR'))]
assert len(fdr_spans) == 10, [s['text'] for s in fdr_spans]
for s in fdr_spans:
    assert s['color'] == (2980007 if s['text'].startswith('L1') else 15242549), s
borders = []
for d in page.get_drawings():
    if d['color'] is None or any((abs(c - 119 / 255) > 0.015 for c in d['color'])):
        continue
    for item in d['items']:
        if item[0] == 're':
            r = item[1]
            if r.width > 30 and r.height > 30 and (r.y0 > 433):
                z = tuple((round(v, 3) for v in r))
                if z not in borders:
                    borders.append(z)
ef = [r for r in borders if r[1] < 790]
assert len(ef) == 10, borders
assert all((abs((r[2] - r[0]) * 25.4 / 72 - 48) < 0.02 and abs((r[3] - r[1]) * 25.4 / 72 - 48) < 0.02 for r in ef))
assert len({round(r[1], 1) for r in ef}) == 2
with open(data / 'five_gene_donor_aware_GAM_results.csv', encoding='utf-8') as f:
    models = list(csv.DictReader(f))
assert len(models) == 20
assert all((r['converged'] == 'TRUE' and int(r['n_donors']) == 18 and math.isfinite(float(r['smooth_FDR'])) for r in models))
for metric in ['Detection', 'Expression']:
    rows = sorted((r for r in models if r['metric'] == metric), key=lambda r: float(r['smooth_p']))
    assert len(rows) == 10
    q = 1
    for i in range(9, -1, -1):
        q = min(q, float(rows[i]['smooth_p']) * 10 / (i + 1))
        assert abs(q - float(rows[i]['smooth_FDR'])) < 1e-12
for name in ['33_pseudotime_lineage_definitions.csv', '34_pseudotime_curve_coordinates.csv', '36_pseudotime_state_positions.csv']:
    assert hashlib.sha256((data / name).read_bytes()).digest() == hashlib.sha256((oldroot / '\u5176\u4ed6' / 'source_data' / name).read_bytes()).digest()
with gzip.open(data / '32_pseudotime_cell_assignments.csv.gz', 'rt', encoding='utf-8') as f:
    cells = list(csv.DictReader(f))
with open(data / 'five_gene_detection_coverage.csv', encoding='utf-8') as f:
    coverage = list(csv.DictReader(f))
assert len(cells) == 14302 and len(coverage) == 5
for r in coverage:
    gene = r['gene']
    assert sum((int(c[gene + '_detection']) for c in cells)) == int(r['n_positive_cells'])
    assert all((int(c[gene + '_detection']) == int(float(c[gene]) > 0) for c in cells))
assert next((int(r['n_positive_cells']) for r in coverage if r['gene'] == 'MMP1')) == 359
assert next((int(r['n_positive_cells']) for r in coverage if r['gene'] == 'MMP3')) == 1041
page.get_pixmap(matrix=pymupdf.Matrix(2, 2)).save(qa / 'pdf_render.png')
report = dict(pass_=True, png_size=[7200, 8508], png_dpi=dpi, pdf_pages=1, first_row_pixel_identical=True, E_F_five_square_panels_each=True, E_F_side_mm=48, FDR_labels=10, FDR_colors_match_paths=True, donor_models_converged=20, n_donors=18, BH_separate_detection_and_expression_verified=True, trajectory_files_unchanged=True, n_cells=14302, gene_detection_verified=True, fonts=[f[3] for f in fonts], all_text_within_page=True)
(qa / 'figure_analysis_QA.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report))
