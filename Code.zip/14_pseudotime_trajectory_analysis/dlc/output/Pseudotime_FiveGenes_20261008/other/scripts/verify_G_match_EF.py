from pathlib import Path
import json
from PIL import Image, ImageChops
import pymupdf
root = Path(__file__).resolve().parents[2]
figs = root / '\u56fe'
qa = root / '\u5176\u4ed6' / 'QA'
base = 'Williams_gingival_fibroblast_pseudotime_FiveGenes_20261008'
stem = base + '_G_match_EF'
with Image.open(figs / f'{base}.png') as prior, Image.open(figs / f'{stem}.png') as revised:
    assert prior.size == revised.size == (7200, 8508)
    region = (0, 0, 7200, 6608)
    assert ImageChops.difference(prior.crop(region).convert('RGB'), revised.crop(region).convert('RGB')).getbbox() is None
doc = pymupdf.open(figs / f'{stem}.pdf')
assert len(doc) == 1
page = doc[0]
borders = []
for drawing in page.get_drawings():
    if drawing['color'] is None or any((abs(c - 119 / 255) > 0.015 for c in drawing['color'])):
        continue
    for item in drawing['items']:
        if item[0] == 're':
            r = item[1]
            if r.width > 30 and r.height > 30 and (r.y0 > 433):
                coords = tuple((round(v, 3) for v in r))
                if coords not in borders:
                    borders.append(coords)
assert len(borders) == 12, borders
assert all((abs((r[2] - r[0]) * 25.4 / 72 - 48) < 0.02 and abs((r[3] - r[1]) * 25.4 / 72 - 48) < 0.02 for r in borders))
for block in page.get_text('dict')['blocks']:
    for line in block.get('lines', []):
        for span in line['spans']:
            x0, y0, x1, y1 = span['bbox']
            assert x0 >= -0.5 and y0 >= -0.5 and (x1 <= page.rect.width + 0.5) and (y1 <= page.rect.height + 0.5)
assert all(('Arial' in f[3] and doc.extract_font(f[0])[3] for f in page.get_fonts()))
page.get_pixmap(matrix=pymupdf.Matrix(2, 2)).save(qa / 'pdf_render_G_match_EF.png')
report = dict(passed=True, A_to_F_pixel_identical=True, E_F_G_square_panels=12, all_panel_sides_mm=48, all_text_within_page=True)
(qa / 'G_match_EF_QA.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report))
