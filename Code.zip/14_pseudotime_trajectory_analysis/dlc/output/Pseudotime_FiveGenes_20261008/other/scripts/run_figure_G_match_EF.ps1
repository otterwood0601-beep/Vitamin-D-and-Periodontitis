$ErrorActionPreference = 'Stop'
$figureProject = (Get-Item -LiteralPath $PSScriptRoot).Parent.Parent.FullName
$figureStage = Join-Path $env:TEMP 'pseudotime_FiveGenes_20261008_G_match_EF_reproduce'
New-Item -ItemType Directory -Path (Join-Path $figureStage 'source_data'),(Join-Path $figureStage 'figures') -Force | Out-Null
Get-ChildItem -LiteralPath (Join-Path $figureProject "$([char]0x5176)$([char]0x4ED6)\source_data") -File | Copy-Item -Destination (Join-Path $figureStage 'source_data')
Copy-Item -LiteralPath (Join-Path $PSScriptRoot '05_pseudotime_figure_G_match_EF.R') -Destination (Join-Path $figureStage 'figure.R')
$env:DLC_ANALYSIS_DIR=(Join-Path $figureStage 'source_data').Replace('\','/')
$env:DLC_FIGURE_OUT=(Join-Path $figureStage 'figures').Replace('\','/')
$env:DLC_FIGURE_RASTER_OUT=$env:DLC_FIGURE_OUT
$env:DLC_PSEUDOTIME_GO_MODE='1'
$env:DLC_HIDE_UMAP_ISOLATED='1'
$env:DLC_EQUAL_UMAP_PANELS='1'
$env:DLC_LEGEND_LAYOUT_V2='1'
$env:DLC_A_LEGEND_RIGHT='1'
$env:DLC_A_BLOCK_LEFT='1'
$env:DLC_REMOVE_PANEL_TITLES='1'
$env:DLC_FINAL_CG_LAYOUT='1'
$env:DLC_SQUARE_EG_MATCH_F='1'
$env:DLC_FIVE_GENE_MODE='1'
$env:DLC_MATCH_G_TO_EF='1'
& 'C:\Program Files\R\R-4.5.3\bin\Rscript.exe' (Join-Path $figureStage 'figure.R')
if ($LASTEXITCODE -ne 0) { throw 'Figure rendering failed' }
Get-ChildItem -LiteralPath (Join-Path $figureStage 'figures') -Filter 'Williams*FiveGenes*' | Copy-Item -Destination (Join-Path $figureProject "$([char]0x56FE)")
