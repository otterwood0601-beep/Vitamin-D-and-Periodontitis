from pathlib import Path
import csv
import json
from PIL import Image, ImageChops
import pymupdf
root = Path(__file__).resolve().parents[2]
figs, qa = (root / '\u56fe', root / '\u5176\u4ed6' / 'QA')
prior_stem = 'Williams_gingival_fibroblast_pseudotime_FiveGenes_20261008_G_match_EF_C_stack_20261009'
stem = 'Williams_gingival_fibroblast_pseudotime_FiveGenes_compact_CDG_20261009'
with Image.open(figs / f'{prior_stem}.png') as prior, Image.open(figs / f'{stem}.png') as revised:
    assert prior.size == (7200, 8508) and revised.size == (7200, 6508)
    assert ImageChops.difference(prior.crop((0, 0, 7200, 1807)).convert('RGB'), revised.crop((0, 0, 7200, 1807)).convert('RGB')).getbbox() is None
    ef_diff = ImageChops.difference(prior.crop((0, 3608, 7200, 6608)).convert('RGB'), revised.crop((0, 3508, 7200, 6508)).convert('RGB'))
    assert ef_diff.getbbox() is None, ef_diff.getbbox()
layout = list(csv.DictReader((qa / 'compact_CDG_layout_QA.csv').open(encoding='utf-8')))
assert [r['panel'] for r in layout] == ['C', 'D', 'G']
for left, right in zip(layout, layout[1:]):
    assert float(right['left_mm']) - float(left['left_mm']) - float(left['width_mm']) >= 2.99
doc = pymupdf.open(figs / f'{stem}.pdf')
assert len(doc) == 1
page = doc[0]
borders = []
for drawing in page.get_drawings():
    if drawing['color'] is None or any((abs(c - 119 / 255) > 0.015 for c in drawing['color'])):
        continue
    for item in drawing['items']:
        if item[0] == 're' and item[1].width > 30 and (item[1].height > 30):
            coords = tuple((round(v, 3) for v in item[1]))
            if coords not in borders:
                borders.append(coords)
rect_dims = [(r, (r[2] - r[0]) * 25.4 / 72, (r[3] - r[1]) * 25.4 / 72) for r in borders]
squares = [r for r, w, h in rect_dims if abs(w - 48) < 0.02 and abs(h - 48) < 0.02]
halfpanels = [r for r, w, h in rect_dims if abs(w - 48) < 0.02 and abs(h - 24) < 0.02]
assert len(squares) == 12, rect_dims
assert len(halfpanels) == 2
assert abs(halfpanels[0][0] - halfpanels[1][0]) < 0.02
assert sum((216 < r[1] < 421 for r in squares)) == 2, squares
assert len(borders) == 15, borders
for block in page.get_text('dict')['blocks']:
    for line in block.get('lines', []):
        for span in line['spans']:
            x0, y0, x1, y1 = span['bbox']
            assert x0 >= -0.5 and y0 >= -0.5 and (x1 <= page.rect.width + 0.5) and (y1 <= page.rect.height + 0.5), span
assert all(('Arial' in f[3] and doc.extract_font(f[0])[3] for f in page.get_fonts()))
page.get_pixmap(matrix=pymupdf.Matrix(2, 2)).save(qa / 'pdf_render_compact_CDG_20261009.png')
report = dict(passed=True, first_row_pixel_identical=True, E_F_pixel_identical_after_translation=True, C_D_G_same_row=True, intergroup_gap_mm=3, C_panel_dimensions_mm=[48, 24], E_F_G_square_panels=12, E_F_G_panel_side_mm=48, canvas_px=[7200, 6508], removed_canvas_height_px=2000, all_text_within_page=True)
(qa / 'compact_CDG_20261009_QA.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report))
