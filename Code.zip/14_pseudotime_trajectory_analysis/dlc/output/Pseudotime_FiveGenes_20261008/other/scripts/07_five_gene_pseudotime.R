options(stringsAsFactors = FALSE)
set.seed(20261008L)
.libPaths(c('C:/Users/Lin/R/win-library/4.5', 'C:/Users/Lin/AppData/Local/R/win-library/4.5', .libPaths()))
suppressPackageStartupMessages({library(data.table); library(Seurat); library(mgcv); library(jsonlite)})
OLD <- 'C:/wb_links/pseudotime_go20261008/source_data'
OUT <- Sys.getenv('DLC_FIVE_GENE_DATA')
stopifnot(nzchar(OUT))
dir.create(OUT, recursive = TRUE, showWarnings = FALSE)
genes <- c('GDF15', 'MMP1', 'MMP3', 'MAPK3', 'MAPK1')
cell <- fread(file.path(OLD, '32_pseudotime_cell_assignments.csv.gz'))
defs <- fread(file.path(OLD, '33_pseudotime_lineage_definitions.csv'))
stopifnot(nrow(cell) == 14302L, uniqueN(cell$donor_key) == 18L, !anyDuplicated(cell$cell_id))
cat('[1/4] Extract five genes from the existing RNA assay\n')
fb <- readRDS('C:/wb_links/dlc_data/outputs/fb_seurat_annotated.rds')
counts <- LayerData(fb, assay = 'RNA', layer = 'counts')[genes, cell$cell_id, drop = FALSE]
expr <- LayerData(fb, assay = 'RNA', layer = 'data')[genes, cell$cell_id, drop = FALSE]
stopifnot(identical(colnames(expr), cell$cell_id), identical(rownames(expr), genes))
for (v in c('GDF15', 'MAPK1', 'MAPK3')) {
  stopifnot(isTRUE(all.equal(as.numeric(expr[v, ]), cell[[v]], tolerance = 1e-10)))
}
for (v in genes) {
  cell[[v]] <- as.numeric(expr[v, ])
  cell[[paste0(v, '_detection')]] <- as.integer(counts[v, ] > 0)
  stopifnot(identical(cell[[paste0(v, '_detection')]], as.integer(cell[[v]] > 0)))
}
fwrite(data.table(gene = genes, n_positive_cells = as.integer(Matrix::rowSums(counts > 0)),
                 n_cells = nrow(cell), detection_fraction = as.numeric(Matrix::rowMeans(counts > 0))),
       file.path(OUT, 'five_gene_detection_coverage.csv'))
rm(fb, counts, expr); gc()
fwrite(cell, file.path(OUT, '32_pseudotime_cell_assignments.csv.gz'))
for (f in c('33_pseudotime_lineage_definitions.csv', '34_pseudotime_curve_coordinates.csv',
            '36_pseudotime_state_positions.csv')) stopifnot(file.copy(file.path(OLD, f), file.path(OUT, f), overwrite = TRUE))
wmean <- function(x, w) {
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (!any(ok)) return(NA_real_)
  sum(x[ok] * w[ok]) / sum(w[ok])
}
det <- paste0(genes, '_detection')
features <- c(det, genes)
lins <- as.character(defs$lineage)
long <- lapply(lins, function(lin) {
  d <- copy(cell)
  d[, `:=`(lineage = lin, pseudotime_01 = get(paste0(lin, '_pseudotime_01')),
            lineage_weight = get(paste0(lin, '_weight')))]
  d <- d[is.finite(pseudotime_01) & is.finite(lineage_weight) & lineage_weight > 0.05]
  d[, pseudotime_bin := pmin(30L, floor(pseudotime_01 * 30) + 1L)]
  d
})
cat('[2/4] Calculate five-gene detection and normalized expression trends\n')
bins <- rbindlist(lapply(long, function(d) rbindlist(lapply(features, function(v) {
  z <- d[, .(value = wmean(get(v), lineage_weight), n_cells = .N,
              effective_weight = sum(lineage_weight),
              pseudotime_01 = wmean(pseudotime_01, lineage_weight),
              periodontitis_fraction = 100*wmean(as.integer(disease == 'periodontitis'), lineage_weight)),
          by = .(lineage, pseudotime_bin)]
  z[, feature := v]
  z
}))))
old_bins <- fread(file.path(OLD, '35_pseudotime_binned_trends.csv'))
for (v in c('GDF15_detection', 'MAPK1', 'MAPK3')) {
  x <- old_bins[feature == v][order(lineage, pseudotime_bin)]
  y <- bins[feature == v][order(lineage, pseudotime_bin)]
  stopifnot(isTRUE(all.equal(x$value, y$value, tolerance = 1e-12)),
            isTRUE(all.equal(x$pseudotime_01, y$pseudotime_01, tolerance = 1e-12)))
}
bins <- rbind(bins, old_bins[feature %in% c('ERK_GO0070371', 'ECM_GO0022617')])
fwrite(bins, file.path(OUT, '35_pseudotime_binned_trends.csv'))
fit_one <- function(d, v) {
  z <- d[, .(y = get(v), pt = pseudotime_01, w = lineage_weight, disease, Study, donor_key)]
  z <- z[is.finite(y) & is.finite(pt) & is.finite(w) & w > 0.05]
  z[, donor_pt_bin := pmin(6L, floor(pt * 6) + 1L)]
  a <- z[, .(y = wmean(y, w), pt = wmean(pt, w), effective_weight = sum(w), n_cells = .N),
           by = .(donor_key, disease, Study, donor_pt_bin)]
  a[, `:=`(disease = droplevels(factor(disease)), donor_key = droplevels(factor(donor_key)),
            Study = droplevels(factor(Study)))]
  a[, model_weight := sqrt(pmin(effective_weight, quantile(effective_weight, 0.90)))]
  fit <- mgcv::gam(y ~ s(pt, k = 5, bs = 'cr') + disease + s(donor_key, bs = 're'),
                   data = a, weights = model_weight, family = gaussian(), method = 'REML')
  sm <- summary(fit)$s.table
  ridx <- match('s(pt)', rownames(sm))
  ref <- data.table(pt = c(0, 1),
    disease = factor(rep(levels(a$disease)[1], 2), levels = levels(a$disease)),
    donor_key = factor(rep(levels(a$donor_key)[1], 2), levels = levels(a$donor_key)))
  pred <- as.numeric(predict(fit, newdata = ref, exclude = 's(donor_key)'))
  lin <- d$lineage[1]
  saveRDS(fit, file.path(OUT, paste0('model_', lin, '_', v, '.rds')))
  fwrite(a, file.path(OUT, paste0('model_units_', lin, '_', v, '.csv')))
  data.table(lineage = lin, feature = v, metric = if (v %in% det) 'Detection' else 'Expression',
    n_cells = nrow(z), n_donor_bin_units = nrow(a), n_donors = nlevels(a$donor_key),
    smooth_edf = sm[ridx, 'edf'], smooth_statistic = sm[ridx, 'F'], smooth_p = sm[ridx, 'p-value'],
    predicted_start = pred[1], predicted_end = pred[2], end_minus_start = pred[2] - pred[1],
    converged = fit$converged)
}
cat('[3/4] Fit donor-aware GAMs using the existing 18-donor definition\n')
res <- rbindlist(lapply(long, function(d) rbindlist(lapply(features, function(v) fit_one(d, v)))))
res[, smooth_FDR := p.adjust(smooth_p, method = 'BH'), by = metric]
res[, direction := fifelse(end_minus_start > 0, 'Increase', 'Decrease')]
stopifnot(nrow(res) == 20L, all(res$converged), all(is.finite(res$smooth_FDR)), all(res$n_donors == 18L))
fwrite(res, file.path(OUT, 'five_gene_donor_aware_GAM_results.csv'))
old_go <- fread(file.path(OLD, '37_pseudotime_donor_aware_GAM_results.csv'))[feature %in% c('ERK_GO0070371', 'ECM_GO0022617')]
fwrite(rbindlist(list(res, old_go), fill = TRUE), file.path(OUT, '37_pseudotime_donor_aware_GAM_results.csv'))
cat('[4/4] Save audit and analysis provenance\n')
manifest <- list(created_at = '2026-10-08', n_cells = nrow(cell), n_merged_donors = 18,
  genes_in_figure_order = genes, protein_name_mapping = list(ERK1 = 'MAPK3', ERK2 = 'MAPK1'),
  detection = 'Raw RNA count > 0; lineage-weighted positive-cell fraction',
  expression = 'Existing RNA data layer; lineage-weighted mean log-normalized expression over all cells',
  display = 'Existing 30 pseudotime bins and LOESS span 0.45 retained',
  inference = 'Same donor-by-6-bin gaussian REML GAM with disease and donor random effects',
  multiple_testing = 'BH separately across 10 detection tests and 10 expression tests; E labels use detection family',
  inherited_GO_scores = 'Original GO scores and curves retained; no rescoring',
  trajectories = 'Original root, UMAP coordinates and lineage assignments retained',
  all_models_converged = TRUE, old_GDF15_MAPK_bin_values_unchanged = TRUE)
writeLines(toJSON(manifest, pretty = TRUE, auto_unbox = TRUE), file.path(OUT, 'five_gene_analysis_manifest.json'))
print(res[, .(lineage, feature, metric, n_donors, smooth_FDR)])
cat('[DONE] Five-gene extension\n')
