from pathlib import Path
import json
from PIL import Image, ImageChops
import pymupdf
root = Path(__file__).resolve().parents[2]
figs, qa = (root / '\u56fe', root / '\u5176\u4ed6' / 'QA')
base = 'Williams_gingival_fibroblast_pseudotime_FiveGenes_20261008_G_match_EF'
stem = base + '_C_stack_20261009'
with Image.open(figs / f'{base}.png') as prior, Image.open(figs / f'{stem}.png') as revised:
    assert prior.size == revised.size == (7200, 8508)
    diff = ImageChops.difference(prior.convert('RGB'), revised.convert('RGB'))
    diff.paste((0, 0, 0), (0, 1807, 3705, 3609))
    assert diff.getbbox() is None, diff.getbbox()
doc = pymupdf.open(figs / f'{stem}.pdf')
page = doc[0]
borders = []
for drawing in page.get_drawings():
    if drawing['color'] is None or any((abs(c - 119 / 255) > 0.015 for c in drawing['color'])):
        continue
    for item in drawing['items']:
        if item[0] == 're' and item[1].width > 30 and (item[1].height > 30):
            coords = tuple((round(v, 3) for v in item[1]))
            if coords not in borders:
                borders.append(coords)
c_panels = sorted([r for r in borders if 216 < r[1] < 433 and r[0] < 444], key=lambda r: r[1])
assert len(c_panels) == 2, c_panels
assert all((abs((r[2] - r[0]) * 25.4 / 72 - 48) < 0.02 and abs((r[3] - r[1]) * 25.4 / 72 - 24) < 0.02 for r in c_panels))
assert abs(c_panels[0][0] - c_panels[1][0]) < 0.02
assert c_panels[0][3] < c_panels[1][1]
efg = [r for r in borders if r[1] > 433]
assert len(efg) == 12
assert all((abs((r[2] - r[0]) * 25.4 / 72 - 48) < 0.02 and abs((r[3] - r[1]) * 25.4 / 72 - 48) < 0.02 for r in efg))
for block in page.get_text('dict')['blocks']:
    for line in block.get('lines', []):
        for span in line['spans']:
            x0, y0, x1, y1 = span['bbox']
            assert x0 >= -0.5 and y0 >= -0.5 and (x1 <= page.rect.width + 0.5) and (y1 <= page.rect.height + 0.5)
assert all(('Arial' in f[3] and doc.extract_font(f[0])[3] for f in page.get_fonts()))
page.get_pixmap(matrix=pymupdf.Matrix(2, 2)).save(qa / 'pdf_render_C_stack_20261009.png')
report = dict(passed=True, all_other_panels_pixel_identical=True, C_panel_dimensions_mm=[48, 24], C_layout='L1 above L2', E_F_G_square_panel_count=12, E_F_G_panel_side_mm=48, all_text_within_page=True)
(qa / 'C_stack_20261009_QA.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report))
