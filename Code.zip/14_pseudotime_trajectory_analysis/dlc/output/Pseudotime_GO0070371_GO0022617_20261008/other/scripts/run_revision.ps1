$ErrorActionPreference = 'Stop'
$revisionRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$sourceDir = Join-Path $revisionRoot "$([char]0x5176)$([char]0x4ED6)\source_data"
$figDir = Join-Path $revisionRoot "$([char]0x56FE)"
$renderTmp = 'C:\Users\Lin\AppData\Local\Temp\pseudotime_GO20261008'
New-Item -ItemType Directory -Path $renderTmp -Force | Out-Null

& 'C:\Program Files\R\R-4.5.3\bin\Rscript.exe' (Join-Path $PSScriptRoot '06_go_pseudotime_revision.R')
if ($LASTEXITCODE -ne 0) { throw 'Analysis failed' }
Copy-Item -LiteralPath (Join-Path $PSScriptRoot '05_pseudotime_figure.R') -Destination (Join-Path $renderTmp 'figure.R')
$env:DLC_ANALYSIS_DIR = 'C:/wb_links/pseudotime_go20261008/source_data'
$env:DLC_FIGURE_OUT = $renderTmp.Replace('\', '/')
$env:DLC_FIGURE_RASTER_OUT = $env:DLC_FIGURE_OUT
$env:DLC_PSEUDOTIME_GO_MODE = '1'
& 'C:\Program Files\R\R-4.5.3\bin\Rscript.exe' (Join-Path $renderTmp 'figure.R')
if ($LASTEXITCODE -ne 0) { throw 'Figure rendering failed' }
Get-ChildItem -LiteralPath $renderTmp -File | Where-Object { $_.Extension -in '.pdf', '.png', '.tiff' -and $_.Name.StartsWith('Williams_gingival_fibroblast_pseudotime_GO_20261008') } | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $figDir $_.Name)
}
& 'C:\Users\Lin\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' (Join-Path $PSScriptRoot 'verify_figure.py')
if ($LASTEXITCODE -ne 0) { throw 'Figure QA failed' }
