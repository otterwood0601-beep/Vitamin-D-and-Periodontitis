options(stringsAsFactors = FALSE)
set.seed(20260918L)

.libPaths(c(
  "C:/Users/Lin/R/win-library/4.5",
  "C:/Users/Lin/AppData/Local/R/win-library/4.5",
  "C:/Program Files/R/R-4.5.3/library"
))

suppressPackageStartupMessages({
  library(data.table)
  library(Seurat)
  library(SingleCellExperiment)
  library(slingshot)
  library(mgcv)
  library(jsonlite)
})

ROOT <- "C:/wb_links/dlc"
OUT <- Sys.getenv("DLC_ANALYSIS_DIR", file.path(ROOT, "data_derived/tranoncol2026"))
STUDY_FILTER <- trimws(Sys.getenv("DLC_STUDY_FILTER", ""))
FB_RDS <- "C:/wb_links/dlc_data/outputs/fb_seurat_annotated.rds"
SCORE_FILE <- file.path(OUT, "05_cell_marker_and_program_scores.csv.gz")
dir.create(OUT, recursive = TRUE, showWarnings = FALSE)

ROOT_STATE <- "Matrix homeostasis"
NBINS <- 30L
TYPE_LEVELS <- c("Immune", "ECM remodeling", "Vascular", "Pre-ECM", "Matrix homeostasis")

wmean <- function(x, w) {
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (!any(ok) || sum(w[ok]) <= 0) return(NA_real_)
  sum(x[ok] * w[ok]) / sum(w[ok])
}

wmedian <- function(x, w) {
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (!any(ok) || sum(w[ok]) <= 0) return(NA_real_)
  x <- x[ok]; w <- w[ok]
  oo <- order(x)
  x <- x[oo]; w <- w[oo]
  x[which(cumsum(w) >= sum(w) / 2)[1]]
}

cat("[1/6] Load human gingival fibroblasts\n")
fb <- readRDS(FB_RDS)
if (nzchar(STUDY_FILTER)) {
  keep_cells <- rownames(fb[[]])[as.character(fb$Study) == STUDY_FILTER]
  if (!length(keep_cells)) stop("No cells matched Study == ", STUDY_FILTER)
  fb <- subset(fb, cells = keep_cells)
  cat("    study filter:", STUDY_FILTER, "cells:", ncol(fb), "\n")
}
md0 <- as.data.table(fb[[]])
md0[, cell_id := colnames(fb)]
scores <- fread(SCORE_FILE)
setkey(scores, cell_id)
scores <- scores[md0$cell_id]
stopifnot(identical(scores$cell_id, md0$cell_id))
md <- copy(scores)
md[, fibroblast_short := factor(fibroblast_short, levels = TYPE_LEVELS)]
md[, disease := factor(disease, levels = c("normal", "periodontitis"))]
md[, donor_key := factor(paste(Study, donor_id, sep = "||"))]
md[, Study := factor(Study)]
md[, GDF15_detection := as.integer(GDF15 > 0)]

cat("[2/6] Infer Slingshot state paths from the fixed UMAP\n")
cd <- DataFrame(as.data.frame(fb[[]]), row.names = colnames(fb))
sce <- SingleCellExperiment(colData = cd)
umap_mat <- Embeddings(fb, "frozen_umap")
rownames(umap_mat) <- colnames(fb)
reducedDims(sce) <- SimpleList(UMAP = umap_mat)
sce <- slingshot(
  sce,
  clusterLabels = "fibroblast_short",
  reducedDim = "UMAP",
  start.clus = ROOT_STATE,
  shrink = TRUE,
  extend = "y"
)

lineages_raw <- slingLineages(sce)
lineage_ids <- paste0("L", seq_along(lineages_raw))
names(lineages_raw) <- lineage_ids
lineage_labels <- vapply(lineages_raw, function(z) paste(z, collapse = " > "), character(1))
lineage_short <- gsub("Matrix homeostasis", "Homeostasis", lineage_labels, fixed = TRUE)
lineage_short <- gsub("ECM remodeling", "ECM", lineage_short, fixed = TRUE)
names(lineage_short) <- lineage_ids

pt <- slingPseudotime(sce, na = TRUE)
cw <- slingCurveWeights(sce)
colnames(pt) <- lineage_ids
colnames(cw) <- lineage_ids
pt_scaled <- pt
for (j in seq_len(ncol(pt))) {
  rr <- range(pt[, j], na.rm = TRUE)
  pt_scaled[, j] <- (pt[, j] - rr[1]) / diff(rr)
}

cell_out <- md[, .(
  cell_id, fibroblast_short, disease, Study, donor_id, donor_key,
  frozen_umap_1, frozen_umap_2,
  GDF15, MAPK1, MAPK3, JUND,
  MAPK_ERK, ECM_synthesis, ECM_organization, ECM_degradation,
  ECM_inhibitors, ECM_adhesion
)]
for (j in seq_along(lineage_ids)) {
  cell_out[[paste0(lineage_ids[j], "_pseudotime_raw")]] <- pt[, j]
  cell_out[[paste0(lineage_ids[j], "_pseudotime_01")]] <- pt_scaled[, j]
  cell_out[[paste0(lineage_ids[j], "_weight")]] <- cw[, j]
}
fwrite(cell_out, file.path(OUT, "32_pseudotime_cell_assignments.csv.gz"))

lineage_def <- rbindlist(lapply(seq_along(lineage_ids), function(j) {
  data.table(
    lineage = lineage_ids[j],
    label = lineage_short[j],
    full_state_path = lineage_labels[j],
    root_state = ROOT_STATE,
    endpoint_state = tail(lineages_raw[[j]], 1),
    n_cells_finite = sum(is.finite(pt[, j])),
    n_cells_weight_gt_0_5 = sum(cw[, j] > 0.5, na.rm = TRUE),
    max_raw_pseudotime = max(pt[, j], na.rm = TRUE)
  )
}))
fwrite(lineage_def, file.path(OUT, "33_pseudotime_lineage_definitions.csv"))

curves <- slingCurves(sce)
curve_dt <- rbindlist(lapply(seq_along(curves), function(j) {
  cr <- curves[[j]]
  ss <- cr[["s"]]
  lam_all <- cr[["lambda"]]
  ord_all <- cr[["ord"]]
  ok <- ord_all[rowSums(is.finite(ss[ord_all, , drop = FALSE])) == ncol(ss)]
  keep <- unique(round(seq(1, length(ok), length.out = min(450L, length(ok)))))
  ids <- ok[keep]
  lam_grid <- seq(min(lam_all, na.rm = TRUE), max(lam_all, na.rm = TRUE),
                  length.out = nrow(ss))
  lam <- lam_grid[ids]
  data.table(
    lineage = lineage_ids[j],
    order = seq_along(ids),
    pseudotime_01 = (lam - min(lam_grid)) / diff(range(lam_grid)),
    umap_1 = ss[ids, 1],
    umap_2 = ss[ids, 2]
  )
}))
fwrite(curve_dt, file.path(OUT, "34_pseudotime_curve_coordinates.csv"))

cat("[3/6] Build lineage-weighted pseudotime bins\n")
features <- c(
  "GDF15_detection", "GDF15", "MAPK1", "MAPK3", "JUND",
  "MAPK_ERK", "ECM_synthesis", "ECM_organization", "ECM_degradation",
  "ECM_inhibitors", "ECM_adhesion"
)

long_list <- vector("list", length(lineage_ids))
bin_list <- vector("list", length(lineage_ids))
state_list <- vector("list", length(lineage_ids))
for (j in seq_along(lineage_ids)) {
  d <- copy(md)
  d[, lineage := lineage_ids[j]]
  d[, pseudotime_01 := pt_scaled[, j]]
  d[, lineage_weight := cw[, j]]
  d <- d[is.finite(pseudotime_01) & is.finite(lineage_weight) & lineage_weight > 0.05]
  d[, pseudotime_bin := pmin(NBINS, floor(pseudotime_01 * NBINS) + 1L)]
  long_list[[j]] <- d

  bins <- d[, .(
    n_cells = .N,
    effective_weight = sum(lineage_weight),
    pseudotime_01 = wmean(pseudotime_01, lineage_weight),
    periodontitis_fraction = 100 * wmean(as.integer(disease == "periodontitis"), lineage_weight)
  ), by = .(lineage, pseudotime_bin)]
  vals <- rbindlist(lapply(features, function(v) {
    d[, .(
      value = wmean(get(v), lineage_weight),
      n_cells = .N,
      effective_weight = sum(lineage_weight),
      pseudotime_01 = wmean(pseudotime_01, lineage_weight)
    ), by = .(lineage, pseudotime_bin)][, feature := v]
  }))
  vals[bins, on = .(lineage, pseudotime_bin),
       periodontitis_fraction := i.periodontitis_fraction]
  bin_list[[j]] <- vals

  state_list[[j]] <- d[, .(
    n_cells = .N,
    effective_weight = sum(lineage_weight),
    mean_pseudotime = wmean(pseudotime_01, lineage_weight),
    median_pseudotime = wmedian(pseudotime_01, lineage_weight),
    periodontitis_fraction = 100 * wmean(as.integer(disease == "periodontitis"), lineage_weight)
  ), by = .(lineage, fibroblast_short)]
}
cell_long <- rbindlist(long_list, fill = TRUE)
binned <- rbindlist(bin_list, fill = TRUE)
state_pos <- rbindlist(state_list, fill = TRUE)
fwrite(binned, file.path(OUT, "35_pseudotime_binned_trends.csv"))
fwrite(state_pos, file.path(OUT, "36_pseudotime_state_positions.csv"))

cat("[4/6] Fit donor-aware weighted GAMs\n")
gam_features <- c(
  "GDF15_detection", "MAPK1", "MAPK3", "JUND", "MAPK_ERK",
  "ECM_synthesis", "ECM_organization", "ECM_degradation",
  "ECM_inhibitors", "ECM_adhesion"
)

fit_one <- function(d, feature) {
  z <- d[, .(
    y = get(feature),
    pt = pseudotime_01,
    w = lineage_weight,
    disease,
    Study,
    donor_key
  )]
  z <- z[is.finite(y) & is.finite(pt) & is.finite(w) & w > 0.05]
  z[, donor_pt_bin := pmin(6L, floor(pt * 6) + 1L)]
  a <- z[, .(
    y = wmean(y, w),
    pt = wmean(pt, w),
    effective_weight = sum(w),
    n_cells = .N
  ), by = .(donor_key, disease, Study, donor_pt_bin)]
  a[, `:=`(
    disease = droplevels(factor(disease)),
    Study = droplevels(factor(Study)),
    donor_key = droplevels(factor(donor_key))
  )]
  cap_w <- quantile(a$effective_weight, 0.90, na.rm = TRUE)
  a[, model_weight := sqrt(pmin(effective_weight, cap_w))]
  form_gam <- if (nlevels(a$Study) > 1L)
    y ~ s(pt, k = 5, bs = "cr") + disease + Study + s(donor_key, bs = "re") else
    y ~ s(pt, k = 5, bs = "cr") + disease + s(donor_key, bs = "re")
  fit <- gam(
    form_gam,
    data = a,
    weights = model_weight,
    family = gaussian(),
    method = "REML"
  )
  sm <- summary(fit)$s.table
  ridx <- grep("^s\\(pt\\)$", rownames(sm))[1]
  ref <- data.table(
    pt = c(0, 1),
    disease = factor(rep(levels(a$disease)[1], 2), levels = levels(a$disease)),
    Study = factor(rep(levels(a$Study)[1], 2), levels = levels(a$Study)),
    donor_key = factor(rep(levels(a$donor_key)[1], 2), levels = levels(a$donor_key))
  )
  pred <- as.numeric(predict(fit, newdata = ref, type = "response",
                             exclude = "s(donor_key)"))
  data.table(
    feature = feature,
    n_cells = nrow(z),
    n_donor_bin_units = nrow(a),
    n_donors = nlevels(a$donor_key),
    smooth_edf = sm[ridx, "edf"],
    smooth_statistic = sm[ridx, "F"],
    smooth_p = sm[ridx, "p-value"],
    predicted_start = pred[1],
    predicted_end = pred[2],
    end_minus_start = pred[2] - pred[1]
  )
}

gam_res <- rbindlist(lapply(seq_along(lineage_ids), function(j) {
  d <- long_list[[j]]
  ans <- rbindlist(lapply(gam_features, function(v) fit_one(d, v)), fill = TRUE)
  ans[, lineage := lineage_ids[j]]
  ans
}))
gam_res[, smooth_FDR := p.adjust(smooth_p, method = "BH")]
gam_res[, direction := fifelse(end_minus_start > 0, "Increase", "Decrease")]
setcolorder(gam_res, c("lineage", "feature", setdiff(names(gam_res), c("lineage", "feature"))))
fwrite(gam_res, file.path(OUT, "37_pseudotime_donor_aware_GAM_results.csv"))

cat("[5/6] Save manifest\n")
manifest <- list(
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  scope = "Human gingival fibroblasts only; no substitute tissue",
  study_filter = if (nzchar(STUDY_FILTER)) STUDY_FILTER else "All studies",
  n_cells = ncol(fb),
  n_donors = uniqueN(md$donor_key),
  embedding = "Existing fixed gingival fibroblast UMAP",
  method = "Slingshot cluster-based trajectories with Matrix homeostasis as the prespecified reference root",
  lineages = setNames(as.list(lineage_labels), lineage_ids),
  trend_model = paste(
    "Lineage-weighted donor-by-pseudotime-bin aggregation followed by mgcv::gam",
    if (nzchar(STUDY_FILTER))
      "with smooth pseudotime, disease fixed effect, and donor random effect"
    else "with smooth pseudotime, disease and Study fixed effects, and donor random effect"
  ),
  interpretation_boundary = paste(
    "Pseudotime represents an inferred transcriptomic state continuum.",
    "It does not establish chronological order, differentiation, or GDF15-to-ERK causality."
  ),
  package_versions = list(
    R = R.version.string,
    slingshot = as.character(packageVersion("slingshot")),
    SingleCellExperiment = as.character(packageVersion("SingleCellExperiment")),
    mgcv = as.character(packageVersion("mgcv")),
    Seurat = as.character(packageVersion("Seurat"))
  )
)
writeLines(toJSON(manifest, auto_unbox = TRUE, pretty = TRUE),
           file.path(OUT, "38_pseudotime_manifest.json"))

cat("[6/6] Pseudotime analysis completed\n")
