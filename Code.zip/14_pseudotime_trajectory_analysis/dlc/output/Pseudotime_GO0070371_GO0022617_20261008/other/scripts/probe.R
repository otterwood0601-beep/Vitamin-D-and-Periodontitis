.libPaths(c('C:/Users/Lin/R/win-library/4.5','C:/Users/Lin/AppData/Local/R/win-library/4.5', .libPaths()))
library(data.table)
library(Seurat)
p <- 'C:/wb_links/tranoncol2026_Williams_20260920/32_pseudotime_cell_assignments.csv.gz'
x <- fread(p)
cat('COLUMNS',paste(names(x), collapse=', '),'\n')
print(unique(x[,.(Study, donor_id, disease)]))
cat('RDS',file.info('C:/wb_links/dlc_data/outputs/fb_seurat_annotated.rds')$size,'\n')
for(k in c('UCell','mgcv','ragg','ggplot2','cowplot','jsonlite','digest')) cat(k,as.character(packageVersion(k)),'\n')
