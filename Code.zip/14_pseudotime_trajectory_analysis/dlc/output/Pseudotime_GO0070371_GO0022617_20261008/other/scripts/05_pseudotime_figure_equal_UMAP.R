options(stringsAsFactors = FALSE)
set.seed(20260918L)

.libPaths(c(
  "C:/Users/Lin/R/win-library/4.5",
  "C:/Users/Lin/AppData/Local/R/win-library/4.5",
  "C:/Program Files/R/R-4.5.3/library"
))

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(ggrepel)
  library(cowplot)
  library(scales)
  library(ragg)
  library(grid)
})

ROOT <- "C:/wb_links/dlc"
DAT <- Sys.getenv("DLC_ANALYSIS_DIR", file.path(ROOT, "data_derived/tranoncol2026"))
OUT <- Sys.getenv("DLC_FIGURE_OUT", "C:/wb_links/tranoncol_out")
RASTER_OUT <- Sys.getenv("DLC_FIGURE_RASTER_OUT", "C:/wb_links/tranoncol_renders")
OUTPUT_TAG <- Sys.getenv("DLC_OUTPUT_TAG", "")
GO_MODE <- identical(Sys.getenv("DLC_PSEUDOTIME_GO_MODE", "0"), "1")
HIDE_UMAP_ISOLATED <- identical(Sys.getenv("DLC_HIDE_UMAP_ISOLATED", "0"), "1")
EQUAL_UMAP_PANELS <- identical(Sys.getenv("DLC_EQUAL_UMAP_PANELS", "0"), "1")
dir.create(OUT, recursive = TRUE, showWarnings = FALSE)
dir.create(RASTER_OUT, recursive = TRUE, showWarnings = FALSE)

FONT <- "Arial"
TYPE_LEVELS <- c("Immune", "ECM remodeling", "Vascular", "Pre-ECM", "Matrix homeostasis")
TYPE_COLORS <- c(
  "Immune" = "#4FA8C5",
  "ECM remodeling" = "#6CB354",
  "Vascular" = "#F29A3A",
  "Pre-ECM" = "#D95C5C",
  "Matrix homeostasis" = "#9880B9"
)
LINEAGE_COLORS <- c("L1" = "#2D78A7", "L2" = "#E89535", "L3" = "#8A6BAE")
LINEAGE_LABELS <- c(
  "L1" = "Homeostasis > Immune > ECM",
  "L2" = "Homeostasis > Immune > Vascular",
  "L3" = "Homeostasis > Pre-ECM"
)

theme_article <- theme_gray(base_size = 6.4, base_family = FONT) +
  theme(
    panel.grid.major = element_line(colour = "#D8D8D8", linewidth = 0.22),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(colour = "#777777", fill = NA, linewidth = 0.35),
    axis.text = element_text(colour = "black", size = 5.7),
    axis.title = element_text(colour = "black", size = 6.3),
    strip.background = element_blank(),
    strip.text = element_text(colour = "black", face = "bold", size = 6.2),
    legend.title = element_text(size = 5.7),
    legend.text = element_text(size = 5.1),
    plot.title = element_text(size = 6.8, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 5.2, hjust = 0.5),
    plot.margin = margin(2, 2, 2, 2, unit = "pt")
  )

theme_umap <- theme_void(base_family = FONT) +
  theme(
    plot.title = element_text(size = 6.5, face = "bold", hjust = 0.5,
                              margin = margin(b = 1.5, unit = "pt")),
    legend.title = element_text(size = 5.8),
    legend.text = element_text(size = 5.0),
    legend.key.height = unit(7, "pt"),
    legend.key.width = unit(5, "pt"),
    plot.margin = margin(1, 1, 1, 1, unit = "pt")
  )

if (GO_MODE) {
  theme_article <- theme_bw(base_size = 7.5, base_family = FONT) +
    theme(panel.grid = element_blank(),
          panel.border = element_rect(colour = "#777777", fill = NA, linewidth = 0.35),
          axis.text = element_text(colour = "black", size = 6.5),
          axis.title = element_text(colour = "black", size = 7.0),
          strip.background = element_rect(fill = "#E4E6EB", colour = NA),
          strip.text = element_text(colour = "black", face = "bold", size = 7.0),
          legend.title = element_text(size = 6.3), legend.text = element_text(size = 5.7),
          plot.title = element_text(size = 7.4, face = "bold", hjust = 0.5),
          plot.subtitle = element_text(size = 5.5, hjust = 0.5),
          plot.margin = margin(3, 3, 3, 3, unit = "pt"))

  cowplot::set_null_device("agg")
}

tag_panel <- function(p, lab, pad = 0.035, size = if (GO_MODE) 12 else 15) {
  ggdraw() +
    draw_plot(p, x = pad, y = 0, width = 1 - pad, height = 0.97) +
    draw_label(lab, x = 0.003, y = 0.995, hjust = 0, vjust = 1,
               fontfamily = FONT, fontface = if (GO_MODE) "bold" else "plain", size = size)
}

add_umap_axes <- function(p, x, y) {
  xr <- range(x, na.rm = TRUE); yr <- range(y, na.rm = TRUE)
  x0 <- xr[1] + 0.05 * diff(xr); y0 <- yr[1] + 0.07 * diff(yr)
  p +
    annotate("segment", x = x0, xend = x0 + 0.19 * diff(xr), y = y0, yend = y0,
             arrow = arrow(length = unit(2.8, "pt")), linewidth = 0.35) +
    annotate("segment", x = x0, xend = x0, y = y0, yend = y0 + 0.19 * diff(yr),
             arrow = arrow(length = unit(2.8, "pt")), linewidth = 0.35) +
    annotate("text", x = x0 + 0.095 * diff(xr), y = y0 - 0.06 * diff(yr),
             label = "UMAP1", size = 1.7, family = FONT) +
    annotate("text", x = x0 - 0.06 * diff(xr), y = y0 + 0.095 * diff(yr),
             label = "UMAP2", angle = 90, size = 1.7, family = FONT)
}

save_exact <- function(plot, stem, width_px = 2000, height_px = 2432) {
  dpi <- 300
  if (GO_MODE) {
    width_px <- 4252
    height_px <- 4918
    dpi <- 600
    if (EQUAL_UMAP_PANELS) {
      width_px <- 5198
      height_px <- 6024
    }
  }
  png_path <- file.path(RASTER_OUT, paste0(stem, ".png"))
  pdf_path <- file.path(OUT, paste0(stem, ".pdf"))
  tif_path <- file.path(RASTER_OUT, paste0(stem, ".tiff"))
  agg_png(png_path, width = width_px, height = height_px, units = "px",
          res = dpi, background = "white")
  print(plot); dev.off()
  cairo_pdf(pdf_path, width = width_px / dpi, height = height_px / dpi,
            family = FONT, onefile = TRUE)
  print(plot); dev.off()
  agg_tiff(tif_path, width = width_px, height = height_px, units = "px",
           res = dpi, compression = "lzw", background = "white")
  print(plot); dev.off()
  if (GO_MODE) {
    agg_png(file.path(RASTER_OUT, paste0(stem, "_preview.png")),
            width = width_px / 2, height = height_px / 2, units = "px",
            res = 300, background = "white")
    print(plot); dev.off()
  }
}

cell <- fread(file.path(DAT, "32_pseudotime_cell_assignments.csv.gz"))
defs <- fread(file.path(DAT, "33_pseudotime_lineage_definitions.csv"))
curves <- fread(file.path(DAT, "34_pseudotime_curve_coordinates.csv"))
bins <- fread(file.path(DAT, "35_pseudotime_binned_trends.csv"))
state_pos <- fread(file.path(DAT, "36_pseudotime_state_positions.csv"))
gam <- fread(file.path(DAT, "37_pseudotime_donor_aware_GAM_results.csv"))

umap_display <- cell
if (HIDE_UMAP_ISOLATED) {
  hidden_ids <- c("GGACGTCTCAGCACAT_22", "ACGCACGCACTACGGC_33",
                  "TCAGATGTCCCAAGTA_13", "ACGCAGCGTGGCCCTA_29")
  hidden_cells <- cell[cell_id %in% hidden_ids]
  stopifnot(nrow(hidden_cells) == 4L)
  umap_display <- cell[!cell_id %in% hidden_ids]
  fwrite(hidden_cells[, .(cell_id, frozen_umap_1, frozen_umap_2)],
         file.path(OUT, "UMAP_hidden_isolated_cells.csv"))
  cat("UMAP display only: hiding 4 marked isolated cells; all analysis data retained\n")
}

lineage_ids <- as.character(defs$lineage)
LINEAGE_COLORS <- LINEAGE_COLORS[lineage_ids]
LINEAGE_LABELS <- setNames(as.character(defs$label), lineage_ids)

cell[, fibroblast_short := factor(fibroblast_short, levels = TYPE_LEVELS)]
curves[, lineage := factor(lineage, levels = names(LINEAGE_COLORS))]
bins[, lineage := factor(lineage, levels = names(LINEAGE_COLORS))]
state_pos[, lineage := factor(lineage, levels = names(LINEAGE_COLORS))]
gam[, lineage := factor(lineage, levels = names(LINEAGE_COLORS))]

root_xy <- cell[fibroblast_short == "Matrix homeostasis",
                .(frozen_umap_1 = median(frozen_umap_1),
                  frozen_umap_2 = median(frozen_umap_2))]

umap_coord <- function() {
  if (!EQUAL_UMAP_PANELS) return(coord_equal())
  xr <- range(cell$frozen_umap_1, na.rm = TRUE)
  yr <- range(cell$frozen_umap_2, na.rm = TRUE)
  coord_equal(xlim = xr + c(-0.08, 0.08) * diff(xr),
              ylim = yr + c(-0.08, 0.08) * diff(yr), expand = FALSE)
}

pA <- ggplot(umap_display, aes(frozen_umap_1, frozen_umap_2)) +
  geom_blank(data = cell) +
  geom_point(aes(fill = fibroblast_short), shape = 21, colour = "white",
             stroke = 0.01, size = 0.30, alpha = 0.78) +
  geom_path(data = curves, aes(umap_1, umap_2, colour = lineage, group = lineage),
            inherit.aes = FALSE, linewidth = 0.85,
            arrow = arrow(type = "closed", length = unit(2.8, "pt"))) +
  geom_point(data = root_xy, aes(frozen_umap_1, frozen_umap_2),
             inherit.aes = FALSE, shape = 23, size = 3.0,
             fill = "#F4E500", colour = "black", stroke = 0.45) +
  annotate("text", x = root_xy$frozen_umap_1, y = root_xy$frozen_umap_2 - 1.15,
           label = "Root reference", family = FONT, size = 1.8) +
  scale_fill_manual(values = TYPE_COLORS, name = "Celltype") +
  scale_colour_manual(values = LINEAGE_COLORS, labels = LINEAGE_LABELS,
                      name = "Inferred path") +
  umap_coord() + theme_umap +
  theme(legend.position = "right") +
  labs(title = "Inferred state paths")
pA <- add_umap_axes(pA, cell$frozen_umap_1, cell$frozen_umap_2)

pt_panel <- function(lin) {
  pt_col <- paste0(lin, "_pseudotime_01")
  wt_col <- paste0(lin, "_weight")
  d <- umap_display[is.finite(get(pt_col)) & get(wt_col) > 0.05]
  setorderv(d, pt_col)
  cv <- curves[lineage == lin]
  p <- ggplot() +
    geom_blank(data = cell, aes(frozen_umap_1, frozen_umap_2)) +
    geom_point(data = umap_display, aes(frozen_umap_1, frozen_umap_2),
               colour = "#D6D6D6", size = 0.08) +
    geom_point(data = d, aes(frozen_umap_1, frozen_umap_2, colour = get(pt_col)),
               size = 0.11, alpha = 0.82) +
    geom_path(data = cv, aes(umap_1, umap_2), colour = "black", linewidth = 0.5,
              arrow = arrow(type = "closed", length = unit(2.2, "pt"))) +
    scale_colour_gradientn(colours = c("#2469A0", "#F4E95B", "#D94A3A"),
                           limits = c(0, 1), name = "Pseudotime") +
    umap_coord() + theme_umap +
    theme(legend.position = if (lin == tail(lineage_ids, 1)) "right" else "none") +
    labs(title = lin)
  add_umap_axes(p, cell$frozen_umap_1, cell$frozen_umap_2)
}
pB <- plot_grid(plotlist = lapply(names(LINEAGE_COLORS), pt_panel), nrow = 1)

state_pos[, fibroblast_short := factor(fibroblast_short, levels = rev(TYPE_LEVELS))]
pC <- ggplot(state_pos, aes(median_pseudotime, fibroblast_short)) +
  geom_segment(aes(x = 0, xend = median_pseudotime, yend = fibroblast_short),
               colour = "#BDBDBD", linewidth = 0.45) +
  geom_point(aes(fill = fibroblast_short, size = effective_weight), shape = 21,
             colour = "#555555", stroke = 0.25) +
  facet_wrap(~lineage, nrow = 1) +
  scale_fill_manual(values = TYPE_COLORS, guide = "none") +
  scale_size_continuous(range = c(1.2, 4.0), name = "Effective\ncell weight") +
  scale_x_continuous(limits = c(0, 1), breaks = c(0, 0.5, 1)) +
  labs(x = "Scaled pseudotime", y = NULL, title = "State position along each path") +
  theme_article + theme(legend.position = "right", axis.text.y = element_text(size = 4.8))

disease_bins <- unique(bins[, .(lineage, pseudotime_bin, pseudotime_01,
                                periodontitis_fraction)])
overall_pd <- 100 * mean(cell$disease == "periodontitis")
pD <- ggplot(disease_bins, aes(pseudotime_01, periodontitis_fraction,
                                colour = lineage)) +
  geom_hline(yintercept = overall_pd, linetype = "dashed", colour = "#777777",
             linewidth = 0.35) +
  geom_line(linewidth = 0.75) +
  geom_point(size = 0.8) +
  scale_colour_manual(values = LINEAGE_COLORS, labels = names(LINEAGE_COLORS),
                      name = "Path") +
  scale_y_continuous(labels = function(x) paste0(x, "%")) +
  labs(x = "Scaled pseudotime", y = "Periodontitis cells",
       title = "Disease composition across pseudotime") +
  theme_article + theme(legend.position = "top", legend.text = element_text(size = 4.3))
if (GO_MODE) pD <- pD + theme(axis.title.y = element_text(margin = margin(r = 5)))

gdf <- bins[feature == "GDF15_detection"]
gdf[, value := 100 * value]
gdf_lab <- gam[feature == "GDF15_detection",
               .(lineage, label = ifelse(smooth_FDR < 0.001, "FDR < 0.001",
                                         sprintf("FDR = %.3f", smooth_FDR)))]
gdf_rng <- gdf[, .(x = 0.97, y = max(value, na.rm = TRUE) * 0.96), by = lineage]
gdf_lab[gdf_rng, on = "lineage", `:=`(x = i.x, y = i.y)]
pE <- ggplot(gdf, aes(pseudotime_01, value, colour = lineage)) +
  geom_point(size = 0.62, alpha = 0.58) +
  geom_smooth(method = "loess", span = 0.45, se = FALSE, linewidth = 0.75) +
  geom_text(data = gdf_lab, aes(x, y, label = label), inherit.aes = FALSE,
            hjust = 1, vjust = 1, family = FONT, size = 1.8) +
  facet_wrap(~lineage, nrow = 1) +
  scale_colour_manual(values = LINEAGE_COLORS, guide = "none") +
  scale_x_continuous(breaks = c(0, 0.5, 1), labels = c("0", ".5", "1")) +
  labs(x = "Scaled pseudotime", y = "GDF15-positive cells (%)",
       title = "GDF15 detection along inferred paths") + theme_article

gene_titles <- c("MAPK1" = "MAPK1 (ERK2)", "MAPK3" = "MAPK3 (ERK1)", "JUND" = "JUND")
if (GO_MODE) gene_titles <- gene_titles[c("MAPK1", "MAPK3")]
gene_bins <- bins[feature %in% names(gene_titles)]
gene_bins[, feature := factor(feature, levels = names(gene_titles))]
pF <- ggplot(gene_bins, aes(pseudotime_01, value, colour = lineage)) +
  geom_point(size = 0.45, alpha = 0.45) +
  geom_smooth(method = "loess", span = 0.45, se = FALSE, linewidth = 0.72) +
  facet_wrap(~feature, nrow = 1, scales = "free_y", labeller = as_labeller(gene_titles)) +
  scale_colour_manual(values = LINEAGE_COLORS, labels = names(LINEAGE_COLORS),
                      name = "Path") +
  scale_x_continuous(breaks = c(0, 0.5, 1), labels = c("0", ".5", "1")) +
  labs(x = "Scaled pseudotime", y = "Mean normalized expression",
       title = "ERK-related transcripts along pseudotime") + theme_article +
  theme(legend.position = "top", legend.text = element_text(size = 4.3))

program_titles <- c(
  "MAPK_ERK" = "MAPK/ERK response",
  "ECM_synthesis" = "Collagen synthesis",
  "ECM_organization" = "ECM organization",
  "ECM_degradation" = "ECM degradation"
)
if (GO_MODE) program_titles <- c(
  "ERK_GO0070371" = "ERK1/2 cascade\nGO:0070371",
  "ECM_GO0022617" = "ECM disassembly\nGO:0022617"
)
program_bins <- bins[feature %in% names(program_titles)]
program_bins[, feature := factor(feature, levels = names(program_titles))]
pG <- ggplot(program_bins, aes(pseudotime_01, value, colour = lineage)) +
  geom_point(size = 0.42, alpha = 0.42) +
  geom_smooth(method = "loess", span = 0.45, se = FALSE, linewidth = 0.72) +
  facet_wrap(~feature, nrow = if (GO_MODE) 1 else 2, scales = "free_y", labeller = as_labeller(program_titles)) +
  scale_colour_manual(values = LINEAGE_COLORS, labels = names(LINEAGE_COLORS),
                      name = "Path") +
  scale_x_continuous(breaks = c(0, 0.5, 1), labels = c("0", ".5", "1")) +
  labs(x = "Scaled pseudotime", y = "Lineage-weighted UCell score",
       title = if (GO_MODE) "GO pathway expression scores" else "MAPK/ERK and ECM program dynamics") + theme_article +
  theme(legend.position = "top", legend.text = element_text(size = 4.3))

show_features <- c("GDF15_detection", "MAPK1", "MAPK3", "JUND", "MAPK_ERK",
                   "ECM_synthesis", "ECM_organization", "ECM_degradation")
show_labels <- c("GDF15 detection", "MAPK1 (ERK2)", "MAPK3 (ERK1)", "JUND",
                 "MAPK/ERK response", "Collagen synthesis", "ECM organization", "ECM degradation")
if (GO_MODE) {
  show_features <- c("GDF15_detection", "MAPK1", "MAPK3", "ERK_GO0070371", "ECM_GO0022617")
  show_labels <- c("GDF15 detection", "MAPK1 (ERK2)", "MAPK3 (ERK1)",
                   "ERK1/2 cascade\nGO:0070371", "ECM disassembly\nGO:0022617")
}
gam_h <- gam[feature %in% show_features]
gam_h[, feature_label := factor(feature,
  levels = rev(show_features),
  labels = rev(show_labels)
)]
gam_h[, sig_direction := fifelse(smooth_FDR >= 0.05, "Not significant",
                                 fifelse(end_minus_start > 0, "Increase", "Decrease"))]
gam_h[, logFDR := pmin(-log10(pmax(smooth_FDR, 1e-12)), 12)]
pH <- ggplot(gam_h, aes(lineage, feature_label)) +
  geom_point(aes(size = logFDR, fill = sig_direction), shape = 21,
             colour = "#666666", stroke = 0.3) +
  scale_fill_manual(values = c("Increase" = "#D8655A", "Decrease" = "#4F79A7",
                               "Not significant" = "#D0D0D0"), name = NULL) +
  scale_size_continuous(range = c(1.1, 4.2), name = "-log10 FDR") +
  labs(x = "Inferred path", y = NULL,
       title = "Donor-aware trajectory tests",
       subtitle = if (GO_MODE) "Color: end-point direction\nSize: smooth-term FDR" else
         "Color: end-point direction; size: smooth-term FDR") +
  theme_article + theme(panel.grid = element_blank(), legend.position = "right",
                        axis.text.y = element_text(size = 4.8))

fig <- plot_grid(
  plot_grid(tag_panel(pA, "A"), tag_panel(pB, "B"), nrow = 1,
            rel_widths = c(0.38, 0.62)),
  plot_grid(tag_panel(pC, "C"), tag_panel(pD, "D"), nrow = 1,
            rel_widths = c(0.56, 0.44)),
  plot_grid(tag_panel(pE, "E"), tag_panel(pF, "F"), nrow = 1,
            rel_widths = c(0.42, 0.58)),
  plot_grid(tag_panel(pG, "G"), tag_panel(pH, "H"), nrow = 1,
            rel_widths = c(0.66, 0.34)),
  ncol = 1,
  rel_heights = c(0.28, 0.19, 0.22, 0.31)
)

if (EQUAL_UMAP_PANELS) {
  
  state_legend <- get_legend(pA +
    theme(legend.position = "bottom", legend.box = "vertical",
          legend.box.just = "left", legend.justification = "left") +
    guides(colour = guide_legend(ncol = 1, order = 1),
           fill = guide_legend(nrow = 2, byrow = TRUE, order = 2)))
  time_legend <- get_legend(pt_panel(tail(lineage_ids, 1)) +
    theme(legend.position = "right") +
    guides(colour = guide_colourbar(barheight = unit(20, "mm"))))
  map_plots <- c(list(pA + theme(legend.position = "none")),
                 lapply(lineage_ids, function(lin) {
                   pt_panel(lin) + theme(legend.position = "none")
                 }))
  stopifnot(length(map_plots) == 3L)
  map_grobs <- align_plots(plotlist = map_plots, align = "hv", axis = "tblr")
  shared_widths <- do.call(unit.pmax, lapply(map_grobs, function(g) g$widths))
  shared_heights <- do.call(unit.pmax, lapply(map_grobs, function(g) g$heights))
  map_grobs <- lapply(map_grobs, function(g) {
    g$widths <- shared_widths
    g$heights <- shared_heights
    g
  })
  stopifnot(identical(map_grobs[[1]]$widths, map_grobs[[2]]$widths),
            identical(map_grobs[[1]]$widths, map_grobs[[3]]$widths),
            identical(map_grobs[[1]]$heights, map_grobs[[2]]$heights),
            identical(map_grobs[[1]]$heights, map_grobs[[3]]$heights))
  map_row <- ggdraw() +
    draw_plot(map_grobs[[1]], x = 0, y = 0, width = 1/3, height = 0.94) +
    draw_plot(map_grobs[[2]], x = 1/3, y = 0, width = 1/3, height = 0.94) +
    draw_plot(map_grobs[[3]], x = 2/3, y = 0, width = 1/3, height = 0.94) +
    draw_label("A", x = 0.003, y = 0.995, hjust = 0, vjust = 1,
               fontfamily = FONT, fontface = "bold", size = 12) +
    draw_label("B", x = 1/3 + 0.003, y = 0.995, hjust = 0, vjust = 1,
               fontfamily = FONT, fontface = "bold", size = 12)
  legend_row <- ggdraw() +
    draw_plot(state_legend, x = 0.025, y = 0, width = 0.64, height = 1) +
    draw_plot(time_legend, x = 0.69, y = 0, width = 0.29, height = 1)
  fig <- plot_grid(map_row, legend_row,
    plot_grid(tag_panel(pC, "C"), tag_panel(pD, "D"), nrow = 1,
              rel_widths = c(0.56, 0.44)),
    plot_grid(tag_panel(pE, "E"), tag_panel(pF, "F"), nrow = 1,
              rel_widths = c(0.42, 0.58)),
    plot_grid(tag_panel(pG, "G"), tag_panel(pH, "H"), nrow = 1,
              rel_widths = c(0.66, 0.34)),
    ncol = 1, rel_heights = c(0.30, 0.11, 0.16, 0.18, 0.25))
  panel_ranges <- lapply(map_plots, function(p) {
    pp <- ggplot_build(p)$layout$panel_params[[1]]
    list(x = pp$x.range, y = pp$y.range)
  })
  stopifnot(identical(panel_ranges[[1]], panel_ranges[[2]]),
            identical(panel_ranges[[1]], panel_ranges[[3]]))
  saveRDS(list(equal_viewport_width = 1/3, equal_viewport_height = 0.94,
               shared_ranges = panel_ranges,
               aligned_widths = lapply(map_grobs, function(g) g$widths),
               aligned_heights = lapply(map_grobs, function(g) g$heights)),
          file.path(OUT, "UMAP_equal_panel_layout_QA.rds"))
}

stem <- if (GO_MODE) "Williams_gingival_fibroblast_pseudotime_GO_20261008" else
  paste0("Reference_Fig3_style_gingival_fibroblast_pseudotime_20260918", OUTPUT_TAG)
if (HIDE_UMAP_ISOLATED) stem <- paste0(stem, "_hide_isolated")
if (EQUAL_UMAP_PANELS) stem <- paste0(stem, "_equal_UMAP")
save_exact(fig, stem)
cat("Pseudotime figure completed\n")
