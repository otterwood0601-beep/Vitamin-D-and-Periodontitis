options(stringsAsFactors = FALSE)
set.seed(20260918L)

.libPaths(c(
  "C:/Users/Lin/R/win-library/4.5",
  "C:/Users/Lin/AppData/Local/R/win-library/4.5",
  "C:/Program Files/R/R-4.5.3/library"
))

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(ggrepel)
  library(cowplot)
  library(scales)
  library(ragg)
  library(grid)
})

ROOT <- "C:/wb_links/dlc"
DAT <- Sys.getenv("DLC_ANALYSIS_DIR", file.path(ROOT, "data_derived/tranoncol2026"))
OUT <- Sys.getenv("DLC_FIGURE_OUT", "C:/wb_links/tranoncol_out")
RASTER_OUT <- Sys.getenv("DLC_FIGURE_RASTER_OUT", "C:/wb_links/tranoncol_renders")
OUTPUT_TAG <- Sys.getenv("DLC_OUTPUT_TAG", "")
dir.create(OUT, recursive = TRUE, showWarnings = FALSE)
dir.create(RASTER_OUT, recursive = TRUE, showWarnings = FALSE)

FONT <- "Arial"
TYPE_LEVELS <- c("Immune", "ECM remodeling", "Vascular", "Pre-ECM", "Matrix homeostasis")
TYPE_COLORS <- c(
  "Immune" = "#4FA8C5",
  "ECM remodeling" = "#6CB354",
  "Vascular" = "#F29A3A",
  "Pre-ECM" = "#D95C5C",
  "Matrix homeostasis" = "#9880B9"
)
LINEAGE_COLORS <- c("L1" = "#2D78A7", "L2" = "#E89535", "L3" = "#8A6BAE")
LINEAGE_LABELS <- c(
  "L1" = "Homeostasis > Immune > ECM",
  "L2" = "Homeostasis > Immune > Vascular",
  "L3" = "Homeostasis > Pre-ECM"
)

theme_article <- theme_gray(base_size = 6.4, base_family = FONT) +
  theme(
    panel.grid.major = element_line(colour = "#D8D8D8", linewidth = 0.22),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(colour = "#777777", fill = NA, linewidth = 0.35),
    axis.text = element_text(colour = "black", size = 5.7),
    axis.title = element_text(colour = "black", size = 6.3),
    strip.background = element_blank(),
    strip.text = element_text(colour = "black", face = "bold", size = 6.2),
    legend.title = element_text(size = 5.7),
    legend.text = element_text(size = 5.1),
    plot.title = element_text(size = 6.8, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 5.2, hjust = 0.5),
    plot.margin = margin(2, 2, 2, 2, unit = "pt")
  )

theme_umap <- theme_void(base_family = FONT) +
  theme(
    plot.title = element_text(size = 6.5, face = "bold", hjust = 0.5,
                              margin = margin(b = 1.5, unit = "pt")),
    legend.title = element_text(size = 5.8),
    legend.text = element_text(size = 5.0),
    legend.key.height = unit(7, "pt"),
    legend.key.width = unit(5, "pt"),
    plot.margin = margin(1, 1, 1, 1, unit = "pt")
  )

tag_panel <- function(p, lab, pad = 0.035, size = 15) {
  ggdraw() +
    draw_plot(p, x = pad, y = 0, width = 1 - pad, height = 0.97) +
    draw_label(lab, x = 0.003, y = 0.995, hjust = 0, vjust = 1,
               fontfamily = FONT, fontface = "plain", size = size)
}

add_umap_axes <- function(p, x, y) {
  xr <- range(x, na.rm = TRUE); yr <- range(y, na.rm = TRUE)
  x0 <- xr[1] + 0.05 * diff(xr); y0 <- yr[1] + 0.07 * diff(yr)
  p +
    annotate("segment", x = x0, xend = x0 + 0.19 * diff(xr), y = y0, yend = y0,
             arrow = arrow(length = unit(2.8, "pt")), linewidth = 0.35) +
    annotate("segment", x = x0, xend = x0, y = y0, yend = y0 + 0.19 * diff(yr),
             arrow = arrow(length = unit(2.8, "pt")), linewidth = 0.35) +
    annotate("text", x = x0 + 0.095 * diff(xr), y = y0 - 0.06 * diff(yr),
             label = "UMAP1", size = 1.7, family = FONT) +
    annotate("text", x = x0 - 0.06 * diff(xr), y = y0 + 0.095 * diff(yr),
             label = "UMAP2", angle = 90, size = 1.7, family = FONT)
}

save_exact <- function(plot, stem, width_px = 2000, height_px = 2432) {
  png_path <- file.path(RASTER_OUT, paste0(stem, ".png"))
  pdf_path <- file.path(OUT, paste0(stem, ".pdf"))
  tif_path <- file.path(RASTER_OUT, paste0(stem, ".tiff"))
  agg_png(png_path, width = width_px, height = height_px, units = "px",
          res = 300, background = "white")
  print(plot); dev.off()
  cairo_pdf(pdf_path, width = width_px / 300, height = height_px / 300,
            family = FONT, onefile = TRUE)
  print(plot); dev.off()
  agg_tiff(tif_path, width = width_px, height = height_px, units = "px",
           res = 300, compression = "lzw", background = "white")
  print(plot); dev.off()
}

cell <- fread(file.path(DAT, "32_pseudotime_cell_assignments.csv.gz"))
defs <- fread(file.path(DAT, "33_pseudotime_lineage_definitions.csv"))
curves <- fread(file.path(DAT, "34_pseudotime_curve_coordinates.csv"))
bins <- fread(file.path(DAT, "35_pseudotime_binned_trends.csv"))
state_pos <- fread(file.path(DAT, "36_pseudotime_state_positions.csv"))
gam <- fread(file.path(DAT, "37_pseudotime_donor_aware_GAM_results.csv"))

lineage_ids <- as.character(defs$lineage)
LINEAGE_COLORS <- LINEAGE_COLORS[lineage_ids]
LINEAGE_LABELS <- setNames(as.character(defs$label), lineage_ids)

cell[, fibroblast_short := factor(fibroblast_short, levels = TYPE_LEVELS)]
curves[, lineage := factor(lineage, levels = names(LINEAGE_COLORS))]
bins[, lineage := factor(lineage, levels = names(LINEAGE_COLORS))]
state_pos[, lineage := factor(lineage, levels = names(LINEAGE_COLORS))]
gam[, lineage := factor(lineage, levels = names(LINEAGE_COLORS))]

root_xy <- cell[fibroblast_short == "Matrix homeostasis",
                .(frozen_umap_1 = median(frozen_umap_1),
                  frozen_umap_2 = median(frozen_umap_2))]

pA <- ggplot(cell, aes(frozen_umap_1, frozen_umap_2)) +
  geom_point(aes(fill = fibroblast_short), shape = 21, colour = "white",
             stroke = 0.01, size = 0.30, alpha = 0.78) +
  geom_path(data = curves, aes(umap_1, umap_2, colour = lineage, group = lineage),
            inherit.aes = FALSE, linewidth = 0.85,
            arrow = arrow(type = "closed", length = unit(2.8, "pt"))) +
  geom_point(data = root_xy, aes(frozen_umap_1, frozen_umap_2),
             inherit.aes = FALSE, shape = 23, size = 3.0,
             fill = "#F4E500", colour = "black", stroke = 0.45) +
  annotate("text", x = root_xy$frozen_umap_1, y = root_xy$frozen_umap_2 - 1.15,
           label = "Root reference", family = FONT, size = 1.8) +
  scale_fill_manual(values = TYPE_COLORS, name = "Celltype") +
  scale_colour_manual(values = LINEAGE_COLORS, labels = LINEAGE_LABELS,
                      name = "Inferred path") +
  coord_equal() + theme_umap +
  theme(legend.position = "right") +
  labs(title = "Inferred state paths")
pA <- add_umap_axes(pA, cell$frozen_umap_1, cell$frozen_umap_2)

pt_panel <- function(lin) {
  pt_col <- paste0(lin, "_pseudotime_01")
  wt_col <- paste0(lin, "_weight")
  d <- cell[is.finite(get(pt_col)) & get(wt_col) > 0.05]
  setorderv(d, pt_col)
  cv <- curves[lineage == lin]
  p <- ggplot() +
    geom_point(data = cell, aes(frozen_umap_1, frozen_umap_2),
               colour = "#D6D6D6", size = 0.08) +
    geom_point(data = d, aes(frozen_umap_1, frozen_umap_2, colour = get(pt_col)),
               size = 0.11, alpha = 0.82) +
    geom_path(data = cv, aes(umap_1, umap_2), colour = "black", linewidth = 0.5,
              arrow = arrow(type = "closed", length = unit(2.2, "pt"))) +
    scale_colour_gradientn(colours = c("#2469A0", "#F4E95B", "#D94A3A"),
                           limits = c(0, 1), name = "Pseudotime") +
    coord_equal() + theme_umap +
    theme(legend.position = if (lin == tail(lineage_ids, 1)) "right" else "none") +
    labs(title = lin)
  add_umap_axes(p, cell$frozen_umap_1, cell$frozen_umap_2)
}
pB <- plot_grid(plotlist = lapply(names(LINEAGE_COLORS), pt_panel), nrow = 1)

state_pos[, fibroblast_short := factor(fibroblast_short, levels = rev(TYPE_LEVELS))]
pC <- ggplot(state_pos, aes(median_pseudotime, fibroblast_short)) +
  geom_segment(aes(x = 0, xend = median_pseudotime, yend = fibroblast_short),
               colour = "#BDBDBD", linewidth = 0.45) +
  geom_point(aes(fill = fibroblast_short, size = effective_weight), shape = 21,
             colour = "#555555", stroke = 0.25) +
  facet_wrap(~lineage, nrow = 1) +
  scale_fill_manual(values = TYPE_COLORS, guide = "none") +
  scale_size_continuous(range = c(1.2, 4.0), name = "Effective\ncell weight") +
  scale_x_continuous(limits = c(0, 1), breaks = c(0, 0.5, 1)) +
  labs(x = "Scaled pseudotime", y = NULL, title = "State position along each path") +
  theme_article + theme(legend.position = "right", axis.text.y = element_text(size = 4.8))

disease_bins <- unique(bins[, .(lineage, pseudotime_bin, pseudotime_01,
                                periodontitis_fraction)])
overall_pd <- 100 * mean(cell$disease == "periodontitis")
pD <- ggplot(disease_bins, aes(pseudotime_01, periodontitis_fraction,
                                colour = lineage)) +
  geom_hline(yintercept = overall_pd, linetype = "dashed", colour = "#777777",
             linewidth = 0.35) +
  geom_line(linewidth = 0.75) +
  geom_point(size = 0.8) +
  scale_colour_manual(values = LINEAGE_COLORS, labels = names(LINEAGE_COLORS),
                      name = "Path") +
  scale_y_continuous(labels = function(x) paste0(x, "%")) +
  labs(x = "Scaled pseudotime", y = "Periodontitis cells",
       title = "Disease composition across pseudotime") +
  theme_article + theme(legend.position = "top", legend.text = element_text(size = 4.3))

gdf <- bins[feature == "GDF15_detection"]
gdf[, value := 100 * value]
gdf_lab <- gam[feature == "GDF15_detection",
               .(lineage, label = ifelse(smooth_FDR < 0.001, "FDR < 0.001",
                                         sprintf("FDR = %.3f", smooth_FDR)))]
gdf_rng <- gdf[, .(x = 0.97, y = max(value, na.rm = TRUE) * 0.96), by = lineage]
gdf_lab[gdf_rng, on = "lineage", `:=`(x = i.x, y = i.y)]
pE <- ggplot(gdf, aes(pseudotime_01, value, colour = lineage)) +
  geom_point(size = 0.62, alpha = 0.58) +
  geom_smooth(method = "loess", span = 0.45, se = FALSE, linewidth = 0.75) +
  geom_text(data = gdf_lab, aes(x, y, label = label), inherit.aes = FALSE,
            hjust = 1, vjust = 1, family = FONT, size = 1.8) +
  facet_wrap(~lineage, nrow = 1) +
  scale_colour_manual(values = LINEAGE_COLORS, guide = "none") +
  scale_x_continuous(breaks = c(0, 0.5, 1), labels = c("0", ".5", "1")) +
  labs(x = "Scaled pseudotime", y = "GDF15-positive cells (%)",
       title = "GDF15 detection along inferred paths") + theme_article

gene_titles <- c("MAPK1" = "MAPK1 (ERK2)", "MAPK3" = "MAPK3 (ERK1)", "JUND" = "JUND")
gene_bins <- bins[feature %in% names(gene_titles)]
gene_bins[, feature := factor(feature, levels = names(gene_titles))]
pF <- ggplot(gene_bins, aes(pseudotime_01, value, colour = lineage)) +
  geom_point(size = 0.45, alpha = 0.45) +
  geom_smooth(method = "loess", span = 0.45, se = FALSE, linewidth = 0.72) +
  facet_wrap(~feature, nrow = 1, scales = "free_y", labeller = as_labeller(gene_titles)) +
  scale_colour_manual(values = LINEAGE_COLORS, labels = names(LINEAGE_COLORS),
                      name = "Path") +
  scale_x_continuous(breaks = c(0, 0.5, 1), labels = c("0", ".5", "1")) +
  labs(x = "Scaled pseudotime", y = "Mean normalized expression",
       title = "ERK-related transcripts along pseudotime") + theme_article +
  theme(legend.position = "top", legend.text = element_text(size = 4.3))

program_titles <- c(
  "MAPK_ERK" = "MAPK/ERK response",
  "ECM_synthesis" = "Collagen synthesis",
  "ECM_organization" = "ECM organization",
  "ECM_degradation" = "ECM degradation"
)
program_bins <- bins[feature %in% names(program_titles)]
program_bins[, feature := factor(feature, levels = names(program_titles))]
pG <- ggplot(program_bins, aes(pseudotime_01, value, colour = lineage)) +
  geom_point(size = 0.42, alpha = 0.42) +
  geom_smooth(method = "loess", span = 0.45, se = FALSE, linewidth = 0.72) +
  facet_wrap(~feature, nrow = 2, scales = "free_y", labeller = as_labeller(program_titles)) +
  scale_colour_manual(values = LINEAGE_COLORS, labels = names(LINEAGE_COLORS),
                      name = "Path") +
  scale_x_continuous(breaks = c(0, 0.5, 1), labels = c("0", ".5", "1")) +
  labs(x = "Scaled pseudotime", y = "Lineage-weighted UCell score",
       title = "MAPK/ERK and ECM program dynamics") + theme_article +
  theme(legend.position = "top", legend.text = element_text(size = 4.3))

show_features <- c("GDF15_detection", "MAPK1", "MAPK3", "JUND", "MAPK_ERK",
                   "ECM_synthesis", "ECM_organization", "ECM_degradation")
gam_h <- gam[feature %in% show_features]
gam_h[, feature_label := factor(feature,
  levels = rev(show_features),
  labels = rev(c("GDF15 detection", "MAPK1 (ERK2)", "MAPK3 (ERK1)", "JUND",
                 "MAPK/ERK response", "Collagen synthesis", "ECM organization",
                 "ECM degradation"))
)]
gam_h[, sig_direction := fifelse(smooth_FDR >= 0.05, "Not significant",
                                 fifelse(end_minus_start > 0, "Increase", "Decrease"))]
gam_h[, logFDR := pmin(-log10(pmax(smooth_FDR, 1e-12)), 12)]
pH <- ggplot(gam_h, aes(lineage, feature_label)) +
  geom_point(aes(size = logFDR, fill = sig_direction), shape = 21,
             colour = "#666666", stroke = 0.3) +
  scale_fill_manual(values = c("Increase" = "#D8655A", "Decrease" = "#4F79A7",
                               "Not significant" = "#D0D0D0"), name = NULL) +
  scale_size_continuous(range = c(1.1, 4.2), name = "-log10 FDR") +
  labs(x = "Inferred path", y = NULL,
       title = "Donor-aware trajectory tests",
       subtitle = "Color: end-point direction; size: smooth-term FDR") +
  theme_article + theme(panel.grid = element_blank(), legend.position = "right",
                        axis.text.y = element_text(size = 4.8))

fig <- plot_grid(
  plot_grid(tag_panel(pA, "A"), tag_panel(pB, "B"), nrow = 1,
            rel_widths = c(0.38, 0.62)),
  plot_grid(tag_panel(pC, "C"), tag_panel(pD, "D"), nrow = 1,
            rel_widths = c(0.56, 0.44)),
  plot_grid(tag_panel(pE, "E"), tag_panel(pF, "F"), nrow = 1,
            rel_widths = c(0.42, 0.58)),
  plot_grid(tag_panel(pG, "G"), tag_panel(pH, "H"), nrow = 1,
            rel_widths = c(0.66, 0.34)),
  ncol = 1,
  rel_heights = c(0.28, 0.19, 0.22, 0.31)
)

save_exact(fig, paste0("Reference_Fig3_style_gingival_fibroblast_pseudotime_20260918", OUTPUT_TAG))
cat("Pseudotime figure completed\n")
