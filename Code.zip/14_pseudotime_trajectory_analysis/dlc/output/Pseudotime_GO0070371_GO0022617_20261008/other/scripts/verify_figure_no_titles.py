import json
from pathlib import Path
from PIL import Image
import pymupdf
root = Path(__file__).resolve().parents[2]
figdir = root / '\u56fe'
qa = root / '\u5176\u4ed6' / 'QA'
stem = 'Williams_gingival_fibroblast_pseudotime_GO_20261008_no_titles'
with Image.open(figdir / f'{stem}.png') as im:
    assert im.size == (6614, 6024), im.size
    dpi = im.info['dpi']
    assert all((abs(x - 600) < 0.1 for x in dpi)), dpi
    png_size = im.size
with Image.open(figdir / f'{stem}.tiff') as im:
    assert im.size == png_size
doc = pymupdf.open(figdir / f'{stem}.pdf')
assert len(doc) == 1
page = doc[0]
text = page.get_text()
for term in ['MAPK1 (ERK2)', 'MAPK3 (ERK1)', 'GO:0070371', 'GO:0022617']:
    assert term in text, term
for term in ['Inferred state paths', 'JUND', 'MAPK/ERK response', 'Collagen synthesis', 'ECM organization']:
    assert term not in text, term
font_names = [x[3] for x in page.get_fonts()]
assert font_names and all(('Arial' in x for x in font_names)), font_names
assert all((doc.extract_font(x[0])[3] for x in page.get_fonts())), 'Unembedded font'
outside = []
for block in page.get_text('dict')['blocks']:
    for line in block.get('lines', []):
        for span in line['spans']:
            x0, y0, x1, y1 = span['bbox']
            if x0 < -0.5 or y0 < -0.5 or x1 > page.rect.width + 0.5 or (y1 > page.rect.height + 0.5):
                outside.append({'text': span['text'], 'bbox': span['bbox']})
assert not outside, outside
page.get_pixmap(matrix=pymupdf.Matrix(2, 2)).save(qa / 'pdf_render_no_titles.png')
report = {'pass': True, 'pdf_pages': len(doc), 'pdf_width_mm': page.rect.width * 25.4 / 72, 'pdf_height_mm': page.rect.height * 25.4 / 72, 'png_size': png_size, 'png_dpi': dpi, 'embedded_fonts': font_names, 'text_within_page': True, 'GO_ids_present': True, 'JUND_and_old_curated_labels_absent': True}
(qa / 'figure_no_titles_QA.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report, ensure_ascii=False))
for deleted in ['State position along each path', 'Disease composition across pseudotime', 'GDF15 detection along inferred paths', 'ERK-related transcripts along pseudotime', 'GO pathway expression scores', 'Donor-aware trajectory tests', 'Color: end-point direction', 'Size: smooth-term FDR']:
    assert deleted not in text, deleted
from PIL import ImageChops
with Image.open(figdir / 'Williams_gingival_fibroblast_pseudotime_GO_20261008_hide_isolated_equal_UMAP_legend_v2_Alegend_right_Ablock_left.png') as prior, Image.open(figdir / f'{stem}.png') as revised:
    assert prior.size == revised.size
    w, h = prior.size
    region = (0, 0, w, int(0.3 * h))
    assert ImageChops.difference(prior.crop(region).convert('RGB'), revised.crop(region).convert('RGB')).getbbox() is None, 'First row changed'
report['C_to_H_titles_and_H_subtitle_deleted'] = True
report['first_row_pixel_identical'] = True
(qa / 'figure_no_titles_QA.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print('PASS: requested text removed; first row pixels identical')
