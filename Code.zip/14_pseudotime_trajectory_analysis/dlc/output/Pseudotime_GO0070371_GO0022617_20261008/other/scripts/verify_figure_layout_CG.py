import json
from pathlib import Path
from PIL import Image
import pymupdf
root = Path(__file__).resolve().parents[2]
figdir = root / '\u56fe'
qa = root / '\u5176\u4ed6' / 'QA'
stem = 'Williams_gingival_fibroblast_pseudotime_GO_20261008_layout_CG'
with Image.open(figdir / f'{stem}.png') as im:
    assert im.size == (6614, 7200), im.size
    dpi = im.info['dpi']
    assert all((abs(x - 600) < 0.1 for x in dpi)), dpi
    png_size = im.size
with Image.open(figdir / f'{stem}.tiff') as im:
    assert im.size == png_size
doc = pymupdf.open(figdir / f'{stem}.pdf')
assert len(doc) == 1
page = doc[0]
text = page.get_text()
for term in ['MAPK1 (ERK2)', 'MAPK3 (ERK1)', 'GO:0070371', 'GO:0022617']:
    assert term in text, term
for term in ['Inferred state paths', 'JUND', 'MAPK/ERK response', 'Collagen synthesis', 'ECM organization']:
    assert term not in text, term
font_names = [x[3] for x in page.get_fonts()]
assert font_names and all(('Arial' in x for x in font_names)), font_names
assert all((doc.extract_font(x[0])[3] for x in page.get_fonts())), 'Unembedded font'
outside = []
for block in page.get_text('dict')['blocks']:
    for line in block.get('lines', []):
        for span in line['spans']:
            x0, y0, x1, y1 = span['bbox']
            if x0 < -0.5 or y0 < -0.5 or x1 > page.rect.width + 0.5 or (y1 > page.rect.height + 0.5):
                outside.append({'text': span['text'], 'bbox': span['bbox']})
assert not outside, outside
page.get_pixmap(matrix=pymupdf.Matrix(2, 2)).save(qa / 'pdf_render_layout_CG.png')
report = {'pass': True, 'pdf_pages': len(doc), 'pdf_width_mm': page.rect.width * 25.4 / 72, 'pdf_height_mm': page.rect.height * 25.4 / 72, 'png_size': png_size, 'png_dpi': dpi, 'embedded_fonts': font_names, 'text_within_page': True, 'GO_ids_present': True, 'JUND_and_old_curated_labels_absent': True}
(qa / 'figure_layout_CG_QA.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report, ensure_ascii=False))
for deleted in ['State position along each path', 'Disease composition across pseudotime', 'GDF15 detection along inferred paths', 'ERK-related transcripts along pseudotime', 'GO pathway expression scores', 'Donor-aware trajectory tests', 'Color: end-point direction', 'Size: smooth-term FDR']:
    assert deleted not in text, deleted
from PIL import ImageChops
with Image.open(figdir / 'Williams_gingival_fibroblast_pseudotime_GO_20261008_hide_isolated_equal_UMAP_legend_v2_Alegend_right_Ablock_left.png') as prior, Image.open(figdir / f'{stem}.png') as revised:
    assert prior.width == revised.width
    w, h = prior.size
    region = (0, 0, w, int(0.3 * h))
    assert ImageChops.difference(prior.crop(region).convert('RGB'), revised.crop(region).convert('RGB')).getbbox() is None, 'First row changed'
report['C_to_H_titles_and_H_subtitle_deleted'] = True
report['first_row_pixel_identical'] = True
(qa / 'figure_layout_CG_QA.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print('PASS: requested text removed; first row pixels identical')
assert '-log10 FDR' not in text and 'Not significant' not in text
assert not any((s['text'].strip() == 'H' for b in page.get_text('dict')['blocks'] for l in b.get('lines', []) for s in l['spans']))
borders = []
for d in page.get_drawings():
    if d['color'] is None or any((abs(c - 119 / 255) > 0.015 for c in d['color'])):
        continue
    for item in d['items']:
        if item[0] == 're':
            r = item[1]
            if r.width > 30 and r.height > 30:
                coords = tuple((round(v, 3) for v in r))
                if coords not in borders:
                    borders.append(coords)
c_borders = [r for r in borders if r[0] < page.rect.width * 0.56 and 216 < r[1] < 432]
assert len(c_borders) == 2, c_borders
assert all((abs(r[2] - r[0] - (r[3] - r[1])) < 0.2 for r in c_borders)), c_borders
fdr_spans = [s for b in page.get_text('dict')['blocks'] for l in b.get('lines', []) for s in l['spans'] if s['text'].startswith('FDR = ')]
assert len(fdr_spans) == 2 and abs(fdr_spans[0]['bbox'][1] - fdr_spans[1]['bbox'][1]) < 0.2
report['C_square_panel_borders'] = c_borders
report['E_FDR_bboxes'] = [s['bbox'] for s in fdr_spans]
report['panel_borders'] = borders
report['H_removed'] = True
(qa / 'figure_layout_CG_QA.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps({'C_square_panel_borders': c_borders, 'E_FDR_bboxes': report['E_FDR_bboxes'], 'panel_borders': borders, 'H_removed': True}))
