import csv, hashlib, json, re, html as html_lib
from pathlib import Path
from datetime import datetime
from urllib.request import urlopen, Request
out = Path(__file__).resolve().parents[1] / 'source_data'
sets = {'ERK_GO0070371': ('GO:0070371', 'GOBP_ERK1_AND_ERK2_CASCADE'), 'ECM_GO0022617': ('GO:0022617', 'GOBP_EXTRACELLULAR_MATRIX_DISASSEMBLY')}
records, audit = ([], [])
for feature, (go_id, name) in sets.items():
    url = f'https://www.gsea-msigdb.org/gsea/msigdb/human/geneset/{name}'
    with urlopen(Request(url, headers={'User-Agent': 'Mozilla/5.0'}), timeout=60) as response:
        raw = response.read()
    html = raw.decode('utf-8')
    (out / f'{name}.html').write_text(html, encoding='utf-8')
    text = html_lib.unescape(re.sub('<[^>]+>', ' ', html))
    text = re.sub('\\s+', ' ', text)
    expected = int(re.search('these\\s+(\\d+)\\s+genes', text).group(1))
    genes = []
    for content in re.findall('<a\\b[^>]*href=[\\"\\\'][^\\"\\\']*ensembl\\.org[^\\"\\\']*[\\"\\\'][^>]*>(.*?)</a>', html, re.S | re.I):
        gene = html_lib.unescape(re.sub('<[^>]+>', '', content)).strip()
        if gene and gene not in genes:
            genes.append(gene)
    if len(genes) != expected:
        raise ValueError(f'{name}: expected {expected}, parsed {len(genes)}')
    if go_id not in text:
        raise ValueError(f'Wrong GO mapping for {name}')
    records.append({'feature': feature, 'go_id': go_id, 'msigdb_name': name, 'species': 'Homo sapiens', 'source_url': url, 'snapshot_date': '2026-10-08', 'n_genes': len(genes), 'html_sha256': hashlib.sha256(raw).hexdigest(), 'genes': genes})
    audit.extend(({'feature': feature, 'go_id': go_id, 'gene': g} for g in genes))
    print(name, 'genes=', len(genes), flush=True)
(out / 'go_gene_sets.json').write_text(json.dumps(records, indent=2), encoding='utf-8')
with (out / 'go_gene_sets_full.csv').open('w', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=['feature', 'go_id', 'gene'])
    writer.writeheader()
    writer.writerows(audit)
with (out / 'go_gene_sets_full.gmt').open('w', encoding='utf-8') as f:
    for x in records:
        f.write('\t'.join([x['feature'], x['source_url']] + x['genes']) + '\n')
