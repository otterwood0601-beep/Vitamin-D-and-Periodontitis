options(stringsAsFactors = FALSE)
set.seed(20261008L)
.libPaths(c('C:/Users/Lin/R/win-library/4.5', 'C:/Users/Lin/AppData/Local/R/win-library/4.5', .libPaths()))
suppressPackageStartupMessages({
  library(data.table); library(Seurat); library(UCell); library(mgcv); library(jsonlite)
})
ROOT <- 'C:/wb_links/dlc'
OLD <- 'C:/wb_links/tranoncol2026_Williams_20260920'
OUTROOT <- 'C:/wb_links/pseudotime_go20261008'
OUT <- file.path(OUTROOT, 'source_data')
QA <- file.path(OUTROOT, 'QA')
dir.create(OUT, recursive = TRUE, showWarnings = FALSE)
dir.create(QA, recursive = TRUE, showWarnings = FALSE)
cat('[1/5] Load fixed Williams-only trajectory and GO sets\n')
cell <- fread(file.path(OLD, '32_pseudotime_cell_assignments.csv.gz'))
defs <- fread(file.path(OLD, '33_pseudotime_lineage_definitions.csv'))
stopifnot(nrow(cell) == 14302L, !anyDuplicated(cell$cell_id), all(cell$Study == 'Williams'))
gene_meta <- fromJSON(file.path(OUT, 'go_gene_sets.json'), simplifyVector = FALSE)
features <- setNames(lapply(gene_meta, function(x) unlist(x$genes)),
                     vapply(gene_meta, function(x) x$feature, character(1)))
stopifnot(identical(sort(names(features)), sort(c('ERK_GO0070371', 'ECM_GO0022617'))))

fb <- readRDS('C:/wb_links/dlc_data/outputs/fb_seurat_annotated.rds')
stopifnot(all(cell$cell_id %in% colnames(fb)))
fb <- subset(fb, cells = cell$cell_id)
counts <- LayerData(fb, assay = 'RNA', layer = 'counts')[, cell$cell_id, drop = FALSE]
stopifnot(identical(colnames(counts), cell$cell_id))
audit <- rbindlist(lapply(names(features), function(v) {
  genes <- features[[v]]
  idx <- match(genes, rownames(counts))
  detected <- rep(0L, length(genes))
  detected[!is.na(idx)] <- Matrix::rowSums(counts[idx[!is.na(idx)], , drop = FALSE] > 0)
  data.table(feature = v, gene = genes, present_in_matrix = !is.na(idx),
             n_positive_cells = detected, used_for_score = !is.na(idx))
}))
fwrite(audit, file.path(OUT, 'go_gene_membership_audit.csv'))
coverage <- audit[, .(n_database_genes = .N, n_present_in_matrix = sum(present_in_matrix),
                      n_detected_in_Williams_cells = sum(n_positive_cells > 0)), by = feature]
fwrite(coverage, file.path(OUT, 'go_gene_coverage_summary.csv'))
print(coverage)

cat('[2/5] Calculate UCell scores from the complete database gene sets\n')
uc <- ScoreSignatures_UCell(matrix = counts, features = features, maxRank = 1500,
                           ncores = 1, missing_genes = 'skip')
uc <- as.data.table(uc, keep.rownames = 'cell_id')
setnames(uc, names(uc), sub('_UCell$', '', names(uc)))
uc <- uc[match(cell$cell_id, cell_id)]
stopifnot(identical(uc$cell_id, cell$cell_id))
for (v in names(features)) cell[[v]] <- uc[[v]]
rm(fb, counts); gc()

inventory <- fread(file.path(ROOT, 'data_derived/sample_inventory_GSE164241.csv'))
cell[, gsm := sub('^.*(GSM[0-9]+)$', '\\1', donor_id)]
map <- inventory[match(cell$gsm, gsm)]
stopifnot(!anyNA(map$donor_merged), all(map$tissue == 'Gingiva'))
cell[, original_donor_key := donor_key]
cell[, donor_merged := map$donor_merged]
cell[, donor_key := paste(Study, donor_merged, sep = '||')]
donor_audit <- unique(cell[, .(Study, donor_id, gsm, donor_merged, donor_key, disease)])
fwrite(donor_audit, file.path(OUT, 'donor_merge_audit.csv'))
stopifnot(uniqueN(cell$donor_key) == 18L)
stopifnot(all(donor_audit[, uniqueN(disease), by = donor_key]$V1 == 1L))
cell[, GDF15_detection := as.integer(GDF15 > 0)]
fwrite(cell, file.path(OUT, '32_pseudotime_cell_assignments.csv.gz'))
for (f in c('33_pseudotime_lineage_definitions.csv', '34_pseudotime_curve_coordinates.csv',
            '36_pseudotime_state_positions.csv')) {
  stopifnot(file.copy(file.path(OLD, f), file.path(OUT, f), overwrite = TRUE))
}
wmean <- function(x, w) {
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (!any(ok)) return(NA_real_)
  sum(x[ok] * w[ok]) / sum(w[ok])
}
display_features <- c('GDF15_detection', 'MAPK1', 'MAPK3', names(features))
lineage_ids <- as.character(defs$lineage)
long_list <- vector('list', length(lineage_ids))
bin_list <- vector('list', length(lineage_ids))
cat('[3/5] Rebuild lineage-weighted 30-bin trends\n')
for (j in seq_along(lineage_ids)) {
  lin <- lineage_ids[j]
  d <- copy(cell)
  d[, lineage := lin]
  d[, pseudotime_01 := get(paste0(lin, '_pseudotime_01'))]
  d[, lineage_weight := get(paste0(lin, '_weight'))]
  d <- d[is.finite(pseudotime_01) & is.finite(lineage_weight) & lineage_weight > 0.05]
  d[, pseudotime_bin := pmin(30L, floor(pseudotime_01 * 30) + 1L)]
  long_list[[j]] <- d
  bin_list[[j]] <- rbindlist(lapply(display_features, function(v) {
    a <- d[, .(value = wmean(get(v), lineage_weight), n_cells = .N,
               effective_weight = sum(lineage_weight),
               pseudotime_01 = wmean(pseudotime_01, lineage_weight),
               periodontitis_fraction = 100 * wmean(as.integer(disease == 'periodontitis'), lineage_weight)),
           by = .(lineage, pseudotime_bin)]
    a[, feature := v]
    a
  }))
}
binned <- rbindlist(bin_list)
fwrite(binned, file.path(OUT, '35_pseudotime_binned_trends.csv'))

cat('[4/5] Fit GAMs after repeated-donor merging\n')
fit_one <- function(d, feature) {
  z <- d[, .(y = get(feature), pt = pseudotime_01, w = lineage_weight,
             disease, Study, donor_key)]
  z <- z[is.finite(y) & is.finite(pt) & is.finite(w) & w > 0.05]
  z[, donor_pt_bin := pmin(6L, floor(pt * 6) + 1L)]
  a <- z[, .(y = wmean(y, w), pt = wmean(pt, w), effective_weight = sum(w),
             n_cells = .N), by = .(donor_key, disease, Study, donor_pt_bin)]
  a[, `:=`(disease = droplevels(factor(disease)), Study = droplevels(factor(Study)),
           donor_key = droplevels(factor(donor_key)))]
  a[, model_weight := sqrt(pmin(effective_weight, quantile(effective_weight, 0.90)))]
  fit <- mgcv::gam(y ~ s(pt, k = 5, bs = 'cr') + disease + s(donor_key, bs = 're'),
                  data = a, weights = model_weight, family = gaussian(), method = 'REML')
  sm <- summary(fit)$s.table
  ridx <- grep('^s\\(pt\\)$', rownames(sm))[1]
  ref <- data.table(pt = c(0, 1),
                    disease = factor(rep(levels(a$disease)[1], 2), levels = levels(a$disease)),
                    donor_key = factor(rep(levels(a$donor_key)[1], 2), levels = levels(a$donor_key)))
  pred <- as.numeric(predict(fit, newdata = ref, type = 'response', exclude = 's(donor_key)'))
  saveRDS(fit, file.path(OUT, paste0('model_', d$lineage[1], '_', feature, '.rds')))
  fwrite(a, file.path(OUT, paste0('model_units_', d$lineage[1], '_', feature, '.csv')))
  data.table(feature = feature, n_cells = nrow(z), n_donor_bin_units = nrow(a),
             n_donors = nlevels(a$donor_key), smooth_edf = sm[ridx, 'edf'],
             smooth_statistic = sm[ridx, 'F'], smooth_p = sm[ridx, 'p-value'],
             predicted_start = pred[1], predicted_end = pred[2],
             end_minus_start = pred[2] - pred[1], converged = fit$converged)
}
gam_res <- rbindlist(lapply(seq_along(lineage_ids), function(j) {
  ans <- rbindlist(lapply(display_features, function(v) fit_one(long_list[[j]], v)))
  ans[, lineage := lineage_ids[j]]
  ans
}))
gam_res[, smooth_FDR := p.adjust(smooth_p, method = 'BH')]
gam_res[, direction := fifelse(end_minus_start > 0, 'Increase', 'Decrease')]
setcolorder(gam_res, c('lineage', 'feature', setdiff(names(gam_res), c('lineage', 'feature'))))
fwrite(gam_res, file.path(OUT, '37_pseudotime_donor_aware_GAM_results.csv'))
print(gam_res[, .(lineage, feature, n_donors, smooth_FDR, direction)])

cat('[5/5] Verify outputs and provenance\n')
old_bins <- fread(file.path(OLD, '35_pseudotime_binned_trends.csv'))
for (v in c('GDF15_detection', 'MAPK1', 'MAPK3')) {
  x <- old_bins[feature == v][order(lineage, pseudotime_bin)]
  y <- binned[feature == v][order(lineage, pseudotime_bin)]
  stopifnot(isTRUE(all.equal(x$value, y$value, tolerance = 1e-12)),
            isTRUE(all.equal(x$pseudotime_01, y$pseudotime_01, tolerance = 1e-12)))
}
for (v in names(features)) stopifnot(all(is.finite(cell[[v]])), all(cell[[v]] >= 0 & cell[[v]] <= 1))
stopifnot(nrow(gam_res) == 10L, all(gam_res$converged), all(is.finite(gam_res$smooth_FDR)))
manifest <- list(created_at = '2026-10-08', scope = 'Williams human gingival fibroblasts only',
                 n_cells = nrow(cell), n_original_GSM_labels = uniqueN(cell$donor_id),
                 n_merged_donors = uniqueN(cell$donor_key),
                 donor_groups = donor_audit[, .(n_donors = uniqueN(donor_key)), by = disease],
                 trajectory = 'Existing Slingshot curves, root and cell assignments retained unchanged',
                 gene_sets = gene_meta, coverage = coverage,
                 scoring = 'UCell 2.14.0; raw RNA counts; maxRank=1500; missing_genes=skip; full GO/MSigDB sets',
                 statistics = 'Lineage-weighted donor-by-6-pseudotime-bin aggregation; gaussian REML GAM with smooth pseudotime, disease fixed effect and merged-donor random effect; BH across the 10 displayed tests',
                 figure_F = 'MAPK1 and MAPK3 normalized RNA expression only; JUND removed',
                 figure_G = 'GO:0070371 and GO:0022617 UCell scores only; old curated scores removed',
                 curve_display = 'Lineage-weighted 30-bin means and LOESS; H and E FDR from donor-aware GAM',
                 interpretation = 'GO scores summarize expression of annotated genes, including regulators; they are not phosphorylation or proteolysis measurements',
                 packages = lapply(c('UCell','mgcv','Seurat','data.table'), function(v) list(package=v, version=as.character(packageVersion(v)))))
writeLines(toJSON(manifest, auto_unbox = TRUE, pretty = TRUE), file.path(OUT, '38_pseudotime_manifest.json'))
qa <- list(pass = TRUE, n_cells = nrow(cell), n_merged_donors = uniqueN(cell$donor_key),
           n_tests = nrow(gam_res), all_models_converged = TRUE,
           unchanged_GDF15_MAPK1_MAPK3_bin_values = TRUE, GO_score_range_0_to_1 = TRUE,
           fixed_trajectory_files_copied = TRUE)
writeLines(toJSON(qa, auto_unbox = TRUE, pretty = TRUE), file.path(QA, 'analysis_QA.json'))
cat('[DONE] GO pseudotime revision\n')
