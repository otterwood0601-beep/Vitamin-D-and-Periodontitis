suppressMessages({library(SeuratObject); library(Matrix)})

DER <- "C:/wb_links/dlc_derived"
obj <- readRDS("C:/wb_links/fb_rds/all_conditions_allStudies_CELLxGENE_direct_fibroblast_counts_only.rds")
counts <- obj@assays$RNA@counts
cat("counts:", dim(counts), "\n")
cat("ENSG fraction:", mean(grepl("^ENSG", rownames(counts))), "\n")

cellmeta <- as.data.frame(data.table::fread("C:/wb_links/fig4_src/01_cell_metadata_UMAP_GDF15.csv.gz"))
inv <- as.data.frame(data.table::fread(file.path(DER, "sample_inventory_GSE164241.csv")))
gsm2donor <- setNames(inv$donor_merged, inv$gsm)

merge_donor <- function(d) {
  g <- sub(".*(GSM[0-9]+)$", "\\1", d)
  ifelse(g %in% names(gsm2donor), paste0("Williams_", gsm2donor[g]), d)
}
cellmeta$donor_merged <- merge_donor(cellmeta$donor_id)

common <- intersect(colnames(counts), cellmeta$cell_barcode)
cat("cells matched:", length(common), "/", ncol(counts), "\n")
stopifnot(length(common) > 14000)
counts <- counts[, common]
cellmeta <- cellmeta[match(common, cellmeta$cell_barcode), ]

agg <- function(group) {
  g <- factor(group)
  m <- fac2sparse(g)
  pb <- m %*% t(counts)
  pb <- t(as.matrix(pb))
  colnames(pb) <- levels(g)
  pb
}

pb_donor <- agg(cellmeta$donor_merged)
lib <- colSums(pb_donor)
cpm_donor <- t(t(pb_donor) / lib * 1e6)
logcpm_donor <- log2(cpm_donor + 0.5)

key <- paste(cellmeta$donor_merged, cellmeta$fibroblast_type, sep = "||")
pb_ds <- agg(key)
lib2 <- colSums(pb_ds)
cpm_ds <- t(t(pb_ds) / lib2 * 1e6)
logcpm_ds <- log2(cpm_ds + 0.5)

donor_info <- unique(cellmeta[, c("donor_merged", "Study", "disease")])
gdf_donor <- data.frame(donor_merged = colnames(logcpm_donor),
                        GDF15_logCPM = as.numeric(logcpm_donor["GDF15", ]))
gdf_donor <- merge(gdf_donor, donor_info, by = "donor_merged")

gdf_ds <- data.frame(key = colnames(logcpm_ds), GDF15_logCPM = as.numeric(logcpm_ds["GDF15", ]),
                     libsize = lib2, n_gene_detected = colSums(pb_ds > 0))
split_key <- do.call(rbind, strsplit(gdf_ds$key, "||", fixed = TRUE))
gdf_ds$donor_merged <- split_key[, 1]
gdf_ds$fibroblast_type <- split_key[, 2]
gdf_ds <- merge(gdf_ds, donor_info, by = "donor_merged")

write.csv(gdf_donor, file.path(DER, "A1_GDF15_pseudobulk_donor.csv"), row.names = FALSE)
write.csv(gdf_ds, file.path(DER, "A1_GDF15_pseudobulk_donor_subtype.csv"), row.names = FALSE)

saveRDS(list(counts_donor = pb_donor, logcpm_donor = logcpm_donor,
             counts_donor_subtype = pb_ds, logcpm_donor_subtype = logcpm_ds,
             donor_info = donor_info),
        file.path(DER, "donor_pseudobulk_matrices.rds"))
cat("donors:", ncol(pb_donor), "| donor x subtype:", ncol(pb_ds), "\n")
cat("--- GDF15 donor-level summary ---\n")
print(aggregate(GDF15_logCPM ~ disease, gdf_donor,
                function(x) c(n = length(x), mean = round(mean(x), 3), sd = round(sd(x), 3))))
