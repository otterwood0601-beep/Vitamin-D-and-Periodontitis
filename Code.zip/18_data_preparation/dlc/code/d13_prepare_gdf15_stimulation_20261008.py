from pathlib import Path
import gzip, hashlib, json, re, shutil, sys
import pandas as pd
import numpy as np
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
OUT = ROOT / 'output' / 'GDF15_\u6210\u7ea4\u7ef4\u7ec6\u80de\u708e\u75c7\u523a\u6fc0_\u4e09\u961f\u5217_20261008'
RAW, SD, CODE = [OUT / x for x in ['raw_data', 'source_data', 'code']]
STAGE = Path('C:\\Users\\Lin\\AppData\\Local\\Temp\\gdf15_stim_20261008')
for d in [SD, CODE, STAGE]:
    d.mkdir(parents=True, exist_ok=True)
sys.stdout.reconfigure(encoding='utf8')

def soft_meta(ds):
    text = gzip.open(RAW / (ds + '_family.soft.gz'), 'rt', encoding='utf8').read()
    rows = []
    for block in re.split('(?m)^\\^SAMPLE = ', text)[1:]:
        row = {'GSM': block.split('\n', 1)[0]}
        for line in block.splitlines():
            if line.startswith('!Sample_title = '):
                row['title'] = line.split(' = ', 1)[1]
            elif line.startswith('!Sample_description = '):
                row['description'] = line.split(' = ', 1)[1]
            elif line.startswith('!Sample_characteristics_ch1 = '):
                k, v = line.split(' = ', 1)[1].split(': ', 1)
                row[k] = v
        rows.append(row)
    return pd.DataFrame(rows)
manifest = {'scope': 'All three datasets and all inflammation-vs-matched-control contrasts; no plotting', 'GDF15_Ensembl': 'ENSG00000130513', 'GDF15_Entrez': 9518, 'GSE216757': 'DMSO control and DMSO-Pg20 only; five donor blocks; 4h; DAC groups excluded to avoid drug confounding; edgeR paired quasi-likelihood', 'GSE335644': 'All four conditions; four donor blocks; Fn, IFNg, FnIFNg versus ctrl; edgeR paired quasi-likelihood', 'GSE118691': 'Only normalized FPKM publicly supplied; per-time paired limma on log2(FPKM+0.5). Primary 2/6h exclude donor F because SOFT culture-time contradicts title; 12h donor F has no treatment; 24/48h include all five donors. Title-based all-five sensitivity retained at early times.', 'multiplicity': 'BH across 9 prespecified GDF15 comparisons; also retain whole-transcriptome FDR within each contrast', 'inference': 'Purified cultured GFs; stimulus-specific transcriptional response, not clinical disease causation or tissue composition', 'cohort_overlap': 'GFHD06 and GFHD102 labels occur in both GSE216757 and GSE335644; do not claim fully independent donor cohorts'}
(SD / '00_analysis_plan.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf8')
for ds, fn in [('GSE216757', 'GSE216757_raw-counts.tsv.gz'), ('GSE335644', 'GSE335644_Genes.COUNTS.csv.gz')]:
    meta = soft_meta(ds)
    d = pd.read_csv(RAW / fn, sep='\t', index_col=0)
    if ds == 'GSE216757':
        meta['sample'] = meta.description
        meta['donor'] = meta['cell line']
        meta['condition'] = meta.treatment.map({'DMSO-medium': 'ctrl', 'DMSO-Pg20': 'Pg', 'DAC-medium': 'DAC_ctrl', 'DAC-Pg20': 'DAC_Pg'})
        keep = meta.condition.isin(['ctrl', 'Pg'])
        meta = meta[keep].copy()
    else:
        aliases = {re.match('(IF\\d+)_', col).group(1): col for col in d.columns}
        meta['sample'] = [aliases[x.replace('Library name: ', '')] for x in meta.description]
        meta['donor'] = meta['cell line']
        meta['condition'] = meta.treatment
    meta = meta.sort_values(['donor', 'condition']).reset_index(drop=True)
    assert not meta.duplicated(['donor', 'condition']).any()
    d = d[meta['sample']]
    d.index = d.index.astype(str).str.split('.').str[0]
    d = d.groupby(level=0, sort=False).sum()
    assert 'ENSG00000130513' in d.index
    assert np.isfinite(d.to_numpy()).all() and (d.to_numpy() >= 0).all()
    assert set(meta['sample']) == set(d.columns)
    d.to_csv(STAGE / (ds + '_counts.tsv'), sep='\t')
    meta.to_csv(STAGE / (ds + '_meta.csv'), index=False)
    meta.to_csv(SD / (ds + '_sample_manifest.csv'), index=False)
    d.loc[['ENSG00000130513']].to_csv(SD / (ds + '_GDF15_raw_counts.csv'))
    print(ds, 'samples', len(meta), 'donors', meta.donor.nunique(), flush=True)
ds = 'GSE118691'
meta = soft_meta(ds)
meta['sample'] = meta.title + '_FPKM'
meta['donor'] = meta.title.str[0]
meta['title_time'] = meta.title.str.extract('[B-F](\\d+)', expand=False).astype(int)
meta['SOFT_time'] = meta['culture time'].str.rstrip('h').astype(int)
meta['condition'] = meta.title.str[-1].map({'C': 'ctrl', 'F': 'Fn'}).fillna('baseline')
meta['time_disagreement'] = meta.title_time != meta.SOFT_time
meta['primary_eligible'] = (meta.condition != 'baseline') & ~meta.time_disagreement
meta.to_csv(SD / (ds + '_sample_manifest.csv'), index=False)
meta.to_csv(STAGE / (ds + '_meta.csv'), index=False)
bad = meta[meta.time_disagreement]
bad.to_csv(SD / (ds + '_time_label_disagreements.csv'), index=False)
full = pd.read_csv(RAW / 'GSE118691_AllSamples.GeneExpression.FPKM.txt.gz', sep='\t', index_col=0)
gdf = full[full.Symbol == 'GDF15']
assert len(gdf) == 1 and int(gdf.index[0]) == 9518
expr = full[meta['sample']].copy()
expr.index = expr.index.astype(str)
assert expr.index.is_unique and (expr.to_numpy() >= 0).all()
expr.to_csv(STAGE / (ds + '_FPKM.tsv'), sep='\t')
gdf[meta['sample']].to_csv(SD / (ds + '_GDF15_FPKM.csv'))
print('Time conflicts:\n', bad[['GSM', 'title', 'title_time', 'SOFT_time']].to_string(index=False), flush=True)
old = ROOT / 'output' / 'GDF15_\u6210\u7ea4\u7ef4\u7ec6\u80de\u5f71\u54cd_AB_20261008' / 'source_data' / '05_FANTOM5_paired_GDF15_statistics.csv'
shutil.copy2(old, SD / 'FANTOM5_previous_paired_result.csv')
hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in RAW.iterdir()}
(SD / '01_raw_file_SHA256.json').write_text(json.dumps(hashes, indent=2), encoding='utf8')
shutil.copy2(__file__, CODE / Path(__file__).name)
print('[DONE] audited inputs ready', flush=True)
