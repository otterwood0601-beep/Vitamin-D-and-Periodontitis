suppressMessages(library(SeuratObject))

rds_path <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/05_\u5355\u7ec6\u80deRNA/\u6d3e\u751f\u8f93\u5165/GDF15_Figure1/input_fb/all_conditions_allStudies_CELLxGENE_direct_fibroblast_counts_only.rds"
obj <- readRDS(rds_path)
cat("assays:", names(obj@assays), "\n")
cat("default assay:", obj@active.assay, "\n")
meta <- obj@meta.data
cat("meta cols:", paste(head(colnames(meta), 30), collapse = ", "), "\n")
counts <- tryCatch(obj@assays$RNA@counts, error = function(e) obj@assays[[obj@active.assay]]@counts)
cat("counts dim:", dim(counts), "\n")
cat("gene head:", head(rownames(counts), 3), "\n")
cat("cell head:", head(colnames(counts), 3), "\n")
cat("GDF15 present:", "GDF15" %in% rownames(counts), "\n")
for (cc in c("donor_id", "fibroblast_type", "disease", "fb_id", "Study")) {
  if (cc %in% colnames(meta)) cat(cc, "levels:", length(unique(meta[[cc]])), "\n")
}
saveRDS(list(meta_cols = colnames(meta)), "E:/\u8840\u6e05\u7ef4\u751f\u7d20D DLC/data_derived/rds_structure_probe.rds")
