x <- readRDS("E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/05_\u5355\u7ec6\u80deRNA/\u6d3e\u751f\u8f93\u5165/GDF15_Figure1/input_fb/all_conditions_allStudies_CELLxGENE_direct_fibroblast_counts_only.rds")
cat("class:", class(x), "\n")
if (is.list(x)) cat("names:", head(names(x), 20), "\n")
m <- NULL
if (methods::is(x, "dgCMatrix") || is.matrix(x)) m <- x
if (is.list(x) && "counts" %in% names(x)) m <- x$counts
if (is.list(x) && is.null(m)) {
  for (nm in names(x)) if (methods::is(x[[nm]], "dgCMatrix")) { m <- x[[nm]]; cat("using slot:", nm, "\n"); break }
}
if (!is.null(m)) {
  cat("dim:", dim(m), "\n")
  cat("rownames head:", head(rownames(m), 5), "\n")
  cat("colnames head:", head(colnames(m), 5), "\n")
  cat("GDF15 in rows:", "GDF15" %in% rownames(m), "\n")
}
