options(stringsAsFactors = FALSE)
source("E:/\u8840\u6e05\u7ef4\u751f\u7d20D DLC/00_\u5171\u7528\u914d\u7f6e/project_paths.R")
ensure_dirs("01_\u6570\u636e\u51c6\u5907")
suppressPackageStartupMessages(library(data.table))

sets <- list(
  MAPK_ERK_transcriptional_response = c(
    "FOS","FOSB","FOSL1","FOSL2","JUN","JUNB","JUND","EGR1","EGR2","EGR3",
    "DUSP1","DUSP2","DUSP4","DUSP5","DUSP6","DUSP8","DUSP10","SPRY1","SPRY2","SPRY4",
    "ETV1","ETV4","ETV5","IER2","IER3","IER5","GEM","CYR61","CTGF","ATF3",
    "KLF2","NR4A1","NR4A2","NR4A3","RGS2","RGS1","MXD1","PLAUR","IL8","PTGS2"),
  MAPK_JNK_p38_transcriptional_response = c(
    "JUN","JUNB","JUND","ATF2","ATF3","ATF4","DDIT3","MAFB","HSPA1A","HSPA1B",
    "HSPB1","HSPH1","DNAJB1","GADD45A","GADD45B","GADD45G","TNFAIP3","TRIB3","PPP1R15A","ZFP36"),
  ECM_synthesis_collagen = c(
    "COL1A1","COL1A2","COL3A1","COL5A1","COL5A2","COL6A1","COL6A2","COL6A3",
    "COL8A1","COL11A1","COL12A1","COL14A1","COL15A1","COL16A1","COL18A1",
    "P4HA1","P4HA2","P4HA3","PLOD1","PLOD2","PLOD3","PCOLCE","PCOLCE2","SC65","HSP47","SERPINH1"),
  ECM_organization_structure = c(
    "FN1","TNC","THBS1","THBS2","FBN1","FBN2","ELN","LUM","DCN","ASPN","FMOD",
    "OGN","PRELP","LAMA2","LAMA4","LAMB1","LAMB2","LAMC1","NID1","NID2","TGM2",
    "LOX","LOXL1","LOXL2","LOXL3","TENASCIN","HTRA1"),
  ECM_degradation_MMP_ADAMTS = c(
    "MMP1","MMP2","MMP3","MMP7","MMP8","MMP9","MMP10","MMP11","MMP12","MMP13",
    "MMP14","MMP15","MMP16","MMP19","MMP24","MMP27","MMP28",
    "ADAMTS1","ADAMTS2","ADAMTS4","ADAMTS5","ADAMTS8","ADAMTS9","ADAMTS12",
    "ADAM8","ADAM10","ADAM12","ADAM17",
    "CTSB","CTSC","CTSD","CTSK","CTSL","CTSS","CTSV","CTSZ"),
  ECM_inhibitors_TIMP = c(
    "TIMP1","TIMP2","TIMP3","TIMP4","RECK","SERPINE1","SERPINF2","CSTB","EFEMP2"),
  ECM_adhesion_integrin = c(
    "ITGA1","ITGA2","ITGA3","ITGA4","ITGA5","ITGA6","ITGA7","ITGA8","ITGA9","ITGA10","ITGA11",
    "ITGB1","ITGB2","ITGB3","ITGB4","ITGB5","ITGB6","ITGB7","ITGB8","TLN1","TLN2","VCL","PXN"),
  WNT_niche_fibroblast_signature = c(
    "APCDD1","SFRP2","DKK3","WIF1","RSPO3","PDPN","SFRP1","SFRP4","DKK1","RSPO1",
    "LEF1","AXIN2","LGR5"),
  VDR_target_signature = c(
    "CYP24A1","CYP24A1P1","TRPV6","CALB1","CDKN1A","IGFBP3","IGFBP5","BCL2L1","SPP1",
    "BGLAP","LPL","THBD","SERPINB1","VDR","CYP27B1","CYP2R1","GC","KLK1","KLF4","FOS")
)

desc <- c(
  MAPK_ERK_transcriptional_response       = "ERK/AP-1 early-response transcriptional footprint (DUSP/SPRY/ETV/IER/NR4A)",
  MAPK_JNK_p38_transcriptional_response   = "JNK/p38 stress-response transcriptional footprint (ATF/GADD45/HSP)",
  ECM_synthesis_collagen                  = "Collagen synthesis/processing: collagens + prolyl/lysyl hydroxylases (P4HA/PLOD/PCOLCE)",
  ECM_organization_structure              = "ECM structural organization: FN/TNC/THBS/FBN/ELN/PGs + lysyl oxidases",
  ECM_degradation_MMP_ADAMTS              = "ECM degradation: MMP/ADAMTS/ADAMTS + cathepsins",
  ECM_inhibitors_TIMP                     = "ECM degradation inhibitors: TIMP/RECK/SERPINE1",
  ECM_adhesion_integrin                   = "ECM adhesion: integrins + focal adhesion adaptors",
  WNT_niche_fibroblast_signature          = "WNT-niche gingival fibroblast signature (project-predefined)",
  VDR_target_signature                    = "Canonical VDR target genes"
)

fb_meta_only <- TRUE
if (fb_meta_only) {
  
}
manifest <- data.frame(
  set_name = rep(names(sets), sapply(sets, length)),
  gene = unlist(sets),
  set_description = unname(desc[rep(names(sets), sapply(sets, length))]),
  n_genes = rep(sapply(sets, length), sapply(sets, length)),
  locked = TRUE,
  created_at = format(Sys.time())
)
gmt_path <- file.path(WORK, "01_\u6570\u636e\u51c6\u5907/outputs/curated_gene_sets_v1.gmt")
writeLines(sprintf("%s\t%s\t%s", names(sets), desc, sapply(sets, paste, collapse = "\t")), gmt_path)
fwrite(manifest, file.path(WORK, "01_\u6570\u636e\u51c6\u5907/outputs/curated_gene_sets_manifest.csv"))
cat("[done] GMT written:", gmt_path, "\n")
print(data.frame(set = names(sets), n = sapply(sets, length)))
