import concurrent.futures
import datetime as dt
import gzip
import hashlib
import json
import re
from pathlib import Path
import requests
ROOT = Path(__file__).resolve().parent
META = ROOT / 'geo_metadata'
META.mkdir(exist_ok=True)
LOCAL = Path('E:/\u8840\u6e05\u7ef4\u751f\u7d20D DLC/01_\u6570\u636e\u51c6\u5907')
TERMS = '(gingiva OR gingival) AND (periodontitis OR periodontal disease) AND "Homo sapiens"[Organism] AND gse[Entry Type]'
SESSION = requests.Session()

def get(url, params=None):
    r = requests.get(url, params=params, timeout=45)
    r.raise_for_status()
    return r

def study(acc):
    target = META / f'{acc}_series.soft.txt'
    url = 'https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi'
    if target.exists():
        body = target.read_text(encoding='utf-8')
    else:
        body = get(url, {'acc': acc, 'targ': 'self', 'form': 'text', 'view': 'brief'}).text
        if '^SERIES = ' + acc not in body:
            raise ValueError(f'{acc}: response is not series SOFT metadata')
        target.write_text(body, encoding='utf-8')
    tags = {}
    for line in body.splitlines():
        if line.startswith('!Series_') and ' = ' in line:
            key, val = line.split(' = ', 1)
            tags.setdefault(key.removeprefix('!Series_'), []).append(val)
    tags.update(accession=acc, source=url + '?acc=' + acc, local_series_matrix=[str(x) for x in (LOCAL / f'external_{acc}').glob('*matrix*')], metadata_sha256=hashlib.sha256(body.encode()).hexdigest())
    return tags

def main():
    es = get('https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi', {'db': 'gds', 'term': TERMS, 'retmode': 'json', 'retmax': 250}).json()
    ids = es['esearchresult']['idlist']
    print('Official GEO search:', es['esearchresult']['count'], 'records', flush=True)
    gs = get('https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi', {'db': 'gds', 'id': ','.join(ids), 'retmode': 'json'}).json()['result']
    records = [gs[x] for x in gs['uids']]
    dest = ROOT / '00_GEO_search_receipt.json'
    if not dest.exists():
        dest.write_text(json.dumps({'query': TERMS, 'retrieved_at': dt.datetime.now(dt.timezone(dt.timedelta(hours=8))).isoformat(), 'records': records}, ensure_ascii=False, indent=2), encoding='utf-8')
    found = sorted({r['accession'] for r in records if r.get('accession', '').startswith('GSE')})
    print('Accessions:', ','.join(found), flush=True)
    leads = {'GSE10334', 'GSE16134', 'GSE23586', 'GSE6751', 'GSE79705', 'GSE106090', 'GSE103184', 'GSE152518', 'GSE173078', 'GSE223328', 'GSE223924', 'GSE27993'}
    for r in records:
        typ = str(r.get('gdstype', '')).lower()
        if 'expression profiling' in typ:
            leads.add(r['accession'])
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        futs = {pool.submit(study, a): a for a in sorted(leads)}
        for f in concurrent.futures.as_completed(futs):
            a = futs[f]
            try:
                r = f.result()
                results.append(r)
                print(a, ' | '.join(r.get('type', [])), 'samples=' + str(len(r.get('sample_id', []))), ' | '.join(r.get('title', [])), flush=True)
            except Exception as e:
                results.append({'accession': a, 'error': str(e)})
                print(a, 'ERROR', str(e), flush=True)
    out = ROOT / '01_GEO_series_inventory.json'
    if out.exists():
        raise FileExistsError('Inventory already exists; preserve it and inspect rather than overwrite.')
    out.write_text(json.dumps(sorted(results, key=lambda x: x['accession']), ensure_ascii=False, indent=2), encoding='utf-8')
if __name__ == '__main__':
    main()
