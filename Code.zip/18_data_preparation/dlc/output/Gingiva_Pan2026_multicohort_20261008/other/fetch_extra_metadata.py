import json, sys, requests
from fetch_candidate_inputs import ROOT, RAW, retrieve, matrix_meta
from fetch_annotations import fetch
sys.stdout.reconfigure(encoding='utf-8')
for acc in ['GPL26963', 'GPL16956']:
    try:
        print(fetch(acc), flush=True)
    except Exception as e:
        print(acc, str(e), flush=True)
acc = 'GSE267170'
url = f'https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc={acc}&targ=self&form=text&view=brief'
r = requests.get(url, timeout=60)
r.raise_for_status()
p = ROOT / 'geo_metadata' / f'{acc}_series.soft.txt'
if not p.exists():
    p.write_bytes(r.content)
print(r.text, flush=True)
target = RAW / acc
target.mkdir(exist_ok=True)
p = target / f'{acc}_series_matrix.txt.gz'
retrieve(f'https://ftp.ncbi.nlm.nih.gov/geo/series/{acc[:-3]}nnn/{acc}/matrix/{p.name}', p)
a = matrix_meta(p)
out = target / 'metadata_expression_audit.json'
if not out.exists():
    out.write_text(json.dumps({'accession': acc, 'matrices': [a], 'supplements': []}, ensure_ascii=False, indent=2), encoding='utf-8')
print('GSE267170', a['sample_metadata'].get('!Sample_title'), a['sample_metadata'].get('!Sample_characteristics_ch1'), flush=True)
