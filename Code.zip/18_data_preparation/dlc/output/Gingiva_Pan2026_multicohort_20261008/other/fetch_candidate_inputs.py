import csv, gzip, hashlib, json, re, sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests
sys.stdout.reconfigure(encoding='utf-8')
ROOT = Path(__file__).resolve().parent
RAW = ROOT / '\u539f\u59cb\u8f93\u5165'
RAW.mkdir(exist_ok=True)
LOCAL = Path('E:/\u8840\u6e05\u7ef4\u751f\u7d20D DLC/01_\u6570\u636e\u51c6\u5907')
ACCS = ['GSE16134', 'GSE10334', 'GSE173078', 'GSE106090', 'GSE223328', 'GSE189022', 'GSE243173', 'GSE23586', 'GSE273165', 'GSE306998', 'GSE223924']

def retrieve(url, path):
    if path.exists():
        return
    temp = path.with_name(path.name + '.part')
    if temp.exists():
        raise FileExistsError(str(temp))
    with requests.get(url, timeout=(20, 60), stream=True) as r:
        r.raise_for_status()
        expected = int(r.headers.get('Content-Length', 0))
        n = 0
        with temp.open('xb') as f:
            for chunk in r.iter_content(2 ** 20):
                f.write(chunk)
                n += len(chunk)
        if expected and n != expected:
            raise ValueError('Content-Length mismatch ' + str(path))
    if path.name.endswith('.gz'):
        with gzip.open(temp, 'rb') as g:
            while g.read(2 ** 20):
                pass
    temp.rename(path)
    print('Downloaded', path.name, n, 'bytes', flush=True)

def matrix_meta(path):
    rows = {}
    table_rows = 0
    columns = None
    with gzip.open(path, 'rt', encoding='utf-8', errors='replace') as f:
        for line in f:
            if line.startswith('!Sample_'):
                vals = next(csv.reader([line], delimiter='\t'))
                rows.setdefault(vals[0], []).append(vals[1:])
            elif line.startswith('!series_matrix_table_begin'):
                columns = next(csv.reader([next(f)], delimiter='\t'))
            elif columns and (not line.startswith('!')):
                table_rows += 1
    return {'matrix_path': str(path), 'expression_rows': table_rows, 'expression_columns': columns, 'sample_metadata': rows}

def study(acc):
    target = RAW / acc
    target.mkdir(exist_ok=True)
    base = f'https://ftp.ncbi.nlm.nih.gov/geo/series/{acc[:-3]}nnn/{acc}'
    series = (ROOT / 'geo_metadata' / f'{acc}_series.soft.txt').read_text(encoding='utf-8')
    files = []
    local = list((LOCAL / f'external_{acc}').glob('*series_matrix*.gz'))
    if local:
        files = local
    else:
        r = requests.get(base + '/matrix/', timeout=40)
        r.raise_for_status()
        names = sorted(set(re.findall('href="([^"/]+series_matrix[^"/]*\\.gz)"', r.text)))
        for name in names:
            p = target / name
            retrieve(base + '/matrix/' + name, p)
            files.append(p)
    mats = [matrix_meta(p) for p in files]
    supplements = []
    for url in re.findall('^!Series_supplementary_file = (.*)$', series, re.M):
        url = url.replace('ftp://', 'https://').strip()
        name = url.rsplit('/', 1)[-1]
        want = acc == 'GSE189022' and 'mRNA_lncRNA' in name or (acc == 'GSE243173' and name.endswith('_RawCountFile.txt.gz')) or (acc == 'GSE273165' and name.endswith('.xlsx')) or (acc == 'GSE306998' and 'Expression_with_annotation' in name)
        if want:
            p = target / name
            retrieve(url, p)
            supplements.append(str(p))
    result = {'accession': acc, 'source': f'https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc={acc}', 'matrices': mats, 'supplements': supplements}
    out = target / 'metadata_expression_audit.json'
    if not out.exists():
        out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    for m in mats:
        sm = m['sample_metadata']
        n = len(sm.get('!Sample_geo_accession', [[]])[0])
        print(acc, 'samples', n, 'expression_rows', m['expression_rows'], flush=True)
        for key in ['!Sample_title', '!Sample_source_name_ch1', '!Sample_characteristics_ch1']:
            for vals in sm.get(key, []):
                print(' ', key, vals[:5], flush=True)
    return result

def main():
    receipts = []
    with ThreadPoolExecutor(max_workers=3) as pool:
        jobs = {pool.submit(study, a): a for a in ACCS}
        for fut in as_completed(jobs):
            try:
                receipts.append(fut.result())
            except Exception as e:
                receipts.append({'accession': jobs[fut], 'error': str(e)})
                print(jobs[fut], 'ERROR', e, flush=True)
    dest = ROOT / '02_processed_input_receipt.json'
    if not dest.exists():
        dest.write_text(json.dumps(receipts, ensure_ascii=False, indent=2), encoding='utf-8')
if __name__ == '__main__':
    main()
