import sys, json, re
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests
from fetch_candidate_inputs import retrieve, matrix_meta, RAW, ROOT
sys.stdout.reconfigure(encoding='utf-8')

def fetch(acc):
    if acc.startswith('GPL'):
        p = ROOT / 'geo_metadata' / f'{acc}_platform.soft.txt'
        if p.exists():
            return str(p)
        url = f'https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc={acc}&targ=self&form=text&view=full'
        r = requests.get(url, timeout=(20, 180))
        r.raise_for_status()
        if '!platform_table_begin' not in r.text:
            raise ValueError('Missing platform table ' + acc)
        p.write_bytes(r.content)
        return str(p)
    target = RAW / acc
    target.mkdir(exist_ok=True)
    name = f'{acc}_series_matrix.txt.gz'
    p = target / name
    retrieve(f'https://ftp.ncbi.nlm.nih.gov/geo/series/{acc[:-3]}nnn/{acc}/matrix/{name}', p)
    result = matrix_meta(p)
    out = target / 'fresh_metadata_expression_audit.json'
    if not out.exists():
        out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    return str(p)
if __name__ == '__main__':
    with ThreadPoolExecutor(max_workers=3) as pool:
        jobs = {pool.submit(fetch, a): a for a in ['GPL570', 'GPL21185', 'GPL21827', 'GSE10334']}
        for job in as_completed(jobs):
            try:
                print(jobs[job], (fetch_result := job.result()), flush=True)
            except Exception as e:
                print(jobs[job], 'ERROR', str(e), flush=True)
