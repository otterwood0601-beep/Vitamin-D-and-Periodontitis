from __future__ import annotations
import argparse
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd
from scipy.ndimage import gaussian_filter
from scipy.spatial import cKDTree

def adaptive_knn_linear_smooth(coordinates: np.ndarray, expression: np.ndarray, neighbours: int) -> tuple[np.ndarray, np.ndarray, float]:
    tree = cKDTree(coordinates)
    distances, indices = tree.query(coordinates, k=min(neighbours, len(coordinates)))
    if distances.ndim == 1:
        distances = distances[:, None]
        indices = indices[:, None]
    local_scale = np.maximum(distances[:, -1], 1e-08)
    weights = np.exp(-0.5 * np.square(distances / local_scale[:, None]))
    weight_sums = np.maximum(np.sum(weights, axis=1), 1e-12)
    normalized_weights = weights / weight_sums[:, None]
    neighbour_expression = expression[indices]
    smoothed = np.sum(normalized_weights * neighbour_expression, axis=1)
    local_support = np.any(neighbour_expression > 0, axis=1)
    max_row_sum_error = float(np.max(np.abs(np.sum(normalized_weights, axis=1) - 1.0)))
    return (smoothed, local_support, max_row_sum_error)

def absolute_spatial_density_check(scissor_plus_xy: np.ndarray, gdf15_xy: np.ndarray, bins: int=180, sigma_bins: float=2.0) -> dict[str, float | int | str | bool]:
    if len(scissor_plus_xy) == 0:
        raise ValueError('No Scissor+ coordinates available for density QA')
    all_xy = scissor_plus_xy
    x_pad = max(np.ptp(all_xy[:, 0]) * 0.03, 0.1)
    y_pad = max(np.ptp(all_xy[:, 1]) * 0.03, 0.1)
    x_range = (float(all_xy[:, 0].min() - x_pad), float(all_xy[:, 0].max() + x_pad))
    y_range = (float(all_xy[:, 1].min() - y_pad), float(all_xy[:, 1].max() + y_pad))
    plus_hist, _, _ = np.histogram2d(scissor_plus_xy[:, 0], scissor_plus_xy[:, 1], bins=bins, range=[x_range, y_range])
    if len(gdf15_xy):
        gdf_hist, _, _ = np.histogram2d(gdf15_xy[:, 0], gdf15_xy[:, 1], bins=bins, range=[x_range, y_range])
    else:
        gdf_hist = np.zeros_like(plus_hist)
    plus_density = gaussian_filter(plus_hist, sigma=sigma_bins, mode='constant')
    gdf_density = gaussian_filter(gdf_hist, sigma=sigma_bins, mode='constant')
    plus_peak = float(np.max(plus_density))
    gdf_peak = float(np.max(gdf_density))
    ratio = float(gdf_peak / plus_peak) if plus_peak > 0 else 0.0
    return {'definition': 'absolute cell-count intensity on one 180x180 UMAP grid; both layers use the same Gaussian sigma=2 bins; no probability normalization', 'scissor_plus_cells': int(len(scissor_plus_xy)), 'gdf15_highlighted_cells': int(len(gdf15_xy)), 'scissor_plus_peak_density': plus_peak, 'gdf15_peak_density': gdf_peak, 'gdf15_to_scissor_plus_peak_ratio': ratio, 'required_upper_ratio': 1.2, 'passes_120_percent_limit': bool(ratio <= 1.2 + 1e-12)}

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('combination_dir', type=Path)
    parser.add_argument('--neighbours', type=int, default=40)
    args = parser.parse_args()
    combo = args.combination_dir.resolve()
    task_dir = combo / '00_\u6e90\u6570\u636e\u4e0e\u5ba1\u8ba1' / 'Scissor_GDF15\u914d\u5957_\u590d\u7528\u65e2\u6709\u4ee3\u7801'
    source_path = task_dir / 'F.J.GDF15\u5728\u5404\u4e2a\u7ec6\u80de\u4e2d\u7684\u8868\u8fbe\u5730\u56fe_\u9010\u7ec6\u80de\u6e90\u6570\u636e.csv.gz'
    data = pd.read_csv(source_path, low_memory=False)
    required = {'cell_barcode', 'UMAP_1', 'UMAP_2', 'subtype_display', 'Scissor_state', 'GDF15_log_normalized'}
    missing = required.difference(data.columns)
    if missing:
        raise RuntimeError(f'Missing GDF15 source columns: {sorted(missing)}')
    if len(data) != 15371 or data['cell_barcode'].duplicated().any():
        raise RuntimeError('Expected 15,371 unique full-atlas fibroblasts')
    numeric_cols = ['UMAP_1', 'UMAP_2', 'GDF15_log_normalized']
    for column in numeric_cols:
        data[column] = pd.to_numeric(data[column], errors='coerce')
    if data[numeric_cols].isna().any().any():
        raise RuntimeError('Non-finite coordinate/expression values detected')
    plus = data.loc[data['Scissor_state'].eq('Vitamin D3+')].copy()
    if len(plus) < 10:
        raise RuntimeError('Too few Scissor+ cells for the inherited 40-NN smoother')
    plus_xy = plus[['UMAP_1', 'UMAP_2']].to_numpy(float)
    plus_expression = plus['GDF15_log_normalized'].to_numpy(float)
    smoothed, local_support, row_sum_error = adaptive_knn_linear_smooth(plus_xy, plus_expression, neighbours=args.neighbours)
    plus['GDF15_knn_linear_smoothed'] = smoothed
    plus['has_detected_GDF15_neighbour'] = local_support
    highlighted = plus.loc[local_support].copy()
    if len(highlighted) > len(plus):
        raise AssertionError('Highlighted GDF15 cells exceed Scissor+ cells')
    if not highlighted['Scissor_state'].eq('Vitamin D3+').all():
        raise AssertionError('A non-Scissor+ cell entered the GDF15 highlight')
    if row_sum_error > 1e-10:
        raise AssertionError('Linear smoother weights do not sum to one')
    density_qa = absolute_spatial_density_check(plus_xy, highlighted[['UMAP_1', 'UMAP_2']].to_numpy(float))
    if not density_qa['passes_120_percent_limit']:
        raise AssertionError('GDF15 peak density exceeds 120% of the Scissor+ peak density')
    fig, ax = plt.subplots(figsize=(9.0, 7.0))
    fig.subplots_adjust(left=0.115, right=0.89, bottom=0.115, top=0.92)
    ax.scatter(data['UMAP_1'], data['UMAP_2'], s=0.85, color='#E2E2E2', linewidths=0, rasterized=False, zorder=1)
    red_cmap = LinearSegmentedColormap.from_list('gdf15_knn_red', ['#F4A39C', '#EE7C73', '#B2182B'])
    positive_scores = highlighted['GDF15_knn_linear_smoothed'].to_numpy(float)
    if len(positive_scores):
        lower = float(np.quantile(positive_scores, 0.05))
        upper = float(np.quantile(positive_scores, 0.98))
        if not np.isfinite(lower) or not np.isfinite(upper) or upper <= lower:
            lower = float(np.min(positive_scores))
            upper = float(np.max(positive_scores) + 1e-12)
        scatter = ax.scatter(highlighted['UMAP_1'], highlighted['UMAP_2'], s=2.3, c=positive_scores, cmap=red_cmap, norm=Normalize(vmin=lower, vmax=upper, clip=True), linewidths=0, rasterized=False, zorder=5)
        colorbar = fig.colorbar(scatter, ax=ax, fraction=0.04, pad=0.018)
        colorbar.set_label(f'GDF15 local score ({args.neighbours}-NN linear smoothed)', fontsize=8)
        colorbar.ax.tick_params(labelsize=7)
    legend_handles = [Line2D([], [], marker='o', linestyle='', markersize=4, markerfacecolor='#E2E2E2', markeredgecolor='none', label='All fibroblasts'), Line2D([], [], marker='o', linestyle='', markersize=4, markerfacecolor='#EE7C73', markeredgecolor='none', label='Scissor+ local GDF15 signal')]
    ax.legend(handles=legend_handles, frameon=False, fontsize=8, loc='upper left')
    ax.set_title('GDF15', fontsize=12, fontweight='bold')
    ax.set_xlabel('UMAP 1')
    ax.set_ylabel('UMAP 2')
    ax.grid(False)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.text(-0.1, 1.03, 'J', transform=ax.transAxes, fontsize=23, fontweight='normal', va='top', ha='left')
    output_pdf = combo / 'F.J.GDF15\u5728\u5404\u4e2a\u7ec6\u80de\u4e2d\u7684\u8868\u8fbe\u5730\u56fe.pdf'
    output_png = task_dir / 'F.J.GDF15\u5728\u5404\u4e2a\u7ec6\u80de\u4e2d\u7684\u8868\u8fbe\u5730\u56fe.png'
    fig.savefig(output_pdf, bbox_inches='tight', metadata={'Title': 'GDF15 local expression map', 'Subject': '40-NN adaptive Gaussian-distance-weighted linear smoothing in Scissor+ cells'})
    fig.savefig(output_png, dpi=250, bbox_inches='tight')
    plt.close(fig)
    output_columns = ['cell_barcode', 'UMAP_1', 'UMAP_2', 'cluster_raw', 'fb_id', 'subtype_display', 'Scissor_state', 'GDF15_log_normalized', 'GDF15_knn_linear_smoothed', 'has_detected_GDF15_neighbour']
    highlighted[output_columns].to_csv(task_dir / 'F.J.GDF15\u5730\u56fe_\u9ad8\u4eae\u7ec6\u80de\u4e0e\u7ebf\u6027\u5e73\u6ed1\u5206\u6570.csv.gz', index=False, compression='gzip', encoding='utf-8-sig')
    pd.DataFrame([density_qa]).to_csv(task_dir / 'GDF15\u4e0eScissor\u9633\u6027_\u5cf0\u503c\u5bc6\u5ea6120\u767e\u5206\u6bd4\u6838\u9a8c.csv', index=False, encoding='utf-8-sig')
    audit = {'gene': 'GDF15', 'population': 'all 15,371 current-combination fibroblasts as background', 'highlight_scope': 'Scissor+ cells only', 'linear_smoothing': {'method': 'adaptive Gaussian-distance-weighted k-nearest-neighbour linear mean in UMAP space', 'equation': 'smoothed_expression = W @ raw_log_normalized_expression', 'k': int(args.neighbours), 'weights_nonnegative': True, 'weights_row_normalized': True, 'maximum_row_sum_error': row_sum_error, 'display_only': True, 'coordinates_modified': False, 'expression_values_modified': False, 'Scissor_labels_modified': False}, 'counts': {'all_fibroblasts': int(len(data)), 'Scissor_positive': int(len(plus)), 'raw_GDF15_positive_within_Scissor_positive': int((plus['GDF15_log_normalized'] > 0).sum()), 'highlighted_local_support_cells': int(len(highlighted))}, 'density_QA': density_qa, 'output_pdf': str(output_pdf)}
    with (task_dir / 'F.J.GDF15\u5730\u56fe_\u7ebf\u6027\u5e73\u6ed1\u4e0e\u5bc6\u5ea6\u5ba1\u8ba1.json').open('w', encoding='utf-8') as handle:
        json.dump(audit, handle, ensure_ascii=False, indent=2)
    print(json.dumps(audit, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
