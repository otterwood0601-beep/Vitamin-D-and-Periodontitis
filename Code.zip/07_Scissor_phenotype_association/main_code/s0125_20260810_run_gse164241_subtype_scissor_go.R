options(stringsAsFactors = FALSE)
options(Seurat.object.assay.version = "v3")

args <- commandArgs(trailingOnly = TRUE)
if (length(args) > 1L) {
  stop("Usage: Rscript 20260810_run_gse164241_subtype_scissor_go.R [output_directory]")
}

output_dir <- if (length(args) == 1L) {
  normalizePath(args[[1]], winslash = "/", mustWork = FALSE)
} else {
  normalizePath(
    "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260810-GSE164241-ECM\u4e0eMatrix\u4e9a\u7fa4-Scissor\u5206\u5c42GO",
    winslash = "/",
    mustWork = FALSE
  )
}

dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
table_dir <- file.path(output_dir, "01_tables")
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

.libPaths(c(
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_Seurat4",
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library",
  "C:/Users/Lin/AppData/Local/R/win-library/4.5",
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_stage11",
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_enrichment",
  .libPaths()
))

suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
  library(data.table)
  library(clusterProfiler)
  library(jsonlite)
})

set.seed(20260730L)

source_batch <- normalizePath(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260730-\u4e09\u7ec4\u6210\u7ea4\u7ef4\u7ec6\u80de-Scissor\u53c2\u6570\u654f\u611f\u6027-\u6570\u91cf\u4e0e\u4e9a\u7fa4\u96c6\u4e2d\u5ea6\u4f18\u5316",
  winslash = "/",
  mustWork = TRUE
)
healthy_dir <- file.path(
  source_batch,
  "01_GSE164241",
  "GSE164241-\u5065\u5eb7\u7259\u9f88"
)
object_path <- file.path(
  healthy_dir,
  "02_official_Scissor",
  "02_official_Scissor_labeled_fibroblasts.rds"
)
original_de_script <- file.path(source_batch, "scripts", "06_run_scissor_downstream.R")
original_plot_script <- file.path(source_batch, "scripts", "10_redesign_GSE164241_healthy.py")
original_figure <- file.path(
  healthy_dir,
  "04_Figure4A-J",
  "GSE164241\u5065\u5eb7\u7ec4\u5b9a\u5236\u7248_\u65e0FB\u7f16\u53f7_GDF15\u5355\u57fa\u56e0",
  "individual_panels",
  "Figure4G_wide_GO_enrichment.pdf"
)

gene_set_dir <- normalizePath(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/05_\u5355\u7ec6\u80deRNA/gene_sets",
  winslash = "/",
  mustWork = TRUE
)
gmt_paths <- c(
  "GO-BP" = file.path(gene_set_dir, "GO_Biological_Process_2025.gmt"),
  "GO-CC" = file.path(gene_set_dir, "GO_Cellular_Component_2025.gmt"),
  "GO-MF" = file.path(gene_set_dir, "GO_Molecular_Function_2025.gmt")
)

required_files <- c(
  object_path,
  original_de_script,
  original_plot_script,
  original_figure,
  gmt_paths
)
if (!all(file.exists(required_files))) {
  stop(
    "Missing required source file(s): ",
    paste(required_files[!file.exists(required_files)], collapse = "; ")
  )
}

safe_write_csv <- function(value, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  fwrite(value, path, bom = FALSE, compress = "auto")
}

read_gmt_term2gene <- function(path) {
  fields <- strsplit(
    readLines(path, warn = FALSE, encoding = "UTF-8"),
    "\t",
    fixed = TRUE
  )
  rbindlist(lapply(fields, function(item) {
    if (length(item) < 3L) return(NULL)
    data.table(term = item[[1]], gene = unique(item[-c(1, 2)]))
  }))
}

empty_enrichment <- function() {
  data.table(
    ID = character(),
    Description = character(),
    GeneRatio = character(),
    BgRatio = character(),
    RichFactor = numeric(),
    FoldEnrichment = numeric(),
    zScore = numeric(),
    pvalue = numeric(),
    p.adjust = numeric(),
    qvalue = numeric(),
    geneID = character(),
    Count = integer(),
    ontology = character(),
    direction = character(),
    subtype = character(),
    DEG_count = integer(),
    universe_count = integer(),
    GeneRatio_numeric = numeric(),
    FDR_significant = logical()
  )
}

run_enricher <- function(genes, universe, term2gene, ontology, direction, subtype) {
  if (length(genes) < 2L) return(empty_enrichment())
  result <- suppressMessages(clusterProfiler::enricher(
    gene = genes,
    universe = universe,
    TERM2GENE = as.data.frame(term2gene),
    pvalueCutoff = 1,
    pAdjustMethod = "BH",
    qvalueCutoff = 1,
    minGSSize = 10,
    maxGSSize = 500
  ))
  if (is.null(result)) return(empty_enrichment())
  table <- as.data.table(as.data.frame(result))
  if (!nrow(table)) return(empty_enrichment())
  table[, `:=`(
    ontology = ontology,
    direction = direction,
    subtype = subtype,
    DEG_count = length(genes),
    universe_count = length(universe)
  )]
  ratio <- tstrsplit(table$GeneRatio, "/", fixed = TRUE)
  table[, GeneRatio_numeric := as.numeric(ratio[[1]]) / as.numeric(ratio[[2]])]
  table[, FDR_significant := p.adjust < 0.05]
  table[]
}

object <- readRDS(object_path)
DefaultAssay(object) <- "RNA"
metadata <- object[[]]
required_metadata <- c("fibroblast_subtype", "Scissor_state")
if (!all(required_metadata %in% colnames(metadata))) {
  stop("The Scissor-labeled Seurat object lacks required metadata columns.")
}
object$clean_subtype <- sub(
  "^FB[0-9]+:\\s*",
  "",
  as.character(object$fibroblast_subtype)
)

target_subtypes <- c("ECM remodeling", "Matrix homeostatic")
target_states <- c("Vitamin D3+", "Vitamin D3-")
reference_log2fc <- log2(1.2)

cell_summary <- as.data.table(object[[]], keep.rownames = "cell")[
  clean_subtype %in% target_subtypes & Scissor_state %in% c(target_states, "Background"),
  .N,
  by = .(subtype = clean_subtype, Scissor_state)
]
cell_summary[, subtype_order := match(subtype, target_subtypes)]
cell_summary[, state_order := match(Scissor_state, c(target_states, "Background"))]
setorder(cell_summary, subtype_order, state_order)
cell_summary[, c("subtype_order", "state_order") := NULL]
safe_write_csv(cell_summary, file.path(table_dir, "01_target_cell_counts.csv"))

de_tables <- list()
enrichment_tables <- list()
deg_summary <- list()

for (subtype_value in target_subtypes) {
  selected_cells <- colnames(object)[
    object$clean_subtype == subtype_value &
      object$Scissor_state %in% target_states
  ]
  sub_object <- subset(object, cells = selected_cells)
  plus_cells <- colnames(sub_object)[sub_object$Scissor_state == "Vitamin D3+"]
  minus_cells <- colnames(sub_object)[sub_object$Scissor_state == "Vitamin D3-"]
  if (length(plus_cells) < 10L || length(minus_cells) < 10L) {
    stop(
      subtype_value,
      " has too few cells for the original two-group analysis: + = ",
      length(plus_cells),
      ", - = ",
      length(minus_cells)
    )
  }

  Idents(sub_object) <- "Scissor_state"
  de <- FindMarkers(
    object = sub_object,
    ident.1 = "Vitamin D3+",
    ident.2 = "Vitamin D3-",
    assay = "RNA",
    slot = "data",
    test.use = "wilcox",
    logfc.threshold = 0,
    min.pct = 0,
    min.cells.feature = 1,
    min.cells.group = 1,
    verbose = FALSE
  )
  de <- as.data.table(de, keep.rownames = "gene")
  if ("avg_logFC" %in% names(de) && !"avg_log2FC" %in% names(de)) {
    setnames(de, "avg_logFC", "avg_log2FC")
  }
  if (!"p_val_adj" %in% names(de)) {
    de[, p_val_adj := p.adjust(p_val, method = "BH")]
  }

  rna_data <- GetAssayData(sub_object, assay = "RNA", slot = "data")
  de[, avg_log2FC_reported_by_FindMarkers := avg_log2FC]
  de_genes <- as.character(de$gene)
  plus_linear_mean <- as.numeric(Matrix::rowMeans(expm1(
    rna_data[de_genes, plus_cells, drop = FALSE]
  )))
  minus_linear_mean <- as.numeric(Matrix::rowMeans(expm1(
    rna_data[de_genes, minus_cells, drop = FALSE]
  )))
  de[, avg_log2FC := log2((plus_linear_mean + 1) / (minus_linear_mean + 1))]
  de[, pct.1 := as.numeric(Matrix::rowMeans(
    rna_data[de_genes, plus_cells, drop = FALSE] > 0
  ))]
  de[, pct.2 := as.numeric(Matrix::rowMeans(
    rna_data[de_genes, minus_cells, drop = FALSE] > 0
  ))]
  de[, `:=`(
    fold_change = 2^avg_log2FC,
    absolute_fold_change = 2^abs(avg_log2FC),
    subtype = subtype_value,
    Vitamin_D3_positive_cells = length(plus_cells),
    Vitamin_D3_negative_cells = length(minus_cells)
  )]
  de[, meets_reference_threshold := (
    p_val < 0.05 & abs(avg_log2FC) >= reference_log2fc
  )]
  de[, direction := fifelse(
    meets_reference_threshold & avg_log2FC > 0,
    "Higher in Vitamin D3+",
    fifelse(
      meets_reference_threshold & avg_log2FC < 0,
      "Higher in Vitamin D3-",
      "Not reference-threshold DEG"
    )
  )]
  de[, absolute_log2FC_for_order := abs(avg_log2FC)]
  setorder(de, p_val, -absolute_log2FC_for_order)
  de_tables[[subtype_value]] <- de

  slug <- gsub("[^A-Za-z0-9]+", "_", subtype_value)
  safe_write_csv(
    de,
    file.path(table_dir, paste0("02_DE_", slug, "_VitaminD3_positive_vs_negative.csv.gz"))
  )

  universe <- unique(de$gene)
  directional_genes <- list(
    "Higher in Vitamin D3+" = de[
      meets_reference_threshold & avg_log2FC > 0,
      unique(gene)
    ],
    "Higher in Vitamin D3-" = de[
      meets_reference_threshold & avg_log2FC < 0,
      unique(gene)
    ]
  )

  for (direction_value in names(directional_genes)) {
    genes <- directional_genes[[direction_value]]
    direction_slug <- if (direction_value == "Higher in Vitamin D3+") {
      "Scissor_positive"
    } else {
      "Scissor_negative"
    }
    safe_write_csv(
      data.table(gene = genes),
      file.path(table_dir, paste0("03_DEG_genes_", slug, "_", direction_slug, ".csv"))
    )
    deg_summary[[paste(subtype_value, direction_value)]] <- data.table(
      subtype = subtype_value,
      direction = direction_value,
      Scissor_state = ifelse(
        direction_value == "Higher in Vitamin D3+",
        "Vitamin D3+",
        "Vitamin D3-"
      ),
      cells_in_state = ifelse(
        direction_value == "Higher in Vitamin D3+",
        length(plus_cells),
        length(minus_cells)
      ),
      comparison_cells = ifelse(
        direction_value == "Higher in Vitamin D3+",
        length(minus_cells),
        length(plus_cells)
      ),
      tested_genes = length(universe),
      DEG_count_raw_P_lt_0_05_abs_FC_ge_1_2 = length(genes)
    )
    for (ontology_value in names(gmt_paths)) {
      term2gene <- read_gmt_term2gene(gmt_paths[[ontology_value]])
      enrichment_tables[[paste(subtype_value, direction_value, ontology_value)]] <- run_enricher(
        genes = genes,
        universe = universe,
        term2gene = term2gene,
        ontology = ontology_value,
        direction = direction_value,
        subtype = subtype_value
      )
    }
  }
  rm(sub_object, rna_data)
  invisible(gc())
}

all_de <- rbindlist(de_tables, fill = TRUE)
safe_write_csv(all_de, file.path(table_dir, "04_all_subtype_DE_results.csv.gz"))

all_enrichment <- rbindlist(enrichment_tables, fill = TRUE)
if (!nrow(all_enrichment)) all_enrichment <- empty_enrichment()
if (nrow(all_enrichment)) {
  setorder(all_enrichment, subtype, direction, ontology, p.adjust, pvalue)
}
safe_write_csv(
  all_enrichment,
  file.path(table_dir, "05_all_GO_enrichment_results.csv.gz")
)

group_grid <- CJ(
  subtype = target_subtypes,
  direction = c("Higher in Vitamin D3+", "Higher in Vitamin D3-"),
  ontology = names(gmt_paths),
  unique = TRUE
)
pathway_summary <- group_grid[, {
  part <- all_enrichment[
    subtype == .BY$subtype &
      direction == .BY$direction &
      ontology == .BY$ontology
  ]
  significant <- part[p.adjust < 0.05]
  eligible <- if (nrow(significant)) significant else part
  list(
    tested_enrichment_terms = nrow(part),
    nominal_P_lt_0_05 = sum(part$pvalue < 0.05, na.rm = TRUE),
    FDR_q_lt_0_05 = nrow(significant),
    display_rule = ifelse(
      nrow(significant),
      "Top 3 among FDR q < 0.05",
      "Top 3 overall because no FDR-significant term"
    ),
    displayed_terms = min(3L, nrow(eligible))
  )
}, by = .(subtype, direction, ontology)]
pathway_summary[, subtype_order := match(subtype, target_subtypes)]
pathway_summary[, direction_order := match(
  direction,
  c("Higher in Vitamin D3+", "Higher in Vitamin D3-")
)]
pathway_summary[, ontology_order := match(ontology, names(gmt_paths))]
setorder(pathway_summary, subtype_order, direction_order, ontology_order)
pathway_summary[, c("subtype_order", "direction_order", "ontology_order") := NULL]
safe_write_csv(
  pathway_summary,
  file.path(table_dir, "06_pathway_count_summary.csv")
)

display_parts <- list()
for (subtype_value in target_subtypes) {
  for (direction_value in c("Higher in Vitamin D3+", "Higher in Vitamin D3-")) {
    for (ontology_value in names(gmt_paths)) {
      part <- all_enrichment[
        subtype == subtype_value &
          direction == direction_value &
          ontology == ontology_value
      ]
      significant <- part[p.adjust < 0.05]
      eligible <- if (nrow(significant)) significant else part
      if (nrow(eligible)) {
        setorder(eligible, p.adjust, pvalue)
        selected <- head(eligible, 3L)
        selected[, display_rank := seq_len(.N)]
        selected[, selection_basis := ifelse(
          nrow(significant),
          "FDR-significant terms",
          "Top overall terms; no FDR-significant term"
        )]
        display_parts[[paste(subtype_value, direction_value, ontology_value)]] <- selected
      }
    }
  }
}
display_terms <- rbindlist(display_parts, fill = TRUE)
safe_write_csv(
  display_terms,
  file.path(table_dir, "07_GO_terms_displayed_in_four_figures.csv")
)

deg_summary_table <- rbindlist(deg_summary, fill = TRUE)
deg_summary_table[, subtype_order := match(subtype, target_subtypes)]
deg_summary_table[, direction_order := match(
  direction,
  c("Higher in Vitamin D3+", "Higher in Vitamin D3-")
)]
setorder(deg_summary_table, subtype_order, direction_order)
deg_summary_table[, c("subtype_order", "direction_order") := NULL]
safe_write_csv(
  deg_summary_table,
  file.path(table_dir, "08_cell_and_DEG_count_summary.csv")
)

audit <- list(
  status = "completed",
  created = format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z"),
  source_dataset = "GSE164241 healthy gingiva fibroblasts",
  source_scissor_object = object_path,
  source_original_figure = original_figure,
  source_original_DE_script = original_de_script,
  source_original_plot_script = original_plot_script,
  comparison = paste0(
    "Within each cleaned fibroblast subtype, Vitamin D3+ cells were compared ",
    "with Vitamin D3- cells; positive and negative directional DEG lists ",
    "generated the four requested GO analyses. FB numeric clusters sharing ",
    "the same biological subtype label were pooled."
  ),
  pooled_original_clusters = list(
    `ECM remodeling` = sort(unique(as.character(object$fibroblast_subtype[
      object$clean_subtype == "ECM remodeling"
    ]))),
    `Matrix homeostatic` = sort(unique(as.character(object$fibroblast_subtype[
      object$clean_subtype == "Matrix homeostatic"
    ])))
  ),
  DE_method = list(
    package = "Seurat",
    package_version = as.character(packageVersion("Seurat")),
    test = "FindMarkers Wilcoxon",
    assay = "RNA",
    slot = "data",
    logfc_threshold_during_test = 0,
    min_pct = 0,
    reporting_threshold = "raw P < 0.05 and absolute fold change >= 1.2",
    fold_change = "recomputed from named RNA log-normalized matrix as in original pipeline"
  ),
  GO_method = list(
    package = "clusterProfiler",
    package_version = as.character(packageVersion("clusterProfiler")),
    function_name = "enricher",
    local_gene_sets = as.list(gmt_paths),
    p_adjust_method = "BH",
    min_gene_set_size = 10,
    max_gene_set_size = 500,
    universe = "genes tested by FindMarkers within each subtype",
    display = "up to 3 terms per ontology; FDR-significant terms preferred exactly as original Figure 4G"
  ),
  colors = list(
    `Vitamin D3-` = "#2B6CB0",
    `Vitamin D3+` = "#EF8178"
  ),
  original_files_preserved = TRUE,
  R = R.version.string
)
write_json(
  audit,
  file.path(output_dir, "09_method_and_source_audit.json"),
  pretty = TRUE,
  auto_unbox = TRUE,
  digits = NA
)

capture.output(sessionInfo(), file = file.path(output_dir, "10_R_sessionInfo.txt"))
cat("Completed subtype-stratified Scissor GO analysis in: ", output_dir, "\n", sep = "")
