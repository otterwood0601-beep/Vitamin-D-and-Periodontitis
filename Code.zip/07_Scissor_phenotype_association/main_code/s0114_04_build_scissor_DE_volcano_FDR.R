options(stringsAsFactors = FALSE)

if (.Platform$OS.type == "windows") {
  try(Sys.setlocale("LC_CTYPE", "Chinese (Simplified)_China.utf8"), silent = TRUE)
}

suppressPackageStartupMessages({
  library(Matrix)
  library(ggplot2)
  library(jsonlite)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1L) {
  stop("Usage: Rscript 04_build_scissor_DE_volcano_FDR.R <combination_dir>")
}

combo_dir <- normalizePath(args[[1]], winslash = "/", mustWork = TRUE)
task_dir <- file.path(
  combo_dir,
  "00_\u6e90\u6570\u636e\u4e0e\u5ba1\u8ba1",
  "Scissor_GDF15\u914d\u5957_\u590d\u7528\u65e2\u6709\u4ee3\u7801"
)
dir.create(task_dir, recursive = TRUE, showWarnings = FALSE)

input_rds <- file.path(task_dir, "official_Scissor_labeled_3000cells.rds")
if (!file.exists(input_rds)) {
  stop("Missing current-project Scissor-labelled Seurat snapshot: ", input_rds)
}

output_pdf <- file.path(
  combo_dir,
  "F.\u5dee\u5f02\u57fa\u56e0\u5728scissors\u9634\u6027\u548c\u9633\u6027\u7ec6\u80de\u4e2d\u7684\u4e0a\u8c03\u548c\u4e0b\u8c03.pdf"
)
output_png <- file.path(
  task_dir,
  "F.\u5dee\u5f02\u57fa\u56e0\u5728scissors\u9634\u6027\u548c\u9633\u6027\u7ec6\u80de\u4e2d\u7684\u4e0a\u8c03\u548c\u4e0b\u8c03.png"
)
output_csv <- file.path(
  task_dir,
  "F.Scissor\u9633\u6027\u4e0e\u9634\u6027\u5dee\u5f02\u8868\u8fbe_\u9010\u57fa\u56e0\u6e90\u6570\u636e.csv.gz"
)
summary_csv <- file.path(
  task_dir,
  "F.Scissor\u9633\u6027\u4e0e\u9634\u6027\u5dee\u5f02\u8868\u8fbe_\u7b5b\u9009\u8ba1\u6570.csv"
)
audit_json <- file.path(
  task_dir,
  "F.Scissor\u9633\u6027\u4e0e\u9634\u6027\u5dee\u5f02\u8868\u8fbe_\u5206\u6790\u5ba1\u8ba1.json"
)

object <- readRDS(input_rds)
meta <- attr(object, "meta.data")
assays <- attr(object, "assays")
rna <- assays[["RNA"]]
log_data <- attr(rna, "data")

if (!inherits(log_data, "dgCMatrix")) {
  log_data <- as(log_data, "dgCMatrix")
}
if (ncol(log_data) != nrow(meta)) {
  stop("Expression columns and metadata rows differ")
}
if (!is.null(rownames(meta)) && !identical(colnames(log_data), rownames(meta))) {
  idx <- match(colnames(log_data), rownames(meta))
  if (anyNA(idx)) stop("Cannot align expression columns to metadata rows")
  meta <- meta[idx, , drop = FALSE]
}
if (!"Scissor_state" %in% colnames(meta)) {
  stop("Scissor_state is absent from the current-project snapshot")
}

plus_idx <- which(meta$Scissor_state == "Vitamin D3+")
minus_idx <- which(meta$Scissor_state == "Vitamin D3-")
if (length(plus_idx) != 1293L || length(minus_idx) != 1658L) {
  stop(
    "Current Scissor counts changed: plus=", length(plus_idx),
    ", minus=", length(minus_idx)
  )
}

pct_plus <- Matrix::rowMeans(log_data[, plus_idx, drop = FALSE] > 0)
pct_minus <- Matrix::rowMeans(log_data[, minus_idx, drop = FALSE] > 0)
mean_plus <- Matrix::rowMeans(expm1(log_data[, plus_idx, drop = FALSE]))
mean_minus <- Matrix::rowMeans(expm1(log_data[, minus_idx, drop = FALSE]))
avg_log2FC <- log2((mean_plus + 1) / (mean_minus + 1))

eligible <- pmax(pct_plus, pct_minus) >= 0.01 & abs(avg_log2FC) >= 0.1
tested_idx <- which(eligible)
if (!length(tested_idx)) stop("No genes passed the historical prefilter")

message("Running Wilcoxon tests for ", length(tested_idx), " genes...")
p_values <- vapply(
  tested_idx,
  function(i) {
    x <- as.numeric(log_data[i, plus_idx])
    y <- as.numeric(log_data[i, minus_idx])
    tryCatch(
      stats::wilcox.test(
        x,
        y,
        alternative = "two.sided",
        exact = FALSE,
        correct = FALSE
      )$p.value,
      error = function(e) NA_real_
    )
  },
  numeric(1)
)

de <- data.frame(
  gene = rownames(log_data)[tested_idx],
  avg_log2FC = avg_log2FC[tested_idx],
  fold_change = 2^avg_log2FC[tested_idx],
  absolute_fold_change = 2^abs(avg_log2FC[tested_idx]),
  pct_scissor_plus = pct_plus[tested_idx],
  pct_scissor_minus = pct_minus[tested_idx],
  p_value = p_values,
  stringsAsFactors = FALSE
)
de$FDR <- stats::p.adjust(de$p_value, method = "BH")

log2fc_cutoff <- 0.5
absolute_fc_cutoff <- 2^log2fc_cutoff
fdr_cutoff <- 0.05
de$meets_final_threshold <- (
  !is.na(de$FDR) &
    de$FDR < fdr_cutoff &
    abs(de$avg_log2FC) >= log2fc_cutoff
)
de$direction <- "Not significant"
de$direction[de$meets_final_threshold & de$avg_log2FC > 0] <- "Higher in Scissor+"
de$direction[de$meets_final_threshold & de$avg_log2FC < 0] <- "Higher in Scissor-"
de$minus_log10_FDR <- -log10(pmax(de$FDR, 1e-300))
display_cap <- 130
de$minus_log10_FDR_display <- pmin(de$minus_log10_FDR, display_cap)
de$FDR_display_capped <- de$minus_log10_FDR > display_cap
de <- de[order(de$p_value, -abs(de$avg_log2FC)), , drop = FALSE]

con <- gzfile(output_csv, open = "wt", encoding = "UTF-8")
utils::write.csv(de, con, row.names = FALSE, fileEncoding = "UTF-8")
close(con)

counts <- table(factor(
  de$direction,
  levels = c("Higher in Scissor-", "Not significant", "Higher in Scissor+")
))
summary_table <- data.frame(
  metric = c(
    "Scissor+ cells",
    "Scissor- cells",
    "genes in RNA assay",
    "genes tested after historical prefilter",
    "higher in Scissor-",
    "not significant",
    "higher in Scissor+",
    "absolute FC cutoff",
    "absolute log2FC cutoff",
    "BH FDR cutoff"
  ),
  value = c(
    length(plus_idx),
    length(minus_idx),
    nrow(log_data),
    nrow(de),
    unname(counts[["Higher in Scissor-"]]),
    unname(counts[["Not significant"]]),
    unname(counts[["Higher in Scissor+"]]),
    absolute_fc_cutoff,
    log2fc_cutoff,
    fdr_cutoff
  ),
  stringsAsFactors = FALSE
)
utils::write.csv(summary_table, summary_csv, row.names = FALSE, fileEncoding = "UTF-8")

plot_levels <- c("Not significant", "Higher in Scissor-", "Higher in Scissor+")
de$direction <- factor(de$direction, levels = plot_levels)
de <- de[order(de$direction), , drop = FALSE]

palette <- c(
  "Not significant" = "#D9D9D9",
  "Higher in Scissor-" = "#3478B9",
  "Higher in Scissor+" = "#EF7D75"
)

p <- ggplot(
  de,
  aes(x = avg_log2FC, y = minus_log10_FDR_display, colour = direction)
) +
  geom_point(
    data = de[!de$FDR_display_capped, , drop = FALSE],
    size = 0.82,
    alpha = 0.78,
    stroke = 0,
    na.rm = TRUE
  ) +
  geom_point(
    data = de[de$FDR_display_capped, , drop = FALSE],
    shape = 16,
    size = 0.82,
    alpha = 0.78,
    stroke = 0,
    na.rm = TRUE
  ) +
  geom_hline(
    yintercept = -log10(fdr_cutoff),
    linetype = "dashed",
    linewidth = 0.45,
    colour = "#666666"
  ) +
  geom_vline(
    xintercept = c(-log2fc_cutoff, log2fc_cutoff),
    linetype = "dashed",
    linewidth = 0.45,
    colour = "#666666"
  ) +
  scale_colour_manual(values = palette, guide = "none", drop = FALSE) +
  scale_y_continuous(
    breaks = c(0, 25, 50, 75, 100, 125),
    limits = c(0, display_cap),
    expand = expansion(mult = c(0.015, 0.025))
  ) +
  labs(
    x = expression(log[2]~fold~change~("Scissor+"/"Scissor-")),
    y = expression(-log[10]~FDR~("capped at 130")),
    tag = "F"
  ) +
  theme_classic(base_size = 12) +
  theme(
    axis.title = element_text(size = 13, colour = "#111111"),
    axis.text = element_text(size = 10.5, colour = "#111111"),
    axis.line = element_line(linewidth = 0.65, colour = "#111111"),
    axis.ticks = element_line(linewidth = 0.55, colour = "#111111"),
    plot.tag = element_text(size = 25, face = "plain", colour = "#111111"),
    plot.tag.position = c(0.006, 0.992),
    plot.margin = margin(16, 16, 12, 18)
  )

ggsave(
  output_pdf,
  plot = p,
  device = grDevices::cairo_pdf,
  width = 7.6,
  height = 5.8,
  units = "in"
)
ggsave(
  output_png,
  plot = p,
  width = 7.6,
  height = 5.8,
  units = "in",
  dpi = 450,
  bg = "white"
)

audit <- list(
  input = normalizePath(input_rds, winslash = "/", mustWork = TRUE),
  output_pdf = normalizePath(output_pdf, winslash = "/", mustWork = TRUE),
  comparison = "Scissor+ / Scissor-",
  Scissor_plus_cells = length(plus_idx),
  Scissor_minus_cells = length(minus_idx),
  test = "two-sided Wilcoxon rank-sum, exact=FALSE, continuity correction=FALSE",
  historical_prefilter = list(min_pct = 0.01, absolute_log2FC = 0.1),
  final_threshold = list(
    absolute_fold_change = unname(absolute_fc_cutoff),
    absolute_log2FC = unname(log2fc_cutoff),
    BH_FDR = fdr_cutoff
  ),
  genes_tested = nrow(de),
  significant_higher_in_Scissor_minus = unname(counts[["Higher in Scissor-"]]),
  significant_higher_in_Scissor_plus = unname(counts[["Higher in Scissor+"]]),
  gene_text_annotations = 0L,
  p_value_axis = "-log10(BH FDR)",
  display_cap_minus_log10_FDR = display_cap,
  display_cap_mark = "circular point at cap; source FDR is unchanged",
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
)
writeLines(
  jsonlite::toJSON(audit, auto_unbox = TRUE, pretty = TRUE, digits = 12),
  audit_json,
  useBytes = TRUE
)

writeLines(capture.output(sessionInfo()), file.path(task_dir, "F\u56fe_R_sessionInfo.txt"))

message("Created: ", output_pdf)
message("Higher in Scissor-: ", counts[["Higher in Scissor-"]])
message("Higher in Scissor+: ", counts[["Higher in Scissor+"]])
