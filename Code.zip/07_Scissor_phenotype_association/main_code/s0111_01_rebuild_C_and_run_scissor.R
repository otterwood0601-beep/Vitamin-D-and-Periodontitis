options(stringsAsFactors = FALSE)
options(Seurat.object.assay.version = "v3")
options(future.globals.maxSize = 24 * 1024^3)

if (.Platform$OS.type == "windows") {
  try(Sys.setlocale("LC_CTYPE", "Chinese (Simplified)_China.utf8"), silent = TRUE)
}

.libPaths(c(
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_enrichment",
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_Seurat4",
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_stage11",
  .libPaths()
))

suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
  library(data.table)
  library(ggplot2)
  library(jsonlite)
  library(Scissor)
})

set.seed(20260730L)

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1L) stop("Usage: Rscript 01_rebuild_C_and_run_scissor.R <combination_dir>")

combo_dir <- normalizePath(args[[1]], winslash = "/", mustWork = TRUE)
source_dir <- file.path(combo_dir, "00_\u6e90\u6570\u636e\u4e0e\u5ba1\u8ba1")
task_dir <- file.path(source_dir, "Scissor_GDF15\u914d\u5957_\u590d\u7528\u65e2\u6709\u4ee3\u7801")
dir.create(task_dir, recursive = TRUE, showWarnings = FALSE)

input_relative <- file.path(
  ".\u9690\u85cf_\u5206\u6790\u8fc7\u7a0b/04_\u5065\u5eb7\u52a0\u7259\u9f88\u708e\u52a0\u7259\u5468\u708e/01_\u4e00\u7ea7\u6f0f\u6597_\u5171\u4eab\u6570\u636e",
  "all_conditions_allStudies_CELLxGENE_direct_fibroblast_counts_only.rds"
)
root_candidates <- character()
cursor <- combo_dir
for (i in 0:6) {
  root_candidates <- c(root_candidates, cursor)
  cursor <- dirname(cursor)
}
input_candidates <- file.path(root_candidates, input_relative)
input_rds <- input_candidates[file.exists(input_candidates)][1]
if (is.na(input_rds)) {
  stop("Could not locate the current-project fibroblast RDS while walking upward from: ", combo_dir)
}
project_root <- dirname(dirname(dirname(dirname(input_rds))))
bulk_dir <- paste0(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/",
  "20260723-\u9636\u6bb511\uff08\u7ef4\u751f\u7d20D-\u7259\u9f88-\u9f8b\u75c5_\u4e25\u683c\u7259\u9f88\u9650\u5b9a\u590d\u523b\uff09/02_GSE212728_bulk"
)

a_source_path <- file.path(source_dir, "A.10\u79cd\u7ec6\u80de\u5206\u7c7b\u5730\u56fe_\u6e90\u6570\u636e.csv.gz")
c_source_path <- file.path(source_dir, "C.10\u79cd\u7ec6\u80de\u7684\u5bf9\u89d2\u7ebfGO\u56fe_\u6e90\u6570\u636e.csv")
mapping_path <- file.path(source_dir, "\u4e9a\u7fa4\u7edf\u4e00\u529f\u80fd\u547d\u540d_GO_BP\u4e3b\u4f9d\u636e.csv")

required_paths <- c(input_rds, a_source_path, c_source_path, mapping_path)
if (!all(file.exists(required_paths))) {
  stop("Missing required input(s): ", paste(required_paths[!file.exists(required_paths)], collapse = "; "))
}

write_csv <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  fwrite(as.data.table(x), path, bom = TRUE)
  invisible(path)
}

c_data <- fread(c_source_path)
mapping <- fread(mapping_path)
mapping[, cluster := as.character(cluster)]
mapping <- mapping[order(as.integer(cluster))]

if (nrow(c_data) != 50L || any(c_data$cluster != c_data$source_cluster)) {
  stop("C source must contain exactly 50 strictly diagonal rows")
}
if (any(table(c_data$source_cluster) != 5L)) {
  stop("Every C-panel subcluster must contain exactly five GO pathways")
}

c_data[, cluster := as.character(cluster)]
c_data[, source_cluster := as.character(source_cluster)]
c_data <- c_data[order(as.integer(source_cluster), within_cluster_rank)]
term_levels <- c_data$term_key
term_labels <- setNames(c_data$Description, c_data$term_key)
cluster_levels <- mapping$cluster

wrap_name <- function(value, width = 18L) {
  paste(strwrap(value, width = width), collapse = "\n")
}
cluster_labels <- setNames(
  vapply(mapping$display_label, wrap_name, character(1)),
  mapping$cluster
)

max_count <- max(c_data$Count, na.rm = TRUE)
count_breaks <- pretty(c(0, max_count), n = 4)
count_breaks <- count_breaks[count_breaks > 0 & count_breaks <= max_count]
if (length(count_breaks) < 2L) count_breaks <- sort(unique(c(1, max_count)))

p_c <- ggplot(
  c_data,
  aes(
    x = factor(cluster, levels = cluster_levels),
    y = factor(term_key, levels = term_levels)
  )
) +
  geom_point(
    aes(size = Count, fill = log10pvalue),
    shape = 21, colour = "#2A2A2A", stroke = 0.35
  ) +
  scale_x_discrete(labels = cluster_labels, drop = FALSE) +
  scale_y_discrete(labels = term_labels, drop = FALSE) +
  scale_size_continuous(range = c(1.2, 7.0), breaks = count_breaks, name = "Count") +
  scale_fill_gradientn(
    colours = c("#FFF200", "#F0A6B8", "#9C27E8"),
    name = "log10pvalue"
  ) +
  labs(x = "Fibroblast subclusters", y = NULL) +
  theme_bw(base_size = 11) +
  theme(
    plot.title = element_blank(),
    plot.subtitle = element_blank(),
    panel.grid.major = element_line(colour = "#E5E5E5", linewidth = 0.35),
    panel.grid.minor = element_blank(),
    axis.title.x = element_text(face = "bold", size = 14, margin = margin(t = 10)),
    axis.text.x = element_text(size = 8.0, colour = "#111111", lineheight = 0.92),
    axis.text.y = element_text(size = 9.2, colour = "#111111", hjust = 1),
    axis.ticks = element_line(colour = "#333333", linewidth = 0.35),
    legend.title = element_text(face = "bold", size = 11),
    legend.text = element_text(size = 9.5),
    legend.key.height = grid::unit(0.55, "cm"),
    legend.position = "right",
    plot.margin = margin(8, 12, 8, 8)
  ) +
  guides(
    size = guide_legend(order = 1, override.aes = list(fill = "white")),
    fill = guide_colourbar(order = 2, barheight = grid::unit(4.0, "cm"))
  )

ggsave(
  file.path(combo_dir, "C.10\u79cd\u7ec6\u80de\u7684\u5bf9\u89d2\u7ebfGO\u56fe.pdf"),
  p_c, device = cairo_pdf, width = 15.2, height = 17.5, units = "in",
  limitsize = FALSE
)
ggsave(
  file.path(task_dir, "C.10\u79cd\u7ec6\u80de\u7684\u5bf9\u89d2\u7ebfGO\u56fe_\u5e26\u7ec6\u80de\u540d\u79f0.png"),
  p_c, width = 15.2, height = 17.5, units = "in", dpi = 180,
  limitsize = FALSE, bg = "white"
)
write_csv(
  mapping[, .(cluster, fb_id, display_label)],
  file.path(task_dir, "C\u56fe_x\u8f74\u7ec6\u80de\u540d\u79f0\u6620\u5c04.csv")
)

message("Loading current all-condition CELLxGENE fibroblast object ...")
object <- readRDS(input_rds)
DefaultAssay(object) <- "RNA"
a_data <- fread(a_source_path)

if (!identical(colnames(object), a_data$cell_barcode)) {
  stop("Current object cell order does not exactly match the audited A-panel source")
}
if (ncol(object) != 15371L || uniqueN(a_data$cell_barcode) != 15371L) {
  stop("Expected 15,371 unique fibroblasts")
}

match_index <- match(colnames(object), a_data$cell_barcode)
object$cluster_raw <- factor(
  as.character(a_data$cluster_raw[match_index]),
  levels = mapping$cluster
)
object$fibroblast_subtype <- factor(
  as.character(a_data$subtype_display[match_index]),
  levels = mapping$display_label
)
object$current_UMAP_1 <- a_data$UMAP_1[match_index]
object$current_UMAP_2 <- a_data$UMAP_2[match_index]
object$sample_key_for_scissor <- paste(
  as.character(object$Study), as.character(object$sample_id), sep = "::"
)

message("Rebuilding normalized PCA input with the current workflow parameters ...")
object <- NormalizeData(
  object, normalization.method = "LogNormalize", scale.factor = 10000,
  verbose = FALSE
)
object <- FindVariableFeatures(
  object, selection.method = "vst", nfeatures = 2000, verbose = FALSE
)

cycling_genes <- intersect(c(
  "MKI67", "TOP2A", "UBE2C", "CENPF", "HMGB2", "TYMS", "STMN1",
  "PTTG1", "PCLAF", "PBK", "TK1", "CDKN3", "TUBA1B"
), rownames(object))
if (length(cycling_genes) < 3L) stop("Too few cycling genes for the inherited regression step")

ucell_scores <- UCell::ScoreSignatures_UCell(
  matrix = GetAssayData(object, assay = "RNA", slot = "counts"),
  features = list(Cycling = cycling_genes),
  maxRank = 1500, chunk.size = 400, ncores = 1,
  missing_genes = "skip", name = "_UCell"
)
object <- AddMetaData(object, metadata = as.data.frame(ucell_scores))
if (!"Cycling_UCell" %in% colnames(object[[]])) stop("Cycling_UCell score was not created")

object <- ScaleData(
  object, features = VariableFeatures(object),
  vars.to.regress = "Cycling_UCell", verbose = FALSE
)
set.seed(42L)
object <- RunPCA(
  object, features = VariableFeatures(object), npcs = 10, verbose = FALSE
)

all_cells <- colnames(object)
strata <- interaction(
  object$sample_key_for_scissor,
  object$fibroblast_subtype,
  drop = TRUE
)
split_cells <- split(all_cells, strata)
target_n <- min(3000L, length(all_cells))
set.seed(20260730L)
selected_cells <- unique(unlist(lapply(split_cells, function(cells) {
  quota <- max(1L, floor(target_n / length(split_cells)))
  sample(cells, min(length(cells), quota))
}), use.names = FALSE))
if (length(selected_cells) < target_n) {
  remaining <- setdiff(all_cells, selected_cells)
  selected_cells <- c(
    selected_cells,
    sample(remaining, min(length(remaining), target_n - length(selected_cells)))
  )
}
selected_cells <- selected_cells[seq_len(min(target_n, length(selected_cells)))]
if (length(selected_cells) != 3000L || anyDuplicated(selected_cells)) {
  stop("The inherited stratified Scissor sample is not exactly 3,000 unique cells")
}

scissor_object <- subset(object, cells = selected_cells)
DefaultAssay(scissor_object) <- "RNA"
scissor_object <- FindNeighbors(
  scissor_object, reduction = "pca", dims = 1:10,
  graph.name = c("RNA_nn", "RNA_snn"), verbose = FALSE
)
if (!"RNA_snn" %in% names(scissor_object@graphs)) stop("RNA_snn graph is absent")

write_csv(
  data.table(
    cell_barcode = selected_cells,
    sample_key = as.character(object$sample_key_for_scissor[match(selected_cells, all_cells)]),
    subtype_display = as.character(object$fibroblast_subtype[match(selected_cells, all_cells)])
  ),
  file.path(task_dir, "Scissor_\u5206\u5c42\u62bd\u68373000\u7ec6\u80de.csv")
)

expression_table <- fread(file.path(bulk_dir, "05_GSE212728_log2_TPM_expression.csv.gz"))
gene_column <- intersect(c("gene", "gene_symbol", "Gene"), names(expression_table))[1]
if (is.na(gene_column)) stop("Could not identify the bulk gene column")
if (anyDuplicated(expression_table[[gene_column]])) {
  expression_table <- expression_table[
    , lapply(.SD, mean), by = c(gene_column),
    .SDcols = setdiff(names(expression_table), gene_column)
  ]
}
bulk_genes <- expression_table[[gene_column]]
bulk <- as.matrix(expression_table[, setdiff(names(expression_table), gene_column), with = FALSE])
rownames(bulk) <- bulk_genes
storage.mode(bulk) <- "double"

bulk_metadata <- fread(file.path(bulk_dir, "04_GSE212728_sample_metadata.csv"))
sample_column <- intersect(c("Sample", "sample"), names(bulk_metadata))[1]
group_column <- intersect(c("Group", "group"), names(bulk_metadata))[1]
bulk_metadata <- bulk_metadata[match(colnames(bulk), bulk_metadata[[sample_column]])]
phenotype <- ifelse(
  grepl("Vitamin D3|^D3$", bulk_metadata[[group_column]], ignore.case = TRUE),
  1, 0
)
names(phenotype) <- colnames(bulk)
if (!identical(sort(as.integer(table(phenotype))), c(2L, 3L))) {
  stop("Expected exactly 2 control and 3 vitamin-D3 bulk samples")
}

common_genes <- intersect(rownames(bulk), rownames(scissor_object))
if (length(common_genes) < 5000L) stop("Too few shared genes for Scissor: ", length(common_genes))

result_path <- file.path(task_dir, "official_Scissor_result_alpha0.01_cutoff1.rds")
labeled_path <- file.path(task_dir, "official_Scissor_labeled_3000cells.rds")
if (file.exists(result_path) && file.exists(labeled_path)) {
  message("Reusing completed current-dataset Scissor result ...")
  scissor_result <- readRDS(result_path)
  scissor_object <- readRDS(labeled_path)
} else {
  message("Running official Scissor 2.0 with inherited parameters ...")
  set.seed(20260730L)
  scissor_result <- Scissor(
    bulk_dataset = bulk,
    sc_dataset = scissor_object,
    phenotype = phenotype,
    tag = c("Control", "Vitamin D3"),
    alpha = 0.01,
    cutoff = 1,
    family = "binomial",
    Save_file = file.path(task_dir, "official_Scissor_input_snapshot.RData")
  )
  saveRDS(scissor_result, result_path, compress = FALSE)

  state <- rep("Background", ncol(scissor_object))
  names(state) <- colnames(scissor_object)
  state[scissor_result$Scissor_pos] <- "Vitamin D3+"
  state[scissor_result$Scissor_neg] <- "Vitamin D3-"
  scissor_object$Scissor_state <- factor(
    state[colnames(scissor_object)],
    levels = c("Vitamin D3-", "Vitamin D3+", "Background")
  )
  saveRDS(scissor_object, labeled_path, compress = FALSE)
}

if (!"Scissor_state" %in% colnames(scissor_object[[]])) {
  stop("Scissor labels are absent from the labeled object")
}

sampled_assignment <- data.table(
  cell_barcode = colnames(scissor_object),
  Scissor_state = as.character(scissor_object$Scissor_state)
)
sampled_assignment <- merge(
  sampled_assignment,
  a_data[, .(
    cell_barcode, UMAP_1, UMAP_2, cluster_raw,
    fb_id, subtype_display, functional_label, sample_id, donor_id, disease
  )],
  by = "cell_barcode", all.x = TRUE, sort = FALSE
)
if (anyNA(sampled_assignment$UMAP_1) || anyDuplicated(sampled_assignment$cell_barcode)) {
  stop("Scissor assignments failed to align with current UMAP coordinates")
}

full_assignment <- merge(
  a_data[, .(
    cell_barcode, UMAP_1, UMAP_2, cluster_raw,
    fb_id, subtype_display, functional_label, sample_id, donor_id, disease
  )],
  sampled_assignment[, .(cell_barcode, Scissor_state)],
  by = "cell_barcode", all.x = TRUE, sort = FALSE
)
full_assignment[is.na(Scissor_state), Scissor_state := "Background"]
full_assignment[, Scissor_state := factor(
  Scissor_state, levels = c("Background", "Vitamin D3-", "Vitamin D3+")
)]

state_counts <- full_assignment[, .N, by = Scissor_state]
state_counts[, percent_all_fibroblasts := 100 * N / sum(N)]
if (state_counts[Scissor_state == "Vitamin D3+", N] < 10L ||
    state_counts[Scissor_state == "Vitamin D3-", N] < 10L) {
  stop("At least 10 Scissor+ and 10 Scissor- cells are required")
}

write_csv(sampled_assignment, file.path(task_dir, "Scissor_3000\u7ec6\u80de\u9010\u7ec6\u80de\u6807\u8bb0.csv"))
write_csv(full_assignment, file.path(task_dir, "D.scissors\u9634\u6027\u9633\u6027\u5730\u56fe_\u516815371\u7ec6\u80de\u6e90\u6570\u636e.csv.gz"))
write_csv(state_counts, file.path(task_dir, "Scissor_\u5168\u7ec6\u80de\u72b6\u6001\u8ba1\u6570.csv"))

state_colours <- c(
  "Background" = "#BDBDBD",
  "Vitamin D3-" = "#3478B9",
  "Vitamin D3+" = "#EF7D75"
)
background <- full_assignment[Scissor_state == "Background"]
selected_plot <- full_assignment[Scissor_state != "Background"]

p_d <- ggplot() +
  geom_point(
    data = background,
    aes(x = UMAP_1, y = UMAP_2, colour = Scissor_state),
    size = 0.35, alpha = 0.68, shape = 16
  ) +
  geom_point(
    data = selected_plot,
    aes(x = UMAP_1, y = UMAP_2, colour = Scissor_state),
    size = 0.65, alpha = 0.96, shape = 16
  ) +
  scale_colour_manual(
    values = state_colours,
    breaks = c("Background", "Vitamin D3-", "Vitamin D3+"),
    drop = FALSE
  ) +
  coord_equal() +
  labs(x = "UMAP 1", y = "UMAP 2", colour = NULL) +
  theme_classic(base_size = 11) +
  theme(
    plot.title = element_blank(), plot.subtitle = element_blank(),
    legend.position = c(0.12, 0.90),
    legend.background = element_blank(),
    legend.key.height = grid::unit(0.36, "cm"),
    legend.text = element_text(size = 9)
  )

ggsave(
  file.path(combo_dir, "D.scissors\u9634\u6027\u9633\u6027\u5730\u56fe.pdf"),
  p_d, device = cairo_pdf, width = 8.2, height = 6.3, units = "in"
)
ggsave(
  file.path(task_dir, "D.scissors\u9634\u6027\u9633\u6027\u5730\u56fe.png"),
  p_d, width = 8.2, height = 6.3, units = "in", dpi = 220, bg = "white"
)

selected_only <- full_assignment[Scissor_state %in% c("Vitamin D3-", "Vitamin D3+")]
e_counts <- selected_only[, .N, by = .(cluster_raw, fb_id, subtype_display, Scissor_state)]
all_grid <- CJ(
  cluster_raw = as.integer(mapping$cluster),
  Scissor_state = c("Vitamin D3+", "Vitamin D3-")
)
all_grid <- merge(
  all_grid,
  mapping[, .(
    cluster_raw = as.integer(cluster), fb_id,
    subtype_display = display_label
  )],
  by = "cluster_raw", all.x = TRUE, sort = FALSE
)
e_counts[, cluster_raw := as.integer(cluster_raw)]
e_counts <- merge(
  all_grid,
  e_counts[, .(cluster_raw, Scissor_state = as.character(Scissor_state), N)],
  by = c("cluster_raw", "Scissor_state"), all.x = TRUE, sort = FALSE
)
e_counts[is.na(N), N := 0L]
e_counts[, selected_total := sum(N), by = cluster_raw]
e_counts[, percent_selected := fifelse(selected_total > 0, 100 * N / selected_total, 0)]
e_counts <- e_counts[
  order(cluster_raw, match(Scissor_state, c("Vitamin D3+", "Vitamin D3-")))
]
write_csv(e_counts, file.path(task_dir, "E.scissors\u9634\u6027\u9633\u6027\u6bd4\u4f8b_\u6e90\u6570\u636e.csv"))

e_counts[, subtype_factor := factor(
  subtype_display,
  levels = rev(mapping$display_label)
)]
e_counts[, Scissor_state := factor(
  Scissor_state, levels = c("Vitamin D3+", "Vitamin D3-")
)]
e_counts[, label_x := cumsum(percent_selected) - percent_selected / 2, by = cluster_raw]

p_e <- ggplot(
  e_counts,
  aes(x = percent_selected, y = subtype_factor, fill = Scissor_state)
) +
  geom_col(width = 0.72, colour = "white", linewidth = 0.35) +
  geom_text(
    data = e_counts[percent_selected >= 8],
    aes(x = label_x, label = sprintf("%.1f%%", percent_selected)),
    size = 3.0, colour = "#111111"
  ) +
  scale_fill_manual(
    values = state_colours[c("Vitamin D3+", "Vitamin D3-")],
    breaks = c("Vitamin D3+", "Vitamin D3-"), drop = FALSE
  ) +
  scale_x_continuous(
    limits = c(0, 100), breaks = seq(0, 100, 20),
    expand = expansion(mult = c(0, 0))
  ) +
  labs(
    x = "Percentage of Scissor-selected fibroblasts",
    y = "Fibroblast subtype", fill = NULL
  ) +
  theme_classic(base_size = 11) +
  theme(
    plot.title = element_blank(), plot.subtitle = element_blank(),
    axis.text.y = element_text(size = 8.5),
    axis.ticks.y = element_blank(),
    panel.grid.major.x = element_line(colour = "#E6E6E6", linewidth = 0.35),
    panel.grid.minor = element_blank(),
    legend.position = "top",
    legend.direction = "horizontal"
  )

ggsave(
  file.path(combo_dir, "E.scissors\u9634\u6027\u9633\u6027\u6bd4\u4f8b.pdf"),
  p_e, device = cairo_pdf, width = 12.6, height = 7.3, units = "in"
)
ggsave(
  file.path(task_dir, "E.scissors\u9634\u6027\u9633\u6027\u6bd4\u4f8b.png"),
  p_e, width = 12.6, height = 7.3, units = "in", dpi = 220, bg = "white"
)

rna_data <- GetAssayData(object, assay = "RNA", slot = "data")
if (!"GDF15" %in% rownames(rna_data)) stop("GDF15 is absent from RNA data")
gdf15_source <- copy(full_assignment)
gdf15_source[, GDF15_log_normalized := as.numeric(
  rna_data["GDF15", cell_barcode, drop = TRUE]
)]
write_csv(
  gdf15_source,
  file.path(task_dir, "F.J.GDF15\u5728\u5404\u4e2a\u7ec6\u80de\u4e2d\u7684\u8868\u8fbe\u5730\u56fe_\u9010\u7ec6\u80de\u6e90\u6570\u636e.csv.gz")
)

audit <- list(
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  current_combination = "PCA10; Harmony; Louvain resolution=0.60; 10 GO-function-named fibroblast subclusters",
  population = list(
    all_fibroblasts = nrow(full_assignment),
    studies = sort(unique(as.character(object$Study))),
    disease_states = sort(unique(as.character(object$disease)))
  ),
  reused_scissor_method = list(
    official_package = "sunduanchen/Scissor",
    package_version = as.character(packageVersion("Scissor")),
    bulk_dataset = "GSE212728",
    control_samples = sum(phenotype == 0),
    vitamin_D3_samples = sum(phenotype == 1),
    single_cell_sampling = "sample_key x current GO-function subtype stratified; maximum 3000 cells",
    sampled_cells = ncol(scissor_object),
    shared_genes = length(common_genes),
    alpha = 0.01,
    cutoff = 1,
    family = "binomial",
    inherited_parameter_status = "exploratory parameter inherited from the previous requested workflow; not independently confirmatory"
  ),
  state_counts_all_15371 = setNames(as.list(state_counts$N), as.character(state_counts$Scissor_state)),
  C_panel = "50 diagonal GO terms retained; x-axis now displays the current functional cell names",
  GDF15_display = "delegated to the paired Python script using the inherited 40-NN adaptive Gaussian-distance-weighted linear smoother"
)
writeLines(
  toJSON(audit, auto_unbox = TRUE, pretty = TRUE, null = "null"),
  file.path(task_dir, "Scissor_GDF15_\u5206\u6790\u5ba1\u8ba1.json"), useBytes = TRUE
)
writeLines(capture.output(sessionInfo()), file.path(task_dir, "R_sessionInfo.txt"), useBytes = TRUE)

message("Completed C, D and E; exported GDF15 source data")
print(state_counts)
