args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1L) stop("Usage: rebuild_go_top5.R <combination_directory>")

Sys.setlocale("LC_CTYPE", ".UTF-8")
options(stringsAsFactors = FALSE)

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(scales)
})

combo_dir <- normalizePath(args[[1]], winslash = "/", mustWork = TRUE)
source_dir <- file.path(combo_dir, "00_\u6e90\u6570\u636e\u4e0e\u5ba1\u8ba1")
go_all_path <- file.path(source_dir, "GO_BP_\u5168\u90e8\u5bcc\u96c6\u7ed3\u679c_\u8d85\u51e0\u4f55\u68c0\u9a8cBH\u6821\u6b63.csv.gz")
mapping_path <- file.path(source_dir, "\u4e9a\u7fa4\u7edf\u4e00\u529f\u80fd\u547d\u540d_GO_BP\u4e3b\u4f9d\u636e.csv")
target_pdf <- file.path(combo_dir, "C.10\u79cd\u7ec6\u80de\u7684\u5bf9\u89d2\u7ebfGO\u56fe.pdf")
selected_path <- file.path(source_dir, "GO_BP_\u5bf9\u89d2\u7ebf\u56fe\u5165\u9009\u6761\u76ee.csv")
plot_data_path <- file.path(source_dir, "C.10\u79cd\u7ec6\u80de\u7684\u5bf9\u89d2\u7ebfGO\u56fe_\u6e90\u6570\u636e.csv")

if (!file.exists(go_all_path)) stop("Missing GO table: ", go_all_path)
if (!file.exists(mapping_path)) stop("Missing mapping table: ", mapping_path)

go_all <- as.data.table(read.csv(gzfile(go_all_path), check.names = FALSE))
mapping <- as.data.table(read.csv(mapping_path, check.names = FALSE))

required_go <- c("cluster", "ID", "Description", "GeneRatio", "Count", "pvalue", "p.adjust")
if (!all(required_go %in% names(go_all))) {
  stop("GO table is missing columns: ", paste(setdiff(required_go, names(go_all)), collapse = ", "))
}
if (!all(c("cluster", "fb_id", "display_label") %in% names(mapping))) {
  stop("Mapping table lacks cluster/fb_id/display_label")
}

go_all[, cluster := as.character(cluster)]
mapping[, cluster := as.character(cluster)]
mapping <- mapping[order(as.integer(cluster))]
cluster_levels <- mapping$cluster

sig_occurrence <- go_all[!is.na(p.adjust) & p.adjust < 0.05,
                         .(n_clusters = uniqueN(cluster)), by = ID]
ranked <- merge(go_all, sig_occurrence, by = "ID", all.x = TRUE, sort = FALSE)
ranked[is.na(n_clusters), n_clusters := max(2L, uniqueN(cluster))]
ranked[, specificity_score := -log10(pmax(p.adjust, 1e-300)) - 0.35 * (n_clusters - 1)]

selected_list <- vector("list", length(cluster_levels))
for (i in seq_along(cluster_levels)) {
  cl <- cluster_levels[[i]]
  significant <- ranked[cluster == cl & !is.na(p.adjust) & p.adjust < 0.05]
  setorder(significant, -specificity_score, p.adjust, -Count, ID)
  chosen <- head(significant, 5L)
  if (nrow(chosen) < 5L) {
    fallback <- ranked[cluster == cl & !ID %in% chosen$ID]
    setorder(fallback, -specificity_score, p.adjust, -Count, ID, na.last = TRUE)
    chosen <- rbind(chosen, head(fallback, 5L - nrow(chosen)), fill = TRUE)
  }
  if (nrow(chosen) != 5L) stop("Could not select five GO terms for cluster ", cl)
  chosen[, `:=`(
    source_cluster = cl,
    within_cluster_rank = seq_len(.N),
    term_key = paste0("C", cl, "__", ID)
  )]
  selected_list[[i]] <- chosen
}
selected <- rbindlist(selected_list, fill = TRUE)
if (nrow(selected) != 5L * length(cluster_levels)) stop("Expected exactly 50 selected terms")
if (any(table(selected$source_cluster) != 5L)) stop("At least one cluster does not have exactly five terms")

selected_terms <- selected[, .(
  source_cluster, within_cluster_rank, term_key, ID, Description,
  selected_GeneRatio = GeneRatio, selected_Count = Count,
  selected_pvalue = pvalue, selected_p_adjust = p.adjust,
  n_clusters, specificity_score
)]
selected_terms <- selected_terms[order(as.integer(source_cluster), within_cluster_rank)]

grid <- CJ(term_key = selected_terms$term_key, cluster = cluster_levels, unique = TRUE)
grid <- merge(
  grid,
  selected_terms[, .(term_key, ID, Description, source_cluster, within_cluster_rank)],
  by = "term_key", all.x = TRUE, sort = FALSE
)
values <- go_all[, .(cluster, ID, Count, GeneRatio, pvalue, p.adjust)]
grid <- merge(grid, values, by = c("cluster", "ID"), all.x = TRUE, sort = FALSE)
grid[, `:=`(
  diagonal = cluster == source_cluster,
  log10pvalue = fifelse(is.na(pvalue), NA_real_, log10(pmax(pvalue, 1e-300))),
  log10padj = fifelse(is.na(p.adjust), NA_real_, log10(pmax(p.adjust, 1e-300)))
)]

term_levels <- selected_terms$term_key
term_labels <- setNames(selected_terms$Description, selected_terms$term_key)
cluster_labels <- setNames(mapping$cluster, mapping$cluster)

plot_data <- grid[
  diagonal == TRUE & !is.na(Count) & Count > 0 & !is.na(log10pvalue)
]
max_count <- max(plot_data$Count, na.rm = TRUE)
count_breaks <- pretty(c(0, max_count), n = 4)
count_breaks <- count_breaks[count_breaks > 0 & count_breaks <= max_count]
if (length(count_breaks) < 2L) count_breaks <- sort(unique(c(1, max_count)))

p <- ggplot(
  plot_data,
  aes(
    x = factor(cluster, levels = cluster_levels),
    y = factor(term_key, levels = term_levels)
  )
) +
  geom_point(
    aes(size = Count, fill = log10pvalue),
    shape = 21, colour = "#2A2A2A", stroke = 0.35
  ) +
  scale_x_discrete(labels = cluster_labels, drop = FALSE) +
  scale_y_discrete(labels = term_labels, drop = FALSE) +
  scale_size_continuous(
    range = c(1.2, 7.0), breaks = count_breaks, name = "Count"
  ) +
  scale_fill_gradientn(
    colours = c("#FFF200", "#F0A6B8", "#9C27E8"),
    name = "log10pvalue"
  ) +
  labs(x = "Fibroblasts subclusters", y = NULL) +
  theme_bw(base_size = 11) +
  theme(
    plot.title = element_blank(),
    plot.subtitle = element_blank(),
    panel.grid.major = element_line(colour = "#E5E5E5", linewidth = 0.35),
    panel.grid.minor = element_blank(),
    axis.title.x = element_text(face = "bold", size = 14, margin = margin(t = 8)),
    axis.text.x = element_text(size = 10, colour = "#111111"),
    axis.text.y = element_text(size = 9.2, colour = "#111111", hjust = 1),
    axis.ticks = element_line(colour = "#333333", linewidth = 0.35),
    legend.title = element_text(face = "bold", size = 11),
    legend.text = element_text(size = 9.5),
    legend.key.height = grid::unit(0.55, "cm"),
    legend.position = "right",
    plot.margin = margin(8, 12, 8, 8)
  ) +
  guides(
    size = guide_legend(order = 1, override.aes = list(fill = "white")),
    fill = guide_colourbar(order = 2, barheight = grid::unit(4.0, "cm"))
  )

ggsave(
  filename = target_pdf,
  plot = p,
  device = cairo_pdf,
  width = 13.5,
  height = 17.0,
  units = "in",
  limitsize = FALSE
)

fwrite(selected, selected_path, bom = TRUE)
fwrite(plot_data, plot_data_path, bom = TRUE)

audit <- c(
  paste0("created_at=", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  "request=expand GO diagonal plot to exactly five pathways per fibroblast subcluster",
  "layout=reference orientation: subclusters on x; selected GO BP terms on y",
  "selection=significant GO BP p.adjust<0.05 ranked by original specificity score",
  "display_policy=diagonal_only; each selected GO term is shown only for its source cluster",
  "size_mapping=Count",
  "fill_mapping=log10(raw pvalue), yellow=more significant, purple=less significant",
  paste0("clusters=", paste(cluster_levels, collapse = ",")),
  paste0("selected_terms=", nrow(selected)),
  paste0("grid_rows=", nrow(grid)),
  paste0("displayed_rows=", nrow(plot_data)),
  paste0("pdf=", normalizePath(target_pdf, winslash = "/"))
)
writeLines(audit, file.path(source_dir, "C\u56fe_\u6bcf\u7fa45\u6761GO\u901a\u8def_\u91cd\u7ed8\u5ba1\u8ba1.txt"), useBytes = TRUE)
writeLines(capture.output(sessionInfo()), file.path(source_dir, "C\u56fe_\u6bcf\u7fa45\u6761GO\u901a\u8def_R_sessionInfo.txt"), useBytes = TRUE)

message("Rebuilt GO plot: ", target_pdf)
message("Selected terms per cluster: ", paste(names(table(selected$source_cluster)), table(selected$source_cluster), sep = "=", collapse = ", "))
