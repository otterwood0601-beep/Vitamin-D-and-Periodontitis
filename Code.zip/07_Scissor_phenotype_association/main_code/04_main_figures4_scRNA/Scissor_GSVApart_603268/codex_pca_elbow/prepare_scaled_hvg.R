args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 4L) {
  stop("Usage: prepare_scaled_hvg.R <input_rds> <output_dir> <dataset_id> <dataset_label>")
}

input_rds <- normalizePath(args[[1]], winslash = "/", mustWork = TRUE)
output_dir <- args[[2]]
dataset_id <- args[[3]]
dataset_label <- args[[4]]

Sys.setlocale("LC_CTYPE", ".UTF-8")
options(stringsAsFactors = FALSE)
options(future.globals.maxSize = 32 * 1024^3)
set.seed(20260818)

seurat_lib <- "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_Seurat4"
dependency_lib <- "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_stage11"
.libPaths(unique(c(seurat_lib, .libPaths(), dependency_lib)))

suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
})

dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
audit_dir <- file.path(output_dir, "00_\u4ee3\u7801\u4e0e\u5ba1\u8ba1")
dir.create(audit_dir, recursive = TRUE, showWarnings = FALSE)

message("[1/6] Reading counts-only source: ", input_rds)
source_obj <- readRDS(input_rds)
if (!inherits(source_obj, "Seurat")) stop("Input is not a Seurat object")
DefaultAssay(source_obj) <- "RNA"
counts <- GetAssayData(source_obj, assay = "RNA", slot = "counts")
metadata <- source_obj[[]]

message("[2/6] Rebuilding a clean Seurat object from raw counts")
obj <- CreateSeuratObject(
  counts = counts,
  assay = "RNA",
  meta.data = metadata,
  min.cells = 0,
  min.features = 0,
  project = dataset_id
)
rm(source_obj, counts, metadata)
invisible(gc())

message("[3/6] LogNormalize (scale.factor=10000)")
obj <- NormalizeData(
  obj,
  normalization.method = "LogNormalize",
  scale.factor = 10000,
  verbose = FALSE
)

message("[4/6] Selecting 2000 HVGs independently by VST")
obj <- FindVariableFeatures(
  obj,
  selection.method = "vst",
  nfeatures = 2000,
  verbose = FALSE
)
hvg <- VariableFeatures(obj)
if (length(hvg) < 2L) stop("Fewer than two variable features were selected")

message("[5/6] Scaling the independently selected HVGs")
obj <- ScaleData(
  obj,
  features = hvg,
  do.center = TRUE,
  do.scale = TRUE,
  scale.max = 10,
  verbose = FALSE
)
scaled <- GetAssayData(obj, assay = "RNA", slot = "scale.data")[hvg, , drop = FALSE]
scaled <- as.matrix(scaled)
if (any(!is.finite(scaled))) stop("Non-finite values detected in scaled HVG matrix")

message("[6/6] Writing the scaled matrix for exact full-spectrum PCA")
binary_path <- file.path(audit_dir, paste0(dataset_id, "_scaled_2000HVG_float32.bin"))
con <- file(binary_path, open = "wb")
writeBin(as.numeric(scaled), con = con, size = 4L, endian = "little")
close(con)

hvg_table <- data.frame(
  hvg_rank = seq_along(hvg),
  gene = hvg,
  stringsAsFactors = FALSE
)
write.csv(
  hvg_table,
  file.path(audit_dir, paste0(dataset_id, "_\u72ec\u7acb\u91cd\u7b97_2000\u9ad8\u53d8\u57fa\u56e0.csv")),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

matrix_info <- data.frame(
  key = c(
    "dataset_id", "dataset_label", "input_rds", "n_genes_source",
    "n_cells", "n_hvg", "matrix_nrow", "matrix_ncol", "binary_path",
    "binary_dtype", "binary_order", "normalization", "variable_features",
    "scaling", "random_seed", "R_version", "Seurat_version"
  ),
  value = c(
    dataset_id, dataset_label, input_rds, nrow(obj), ncol(obj), length(hvg),
    nrow(scaled), ncol(scaled), normalizePath(binary_path, winslash = "/"),
    "float32 little-endian", "Fortran/column-major",
    "LogNormalize scale.factor=10000",
    "vst nfeatures=2000, recalculated from counts",
    "center=TRUE; scale=TRUE; scale.max=10; no covariates regressed",
    "20260818", R.version.string, as.character(packageVersion("Seurat"))
  ),
  stringsAsFactors = FALSE
)
write.csv(
  matrix_info,
  file.path(audit_dir, paste0(dataset_id, "_PCA\u72ec\u7acb\u91cd\u7b97_\u8f93\u5165\u4e0e\u53c2\u6570.csv")),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

session_lines <- capture.output(sessionInfo())
writeLines(
  c(
    "Independent PCA preparation audit",
    paste0("Created: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
    "Existing PCA/Harmony/clustering parameters were not imported.",
    "The input Seurat object was rebuilt from its RNA counts and metadata only.",
    "",
    session_lines
  ),
  file.path(audit_dir, paste0(dataset_id, "_R\u4f1a\u8bdd\u4e0e\u72ec\u7acb\u6027\u5ba1\u8ba1.txt")),
  useBytes = TRUE
)

message("Prepared: ", dataset_id, " | cells=", ncol(obj), " | HVGs=", length(hvg))
