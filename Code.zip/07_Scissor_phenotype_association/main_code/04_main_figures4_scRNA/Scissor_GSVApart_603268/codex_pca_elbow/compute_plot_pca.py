from __future__ import annotations
import csv
import json
import math
import os
import shutil
import sys
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

def read_key_value_csv(path: Path) -> dict[str, str]:
    with path.open('r', encoding='utf-8-sig', newline='') as handle:
        return {row['key']: row['value'] for row in csv.DictReader(handle)}

def piecewise_elbow(y: np.ndarray) -> int:
    x = np.arange(1, len(y) + 1, dtype=float)
    best_k, best_sse = (2, math.inf)
    for k in range(2, len(y)):
        fit1 = np.polyval(np.polyfit(x[:k], y[:k], 1), x[:k])
        fit2 = np.polyval(np.polyfit(x[k - 1:], y[k - 1:], 1), x[k - 1:])
        sse = float(np.square(y[:k] - fit1).sum() + np.square(y[k - 1:] - fit2).sum())
        if sse < best_sse:
            best_k, best_sse = (k, sse)
    return best_k

def kneedle_elbow(y: np.ndarray) -> int:
    x = np.linspace(0.0, 1.0, len(y))
    span = float(y[0] - y[-1])
    if span <= 0:
        return 1
    yn = (y - y[-1]) / span
    distance = 1.0 - x - yn
    return int(np.argmax(distance)) + 1

def first_threshold(cumulative: np.ndarray, threshold: float) -> int:
    idx = np.flatnonzero(cumulative >= threshold)
    return int(idx[0]) + 1 if len(idx) else -1

def write_csv(path: Path, header: list[str], rows) -> None:
    with path.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.writer(handle)
        writer.writerow(header)
        writer.writerows(rows)

def main() -> None:
    if len(sys.argv) != 4:
        raise SystemExit('Usage: compute_plot_pca.py <output_dir> <dataset_id> <dataset_label>')
    output_dir = Path(sys.argv[1])
    dataset_id = sys.argv[2]
    dataset_label = sys.argv[3]
    audit_dir = output_dir / '00_\u4ee3\u7801\u4e0e\u5ba1\u8ba1'
    info_path = audit_dir / f'{dataset_id}_PCA\u72ec\u7acb\u91cd\u7b97_\u8f93\u5165\u4e0e\u53c2\u6570.csv'
    info = read_key_value_csv(info_path)
    n_hvg = int(info['matrix_nrow'])
    n_cells = int(info['matrix_ncol'])
    binary_path = Path(info['binary_path'])
    expected_bytes = n_hvg * n_cells * 4
    actual_bytes = binary_path.stat().st_size
    if actual_bytes != expected_bytes:
        raise RuntimeError(f'Binary size mismatch: expected {expected_bytes}, got {actual_bytes}')
    print(f'Computing full covariance: {dataset_id}, {n_hvg} HVGs x {n_cells} cells', flush=True)
    matrix = np.memmap(binary_path, dtype='<f4', mode='r', shape=(n_hvg, n_cells), order='F')
    gram = np.zeros((n_hvg, n_hvg), dtype=np.float64)
    block_size = 768
    sum_squares = 0.0
    for start in range(0, n_cells, block_size):
        stop = min(start + block_size, n_cells)
        block = np.asarray(matrix[:, start:stop], dtype=np.float64, order='C')
        gram += block @ block.T
        sum_squares += float(np.square(block).sum())
        print(f'  cells {start + 1}-{stop}', flush=True)
    gram /= max(n_cells - 1, 1)
    print('Diagonalizing the complete 2000 x 2000 covariance matrix', flush=True)
    eigenvalues = np.linalg.eigvalsh(gram)[::-1]
    eigenvalues[eigenvalues < 0] = 0.0
    total_variance = float(eigenvalues.sum())
    direct_total = sum_squares / max(n_cells - 1, 1)
    total_difference = abs(total_variance - direct_total)
    variance_fraction = eigenvalues / total_variance
    cumulative = np.cumsum(variance_fraction)
    standard_deviation = np.sqrt(eigenvalues)
    rank_tolerance = max(float(eigenvalues[0]) * 1e-10, np.finfo(float).eps)
    effective_rank = int(np.count_nonzero(eigenvalues > rank_tolerance))
    n_elbow = min(50, effective_rank)
    if n_elbow < 4:
        raise RuntimeError(f'Only {effective_rank} non-zero PCs; an elbow cannot be estimated reliably')
    elbow_y = standard_deviation[:n_elbow]
    elbow_piecewise = piecewise_elbow(elbow_y)
    elbow_kneedle = kneedle_elbow(elbow_y)
    elbow_low = min(elbow_piecewise, elbow_kneedle)
    elbow_high = max(elbow_piecewise, elbow_kneedle)
    pc70 = first_threshold(cumulative, 0.7)
    pc80 = first_threshold(cumulative, 0.8)
    pc90 = first_threshold(cumulative, 0.9)
    pc_csv = audit_dir / f'{dataset_id}_\u5168\u90e8PC_\u65b9\u5dee\u8d21\u732e\u7387.csv'
    write_csv(pc_csv, ['PC', 'standard_deviation', 'eigenvalue', 'variance_pct_total', 'cumulative_variance_pct_total'], ((i + 1, f'{standard_deviation[i]:.10g}', f'{eigenvalues[i]:.10g}', f'{100 * variance_fraction[i]:.10g}', f'{100 * cumulative[i]:.10g}') for i in range(len(eigenvalues))))
    summary = {'dataset_id': dataset_id, 'dataset_label': dataset_label, 'input_rds': info['input_rds'], 'n_source_genes': int(info['n_genes_source']), 'n_cells': n_cells, 'n_hvg': n_hvg, 'variance_denominator': 'complete eigenvalue sum of the independently scaled 2000-HVG matrix', 'total_variance': total_variance, 'total_variance_direct_frobenius': direct_total, 'total_variance_absolute_difference': total_difference, 'elbow_piecewise_pc': elbow_piecewise, 'elbow_kneedle_pc': elbow_kneedle, 'elbow_consensus_low_pc': elbow_low, 'elbow_consensus_high_pc': elbow_high, 'pc_for_70_pct_total_variance': pc70, 'pc_for_80_pct_total_variance': pc80, 'pc_for_90_pct_total_variance': pc90, 'cumulative_at_piecewise_elbow_pct': float(100 * cumulative[elbow_piecewise - 1]), 'cumulative_at_kneedle_elbow_pct': float(100 * cumulative[elbow_kneedle - 1]), 'cumulative_final_pct': float(100 * cumulative[-1]), 'full_spectrum_pc_count': len(eigenvalues), 'effective_nonzero_pc_count': effective_rank, 'qa': {'eigenvalues_nonincreasing': bool(np.all(np.diff(eigenvalues) <= 1e-08)), 'cumulative_monotonic': bool(np.all(np.diff(cumulative) >= -1e-12)), 'cumulative_ends_at_100pct': bool(abs(cumulative[-1] - 1.0) < 1e-08), 'threshold_order_valid': bool(0 < pc70 <= pc80 <= pc90 <= len(eigenvalues)), 'trace_matches_frobenius': bool(total_difference <= max(1e-06, 1e-08 * direct_total))}}
    with (audit_dir / f'{dataset_id}_PCA\u62d0\u70b9\u4e0e\u7d2f\u8ba1\u8d21\u732e\u7387_\u6458\u8981.json').open('w', encoding='utf-8') as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    write_csv(output_dir / f'{dataset_id}_PCA\u62d0\u70b9\u4e0e\u7d2f\u8ba1\u8d21\u732e\u7387_\u6458\u8981.csv', ['dataset_id', 'dataset_label', 'n_cells', 'n_hvg', 'piecewise_elbow_pc', 'kneedle_elbow_pc', 'elbow_range', 'cum_at_piecewise_elbow_pct', 'cum_at_kneedle_elbow_pct', 'pc70', 'pc80', 'pc90', 'variance_denominator'], [[dataset_id, dataset_label, n_cells, n_hvg, elbow_piecewise, elbow_kneedle, f'PC{elbow_low}-PC{elbow_high}', f'{100 * cumulative[elbow_piecewise - 1]:.3f}', f'{100 * cumulative[elbow_kneedle - 1]:.3f}', pc70, pc80, pc90, 'all 2000 independently scaled HVGs']])
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10.5, 'axes.titlesize': 13, 'axes.labelsize': 11, 'axes.edgecolor': '#374151', 'axes.linewidth': 0.8, 'xtick.color': '#374151', 'ytick.color': '#374151', 'text.color': '#1f2937', 'pdf.fonttype': 42, 'ps.fonttype': 42})
    fig, axes = plt.subplots(1, 2, figsize=(14, 6.6), constrained_layout=True)
    fig.suptitle(dataset_label, fontsize=16, fontweight='bold', y=1.02)
    x_elbow = np.arange(1, n_elbow + 1)
    ax = axes[0]
    ax.plot(x_elbow, elbow_y, color='#1f77b4', linewidth=2.0)
    ax.scatter(x_elbow, elbow_y, color='#1f77b4', s=16, zorder=3)
    if elbow_low != elbow_high:
        ax.axvspan(elbow_low, elbow_high, color='#f59e0b', alpha=0.14, label=f'algorithm range PC{elbow_low}-{elbow_high}')
    ax.axvline(elbow_piecewise, color='#d62728', linestyle='--', linewidth=1.8, label=f'piecewise elbow: PC{elbow_piecewise}')
    ax.axvline(elbow_kneedle, color='#f59e0b', linestyle=':', linewidth=2.0, label=f'Kneedle: PC{elbow_kneedle}')
    ax.set_title(f'Elbow plot (first {n_elbow} non-zero PCs)', loc='left', fontweight='bold')
    ax.set_xlabel('Principal component')
    ax.set_ylabel('Standard deviation')
    ax.set_xlim(1, n_elbow)
    ax.grid(True, color='#dbe3ec', linewidth=0.8, alpha=0.8)
    ax.legend(frameon=False, loc='upper right')
    ax = axes[1]
    x_all = np.arange(1, effective_rank + 1)
    ax.plot(x_all, cumulative[:effective_rank] * 100, color='#2ca02c', linewidth=2.2)
    colors = {70: '#2563eb', 80: '#7c3aed', 90: '#dc2626'}
    thresholds = {70: pc70, 80: pc80, 90: pc90}
    for pct, pc in thresholds.items():
        ax.axhline(pct, color=colors[pct], linestyle='--', linewidth=1.2, alpha=0.8)
        ax.axvline(pc, color=colors[pct], linestyle=':', linewidth=1.5, alpha=0.9)
        ax.scatter([pc], [pct], color=colors[pct], s=35, zorder=4)
        ax.annotate(f'{pct}%: PC{pc}', xy=(pc, pct), xytext=(8, 7 if pct != 80 else -14), textcoords='offset points', color=colors[pct], fontsize=9.5)
    ax.set_title('Cumulative explained variance (complete spectrum)', loc='left', fontweight='bold')
    ax.set_xlabel('Number of principal components')
    ax.set_ylabel('Cumulative explained variance (%)')
    ax.set_xlim(1, effective_rank)
    ax.set_ylim(0, 102)
    ax.grid(True, color='#dbe3ec', linewidth=0.8, alpha=0.8)
    note = f'Denominator: all {n_hvg} scaled HVGs\nElbow algorithms: PC{elbow_piecewise} and PC{elbow_kneedle}\n70% / 80% / 90%: PC{pc70} / PC{pc80} / PC{pc90}'
    ax.text(0.98, 0.04, note, transform=ax.transAxes, ha='right', va='bottom', fontsize=9.2, bbox=dict(boxstyle='round,pad=0.45', facecolor='white', edgecolor='#9ca3af', alpha=0.92))
    pdf_path = output_dir / f'{dataset_id}_\u72ec\u7acb\u91cd\u7b97_PCA\u8098\u578b\u56fe\u4e0e\u7d2f\u8ba1\u8d21\u732e\u7387.pdf'
    png_path = output_dir / f'{dataset_id}_\u72ec\u7acb\u91cd\u7b97_PCA\u8098\u578b\u56fe\u4e0e\u7d2f\u8ba1\u8d21\u732e\u7387.png'
    fig.savefig(pdf_path, bbox_inches='tight')
    fig.savefig(png_path, dpi=300, bbox_inches='tight')
    plt.close(fig)
    readme_lines = [f'\u6570\u636e\u96c6\uff1a{dataset_label}', f'\u7ec6\u80de\u6570\uff1a{n_cells}\uff1b\u72ec\u7acb\u9009\u62e9\u9ad8\u53d8\u57fa\u56e0\u6570\uff1a{n_hvg}', '\u6d41\u7a0b\uff1a\u4ece RNA counts \u91cd\u5efa\u5bf9\u8c61 \u2192 LogNormalize(10000) \u2192 VST 2000 HVGs \u2192 ScaleData \u2192 \u5b8c\u6574\u7279\u5f81\u8c31 PCA\u3002', '\u672a\u8bfb\u53d6\u6216\u590d\u7528\u4efb\u4f55\u65e2\u6709 PCA\u3001Harmony\u3001\u90bb\u63a5\u56fe\u3001\u805a\u7c7b\u6216 resolution \u53c2\u6570\u3002', f'\u4e24\u6bb5\u7ebf\u6027\u62df\u5408\u62d0\u70b9\uff1aPC{elbow_piecewise}\uff1bKneedle \u62d0\u70b9\uff1aPC{elbow_kneedle}\uff1b\u5efa\u8bae\u5c06 PC{elbow_low}\u2013PC{elbow_high} \u4f5c\u4e3a\u62d0\u70b9\u68c0\u67e5\u533a\u95f4\u3002', f'\u8fbe\u5230\u603b\u65b9\u5dee 70% / 80% / 90% \u6240\u9700 PC \u6570\uff1a{pc70} / {pc80} / {pc90}\u3002', '\u7d2f\u8ba1\u8d21\u732e\u7387\u5206\u6bcd\u4e3a\u72ec\u7acb\u7f29\u653e\u540e\u7684\u5168\u90e8 2000 \u4e2a\u9ad8\u53d8\u57fa\u56e0\u7684\u5b8c\u6574\u7279\u5f81\u503c\u4e4b\u548c\uff0c\u4e0d\u662f\u524d 30/50 \u4e2a PC \u7684\u5c40\u90e8\u548c\u3002', f"QA\uff1a{json.dumps(summary['qa'], ensure_ascii=False)}"]
    (output_dir / f'{dataset_id}_\u7ed3\u679c\u8bf4\u660e.txt').write_text('\n'.join(readme_lines) + '\n', encoding='utf-8')
    del matrix
    try:
        binary_path.unlink()
    except PermissionError:
        pass
    print(json.dumps(summary, ensure_ascii=False), flush=True)
if __name__ == '__main__':
    main()
