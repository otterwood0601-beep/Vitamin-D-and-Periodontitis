from __future__ import annotations
import csv
import shutil
import sys
from pathlib import Path
from pypdf import PdfReader, PdfWriter

def read_one(path: Path) -> dict[str, str]:
    with path.open('r', encoding='utf-8-sig', newline='') as handle:
        return next(csv.DictReader(handle))

def write_rows(path: Path, rows: list[dict[str, str]]) -> None:
    with path.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

def merge_pdfs(inputs: list[Path], output: Path) -> None:
    writer = PdfWriter()
    for source in inputs:
        reader = PdfReader(source)
        for page in reader.pages:
            writer.add_page(page)
    with output.open('wb') as handle:
        writer.write(handle)

def main() -> None:
    if len(sys.argv) != 4:
        raise SystemExit('Usage: assemble_outputs.py <four_cohort_output> <williams_output> <script_dir>')
    four_root = Path(sys.argv[1])
    williams_root = Path(sys.argv[2])
    script_dir = Path(sys.argv[3])
    cohorts = [('01_\u5065\u5eb7', 'healthy'), ('02_\u7259\u9f88\u708e', 'gingivitis'), ('03_\u7259\u5468\u708e', 'periodontitis'), ('04_\u5065\u5eb7\u52a0\u7259\u9f88\u708e\u52a0\u7259\u5468\u708e', 'all_conditions')]
    rows: list[dict[str, str]] = []
    four_pdfs: list[Path] = []
    for subdir, dataset_id in cohorts:
        folder = four_root / subdir
        rows.append(read_one(folder / f'{dataset_id}_PCA\u62d0\u70b9\u4e0e\u7d2f\u8ba1\u8d21\u732e\u7387_\u6458\u8981.csv'))
        four_pdfs.append(folder / f'{dataset_id}_\u72ec\u7acb\u91cd\u7b97_PCA\u8098\u578b\u56fe\u4e0e\u7d2f\u8ba1\u8d21\u732e\u7387.pdf')
    williams_row = read_one(williams_root / 'williams_PCA\u62d0\u70b9\u4e0e\u7d2f\u8ba1\u8d21\u732e\u7387_\u6458\u8981.csv')
    write_rows(four_root / '\u56db\u961f\u5217_PCA\u62d0\u70b9\u4e0e\u7d2f\u8ba1\u8d21\u732e\u7387_\u6c47\u603b.csv', rows)
    write_rows(four_root / '\u5168\u90e8\u4e94\u7ec4_PCA\u62d0\u70b9\u4e0e\u7d2f\u8ba1\u8d21\u732e\u7387_\u6c47\u603b.csv', rows + [williams_row])
    write_rows(williams_root / 'Williams_PCA\u62d0\u70b9\u4e0e\u7d2f\u8ba1\u8d21\u732e\u7387_\u6c47\u603b.csv', [williams_row])
    merge_pdfs(four_pdfs, four_root / '\u56db\u961f\u5217_\u72ec\u7acb\u91cd\u7b97_PCA\u8098\u578b\u56fe\u4e0e\u7d2f\u8ba1\u8d21\u732e\u7387_\u6c47\u603b.pdf')
    for target_root in (four_root, williams_root):
        code_dir = target_root / '00_\u4ee3\u7801\u4e0e\u5ba1\u8ba1'
        code_dir.mkdir(parents=True, exist_ok=True)
        for name in ('prepare_scaled_hvg.R', 'compute_plot_pca.py', 'assemble_outputs.py'):
            shutil.copy2(script_dir / name, code_dir / name)
    all_rows = rows + [williams_row]
    lines = ['PCA \u8098\u578b\u56fe\u4e0e\u7d2f\u8ba1\u8d21\u732e\u7387\u72ec\u7acb\u91cd\u7b97\u6c47\u603b', '', '\u7edf\u4e00\u6d41\u7a0b\uff1aRNA counts \u2192 \u91cd\u5efa\u5e72\u51c0 Seurat \u5bf9\u8c61 \u2192 LogNormalize(10000) \u2192 VST 2000 HVGs \u2192 ScaleData \u2192 \u5b8c\u6574\u7279\u5f81\u8c31 PCA\u3002', '\u672a\u8bfb\u53d6\u4efb\u4f55\u65e2\u6709 PCA\u3001Harmony\u3001\u90bb\u63a5\u56fe\u3001\u805a\u7c7b\u6216 resolution \u53c2\u6570\u3002\u7d2f\u8ba1\u8d21\u732e\u7387\u5206\u6bcd\u4e3a\u5168\u90e8 2000 \u4e2a\u72ec\u7acb\u7f29\u653e HVG \u7684\u5b8c\u6574\u7279\u5f81\u503c\u4e4b\u548c\u3002', '', 'dataset | cells | elbow range | PC70 | PC80 | PC90']
    for row in all_rows:
        lines.append(f"{row['dataset_label']} | {row['n_cells']} | {row['elbow_range']} | {row['pc70']} | {row['pc80']} | {row['pc90']}")
    lines.extend(['', '\u89e3\u91ca\uff1a\u5927\u961f\u5217\u4e2d 70%\u201390% \u603b\u65b9\u5dee\u9700\u4fdd\u7559\u6570\u767e\u81f3\u4e0a\u5343 PC\uff0c\u8fd9\u4e0d\u9002\u5408\u4f5c\u4e3a\u5355\u7ec6\u80de\u805a\u7c7b\u7684\u76f4\u63a5\u9009\u7ef4\u6807\u51c6\uff1b\u5e94\u4f18\u5148\u7ed3\u5408\u8098\u70b9\u533a\u95f4\u4e0e\u4e0b\u6e38\u7a33\u5b9a\u6027\u3002', '\u7259\u9f88\u708e\u4ec5 23 \u4e2a\u7ec6\u80de\u3001\u6709\u6548\u79e9 22\uff0c\u62d0\u70b9\u548c\u7d2f\u8ba1\u9608\u503c\u5747\u53d7\u5c0f\u6837\u672c\u5f3a\u7ea6\u675f\uff0c\u5e94\u5355\u72ec\u8c28\u614e\u89e3\u91ca\u3002'])
    (four_root / 'PCA\u72ec\u7acb\u91cd\u7b97_\u7ed3\u679c\u6c47\u603b\u8bf4\u660e.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    (williams_root / 'PCA\u72ec\u7acb\u91cd\u7b97_\u7ed3\u679c\u6c47\u603b\u8bf4\u660e.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
if __name__ == '__main__':
    main()
