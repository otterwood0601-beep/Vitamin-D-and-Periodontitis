script_dir <- dirname(normalizePath(
  sub("^--file=", "", grep("^--file=", commandArgs(), value = TRUE)[1]),
  winslash = "/",
  mustWork = TRUE
))
source(file.path(script_dir, "00_common.R"), encoding = "UTF-8")

dataset_root <- file.path(RAW_ROOT, "GSE171213")
count_dir <- file.path(
  dataset_root,
  "raw_supplement",
  "per_sample_counts"
)
metadata <- fread(file.path(
  dataset_root,
  "metadata",
  "GSE171213_GEO_sample_metadata.tsv"
))

metadata[
  ,
  sample_id := title
]
metadata[
  ,
  donor_id := title
]
metadata[
  ,
  clinical_group := fifelse(
    inferred_group == "Healthy",
    "Healthy",
    fifelse(inferred_group == "Post-treatment", "Post_treatment", "Periodontitis")
  )
]

objects_by_group <- setNames(
  vector("list", 3L),
  c("Healthy", "Periodontitis", "Post_treatment")
)
qc_rows <- list()

for (index in seq_len(nrow(metadata))) {
  row <- metadata[index]
  count_file <- file.path(
    count_dir,
    paste0(row$geo_accession, "_", row$sample_id, ".counts.tsv.gz")
  )
  cell_file <- file.path(
    count_dir,
    paste0(row$geo_accession, "_", row$sample_id, ".cellname.list.txt.gz")
  )
  if (!all(file.exists(c(count_file, cell_file)))) {
    stop("Missing GSE171213 processed matrix for ", row$sample_id)
  }
  message(
    "Reading dense GSE171213 matrix ", row$sample_id,
    " at ", format(Sys.time())
  )
  dense <- fread(count_file, check.names = FALSE)
  genes <- make.unique(dense[[1]])
  dense[[1]] <- NULL
  count_matrix <- as.matrix(dense)
  storage.mode(count_matrix) <- "numeric"
  sparse <- Matrix(count_matrix, sparse = TRUE)
  rownames(sparse) <- genes
  cell_map <- fread(cell_file)
  if (!all(c("CellName", "CellIndex") %in% names(cell_map))) {
    stop("Unexpected cell-name manifest for ", row$sample_id)
  }
  ordered_names <- cell_map$CellName[
    match(colnames(sparse), cell_map$CellIndex)
  ]
  if (anyNA(ordered_names)) {
    stop("Cell indices do not align for ", row$sample_id)
  }
  colnames(sparse) <- ordered_names
  rm(dense, count_matrix, cell_map)
  gc()

  result <- qc_and_extract_fibroblast(
    counts = sparse,
    sample_id = row$sample_id,
    donor_id = row$donor_id,
    clinical_group = row$clinical_group,
    dataset = "GSE171213"
  )
  objects_by_group[[row$clinical_group]] <- c(
    objects_by_group[[row$clinical_group]],
    list(result$object)
  )
  qc_rows[[length(qc_rows) + 1L]] <- result$qc
  rm(sparse, result)
  gc()
}

qc_all <- rbindlist(qc_rows, fill = TRUE)
safe_write_csv(
  qc_all,
  file.path(OUTPUT_ROOT, "05_GSE171213", "GSE171213_sample_QC.csv")
)

for (group_key in names(objects_by_group)) {
  object <- merge_fibroblast_objects(objects_by_group[[group_key]])
  safe_write_csv(
    qc_all[clinical_group == group_key],
    file.path(group_dir("GSE171213", group_key), "00_QC", "sample_QC.csv")
  )
  cluster_fibroblast_group(
    object = object,
    dataset = "GSE171213",
    group_key = group_key,
    source_value_type = "GEO supplied processed UMI count tables",
    renormalize = TRUE
  )
  rm(object)
  gc()
}
