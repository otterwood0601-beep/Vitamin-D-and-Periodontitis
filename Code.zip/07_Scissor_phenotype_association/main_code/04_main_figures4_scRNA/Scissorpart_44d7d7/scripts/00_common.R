options(stringsAsFactors = FALSE)
options(Seurat.object.assay.version = "v3")
options(future.globals.maxSize = 24 * 1024^3)

PIPELINE_SEED <- 20260730L
set.seed(PIPELINE_SEED)

OUTPUT_ROOT <- normalizePath(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u4ee3\u7801/\u8fd0\u884c\u8f93\u51fa/20260730-\u591a\u6570\u636e\u5e93-\u7259\u9f88\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e9a\u7fa4-Scissor-Figure4\u590d\u7b97",
  winslash = "/",
  mustWork = TRUE
)
RAW_ROOT <- normalizePath(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/05_\u5355\u7ec6\u80deRNA/01_scRNA-seq",
  winslash = "/",
  mustWork = TRUE
)
RUNTIME_ROOT <- normalizePath(
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883",
  winslash = "/",
  mustWork = TRUE
)

dir.create(
  file.path(OUTPUT_ROOT, "source_data", "R_library"),
  recursive = TRUE,
  showWarnings = FALSE
)
.libPaths(c(
  file.path(OUTPUT_ROOT, "source_data", "R_library"),
  file.path(RUNTIME_ROOT, "R_library_stage11"),
  file.path(RUNTIME_ROOT, "R_library"),
  file.path(RUNTIME_ROOT, "R_library_Seurat4"),
  file.path(RUNTIME_ROOT, "R_library_enrichment"),
  file.path(RUNTIME_ROOT, "R_library_raw"),
  .libPaths()
))

suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
  library(data.table)
  library(ggplot2)
  library(ggrepel)
  library(jsonlite)
})

CANDIDATE_GENES <- c("GDF15", "PLAU", "RORC")
REFERENCE_LOG2FC <- log2(1.2)
MIN_FIBROBLAST_CELLS <- 100L
MIN_SUBCLUSTER_CELLS <- 40L
SCISSOR_MAX_CELLS <- 3000L

LINEAGE_MARKERS <- list(
  Fibroblast = c(
    "COL1A1", "COL1A2", "COL3A1", "DCN", "LUM", "PDGFRA",
    "COL6A1", "COL6A2", "COL6A3", "SPARC"
  ),
  Epithelial = c(
    "EPCAM", "KRT5", "KRT14", "KRT15", "KRT19", "KRT8", "KRT18"
  ),
  Endothelial = c(
    "PECAM1", "VWF", "EMCN", "KDR", "CLDN5", "RAMP2", "ENG"
  ),
  Pericyte = c(
    "RGS5", "MCAM", "CSPG4", "ACTA2", "PDGFRB", "COL4A1", "MYH11"
  ),
  Myeloid = c(
    "LST1", "TYROBP", "FCER1G", "CTSS", "LYZ", "AIF1", "CSF1R"
  ),
  T_NK = c(
    "CD3D", "CD3E", "TRBC1", "TRBC2", "IL7R", "NKG7", "GNLY"
  ),
  B_Plasma = c(
    "MS4A1", "CD79A", "CD74", "CD37", "MZB1", "JCHAIN", "SDC1"
  ),
  Mast = c("KIT", "TPSAB1", "TPSB2", "CPA3", "MS4A2")
)

FIBROBLAST_STATE_MARKERS <- list(
  Matrix_homeostatic = c(
    "COL1A1", "COL1A2", "COL3A1", "COL6A1", "DCN", "LUM",
    "COL14A1", "PI16", "COCH", "ITIH5"
  ),
  Inflammatory_CXCL = c(
    "CXCL1", "CXCL2", "CXCL3", "CXCL5", "CXCL6", "CXCL8",
    "IL6", "CCL2", "IL24", "TNFRSF21"
  ),
  Immune_regulatory = c(
    "CXCL13", "CCL19", "C3", "C7", "C1R", "C1S", "CFD",
    "HLA-DRA", "HLA-DPB1", "CD74"
  ),
  ECM_remodeling = c(
    "COL11A1", "ASPN", "SFRP4", "FNDC1", "POSTN", "MMP2",
    "MMP3", "MMP11", "MMP14", "PLAU", "TNC", "FAP", "THBS1"
  ),
  Perivascular_adventitial = c(
    "SFRP1", "ANGPTL1", "PTGDS", "RBP1", "COL4A1", "COL4A2",
    "PDGFRB", "MCAM", "CSPG4", "RGS5"
  ),
  Myofibroblast = c(
    "ACTA2", "TAGLN", "MYL9", "TPM2", "CNN1", "MYH11"
  ),
  Osteogenic_MSC = c(
    "CD55", "CXCL12", "APOE", "ALPL", "IBSP", "RUNX2",
    "SP7", "SPP1", "BGLAP"
  ),
  Proliferative = c(
    "MKI67", "TOP2A", "UBE2C", "CENPF", "TUBA1B", "HMGB2"
  ),
  Stress_GDF15 = c(
    "GDF15", "ATF3", "JUN", "FOS", "DDIT3", "IER2", "IER3",
    "HSPA1A", "HSPA1B"
  )
)

GROUP_OUTPUTS <- data.table(
  dataset = c(
    rep("GSE164241", 3),
    rep("GSE152042", 3),
    rep("CNP0001395", 2),
    rep("CELLxGENE", 3),
    rep("GSE171213", 3)
  ),
  group_key = c(
    "Healthy", "Periodontitis", "LAD1_periodontitis",
    "Healthy", "Mild_periodontitis", "Severe_periodontitis",
    "Healthy", "Periodontitis",
    "Healthy", "Gingivitis", "Periodontitis",
    "Healthy", "Periodontitis", "Post_treatment"
  ),
  folder = c(
    "01_GSE164241/GSE164241-\u5065\u5eb7\u7259\u9f88",
    "01_GSE164241/GSE164241-\u7259\u5468\u708e",
    "01_GSE164241/GSE164241-LAD1\u7259\u5468\u708e",
    "02_GSE152042/GSE152042-\u5065\u5eb7\u7259\u9f88",
    "02_GSE152042/GSE152042-\u8f7b\u5ea6\u7259\u5468\u708e",
    "02_GSE152042/GSE152042-\u91cd\u5ea6\u7259\u5468\u708e",
    "03_CNP0001395/CNP0001395-\u5065\u5eb7\u7259\u9f88",
    "03_CNP0001395/CNP0001395-\u7259\u5468\u708e",
    "04_CELLxGENE/CELLxGENE-\u5065\u5eb7",
    "04_CELLxGENE/CELLxGENE-\u9f88\u708e",
    "04_CELLxGENE/CELLxGENE-\u7259\u5468\u708e",
    "05_GSE171213/GSE171213-\u5065\u5eb7",
    "05_GSE171213/GSE171213-\u7259\u5468\u708e",
    "05_GSE171213/GSE171213-\u6cbb\u7597\u540e"
  )
)

for (folder in GROUP_OUTPUTS$folder) {
  path <- file.path(OUTPUT_ROOT, folder)
  for (subfolder in c(
    "00_QC", "01_fibroblast_atlas", "02_official_Scissor",
    "03_DE_enrichment_GSVA", "04_Figure4A-J", "source_data", "logs"
  )) {
    dir.create(
      file.path(path, subfolder),
      recursive = TRUE,
      showWarnings = FALSE
    )
  }
}

group_dir <- function(dataset, group_key) {
  dataset_value <- dataset
  group_value <- group_key
  hit <- GROUP_OUTPUTS[
    dataset == dataset_value & group_key == group_value,
    folder
  ]
  if (length(hit) != 1L) {
    stop("Unknown or duplicated dataset/group: ", dataset, " / ", group_key)
  }
  file.path(OUTPUT_ROOT, hit)
}

safe_write_csv <- function(x, path, gzip = grepl("\\.gz$", path)) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  if (gzip) {
    fwrite(as.data.table(x), path)
  } else {
    fwrite(as.data.table(x), path, bom = TRUE)
  }
}

safe_write_json <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  write_json(x, path, pretty = TRUE, auto_unbox = TRUE, na = "null")
}

module_score_matrix <- function(data_matrix, marker_sets) {
  result <- lapply(marker_sets, function(genes) {
    genes <- intersect(genes, rownames(data_matrix))
    if (!length(genes)) {
      return(rep(0, ncol(data_matrix)))
    }
    Matrix::colMeans(data_matrix[genes, , drop = FALSE])
  })
  result <- do.call(cbind, result)
  colnames(result) <- names(marker_sets)
  rownames(result) <- colnames(data_matrix)
  result
}

extract_fibroblast_cells <- function(object) {
  DefaultAssay(object) <- "RNA"
  if (ncol(object) == 0L) {
    return(character())
  }
  if (!"data" %in% Layers(object[["RNA"]])) {
    object <- NormalizeData(object, verbose = FALSE)
  }
  data_matrix <- GetAssayData(object, assay = "RNA", layer = "data")
  count_matrix <- GetAssayData(object, assay = "RNA", layer = "counts")
  scores <- module_score_matrix(data_matrix, LINEAGE_MARKERS)
  fibro_genes <- intersect(LINEAGE_MARKERS$Fibroblast, rownames(count_matrix))
  fibro_detected <- Matrix::colSums(
    count_matrix[fibro_genes, , drop = FALSE] > 0
  )
  best_lineage <- colnames(scores)[max.col(scores, ties.method = "first")]
  names(best_lineage) <- rownames(scores)
  selected <- rownames(scores)[
    best_lineage == "Fibroblast" &
      fibro_detected >= 2L &
      scores[, "Fibroblast"] > 0
  ]
  selected
}

qc_and_extract_fibroblast <- function(
    counts,
    sample_id,
    donor_id,
    clinical_group,
    dataset,
    prefiltered = FALSE) {
  if (is.null(colnames(counts))) {
    colnames(counts) <- paste0(sample_id, "_Cell", seq_len(ncol(counts)))
  }
  colnames(counts) <- make.unique(paste(sample_id, colnames(counts), sep = "_"))
  object <- CreateSeuratObject(
    counts = counts,
    project = paste(dataset, clinical_group, sep = "_"),
    min.cells = 0,
    min.features = 0
  )
  object$sample_id <- sample_id
  object$donor_id <- donor_id
  object$clinical_group <- clinical_group
  object$dataset <- dataset
  object[["percent.mt"]] <- PercentageFeatureSet(object, pattern = "^MT-")
  loaded_n <- ncol(object)
  if (!prefiltered) {
    upper_umi <- as.numeric(quantile(object$nCount_RNA, 0.995))
    keep <- (
      object$nFeature_RNA >= 200 &
        object$nFeature_RNA <= 7500 &
        object$percent.mt <= 25 &
        object$nCount_RNA <= upper_umi
    )
    object <- subset(object, cells = colnames(object)[keep])
  } else {
    upper_umi <- NA_real_
  }
  qc_n <- ncol(object)
  object <- NormalizeData(object, verbose = FALSE)
  selected <- extract_fibroblast_cells(object)
  fibroblast <- if (length(selected)) {
    subset(object, cells = selected)
  } else {
    NULL
  }
  qc <- data.table(
    dataset = dataset,
    clinical_group = clinical_group,
    sample_id = sample_id,
    donor_id = donor_id,
    cells_loaded = loaded_n,
    cells_after_QC = qc_n,
    fibroblast_cells = length(selected),
    fibroblast_percent_after_QC = if (qc_n) length(selected) / qc_n * 100 else NA_real_,
    upper_UMI_99.5pct = upper_umi,
    fibroblast_rule = paste(
      "highest major-lineage module score;",
      "at least two pan-fibroblast markers detected"
    )
  )
  list(object = fibroblast, qc = qc)
}

merge_fibroblast_objects <- function(objects) {
  objects <- Filter(Negate(is.null), objects)
  if (!length(objects)) {
    return(NULL)
  }
  if (length(objects) == 1L) {
    result <- objects[[1]]
  } else {
    result <- merge(
      x = objects[[1]],
      y = objects[-1],
      merge.data = TRUE
    )
  }
  DefaultAssay(result) <- "RNA"
  if (length(Layers(result[["RNA"]])) > 2L) {
    result <- JoinLayers(result, assay = "RNA")
  }
  result
}

adaptive_resolution <- function(n_cells) {
  if (n_cells < 300) return(0.20)
  if (n_cells < 1000) return(0.30)
  if (n_cells < 5000) return(0.40)
  0.50
}

cluster_fibroblast_group <- function(
    object,
    dataset,
    group_key,
    source_value_type = "UMI counts",
    renormalize = TRUE) {
  out <- group_dir(dataset, group_key)
  qc_dir <- file.path(out, "00_QC")
  atlas_dir <- file.path(out, "01_fibroblast_atlas")
  source_dir <- file.path(out, "source_data")
  if (is.null(object) || ncol(object) < MIN_FIBROBLAST_CELLS) {
    n_cells <- if (is.null(object)) 0L else ncol(object)
    audit <- list(
      dataset = dataset,
      clinical_group = group_key,
      status = "insufficient_fibroblast_cells",
      fibroblast_cells = n_cells,
      minimum_required = MIN_FIBROBLAST_CELLS,
      reason = paste(
        "No biologically defensible fibroblast subclustering or",
        "Scissor analysis is produced below the prespecified minimum."
      )
    )
    safe_write_json(audit, file.path(qc_dir, "analysis_feasibility.json"))
    return(invisible(audit))
  }

  DefaultAssay(object) <- "RNA"
  if (renormalize || !"data" %in% Layers(object[["RNA"]])) {
    object <- NormalizeData(object, verbose = FALSE)
  }
  object <- FindVariableFeatures(
    object,
    selection.method = "vst",
    nfeatures = min(2500L, nrow(object)),
    verbose = FALSE
  )
  object <- ScaleData(
    object,
    features = VariableFeatures(object),
    verbose = FALSE
  )
  npcs <- min(30L, ncol(object) - 1L, length(VariableFeatures(object)) - 1L)
  if (npcs < 5L) {
    stop("Too few dimensions for fibroblast clustering: ", npcs)
  }
  object <- RunPCA(
    object,
    features = VariableFeatures(object),
    npcs = npcs,
    verbose = FALSE,
    seed.use = PIPELINE_SEED
  )
  dims_use <- seq_len(min(25L, npcs))
  object <- FindNeighbors(
    object,
    reduction = "pca",
    dims = dims_use,
    graph.name = c("RNA_nn", "RNA_snn"),
    verbose = FALSE
  )
  resolution <- adaptive_resolution(ncol(object))
  object <- FindClusters(
    object,
    graph.name = "RNA_snn",
    algorithm = 1,
    resolution = resolution,
    random.seed = PIPELINE_SEED,
    verbose = FALSE
  )
  object <- RunUMAP(
    object,
    reduction = "pca",
    dims = dims_use,
    seed.use = PIPELINE_SEED,
    n.neighbors = min(30L, max(10L, floor(sqrt(ncol(object))))),
    min.dist = 0.30,
    verbose = FALSE
  )
  Idents(object) <- "seurat_clusters"

  cluster_sizes <- table(object$seurat_clusters)
  tiny <- names(cluster_sizes)[cluster_sizes < MIN_SUBCLUSTER_CELLS]
  object$low_cell_cluster <- object$seurat_clusters %in% tiny

  markers <- FindAllMarkers(
    object,
    assay = "RNA",
    slot = "data",
    only.pos = TRUE,
    test.use = "wilcox",
    logfc.threshold = 0.20,
    min.pct = 0.10,
    return.thresh = 1,
    verbose = FALSE
  )
  markers_dt <- as.data.table(markers, keep.rownames = "marker_row")
  if (!"gene" %in% names(markers_dt)) {
    markers_dt[, gene := rownames(markers)]
  }

  marker_schema <- list(
    gene = character(),
    cluster = character(),
    p_val = numeric(),
    avg_log2FC = numeric(),
    pct.1 = numeric(),
    pct.2 = numeric(),
    p_val_adj = numeric()
  )
  for (field in names(marker_schema)) {
    if (!field %in% names(markers_dt)) {
      markers_dt[, (field) := marker_schema[[field]]]
    }
  }
  markers_dt[, cluster := as.character(cluster)]
  safe_write_csv(
    markers_dt,
    file.path(atlas_dir, "04_FindAllMarkers_fibroblast_subclusters.csv.gz")
  )

  data_matrix <- GetAssayData(object, assay = "RNA", layer = "data")
  cluster_ids <- sort(unique(as.character(object$seurat_clusters)))
  state_scores <- rbindlist(lapply(cluster_ids, function(cluster_id) {
    cells <- colnames(object)[as.character(object$seurat_clusters) == cluster_id]
    rbindlist(lapply(names(FIBROBLAST_STATE_MARKERS), function(state) {
      genes <- intersect(FIBROBLAST_STATE_MARKERS[[state]], rownames(data_matrix))
      data.table(
        cluster = cluster_id,
        state = state,
        n_genes = length(genes),
        mean_expression = if (length(genes)) {
          mean(Matrix::rowMeans(data_matrix[genes, cells, drop = FALSE]))
        } else {
          0
        }
      )
    }))
  }))
  state_scores[
    ,
    z_score := if (.N > 1L && sd(mean_expression) > 0) {
      as.numeric(scale(mean_expression))
    } else {
      mean_expression
    },
    by = state
  ]
  best_state <- state_scores[
    order(cluster, -z_score, -mean_expression),
    .SD[1],
    by = cluster
  ]

  top_marker_table <- markers_dt[
    order(cluster, p_val_adj, -avg_log2FC),
    .(top_markers = paste(head(gene, 8), collapse = ";")),
    by = cluster
  ]
  annotation <- merge(
    data.table(
      cluster = cluster_ids,
      cells = as.integer(cluster_sizes[cluster_ids]),
      proportion = as.integer(cluster_sizes[cluster_ids]) / ncol(object)
    ),
    best_state[, .(cluster, best_state = state, state_score = z_score)],
    by = "cluster",
    all.x = TRUE
  )
  annotation <- merge(annotation, top_marker_table, by = "cluster", all.x = TRUE)
  annotation[
    ,
    low_cell_cluster := cells < MIN_SUBCLUSTER_CELLS
  ]
  annotation[
    ,
    subtype := paste0(
      "FB", cluster, ": ",
      gsub("_", " ", best_state),
      fifelse(low_cell_cluster, " (low-cell)", "")
    )
  ]
  subtype_map <- setNames(annotation$subtype, annotation$cluster)
  object$fibroblast_subtype <- factor(
    unname(subtype_map[as.character(object$seurat_clusters)]),
    levels = annotation[order(as.numeric(cluster)), subtype]
  )
  Idents(object) <- "fibroblast_subtype"

  safe_write_csv(
    state_scores,
    file.path(atlas_dir, "05_fibroblast_state_module_scores.csv")
  )
  safe_write_csv(
    annotation,
    file.path(atlas_dir, "06_fibroblast_subtype_annotation.csv")
  )

  umap <- Embeddings(object, "umap")
  umap_table <- cbind(
    data.table(
    cell = rownames(umap),
    UMAP_1 = umap[, 1],
      UMAP_2 = umap[, 2]
    ),
    as.data.table(object[[]][rownames(umap), , drop = FALSE])
  )
  safe_write_csv(
    umap_table,
    file.path(atlas_dir, "01_fibroblast_UMAP_metadata.csv.gz")
  )
  subtype_counts <- as.data.table(table(
    fibroblast_subtype = object$fibroblast_subtype
  ))
  subtype_counts[, proportion := N / sum(N)]
  safe_write_csv(
    subtype_counts,
    file.path(atlas_dir, "02_fibroblast_subtype_counts.csv")
  )

  top_features <- unique(unlist(lapply(levels(object$fibroblast_subtype), function(label) {
    cluster_id <- sub("^FB([^:]+):.*$", "\\1", label)
    canonical <- annotation[cluster == cluster_id, best_state]
    canonical_genes <- FIBROBLAST_STATE_MARKERS[[canonical]]
    marker_genes <- markers_dt[
      as.character(cluster) == cluster_id
    ][order(p_val_adj, -avg_log2FC), head(gene, 4)]
    head(unique(c(marker_genes, canonical_genes)), 5)
  })))
  top_features <- intersect(top_features, rownames(data_matrix))
  marker_summary <- rbindlist(lapply(
    levels(object$fibroblast_subtype),
    function(label) {
      cells <- colnames(object)[object$fibroblast_subtype == label]
      rbindlist(lapply(top_features, function(gene) {
        values <- as.numeric(data_matrix[gene, cells])
        data.table(
          fibroblast_subtype = label,
          feature = gene,
          average_expression = mean(values),
          percent_expressed = mean(values > 0) * 100
        )
      }))
    }
  ))
  safe_write_csv(
    marker_summary,
    file.path(atlas_dir, "03_fibroblast_marker_DotPlot_source.csv")
  )

  candidate_summary <- rbindlist(lapply(
    CANDIDATE_GENES,
    function(gene) {
      rbindlist(lapply(levels(object$fibroblast_subtype), function(label) {
        cells <- colnames(object)[object$fibroblast_subtype == label]
        if (!gene %in% rownames(data_matrix)) {
          return(data.table(
            gene = gene,
            fibroblast_subtype = label,
            cells = length(cells),
            average_expression = NA_real_,
            percent_expressed = NA_real_
          ))
        }
        values <- as.numeric(data_matrix[gene, cells])
        data.table(
          gene = gene,
          fibroblast_subtype = label,
          cells = length(cells),
          average_expression = mean(values),
          percent_expressed = mean(values > 0) * 100
        )
      }))
    }
  ))
  safe_write_csv(
    candidate_summary,
    file.path(atlas_dir, "07_GDF15_PLAU_RORC_by_subtype.csv")
  )

  saveRDS(
    object,
    file.path(source_dir, "fibroblast_atlas_full.rds"),
    compress = FALSE
  )

  all_cells <- colnames(object)
  strata <- interaction(
    object$sample_id,
    object$fibroblast_subtype,
    drop = TRUE
  )
  split_cells <- split(all_cells, strata)
  target_n <- min(SCISSOR_MAX_CELLS, length(all_cells))
  selected <- unique(unlist(lapply(split_cells, function(cells) {
    quota <- max(1L, floor(target_n / length(split_cells)))
    sample(cells, min(length(cells), quota))
  }), use.names = FALSE))
  if (length(selected) < target_n) {
    remaining <- setdiff(all_cells, selected)
    selected <- c(
      selected,
      sample(remaining, min(length(remaining), target_n - length(selected)))
    )
  }
  selected <- selected[seq_len(min(target_n, length(selected)))]
  scissor_object <- subset(object, cells = selected)
  DefaultAssay(scissor_object) <- "RNA"
  scissor_object <- FindNeighbors(
    scissor_object,
    reduction = "pca",
    dims = dims_use,
    graph.name = c("RNA_nn", "RNA_snn"),
    verbose = FALSE
  )
  saveRDS(
    scissor_object,
    file.path(source_dir, "fibroblast_Scissor_input.rds"),
    compress = FALSE
  )

  donor_cluster <- as.data.table(table(
    donor_id = object$donor_id,
    sample_id = object$sample_id,
    fibroblast_subtype = object$fibroblast_subtype
  ))
  donor_cluster <- donor_cluster[N > 0]
  safe_write_csv(
    donor_cluster,
    file.path(atlas_dir, "08_subtype_by_donor_and_sample.csv")
  )

  audit <- list(
    dataset = dataset,
    clinical_group = group_key,
    status = "fibroblast_subclusters_completed",
    all_fibroblast_cells = ncol(object),
    donors = length(unique(object$donor_id)),
    samples = length(unique(object$sample_id)),
    clusters = length(unique(object$seurat_clusters)),
    low_cell_clusters = tiny,
    clustering = paste0(
      "Seurat PCA; FindNeighbors PCs 1-", max(dims_use),
      "; FindClusters Louvain resolution ", resolution,
      "; RunUMAP"
    ),
    cluster_annotation = paste(
      "Highest cross-cluster standardized canonical fibroblast-state",
      "module score, checked against top FindAllMarkers genes."
    ),
    source_value_type = source_value_type,
    scissor_input_cells = ncol(scissor_object),
    candidate_genes = CANDIDATE_GENES,
    seed = PIPELINE_SEED
  )
  safe_write_json(audit, file.path(qc_dir, "analysis_feasibility.json"))
  invisible(audit)
}
