from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\20260730-\u591a\u6570\u636e\u5e93-\u7259\u9f88\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e9a\u7fa4-Scissor-Figure4\u590d\u7b97')
SUMMARY_DIR = ROOT / 'summary'
METHOD_DIR = ROOT / '00_\u65b9\u6cd5\u4e0e\u8d28\u63a7'
SUMMARY_DIR.mkdir(parents=True, exist_ok=True)
METHOD_DIR.mkdir(parents=True, exist_ok=True)
GROUPS = [('GSE164241', '\u5065\u5eb7\u7259\u9f88', ROOT / '01_GSE164241' / 'GSE164241-\u5065\u5eb7\u7259\u9f88'), ('GSE164241', '\u7259\u5468\u708e', ROOT / '01_GSE164241' / 'GSE164241-\u7259\u5468\u708e'), ('GSE164241', 'LAD1\u7259\u5468\u708e', ROOT / '01_GSE164241' / 'GSE164241-LAD1\u7259\u5468\u708e'), ('GSE152042', '\u5065\u5eb7\u7259\u9f88', ROOT / '02_GSE152042' / 'GSE152042-\u5065\u5eb7\u7259\u9f88'), ('GSE152042', '\u8f7b\u5ea6\u7259\u5468\u708e', ROOT / '02_GSE152042' / 'GSE152042-\u8f7b\u5ea6\u7259\u5468\u708e'), ('GSE152042', '\u91cd\u5ea6\u7259\u5468\u708e', ROOT / '02_GSE152042' / 'GSE152042-\u91cd\u5ea6\u7259\u5468\u708e'), ('CNP0001395', '\u5065\u5eb7\u7259\u9f88', ROOT / '03_CNP0001395' / 'CNP0001395-\u5065\u5eb7\u7259\u9f88'), ('CNP0001395', '\u7259\u5468\u708e', ROOT / '03_CNP0001395' / 'CNP0001395-\u7259\u5468\u708e'), ('CELLxGENE', '\u5065\u5eb7', ROOT / '04_CELLxGENE' / 'CELLxGENE-\u5065\u5eb7'), ('CELLxGENE', '\u9f88\u708e', ROOT / '04_CELLxGENE' / 'CELLxGENE-\u9f88\u708e'), ('CELLxGENE', '\u7259\u5468\u708e', ROOT / '04_CELLxGENE' / 'CELLxGENE-\u7259\u5468\u708e'), ('GSE171213', '\u5065\u5eb7', ROOT / '05_GSE171213' / 'GSE171213-\u5065\u5eb7'), ('GSE171213', '\u7259\u5468\u708e', ROOT / '05_GSE171213' / 'GSE171213-\u7259\u5468\u708e'), ('GSE171213', '\u6cbb\u7597\u540e', ROOT / '05_GSE171213' / 'GSE171213-\u6cbb\u7597\u540e')]

def load_json(path: Path) -> dict:
    if not path.exists():
        return {}
    with path.open(encoding='utf-8') as handle:
        return json.load(handle)

def read_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    try:
        return pd.read_csv(path, low_memory=False)
    except pd.errors.EmptyDataError:
        return pd.DataFrame()
status_rows: list[dict] = []
candidate_tables: list[pd.DataFrame] = []
annotation_tables: list[pd.DataFrame] = []
for dataset, clinical_group, group_dir in GROUPS:
    feasibility = load_json(group_dir / '00_QC' / 'analysis_feasibility.json')
    downstream = load_json(group_dir / '02_official_Scissor' / 'downstream_status.json')
    figure_dir = group_dir / '04_Figure4A-J'
    composite = figure_dir / 'Figure4A-J_fibroblast_subclusters_reference_style.png'
    panel_dir = figure_dir / 'individual_panels'
    cells = feasibility.get('all_fibroblast_cells', feasibility.get('fibroblast_cells'))
    row = {'dataset': dataset, 'clinical_group': clinical_group, 'folder': str(group_dir), 'fibroblast_scope': True, 'upstream_status': feasibility.get('status', 'missing'), 'fibroblast_cells': cells, 'fibroblast_subclusters': feasibility.get('clusters'), 'low_cell_clusters': ';'.join(map(str, feasibility.get('low_cell_clusters', []))) if isinstance(feasibility.get('low_cell_clusters', []), list) else feasibility.get('low_cell_clusters'), 'Scissor_status': downstream.get('status', 'not_run'), 'Vitamin_D3_positive_cells': downstream.get('Vitamin_D3_positive'), 'Vitamin_D3_negative_cells': downstream.get('Vitamin_D3_negative'), 'Background_cells': downstream.get('Background'), 'A_to_C_available': feasibility.get('status') == 'fibroblast_subclusters_completed', 'D_to_E_available': (group_dir / '02_official_Scissor' / '03_official_Scissor_cell_assignments.csv.gz').exists(), 'F_to_J_estimable': downstream.get('status') == 'completed', 'composite_png_exists': composite.exists(), 'individual_png_count': len(list(panel_dir.glob('*.png'))), 'individual_pdf_count': len(list(panel_dir.glob('*.pdf'))), 'individual_svg_count': len(list(panel_dir.glob('*.svg')))}
    status_rows.append(row)
    candidate_path = group_dir / '03_DE_enrichment_GSVA' / '03_GDF15_PLAU_RORC_statistics.csv'
    candidate = read_csv(candidate_path)
    if not candidate.empty:
        candidate.insert(0, 'clinical_group', clinical_group)
        candidate.insert(0, 'dataset', dataset)
        candidate.insert(2, 'folder', str(group_dir))
        candidate_tables.append(candidate)
    annotation_path = group_dir / '01_fibroblast_atlas' / '06_fibroblast_subtype_annotation.csv'
    annotation = read_csv(annotation_path)
    if not annotation.empty:
        annotation.insert(0, 'clinical_group', clinical_group)
        annotation.insert(0, 'dataset', dataset)
        annotation.insert(2, 'folder', str(group_dir))
        annotation_tables.append(annotation)
status = pd.DataFrame(status_rows)
status.to_csv(SUMMARY_DIR / '01_all_group_analysis_status.csv', index=False, encoding='utf-8-sig')
candidate_all = pd.concat(candidate_tables, ignore_index=True) if candidate_tables else pd.DataFrame()
candidate_all.to_csv(SUMMARY_DIR / '02_GDF15_PLAU_RORC_statistics_all_estimable_groups.csv', index=False, encoding='utf-8-sig')
annotation_all = pd.concat(annotation_tables, ignore_index=True) if annotation_tables else pd.DataFrame()
annotation_all.to_csv(SUMMARY_DIR / '03_fibroblast_subtype_annotations_all_groups.csv', index=False, encoding='utf-8-sig')
completed = status.loc[status['upstream_status'].eq('fibroblast_subclusters_completed')]
full = status.loc[status['F_to_J_estimable'].fillna(False)]
blocked = status.loc[~status['upstream_status'].eq('fibroblast_subclusters_completed')]
lines = ['# \u591a\u6570\u636e\u5e93\u7259\u9f88\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e9a\u7fa4\u5206\u6790\u7ed3\u679c\u7d22\u5f15', '', '## \u5206\u6790\u8303\u56f4', '', '\u6240\u6709 A\u2013J \u9762\u677f\u5747\u4ee5\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e3a\u5206\u6790\u6bcd\u4f53\uff1b\u56fe\u4e2d\u7684\u5206\u7c7b\u662f\u6210\u7ea4\u7ef4\u7ec6\u80de\u5185\u90e8\u4e9a\u7fa4\uff0c\u4e0d\u662f\u5185\u76ae\u3001\u514d\u75ab\u3001\u4e0a\u76ae\u7b49\u5927\u7c7b\u7ec6\u80de\u3002', '', '\u6bcf\u4e2a\u6570\u636e\u5e93\u7684\u6bcf\u4e2a\u4e34\u5e8a\u5206\u7c7b\u5747\u4f4d\u4e8e\u72ec\u7acb\u6587\u4ef6\u5939\u3002\u6bcf\u4e2a\u53ef\u4f5c\u56fe\u6587\u4ef6\u5939\u5305\u542b\uff1a', '', '- `01_fibroblast_atlas`\uff1a\u6210\u7ea4\u7ef4\u7ec6\u80de UMAP\u3001\u4e9a\u7fa4\u6bd4\u4f8b\u3001\u6807\u5fd7\u57fa\u56e0\u4e0e\u6ce8\u91ca\u6e90\u8868\uff1b', '- `02_official_Scissor`\uff1a\u5b98\u65b9 Scissor \u5206\u7c7b\u4e0e\u5ba1\u8ba1\uff1b', '- `03_DE_enrichment_GSVA`\uff1a\u5dee\u5f02\u3001GO/Reactome\u3001GSVA \u4e0e GDF15/PLAU/RORC \u7edf\u8ba1\uff1b', '- `04_Figure4A-J`\uff1aA\u2013J \u62fc\u56fe\u53ca\u5404\u9762\u677f PNG/PDF/SVG\uff1b', '- `source_data`\uff1a\u53ef\u590d\u7b97\u7684 Seurat/Scissor \u5bf9\u8c61\u3002', '', '## \u5b8c\u6210\u6982\u89c8', '', f'- \u6210\u529f\u5b8c\u6210\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e9a\u7fa4\u5206\u6790\uff1a{len(completed)} \u4e2a\u4e34\u5e8a\u7ec4\u3002', f'- Scissor \u540e F\u2013J \u53ef\u5b8c\u6574\u4f30\u8ba1\uff1a{len(full)} \u4e2a\u4e34\u5e8a\u7ec4\u3002', f'- \u56e0\u6570\u636e\u4e0d\u53ef\u5f97\u6216\u7ec6\u80de\u4e0d\u8db3\u800c\u4e0d\u53ef\u5206\u7fa4\uff1a{len(blocked)} \u4e2a\u4e34\u5e8a\u7ec4\u3002', '', '| \u6570\u636e\u5e93 | \u4e34\u5e8a\u5206\u7c7b | \u6210\u7ea4\u7ef4\u7ec6\u80de\u6570 | \u4e9a\u7fa4\u6570 | Scissor/\u4e0b\u6e38\u72b6\u6001 |', '|---|---:|---:|---:|---|']
for _, row in status.iterrows():
    cells_value = '' if pd.isna(row['fibroblast_cells']) else str(int(row['fibroblast_cells']))
    clusters_value = '' if pd.isna(row['fibroblast_subclusters']) else str(int(row['fibroblast_subclusters']))
    lines.append(f"| {row['dataset']} | {row['clinical_group']} | {cells_value} | {clusters_value} | {row['Scissor_status']} |")
lines.extend(['', '## \u5173\u952e\u9650\u5236', '', '- CNP0001395 \u5b98\u65b9\u5165\u53e3\u4ec5\u63d0\u4f9b\u9700\u7533\u8bf7\u7684\u539f\u59cb FASTQ\uff08\u9879\u76ee\u7ea6 332 GB\uff09\uff0c\u672a\u53d1\u73b0\u53ef\u76f4\u63a5\u516c\u5f00\u4e0b\u8f7d\u7684\u5904\u7406\u540e\u8868\u8fbe\u77e9\u9635\uff0c\u56e0\u6b64\u672a\u7528\u8d85\u5927\u539f\u59cb\u6570\u636e\u66ff\u4ee3\u3002', '- CELLxGENE \u9f88\u708e\u7ec4\u53ea\u6709 25 \u4e2a\u5df2\u6ce8\u91ca\u6210\u7ea4\u7ef4\u7ec6\u80de\uff0c\u4f4e\u4e8e\u9884\u8bbe\u6700\u5c0f\u503c 100\uff0c\u672a\u5f3a\u884c\u5206\u7fa4\u3002', '- Scissor \u540e Vitamin D3\u207a \u6216 Vitamin D3\u207b \u5c11\u4e8e 10 \u4e2a\u7ec6\u80de\u7684\u7ec4\uff0cF\u2013J \u6807\u4e3a\u4e0d\u53ef\u4f30\u8ba1\uff1b\u6ca1\u6709\u901a\u8fc7\u6362\u53c2\u6570\u6216\u6362\u7ec4\u5f3a\u884c\u5236\u9020\u663e\u8457\u7ed3\u679c\u3002', '- I/J \u59cb\u7ec8\u53ea\u5c55\u793a GDF15\u3001PLAU\u3001RORC\uff1b\u7edf\u8ba1\u663e\u8457\u6027\u4e0e\u8868\u8fbe\u5206\u5e03\u6309\u89c2\u6d4b\u6570\u636e\u5448\u73b0\u3002', '', '\u8be6\u7ec6\u673a\u5668\u53ef\u8bfb\u72b6\u6001\u89c1 `summary/01_all_group_analysis_status.csv`\u3002'])
(ROOT / 'README_\u7ed3\u679c\u7d22\u5f15.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
methods = '# \u65b9\u6cd5\u4e0e\u5224\u5b9a\u8bf4\u660e\n\n## \u5206\u6790\u5bf9\u8c61\n\n\u6bcf\u4e2a\u6570\u636e\u5e93\u5148\u6309\u4e34\u5e8a\u5206\u7c7b\u72ec\u7acb\u5904\u7406\uff0c\u518d\u4ece\u8be5\u5206\u7c7b\u7684\u5168\u90e8\u7ec6\u80de\u4e2d\u901a\u8fc7\u6210\u7ea4\u7ef4\u7ec6\u80de\u8c31\u7cfb\u6a21\u5757\uff08COL1A1/COL1A2/COL3A1/DCN/LUM/PDGFRA \u7b49\uff09\u63d0\u53d6\u6210\u7ea4\u7ef4\u7ec6\u80de\u3002\u540e\u7eed\u6240\u6709\u805a\u7c7b\u4e0e A\u2013J \u56fe\u5747\u4ec5\u5728\u6210\u7ea4\u7ef4\u7ec6\u80de\u5185\u90e8\u8fdb\u884c\u3002\n\n## \u6210\u7ea4\u7ef4\u7ec6\u80de\u4e9a\u7fa4\n\n- Seurat \u6807\u51c6\u5316\u4e0e\u9ad8\u53d8\u57fa\u56e0\uff1b\n- PCA\uff1b\n- \u90bb\u63a5\u56fe\uff1b\n- FindClusters\uff08Louvain\uff0c\u6309\u7ec6\u80de\u91cf\u9884\u8bbe\u5206\u8fa8\u7387 0.2\u20130.5\uff09\uff1b\n- UMAP\uff1b\n- FindAllMarkers\uff1b\n- \u4f9d\u636e\u8de8\u4e9a\u7fa4\u6807\u51c6\u5316\u7684\u6210\u7ea4\u7ef4\u7ec6\u80de\u72b6\u6001\u6a21\u5757\u4e0e\u6807\u5fd7\u57fa\u56e0\uff0c\u5bf9\u4e9a\u7fa4\u6807\u6ce8\u4e3a\u57fa\u8d28\u7a33\u6001\u3001\u708e\u75c7 CXCL\u3001\u514d\u75ab\u8c03\u8282\u3001ECM \u91cd\u5851\u3001\u5468\u8840\u7ba1/\u5916\u819c\u3001\u808c\u6210\u7ea4\u7ef4\u3001\u6210\u9aa8/MSC\u3001\u589e\u6b96\u6216 GDF15 \u5e94\u6fc0\u7b49\u72b6\u6001\u3002\n\n\u4e9a\u7fa4\u540d\u79f0\u5305\u542b `FB\u7f16\u53f7`\uff0c\u5373\u4f7f\u4e24\u4e2a\u4e9a\u7fa4\u5171\u4eab\u540c\u4e00\u4e3b\u8981\u72b6\u6001\u6807\u7b7e\uff0c\u4e5f\u4fdd\u7559\u4e3a\u4e0d\u540c\u805a\u7c7b\u3002\u5c11\u4e8e 40 \u4e2a\u7ec6\u80de\u7684\u4e9a\u7fa4\u6807\u6ce8\u4e3a low-cell\uff1b\u5c11\u4e8e 100 \u4e2a\u6210\u7ea4\u7ef4\u7ec6\u80de\u7684\u4e34\u5e8a\u7ec4\u4e0d\u8fdb\u884c\u5206\u7fa4\u3002\n\n## Scissor \u4e0e\u4e0b\u6e38\u5206\u6790\n\n- Bulk\uff1aGSE212728\uff0cVitamin D3=1\uff0c\u4e59\u9187\u5bf9\u7167=0\uff1b\n- \u5355\u7ec6\u80de\uff1a\u6bcf\u4e00\u6570\u636e\u5e93\xd7\u4e34\u5e8a\u5206\u7c7b\u7684\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e9a\u7fa4\u5bf9\u8c61\uff0c\u6309\u4f9b\u8005/\u4e9a\u7fa4\u5206\u5c42\u62bd\u6837\uff0c\u4e0a\u9650 3,000 \u4e2a\u7ec6\u80de\uff1b\n- \u5b98\u65b9 Scissor 2.0.0\uff0cbinomial\uff0ccutoff=0.20\uff1b\n- Scissor \u540e\u6bcf\u7ec4\u81f3\u5c11 10 \u4e2a Vitamin D3\u207a \u548c 10 \u4e2a Vitamin D3\u207b \u7ec6\u80de\u624d\u4f30\u8ba1 F\u2013J\uff1b\n- DEG\uff1a\u53cc\u4fa7 Wilcoxon\uff0c\u539f\u59cb P<0.05 \u4e14 |fold change|\u22651.2\uff1b\n- GO-BP/CC/MF \u4e0e Reactome\uff1aclusterProfiler::enricher\uff1b\n- GSVA\uff1aMSigDB Hallmark\uff1b\n- I/J\uff1a\u53ea\u5c55\u793a GDF15\u3001PLAU\u3001RORC\u3002\n\n\u6ca1\u6709\u989d\u5916 alpha \u654f\u611f\u6027\u5206\u6790\u3001bootstrap\u3001\u7559\u4e00\u6cd5\u3001\u591a\u968f\u673a\u79cd\u5b50\u3001UCell/AUCell\u3001\u5019\u9009\u57fa\u56e0\u5220\u9664\u91cd\u8dd1\u6216 pseudobulk \u4e3b\u56fe\u5206\u6790\uff0c\u4e5f\u6ca1\u6709\u4e3a\u83b7\u5f97\u76ee\u6807\u9633\u6027\u800c\u91cd\u5206\u7ec4\u3002\n'
(METHOD_DIR / '\u65b9\u6cd5\u4e0e\u5224\u5b9a\u8bf4\u660e.md').write_text(methods, encoding='utf-8')
print(ROOT)
