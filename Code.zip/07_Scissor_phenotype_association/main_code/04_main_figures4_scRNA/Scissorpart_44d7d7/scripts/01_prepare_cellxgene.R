script_dir <- dirname(normalizePath(
  sub("^--file=", "", grep("^--file=", commandArgs(), value = TRUE)[1]),
  winslash = "/",
  mustWork = TRUE
))
source(file.path(script_dir, "00_common.R"), encoding = "UTF-8")
suppressPackageStartupMessages(library(rhdf5))

h5_path <- file.path(
  RAW_ROOT,
  "CELLxGENE_Integrated_Periodontitis_Atlas",
  "processed",
  "Integrated_Human_Periodontitis_Atlas_105918cells.h5ad"
)
if (!file.exists(h5_path)) {
  stop("CELLxGENE h5ad is missing: ", h5_path)
}

read_categorical <- function(name) {
  categories <- h5read(
    h5_path,
    paste0("/obs/", name, "/categories")
  )
  codes <- h5read(
    h5_path,
    paste0("/obs/", name, "/codes")
  )
  ifelse(codes < 0L, NA_character_, categories[codes + 1L])
}

obs <- data.table(
  cell = h5read(h5_path, "/obs/_index"),
  annotated_cell_set = read_categorical("Annotated Cell Sets"),
  cell_type = read_categorical("cell_type"),
  disease = read_categorical("disease"),
  donor_id = read_categorical("donor_id"),
  sample_id = read_categorical("Sample ID"),
  study = read_categorical("Study"),
  source_GSE = read_categorical("GSE")
)

fibro_rows <- which(tolower(obs$cell_type) == "fibroblast")
if (length(fibro_rows) != 17533L) {
  stop("Unexpected number of curated CELLxGENE fibroblasts: ", length(fibro_rows))
}

feature_categories <- h5read(
  h5_path,
  "/raw/var/feature_name/categories"
)
feature_codes <- h5read(
  h5_path,
  "/raw/var/feature_name/codes"
)
feature_names <- ifelse(
  feature_codes < 0L,
  h5read(h5_path, "/raw/var/_index"),
  feature_categories[feature_codes + 1L]
)
feature_names <- make.unique(feature_names)
indptr <- h5read(h5_path, "/raw/X/indptr")
shape <- h5readAttributes(h5_path, "/raw/X")$shape
if (!identical(as.integer(shape), c(nrow(obs), length(feature_names)))) {
  stop("CELLxGENE sparse-matrix dimensions do not match obs/var.")
}

extract_csr_rows <- function(row_indices, merge_gap = 300L) {
  row_indices <- sort(unique(as.integer(row_indices)))
  if (!length(row_indices)) {
    return(Matrix(0, nrow = length(feature_names), ncol = 0, sparse = TRUE))
  }
  split_id <- cumsum(c(TRUE, diff(row_indices) > merge_gap))
  blocks <- split(row_indices, split_id)
  i_all <- vector("list", length(blocks))
  j_all <- vector("list", length(blocks))
  x_all <- vector("list", length(blocks))
  selected_position <- setNames(seq_along(row_indices), row_indices)

  for (block_index in seq_along(blocks)) {
    selected_rows <- blocks[[block_index]]
    block_start <- min(selected_rows)
    block_end <- max(selected_rows)
    data_start <- indptr[block_start] + 1L
    data_end <- indptr[block_end + 1L]
    if (data_end < data_start) {
      next
    }
    block_data <- h5read(
      h5_path,
      "/raw/X/data",
      start = data_start,
      count = data_end - data_start + 1L
    )
    block_indices <- h5read(
      h5_path,
      "/raw/X/indices",
      start = data_start,
      count = data_end - data_start + 1L
    )
    i_part <- vector("list", length(selected_rows))
    j_part <- vector("list", length(selected_rows))
    x_part <- vector("list", length(selected_rows))
    for (local_row_index in seq_along(selected_rows)) {
      row_id <- selected_rows[[local_row_index]]
      row_start <- indptr[row_id] + 1L
      row_end <- indptr[row_id + 1L]
      if (row_end < row_start) {
        next
      }
      local <- (row_start:row_end) - data_start + 1L
      i_part[[local_row_index]] <- block_indices[local] + 1L
      j_part[[local_row_index]] <- rep.int(
        selected_position[[as.character(row_id)]],
        length(local)
      )
      x_part[[local_row_index]] <- block_data[local]
    }
    i_all[[block_index]] <- unlist(i_part, use.names = FALSE)
    j_all[[block_index]] <- unlist(j_part, use.names = FALSE)
    x_all[[block_index]] <- unlist(x_part, use.names = FALSE)
    message(
      "CELLxGENE block ", block_index, "/", length(blocks),
      ": rows ", block_start, "-", block_end
    )
  }
  sparseMatrix(
    i = unlist(i_all, use.names = FALSE),
    j = unlist(j_all, use.names = FALSE),
    x = unlist(x_all, use.names = FALSE),
    dims = c(length(feature_names), length(row_indices)),
    dimnames = list(feature_names, obs$cell[row_indices]),
    giveCsparse = TRUE
  )
}

fibro_log <- extract_csr_rows(fibro_rows)
fibro_obs <- copy(obs[fibro_rows])
fibro_obs[, clinical_group := fifelse(
  disease == "normal",
  "Healthy",
  fifelse(disease == "gingivitis", "Gingivitis", "Periodontitis")
)]

global_qc <- fibro_obs[
  ,
  .N,
  by = .(
    clinical_group, disease, annotated_cell_set,
    study, source_GSE
  )
][order(clinical_group, -N)]
safe_write_csv(
  global_qc,
  file.path(
    OUTPUT_ROOT,
    "04_CELLxGENE",
    "CELLxGENE_fibroblast_inventory.csv"
  )
)

for (group_key in c("Healthy", "Gingivitis", "Periodontitis")) {
  cells <- fibro_obs[clinical_group == group_key, cell]
  selected <- match(cells, colnames(fibro_log))
  selected <- selected[!is.na(selected)]
  matrix_group <- fibro_log[, selected, drop = FALSE]
  metadata <- as.data.frame(fibro_obs[match(colnames(matrix_group), cell)])
  rownames(metadata) <- metadata$cell
  object <- CreateSeuratObject(
    counts = matrix_group,
    meta.data = metadata,
    project = paste0("CELLxGENE_", group_key),
    min.cells = 0,
    min.features = 0
  )
  object[["RNA"]] <- SetAssayData(
    object[["RNA"]],
    layer = "data",
    new.data = matrix_group
  )
  object$dataset <- "CELLxGENE"
  object$sample_id <- as.character(object$sample_id)
  object$donor_id <- as.character(object$donor_id)
  object$clinical_group <- group_key
  object$source_annotation <- as.character(object$annotated_cell_set)

  qc <- data.table(
    dataset = "CELLxGENE",
    clinical_group = group_key,
    fibroblast_cells = ncol(object),
    donors = uniqueN(object$donor_id),
    samples = uniqueN(object$sample_id),
    source_value_type = "CELLxGENE log-normalized expression",
    source_fibroblast_labels = paste(
      sort(unique(object$source_annotation)),
      collapse = ";"
    )
  )
  safe_write_csv(
    qc,
    file.path(group_dir("CELLxGENE", group_key), "00_QC", "sample_QC.csv")
  )
  cluster_fibroblast_group(
    object = object,
    dataset = "CELLxGENE",
    group_key = group_key,
    source_value_type = "CELLxGENE log-normalized expression",
    renormalize = FALSE
  )
  rm(object, matrix_group)
  gc()
}

safe_write_json(
  list(
    dataset = "CELLxGENE Integrated Periodontitis Atlas",
    total_cells = nrow(obs),
    curated_fibroblasts = length(fibro_rows),
    source_labels = sort(unique(fibro_obs$annotated_cell_set)),
    conditions = as.list(table(fibro_obs$clinical_group)),
    note = paste(
      "Gingivitis contains only 25 curated fibroblasts and therefore",
      "does not meet the prespecified minimum for subclustering."
    )
  ),
  file.path(
    OUTPUT_ROOT,
    "04_CELLxGENE",
    "CELLxGENE_source_audit.json"
  )
)
