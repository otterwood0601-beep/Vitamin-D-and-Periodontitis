script_dir <- dirname(normalizePath(
  sub("^--file=", "", grep("^--file=", commandArgs(), value = TRUE)[1]),
  winslash = "/",
  mustWork = TRUE
))
source(file.path(script_dir, "00_common.R"), encoding = "UTF-8")

metadata_dir <- file.path(RAW_ROOT, "CNP0001395", "metadata")
sample_path <- file.path(
  metadata_dir,
  "metadata_CNP0001395_sample_Human_sample.tsv"
)
experiment_path <- file.path(
  metadata_dir,
  "metadata_CNP0001395_experiment.tsv"
)
if (!all(file.exists(c(sample_path, experiment_path)))) {
  stop("CNP0001395 metadata files are missing.")
}
samples <- fread(sample_path)
experiments <- fread(experiment_path)
samples[
  ,
  clinical_group := fifelse(
    grepl("Healthy", sample_title, ignore.case = TRUE),
    "Healthy",
    "Periodontitis"
  )
]

safe_write_csv(
  samples,
  file.path(OUTPUT_ROOT, "03_CNP0001395", "CNP0001395_sample_manifest.csv")
)
safe_write_csv(
  experiments,
  file.path(OUTPUT_ROOT, "03_CNP0001395", "CNP0001395_run_manifest.csv.gz")
)

for (group_key in c("Healthy", "Periodontitis")) {
  out <- group_dir("CNP0001395", group_key)
  group_samples <- samples[clinical_group == group_key]
  audit <- list(
    dataset = "CNP0001395",
    clinical_group = group_key,
    status = "blocked_by_controlled_raw_data",
    samples = group_samples$sample_name,
    donors = nrow(group_samples),
    official_project_cells_after_QC = 29967,
    official_project_raw_size_GB = 332.45,
    public_files_found = "metadata only",
    official_access = "Apply for data",
    processed_count_matrix_found_locally = FALSE,
    action_taken = paste(
      "Downloaded the four small official metadata tables.",
      "Did not download 332.45 GB of raw FASTQ because access is controlled",
      "and a processed gene-count matrix is not publicly exposed."
    ),
    analysis_requirement = paste(
      "A Cell Ranger/Seurat processed matrix for Nor1, Nor2, P1 and P2",
      "or approved CNGB access is required before A-J can be computed."
    )
  )
  safe_write_json(audit, file.path(out, "00_QC", "analysis_feasibility.json"))
  safe_write_csv(
    group_samples,
    file.path(out, "00_QC", "sample_manifest.csv")
  )
}
