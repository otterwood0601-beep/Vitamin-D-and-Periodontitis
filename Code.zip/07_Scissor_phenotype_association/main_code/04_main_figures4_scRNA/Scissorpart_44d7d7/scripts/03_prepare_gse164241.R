script_dir <- dirname(normalizePath(
  sub("^--file=", "", grep("^--file=", commandArgs(), value = TRUE)[1]),
  winslash = "/",
  mustWork = TRUE
))
source(file.path(script_dir, "00_common.R"), encoding = "UTF-8")

dataset_root <- file.path(RAW_ROOT, "GSE164241")
raw_dir <- file.path(dataset_root, "raw_supplement")
metadata <- fread(file.path(
  dataset_root,
  "metadata",
  "GSE164241_GEO_sample_metadata.tsv"
))
metadata <- metadata[
  inferred_group %in% c("Healthy gingiva", "Periodontitis gingiva")
]
metadata[
  ,
  clinical_group := fifelse(
    inferred_group == "Healthy gingiva",
    "Healthy",
    fifelse(title == "ID080UST", "LAD1_periodontitis", "Periodontitis")
  )
]
metadata[
  ,
  donor_id := fifelse(
    title == "ID080UST",
    title,
    sub("[a-z]+$", "", title)
  )
]

objects_by_group <- setNames(
  vector("list", 3L),
  c("Healthy", "Periodontitis", "LAD1_periodontitis")
)
qc_rows <- list()

for (index in seq_len(nrow(metadata))) {
  row <- metadata[index]
  prefix <- file.path(raw_dir, paste0(row$geo_accession, "_", row$title))
  matrix_file <- paste0(prefix, "_matrix.mtx.gz")
  barcode_file <- paste0(prefix, "_barcodes.tsv.gz")
  feature_file <- paste0(prefix, "_features.tsv.gz")
  if (!file.exists(feature_file)) {
    feature_file <- paste0(prefix, "_genes.tsv.gz")
  }
  if (!all(file.exists(c(matrix_file, barcode_file, feature_file)))) {
    stop("Incomplete 10X triplet for ", row$geo_accession, " ", row$title)
  }
  message("Reading ", row$geo_accession, " / ", row$title)
  counts <- ReadMtx(
    mtx = matrix_file,
    cells = barcode_file,
    features = feature_file,
    feature.column = 2,
    cell.column = 1,
    unique.features = TRUE,
    strip.suffix = FALSE
  )
  result <- qc_and_extract_fibroblast(
    counts = counts,
    sample_id = row$title,
    donor_id = row$donor_id,
    clinical_group = row$clinical_group,
    dataset = "GSE164241"
  )
  objects_by_group[[row$clinical_group]] <- c(
    objects_by_group[[row$clinical_group]],
    list(result$object)
  )
  qc_rows[[length(qc_rows) + 1L]] <- result$qc
  rm(counts, result)
  gc()
}

qc_all <- rbindlist(qc_rows, fill = TRUE)
safe_write_csv(
  qc_all,
  file.path(OUTPUT_ROOT, "01_GSE164241", "GSE164241_gingiva_sample_QC.csv")
)

for (group_key in names(objects_by_group)) {
  object <- merge_fibroblast_objects(objects_by_group[[group_key]])
  safe_write_csv(
    qc_all[clinical_group == group_key],
    file.path(group_dir("GSE164241", group_key), "00_QC", "sample_QC.csv")
  )
  cluster_fibroblast_group(
    object = object,
    dataset = "GSE164241",
    group_key = group_key,
    source_value_type = "Cell Ranger filtered UMI counts",
    renormalize = TRUE
  )
  rm(object)
  gc()
}
