from __future__ import annotations
import argparse
import json
import math
import re
import textwrap
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import gridspec
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle
import numpy as np
import pandas as pd
BLUE = '#2B6CB0'
SALMON = '#EF8178'
GREY = '#D9D9D9'
DARK_GREY = '#555555'
FOLD_CUTOFF = math.log2(1.2)
CANDIDATES = ['GDF15', 'PLAU', 'RORC']
SUBTYPE_COLORS = ['#0B78B2', '#D95F02', '#00A087', '#F0E442', '#56B4E9', '#CC79A7', '#E69F00', '#5E3C99', '#8C564B', '#8C8C8C', '#222222', '#6A994E']
plt.rcParams.update({'font.family': 'Arial', 'font.size': 8, 'axes.titlesize': 9, 'axes.labelsize': 8, 'xtick.labelsize': 7, 'ytick.labelsize': 7, 'legend.fontsize': 7, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'axes.spines.top': False, 'axes.spines.right': False})

def read_table(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    try:
        return pd.read_csv(path, low_memory=False)
    except pd.errors.EmptyDataError:
        return pd.DataFrame()

def panel_letter(ax: plt.Axes, letter: str, x: float=-0.12) -> None:
    ax.text(x, 1.06, letter, transform=ax.transAxes, fontsize=23, fontweight='normal', va='top', ha='left')

def clean_term(term: object, width: int=28) -> str:
    value = str(term)
    value = re.sub('\\s*\\(GO:\\d+\\)\\s*', ' ', value)
    value = re.sub('^GO:\\d+\\s*[:\\-]?\\s*', '', value)
    value = value.replace('_', ' ')
    value = re.sub('\\s+', ' ', value).strip()
    return '\n'.join(textwrap.wrap(value, width=width))

def p_label(value: float) -> str:
    if not np.isfinite(value):
        return 'NA'
    if value < 0.0001:
        return '****'
    if value < 0.001:
        return '***'
    if value < 0.01:
        return '**'
    if value < 0.05:
        return '*'
    return 'ns'

def save_figure(fig: plt.Figure, stem: Path, dpi: int=500) -> None:
    stem.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(stem.with_suffix('.png'), dpi=dpi, bbox_inches='tight')
    fig.savefig(stem.with_suffix('.pdf'), bbox_inches='tight')
    fig.savefig(stem.with_suffix('.svg'), bbox_inches='tight')

def placeholder(ax: plt.Axes, letter: str, message: str) -> None:
    ax.text(0.5, 0.5, '\n'.join(textwrap.wrap(message, 42)), ha='center', va='center', color=DARK_GREY, transform=ax.transAxes)
    ax.set_xticks([])
    ax.set_yticks([])
    panel_letter(ax, letter)

class Figure4Builder:

    def __init__(self, group_dir: Path):
        self.group_dir = group_dir.resolve()
        self.atlas = self.group_dir / '01_fibroblast_atlas'
        self.scissor = self.group_dir / '02_official_Scissor'
        self.analysis = self.group_dir / '03_DE_enrichment_GSVA'
        self.output = self.group_dir / '04_Figure4A-J'
        self.panels = self.output / 'individual_panels'
        self.output.mkdir(parents=True, exist_ok=True)
        self.panels.mkdir(parents=True, exist_ok=True)
        self.umap = read_table(self.atlas / '01_fibroblast_UMAP_metadata.csv.gz')
        self.counts = read_table(self.atlas / '02_fibroblast_subtype_counts.csv')
        self.dot = read_table(self.atlas / '03_fibroblast_marker_DotPlot_source.csv')
        self.assign = read_table(self.scissor / '03_official_Scissor_cell_assignments.csv.gz')
        self.state_by_subtype = read_table(self.scissor / '05_Scissor_state_by_fibroblast_subtype.csv')
        self.de = read_table(self.analysis / '01_VitaminD3_positive_vs_negative_DE.csv.gz')
        self.enrichment = read_table(self.analysis / '04_GO_Reactome_enrichment_all.csv.gz')
        self.gsva = read_table(self.analysis / '06_Hallmark_GSVA_heatmap_source.csv.gz')
        self.candidate_expression = read_table(self.analysis / '02_GDF15_PLAU_RORC_cell_expression.csv.gz')
        self.candidate_stats = read_table(self.analysis / '03_GDF15_PLAU_RORC_statistics.csv')
        self.subtypes = self._subtype_order()
        self.palette = {subtype: SUBTYPE_COLORS[index % len(SUBTYPE_COLORS)] for index, subtype in enumerate(self.subtypes)}

    def _subtype_order(self) -> list[str]:
        if not self.counts.empty and 'fibroblast_subtype' in self.counts:
            return self.counts['fibroblast_subtype'].astype(str).tolist()
        if not self.umap.empty and 'fibroblast_subtype' in self.umap:
            return list(dict.fromkeys(self.umap['fibroblast_subtype'].dropna().astype(str)))
        return []

    def panel_a(self, ax: plt.Axes) -> None:
        if self.umap.empty:
            placeholder(ax, 'A', 'Fibroblast-subcluster UMAP unavailable')
            return
        for subtype in self.subtypes:
            subset = self.umap.loc[self.umap['fibroblast_subtype'].astype(str) == subtype]
            ax.scatter(subset['UMAP_1'], subset['UMAP_2'], s=1.2, color=self.palette[subtype], linewidths=0, rasterized=True)
            if len(subset) >= 15:
                ax.text(subset['UMAP_1'].median(), subset['UMAP_2'].median(), subtype, fontsize=5.5, ha='center', va='center', bbox={'facecolor': 'white', 'edgecolor': 'none', 'alpha': 0.65, 'pad': 0.4})
        ax.set_xlabel('UMAP 1')
        ax.set_ylabel('UMAP 2')
        ax.grid(False)
        panel_letter(ax, 'A')

    def panel_b(self, ax: plt.Axes, compact: bool=False) -> None:
        if self.counts.empty:
            placeholder(ax, 'B', 'Fibroblast-subcluster proportions unavailable')
            return
        values = self.counts.copy()
        values['proportion'] = pd.to_numeric(values['proportion'], errors='coerce')
        left = 0.0
        for _, row in values.iterrows():
            subtype = str(row['fibroblast_subtype'])
            width = float(row['proportion']) * 100
            ax.barh([0], [width], left=left, height=0.42, color=self.palette.get(subtype, GREY), edgecolor='white', linewidth=0.5)
            if width >= 5:
                ax.text(left + width / 2, 0, f'{width:.1f}%', ha='center', va='center', color='white' if width > 7 else 'black', fontsize=5.5, fontweight='bold')
            left += width
        ax.set_xlim(0, 100)
        ax.set_yticks([0])
        ax.set_yticklabels(['Fibroblasts'])
        ax.set_xlabel('Proportion of fibroblast cells (%)')
        if not compact:
            handles = [Patch(color=self.palette[subtype], label=subtype) for subtype in self.subtypes]
            ax.legend(handles=handles, loc='upper center', bbox_to_anchor=(0.5, -0.26), ncol=min(3, max(1, len(handles))), frameon=False, fontsize=5.0)
        ax.grid(axis='x', color='#E8E8E8', linewidth=0.5)
        ax.grid(axis='y', visible=False)
        panel_letter(ax, 'B', x=-0.16)

    def panel_c(self, ax: plt.Axes, compact: bool=False) -> None:
        if self.dot.empty:
            placeholder(ax, 'C', 'Fibroblast-subcluster marker DotPlot unavailable')
            return
        data = self.dot.copy()
        features = list(dict.fromkeys(data['feature'].astype(str)))
        data = data.loc[data['fibroblast_subtype'].astype(str).isin(self.subtypes)]
        data['feature'] = pd.Categorical(data['feature'].astype(str), categories=features, ordered=True)
        data['fibroblast_subtype'] = pd.Categorical(data['fibroblast_subtype'].astype(str), categories=self.subtypes[::-1], ordered=True)
        data['average_expression'] = pd.to_numeric(data['average_expression'], errors='coerce')
        data['percent_expressed'] = pd.to_numeric(data['percent_expressed'], errors='coerce').fillna(0)
        data['scaled_average'] = data.groupby('feature', observed=True)['average_expression'].transform(lambda values: (values - values.mean()) / values.std() if values.notna().sum() > 1 and values.std() > 0 else values * 0)
        scatter = ax.scatter(data['feature'].cat.codes, data['fibroblast_subtype'].cat.codes, s=4 + data['percent_expressed'] * 0.72, c=data['scaled_average'], cmap='coolwarm', vmin=-2, vmax=2, linewidths=0)
        ax.set_xticks(range(len(features)))
        ax.set_xticklabels(features, rotation=90, fontsize=4.9)
        ax.set_yticks(range(len(self.subtypes)))
        ax.set_yticklabels(self.subtypes[::-1], fontsize=5.1)
        ax.set_xlim(-0.8, max(0.2, len(features) - 0.2))
        ax.set_ylim(-0.8, max(0.2, len(self.subtypes) - 0.2))
        ax.grid(False)
        colorbar = plt.colorbar(scatter, ax=ax, fraction=0.018, pad=0.012)
        colorbar.set_label('Scaled average expression', fontsize=6)
        if not compact:
            size_handles = [Line2D([], [], marker='o', linestyle='', markersize=math.sqrt(4 + value * 0.72), color='#555555', label=f'{value}%') for value in (25, 50, 75)]
            ax.legend(handles=size_handles, title='Percent expressed', loc='upper left', bbox_to_anchor=(1.02, 0.55), frameon=False, fontsize=5, title_fontsize=5.5)
        panel_letter(ax, 'C', x=-0.06)

    def panel_d(self, ax: plt.Axes) -> None:
        if self.assign.empty:
            placeholder(ax, 'D', 'Official Scissor output not estimable')
            return
        background = self.assign.loc[self.assign['Scissor_state'].astype(str) == 'Background']
        ax.scatter(background['UMAP_1'], background['UMAP_2'], s=0.8, color='#E1E1E1', linewidths=0, rasterized=True, label='Background')
        for state, color in (('Vitamin D3-', BLUE), ('Vitamin D3+', SALMON)):
            subset = self.assign.loc[self.assign['Scissor_state'].astype(str) == state]
            ax.scatter(subset['UMAP_1'], subset['UMAP_2'], s=2.2, color=color, linewidths=0, rasterized=True, label=state)
        ax.set_xlabel('UMAP 1')
        ax.set_ylabel('UMAP 2')
        ax.grid(False)
        ax.legend(frameon=False, markerscale=3, fontsize=6)
        panel_letter(ax, 'D')

    def panel_e(self, ax: plt.Axes) -> None:
        if self.state_by_subtype.empty:
            placeholder(ax, 'E', 'Scissor-state proportions unavailable')
            return
        data = self.state_by_subtype.loc[self.state_by_subtype['Scissor_state'].astype(str).isin(['Vitamin D3-', 'Vitamin D3+'])].copy()
        wide = data.pivot_table(index='fibroblast_subtype', columns='Scissor_state', values='N', aggfunc='sum', fill_value=0)
        for column in ('Vitamin D3-', 'Vitamin D3+'):
            if column not in wide:
                wide[column] = 0
        wide = wide.reindex([x for x in self.subtypes if x in wide.index])
        wide = wide.loc[wide.sum(axis=1) > 0]
        if wide.empty:
            placeholder(ax, 'E', 'No Scissor-selected fibroblasts')
            return
        proportions = wide.div(wide.sum(axis=1), axis=0) * 100
        y = np.arange(len(proportions))
        ax.barh(y, proportions['Vitamin D3+'], color=SALMON, label='Vitamin D3+')
        ax.barh(y, proportions['Vitamin D3-'], left=proportions['Vitamin D3+'], color=BLUE, label='Vitamin D3-')
        for index, (_, row) in enumerate(proportions.iterrows()):
            if row['Vitamin D3+'] >= 8:
                ax.text(row['Vitamin D3+'] / 2, index, f"{row['Vitamin D3+']:.1f}%", ha='center', va='center', fontsize=5)
            if row['Vitamin D3-'] >= 8:
                ax.text(row['Vitamin D3+'] + row['Vitamin D3-'] / 2, index, f"{row['Vitamin D3-']:.1f}%", ha='center', va='center', fontsize=5, color='white')
        ax.set_yticks(y)
        ax.set_yticklabels(proportions.index, fontsize=5.5)
        ax.set_xlim(0, 100)
        ax.set_xlabel('Percentage of Scissor-selected fibroblasts')
        ax.set_ylabel('Fibroblast subtype')
        ax.legend(frameon=False, loc='lower right')
        ax.grid(axis='x', color='#E8E8E8', linewidth=0.5)
        ax.grid(axis='y', visible=False)
        panel_letter(ax, 'E')

    def panel_f(self, ax: plt.Axes) -> None:
        if self.de.empty:
            placeholder(ax, 'F', 'Vitamin D3+ versus Vitamin D3- DE unavailable')
            return
        data = self.de.copy()
        data['avg_log2FC'] = pd.to_numeric(data['avg_log2FC'], errors='coerce')
        data['p_val'] = pd.to_numeric(data['p_val'], errors='coerce')
        data['minus_log10_p'] = -np.log10(data['p_val'].clip(lower=1e-300))
        direction = data['direction'].astype(str)
        neutral = direction == 'Not reference-threshold DEG'
        down = direction == 'Higher in Vitamin D3-'
        up = direction == 'Higher in Vitamin D3+'
        ax.scatter(data.loc[neutral, 'avg_log2FC'], data.loc[neutral, 'minus_log10_p'], s=3.0, color='#D5D5D5', linewidths=0, alpha=0.65, rasterized=True)
        ax.scatter(data.loc[down, 'avg_log2FC'], data.loc[down, 'minus_log10_p'], s=5.0, color=BLUE, linewidths=0, alpha=0.78, rasterized=True, label='Higher in Vitamin D3-')
        ax.scatter(data.loc[up, 'avg_log2FC'], data.loc[up, 'minus_log10_p'], s=5.0, color=SALMON, linewidths=0, alpha=0.78, rasterized=True, label='Higher in Vitamin D3+')
        ax.axhline(-math.log10(0.05), color='#777777', ls='--', lw=0.7)
        ax.axvline(FOLD_CUTOFF, color='#777777', ls='--', lw=0.7)
        ax.axvline(-FOLD_CUTOFF, color='#777777', ls='--', lw=0.7)
        label_rows = []
        significant = data.loc[up | down].nsmallest(12, 'p_val')
        label_rows.extend(significant.index.tolist())
        gene_column = 'gene' if 'gene' in data else 'gene_symbol'
        for gene in CANDIDATES:
            hit = data.index[data[gene_column].astype(str).str.upper() == gene]
            if len(hit):
                label_rows.append(hit[0])
        for row_index in dict.fromkeys(label_rows):
            row = data.loc[row_index]
            ax.text(row['avg_log2FC'], row['minus_log10_p'], str(row[gene_column]), fontsize=4.8)
        ax.set_xlabel('$\\log_2$ fold change (Vitamin D3+ / Vitamin D3-)')
        ax.set_ylabel('$-\\log_{10}$ raw P')
        ax.legend(frameon=False, fontsize=5.5, loc='lower center', bbox_to_anchor=(0.5, -0.31), ncol=2)
        panel_letter(ax, 'F')

    def panel_g(self, ax: plt.Axes) -> None:
        if self.enrichment.empty:
            placeholder(ax, 'G', 'No estimable GO enrichment table')
            return
        data = self.enrichment.loc[self.enrichment['ontology'].isin(['GO-BP', 'GO-CC', 'GO-MF'])].copy()
        if data.empty:
            placeholder(ax, 'G', 'No estimable GO BP/CC/MF terms')
            return
        data['p.adjust'] = pd.to_numeric(data['p.adjust'], errors='coerce')
        data['pvalue'] = pd.to_numeric(data['pvalue'], errors='coerce')
        selected_parts = []
        for (ontology, direction), part in data.groupby(['ontology', 'direction'], observed=True):
            significant = part.loc[part['p.adjust'] < 0.05]
            use = significant if not significant.empty else part
            selected_parts.append(use.sort_values(['p.adjust', 'pvalue']).head(3))
        selected = pd.concat(selected_parts, ignore_index=True)
        selected = selected.sort_values(['ontology', 'direction', 'p.adjust', 'pvalue'], ascending=[False, True, False, False]).reset_index(drop=True)
        selected['score'] = -np.log10(selected['p.adjust'].clip(lower=1e-300))
        selected['label'] = selected['Description'].map(lambda value: clean_term(value, 24))
        colors = selected['direction'].map({'Higher in Vitamin D3+': SALMON, 'Higher in Vitamin D3-': BLUE}).fillna(GREY)
        y = np.arange(len(selected))
        ax.barh(y, selected['score'], color=colors)
        ax.set_yticks(y)
        ax.set_yticklabels(selected['label'], fontsize=4.7)
        ax.set_xlabel('$-\\log_{10}$(FDR q-value)')
        ax.axvline(-math.log10(0.05), color='#777777', ls='--', lw=0.6)
        previous = None
        for index, row in selected.iterrows():
            if previous is not None and row['ontology'] != previous:
                ax.axhline(index - 0.5, color='#AAAAAA', lw=0.6)
            if row['p.adjust'] < 0.05:
                ax.text(row['score'] + max(selected['score'].max() * 0.01, 0.03), index, '*', va='center', fontsize=6)
            previous = row['ontology']
        handles = [Patch(color=BLUE, label='Vitamin D3-'), Patch(color=SALMON, label='Vitamin D3+')]
        ax.legend(handles=handles, title='Group', loc='lower center', bbox_to_anchor=(0.5, 1.01), frameon=False, ncol=2, fontsize=5.5, title_fontsize=5.5)
        panel_letter(ax, 'G')

    def panel_h(self, ax: plt.Axes) -> None:
        if self.gsva.empty:
            placeholder(ax, 'H', 'Hallmark GSVA heatmap unavailable')
            return
        data = self.gsva.copy()
        data['GSVA_score'] = pd.to_numeric(data['GSVA_score'], errors='coerce')
        pathway_order = list(dict.fromkeys(data['clean_pathway'].astype(str)))
        state_order = {'Vitamin D3-': 0, 'Vitamin D3+': 1}
        cell_meta = data[['cell', 'Scissor_state']].drop_duplicates().assign(state_order=lambda frame: frame['Scissor_state'].map(state_order).fillna(2)).sort_values(['state_order', 'cell'])
        cell_order = cell_meta['cell'].astype(str).tolist()
        matrix = data.pivot_table(index='clean_pathway', columns='cell', values='GSVA_score', aggfunc='mean').reindex(index=pathway_order, columns=cell_order)
        image = ax.imshow(matrix.to_numpy(), aspect='auto', interpolation='nearest', cmap='coolwarm', vmin=-2, vmax=2, rasterized=True)
        ax.set_yticks(range(len(matrix.index)))
        ax.set_yticklabels([clean_term(value, 22) for value in matrix.index], fontsize=5.0)
        ax.set_xticks([])
        ax.set_xlabel('Scissor-selected fibroblasts')
        boundary = sum(cell_meta['Scissor_state'].astype(str) == 'Vitamin D3-')
        if 0 < boundary < len(cell_order):
            ax.axvline(boundary - 0.5, color='white', lw=1.0)
        strip = ax.inset_axes([0, 1.01, 1, 0.025])
        states = cell_meta['Scissor_state'].astype(str)
        strip_values = np.array([0 if value == 'Vitamin D3-' else 1 for value in states])[None, :]
        from matplotlib.colors import ListedColormap
        strip.imshow(strip_values, aspect='auto', cmap=ListedColormap([BLUE, SALMON]), interpolation='nearest')
        strip.axis('off')
        plt.colorbar(image, ax=ax, fraction=0.024, pad=0.015).set_label('GSVA score', fontsize=6)
        ax.legend(handles=[Patch(color=BLUE, label='Vitamin D3-'), Patch(color=SALMON, label='Vitamin D3+')], loc='lower center', bbox_to_anchor=(0.5, 1.025), ncol=2, frameon=False, fontsize=5.5)
        panel_letter(ax, 'H')

    @staticmethod
    def _draw_violin(ax: plt.Axes, values: np.ndarray, position: int, color: str) -> None:
        values = values[np.isfinite(values)]
        if len(values) >= 2 and np.nanstd(values) > 0:
            parts = ax.violinplot(values, positions=[position], widths=0.88, showmeans=False, showmedians=False, showextrema=False)
            for body in parts['bodies']:
                body.set_facecolor(color)
                body.set_edgecolor('#333333')
                body.set_linewidth(0.55)
                body.set_alpha(0.95)
        elif len(values):
            ax.scatter([position], [float(np.nanmedian(values))], marker='_', s=90, color=color, linewidths=1.5)
        if len(values):
            median = float(np.nanmedian(values))
            ax.plot([position - 0.08, position + 0.08], [median, median], color='#333333', lw=0.9)

    def panel_i(self, spec, fig: plt.Figure) -> list[plt.Axes]:
        sub = spec.subgridspec(1, 3, wspace=0.33)
        axes = [fig.add_subplot(sub[0, index]) for index in range(3)]
        if self.candidate_expression.empty:
            for index, ax in enumerate(axes):
                if index == 0:
                    placeholder(ax, 'I', 'Candidate-gene violins unavailable')
                else:
                    ax.axis('off')
            return axes
        gene_column = 'gene' if 'gene' in self.candidate_expression else 'gene_symbol'
        for index, (ax, gene) in enumerate(zip(axes, CANDIDATES)):
            subset = self.candidate_expression.loc[self.candidate_expression[gene_column].astype(str).str.upper().eq(gene) & self.candidate_expression['Scissor_state'].astype(str).isin(['Vitamin D3-', 'Vitamin D3+'])].copy()
            values_minus = pd.to_numeric(subset.loc[subset['Scissor_state'].astype(str) == 'Vitamin D3-', 'expression'], errors='coerce').to_numpy()
            values_plus = pd.to_numeric(subset.loc[subset['Scissor_state'].astype(str) == 'Vitamin D3+', 'expression'], errors='coerce').to_numpy()
            self._draw_violin(ax, values_minus, 0, BLUE)
            self._draw_violin(ax, values_plus, 1, SALMON)
            ax.set_xticks([0, 1])
            ax.set_xticklabels(['Vitamin D3-', 'Vitamin D3+'], rotation=0, fontsize=6)
            ax.set_title(gene, fontsize=9, fontweight='bold')
            ax.set_xlabel('')
            ax.set_ylabel('Log-normalized expression' if index == 0 else '')
            p_value = np.nan
            if not self.candidate_stats.empty:
                stats_gene_column = 'gene' if 'gene' in self.candidate_stats else 'gene_symbol'
                hit = self.candidate_stats.loc[self.candidate_stats[stats_gene_column].astype(str).str.upper().eq(gene)]
                if len(hit):
                    p_value = pd.to_numeric(hit['cell_level_wilcoxon_P'], errors='coerce').iloc[0]
            ax.text(0.98, 0.96, p_label(float(p_value)), transform=ax.transAxes, ha='right', va='top', fontweight='bold')
            ax.grid(axis='y', color='#E8E8E8', linewidth=0.5)
        panel_letter(axes[0], 'I', x=-0.22)
        return axes

    def panel_j(self, spec, fig: plt.Figure) -> list[plt.Axes]:
        sub = spec.subgridspec(1, 3, wspace=0.18)
        axes = [fig.add_subplot(sub[0, index]) for index in range(3)]
        if self.candidate_expression.empty:
            for index, ax in enumerate(axes):
                if index == 0:
                    placeholder(ax, 'J', 'Candidate-gene FeaturePlots unavailable')
                else:
                    ax.axis('off')
            return axes
        gene_column = 'gene' if 'gene' in self.candidate_expression else 'gene_symbol'
        for ax, gene in zip(axes, CANDIDATES):
            subset = self.candidate_expression.loc[self.candidate_expression[gene_column].astype(str).str.upper().eq(gene)].copy()
            subset['expression'] = pd.to_numeric(subset['expression'], errors='coerce').fillna(0)
            ax.scatter(subset['UMAP_1'], subset['UMAP_2'], s=0.65, color='#DADADA', linewidths=0, rasterized=True)
            expressed = subset.loc[subset['expression'] > 0].sort_values('expression')
            if len(expressed):
                from matplotlib.colors import LinearSegmentedColormap
                cmap = LinearSegmentedColormap.from_list('candidate_salmon', ['#F8F2EF', SALMON, '#B2182B'])
                scatter = ax.scatter(expressed['UMAP_1'], expressed['UMAP_2'], s=1.6, c=expressed['expression'], cmap=cmap, linewidths=0, rasterized=True)
                plt.colorbar(scatter, ax=ax, fraction=0.045, pad=0.012)
            ax.set_title(gene, fontsize=9, fontweight='bold')
            ax.set_xlabel('UMAP 1')
            ax.set_ylabel('UMAP 2')
            ax.grid(False)
        panel_letter(axes[0], 'J', x=-0.22)
        return axes

    def build_individual(self) -> None:
        simple_panels = [('Figure4A_fibroblast_subcluster_UMAP', self.panel_a, (6.2, 5.2)), ('Figure4B_fibroblast_subcluster_composition', self.panel_b, (9.5, 3.8)), ('Figure4C_fibroblast_subcluster_marker_DotPlot', self.panel_c, (12.0, 5.7)), ('Figure4D_official_Scissor_UMAP', self.panel_d, (6.2, 5.2)), ('Figure4E_Scissor_state_by_fibroblast_subtype', self.panel_e, (8.0, 5.5)), ('Figure4F_Scissor_DE_volcano', self.panel_f, (6.2, 5.2)), ('Figure4G_GO_enrichment', self.panel_g, (8.0, 6.5)), ('Figure4H_Hallmark_GSVA_heatmap', self.panel_h, (8.0, 5.8))]
        for name, function, size in simple_panels:
            fig, ax = plt.subplots(figsize=size)
            function(ax)
            save_figure(fig, self.panels / name)
            plt.close(fig)
        fig_i = plt.figure(figsize=(12.0, 4.7))
        spec_i = gridspec.GridSpec(1, 1, figure=fig_i)[0, 0]
        self.panel_i(spec_i, fig_i)
        save_figure(fig_i, self.panels / 'Figure4I_GDF15_PLAU_RORC_violins')
        plt.close(fig_i)
        fig_j = plt.figure(figsize=(12.0, 4.7))
        spec_j = gridspec.GridSpec(1, 1, figure=fig_j)[0, 0]
        self.panel_j(spec_j, fig_j)
        save_figure(fig_j, self.panels / 'Figure4J_GDF15_PLAU_RORC_FeaturePlots')
        plt.close(fig_j)

    def build_composite(self) -> None:
        fig = plt.figure(figsize=(17.2, 18.8), constrained_layout=False)
        outer = gridspec.GridSpec(16, 12, figure=fig, left=0.055, right=0.985, bottom=0.035, top=0.985, wspace=1.25, hspace=1.3)
        self.panel_a(fig.add_subplot(outer[0:4, 0:4]))
        self.panel_b(fig.add_subplot(outer[0:4, 4:6]), compact=True)
        self.panel_c(fig.add_subplot(outer[0:4, 6:12]), compact=True)
        self.panel_d(fig.add_subplot(outer[4:8, 0:4]))
        self.panel_e(fig.add_subplot(outer[4:8, 4:8]))
        self.panel_f(fig.add_subplot(outer[4:8, 8:12]))
        self.panel_g(fig.add_subplot(outer[8:12, 0:4]))
        self.panel_i(outer[8:12, 4:12], fig)
        self.panel_h(fig.add_subplot(outer[12:16, 0:4]))
        self.panel_j(outer[12:16, 4:12], fig)
        save_figure(fig, self.output / 'Figure4A-J_fibroblast_subclusters_reference_style', dpi=350)
        plt.close(fig)

    def write_manifest(self) -> None:
        status = {'group_directory': str(self.group_dir), 'scope': 'fibroblast cells only; categories are fibroblast subclusters', 'candidate_genes_in_I_and_J': CANDIDATES, 'A_to_C_available': bool(not self.umap.empty), 'D_to_J_available': bool(not self.assign.empty), 'fibroblast_subclusters': self.subtypes, 'figure_format': 'reference-style A-J; PNG/PDF/SVG', 'GO_labels': 'GO identifiers removed from plotted term labels', 'truthfulness_rule': 'No cluster, Scissor state, DEG, enrichment term, or candidate-gene significance was forced.'}
        with (self.output / 'Figure4_manifest.json').open('w', encoding='utf-8') as handle:
            json.dump(status, handle, ensure_ascii=False, indent=2)

    def build(self) -> None:
        self.build_individual()
        self.build_composite()
        self.write_manifest()

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('group_dir', type=Path, help='Dataset-specific clinical-group output directory')
    args = parser.parse_args()
    builder = Figure4Builder(args.group_dir)
    builder.build()
    print(builder.output)
if __name__ == '__main__':
    main()
