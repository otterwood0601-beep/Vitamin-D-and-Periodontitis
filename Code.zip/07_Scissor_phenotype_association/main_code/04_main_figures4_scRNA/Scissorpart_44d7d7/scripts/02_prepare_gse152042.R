script_dir <- dirname(normalizePath(
  sub("^--file=", "", grep("^--file=", commandArgs(), value = TRUE)[1]),
  winslash = "/",
  mustWork = TRUE
))
source(file.path(script_dir, "00_common.R"), encoding = "UTF-8")
suppressPackageStartupMessages(library(rhdf5))

dataset_root <- file.path(RAW_ROOT, "GSE152042")
h5_dir <- file.path(dataset_root, "raw_supplement", "H5")
metadata_path <- file.path(
  dataset_root,
  "metadata",
  "GSE152042_GEO_sample_metadata.tsv"
)
metadata <- fread(metadata_path)

read_10x_h5_rhdf5 <- function(path) {
  data <- h5read(path, "/matrix/data")
  indices <- h5read(path, "/matrix/indices")
  indptr <- h5read(path, "/matrix/indptr")
  shape <- h5read(path, "/matrix/shape")
  barcodes <- h5read(path, "/matrix/barcodes")
  features <- h5read(path, "/matrix/features/name")
  column_index <- rep.int(
    seq_len(as.integer(shape[[2]])),
    diff(as.integer(indptr))
  )
  matrix <- sparseMatrix(
    i = as.integer(indices) + 1L,
    j = column_index,
    x = as.numeric(data),
    dims = as.integer(shape),
    dimnames = list(make.unique(features), barcodes),
    giveCsparse = TRUE
  )
  matrix
}

sample_map <- data.table(
  geo_accession = metadata$geo_accession,
  sample_id = metadata$title,
  clinical_group = c(
    "Healthy", "Healthy", "Mild_periodontitis", "Severe_periodontitis"
  )
)
sample_map[, donor_id := gsub(" ", "_", sample_id)]

objects_by_group <- setNames(
  vector("list", 3L),
  c("Healthy", "Mild_periodontitis", "Severe_periodontitis")
)
qc_rows <- list()

for (index in seq_len(nrow(sample_map))) {
  row <- sample_map[index]
  h5_file <- list.files(
    h5_dir,
    pattern = paste0("^", row$geo_accession, ".*\\.h5$"),
    full.names = TRUE
  )
  if (length(h5_file) != 1L) {
    stop("Expected one H5 file for ", row$geo_accession)
  }
  message("Reading ", basename(h5_file))
  counts <- read_10x_h5_rhdf5(h5_file)
  result <- qc_and_extract_fibroblast(
    counts = counts,
    sample_id = row$sample_id,
    donor_id = row$donor_id,
    clinical_group = row$clinical_group,
    dataset = "GSE152042"
  )
  objects_by_group[[row$clinical_group]] <- c(
    objects_by_group[[row$clinical_group]],
    list(result$object)
  )
  qc_rows[[length(qc_rows) + 1L]] <- result$qc
  rm(counts, result)
  gc()
}

qc_all <- rbindlist(qc_rows, fill = TRUE)
safe_write_csv(
  qc_all,
  file.path(OUTPUT_ROOT, "02_GSE152042", "GSE152042_sample_QC.csv")
)

for (group_key in names(objects_by_group)) {
  object <- merge_fibroblast_objects(objects_by_group[[group_key]])
  safe_write_csv(
    qc_all[clinical_group == group_key],
    file.path(group_dir("GSE152042", group_key), "00_QC", "sample_QC.csv")
  )
  cluster_fibroblast_group(
    object = object,
    dataset = "GSE152042",
    group_key = group_key,
    source_value_type = "Cell Ranger filtered UMI counts",
    renormalize = TRUE
  )
  rm(object)
  gc()
}
