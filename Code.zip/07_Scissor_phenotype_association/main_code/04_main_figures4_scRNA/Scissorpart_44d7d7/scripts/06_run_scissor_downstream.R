args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2L) {
  stop("Usage: Rscript 06_run_scissor_downstream.R <dataset> <group_key>")
}
dataset_arg <- args[[1]]
group_arg <- args[[2]]

script_dir <- dirname(normalizePath(
  sub("^--file=", "", grep("^--file=", commandArgs(), value = TRUE)[1]),
  winslash = "/",
  mustWork = TRUE
))
source(file.path(script_dir, "00_common.R"), encoding = "UTF-8")
suppressPackageStartupMessages({
  library(Scissor)
  library(clusterProfiler)
  library(GSVA)
})

set.seed(PIPELINE_SEED)
out <- group_dir(dataset_arg, group_arg)
qc_dir <- file.path(out, "00_QC")
scissor_dir <- file.path(out, "02_official_Scissor")
analysis_dir <- file.path(out, "03_DE_enrichment_GSVA")
source_dir <- file.path(out, "source_data")
dir.create(scissor_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(analysis_dir, recursive = TRUE, showWarnings = FALSE)

feasibility_path <- file.path(qc_dir, "analysis_feasibility.json")
if (!file.exists(feasibility_path)) {
  stop("Missing upstream feasibility audit: ", feasibility_path)
}
feasibility <- read_json(feasibility_path, simplifyVector = TRUE)
if (!identical(feasibility$status, "fibroblast_subclusters_completed")) {
  safe_write_json(
    list(
      dataset = dataset_arg,
      clinical_group = group_arg,
      status = "not_run",
      reason = feasibility$status
    ),
    file.path(scissor_dir, "downstream_status.json")
  )
  quit(save = "no", status = 0)
}

object_path <- file.path(source_dir, "fibroblast_Scissor_input.rds")
if (!file.exists(object_path)) {
  stop("Missing Scissor input object: ", object_path)
}
object <- readRDS(object_path)
DefaultAssay(object) <- "RNA"
if (!"RNA_snn" %in% names(object@graphs)) {
  stop("Scissor input lacks RNA_snn graph.")
}

bulk_dir <- file.path(PREVIOUS_STAGE11, "02_GSE212728_bulk")
expression_table <- fread(
  file.path(bulk_dir, "05_GSE212728_log2_TPM_expression.csv.gz")
)
gene_column <- intersect(
  c("gene", "gene_symbol", "Gene"),
  names(expression_table)
)[1]
if (is.na(gene_column)) {
  stop("Could not identify the bulk-expression gene column.")
}
if (anyDuplicated(expression_table[[gene_column]])) {
  expression_table <- expression_table[
    ,
    lapply(.SD, mean),
    by = c(gene_column),
    .SDcols = setdiff(names(expression_table), gene_column)
  ]
}
bulk_genes <- expression_table[[gene_column]]
bulk <- as.matrix(expression_table[, setdiff(names(expression_table), gene_column), with = FALSE])
rownames(bulk) <- bulk_genes
storage.mode(bulk) <- "double"

bulk_metadata <- fread(
  file.path(bulk_dir, "04_GSE212728_sample_metadata.csv")
)
sample_column <- intersect(c("Sample", "sample"), names(bulk_metadata))[1]
group_column <- intersect(c("Group", "group"), names(bulk_metadata))[1]
bulk_metadata <- bulk_metadata[
  match(colnames(bulk), bulk_metadata[[sample_column]])
]
phenotype <- ifelse(
  grepl("Vitamin D3|^D3$", bulk_metadata[[group_column]], ignore.case = TRUE),
  1,
  0
)
names(phenotype) <- colnames(bulk)
if (!identical(sort(as.integer(table(phenotype))), c(2L, 3L))) {
  stop("Expected 2 control and 3 vitamin-D3 bulk samples.")
}

common_genes <- intersect(rownames(bulk), rownames(object))
if (length(common_genes) < 5000L) {
  stop("Too few shared genes for Scissor: ", length(common_genes))
}

result_path <- file.path(scissor_dir, "01_official_Scissor_result.rds")
labeled_path <- file.path(
  scissor_dir,
  "02_official_Scissor_labeled_fibroblasts.rds"
)
started <- Sys.time()
if (file.exists(result_path) && file.exists(labeled_path)) {
  result <- readRDS(result_path)
  object <- readRDS(labeled_path)
} else {
  input_snapshot <- file.path(
    scissor_dir,
    "official_Scissor_input_snapshot.RData"
  )
  result <- Scissor(
    bulk_dataset = bulk,
    sc_dataset = object,
    phenotype = phenotype,
    tag = c("Control", "Vitamin D3"),
    alpha = c(
      0.005, 0.01, 0.05, 0.1, 0.2, 0.3,
      0.4, 0.5, 0.6, 0.7, 0.8, 0.9
    ),
    cutoff = 0.20,
    family = "binomial",
    Save_file = input_snapshot
  )
  saveRDS(result, result_path, compress = FALSE)
  state <- rep("Background", ncol(object))
  names(state) <- colnames(object)
  state[result$Scissor_pos] <- "Vitamin D3+"
  state[result$Scissor_neg] <- "Vitamin D3-"
  object$Scissor_state <- factor(
    state[colnames(object)],
    levels = c("Vitamin D3-", "Vitamin D3+", "Background")
  )
  coefficient <- rep(0, ncol(object))
  names(coefficient) <- colnames(object)
  if (length(result$Coefs) == ncol(object)) {
    coefficient <- as.numeric(result$Coefs)
    names(coefficient) <- colnames(object)
  } else if (!is.null(names(result$Coefs))) {
    coefficient[names(result$Coefs)] <- as.numeric(result$Coefs)
  }
  object$Scissor_coefficient <- coefficient[colnames(object)]
  saveRDS(object, labeled_path, compress = FALSE)
}
finished <- Sys.time()

umap <- Embeddings(object, "umap")
assignment <- cbind(
  data.table(
    cell = rownames(umap),
    UMAP_1 = umap[, 1],
    UMAP_2 = umap[, 2]
  ),
  as.data.table(object[[]][rownames(umap), , drop = FALSE])
)
safe_write_csv(
  assignment,
  file.path(scissor_dir, "03_official_Scissor_cell_assignments.csv.gz")
)

state_counts <- assignment[
  ,
  .N,
  by = Scissor_state
]
state_counts[, percentage := N / sum(N) * 100]
safe_write_csv(
  state_counts,
  file.path(scissor_dir, "04_official_Scissor_state_counts.csv")
)

subtype_counts <- assignment[
  ,
  .N,
  by = .(fibroblast_subtype, Scissor_state)
]
subtype_counts[
  ,
  selected_total := sum(N[Scissor_state != "Background"]),
  by = fibroblast_subtype
]
subtype_counts[
  ,
  percentage_among_selected := fifelse(
    Scissor_state == "Background" | selected_total == 0,
    NA_real_,
    N / selected_total * 100
  )
]
safe_write_csv(
  subtype_counts,
  file.path(scissor_dir, "05_Scissor_state_by_fibroblast_subtype.csv")
)

selected_cells <- colnames(object)[
  object$Scissor_state %in% c("Vitamin D3-", "Vitamin D3+")
]
plus_cells <- colnames(object)[object$Scissor_state == "Vitamin D3+"]
minus_cells <- colnames(object)[object$Scissor_state == "Vitamin D3-"]

if (length(plus_cells) < 10L || length(minus_cells) < 10L) {
  audit <- list(
    dataset = dataset_arg,
    clinical_group = group_arg,
    status = "Scissor_completed_but_downstream_not_estimable",
    Vitamin_D3_positive = length(plus_cells),
    Vitamin_D3_negative = length(minus_cells),
    Background = sum(object$Scissor_state == "Background"),
    reason = "At least 10 cells in each selected state are required."
  )
  safe_write_json(audit, file.path(scissor_dir, "downstream_status.json"))
  quit(save = "no", status = 0)
}

Idents(object) <- "Scissor_state"
de <- FindMarkers(
  object = object,
  ident.1 = "Vitamin D3+",
  ident.2 = "Vitamin D3-",
  assay = "RNA",
  slot = "data",
  test.use = "wilcox",
  logfc.threshold = 0,
  min.pct = 0,
  min.cells.feature = 1,
  min.cells.group = 1,
  verbose = FALSE
)
de <- as.data.table(de, keep.rownames = "gene")
if ("avg_logFC" %in% names(de) && !"avg_log2FC" %in% names(de)) {
  setnames(de, "avg_logFC", "avg_log2FC")
}
if (!"p_val_adj" %in% names(de)) {
  de[, p_val_adj := p.adjust(p_val, method = "BH")]
}

rna_data <- GetAssayData(object, assay = "RNA", layer = "data")
de[, avg_log2FC_reported_by_FindMarkers := avg_log2FC]
de_genes <- as.character(de$gene)
missing_de_genes <- setdiff(de_genes, rownames(rna_data))
if (length(missing_de_genes)) {
  stop(
    "DE table contains genes absent from the named RNA matrix: ",
    paste(head(missing_de_genes, 5L), collapse = ", ")
  )
}
plus_linear_mean <- as.numeric(Matrix::rowMeans(expm1(
  rna_data[de_genes, plus_cells, drop = FALSE]
)))
minus_linear_mean <- as.numeric(Matrix::rowMeans(expm1(
  rna_data[de_genes, minus_cells, drop = FALSE]
)))
de[, avg_log2FC := log2(
  (plus_linear_mean + 1) / (minus_linear_mean + 1)
)]
de[, pct.1 := as.numeric(Matrix::rowMeans(
  rna_data[de_genes, plus_cells, drop = FALSE] > 0
))]
de[, pct.2 := as.numeric(Matrix::rowMeans(
  rna_data[de_genes, minus_cells, drop = FALSE] > 0
))]
de[, fold_change := 2^avg_log2FC]
de[, absolute_fold_change := 2^abs(avg_log2FC)]
de[
  ,
  meets_reference_threshold := (
    p_val < 0.05 &
      abs(avg_log2FC) >= REFERENCE_LOG2FC
  )
]
de[
  ,
  direction := fifelse(
    meets_reference_threshold & avg_log2FC > 0,
    "Higher in Vitamin D3+",
    fifelse(
      meets_reference_threshold & avg_log2FC < 0,
      "Higher in Vitamin D3-",
      "Not reference-threshold DEG"
    )
  )
]
de[, absolute_log2FC_for_order := abs(avg_log2FC)]
setorder(de, p_val, -absolute_log2FC_for_order)
safe_write_csv(
  de,
  file.path(analysis_dir, "01_VitaminD3_positive_vs_negative_DE.csv.gz")
)

candidate_expression <- rbindlist(lapply(CANDIDATE_GENES, function(gene) {
  values <- if (gene %in% rownames(rna_data)) {
    as.numeric(rna_data[gene, colnames(object)])
  } else {
    rep(NA_real_, ncol(object))
  }
  data.table(
    gene = gene,
    cell = colnames(object),
    expression = values,
    UMAP_1 = umap[colnames(object), 1],
    UMAP_2 = umap[colnames(object), 2],
    Scissor_state = as.character(object$Scissor_state),
    fibroblast_subtype = as.character(object$fibroblast_subtype),
    sample_id = as.character(object$sample_id),
    donor_id = as.character(object$donor_id)
  )
}))
safe_write_csv(
  candidate_expression,
  file.path(analysis_dir, "02_GDF15_PLAU_RORC_cell_expression.csv.gz")
)

safe_wilcox <- function(left, right) {
  tryCatch(
    wilcox.test(left, right, exact = FALSE)$p.value,
    error = function(error) NA_real_
  )
}
candidate_stats <- rbindlist(lapply(CANDIDATE_GENES, function(gene) {
  gene_value <- gene
  part <- candidate_expression[
    gene == gene_value &
      Scissor_state %in% c("Vitamin D3-", "Vitamin D3+")
  ]
  plus <- part[Scissor_state == "Vitamin D3+", expression]
  minus <- part[Scissor_state == "Vitamin D3-", expression]
  de_row <- de[gene == gene_value]
  data.table(
    gene = gene,
    Vitamin_D3_positive_cells = length(plus),
    Vitamin_D3_negative_cells = length(minus),
    mean_positive = mean(plus, na.rm = TRUE),
    mean_negative = mean(minus, na.rm = TRUE),
    mean_difference = mean(plus, na.rm = TRUE) - mean(minus, na.rm = TRUE),
    cell_level_wilcoxon_P = safe_wilcox(plus, minus),
    FindMarkers_log2FC = if (nrow(de_row)) de_row$avg_log2FC[[1]] else NA_real_,
    FindMarkers_raw_P = if (nrow(de_row)) de_row$p_val[[1]] else NA_real_,
    FindMarkers_FDR = if (nrow(de_row)) de_row$p_val_adj[[1]] else NA_real_
  )
}))
candidate_stats[, cell_level_FDR := p.adjust(cell_level_wilcoxon_P, "BH")]
safe_write_csv(
  candidate_stats,
  file.path(analysis_dir, "03_GDF15_PLAU_RORC_statistics.csv")
)

read_gmt_term2gene <- function(path) {
  fields <- strsplit(
    readLines(path, warn = FALSE, encoding = "UTF-8"),
    "\t",
    fixed = TRUE
  )
  rbindlist(lapply(fields, function(item) {
    if (length(item) < 3L) return(NULL)
    data.table(term = item[[1]], gene = unique(item[-c(1, 2)]))
  }))
}

gene_set_dir <- file.path(PREVIOUS_STAGE11, "source_data", "gene_sets")
gmt_paths <- c(
  "GO-BP" = file.path(gene_set_dir, "GO_Biological_Process_2025.gmt"),
  "GO-CC" = file.path(gene_set_dir, "GO_Cellular_Component_2025.gmt"),
  "GO-MF" = file.path(gene_set_dir, "GO_Molecular_Function_2025.gmt"),
  "Reactome" = file.path(gene_set_dir, "Reactome_Pathways_2024.gmt")
)
if (!all(file.exists(gmt_paths))) {
  stop("One or more local GO/Reactome GMT files are missing.")
}

universe <- unique(de$gene)
up_genes <- de[
  meets_reference_threshold & avg_log2FC > 0,
  unique(gene)
]
down_genes <- de[
  meets_reference_threshold & avg_log2FC < 0,
  unique(gene)
]

run_enricher <- function(genes, term2gene, ontology, direction) {
  if (length(genes) < 2L) {
    return(data.table())
  }
  result <- suppressMessages(clusterProfiler::enricher(
    gene = genes,
    universe = universe,
    TERM2GENE = as.data.frame(term2gene),
    pvalueCutoff = 1,
    pAdjustMethod = "BH",
    qvalueCutoff = 1,
    minGSSize = 10,
    maxGSSize = 500
  ))
  if (is.null(result)) {
    return(data.table())
  }
  table <- as.data.table(as.data.frame(result))
  if (!nrow(table)) {
    return(data.table())
  }
  table[, ontology := ontology]
  table[, direction := direction]
  ratio <- tstrsplit(table$GeneRatio, "/", fixed = TRUE)
  table[, GeneRatio_numeric := as.numeric(ratio[[1]]) / as.numeric(ratio[[2]])]
  table[, FDR_significant := p.adjust < 0.05]
  table[]
}

enrichment_tables <- list()
for (ontology in names(gmt_paths)) {
  term2gene <- read_gmt_term2gene(gmt_paths[[ontology]])
  enrichment_tables[[paste(ontology, "up")]] <- run_enricher(
    up_genes,
    term2gene,
    ontology,
    "Higher in Vitamin D3+"
  )
  enrichment_tables[[paste(ontology, "down")]] <- run_enricher(
    down_genes,
    term2gene,
    ontology,
    "Higher in Vitamin D3-"
  )
}
enrichment_all <- rbindlist(enrichment_tables, fill = TRUE)
if (nrow(enrichment_all)) {
  setorder(enrichment_all, ontology, direction, p.adjust, pvalue)
} else {
  enrichment_all <- data.table(
    ID = character(),
    Description = character(),
    GeneRatio = character(),
    BgRatio = character(),
    RichFactor = numeric(),
    FoldEnrichment = numeric(),
    zScore = numeric(),
    pvalue = numeric(),
    p.adjust = numeric(),
    qvalue = numeric(),
    geneID = character(),
    Count = integer(),
    ontology = character(),
    direction = character(),
    GeneRatio_numeric = numeric(),
    FDR_significant = logical()
  )
}
safe_write_csv(
  enrichment_all,
  file.path(analysis_dir, "04_GO_Reactome_enrichment_all.csv.gz")
)

read_gmt_list <- function(path) {
  fields <- strsplit(
    readLines(path, warn = FALSE, encoding = "UTF-8"),
    "\t",
    fixed = TRUE
  )
  names(fields) <- vapply(fields, function(item) item[[1]], character(1))
  lapply(fields, function(item) unique(item[-c(1, 2)]))
}
clean_pathway <- function(value) {
  value <- sub("^HALLMARK_", "", value)
  tools::toTitleCase(tolower(gsub("_", " ", value)))
}

hallmark <- read_gmt_list(
  file.path(gene_set_dir, "MSigDB_Hallmark_2020.gmt")
)
hallmark <- lapply(hallmark, intersect, y = rownames(rna_data))
hallmark <- hallmark[lengths(hallmark) >= 10 & lengths(hallmark) <= 500]
hallmark_genes <- unique(unlist(hallmark, use.names = FALSE))
gsva_expression <- as.matrix(
  rna_data[hallmark_genes, selected_cells, drop = FALSE]
)
expressed <- rowSums(gsva_expression > 0) >= 3L
gsva_expression <- gsva_expression[expressed, , drop = FALSE]
hallmark <- lapply(hallmark, intersect, y = rownames(gsva_expression))
hallmark <- hallmark[lengths(hallmark) >= 10 & lengths(hallmark) <= 500]
parameter <- gsvaParam(
  exprData = gsva_expression,
  geneSets = hallmark,
  minSize = 10,
  maxSize = 500,
  kcdf = "Gaussian",
  sparse = FALSE,
  verbose = FALSE
)
scores <- gsva(parameter, verbose = FALSE)
gsva_stats <- rbindlist(lapply(rownames(scores), function(pathway) {
  plus <- as.numeric(scores[pathway, plus_cells])
  minus <- as.numeric(scores[pathway, minus_cells])
  data.table(
    pathway = pathway,
    clean_pathway = clean_pathway(pathway),
    positive_n = length(plus),
    negative_n = length(minus),
    mean_positive = mean(plus),
    mean_negative = mean(minus),
    mean_difference = mean(plus) - mean(minus),
    cell_level_wilcoxon_P = safe_wilcox(plus, minus)
  )
}))
gsva_stats[, FDR := p.adjust(cell_level_wilcoxon_P, "BH")]
gsva_stats[, absolute_mean_difference_for_order := abs(mean_difference)]
setorder(
  gsva_stats,
  cell_level_wilcoxon_P,
  -absolute_mean_difference_for_order
)
safe_write_csv(
  gsva_stats,
  file.path(analysis_dir, "05_Hallmark_GSVA_statistics.csv")
)
significant_pathways <- gsva_stats[
  cell_level_wilcoxon_P < 0.05,
  pathway
]
display_pathways <- unique(c(
  head(significant_pathways, 10L),
  gsva_stats$pathway
))[seq_len(min(10L, nrow(gsva_stats)))]
display_cells <- c(
  minus_cells[order(object$Scissor_coefficient[match(
    minus_cells,
    colnames(object)
  )])],
  plus_cells[order(object$Scissor_coefficient[match(
    plus_cells,
    colnames(object)
  )])]
)
heat_long <- rbindlist(lapply(display_pathways, function(pathway) {
  data.table(
    pathway = pathway,
    clean_pathway = clean_pathway(pathway),
    cell = display_cells,
    Scissor_state = as.character(
      object$Scissor_state[match(display_cells, colnames(object))]
    ),
    fibroblast_subtype = as.character(
      object$fibroblast_subtype[match(display_cells, colnames(object))]
    ),
    GSVA_score = as.numeric(scores[pathway, display_cells])
  )
}))
safe_write_csv(
  heat_long,
  file.path(analysis_dir, "06_Hallmark_GSVA_heatmap_source.csv.gz")
)

audit <- list(
  dataset = dataset_arg,
  clinical_group = group_arg,
  status = "completed",
  official_package = "sunduanchen/Scissor",
  package_version = as.character(packageVersion("Scissor")),
  bulk_dataset = "GSE212728",
  bulk_samples = ncol(bulk),
  control_samples = sum(phenotype == 0),
  vitamin_D3_samples = sum(phenotype == 1),
  single_cell_dataset = dataset_arg,
  single_cell_group = group_arg,
  single_cell_scope = "fibroblasts only; donor/subtype-stratified maximum 3000 cells",
  shared_genes = length(common_genes),
  phenotype_encoding = "Vitamin D3=1; ethanol control=0",
  interpretation = "Vitamin D3+ is positively associated with the bulk vitamin-D3 phenotype",
  selected_alpha = result$para$alpha,
  selected_lambda = result$para$lambda,
  cutoff = 0.20,
  Vitamin_D3_positive = length(plus_cells),
  Vitamin_D3_negative = length(minus_cells),
  Background = sum(object$Scissor_state == "Background"),
  DEG_threshold = "raw P < 0.05 and absolute fold change >= 1.2",
  GO_Reactome = "clusterProfiler::enricher with local 2025 GO / 2024 Reactome GMT",
  GSVA = "cell-level GSVA with MSigDB Hallmark 2020",
  candidate_genes = CANDIDATE_GENES,
  elapsed_seconds = as.numeric(difftime(finished, started, units = "secs")),
  repeated_parameter_sensitivity_analysis = FALSE,
  pseudobulk_used_for_main_figure = FALSE
)
safe_write_json(audit, file.path(scissor_dir, "downstream_status.json"))
print(audit)
