from __future__ import annotations
import argparse
import json
import math
import re
import textwrap
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import numpy as np
import pandas as pd
BLUE = '#2B6CB0'
SALMON = '#EF8178'
FDR_LINE = -math.log10(0.05)
ONTOLOGY_ORDER = ['GO-MF', 'GO-CC', 'GO-BP']
plt.rcParams.update({'font.family': 'Arial', 'font.size': 8, 'axes.titlesize': 9, 'axes.labelsize': 8, 'xtick.labelsize': 7, 'ytick.labelsize': 7, 'legend.fontsize': 7, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'axes.spines.top': False, 'axes.spines.right': False})

def clean_term(term: object, width: int=34) -> str:
    value = str(term)
    value = re.sub('\\s*\\(GO:\\d+\\)\\s*', ' ', value)
    value = re.sub('^GO:\\d+\\s*[:\\-]?\\s*', '', value)
    value = value.replace('_', ' ')
    value = re.sub('\\s+', ' ', value).strip()
    return '\n'.join(textwrap.wrap(value, width=width))

def slugify(value: str) -> str:
    return re.sub('[^A-Za-z0-9]+', '_', value).strip('_')

def panel_label(ax: plt.Axes, label: str) -> None:
    ax.text(-0.13, 1.06, label, transform=ax.transAxes, fontsize=23, fontweight='normal', va='top', ha='left')

def order_terms(frame: pd.DataFrame) -> pd.DataFrame:
    parts: list[pd.DataFrame] = []
    for ontology in ONTOLOGY_ORDER:
        part = frame.loc[frame['ontology'] == ontology].copy()
        if part.empty:
            continue
        part = part.sort_values(['p.adjust', 'pvalue'], ascending=[False, False])
        parts.append(part)
    if not parts:
        return pd.DataFrame(columns=frame.columns)
    return pd.concat(parts, ignore_index=True)

def draw_one(data: pd.DataFrame, subtype: str, direction: str, panel: str, output_dir: Path) -> dict[str, object]:
    part = data.loc[(data['subtype'] == subtype) & (data['direction'] == direction)].copy()
    part['p.adjust'] = pd.to_numeric(part['p.adjust'], errors='coerce')
    part['pvalue'] = pd.to_numeric(part['pvalue'], errors='coerce')
    part = part.dropna(subset=['p.adjust', 'pvalue'])
    part = order_terms(part)
    if part.empty:
        raise RuntimeError(f'No displayable GO terms for {subtype} / {direction}')
    part['score'] = -np.log10(part['p.adjust'].clip(lower=1e-300))
    part['label'] = part['Description'].map(clean_term)
    color = SALMON if direction.endswith('+') else BLUE
    state = 'Scissor+' if direction.endswith('+') else 'Scissor-'
    state_slug = 'Scissor_positive' if direction.endswith('+') else 'Scissor_negative'
    fig, ax = plt.subplots(figsize=(12.0, 8.0), constrained_layout=False)
    y = np.arange(len(part))
    ax.barh(y, part['score'], color=color, height=0.72)
    ax.set_yticks(y)
    ax.set_yticklabels(part['label'], fontsize=8.0)
    ax.tick_params(axis='y', pad=5)
    ax.set_xlabel('$-\\log_{10}$(FDR q-value)')
    ax.axvline(FDR_LINE, color='#777777', ls='--', lw=0.8)
    previous = None
    padding = max(float(part['score'].max()) * 0.015, 0.08)
    for index, row in part.iterrows():
        if previous is not None and row['ontology'] != previous:
            ax.axhline(index - 0.5, color='#AAAAAA', lw=0.75)
        if row['p.adjust'] < 0.05:
            ax.text(row['score'] + padding, index, '*', va='center', fontsize=9)
        previous = row['ontology']
    ax.set_xlim(0, float(part['score'].max()) + padding * 5)
    ax.legend(handles=[Patch(color=BLUE, label='Vitamin D3-'), Patch(color=SALMON, label='Vitamin D3+')], title='Higher in', loc='lower center', bbox_to_anchor=(0.5, 1.01), frameon=False, ncol=2, fontsize=8, title_fontsize=8)
    ax.set_title(f'{subtype} \u2014 {state}', pad=42, fontsize=10)
    panel_label(ax, panel)
    fig.subplots_adjust(left=0.28, right=0.98, bottom=0.08, top=0.84)
    base = output_dir / f'Figure4{panel}_{slugify(subtype)}_{state_slug}_GO_enrichment'
    fig.savefig(base.with_suffix('.pdf'), bbox_inches='tight')
    fig.savefig(base.with_suffix('.svg'), bbox_inches='tight')
    fig.savefig(base.with_suffix('.png'), dpi=300, bbox_inches='tight')
    plt.close(fig)
    return {'panel': panel, 'subtype': subtype, 'state': state, 'direction': direction, 'color': color, 'displayed_terms': int(len(part)), 'displayed_BP': int((part['ontology'] == 'GO-BP').sum()), 'displayed_CC': int((part['ontology'] == 'GO-CC').sum()), 'displayed_MF': int((part['ontology'] == 'GO-MF').sum()), 'pdf': str(base.with_suffix('.pdf')), 'svg': str(base.with_suffix('.svg')), 'png': str(base.with_suffix('.png'))}

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--analysis-dir', required=True, type=Path)
    parser.add_argument('--output-dir', required=True, type=Path)
    args = parser.parse_args()
    source = args.analysis_dir / '01_tables' / '07_GO_terms_displayed_in_four_figures.csv'
    if not source.exists():
        raise FileNotFoundError(source)
    data = pd.read_csv(source, low_memory=False)
    required = {'subtype', 'direction', 'ontology', 'Description', 'p.adjust', 'pvalue'}
    missing = required.difference(data.columns)
    if missing:
        raise ValueError(f'Missing columns in GO display table: {sorted(missing)}')
    args.output_dir.mkdir(parents=True, exist_ok=True)
    specifications = [('ECM remodeling', 'Higher in Vitamin D3+', 'G1'), ('ECM remodeling', 'Higher in Vitamin D3-', 'G2'), ('Matrix homeostatic', 'Higher in Vitamin D3+', 'G3'), ('Matrix homeostatic', 'Higher in Vitamin D3-', 'G4')]
    manifest = [draw_one(data, subtype, direction, panel, args.output_dir) for subtype, direction, panel in specifications]
    with (args.output_dir / 'figure_manifest.json').open('w', encoding='utf-8') as handle:
        json.dump(manifest, handle, ensure_ascii=False, indent=2)
    print(f'Created {len(manifest)} subtype/state GO figures in {args.output_dir}')
if __name__ == '__main__':
    main()
