import re
from pathlib import Path
import pandas as pd
from IPython.display import display
COMPOSITION_CSV = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u8f93\u51fa\u7ed3\u679c\\20260731-\u7ef4\u751f\u7d20D-\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e9a\u578b-\u591a\u6570\u636e\u5e93\u5bcc\u96c6\u4e0e\u76f8\u5173\u6027\u7f51\u7edc\\source_tables\\v2_9class_cell_composition.csv')
DOTPLOT_CSV = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u8f93\u51fa\u7ed3\u679c\\20260731-\u7ef4\u751f\u7d20D-\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e9a\u578b-\u591a\u6570\u636e\u5e93\u5bcc\u96c6\u4e0e\u76f8\u5173\u6027\u7f51\u7edc\\source_tables\\v2_9class_marker_DotPlot_source.csv')
DONOR_CSV = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u8f93\u51fa\u7ed3\u679c\\20260731-\u7ef4\u751f\u7d20D-\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e9a\u578b-\u591a\u6570\u636e\u5e93\u5bcc\u96c6\u4e0e\u76f8\u5173\u6027\u7f51\u7edc\\source_tables\\v2_GSE164241_healthy_21subtype_donor_counts.csv')
ANNOTATION_CSV = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u8f93\u51fa\u7ed3\u679c\\20260730-\u591a\u6570\u636e\u5e93-\u7259\u9f88\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e9a\u7fa4-Scissor-Figure4\u590d\u7b97\\01_GSE164241\\GSE164241-\u5065\u5eb7\u7259\u9f88\\01_fibroblast_atlas\\06_fibroblast_subtype_annotation.csv')
SCORES_CSV = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u8f93\u51fa\u7ed3\u679c\\20260730-\u591a\u6570\u636e\u5e93-\u7259\u9f88\u6210\u7ea4\u7ef4\u7ec6\u80de\u4e9a\u7fa4-Scissor-Figure4\u590d\u7b97\\01_GSE164241\\GSE164241-\u5065\u5eb7\u7259\u9f88\\01_fibroblast_atlas\\05_fibroblast_state_module_scores.csv')
composition = pd.read_csv(COMPOSITION_CSV)
dotplot = pd.read_csv(DOTPLOT_CSV)
donor = pd.read_csv(DONOR_CSV)
annotation = pd.read_csv(ANNOTATION_CSV)
scores = pd.read_csv(SCORES_CSV)
annotation['cluster'] = annotation['cluster'].astype(int)
scores['cluster'] = scores['cluster'].astype(int)
total_cells = int(composition['cell_count'].sum())
assert total_cells == int(annotation['cells'].sum()) == 16603
assert abs(composition['proportion'].sum() - 1) < 1e-09
print(f"Loaded {total_cells:,} cells, {len(composition)} merged classes, {annotation['cluster'].nunique()} upstream clusters.")
composition_view = composition[['class9', 'cell_count', 'percentage']].copy()
composition_view['percentage'] = composition_view['percentage'].round(2)
display(composition_view)
ranked = scores.sort_values(['cluster', 'z_score'], ascending=[True, False]).copy()
ranked['rank'] = ranked.groupby('cluster').cumcount() + 1
top = ranked.loc[ranked['rank'] == 1, ['cluster', 'state', 'z_score']].rename(columns={'state': 'top_state', 'z_score': 'top_z'})
second = ranked.loc[ranked['rank'] == 2, ['cluster', 'state', 'z_score']].rename(columns={'state': 'second_state', 'z_score': 'second_z'})
margins = annotation[['cluster', 'cells', 'subtype', 'top_markers']].merge(top, on='cluster').merge(second, on='cluster')
margins['margin'] = margins['top_z'] - margins['second_z']
margins['negative_best'] = margins['top_z'] < 0
margins['low_margin_lt_0_25'] = margins['margin'] < 0.25
negative_cells = int(margins.loc[margins['negative_best'], 'cells'].sum())
low_margin_cells = int(margins.loc[margins['low_margin_lt_0_25'], 'cells'].sum())
print(f'\u6700\u9ad8\u5206\u4ecd\u4e3a\u8d1f\u503c\uff1a{{negative_cells:,}} / {{total_cells:,}} = {{negative_cells/total_cells:.1%}}')
print(f'\u7b2c\u4e00\u3001\u7b2c\u4e8c\u540d\u5dee < 0.25\uff1a{{low_margin_cells:,}} / {{total_cells:,}} = {{low_margin_cells/total_cells:.1%}}')
display(margins.sort_values('margin').head(12)[['cluster', 'cells', 'subtype', 'top_state', 'top_z', 'second_state', 'second_z', 'margin']])
identity_calls = {'4': {'assigned_class': 'Immune regulatory', 'likely_identity': 'Endothelial', 'marker_signature': 'CCL14; PLVAP; SOX17; SOX18; CLEC14A', 'audit_category': '\u660e\u786e\u975e\u6210\u7ea4\u7ef4\u7ec6\u80de'}, '11': {'assigned_class': 'Proliferative', 'likely_identity': 'T/NK cell', 'marker_signature': 'CD2; KLRB1; GZMA; CD7; GZMK; CCL5; CD3G', 'audit_category': '\u660e\u786e\u975e\u6210\u7ea4\u7ef4\u7ec6\u80de'}, '13': {'assigned_class': 'Inflammatory CXCL', 'likely_identity': 'Epithelial/keratinocyte', 'marker_signature': 'SPRR1A; MUC21; SPRR1B; SCEL; ELF3', 'audit_category': '\u660e\u786e\u975e\u6210\u7ea4\u7ef4\u7ec6\u80de'}, '15': {'assigned_class': 'Inflammatory CXCL', 'likely_identity': 'Lymphatic endothelial', 'marker_signature': 'CCL21; PROX1; MMRN1; FLT4', 'audit_category': '\u660e\u786e\u975e\u6210\u7ea4\u7ef4\u7ec6\u80de'}, '17': {'assigned_class': 'Immune regulatory', 'likely_identity': 'Myeloid/DC', 'marker_signature': 'FPR3; C1QC; C1QA; MS4A6A; CD86; CLEC10A', 'audit_category': '\u660e\u786e\u975e\u6210\u7ea4\u7ef4\u7ec6\u80de'}, '18': {'assigned_class': 'Osteogenic MSC', 'likely_identity': 'Melanocyte', 'marker_signature': 'DCT; SLC24A5; MLANA; PMEL', 'audit_category': '\u660e\u786e\u975e\u6210\u7ea4\u7ef4\u7ec6\u80de'}, '20': {'assigned_class': 'Stress GDF15', 'likely_identity': 'Myogenic/satellite-cell program', 'marker_signature': 'CALCR; ZIC1; ASB5; MYF5; PAX7; MYF6', 'audit_category': '\u660e\u786e\u975e\u6210\u7ea4\u7ef4\u7ec6\u80de'}, '8': {'assigned_class': 'Myofibroblast', 'likely_identity': 'Pericyte/vascular mural', 'marker_signature': 'HIGD1B; RGS5; NDUFA4L2; KCNJ8; PPP1R14A', 'audit_category': '\u5468\u7ec6\u80de/\u8840\u7ba1\u58c1\u7ec6\u80de'}, '16': {'assigned_class': 'Myofibroblast', 'likely_identity': 'Pericyte/vascular mural', 'marker_signature': 'MCAM; ABCC9; GJC1; ITGA7', 'audit_category': '\u5468\u7ec6\u80de/\u8840\u7ba1\u58c1\u7ec6\u80de'}}
rows = []
for cluster, call in identity_calls.items():
    cluster = int(cluster)
    row = annotation.loc[annotation['cluster'] == cluster].iloc[0]
    rows.append({'cluster': cluster, 'cells': int(row['cells']), **call})
identity_audit = pd.DataFrame(rows).sort_values(['audit_category', 'cells'], ascending=[True, False])
clear_nonfib = int(identity_audit.loc[identity_audit['audit_category'] == '\u660e\u786e\u975e\u6210\u7ea4\u7ef4\u7ec6\u80de', 'cells'].sum())
with_mural = int(identity_audit['cells'].sum())
print(f'\u660e\u786e\u975e\u6210\u7ea4\u7ef4\u6c61\u67d3\uff1a{clear_nonfib:,} / {total_cells:,} = {clear_nonfib / total_cells:.1%}')
print(f'\u52a0\u4e0a\u5468\u7ec6\u80de/\u8840\u7ba1\u58c1\u7ec6\u80de\uff1a{with_mural:,} / {total_cells:,} = {with_mural / total_cells:.1%}')
display(identity_audit)
donor['class9'] = donor['subtype'].str.replace(' \\([A-Z]\\)$', '', regex=True)
donor_class = donor.groupby(['donor_id', 'class9'], as_index=False)['cell_count'].sum()
totals = donor_class.groupby('class9')['cell_count'].sum()
donor_class['class_total'] = donor_class['class9'].map(totals)
donor_class['donor_share'] = donor_class['cell_count'] / donor_class['class_total']
concentration = donor_class.groupby('class9', as_index=False).agg(donors_with_cells=('cell_count', lambda x: int((x > 0).sum())), max_donor_share=('donor_share', 'max'))
max_rows = donor_class.loc[donor_class.groupby('class9')['cell_count'].idxmax(), ['class9', 'donor_id', 'cell_count']]
concentration = concentration.merge(max_rows, on='class9').sort_values('max_donor_share', ascending=False)
display(concentration)
