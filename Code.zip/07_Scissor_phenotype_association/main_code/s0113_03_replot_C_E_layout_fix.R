options(stringsAsFactors = FALSE)
if (.Platform$OS.type == "windows") {
  try(Sys.setlocale("LC_CTYPE", "Chinese (Simplified)_China.utf8"), silent = TRUE)
}
.libPaths(c(
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_stage11",
  .libPaths()
))
suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1L) stop("Usage: Rscript 03_replot_C_E_layout_fix.R <combination_dir>")
combo_dir <- normalizePath(args[[1]], winslash = "/", mustWork = TRUE)
source_dir <- file.path(combo_dir, "00_\u6e90\u6570\u636e\u4e0e\u5ba1\u8ba1")
task_dir <- file.path(source_dir, "Scissor_GDF15\u914d\u5957_\u590d\u7528\u65e2\u6709\u4ee3\u7801")

mapping <- fread(file.path(source_dir, "\u4e9a\u7fa4\u7edf\u4e00\u529f\u80fd\u547d\u540d_GO_BP\u4e3b\u4f9d\u636e.csv"))
mapping[, cluster := as.character(cluster)]
mapping <- mapping[order(as.integer(cluster))]

c_data <- fread(file.path(source_dir, "C.10\u79cd\u7ec6\u80de\u7684\u5bf9\u89d2\u7ebfGO\u56fe_\u6e90\u6570\u636e.csv"))
c_data[, `:=`(cluster = as.character(cluster), source_cluster = as.character(source_cluster))]
c_data <- c_data[order(as.integer(source_cluster), within_cluster_rank)]
if (nrow(c_data) != 50L || any(c_data$cluster != c_data$source_cluster) ||
    any(table(c_data$source_cluster) != 5L)) {
  stop("C source failed strict 10 x 5 diagonal validation")
}
cluster_labels <- setNames(
  vapply(mapping$display_label, function(value) {
    fb_id <- sub("\\s+.*$", "", value)
    cell_name <- sub("^[^ ]+\\s+", "", value)
    paste(fb_id, cell_name, sep = "\n")
  }, character(1)),
  mapping$cluster
)
term_labels <- setNames(c_data$Description, c_data$term_key)
max_count <- max(c_data$Count, na.rm = TRUE)
count_breaks <- pretty(c(0, max_count), n = 4)
count_breaks <- count_breaks[count_breaks > 0 & count_breaks <= max_count]

p_c <- ggplot(c_data, aes(
  x = factor(cluster, levels = mapping$cluster),
  y = factor(term_key, levels = c_data$term_key)
)) +
  geom_point(aes(size = Count, fill = log10pvalue), shape = 21,
             colour = "#2A2A2A", stroke = 0.35) +
  scale_x_discrete(labels = cluster_labels, drop = FALSE) +
  scale_y_discrete(labels = term_labels, drop = FALSE) +
  scale_size_continuous(range = c(1.2, 7.0), breaks = count_breaks, name = "Count") +
  scale_fill_gradientn(colours = c("#FFF200", "#F0A6B8", "#9C27E8"),
                       name = "log10pvalue") +
  labs(x = "Fibroblast subclusters", y = NULL) +
  theme_bw(base_size = 11) +
  theme(
    plot.title = element_blank(), plot.subtitle = element_blank(),
    panel.grid.major = element_line(colour = "#E5E5E5", linewidth = 0.35),
    panel.grid.minor = element_blank(),
    axis.title.x = element_text(face = "bold", size = 14, margin = margin(t = 10)),
    axis.text.x = element_text(size = 8.3, colour = "#111111",
                               angle = 58, hjust = 1, vjust = 1, lineheight = 0.94),
    axis.text.y = element_text(size = 9.2, colour = "#111111", hjust = 1),
    axis.ticks = element_line(colour = "#333333", linewidth = 0.35),
    legend.title = element_text(face = "bold", size = 11),
    legend.text = element_text(size = 9.5),
    legend.key.height = grid::unit(0.55, "cm"),
    legend.position = "right",
    plot.margin = margin(8, 12, 10, 8)
  ) +
  guides(
    size = guide_legend(order = 1, override.aes = list(fill = "white")),
    fill = guide_colourbar(order = 2, barheight = grid::unit(4.0, "cm"))
  )

ggsave(file.path(combo_dir, "C.10\u79cd\u7ec6\u80de\u7684\u5bf9\u89d2\u7ebfGO\u56fe.pdf"), p_c,
       device = cairo_pdf, width = 15.2, height = 18.0, units = "in", limitsize = FALSE)
ggsave(file.path(task_dir, "C.10\u79cd\u7ec6\u80de\u7684\u5bf9\u89d2\u7ebfGO\u56fe_\u5e26\u7ec6\u80de\u540d\u79f0.png"), p_c,
       width = 15.2, height = 18.0, units = "in", dpi = 180,
       limitsize = FALSE, bg = "white")

e_data <- fread(file.path(task_dir, "E.scissors\u9634\u6027\u9633\u6027\u6bd4\u4f8b_\u6e90\u6570\u636e.csv"))
e_data[, cluster_raw := as.integer(cluster_raw)]
e_data[, Scissor_state := factor(
  Scissor_state, levels = c("Vitamin D3+", "Vitamin D3-")
)]
e_data <- e_data[order(cluster_raw, Scissor_state)]
e_data[, label_x := cumsum(percent_selected) - percent_selected / 2, by = cluster_raw]
e_data[, subtype_factor := factor(subtype_display, levels = rev(mapping$display_label))]

state_colours <- c("Vitamin D3+" = "#EF7D75", "Vitamin D3-" = "#3478B9")
p_e <- ggplot(e_data, aes(x = percent_selected, y = subtype_factor, fill = Scissor_state)) +
  geom_col(width = 0.72, colour = "white", linewidth = 0.35,
           position = position_stack(reverse = TRUE)) +
  geom_text(
    data = e_data[percent_selected >= 8],
    aes(x = label_x, label = sprintf("%.1f%%", percent_selected)),
    size = 3.0, colour = "#111111"
  ) +
  scale_fill_manual(values = state_colours,
                    breaks = c("Vitamin D3+", "Vitamin D3-"), drop = FALSE) +
  scale_x_continuous(breaks = seq(0, 100, 20),
                     expand = expansion(mult = c(0, 0))) +
  coord_cartesian(xlim = c(0, 100), clip = "on") +
  labs(x = "Percentage of Scissor-selected fibroblasts",
       y = "Fibroblast subtype", fill = NULL) +
  theme_classic(base_size = 11) +
  theme(
    plot.title = element_blank(), plot.subtitle = element_blank(),
    axis.text.y = element_text(size = 8.5), axis.ticks.y = element_blank(),
    panel.grid.major.x = element_line(colour = "#E6E6E6", linewidth = 0.35),
    panel.grid.minor = element_blank(), legend.position = "top",
    legend.direction = "horizontal"
  )

ggsave(file.path(combo_dir, "E.scissors\u9634\u6027\u9633\u6027\u6bd4\u4f8b.pdf"), p_e,
       device = cairo_pdf, width = 12.6, height = 7.3, units = "in")
ggsave(file.path(task_dir, "E.scissors\u9634\u6027\u9633\u6027\u6bd4\u4f8b.png"), p_e,
       width = 12.6, height = 7.3, units = "in", dpi = 220, bg = "white")

cat("C_E_LAYOUT_FIX_COMPLETE\n")
