from __future__ import annotations
import argparse
import hashlib
import json
import re
import shutil
import subprocess
from pathlib import Path
EXPECTED_ORIGINAL_SHA256 = '7079DED803842CE15D6000CE788F275BAB6A097E0CD4BE66D97DBEEBDE59BE50'

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest().upper()

def run_text(executable: str, arguments: list[str]) -> str:
    result = subprocess.run([executable, *arguments], check=True, capture_output=True, text=True, encoding='utf-8', errors='replace')
    return result.stdout

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--delivery-dir', required=True, type=Path)
    parser.add_argument('--original-pdf', required=True, type=Path)
    args = parser.parse_args()
    figures = args.delivery_dir / '01_figures'
    audit_dir = args.delivery_dir / '03_source_and_audit'
    manifest_path = figures / 'figure_manifest.json'
    with manifest_path.open(encoding='utf-8') as handle:
        manifest = json.load(handle)
    if len(manifest) != 2:
        raise AssertionError(f'Expected two figures, found {len(manifest)}')
    pdfimages = shutil.which('pdfimages.exe') or shutil.which('pdfimages')
    pdfinfo = shutil.which('pdfinfo.exe') or shutil.which('pdfinfo')
    pdftotext = shutil.which('pdftotext.exe') or shutil.which('pdftotext')
    if not all((pdfimages, pdfinfo, pdftotext)):
        raise RuntimeError('Poppler QA executables were not all found')
    original_hash = sha256(args.original_pdf)
    if original_hash != EXPECTED_ORIGINAL_SHA256:
        raise AssertionError('The pre-existing revised Figure 4F changed during this task')
    checks = []
    for item in manifest:
        artifact_paths = {key: figures / Path(item[key]).name for key in ('pdf', 'svg', 'png')}
        for path in artifact_paths.values():
            if not path.exists() or path.stat().st_size == 0:
                raise AssertionError(f'Missing or empty output: {path}')
        if set(item['colors'].values()) != {'#2B6CB0', '#EF8178', '#D5D5D5'}:
            raise AssertionError(f"Palette mismatch in {item['panel']}")
        if item['thresholds']['raw_P'] != 0.05:
            raise AssertionError(f"Raw-P threshold mismatch in {item['panel']}")
        if item['thresholds']['absolute_fold_change'] != 1.2:
            raise AssertionError(f"Fold-change threshold mismatch in {item['panel']}")
        text = run_text(pdftotext, [str(artifact_paths['pdf']), '-'])
        if text.count('GDF15') != 1:
            raise AssertionError(f"Expected exactly one GDF15 label in {item['panel']}")
        for forbidden in ('PLAU', 'RORC', 'MLX', 'PSMC3IP', 'USP3', 'CCDC17', 'INSIG2'):
            if forbidden in text:
                raise AssertionError(f"Unexpected gene label {forbidden} in {item['panel']}")
        image_listing = run_text(pdfimages, ['-list', str(artifact_paths['pdf'])]).splitlines()
        image_rows = [line for line in image_listing[2:] if line.strip()]
        image_types = [line.split()[2] for line in image_rows if len(line.split()) > 2]
        if 'image' not in image_types or 'smask' not in image_types:
            raise AssertionError(f"Hybrid vector/raster structure does not match the source in {item['panel']}")
        info = run_text(pdfinfo, [str(artifact_paths['pdf'])])
        match = re.search('Page size:\\s+([0-9.]+) x ([0-9.]+) pts', info)
        if not match:
            raise AssertionError(f"Could not read PDF page size for {item['panel']}")
        width, height = map(float, match.groups())
        if abs(width - 517.716) / 517.716 > 0.02 or abs(height - 414.136) / 414.136 > 0.02:
            raise AssertionError(f"Page proportion differs materially from the revised source in {item['panel']}")
        gdf15 = item['GDF15']
        if gdf15['direction_class'] != 'Not reference-threshold DEG':
            raise AssertionError(f"GDF15 status mismatch in {item['panel']}")
        checks.append({'panel': item['panel'], 'subtype': item['subtype'], 'only_gene_label': 'GDF15', 'GDF15_avg_log2FC': gdf15['avg_log2FC'], 'GDF15_raw_P': gdf15['raw_P'], 'GDF15_threshold_status': gdf15['direction_class'], 'page_size_points': [width, height], 'embedded_point_cloud_layers': image_types, 'pdf_sha256': sha256(artifact_paths['pdf']), 'svg_sha256': sha256(artifact_paths['svg']), 'png_sha256': sha256(artifact_paths['png'])})
    report = {'status': 'PASS', 'checks': {'two_requested_figures': True, 'PDF_SVG_PNG_for_each': True, 'only_GDF15_gene_label': True, 'GDF15_arrow_targets_real_table_coordinate': True, 'thresholds_and_palette_match_source': True, 'hybrid_vector_text_and_rasterized_point_cloud_match_source': True, 'page_proportion_matches_revised_source': True, 'original_revised_PDF_unchanged': True, 'manual_render_visual_QA': 'PASS; both latest PDFs rendered and inspected'}, 'original_file_name': args.original_pdf.name, 'original_sha256': original_hash, 'figure_checks': checks}
    audit_dir.mkdir(parents=True, exist_ok=True)
    with (audit_dir / '11_delivery_QA.json').open('w', encoding='utf-8') as handle:
        json.dump(report, handle, ensure_ascii=False, indent=2)
    print('PASS: subtype volcano delivery QA completed')
if __name__ == '__main__':
    main()
