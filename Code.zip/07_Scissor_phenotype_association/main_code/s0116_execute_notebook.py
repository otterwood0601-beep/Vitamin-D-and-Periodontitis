from __future__ import annotations
import os
from pathlib import Path
import nbformat
from nbclient import NotebookClient
os.environ['JUPYTER_PATH'] = 'G:\\\u8840\u6e05\u7ef4\u751f\u7d20\\E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2\\E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784\\\u4ee3\u7801\\\u8fd0\u884c\u73af\u5883\\python_notebook_pkgs'
output_dir = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\_\u4e34\u65f6\u8fd0\u884c\u533a\\fibroblast-9-subtypes-evaluation\\20260815_reassessment')
notebook_path = output_dir / '\u4e5d\u79cd\u6210\u7ea4\u7ef4\u7ec6\u80de\u5206\u7c7b_\u5b9a\u91cf\u590d\u6838.ipynb'
with notebook_path.open('r', encoding='utf-8') as handle:
    notebook = nbformat.read(handle, as_version=4)
client = NotebookClient(notebook, timeout=300, kernel_name='codex_temp314', allow_errors=False, record_timing=True)
client.execute(cwd=str(output_dir))
with notebook_path.open('w', encoding='utf-8') as handle:
    nbformat.write(notebook, handle)
print(notebook_path)
