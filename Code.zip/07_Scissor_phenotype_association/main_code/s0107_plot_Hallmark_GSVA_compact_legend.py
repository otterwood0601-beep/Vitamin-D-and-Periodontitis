from __future__ import annotations
import hashlib
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, ListedColormap, TwoSlopeNorm
from matplotlib.patches import Patch
import numpy as np
import pandas as pd
from scipy.cluster.hierarchy import dendrogram, linkage
BLUE = '#2B6CB0'
RED = '#EF8178'
INK = '#1F1F1F'
OUTPUT_DPI = 500
ONE_PIXEL_INCHES = 1.0 / OUTPUT_DPI
SOURCE_DIR = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\\u5f53\u524d\u6295\u7a3f\u9879\u76ee\\\u91cd\u505aGVAS\u901a\u8def\u70ed\u56fe-\u5355\u7ec6\u80de\\\u5b9a\u5411\u7ec6\u80de\u5b50\u96c6_\u4e09\u901a\u8def75pct_20260811')
OUTPUT_DIR = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u4ee3\u7801\\\u8fd0\u884c\u8f93\u51fa\\\u5f53\u524d\u6295\u7a3f\u9879\u76ee\\3..\u5355\u7ec6\u80de\u6d4b\u5e8f\\20260817_CELLxGENE\u6574\u5408\u7259\u5468\u56fe\u8c31_\u56db\u961f\u5217_FB_GO\u529f\u80fd\u5206\u7c7b_\u6700\u7ec8\u7a3f_v1\\04_\u5168\u90e8\u6837\u672c__\u7ec4\u5408_PCA10_Harmony_Louvain_res0.60\\PCA10_res0.50_0.40_0.30_0.20_0.10_GO\u5168\u663e\u8457\u6761\u76ee_v1\\\u7ec4\u5408_PCA10_Harmony_Louvain_res0.50')
OUTPUT_STEM = 'H.\u5dee\u5f02\u57fa\u56e0\u7684Hallmark-GSVA\u70ed\u56fe_\u683c\u5bbd50pct_\u53bb\u9664\u6846\u9009\u6587\u5b57_\u589e\u52a0VitaminD3\u56fe\u4f8b_D3plus\u84dd_D3minus\u7ea2_\u56fe\u4f8b\u7d27\u51d1_\u805a\u7c7b\u6811\u5bbd\u4e09\u5206\u4e4b\u4e00_\u65e0\u6a2a\u8f74\u6807\u9898'
SELECTED_CELLS_CSV = SOURCE_DIR / '01_selected_cells_and_target_pathway_scores.csv.gz'
HEATMAP_SOURCE_CSV = SOURCE_DIR / '04_heatmap_source_10pathways_320cells.csv.gz'

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def clean_term(value: str) -> str:
    replacements = {'E2f Targets': 'E2F Targets', 'G2-m Checkpoint': 'G2-M Checkpoint', 'Wnt-Beta Catenin Signaling': 'Wnt-Beta Catenin Signaling', 'Heme Metabolism': 'Heme Metabolism'}
    return replacements.get(str(value), str(value))

def main() -> None:
    source_hashes_before = {SELECTED_CELLS_CSV.name: sha256(SELECTED_CELLS_CSV), HEATMAP_SOURCE_CSV.name: sha256(HEATMAP_SOURCE_CSV)}
    selected_cells = pd.read_csv(SELECTED_CELLS_CSV, low_memory=False)
    plot_long = pd.read_csv(HEATMAP_SOURCE_CSV, low_memory=False)
    pathway_order = list(dict.fromkeys(plot_long['pathway'].astype(str)))
    cell_order = selected_cells['cell'].astype(str).tolist()
    matrix = plot_long.pivot_table(index='pathway', columns='cell', values='GSVA_score', aggfunc='mean', sort=False).reindex(index=pathway_order, columns=cell_order)
    if matrix.shape != (10, 320):
        raise ValueError(f'Unexpected plotting matrix shape: {matrix.shape}')
    link = linkage(np.nan_to_num(matrix.to_numpy(float), nan=0.0), method='average', metric='euclidean')
    matplotlib.rcParams.update({'font.family': 'Arial', 'font.sans-serif': ['Arial', 'Liberation Sans', 'DejaVu Sans'], 'font.size': 9, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'axes.unicode_minus': False})
    original_tree_width = 1.18
    tree_width = original_tree_width / 3.0
    removed_tree_width = original_tree_width - tree_width
    figure_width = 10.0 - removed_tree_width
    figure_height = 7.6
    fig = plt.figure(figsize=(figure_width, figure_height), constrained_layout=False)
    tree_left = 0.55
    heat_left = tree_left + tree_width + ONE_PIXEL_INCHES
    heat_width = 4.0
    label_left = heat_left + heat_width + 0.055
    label_width = 1.88
    heat_bottom = 0.58
    heat_height = 5.78

    def rect(left: float, bottom: float, width: float, height: float) -> list[float]:
        return [left / figure_width, bottom / figure_height, width / figure_width, height / figure_height]
    ax_tree = fig.add_axes(rect(tree_left, heat_bottom, tree_width, heat_height))
    ax_heat = fig.add_axes(rect(heat_left, heat_bottom, heat_width, heat_height))
    ax_labels = fig.add_axes(rect(label_left, heat_bottom, label_width, heat_height))
    tree = dendrogram(link, orientation='left', no_labels=True, color_threshold=0, above_threshold_color='#555555', link_color_func=lambda _: '#555555', ax=ax_tree)
    matrix = matrix.iloc[tree['leaves']]
    ax_tree.invert_yaxis()
    for collection in ax_tree.collections:
        collection.set_linewidth(0.95)
    ax_tree.margins(x=0)
    ax_tree.set_xticks([])
    ax_tree.set_yticks([])
    for spine in ax_tree.spines.values():
        spine.set_visible(False)
    gsva_cmap = LinearSegmentedColormap.from_list('gsva_reference_layout', ['#0B5AA6', '#A7C7E7', '#F7F7F7', '#F6B3AA', '#E85B52'], N=256)
    image = ax_heat.imshow(matrix.to_numpy(float), aspect='auto', interpolation='nearest', cmap=gsva_cmap, norm=TwoSlopeNorm(vmin=-0.5, vcenter=0.0, vmax=0.5), rasterized=True)
    ax_heat.set_xticks([])
    ax_heat.set_yticks([])
    ax_heat.set_xlabel('')
    n_minus = int(selected_cells['Scissor_state'].astype(str).eq('Vitamin D3-').sum())
    ax_heat.axvline(n_minus - 0.5, color='white', linewidth=1.2)
    group_values = np.array([0 if state == 'Vitamin D3-' else 1 for state in selected_cells['Scissor_state']])[None, :]
    strip = fig.add_axes(rect(heat_left, heat_bottom + heat_height + 0.055, heat_width, 0.2))
    strip.imshow(group_values, aspect='auto', cmap=ListedColormap([RED, BLUE]), interpolation='nearest')
    strip.set_xticks([])
    strip.set_yticks([])
    for spine in strip.spines.values():
        spine.set_visible(False)
    fig.text((heat_left - 0.045) / figure_width, (heat_bottom + heat_height + 0.155) / figure_height, 'Group', ha='right', va='center', fontsize=9, fontweight='bold')
    ax_labels.set_xlim(0, 1)
    ax_labels.set_ylim(len(matrix.index) - 0.5, -0.5)
    ax_labels.axis('off')
    clean_lookup = plot_long[['pathway', 'clean_pathway']].drop_duplicates('pathway').set_index('pathway')['clean_pathway'].astype(str)
    for row_index, pathway in enumerate(matrix.index.astype(str)):
        ax_labels.text(0.0, row_index, clean_term(clean_lookup.get(pathway, pathway)), ha='left', va='center', fontsize=8.6, color=INK, linespacing=1.03)
    colorbar_left = 7.68 - removed_tree_width
    legend_left = 7.52 - removed_tree_width
    cax = fig.add_axes(rect(colorbar_left, 3.64, 0.14, 1.62))
    colorbar = fig.colorbar(image, cax=cax, extend='both')
    colorbar.set_label('GSVA score', fontsize=8)
    colorbar.set_ticks([-0.5, -0.25, 0.0, 0.25, 0.5])
    colorbar.ax.tick_params(labelsize=7)
    fig.legend(handles=[Patch(color=BLUE, label='Vitamin D3+'), Patch(color=RED, label='Vitamin D3-')], title='Group', loc='upper left', bbox_to_anchor=(legend_left / figure_width, 3.44 / figure_height), bbox_transform=fig.transFigure, frameon=False, fontsize=8, title_fontsize=8, borderaxespad=0)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    output_pdf = OUTPUT_DIR / f'{OUTPUT_STEM}.pdf'
    metadata = {'Creator': 'Matplotlib', 'Title': OUTPUT_STEM}
    fig.savefig(output_pdf, facecolor='white', metadata=metadata)
    plt.close(fig)
    source_hashes_after = {SELECTED_CELLS_CSV.name: sha256(SELECTED_CELLS_CSV), HEATMAP_SOURCE_CSV.name: sha256(HEATMAP_SOURCE_CSV)}
    audit = {'status': 'completed', 'source_files_unchanged': source_hashes_before == source_hashes_after, 'source_hashes_before': source_hashes_before, 'source_hashes_after': source_hashes_after, 'matrix_shape': list(matrix.shape), 'cell_width_ratio': 0.5, 'data_values_changed': False, 'top_title_block_removed': True, 'descriptive_note_removed': True, 'vitamin_d3_color_mapping': {'Vitamin D3+': BLUE, 'Vitamin D3-': RED}, 'compact_legend_layout': True, 'legend_shift_left_inches': 0.6, 'figure_width_inches': figure_width, 'original_tree_width_inches': original_tree_width, 'new_tree_width_inches': tree_width, 'tree_width_ratio': tree_width / original_tree_width, 'x_axis_title_removed': True, 'output_pdf': str(output_pdf)}
    (Path(__file__).resolve().parent / f'{OUTPUT_STEM}_audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
if __name__ == '__main__':
    main()
