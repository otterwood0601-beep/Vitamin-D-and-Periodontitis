from __future__ import annotations
import argparse
import json
import math
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
BLUE = '#2B6CB0'
SALMON = '#EF8178'
NEUTRAL = '#D5D5D5'
DARK_GREY = '#555555'
FOLD_CUTOFF = math.log2(1.2)
plt.rcParams.update({'font.family': 'Arial', 'font.size': 8, 'axes.titlesize': 9, 'axes.labelsize': 8, 'xtick.labelsize': 7, 'ytick.labelsize': 7, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'axes.spines.top': False, 'axes.spines.right': False})

def panel_letter(ax: plt.Axes, value: str) -> None:
    ax.text(-0.1, 1.06, value, transform=ax.transAxes, fontsize=23, fontweight='normal', va='top', ha='left')

def plot_one(source: Path, subtype: str, panel: str, filename: str, output_dir: Path) -> dict[str, object]:
    data = pd.read_csv(source, low_memory=False)
    required = {'gene', 'p_val', 'avg_log2FC', 'direction'}
    missing = required.difference(data.columns)
    if missing:
        raise ValueError(f'Missing columns in {source}: {sorted(missing)}')
    data['avg_log2FC'] = pd.to_numeric(data['avg_log2FC'], errors='coerce')
    data['p_val'] = pd.to_numeric(data['p_val'], errors='coerce')
    data = data.dropna(subset=['avg_log2FC', 'p_val']).copy()
    data['minus_log10_p'] = -np.log10(data['p_val'].clip(lower=1e-300))
    direction = data['direction'].astype(str)
    neutral = direction.eq('Not reference-threshold DEG')
    down = direction.eq('Higher in Vitamin D3-')
    up = direction.eq('Higher in Vitamin D3+')
    hit = data.loc[data['gene'].astype(str).str.upper().eq('GDF15')]
    if len(hit) != 1:
        raise AssertionError(f'Expected exactly one GDF15 row in {source}, found {len(hit)}')
    gdf15 = hit.iloc[0]
    fig, ax = plt.subplots(figsize=(7.8, 6.6))
    ax.scatter(data.loc[neutral, 'avg_log2FC'], data.loc[neutral, 'minus_log10_p'], s=3.3, color=NEUTRAL, linewidths=0, alpha=0.65, rasterized=True)
    ax.scatter(data.loc[down, 'avg_log2FC'], data.loc[down, 'minus_log10_p'], s=5.2, color=BLUE, linewidths=0, alpha=0.8, rasterized=True)
    ax.scatter(data.loc[up, 'avg_log2FC'], data.loc[up, 'minus_log10_p'], s=5.2, color=SALMON, linewidths=0, alpha=0.8, rasterized=True)
    ax.axhline(-math.log10(0.05), color='#777777', ls='--', lw=0.8)
    ax.axvline(FOLD_CUTOFF, color='#777777', ls='--', lw=0.8)
    ax.axvline(-FOLD_CUTOFF, color='#777777', ls='--', lw=0.8)
    x = float(gdf15['avg_log2FC'])
    y = float(gdf15['minus_log10_p'])
    hit_direction = str(gdf15['direction'])
    hit_color = {'Higher in Vitamin D3+': SALMON, 'Higher in Vitamin D3-': BLUE}.get(hit_direction, NEUTRAL)
    ax.scatter([x], [y], s=24, color=hit_color, edgecolor='black', linewidth=0.65, zorder=7)
    x_range = float(data['avg_log2FC'].max() - data['avg_log2FC'].min())
    y_max = float(data['minus_log10_p'].max())
    label_x = x - max(0.55, x_range * 0.1)
    label_y = max(y + 1.5, y_max * 0.24)
    ax.annotate('GDF15', xy=(x, y), xytext=(label_x, label_y), ha='right', va='center', fontsize=9, fontweight='bold', color='black', arrowprops={'arrowstyle': '->', 'color': 'black', 'lw': 1.2}, zorder=8)
    ax.set_xlabel('$\\log_2$ fold change (Vitamin D3+ / Vitamin D3-)')
    ax.set_ylabel('$-\\log_{10}$ raw P')
    ax.set_title(f'{subtype}: Scissor+ versus Scissor-', pad=10)
    panel_letter(ax, panel)
    fig.subplots_adjust(left=0.16, right=0.98, bottom=0.14, top=0.88)
    base = output_dir / filename
    fig.savefig(base.with_suffix('.pdf'), bbox_inches='tight')
    fig.savefig(base.with_suffix('.svg'), bbox_inches='tight')
    fig.savefig(base.with_suffix('.png'), dpi=300, bbox_inches='tight')
    plt.close(fig)
    return {'panel': panel, 'subtype': subtype, 'comparison': 'Scissor+ versus Scissor- within subtype', 'source_DE_table': str(source), 'tested_genes': int(len(data)), 'higher_in_Scissor_positive': int(up.sum()), 'higher_in_Scissor_negative': int(down.sum()), 'neutral': int(neutral.sum()), 'GDF15': {'avg_log2FC': x, 'raw_P': float(gdf15['p_val']), 'minus_log10_raw_P': y, 'direction_class': hit_direction, 'meets_reference_threshold': bool(gdf15.get('meets_reference_threshold', False)), 'pct_Scissor_positive': float(gdf15.get('pct.1', np.nan)), 'pct_Scissor_negative': float(gdf15.get('pct.2', np.nan))}, 'thresholds': {'raw_P': 0.05, 'absolute_fold_change': 1.2, 'absolute_log2FC': FOLD_CUTOFF}, 'colors': {'higher_in_Scissor_negative': BLUE, 'higher_in_Scissor_positive': SALMON, 'neutral': NEUTRAL}, 'pdf': str(base.with_suffix('.pdf')), 'svg': str(base.with_suffix('.svg')), 'png': str(base.with_suffix('.png'))}

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--analysis-dir', required=True, type=Path)
    parser.add_argument('--output-dir', required=True, type=Path)
    args = parser.parse_args()
    table_dir = args.analysis_dir / '01_tables'
    args.output_dir.mkdir(parents=True, exist_ok=True)
    specifications = [(table_dir / '02_DE_ECM_remodeling_VitaminD3_positive_vs_negative.csv.gz', 'ECM remodeling', 'F1', 'Figure4F1_ECM_remodeling_Scissor_positive_vs_negative_GDF15_only_label'), (table_dir / '02_DE_Matrix_homeostatic_VitaminD3_positive_vs_negative.csv.gz', 'Matrix homeostatic', 'F2', 'Figure4F2_Matrix_homeostatic_Scissor_positive_vs_negative_GDF15_only_label')]
    for source, _, _, _ in specifications:
        if not source.exists():
            raise FileNotFoundError(source)
    manifest = [plot_one(source, subtype, panel, filename, args.output_dir) for source, subtype, panel, filename in specifications]
    with (args.output_dir / 'figure_manifest.json').open('w', encoding='utf-8') as handle:
        json.dump(manifest, handle, ensure_ascii=False, indent=2)
    gdf15_rows = []
    for item in manifest:
        gdf15_rows.append({'subtype': item['subtype'], 'comparison': item['comparison'], 'avg_log2FC': item['GDF15']['avg_log2FC'], 'fold_change': 2 ** item['GDF15']['avg_log2FC'], 'raw_P': item['GDF15']['raw_P'], 'minus_log10_raw_P': item['GDF15']['minus_log10_raw_P'], 'direction_class': item['GDF15']['direction_class'], 'meets_reference_threshold': item['GDF15']['meets_reference_threshold'], 'pct_Scissor_positive': item['GDF15']['pct_Scissor_positive'], 'pct_Scissor_negative': item['GDF15']['pct_Scissor_negative']})
    pd.DataFrame(gdf15_rows).to_csv(args.output_dir / 'GDF15_subtype_statistics.csv', index=False, encoding='utf-8-sig')
    print(f'Created two subtype-specific GDF15-only volcano plots in {args.output_dir}')
if __name__ == '__main__':
    main()
