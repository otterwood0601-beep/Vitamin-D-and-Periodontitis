from __future__ import annotations
import argparse
import csv
import hashlib
import json
import shutil
import subprocess
from pathlib import Path
EXPECTED = [('ECM remodeling', 'Higher in Vitamin D3+', '#EF8178'), ('ECM remodeling', 'Higher in Vitamin D3-', '#2B6CB0'), ('Matrix homeostatic', 'Higher in Vitamin D3+', '#EF8178'), ('Matrix homeostatic', 'Higher in Vitamin D3-', '#2B6CB0')]

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest().upper()

def pdf_image_count(path: Path) -> int:
    executable = shutil.which('pdfimages.exe') or shutil.which('pdfimages')
    if executable is None:
        raise RuntimeError('pdfimages was not found')
    result = subprocess.run([executable, '-list', str(path)], check=True, capture_output=True, text=True, encoding='utf-8', errors='replace')
    lines = [line for line in result.stdout.splitlines() if line.strip()]
    return max(0, len(lines) - 2)

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--delivery-dir', required=True, type=Path)
    parser.add_argument('--desktop-original', required=True, type=Path)
    parser.add_argument('--source-original', required=True, type=Path)
    parser.add_argument('--expected-desktop-original-sha256', required=True)
    args = parser.parse_args()
    figures = args.delivery_dir / '01_figures'
    tables = args.delivery_dir / '02_tables'
    audit_dir = args.delivery_dir / '03_source_and_audit'
    manifest_path = figures / 'figure_manifest.json'
    displayed_path = tables / '07_GO_terms_displayed_in_four_figures.csv'
    summary_path = tables / '06_pathway_count_summary.csv'
    with manifest_path.open(encoding='utf-8') as handle:
        manifest = json.load(handle)
    if len(manifest) != 4:
        raise AssertionError(f'Expected four figure entries, found {len(manifest)}')
    manifest_keys = {(item['subtype'], item['direction'], item['color'].upper()) for item in manifest}
    expected_keys = {(subtype, direction, color.upper()) for subtype, direction, color in EXPECTED}
    if manifest_keys != expected_keys:
        raise AssertionError('Manifest group/direction/color mapping does not match the requested design')
    figure_checks = []
    for item in manifest:
        if item['displayed_terms'] != 9:
            raise AssertionError(f"Expected nine displayed terms in {item['panel']}")
        if (item['displayed_BP'], item['displayed_CC'], item['displayed_MF']) != (3, 3, 3):
            raise AssertionError(f"BP/CC/MF display counts are not 3/3/3 in {item['panel']}")
        base_names = {suffix: Path(item[suffix]).name for suffix in ('pdf', 'svg', 'png')}
        paths = {suffix: figures / name for suffix, name in base_names.items()}
        for path in paths.values():
            if not path.exists() or path.stat().st_size == 0:
                raise AssertionError(f'Missing or empty figure artifact: {path}')
        image_count = pdf_image_count(paths['pdf'])
        if image_count != 0:
            raise AssertionError(f"PDF contains {image_count} raster image object(s): {paths['pdf']}")
        figure_checks.append({'panel': item['panel'], 'subtype': item['subtype'], 'state': item['state'], 'pdf_vector_image_objects': image_count, 'pdf_sha256': sha256(paths['pdf']), 'svg_sha256': sha256(paths['svg']), 'png_sha256': sha256(paths['png'])})
    with displayed_path.open(encoding='utf-8-sig', newline='') as handle:
        displayed = list(csv.DictReader(handle))
    displayed_counts = {}
    for row in displayed:
        key = (row['subtype'], row['direction'], row['ontology'])
        displayed_counts[key] = displayed_counts.get(key, 0) + 1
    for subtype, direction, _ in EXPECTED:
        for ontology in ('GO-BP', 'GO-CC', 'GO-MF'):
            if displayed_counts.get((subtype, direction, ontology)) != 3:
                raise AssertionError(f'Displayed table is not 3 terms for {subtype}/{direction}/{ontology}')
    with summary_path.open(encoding='utf-8-sig', newline='') as handle:
        summary = list(csv.DictReader(handle))
    if len(summary) != 12:
        raise AssertionError(f'Expected 12 pathway-count rows, found {len(summary)}')
    desktop_hash = sha256(args.desktop_original)
    if desktop_hash != args.expected_desktop_original_sha256.upper():
        raise AssertionError('The pre-existing desktop Figure 4G changed during this task')
    report = {'status': 'PASS', 'checks': {'four_requested_figures': True, 'pdf_svg_png_for_each': True, 'three_BP_three_CC_three_MF_for_each': True, 'direction_colors_match_original': True, 'PDFs_have_zero_raster_image_objects': True, 'original_desktop_figure_unchanged': True, 'manual_PDF_render_visual_QA': 'PASS; all four rendered pages inspected'}, 'desktop_original': {'file_name': args.desktop_original.name, 'sha256': desktop_hash}, 'source_original': {'file_name': args.source_original.name, 'sha256': sha256(args.source_original)}, 'figure_checks': figure_checks}
    audit_dir.mkdir(parents=True, exist_ok=True)
    output = audit_dir / '11_delivery_QA.json'
    with output.open('w', encoding='utf-8') as handle:
        json.dump(report, handle, ensure_ascii=False, indent=2)
    print('PASS: delivery QA completed')
if __name__ == '__main__':
    main()
