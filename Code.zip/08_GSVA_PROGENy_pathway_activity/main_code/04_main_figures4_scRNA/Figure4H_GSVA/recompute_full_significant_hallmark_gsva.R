args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 4L) {
  stop(
    "Usage: Rscript recompute_full_significant_hallmark_gsva.R ",
    "<group_dir> <stage11_dir> <latest_stage_dir> <output_dir>"
  )
}

group_dir_arg <- normalizePath(args[[1]], winslash = "/", mustWork = TRUE)
stage11_dir <- normalizePath(args[[2]], winslash = "/", mustWork = TRUE)
latest_stage_dir <- normalizePath(args[[3]], winslash = "/", mustWork = TRUE)
output_dir <- normalizePath(
  args[[4]], winslash = "/", mustWork = FALSE
)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

user_library_45 <- file.path(
  Sys.getenv("LOCALAPPDATA"), "R", "win-library", "4.5"
)
.libPaths(c(
  user_library_45,
  file.path(latest_stage_dir, "source_data", "R_library_Seurat4"),
  file.path(stage11_dir, "source_data", "R_library"),
  file.path(latest_stage_dir, "source_data", "R_library"),
  file.path(latest_stage_dir, "source_data", "R_library_enrichment"),
  .libPaths()
))
suppressPackageStartupMessages({
  library(GSVA)
  library(Seurat)
  library(Matrix)
  library(data.table)
  library(jsonlite)
})

PIPELINE_SEED <- 20260730L
set.seed(PIPELINE_SEED)

object_path <- file.path(
  group_dir_arg,
  "02_official_Scissor",
  "02_official_Scissor_labeled_fibroblasts.rds"
)
statistics_path <- file.path(
  group_dir_arg,
  "03_DE_enrichment_GSVA",
  "05_Hallmark_GSVA_statistics.csv"
)
gmt_path <- file.path(
  stage11_dir,
  "source_data",
  "gene_sets",
  "MSigDB_Hallmark_2020.gmt"
)
required <- c(object_path, statistics_path, gmt_path)
if (!all(file.exists(required))) {
  stop("Missing required input: ", paste(required[!file.exists(required)], collapse = "; "))
}

read_gmt_list <- function(path) {
  fields <- strsplit(
    readLines(path, warn = FALSE, encoding = "UTF-8"),
    "\t",
    fixed = TRUE
  )
  names(fields) <- vapply(fields, function(item) item[[1]], character(1))
  lapply(fields, function(item) unique(item[-c(1, 2)]))
}

clean_pathway <- function(value) {
  value <- sub("^HALLMARK_", "", value)
  tools::toTitleCase(tolower(gsub("_", " ", value)))
}

safe_wilcox <- function(left, right) {
  tryCatch(
    wilcox.test(left, right, exact = FALSE)$p.value,
    error = function(error) NA_real_
  )
}

object <- readRDS(object_path)
DefaultAssay(object) <- "RNA"
selected_cells <- colnames(object)[
  object$Scissor_state %in% c("Vitamin D3-", "Vitamin D3+")
]
plus_cells <- colnames(object)[object$Scissor_state == "Vitamin D3+"]
minus_cells <- colnames(object)[object$Scissor_state == "Vitamin D3-"]
if (!identical(c(length(minus_cells), length(plus_cells)), c(1391L, 1511L))) {
  warning(
    "Selected-cell counts differ from the source analysis: minus=",
    length(minus_cells), ", plus=", length(plus_cells)
  )
}

rna_data <- GetAssayData(object, assay = "RNA", slot = "data")
hallmark <- read_gmt_list(gmt_path)
hallmark <- lapply(hallmark, intersect, y = rownames(rna_data))
hallmark <- hallmark[lengths(hallmark) >= 10 & lengths(hallmark) <= 500]
hallmark_genes <- unique(unlist(hallmark, use.names = FALSE))
gsva_expression <- as.matrix(
  rna_data[hallmark_genes, selected_cells, drop = FALSE]
)
expressed <- rowSums(gsva_expression > 0) >= 3L
gsva_expression <- gsva_expression[expressed, , drop = FALSE]
hallmark <- lapply(hallmark, intersect, y = rownames(gsva_expression))
hallmark <- hallmark[lengths(hallmark) >= 10 & lengths(hallmark) <= 500]

parameter <- gsvaParam(
  exprData = gsva_expression,
  geneSets = hallmark,
  minSize = 10,
  maxSize = 500,
  kcdf = "Gaussian",
  sparse = FALSE,
  verbose = FALSE
)
scores <- gsva(parameter, verbose = FALSE)

recalculated <- rbindlist(lapply(rownames(scores), function(pathway) {
  plus <- as.numeric(scores[pathway, plus_cells])
  minus <- as.numeric(scores[pathway, minus_cells])
  data.table(
    pathway = pathway,
    clean_pathway = clean_pathway(pathway),
    positive_n = length(plus),
    negative_n = length(minus),
    mean_positive = mean(plus),
    mean_negative = mean(minus),
    mean_difference = mean(plus) - mean(minus),
    cell_level_wilcoxon_P = safe_wilcox(plus, minus)
  )
}))
recalculated[, FDR := p.adjust(cell_level_wilcoxon_P, method = "BH")]
recalculated[, higher_in := fifelse(
  mean_difference > 0,
  "Vitamin D3+",
  "Vitamin D3-"
)]
recalculated[, significant_FDR_0_05 := FDR < 0.05]
recalculated[, absolute_mean_difference_for_order := abs(mean_difference)]
setorder(recalculated, FDR, -absolute_mean_difference_for_order)

source_stats <- fread(statistics_path)
comparison <- merge(
  source_stats[
    , .(
      pathway,
      source_mean_difference = mean_difference,
      source_P = cell_level_wilcoxon_P,
      source_FDR = FDR
    )
  ],
  recalculated[
    , .(
      pathway,
      recalculated_mean_difference = mean_difference,
      recalculated_P = cell_level_wilcoxon_P,
      recalculated_FDR = FDR
    )
  ],
  by = "pathway",
  all = TRUE
)
comparison[, mean_difference_absolute_error := abs(
  source_mean_difference - recalculated_mean_difference
)]
comparison[, P_absolute_error := abs(source_P - recalculated_P)]
comparison[, FDR_absolute_error := abs(source_FDR - recalculated_FDR)]

minus_order <- minus_cells[order(object$Scissor_coefficient[match(
  minus_cells,
  colnames(object)
)])]
plus_order <- plus_cells[order(object$Scissor_coefficient[match(
  plus_cells,
  colnames(object)
)])]
display_cells <- c(minus_order, plus_order)
significant_pathways <- recalculated[
  significant_FDR_0_05 == TRUE,
  pathway
]

full_long <- rbindlist(lapply(rownames(scores), function(pathway) {
  data.table(
    pathway = pathway,
    clean_pathway = clean_pathway(pathway),
    cell = display_cells,
    Scissor_state = as.character(
      object$Scissor_state[match(display_cells, colnames(object))]
    ),
    fibroblast_subtype = as.character(
      object$fibroblast_subtype[match(display_cells, colnames(object))]
    ),
    GSVA_score = as.numeric(scores[pathway, display_cells])
  )
}))
significant_long <- full_long[pathway %in% significant_pathways]

fwrite(
  recalculated,
  file.path(output_dir, "01_Hallmark_GSVA_all50_statistics.csv"),
  bom = TRUE
)
fwrite(
  recalculated[significant_FDR_0_05 == TRUE],
  file.path(output_dir, "02_Hallmark_GSVA_43_significant_statistics.csv"),
  bom = TRUE
)
fwrite(
  full_long,
  file.path(output_dir, "03_Hallmark_GSVA_all50_cell_scores.csv.gz"),
  compress = "gzip"
)
fwrite(
  significant_long,
  file.path(output_dir, "04_Hallmark_GSVA_43_significant_cell_scores.csv.gz"),
  compress = "gzip"
)
fwrite(
  comparison,
  file.path(output_dir, "05_recalculation_vs_source_audit.csv"),
  bom = TRUE
)
saveRDS(
  scores,
  file.path(output_dir, "06_Hallmark_GSVA_all50_score_matrix.rds"),
  compress = "xz"
)

audit <- list(
  status = "completed",
  source_object = object_path,
  source_statistics = statistics_path,
  source_gmt = gmt_path,
  R_version = R.version.string,
  Seurat_version = as.character(packageVersion("Seurat")),
  GSVA_version = as.character(packageVersion("GSVA")),
  method = "GSVA Hallmark 2020; cell-level two-sided Wilcoxon; BH FDR",
  selected_cells = length(display_cells),
  Vitamin_D3_negative = length(minus_cells),
  Vitamin_D3_positive = length(plus_cells),
  pathways_tested = nrow(recalculated),
  significant_pathways_FDR_0_05 = sum(recalculated$significant_FDR_0_05),
  higher_in_Vitamin_D3_positive = sum(
    recalculated$significant_FDR_0_05 & recalculated$mean_difference > 0
  ),
  higher_in_Vitamin_D3_negative = sum(
    recalculated$significant_FDR_0_05 & recalculated$mean_difference < 0
  ),
  max_mean_difference_absolute_error = max(
    comparison$mean_difference_absolute_error,
    na.rm = TRUE
  ),
  max_P_absolute_error = max(comparison$P_absolute_error, na.rm = TRUE),
  max_FDR_absolute_error = max(comparison$FDR_absolute_error, na.rm = TRUE)
)
write_json(
  audit,
  file.path(output_dir, "07_recalculation_audit.json"),
  pretty = TRUE,
  auto_unbox = TRUE,
  digits = 16
)

print(audit)
