from __future__ import annotations
import argparse
import json
import textwrap
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, ListedColormap, TwoSlopeNorm
from matplotlib.patches import Patch
import numpy as np
import pandas as pd
from scipy.cluster.hierarchy import dendrogram, linkage
BLUE = '#2B6CB0'
SALMON = '#EF8178'
INK = '#1F1F1F'
OUTPUT_DPI = 500
ONE_PIXEL_INCHES = 1.0 / OUTPUT_DPI
OUTPUT_STEM = 'Figure4H_GSVA_43_significant_pathways_full'

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument('--scores', type=Path, required=True)
    parser.add_argument('--statistics', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    return parser.parse_args()

def clean_label(value: str, width: int=40) -> str:
    return '\n'.join(textwrap.wrap(str(value), width=width, break_long_words=False, break_on_hyphens=False))

def rect(left: float, bottom: float, width: float, height: float, figure_width: float, figure_height: float) -> list[float]:
    return [left / figure_width, bottom / figure_height, width / figure_width, height / figure_height]

def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    matplotlib.rcParams.update({'font.family': 'Arial', 'font.sans-serif': ['Arial', 'Liberation Sans', 'DejaVu Sans'], 'font.size': 8, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none', 'axes.unicode_minus': False})
    data = pd.read_csv(args.scores, low_memory=False)
    stats = pd.read_csv(args.statistics, low_memory=False)
    expected_columns = {'pathway', 'clean_pathway', 'cell', 'Scissor_state', 'GSVA_score'}
    missing = expected_columns - set(data.columns)
    if missing:
        raise ValueError(f'Missing score columns: {sorted(missing)}')
    if len(stats) != 43 or not stats['significant_FDR_0_05'].astype(bool).all():
        raise ValueError('Expected exactly 43 BH-FDR-significant pathways.')
    data['GSVA_score'] = pd.to_numeric(data['GSVA_score'], errors='coerce')
    pathway_order = stats.sort_values(['FDR', 'pathway'])['pathway'].astype(str).tolist()
    pathway_order = [value for value in pathway_order if value in set(data['pathway'].astype(str))]
    cell_order = list(dict.fromkeys(data['cell'].astype(str)))
    state_by_cell = data[['cell', 'Scissor_state']].drop_duplicates('cell').set_index('cell')['Scissor_state'].astype(str)
    clean_by_pathway = data[['pathway', 'clean_pathway']].drop_duplicates('pathway').set_index('pathway')['clean_pathway'].astype(str)
    matrix = data.pivot_table(index='pathway', columns='cell', values='GSVA_score', aggfunc='mean', sort=False).reindex(index=pathway_order, columns=cell_order)
    if matrix.shape != (43, 2902):
        raise ValueError(f'Unexpected matrix shape: {matrix.shape}; expected (43, 2902).')
    values = np.nan_to_num(matrix.to_numpy(float), nan=0.0)
    link = linkage(values, method='average', metric='euclidean')
    figure_width = 15.0
    figure_height = 13.7
    fig = plt.figure(figsize=(figure_width, figure_height), constrained_layout=False)
    tree_left = 0.55
    tree_width = 1.2
    heat_left = tree_left + tree_width + ONE_PIXEL_INCHES
    heat_width = 8.15
    label_left = heat_left + heat_width + 0.07
    label_width = 3.25
    heat_bottom = 0.72
    heat_height = 11.7
    ax_tree = fig.add_axes(rect(tree_left, heat_bottom, tree_width, heat_height, figure_width, figure_height))
    ax_heat = fig.add_axes(rect(heat_left, heat_bottom, heat_width, heat_height, figure_width, figure_height))
    ax_labels = fig.add_axes(rect(label_left, heat_bottom, label_width, heat_height, figure_width, figure_height))
    tree = dendrogram(link, orientation='left', no_labels=True, color_threshold=0, above_threshold_color='#555555', link_color_func=lambda _: '#555555', ax=ax_tree)
    matrix = matrix.iloc[tree['leaves']]
    ax_tree.invert_yaxis()
    for collection in ax_tree.collections:
        collection.set_linewidth(0.85)
    ax_tree.margins(x=0)
    ax_tree.set_xticks([])
    ax_tree.set_yticks([])
    for spine in ax_tree.spines.values():
        spine.set_visible(False)
    gsva_cmap = LinearSegmentedColormap.from_list('gsva_reference_layout', ['#0B5AA6', '#A7C7E7', '#F7F7F7', '#F6B3AA', '#E85B52'], N=256)
    gsva_norm = TwoSlopeNorm(vmin=-0.5, vcenter=0.0, vmax=0.5)
    image = ax_heat.imshow(matrix.to_numpy(float), aspect='auto', interpolation='nearest', cmap=gsva_cmap, norm=gsva_norm, rasterized=True)
    ax_heat.set_xticks([])
    ax_heat.set_yticks([])
    ax_heat.set_xlabel('Scissor-selected fibroblasts', fontsize=9.3, labelpad=7)
    boundary = sum(state_by_cell.reindex(cell_order).eq('Vitamin D3-'))
    if 0 < boundary < len(cell_order):
        ax_heat.axvline(boundary - 0.5, color='white', linewidth=1.2)
    strip_values = np.array([0 if state_by_cell.loc[cell] == 'Vitamin D3-' else 1 for cell in cell_order])[None, :]
    strip = fig.add_axes(rect(heat_left, heat_bottom + heat_height + 0.055, heat_width, 0.2, figure_width, figure_height))
    strip.imshow(strip_values, aspect='auto', cmap=ListedColormap([BLUE, SALMON]), interpolation='nearest')
    strip.set_xticks([])
    strip.set_yticks([])
    for spine in strip.spines.values():
        spine.set_visible(False)
    fig.text((heat_left - 0.045) / figure_width, (heat_bottom + heat_height + 0.155) / figure_height, 'Group', ha='right', va='center', fontsize=9, fontweight='bold')
    ax_labels.set_xlim(0, 1)
    ax_labels.set_ylim(len(matrix.index) - 0.5, -0.5)
    ax_labels.axis('off')
    figure_order = []
    for row_index, pathway in enumerate(matrix.index.astype(str)):
        label = str(clean_by_pathway.get(pathway, pathway))
        if label == 'Pperoxisome':
            label = 'Peroxisome'
        ax_labels.text(0.0, row_index, clean_label(label, 40), ha='left', va='center', fontsize=7.65, color=INK, linespacing=1.0)
        figure_order.append((row_index + 1, pathway, label))
    cax = fig.add_axes(rect(13.63, 8.75, 0.15, 2.0, figure_width, figure_height))
    colorbar = fig.colorbar(image, cax=cax, extend='both')
    colorbar.set_label('GSVA score', fontsize=8.5)
    colorbar.set_ticks([-0.5, -0.25, 0.0, 0.25, 0.5])
    colorbar.ax.tick_params(labelsize=7.5)
    fig.legend(handles=[Patch(color=BLUE, label='Vitamin D3- (n=1,391)'), Patch(color=SALMON, label='Vitamin D3+ (n=1,511)')], title='Group', loc='upper left', bbox_to_anchor=(13.38 / figure_width, 8.35 / figure_height), bbox_transform=fig.transFigure, frameon=False, fontsize=8, title_fontsize=8.5, borderaxespad=0)
    fig.text(13.38 / figure_width, 6.35 / figure_height, 'Significant pathways\nBH FDR < 0.05: 43/50\nHigher mean in D3+: 19\nHigher mean in D3-: 24', ha='left', va='top', fontsize=8.0, linespacing=1.45, color=INK)
    fig.text(0.035, 0.972, 'H', fontsize=23, ha='left', va='top')
    fig.text(heat_left / figure_width, 0.972, 'Hallmark GSVA pathways significantly different between Scissor groups', fontsize=15.5, fontweight='bold', ha='left', va='top', color=INK)
    fig.text(heat_left / figure_width, 0.946, 'GSE164241 healthy gingival fibroblasts; cell-level Wilcoxon test with BH correction', fontsize=9.2, ha='left', va='top', color='#555555')
    stem = args.output_dir / OUTPUT_STEM
    metadata = {'Creator': 'Matplotlib', 'Title': OUTPUT_STEM}
    fig.savefig(stem.with_suffix('.pdf'), facecolor='white', metadata=metadata)
    fig.savefig(stem.with_suffix('.png'), facecolor='white', dpi=OUTPUT_DPI)
    fig.savefig(stem.with_suffix('.svg'), facecolor='white', metadata=metadata)
    plt.close(fig)
    order_table = pd.DataFrame(figure_order, columns=['row_from_top', 'pathway', 'display_label']).merge(stats[['pathway', 'mean_positive', 'mean_negative', 'mean_difference', 'higher_in', 'cell_level_wilcoxon_P', 'FDR']], on='pathway', how='left')
    order_table.to_csv(args.output_dir / '08_pathway_order_and_statistics_in_figure.csv', index=False, encoding='utf-8-sig')
    audit = {'status': 'completed', 'matrix_rows': int(matrix.shape[0]), 'matrix_columns': int(matrix.shape[1]), 'Vitamin_D3_negative': int(boundary), 'Vitamin_D3_positive': int(len(cell_order) - boundary), 'all_43_labels_drawn': len(figure_order) == 43, 'tree_to_heatmap_gap_inches': ONE_PIXEL_INCHES, 'tree_to_heatmap_gap_pixels_at_500_dpi': 1, 'page_inches': [figure_width, figure_height], 'outputs': [str(stem.with_suffix(ext)) for ext in ('.pdf', '.png', '.svg')]}
    (args.output_dir / '09_figure_audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
if __name__ == '__main__':
    main()
