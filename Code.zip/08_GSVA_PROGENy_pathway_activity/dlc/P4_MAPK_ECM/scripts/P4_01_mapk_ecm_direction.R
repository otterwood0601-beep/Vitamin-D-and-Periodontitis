options(stringsAsFactors = FALSE)
source("E:/\u8840\u6e05\u7ef4\u751f\u7d20D DLC/00_\u5171\u7528\u914d\u7f6e/project_paths.R")
PROJ <- "P4_MAPK_ECM"; ensure_dirs(PROJ)
FIG <- SEG_FIGDIR(PROJ); SD <- SEG_SRC(PROJ); QA <- SEG_QA(PROJ)

suppressPackageStartupMessages({
  library(data.table); library(ggplot2); library(patchwork); library(fgsea)
  library(GSVA)
})
set.seed(20260910L)
t0 <- Sys.time()

P1_SD <- file.path(WORK, "P1_\u75be\u75c5\u72b6\u6001\u9a8c\u8bc1/outputs/02_source_data")
DON_PB_GZ <- file.path(P1_SD, "06_donor_pseudobulk_log2CPM.csv.gz")
DON_META  <- file.path(P1_SD, "05_pseudobulk_unit_metadata.csv")

cat("[0] load disease/VD signatures + locked modules\n")
dis <- fread(DE_DONOR_GZ)
dis <- dis[, .(gene, lfc_disease = log2FC_periodontitis_minus_healthy,
               t_disease = t_statistic, p_disease = p_value, fdr_disease = FDR)]
dis <- dis[!is.na(t_disease)]

vd <- fread(DESEQ_ALL)[!is.na(gene_symbol), .(gene = gene_symbol,
                                               lfc_vd = log2FoldChange,
                                               stat_vd = stat,
                                               fdr_vd = padj)][!duplicated(gene)]

gmt <- list()
for (ln in readLines(file.path(WORK, "01_\u6570\u636e\u51c6\u5907/outputs/curated_gene_sets_v1.gmt"))) {
  p <- strsplit(ln, "\t", fixed = TRUE)[[1]]
  gmt[[p[1]]] <- p[-c(1, 2)]
}

m <- merge(dis, vd, by = "gene", all = FALSE)
cat("    genes with both signatures:", nrow(m), "\n")
fwrite(m, file.path(SD, "01_disease_vs_vitaminD_logFC_integration.csv"))

MAPK_SETS <- list(MAPK_ERK = gmt$MAPK_ERK_transcriptional_response,
                  MAPK_JNK_p38 = gmt$MAPK_JNK_p38_transcriptional_response)
ECM_SETS <- list(ECM_synthesis_collagen = gmt$ECM_synthesis_collagen,
                 ECM_organization = gmt$ECM_organization_structure,
                 ECM_degradation_MMP = gmt$ECM_degradation_MMP_ADAMTS,
                 ECM_inhibitors_TIMP = gmt$ECM_inhibitors_TIMP,
                 ECM_adhesion_integrin = gmt$ECM_adhesion_integrin)

cat("[A] GSEA NES direction across disease vs VD\n")
run_gsea <- function(set_list, stat_vec, minSize = 5, maxSize = 2000) {
  fgseaMultilevel(pathways = set_list, stats = stat_vec, minSize = minSize,
                  maxSize = maxSize, eps = 1e-50,
                  BPPARAM = BiocParallel::SerialParam())
}
rk_d <- dis[order(-t_disease)]$t_disease; names(rk_d) <- dis[order(-t_disease)]$gene
rk_v <- vd[order(-stat_vd)]$stat_vd; names(rk_v) <- vd[order(-stat_vd)]$gene

all_sets <- c(MAPK_SETS, ECM_SETS)
fg_d <- run_gsea(all_sets, rk_d); fg_d <- as.data.table(fg_d)[, .(program = pathway, NES_disease = NES, FDR_disease = padj)]
fg_v <- run_gsea(all_sets, rk_v); fg_v <- as.data.table(fg_v)[, .(program = pathway, NES_vd = NES, FDR_vd = padj)]
gsea_out <- merge(fg_d, fg_v, by = "program")
gsea_out[, FDR_disease := fifelse(FDR_disease <= 0, 1e-99, FDR_disease)]
gsea_out[, FDR_vd := fifelse(FDR_vd <= 0, 1e-99, FDR_vd)]
fwrite(gsea_out, file.path(SD, "02_program_NES_direction.csv"))

star_fun <- function(f) fifelse(f < 1e-3, "***", fifelse(f < 1e-2, "**", fifelse(f < 0.05, "*", "")))
gl <- melt(gsea_out, id.vars = c("program", "FDR_disease", "FDR_vd"),
           measure.vars = c("NES_disease", "NES_vd"),
           variable.name = "cmp", value.name = "NES")
gl[, array := fifelse(cmp == "NES_disease", "Periodontitis vs healthy", "Vitamin D3 vs ethanol")]
gl[, fdr := fifelse(cmp == "NES_disease", FDR_disease, FDR_vd)]
gl[, star := star_fun(fdr)]
gl[, lab := sprintf("%.2f%s", NES, star)]
gl[, program := factor(program, levels = rev(names(all_sets)))]
gl[, array := factor(array, levels = c("Periodontitis vs healthy", "Vitamin D3 vs ethanol"))]
vlim <- max(abs(gl$NES), na.rm = TRUE) * 1.1
gpA <- ggplot(gl, aes(array, program, fill = NES)) +
  geom_tile(colour = "white", linewidth = 0.6) +
  geom_text(aes(label = lab), size = 2.4) +
  scale_fill_gradient2(low = "#2166AC", mid = "#F7F7F7", high = "#B2182B",
                       midpoint = 0, limits = c(-vlim, vlim), name = "NES (fgsea)") +
  labs(x = NULL, y = NULL,
       title = "MAPK / ECM program direction: disease vs vitamin D",
       subtitle = "NES of locked sets against each ranking; * p<0.05 ** p<0.01 *** p<0.001 (BH)") +
  THEME_NPJ +
  theme(axis.text.x = element_text(angle = 20, hjust = 1),
        plot.tag = element_text(face = "bold", size = 12), plot.tag.position = "topleft") +
  labs(tag = "A")
ggsave(file.path(FIG, "\u56feP4A_MAPK_ECM\u7a0b\u5e8f\u65b9\u5411\u70ed\u56fe.pdf"), gpA, width = 4.4, height = 3.0)
ggsave(file.path(FIG, "\u56feP4A_MAPK_ECM\u7a0b\u5e8f\u65b9\u5411\u70ed\u56fe.png"), gpA, width = 4.4, height = 3.0, dpi = 300)

cat("[B] MAPK immediate-response gene heatmap\n")
mk_genes <- unique(c(intersect(gmt$MAPK_ERK_transcriptional_response, m$gene),
                     intersect(gmt$MAPK_JNK_p38_transcriptional_response, m$gene)))
sub <- m[gene %in% mk_genes, .(gene, t_disease, stat_vd)]
sub <- sub[order(-abs(t_disease))]

stab_max <- max(abs(sub$stat_vd), na.rm = TRUE)
fwrite(sub, file.path(SD, "03_MAPK_response_genes_tstats.csv"))
mlong <- melt(sub, id.vars = "gene", measure.vars = c("t_disease", "stat_vd"),
              variable.name = "cmp", value.name = "value")
mlong[, cmp := factor(cmp, levels = c("t_disease", "stat_vd"),
                      labels = c("Disease t", "VitD3 stat"))]
mlong[, gene := factor(gene, levels = sub$gene)]
vmaxB <- max(abs(mlong$value), na.rm = TRUE)
gpB <- ggplot(mlong, aes(cmp, gene, fill = value)) +
  geom_tile(colour = "white", linewidth = 0.4) +
  scale_fill_gradient2(low = "#2166AC", mid = "#F7F7F7", high = "#B2182B",
                       midpoint = 0, limits = c(-vmaxB, vmaxB), name = "statistic") +
  labs(x = NULL, y = NULL, title = "MAPK immediate-response genes: disease vs vitamin D") +
  THEME_NPJ +
  theme(axis.text.x = element_text(angle = 20, hjust = 1),
        axis.text.y = element_text(size = 5),
        plot.tag = element_text(face = "bold", size = 12), plot.tag.position = "topleft") +
  labs(tag = "B")
ggsave(file.path(FIG, "\u56feP4B_MAPK\u5e94\u7b54\u57fa\u56e0\u8de8\u6570\u636e\u70ed\u56fe.pdf"), gpB, width = 3.0, height = max(3, nrow(sub) * 0.16), limitsize = FALSE)
ggsave(file.path(FIG, "\u56feP4B_MAPK\u5e94\u7b54\u57fa\u56e0\u8de8\u6570\u636e\u70ed\u56fe.png"), gpB, width = 3.0, height = max(3, nrow(sub) * 0.16), limitsize = FALSE, dpi = 300)

cat("[C] donor-level ssGSEA footprint (GSVA ssgsea)\n")
pb <- as.matrix(fread(DON_PB_GZ))   
rownames(pb) <- pb[, 1]; pb <- pb[, -1, drop = FALSE]
storage.mode(pb) <- "double"
pb <- pb[rowSums(!is.na(pb)) == ncol(pb), , drop = FALSE]

if (any(!is.finite(pb))) { fl <- min(pb[is.finite(pb)], na.rm = TRUE) - 1; pb[!is.finite(pb)] <- fl }
meta <- fread(DON_META)
don_meta <- meta[, .(donor_id = unique(donor_id), disease = unique(disease)), by = donor_id]

param <- ssgseaParam(exprData = pb, geneSets = all_sets, minSize = 5, maxSize = 2000,
                     normalize = TRUE, verbose = FALSE)
ss <- gsva(param, verbose = FALSE)
ss_dt <- as.data.table(ss, keep.rownames = "program")
foot <- melt(ss_dt, id.vars = "program", variable.name = "donor", value.name = "score")
foot[, donor := as.character(donor)]
foot[, disease := don_meta$disease[match(donor, don_meta$donor_id)]]
fwrite(foot, file.path(SD, "04_donor_program_footprint_ssGSEA.csv"))

foot_stats <- foot[, {
  h <- score[disease == "normal"]; p <- score[disease == "periodontitis"]
  wt <- suppressWarnings(wilcox.test(h, p, exact = FALSE))
  data.table(n_h = length(h), n_p = length(p),
             median_h = median(h), median_p = median(p),
             diff = median(p) - median(h),
             p_wilcox = wt$p.value)
}, by = program]
foot_stats[, p_BH := p.adjust(p_wilcox, "BH")]
fwrite(foot_stats, file.path(SD, "05_donor_program_footprint_stats.csv"))

fp <- melt(foot_stats, id.vars = c("program", "p_BH"),
           measure.vars = c("median_h", "median_p"),
           variable.name = "grp", value.name = "med")
fp[, grp := fifelse(grp == "median_h", "Healthy", "Periodontitis")]
fp[, star := star_fun(p_BH)]
fp[, lab := sprintf("%.2f%s", med, star)]
fp[, program := factor(program, levels = rev(names(all_sets)))]
gpC <- ggplot(fp, aes(grp, program, fill = med)) +
  geom_tile(colour = "white", linewidth = 0.6) +
  geom_text(aes(label = lab), size = 2.4) +
  scale_fill_gradient2(low = "#2166AC", mid = "#F7F7F7", high = "#B2182B", midpoint = 0, name = "median ssGSEA") +
  labs(x = NULL, y = NULL,
       title = "Donor-level program footprint (GSVA ssGSEA), PD vs healthy",
       subtitle = "Median ssGSEA score per program; stars = donor-level Wilcoxon (BH)") +
  THEME_NPJ +
  theme(axis.text.x = element_text(angle = 20, hjust = 1),
        plot.tag = element_text(face = "bold", size = 12), plot.tag.position = "topleft") +
  labs(tag = "C")
ggsave(file.path(FIG, "\u56feP4C_\u4f9b\u8005\u7ea7\u7a0b\u5e8f\u8db3\u8ff9\u70ed\u56fe.pdf"), gpC, width = 4.4, height = 2.8)
ggsave(file.path(FIG, "\u56feP4C_\u4f9b\u8005\u7ea7\u7a0b\u5e8f\u8db3\u8ff9\u70ed\u56fe.png"), gpC, width = 4.4, height = 2.8, dpi = 300)

val <- list(created_at = format(Sys.time()), n_genes_merged = nrow(m),
            gsea_NES = gsea_out,
            donor_footprint = foot_stats,
            caveat = paste(
              "MAPK transcript footprint (ssGSEA/GSEA) is expression-based inference, NOT p-ERK protein measurement.",
              "ECM program decrease does not automatically equal tissue protection. GSE212728 has 3 treated vs 2 control",
              "samples and no patient-level intervention; cross-dataset direction is associative, not in-vivo reversal."),
            sessionInfo = paste(capture.output(sessionInfo()), collapse = "\n"))
writeLines(jsonlite::toJSON(val, pretty = TRUE, auto_unbox = TRUE, na = "null", digits = 6),
           file.path(QA, "P4_QA_report.json"))
cat("[done] P4 in", round(as.numeric(difftime(Sys.time(), t0, units = "mins")), 2), "min\n")
