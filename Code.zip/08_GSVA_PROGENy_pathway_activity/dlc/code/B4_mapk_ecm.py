import os, sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats as st
import gseapy as gp
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from style_npj import set_npj_style, save_npj, NPJ_CASE, NPJ_CTRL, MM
set_npj_style()
DER = 'C:\\wb_links\\dlc_derived'
OUTDIR = 'C:\\wb_links\\dlc_out\\\u6838\u5fc3\u7ed3\u679cB_MAPK_ECM'
os.makedirs(OUTDIR, exist_ok=True)
m = pd.read_csv(os.path.join(DER, 'B3_gene_level_merged_disease_vs_VD.csv'))
progeny_score = {}
progeny_p = {}
try:
    import decoupler as dc
    net_path = os.path.join(DER, 'B4_PROGENy_human_top500_network.csv')
    if os.path.exists(net_path):
        net = pd.read_csv(net_path)
    else:
        net = dc.op.progeny(organism='human', top=500)
    net = net[net['target'].isin(m.symbol)]
    for tag, col in [('Disease', 'dis_t'), ('VitaminD3', 'vd_stat')]:
        mat = m.groupby('symbol', as_index=True)[col].mean().to_frame().T
        if hasattr(dc, 'mt') and hasattr(dc.mt, 'ulm'):
            est, pvals = dc.mt.ulm(mat, net, verbose=False)
            progeny_score[tag] = est.iloc[0]
            progeny_p[tag] = pvals.iloc[0]
        else:
            est, norm, pvals = dc.run_ulm(mat=mat, net=net, source='source', target='target', weight='weight', verbose=False)
            progeny_score[tag] = norm.iloc[0]
            progeny_p[tag] = pvals.iloc[0]
    pro = pd.DataFrame(progeny_score)
    pro.index.name = 'pathway'
    pro.to_csv(os.path.join(DER, 'B4_PROGENy_ULM_scores.csv'))
    pp = pd.DataFrame(progeny_p).reindex(pro.index)
    qv = pp.copy()
    for c in qv.columns:
        p = pp[c].to_numpy(float)
        o = np.argsort(p)
        q = np.empty_like(p)
        z = p[o] * len(p) / np.arange(1, len(p) + 1)
        z = np.minimum.accumulate(z[::-1])[::-1]
        q[o] = np.minimum(z, 1.0)
        qv[c] = q
    long = []
    for pathway in pro.index:
        for contrast in pro.columns:
            long.append({'pathway': pathway, 'contrast': contrast, 'activity': pro.loc[pathway, contrast], 'p': pp.loc[pathway, contrast], 'FDR': qv.loc[pathway, contrast]})
    pd.DataFrame(long).to_csv(os.path.join(DER, 'B4_PROGENy_ULM_full_results.csv'), index=False)
    print('PROGENy done')
    print(pro.loc[['MAPK', 'EGFR', 'TGFb', 'NFkB', 'PI3K']] if 'MAPK' in pro.index else pro.head())
except Exception as e:
    print('PROGENy failed:', repr(e))
    pro = None
ECM_SETS = {'ECM synthesis/assembly': ['COL1A1', 'COL1A2', 'COL3A1', 'COL5A1', 'COL5A2', 'COL6A1', 'COL6A2', 'COL6A3', 'DCN', 'LUM', 'FBN1', 'FMOD', 'BGN', 'ELN', 'FN1', 'SPARC', 'P4HA1', 'P4HA2', 'PLOD1', 'PLOD2', 'LOX', 'LOXL1', 'LOXL2', 'SERPINH1', 'ADAMTS2', 'PCOLCE'], 'ECM proteases (degradation)': ['MMP1', 'MMP2', 'MMP3', 'MMP9', 'MMP13', 'MMP14', 'MMP16', 'MMP19', 'ADAMTS1', 'ADAMTS4', 'ADAMTS5', 'CTSK', 'CTSL', 'CTSB', 'PLAU', 'PLAT'], 'ECM protease inhibitors': ['TIMP1', 'TIMP2', 'TIMP3', 'SERPINE1', 'SERPINB2', 'CSTA'], 'ECM adhesion/signaling': ['ITGA1', 'ITGA2', 'ITGA5', 'ITGA11', 'ITGAV', 'ITGB1', 'ITGB3', 'ITGB5', 'SDC1', 'SDC2', 'SDC4', 'HSPG2', 'VCAN', 'THBS1', 'THBS2', 'POSTN', 'TNC', 'LAMA4', 'LAMB1', 'LAMC1', 'DAG1', 'CD36']}
MAPK_SET = {'MAPK/ERK immediate response': ['FOS', 'FOSB', 'JUN', 'JUNB', 'JUND', 'EGR1', 'EGR2', 'EGR3', 'DUSP1', 'DUSP4', 'DUSP5', 'DUSP6', 'DUSP10', 'MYC', 'IER2', 'IERS', 'NR4A1', 'NR4A2', 'ATF3', 'KLF2', 'KLF4', 'KLF6', 'ZFP36', 'BTG2', 'CYR61', 'CTGF']}
ALL_SETS = {**ECM_SETS, **MAPK_SET}

def gsea_one(rank_col, sets):
    rnk = m[['symbol', rank_col]].dropna()
    pre = gp.prerank(rnk=rnk, gene_sets=sets, permutation_num=1000, seed=42, threads=4, min_size=5, max_size=2000, outdir=None, verbose=False)
    r = pre.res2d[['Term', 'ES', 'NES', 'NOM p-val', 'FDR q-val']].copy()
    r.columns = ['term', 'ES', 'NES', 'p', 'FDR']
    return r.set_index('term')
g_dis = gsea_one('dis_t', ALL_SETS)
g_vd = gsea_one('vd_stat', ALL_SETS)
both = g_dis[['NES', 'FDR']].rename(columns={'NES': 'NES_disease', 'FDR': 'FDR_disease'}).join(g_vd[['NES', 'FDR']].rename(columns={'NES': 'NES_vitaminD3', 'FDR': 'FDR_vitaminD3'}))
both.to_csv(os.path.join(DER, 'B4_ECM_MAPK_GSEA_both.csv'))
print(both.to_string())
mk = ALL_SETS['MAPK/ERK immediate response']
sub = m[m.symbol.isin(mk)].set_index('symbol')[['dis_t', 'vd_stat']]
sub = sub.loc[sub.dis_t.abs().sort_values(ascending=False).index]
sub.to_csv(os.path.join(DER, 'B4_MAPK_response_genes_tstats.csv'))
fig = plt.figure(figsize=(180 * MM, 100 * MM))
gs = fig.add_gridspec(1, 2, width_ratios=[1.0, 1.15], wspace=0.35, left=0.17, right=0.97, top=0.84, bottom=0.16)
axA = fig.add_subplot(gs[0, 0])
terms = list(both.index)[::-1]
short = {'ECM synthesis/assembly': 'ECM synthesis', 'ECM proteases (degradation)': 'ECM proteases', 'ECM protease inhibitors': 'ECM inhibitors', 'ECM adhesion/signaling': 'ECM adhesion', 'MAPK/ERK immediate response': 'MAPK/ERK response'}
mat = both.loc[terms, ['NES_disease', 'NES_vitaminD3']].values
vmax = np.nanmax(np.abs(mat)) * 1.05
im = axA.imshow(mat, cmap='RdBu_r', vmin=-vmax, vmax=vmax, aspect='auto')
axA.set_xticks([0, 1])
axA.set_xticklabels(['Disease\n(PD\u2212healthy)', 'Vitamin D3\n(D3\u2212ethanol)'], fontsize=7)
axA.set_yticks(range(len(terms)))
axA.set_yticklabels([short.get(t, t) for t in terms], fontsize=7)
for i, t in enumerate(terms):
    for j, c in enumerate(['disease', 'vitaminD3']):
        fdr = both.loc[t, f'FDR_{c}']
        star = '***' if fdr < 0.001 else '**' if fdr < 0.01 else '*' if fdr < 0.05 else ''
        axA.text(j, i, f'{mat[i, j]:.2f}\n{star}', ha='center', va='center', fontsize=6.5, color='white' if abs(mat[i, j]) > vmax * 0.55 else 'black')
cb = fig.colorbar(im, ax=axA, fraction=0.03, pad=0.02)
cb.set_label('NES (GSEA)', fontsize=7)
cb.ax.tick_params(labelsize=6)
axA.set_title('Functional program direction', fontsize=8, fontweight='bold', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=0.35'))
fig.text(0.1, 0.92, 'A', fontsize=12, fontweight='bold')
axB = fig.add_subplot(gs[0, 1])
genes = sub.index.tolist()
mat2 = sub[['dis_t', 'vd_stat']].values
vmax2 = np.nanmax(np.abs(mat2))
im2 = axB.imshow(mat2, cmap='RdBu_r', vmin=-vmax2, vmax=vmax2, aspect='auto')
axB.set_xticks([0, 1])
axB.set_xticklabels(['Disease t', 'VD3 stat'], fontsize=7)
axB.set_yticks(range(len(genes)))
axB.set_yticklabels(genes, fontsize=6)
cb2 = fig.colorbar(im2, ax=axB, fraction=0.03, pad=0.02)
cb2.set_label('t-statistic', fontsize=7)
cb2.ax.tick_params(labelsize=6)
axB.set_title('MAPK/ERK immediate-response genes', fontsize=8, fontweight='bold', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=0.35'))
fig.text(0.52, 0.92, 'B', fontsize=12, fontweight='bold')
save_npj(fig, os.path.join(OUTDIR, '\u6838\u5fc3\u7ed3\u679cB_MAPK_ECM_\u65b9\u5411\u70ed\u56fe_20260914'), width_mm=180, height_mm=100, dpi=600)
print('FIG SAVED')
if pro is not None:
    order = pro['Disease'].sort_values().index.tolist()
    pmat = pro.loc[order, ['Disease', 'VitaminD3']].values
    pvmax = np.nanmax(np.abs(pmat))
    figp, axp = plt.subplots(figsize=(180 * MM, 92 * MM))
    figp.subplots_adjust(left=0.25, right=0.88, top=0.84, bottom=0.16)
    imp = axp.imshow(pmat, cmap='RdBu_r', vmin=-pvmax, vmax=pvmax, aspect='auto')
    axp.set_xticks([0, 1])
    axp.set_xticklabels(['Disease\n(PD\u2212healthy)', 'Vitamin D3\n(D3\u2212ethanol)'], fontsize=7)
    axp.set_yticks(range(len(order)))
    axp.set_yticklabels(order, fontsize=7)
    for i in range(len(order)):
        for j in range(2):
            axp.text(j, i, f'{pmat[i, j]:.2f}', ha='center', va='center', fontsize=6, color='white' if abs(pmat[i, j]) > pvmax * 0.55 else 'black')
    cbp = figp.colorbar(imp, ax=axp, fraction=0.035, pad=0.025)
    cbp.set_label('PROGENy ULM activity', fontsize=7)
    cbp.ax.tick_params(labelsize=6)
    axp.set_title('PROGENy transcriptional footprint (top 500 genes/pathway)', fontsize=8, fontweight='bold', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=0.35'))
    figp.text(0.08, 0.92, 'A', fontsize=12, fontweight='bold')
    save_npj(figp, os.path.join(OUTDIR, '\u7b2c4\u9879_PROGENy\u8f6c\u5f55\u8db3\u8ff9_20260914'), width_mm=180, height_mm=92, dpi=600)
    print('PROGENy FIG SAVED')
