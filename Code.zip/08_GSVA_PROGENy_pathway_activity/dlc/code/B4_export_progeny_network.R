suppressPackageStartupMessages(library(progeny))

model <- getModel(organism = "Human", top = 500)
network <- data.frame(
  target = rep(rownames(model), times = ncol(model)),
  source = rep(colnames(model), each = nrow(model)),
  weight = as.vector(as.matrix(model)),
  stringsAsFactors = FALSE
)
network <- network[network$weight != 0, ]
write.csv(
  network,
  "C:/wb_links/dlc_derived/B4_PROGENy_human_top500_network.csv",
  row.names = FALSE
)
cat(nrow(network), "non-zero edges;", length(unique(network$source)), "pathways\n")
