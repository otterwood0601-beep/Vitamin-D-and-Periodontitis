suppressPackageStartupMessages({library(data.table);library(jsonlite)})
ROOT <- 'C:/wb_links/williams_vd47_global_20261008'
OLD <- 'C:/wb_links/williams_vd47_full_20261008'
old_pdf <- file.path(OLD,'figures','Fig1F_J_K_VD35_correlation_Bisque_JHazMat_style_20261008.pdf')
old_md5 <- tools::md5sum(old_pdf)
render <- tempfile('bulk_global_',tmpdir='C:/wb_temp')
dir.create(render)
render <- normalizePath(render,winslash='/',mustWork=TRUE)
code <- readLines(file.path(OLD,'code','04_original_bulk_recipe_adapted.R'))
code <- gsub(OLD,ROOT,code,fixed=TRUE)
code[grep('^FD <-',code)] <- paste0('FD <- "',render,'"')
stopifnot(sum(grepl('), by = dataset]',code,fixed=TRUE))==1L)
code <- gsub('), by = dataset]',')]',code,fixed=TRUE)
code <- code[!grepl('assoc[, FDR_high_low :=',code,fixed=TRUE)]
code <- gsub('Within-cohort VD35','Global-median VD35',code,fixed=TRUE)
code <- gsub('20261008.pdf','20261008_global_median_corrected.pdf',code,fixed=TRUE)
code <- gsub('20261008.png','20261008_global_median_corrected.png',code,fixed=TRUE)
idx <- grep('^pdf_path <-',code)
code <- append(code,c(
  'fig <- ggdraw() + draw_plot(fig,x=0,y=0.06,width=1,height=0.94) +',
  '  draw_label("Global median across all 44 gingival bulk samples; all p values raw (unadjusted). Cohort covariate retained in association models.",',
  '             x=0.005,y=0.015,hjust=0,vjust=0,fontfamily="Arial",size=6.5)'
),after=idx-1L)
writeLines(code,file.path(ROOT,'code','02_bulk_global_recipe.R'))
eval(parse(text=code),envir=.GlobalEnv)
stopifnot(nrow(vd17)==44L,length(sig_genes)==35L)
cut <- median(vd17$VD35_score)
stopifnot(all(as.character(vd17$score_group)==ifelse(vd17$VD35_score>cut,'High','Low')))
stopifnot(file.copy(c(pdf_path,png_path),file.path(ROOT,'figures'),overwrite=FALSE))
manifest$global_threshold <- cut
manifest$grouping <- 'one median across all 44 bulk samples, not a separate median in each cohort'
manifest$raw_p_no_multiplicity_correction <- TRUE
manifest$cohort_covariate_retained <- TRUE
manifest$group_counts <- as.list(vd17[,.N,by=score_group])
manifest$output <- file.path(ROOT,'figures',basename(manifest$output))
manifest$unchanged_components <- 'F gene correlations and K continuous partial correlation have no median dependence'
write_json(manifest,file.path(ROOT,'source_data','21_Fig1F_J_K_manifest.json'),pretty=TRUE,auto_unbox=TRUE)
fwrite(vd17,file.path(ROOT,'source_data','28_bulk_K_exact_plotted_variables.csv'))
stopifnot(identical(unname(old_md5),unname(tools::md5sum(old_pdf))))
cat('Bulk global threshold:',cut,'\n');print(vd17[,.N,by=score_group]);print(assoc)
