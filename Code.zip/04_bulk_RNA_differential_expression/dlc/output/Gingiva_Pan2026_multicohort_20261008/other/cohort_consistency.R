.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(limma);library(jsonlite)})
SD <- 'C:/wb_links/pan_multicohort_20261008_other'
obj <- readRDS(file.path(SD,'08_normalized_cohorts.rds'))
meta <- obj$meta;expr <- obj$pooled_before
axis <- c('GDF15','MAPK1','MAPK3','MMP1','MMP3')
res <- list();stats <- list()
for(acc in unique(meta$dataset)){
  m <- meta[dataset!=acc];idx <- match(m$sample,colnames(expr))
  m[,group:=factor(group,levels=c('Control','Periodontitis'))]
  f <- if(uniqueN(m$EBV_binary)>1)~group+batch+EBV_binary else ~group+batch
  design <- model.matrix(f,m)
  stopifnot(qr(design)$rank==ncol(design))
  fit <- eBayes(lmFit(expr[,idx,drop=FALSE],design),trend=TRUE,robust=TRUE)
  d <- as.data.table(topTable(fit,coef='groupPeriodontitis',number=Inf),keep.rownames='gene')
  d[,removed_cohort:=acc]
  res[[acc]] <- d[gene %in% axis]
  stats[[acc]] <- data.table(removed_cohort=acc,N=nrow(m),
    strict_DEGs=sum(d$adj.P.Val<.05 & abs(d$logFC)>1))
}
fwrite(rbindlist(res),file.path(SD,'13_leave_one_cohort_out_axis.csv'))
fwrite(rbindlist(stats),file.path(SD,'13_leave_one_cohort_out_DEG_counts.csv'))
individual <- rbindlist(lapply(unique(meta$dataset),function(acc){
  d <- fread(file.path(SD,paste0('08_',acc,'_DE.csv.gz')))
  d[gene %in% axis][,dataset:=acc]
}),fill=TRUE)
fwrite(individual,file.path(SD,'13_axis_results_each_cohort.csv'))
print(rbindlist(stats));print(individual[,.(dataset,gene,logFC,adj.P.Val)])
