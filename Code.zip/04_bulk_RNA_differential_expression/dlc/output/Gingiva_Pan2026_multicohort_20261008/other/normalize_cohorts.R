options(stringsAsFactors=FALSE,scipen=999)
.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(edgeR);library(limma);library(jsonlite)})
SD <- 'C:/wb_links/pan_multicohort_20261008_other'
meta <- fread(file.path(SD,'04_model_sample_metadata.csv'))
meta <- meta[dataset!='GSE106090']
stopifnot(nrow(meta)==72,!anyDuplicated(meta$unique_id))
cohorts <- split(meta,by='dataset',keep.by=TRUE)
exprs <- list(); quality <- list(); single_de <- list()
for (acc in names(cohorts)) {
  message('Normalize ',acc)
  m <- cohorts[[acc]]
  if (acc=='GSE223328') {
    raw <- fread(file.path(SD,'07_GSE223328_processed_gene_expression.csv.gz'))
  } else if(acc=='GSE243173') {
    raw <- fread(file.path(SD,'07_GSE243173_gene_counts.csv.gz'))
  } else {
    name <- if(acc=='GSE173078') 'GSE173078_rnaseq_raw_counts.txt.gz' else 'GSE223924_raw_count.csv.gz'
    raw <- fread(file.path('C:/wb_links/dlc_data',paste0('external_',acc),name))
  }
  setnames(raw,1,'gene')
  stopifnot(!anyDuplicated(raw$gene),all(m$sample %in% names(raw)))
  selected <- m$sample
  x <- as.matrix(raw[,..selected]);storage.mode(x)<-'double';rownames(x)<-raw$gene
  stopifnot(all(is.finite(x)))
  if (acc!='GSE223328') {
    stopifnot(all(x>=0),all(x==round(x)))
    y <- DGEList(x)
    keep <- filterByExpr(y,group=m$group,min.count=5)
    y <- calcNormFactors(y[keep,,keep.lib.sizes=FALSE])
    x <- cpm(y,log=TRUE,prior.count=.5)
    normalization <- 'edgeR TMM log2 CPM; raw counts do not support invented TPM gene lengths'
  } else normalization <- 'Public log2 quantile-normalized Agilent matrix, mapped probes averaged by gene'
  m[,group:=factor(group,levels=c('Control','Periodontitis'))]
  m[,EBV_binary:=as.integer(EBV=='EBV-positive')]
  if (acc=='GSE173078') {
    m[,within_batch:=factor(batch)]
    design <- model.matrix(~ group+within_batch,m)
  } else if(acc=='GSE223328') design <- model.matrix(~group+EBV_binary,m)
  else design <- model.matrix(~group,m)
  fit <- eBayes(lmFit(x,design),trend=TRUE,robust=TRUE)
  d <- as.data.table(topTable(fit,coef='groupPeriodontitis',number=Inf),keep.rownames='gene')
  d[,strict_Pan_DEG:=adj.P.Val<.05 & abs(logFC)>1]
  fwrite(d,file.path(SD,paste0('08_',acc,'_DE.csv.gz')))
  quality[[acc]] <- data.table(dataset=acc,N=nrow(m),Control=sum(m$group=='Control'),
    Periodontitis=sum(m$group=='Periodontitis'),genes=nrow(x),
    strict_Pan_DEGs=sum(d$strict_Pan_DEG),normalization=normalization)
  colnames(x) <- m$unique_id
  fwrite(as.data.table(x,keep.rownames='gene'),file.path(SD,paste0('08_',acc,'_normalized.csv.gz')))
  exprs[[acc]] <- x
  m[,sample:=unique_id]
  cohorts[[acc]] <- m
}
common <- Reduce(intersect,lapply(exprs,rownames))
merged <- do.call(cbind,lapply(exprs,function(x)x[common,,drop=FALSE]))
m <- rbindlist(cohorts,fill=TRUE)
stopifnot(identical(colnames(merged),m$sample),ncol(merged)==72)

merged <- normalizeBetweenArrays(merged,method='quantile')
fwrite(as.data.table(merged,keep.rownames='gene'),file.path(SD,'08_pooled_before_batch.csv.gz'))
fwrite(m,file.path(SD,'08_pooled_sample_metadata.csv'))
fwrite(rbindlist(quality),file.path(SD,'08_cohort_normalization_QC.csv'))
saveRDS(list(exprs=exprs,pooled_before=merged,meta=m,common_genes=common),file.path(SD,'08_normalized_cohorts.rds'))
message('Saved ',length(common),' shared genes across ',ncol(merged),' eligible samples')
status <- system2('C:/Python314/python.exe',c(file.path(SD,'combat_multicohort.py'),SD))
if(status!=0)stop('ComBat failed; no silent alternative correction')
message('ComBat completed; differential expression uses original quantile matrix with batch covariates to retain valid residual df')
design <- model.matrix(~group+batch+EBV_binary,m)
fit <- eBayes(lmFit(merged,design),trend=TRUE,robust=TRUE)
d <- as.data.table(topTable(fit,coef='groupPeriodontitis',number=Inf),keep.rownames='gene')
d[,strict_Pan_DEG:=adj.P.Val<.05 & abs(logFC)>1]
fwrite(d,file.path(SD,'10_pooled_DE_batch_and_EBV_adjusted.csv.gz'))
axis <- d[gene %in% c('GDF15','MAPK1','MAPK3','MMP1','MMP3')]
fwrite(axis,file.path(SD,'10_core_axis_descriptive_results.csv'))
audit <- list(cohorts=names(exprs),samples=72,Control=sum(m$group=='Control'),
  Periodontitis=sum(m$group=='Periodontitis'),common_genes=length(common),
  strict_DEG_threshold='BH FDR < 0.05 and |log2FC| > 1',strict_DEG_n=sum(d$strict_Pan_DEG),
  normalization='TMM logCPM for RNA-seq; public normalized Agilent expression; pooled limma quantile',
  exact_Pan_preprocessing=FALSE,
  deviations=c('RNA-seq count inputs use TMM logCPM, not unsupported TPM/FPKM conversion',
    'Agilent processed arrays reused; RMA is not applied to these non-Affymetrix platforms',
    'ComBat implementation neuroCombat, same empirical Bayes method rather than unavailable R sva',
    'DE uses pre-ComBat expression with explicit batch/EBV covariates to avoid ignoring residual batch estimation'),
  interpretation='Disease association only. These biopsies contain no measured vitamin D intervention or ERK phosphorylation.',
  ml_status='Not fitted. No 113-combination grid, best-model genes or model A-D figures have been generated in this run.',
  validation_warning='Pooled quantile/label-preserving ComBat is for descriptive analysis only; do not feed it directly to cross-validation as leakage-free input')
write_json(audit,file.path(SD,'10_analysis_status.json'),pretty=TRUE,auto_unbox=TRUE)
print(rbindlist(quality));print(axis);message('Strict DEGs: ',sum(d$strict_Pan_DEG))
