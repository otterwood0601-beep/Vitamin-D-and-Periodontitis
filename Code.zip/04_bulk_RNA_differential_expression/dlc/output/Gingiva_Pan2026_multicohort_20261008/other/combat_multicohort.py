import sys
from pathlib import Path
import pandas as pd
from neuroCombat import neuroCombat
root = Path(sys.argv[1])
expr = pd.read_csv(root / '08_pooled_before_batch.csv.gz', index_col=0)
meta = pd.read_csv(root / '08_pooled_sample_metadata.csv').set_index('sample').loc[expr.columns]
covars = pd.DataFrame({'batch': meta.batch.astype(str), 'group': meta.group.astype(str), 'EBV': meta.EBV_binary.astype(str)}, index=meta.index)
result = neuroCombat(dat=expr, covars=covars, batch_col='batch', categorical_cols=['group', 'EBV'], eb=True, parametric=True, mean_only=False, ref_batch=None)['data']
out = root / '09_pooled_ComBat.csv.gz'
if out.exists():
    raise FileExistsError('Do not overwrite ' + str(out))
pd.DataFrame(result, index=expr.index, columns=expr.columns).to_csv(out, index_label='gene', compression='gzip')
