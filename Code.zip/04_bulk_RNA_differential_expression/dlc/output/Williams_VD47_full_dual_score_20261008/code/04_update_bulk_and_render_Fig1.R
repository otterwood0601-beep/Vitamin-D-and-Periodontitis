OUT <- 'C:/wb_links/williams_vd47_full_20261008'
render_dir <- tempfile('williams_bulk_fig1_',tmpdir = 'C:/wb_temp')
dir.create(render_dir)
render_dir <- normalizePath(render_dir, winslash = '/', mustWork = TRUE)
code <- readLines('C:/wb_links/no2uc_original_code/04_fig1_missing_panels.R')
code <- gsub('C:/wb_links/jhazmat2026_no2uc_20260925',OUT,code,fixed = TRUE)
code <- gsub('C:/wb_links/bioorgchem2026_20260924/source_data/09_vitaminD_gingiva_overlap_genes.csv',
             'C:/wb_links/williams_vd47_full_20261008/source_data/01_VD47_signature_gene_audit.csv',code,fixed = TRUE)
code <- gsub('FD <- file.path(OUT, "figures")',paste0('FD <- "',render_dir,'"'),code,fixed = TRUE)

loc <- grep('storage.mode\\(mat\\)',code)
code <- append(code,c(
  'rownames(mat)[rownames(mat) == "EFTUD1"] <- "EFL1"',
  'rownames(mat)[rownames(mat) == "CYR61"] <- "CCN1"',
  'stopifnot(!anyDuplicated(rownames(mat)))'),after = loc)
code <- gsub('VD17','VD35',code,fixed = TRUE)
loc <- grep('stopifnot\\(length\\(sig_genes',code)
code <- append(code,c(
  'stopifnot(length(sig_genes) == 35, "GDF15" %in% sig_genes)',
  'bulk_audit <- copy(sig)',
  'bulk_audit[, present_in_bulk := gene %in% rownames(mat)]',
  'bulk_audit[, matrix_symbol_before_harmonization := fifelse(gene == "EFL1", "EFTUD1", fifelse(gene == "CCN1", "CYR61", gene))]',
  'fwrite(bulk_audit, file.path(SD, "26_bulk_signature_gene_audit.csv"))'),after = loc)
loc <- grep('corr\\[, lower_triangle',code)
code <- append(code,'corr[x_index == y_index, significance := ""]',after = loc)
loc <- grep('fwrite\\(assoc',code)
code <- append(code,'assoc[, FDR_high_low := p.adjust(adjusted_high_vs_low_p, "BH")]',after = loc-1L)

loc <- grep('^partial_stats <-',code)
code <- append(code,c(
  'partial_r <- unname(partial$estimate)',
  'partial_df <- nrow(vd17) - 3L',
  'partial$p.value <- 2*pt(-abs(partial_r*sqrt(partial_df/(1-partial_r^2))), df = partial_df)',
  'vd17[, VD35_adjusted_score := residuals(tnk_fit_x)]',
  'vd17[, TNK_adjusted_fraction := residuals(tnk_fit_y)]'),after = loc-1L)

start <- grep('^pKmain <-',code); end <- grep('^pK <-',code)-1L
code[start:end] <- gsub('VD35_score','VD35_adjusted_score',code[start:end],fixed = TRUE)
code[start:end] <- gsub('`T/NK` * 100','TNK_adjusted_fraction',code[start:end],fixed = TRUE)
code[start:end] <- gsub('VD35 bulk signature score','Cohort-adjusted VD35 score',code[start:end],fixed = TRUE)
code[start:end] <- gsub('T/NK fraction (%)','Adjusted T/NK (arcsin-sqrt residual)',code[start:end],fixed = TRUE)
code <- gsub('Fig1F_J_K_VD35_correlation_Bisque_JHazMat_style',
             'Fig1F_J_K_VD35_correlation_Bisque_JHazMat_style_20261008',code,fixed = TRUE)
loc <- grep('^ggsave\\(pdf_path',code)
code <- append(code,'ggsave(png_path, fig, width = 15.4, height = 5.4, units = "in", dpi = 600, bg = "white")',after = loc)
writeLines(code,file.path(OUT,'code','04_original_bulk_recipe_adapted.R'))
eval(parse(text = code),envir = .GlobalEnv)
stopifnot(file.info(pdf_path)$size > 1000,file.info(png_path)$size > 1000)
stopifnot(file.copy(c(pdf_path,png_path),file.path(OUT,'figures'),overwrite = FALSE))
manifest$output <- file.path(OUT,'figures',basename(manifest$output))
manifest$latest_candidate_signature_n <- 47L
manifest$actual_measured_signature_n <- length(sig_genes)
manifest$HGNC_symbol_updates <- c('EFTUD1 to EFL1','CYR61 to CCN1')
manifest$missing_signature_genes <- setdiff(sig$gene, sig_genes)
write_json(manifest,file.path(SD,'21_Fig1F_J_K_manifest.json'),auto_unbox = TRUE,pretty = TRUE)
cat('Saved full Fig1 F/J/K; bulk input genes = ',length(sig_genes),'\n')
