options(stringsAsFactors = FALSE, scipen = 999)
set.seed(20260926)

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(patchwork)
  library(cowplot)
  library(scales)
  library(jsonlite)
})

OUT <- "C:/wb_links/williams_vd47_full_20261008"
SD <- file.path(OUT, "source_data")
FD <- "C:/wb_temp/williams_bulk_fig1_77dc5a291736"
BULK <- "C:/wb_links/bioorgchem2026_20260924/source_data/01_bulk_expr_ComBat.csv.gz"
META <- "C:/wb_links/bioorgchem2026_20260924/source_data/01_bulk_sample_metadata.csv"
SIG <- "C:/wb_links/williams_vd47_full_20261008/source_data/01_VD47_signature_gene_audit.csv"
F223 <- "C:/wb_links/dlc_derived/D11_deconvolution/D11_GSE223924_Bisque_cell_fractions.csv"
F173 <- "C:/wb_links/dlc_derived/D11_deconvolution/D11_GSE173078_Bisque_cell_fractions.csv"

for (p in c(BULK, META, SIG, F223, F173)) {
  if (!file.exists(p)) stop("Missing input: ", p)
}

message("[1/5] Loading prior gingival bulk expression and BisqueRNA fractions")
bulk <- fread(BULK)
genes <- bulk$gene
mat <- as.matrix(bulk[, -"gene"])
rownames(mat) <- genes
storage.mode(mat) <- "double"
rownames(mat)[rownames(mat) == "EFTUD1"] <- "EFL1"
rownames(mat)[rownames(mat) == "CYR61"] <- "CCN1"
stopifnot(!anyDuplicated(rownames(mat)))
meta <- fread(META)
sig <- fread(SIG)
sig_genes <- intersect(sig$gene, rownames(mat))
stopifnot(length(sig_genes) >= 10)
stopifnot(length(sig_genes) == 35, "GDF15" %in% sig_genes)
bulk_audit <- copy(sig)
bulk_audit[, present_in_bulk := gene %in% rownames(mat)]
bulk_audit[, matrix_symbol_before_harmonization := fifelse(gene == "EFL1", "EFTUD1", fifelse(gene == "CCN1", "CYR61", gene))]
fwrite(bulk_audit, file.path(SD, "26_bulk_signature_gene_audit.csv"))

f223 <- fread(F223)
f173 <- fread(F173)
f223[, dataset := "GSE223924"]
f173[, dataset := "GSE173078"]
fractions <- rbindlist(list(f223, f173), use.names = TRUE, fill = TRUE)
fraction_cols <- c("B/Plasma", "Endothelial", "Epithelial", "Fibroblast", "Mast",
                   "Mural", "Myeloid/DC", "Neural/Melanocyte", "Neutrophil", "T/NK")
fractions <- fractions[, c("sample", "dataset", fraction_cols), with = FALSE]

message("[2/5] Computing 17-gene Pearson correlation matrix")
x <- t(mat[sig_genes, meta$sample, drop = FALSE])
cormat <- cor(x, method = "pearson", use = "pairwise.complete.obs")
pval <- matrix(NA_real_, nrow = length(sig_genes), ncol = length(sig_genes),
               dimnames = list(sig_genes, sig_genes))
for (i in seq_along(sig_genes)) {
  for (j in seq_along(sig_genes)) {
    pval[i, j] <- suppressWarnings(cor.test(x[, i], x[, j], method = "pearson")$p.value)
  }
}
corr <- as.data.table(as.table(cormat))
setnames(corr, c("gene_y", "gene_x", "r"))
corr[, p_value := as.vector(pval)]
corr[, `:=`(
  x_index = match(gene_x, sig_genes),
  y_index = match(gene_y, sig_genes),
  significance = fifelse(p_value < 0.001, "***",
                         fifelse(p_value < 0.01, "**",
                                 fifelse(p_value < 0.05, "*", "")))
)]
corr[, lower_triangle := y_index >= x_index]
corr[x_index == y_index, significance := ""]
fwrite(corr, file.path(SD, "17_VD35_bulk_gene_correlations.csv"))

message("[3/5] Computing bulk VD35 score and tissue-specific composition associations")

z <- t(scale(t(mat[sig_genes, meta$sample, drop = FALSE])))
vd17 <- data.table(sample = colnames(z), VD35_score = colMeans(z, na.rm = TRUE))
vd17[meta, on = "sample", `:=`(dataset = i.dataset, group = i.group)]
vd17[, score_group := ifelse(
  VD35_score > median(VD35_score, na.rm = TRUE), "High", "Low"
), by = dataset]
vd17[, score_group := factor(score_group, levels = c("Low", "High"))]
vd17[fractions, on = .(sample, dataset), (fraction_cols) := mget(paste0("i.", fraction_cols))]
stopifnot(!anyNA(vd17[["T/NK"]]))
fwrite(vd17, file.path(SD, "18_bulk_VD35_score_and_Bisque_fractions.csv"))

long <- melt(vd17, id.vars = c("sample", "dataset", "group", "VD35_score", "score_group"),
             measure.vars = fraction_cols, variable.name = "cell_type",
             value.name = "fraction")
assoc <- rbindlist(lapply(fraction_cols, function(ct) {
  d <- long[cell_type == ct]
  d[, score_group := relevel(factor(score_group), ref = "Low")]
  fit <- lm(asin(sqrt(pmin(pmax(fraction, 0), 1))) ~ score_group + dataset, data = d)
  sm <- summary(fit)$coefficients
  sp <- suppressWarnings(cor.test(d$VD35_score, d$fraction, method = "spearman", exact = FALSE))
  data.table(
    cell_type = ct,
    adjusted_high_vs_low_beta = sm["score_groupHigh", "Estimate"],
    adjusted_high_vs_low_p = sm["score_groupHigh", "Pr(>|t|)"],
    spearman_rho = unname(sp$estimate),
    spearman_p = sp$p.value,
    n = nrow(d)
  )
}))
assoc[, FDR_high_low := p.adjust(adjusted_high_vs_low_p, "BH")]
fwrite(assoc, file.path(SD, "19_VD35_Bisque_fraction_associations.csv"))

tnk_fit_x <- lm(VD35_score ~ dataset, data = vd17)
tnk_fit_y <- lm(asin(sqrt(pmin(pmax(`T/NK`, 0), 1))) ~ dataset, data = vd17)
partial <- cor.test(residuals(tnk_fit_x), residuals(tnk_fit_y), method = "pearson")
partial_r <- unname(partial$estimate)
partial_df <- nrow(vd17) - 3L
partial$p.value <- 2*pt(-abs(partial_r*sqrt(partial_df/(1-partial_r^2))), df = partial_df)
vd17[, VD35_adjusted_score := residuals(tnk_fit_x)]
vd17[, TNK_adjusted_fraction := residuals(tnk_fit_y)]
partial_stats <- data.table(
  endpoint = "T/NK_fraction",
  method = "Pearson correlation after residualizing both variables for dataset",
  r = unname(partial$estimate),
  p_value = partial$p.value,
  n = nrow(vd17)
)
fwrite(partial_stats, file.path(SD, "20_VD35_TNK_partial_correlation.csv"))

message("[4/5] Recreating reference Fig. 1 panels F, J and K")
paper_theme <- theme_classic(base_size = 8, base_family = "Arial") +
  theme(
    axis.title = element_text(size = 8, colour = "black"),
    axis.text = element_text(size = 6.2, colour = "black"),
    axis.line = element_line(linewidth = 0.35),
    axis.ticks = element_line(linewidth = 0.3),
    plot.title = element_text(size = 8.5, hjust = 0.5, face = "plain"),
    legend.title = element_text(size = 6.5),
    legend.text = element_text(size = 6),
    legend.key.size = grid::unit(0.3, "cm"),
    plot.margin = margin(4, 4, 4, 4)
  )
score_cols <- c("Low" = "#E68173", "High" = "#4D8FC2")

corr_plot <- corr[lower_triangle == TRUE]
corr_plot[, gene_x := factor(gene_x, levels = sig_genes)]
corr_plot[, gene_y := factor(gene_y, levels = rev(sig_genes))]
pF <- ggplot(corr_plot, aes(gene_x, gene_y, fill = r)) +
  geom_tile(colour = "white", linewidth = 0.38) +
  geom_text(aes(label = significance), size = 1.7, family = "Arial") +
  scale_fill_gradient2(low = "#4D8FC2", mid = "white", high = "#D95F59",
                       midpoint = 0, limits = c(-1, 1), name = "Pearson's r") +
  scale_x_discrete(drop = FALSE) + scale_y_discrete(drop = FALSE) +
  coord_fixed() +
  labs(title = "VD35 gene correlations in human gingiva", x = NULL, y = NULL) +
  theme_minimal(base_family = "Arial", base_size = 7) +
  theme(
    panel.grid = element_blank(),
    axis.text.x = element_text(angle = 55, hjust = 1, size = 5.6, colour = "black"),
    axis.text.y = element_text(size = 5.6, colour = "black"),
    plot.title = element_text(size = 8.5, hjust = 0.5),
    legend.title = element_text(size = 6.5),
    legend.text = element_text(size = 6),
    plot.margin = margin(4, 4, 4, 4)
  )

show_types <- c("T/NK", "Myeloid/DC", "Fibroblast")
jdat <- long[cell_type %in% show_types]
jdat[, cell_type := factor(cell_type, levels = show_types)]
janno <- assoc[cell_type %in% show_types]
janno[, cell_type := factor(cell_type, levels = show_types)]
janno[, label := ifelse(adjusted_high_vs_low_p < 0.001, "p < 0.001",
                        paste0("p = ", sprintf("%.2f", adjusted_high_vs_low_p)))]
pJ <- ggplot(jdat, aes(cell_type, fraction * 100, fill = score_group)) +
  geom_violin(position = position_dodge(width = 0.72), width = 0.68,
              linewidth = 0.32, alpha = 0.90, trim = TRUE) +
  geom_boxplot(position = position_dodge(width = 0.72), width = 0.12,
               outlier.shape = NA, colour = "black", fill = "white", linewidth = 0.28) +
  geom_point(aes(colour = score_group),
             position = position_jitterdodge(jitter.width = 0.08, dodge.width = 0.72),
             size = 0.55, alpha = 0.70, show.legend = FALSE) +
  geom_text(data = janno, aes(x = cell_type, y = Inf, label = label),
            inherit.aes = FALSE, vjust = 1.15, size = 2.0, family = "Arial") +
  scale_fill_manual(values = score_cols, name = "VD35 score") +
  scale_colour_manual(values = score_cols) +
  labs(title = "BisqueRNA gingival cell fractions", x = NULL, y = "Estimated fraction (%)") +
  paper_theme + theme(axis.text.x = element_text(angle = 20, hjust = 1))

pKmain <- ggplot(vd17, aes(VD35_adjusted_score, TNK_adjusted_fraction, colour = score_group)) +
  geom_point(size = 1.15, alpha = 0.82) +
  geom_smooth(aes(group = 1), method = "lm", se = TRUE, colour = "#555555",
              fill = "#D9D9D9", linewidth = 0.45) +
  annotate("text", x = -Inf, y = Inf,
           label = paste0("dataset-adjusted r = ", sprintf("%.2f", partial_stats$r),
                          ", p = ", sprintf("%.3f", partial_stats$p_value)),
           hjust = -0.02, vjust = 1.15, size = 2.1, family = "Arial") +
  scale_colour_manual(values = score_cols, name = "VD35 score") +
  labs(x = "Cohort-adjusted VD35 score", y = "Adjusted T/NK (arcsin-sqrt residual)") + paper_theme +
  theme(legend.position = c(0.80, 0.20),
        legend.background = element_rect(fill = alpha("white", 0.75), colour = NA))
pKtop <- ggplot(vd17, aes(VD35_adjusted_score, fill = score_group)) +
  geom_histogram(bins = 16, alpha = 0.75, colour = "white", linewidth = 0.2) +
  scale_fill_manual(values = score_cols, guide = "none") +
  theme_void()
pKright <- ggplot(vd17, aes(TNK_adjusted_fraction, fill = score_group)) +
  geom_histogram(bins = 16, alpha = 0.75, colour = "white", linewidth = 0.2) +
  scale_fill_manual(values = score_cols, guide = "none") +
  coord_flip() + theme_void()
pK <- (pKtop + plot_spacer()) / (pKmain + pKright) +
  plot_layout(widths = c(4, 1), heights = c(1, 4)) +
  plot_annotation(title = "VD35 score and T/NK infiltration",
                  theme = theme(plot.title = element_text(family = "Arial", size = 8.5,
                                                          hjust = 0.5, face = "plain")))

fig <- plot_grid(pF, pJ, pK, nrow = 1, rel_widths = c(1.22, 1.0, 1.08),
                 labels = c("F", "J", "K"), label_fontfamily = "Arial",
                 label_fontface = "plain", label_size = 11, hjust = -0.2, vjust = 1.2)

pdf_path <- file.path(FD, "Fig1F_J_K_VD35_correlation_Bisque_JHazMat_style_20261008.pdf")
png_path <- file.path(FD, "Fig1F_J_K_VD35_correlation_Bisque_JHazMat_style_20261008.png")
ggsave(pdf_path, fig, width = 15.4, height = 5.4, units = "in", device = cairo_pdf)
ggsave(png_path, fig, width = 15.4, height = 5.4, units = "in", dpi = 600, bg = "white")

message("[5/5] Writing manifest")
manifest <- list(
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  reference_panels = c("Fig. 1F correlation matrix", "Fig. 1J high/low immune-stromal comparison",
                       "Fig. 1K signature-infiltration correlation"),
  reused_inputs = c(
    "Previously completed ComBat-corrected gingival bulk expression (GSE223924 plus GSE173078)",
    "Previously completed BisqueRNA gingival-reference deconvolution; no deconvolution was rerun"
  ),
  new_work = c(
    "VD35 Pearson correlation matrix across 44 human gingival samples",
    "Within-cohort VD35 high/low association with BisqueRNA fractions",
    "Dataset-adjusted correlation of VD35 score with T/NK fraction"
  ),
  n_samples = nrow(vd17),
  n_signature_genes = length(sig_genes),
  output = c(pdf_path, png_path),
  caveat = "BisqueRNA tissue-specific fractions replace the paper's xCell scores to preserve the user's human-gingiva-only requirement."
)
write_json(manifest, file.path(SD, "21_Fig1F_J_K_manifest.json"),
           auto_unbox = TRUE, pretty = TRUE)

print(assoc)
print(partial_stats)
cat(pdf_path, "\n")
