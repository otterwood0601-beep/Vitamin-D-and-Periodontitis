options(stringsAsFactors=FALSE,scipen=999)
.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(edgeR);library(limma);library(jsonlite);library(digest)})
args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args)==1)
OUT <- args[1]
SD <- file.path(OUT,'source_data')
dir.create(SD,recursive=TRUE,showWarnings=FALSE)
RAW <- 'C:/wb_links/dlc_data/external_GSE173078/GSE173078_rnaseq_raw_counts.txt.gz'
GEO <- 'C:/wb_links/dlc_data/external_GSE173078/GSE173078_series_matrix.txt.gz'
geo_lines <- readLines(gzfile(GEO),warn=FALSE)
fields <- lapply(geo_lines,function(x) gsub('^"|"$','',strsplit(x,'\t',fixed=TRUE)[[1]]))
get_row <- function(key) {
  hits <- Filter(function(x) x[1]==key,fields)
  stopifnot(length(hits)==1)
  hits[[1]][-1]
}
get_characteristic <- function(key) {
  hits <- Filter(function(x) x[1]=='!Sample_characteristics_ch1' && startsWith(x[2],paste0(key,': ')),fields)
  stopifnot(length(hits)==1)
  sub(paste0('^',key,': '),'',hits[[1]][-1])
}
meta_all <- data.table(sample=sub('_.*','',get_row('!Sample_title')),
  GSM=get_row('!Sample_geo_accession'),title=get_row('!Sample_title'),
  tissue=get_row('!Sample_source_name_ch1'),phenotype=get_characteristic('phenotype'),
  batch=get_characteristic('batch'),age=as.numeric(get_characteristic('age')),sex=get_characteristic('Sex'),dataset='GSE173078')
stopifnot(nrow(meta_all)==36,!anyDuplicated(meta_all$sample),all(grepl('gingival',meta_all$tissue,ignore.case=TRUE)))
meta_all[, included := phenotype %in% c('Healthy','Periodontitis')]
meta_all[, exclusion_reason := ifelse(included,'','Gingivitis excluded')]
fwrite(meta_all,file.path(SD,'00_GSE173078_all_sample_audit.csv'))

old <- parse('C:/wb_links/bioorgchem2026_code/01_bulk_fig1.R')
heads <- vapply(old,function(e) paste(deparse(e),collapse='\n'),character(1))
idx <- which(startsWith(heads,'read_cohort <-'))
stopifnot(length(idx)==1)
eval(old[[idx]])
c2 <- read_cohort('GSE173078')
meta <- meta_all[match(c2$meta$sample,sample)]
stopifnot(nrow(meta)==24,all(meta$included),sum(meta$phenotype=='Healthy')==12,sum(meta$phenotype=='Periodontitis')==12,
  identical(c2$meta$group,ifelse(meta$phenotype=='Healthy','Control','Periodontitis')),
  identical(colnames(c2$expr),meta$sample))
meta[, group := factor(ifelse(phenotype=='Healthy','Control','Periodontitis'),levels=c('Control','Periodontitis'))]
meta[, batch := factor(batch,levels=c('A','B'))]
stopifnot(all(table(meta$batch,meta$group)==6))
raw <- fread(RAW)
setnames(raw,1,'gene')
samples <- meta$sample
counts <- as.matrix(raw[,..samples])
stopifnot(!anyDuplicated(raw$gene),all(is.finite(counts)),all(counts>=0),all(counts==round(counts)))
meta[, raw_library_size := colSums(counts)]
fwrite(meta,file.path(SD,'01_bulk_sample_metadata.csv'))
fwrite(as.data.table(c2$expr,keep.rownames='gene'),file.path(SD,'01_GSE173078_logCPM.csv.gz'))
design <- model.matrix(~group+batch,data=meta)
stopifnot(qr(design)$rank==ncol(design))
fit <- eBayes(lmFit(c2$expr,design),trend=TRUE,robust=TRUE)
de <- as.data.table(topTable(fit,coef='groupPeriodontitis',number=Inf,sort.by='P'),keep.rownames='gene')
de[, status := fifelse(adj.P.Val<.05 & logFC>0,'Up',fifelse(adj.P.Val<.05 & logFC<0,'Down','Not'))]
fwrite(de,file.path(SD,'02_bulk_differential_expression.csv.gz'))
fwrite(de[adj.P.Val<.05],file.path(SD,'02_GSE173078_DEGs_FDR005.csv'))
saveRDS(list(expression=c2$expr,metadata=meta,design=design,fit=fit),file.path(SD,'00_GSE173078_DE_model.rds'))
provenance <- list(dataset='GSE173078',n_healthy=12,n_periodontitis=12,n_excluded_gingivitis=12,
  raw_counts_input="E:/\u8840\u6e05\u7ef4\u751f\u7d20D DLC/01_\u6570\u636e\u51c6\u5907/external_GSE173078/GSE173078_rnaseq_raw_counts.txt.gz",
  raw_counts_sha256=digest(file=RAW,algo='sha256'),
  GEO_metadata_input="E:/\u8840\u6e05\u7ef4\u751f\u7d20D DLC/01_\u6570\u636e\u51c6\u5907/external_GSE173078/GSE173078_series_matrix.txt.gz",
  GEO_metadata_sha256=digest(file=GEO,algo='sha256'),
  group_batch_table=as.data.frame(table(meta$batch,meta$group)),
  method='Same legacy edgeR filterByExpr(min.count=5), TMM, logCPM(prior.count=0.5), limma-trend robust empirical Bayes; design ~group+batch',
  contrast='Periodontitis minus Control, adjusted for within-study GEO batch A/B',
  inter_cohort_merge=FALSE,inter_cohort_ComBat=FALSE,tested_genes=nrow(de),FDR005_genes=sum(de$adj.P.Val<.05),
  no_added_disease_genes=TRUE,extra_fold_change_cutoff=FALSE,
  GDF15=as.list(de[gene=='GDF15']),MAPK1=as.list(de[gene=='MAPK1']),MAPK3=as.list(de[gene=='MAPK3']),
  gene_annotation='Published raw-count gene symbols, no gene-name fabrication',
  limits=c('Whole gingival tissue, not fibroblast-specific','Cross-sectional association; no causal inference','Primary design adjusts original batch only, not age/sex; remains exploratory'),
  derived_at=format(Sys.time(),tz='Asia/Shanghai',usetz=TRUE))
write_json(provenance,file.path(SD,'00_GSE173078_DE_provenance.json'),auto_unbox=TRUE,pretty=TRUE,digits=NA)
writeLines(capture.output(sessionInfo()),file.path(OUT,'logs','GSE173078_DE_sessionInfo.txt'))
cat('GSE173078 only: ',nrow(de),' tested genes; ',sum(de$adj.P.Val<.05),' FDR < .05 genes\n',sep='')
print(de[gene %in% c('GDF15','MAPK1','MAPK3','MMP1','MMP3')])
