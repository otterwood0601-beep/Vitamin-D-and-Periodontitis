options(stringsAsFactors = FALSE, scipen = 999)
set.seed(20260924)

suppressPackageStartupMessages({
  library(data.table)
  library(edgeR)
  library(limma)
  library(WGCNA)
  library(ggplot2)
  library(patchwork)
  library(pheatmap)
  library(ggplotify)
  library(ggdendro)
  library(cowplot)
  library(RColorBrewer)
})

allowWGCNAThreads(nThreads = 2)

OUT <- "C:/wb_links/bioorgchem2026_20260924"
SD <- file.path(OUT, "source_data")
FD <- file.path(OUT, "figures")
dir.create(SD, recursive = TRUE, showWarnings = FALSE)
dir.create(FD, recursive = TRUE, showWarnings = FALSE)

read_cohort <- function(dataset) {
  if (dataset == "GSE223924") {
    x <- fread("C:/wb_links/dlc_data/external_GSE223924/GSE223924_raw_count.csv.gz")
    setnames(x, 1, "gene")
    samples <- c(paste0("H", 1:10), paste0("PT", c(1:8, 10, 11)))
    group <- c(rep("Control", 10), rep("Periodontitis", 10))
  } else if (dataset == "GSE173078") {
    x <- fread("C:/wb_links/dlc_data/external_GSE173078/GSE173078_rnaseq_raw_counts.txt.gz")
    setnames(x, 1, "gene")
    pd_a <- c("AC001", "AC003", "AC005", "AC007", "AC009", "AC011")
    h_a <- c("AC013", "AC016", "AC018", "AC019", "AC022", "AC024")
    pd_b <- c("AC037", "AC039", "AC042", "AC044", "AC046", "AC048")
    h_b <- c("AC050", "AC052", "AC054", "AC056", "AC058", "AC060")
    samples <- c(h_a, h_b, pd_a, pd_b)
    group <- c(rep("Control", 12), rep("Periodontitis", 12))
  } else stop("Unknown cohort")

  mat <- as.matrix(x[, ..samples])
  rownames(mat) <- make.unique(as.character(x$gene))
  storage.mode(mat) <- "numeric"
  dge <- DGEList(mat)
  keep <- filterByExpr(dge, group = group, min.count = 5)
  dge <- calcNormFactors(dge[keep, , keep.lib.sizes = FALSE])
  logcpm <- cpm(dge, log = TRUE, prior.count = 0.5)
  meta <- data.table(sample = samples, dataset = dataset, group = group)
  list(expr = logcpm, meta = meta)
}

message("[1/6] Load and normalize the two human gingiva cohorts")
c1 <- read_cohort("GSE223924")
c2 <- read_cohort("GSE173078")
common <- intersect(rownames(c1$expr), rownames(c2$expr))
expr_before <- cbind(c1$expr[common, , drop = FALSE], c2$expr[common, , drop = FALSE])
meta <- rbindlist(list(c1$meta, c2$meta))
stopifnot(identical(colnames(expr_before), meta$sample))
meta[, dataset := factor(dataset, levels = c("GSE223924", "GSE173078"))]
meta[, group := factor(group, levels = c("Control", "Periodontitis"))]

message("[2/6] Batch correction while preserving disease status")
design_preserve <- model.matrix(~ group, data = meta)
batch_method <- "limma::removeBatchEffect"
combat_in <- file.path(SD, "01_bulk_expr_before.csv.gz")
combat_out <- file.path(SD, "01_bulk_expr_ComBat.csv.gz")
combat_meta <- file.path(SD, "01_bulk_sample_metadata.csv")
fwrite(as.data.table(expr_before, keep.rownames = "gene"), combat_in)
fwrite(meta, combat_meta)
py_log <- file.path(OUT, "logs", "neuroCombat.log")
py_status <- tryCatch(
  system2(
    "python",
    c("C:/wb_links/bioorgchem2026_code/combat_batch.py", combat_in, combat_meta, combat_out),
    stdout = py_log, stderr = py_log
  ),
  error = function(e) 1L
)
if (identical(py_status, 0L) && file.exists(combat_out)) {
  ca <- fread(combat_out)
  expr_after <- as.matrix(ca[, -1])
  rownames(expr_after) <- ca[[1]]
  colnames(expr_after) <- names(ca)[-1]
  expr_after <- expr_after[rownames(expr_before), colnames(expr_before), drop = FALSE]
  storage.mode(expr_after) <- "numeric"
  batch_method <- "neuroCombat parametric empirical-Bayes ComBat"
} else if (requireNamespace("sva", quietly = TRUE)) {
  expr_after <- sva::ComBat(
    dat = expr_before,
    batch = meta$dataset,
    mod = design_preserve,
    par.prior = TRUE,
    prior.plots = FALSE
  )
  batch_method <- "sva::ComBat"
} else {
  expr_after <- removeBatchEffect(expr_before, batch = meta$dataset, design = design_preserve)
}

saveRDS(list(expr_before = expr_before, expr_after = expr_after, meta = meta),
        file.path(SD, "01_bulk_merged_batch_corrected.rds"))
fwrite(meta, file.path(SD, "01_bulk_sample_metadata.csv"))

message("[3/6] Differential expression")
design <- model.matrix(~ 0 + group, data = meta)
colnames(design) <- levels(meta$group)
fit <- eBayes(contrasts.fit(lmFit(expr_after, design),
                            makeContrasts(Periodontitis - Control, levels = design)),
               trend = TRUE, robust = TRUE)
de <- as.data.table(topTable(fit, number = Inf, sort.by = "P"), keep.rownames = "gene")
de[, status := fifelse(adj.P.Val < 0.05 & logFC > 1, "Up",
                       fifelse(adj.P.Val < 0.05 & logFC < -1, "Down", "Not"))]
fwrite(de, file.path(SD, "02_bulk_differential_expression.csv.gz"))
strict_deg <- de[status != "Not", gene]

message("[4/6] WGCNA on paper-threshold DEGs, with prespecified stability fallback")
if (length(strict_deg) >= 80) {
  wgenes <- strict_deg
  wgcna_input_rule <- "Strict DEGs: |log2FC| > 1 and BH FDR < 0.05"
} else {
  wgenes <- unique(c(de[order(adj.P.Val, -abs(logFC))][1:min(800, .N), gene],
                     intersect(c("GDF15", "MAPK1", "MAPK3"), rownames(expr_after))))
  wgcna_input_rule <- paste0(
    "Exploratory stability fallback: strict DEGs n=", length(strict_deg),
    "; WGCNA used the top ", length(wgenes),
    " disease-ranked genes plus available prespecified axis genes"
  )
}
datExpr <- t(expr_after[wgenes, , drop = FALSE])
gsg <- goodSamplesGenes(datExpr, verbose = 0)
datExpr <- datExpr[gsg$goodSamples, gsg$goodGenes, drop = FALSE]
meta_w <- meta[match(rownames(datExpr), sample)]

powers <- c(1:10, seq(12, 20, 2))
sft <- suppressWarnings(pickSoftThreshold(datExpr, powerVector = powers,
                                          networkType = "signed", verbose = 0))
fi <- as.data.table(sft$fitIndices)
setnames(fi, names(fi)[1:3], c("Power", "SFT_R2", "slope"))
candidate <- fi[SFT_R2 >= 0.80 & slope < 0, Power]
soft_power <- if (length(candidate)) min(candidate) else fi[which.max(SFT_R2), Power]
if (!is.finite(soft_power)) soft_power <- 6

net <- blockwiseModules(
  datExpr,
  power = soft_power,
  TOMType = "signed",
  minModuleSize = 20,
  mergeCutHeight = 0.25,
  numericLabels = FALSE,
  pamRespectsDendro = FALSE,
  maxBlockSize = max(5000, ncol(datExpr)),
  verbose = 0
)
module_colors <- net$colors
names(module_colors) <- colnames(datExpr)
MEs <- orderMEs(net$MEs)
trait <- data.frame(
  Control = as.integer(meta_w$group == "Control"),
  Periodontitis = as.integer(meta_w$group == "Periodontitis"),
  row.names = meta_w$sample
)
module_cor <- cor(MEs, trait, use = "p")
module_p <- corPvalueStudent(module_cor, nrow(datExpr))

mods <- sub("^ME", "", rownames(module_cor))
pd_cor <- module_cor[, "Periodontitis"]
pd_cor[mods == "grey"] <- NA_real_
selected_module <- mods[which.max(pd_cor)]
selected_genes <- names(module_colors)[module_colors == selected_module]

members <- data.table(gene = names(module_colors), module = unname(module_colors))
members[de, on = "gene", `:=`(logFC = i.logFC, P.Value = i.P.Value,
                                adj.P.Val = i.adj.P.Val, status = i.status)]
fwrite(members, file.path(SD, "03_WGCNA_module_membership.csv"))
fwrite(data.table(gene = selected_genes, module = selected_module),
       file.path(SD, "04_selected_periodontitis_module_genes.csv"))
fwrite(fi, file.path(SD, "05_WGCNA_soft_threshold_diagnostics.csv"))

trait_long <- data.table(
  module = rep(rownames(module_cor), times = ncol(module_cor)),
  trait = rep(colnames(module_cor), each = nrow(module_cor)),
  correlation = as.vector(module_cor),
  p_value = as.vector(module_p)
)
trait_long[, module := sub("^ME", "ME", as.character(module))]
fwrite(trait_long, file.path(SD, "06_WGCNA_module_trait_correlations.csv"))

manifest <- list(
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  tissue = "Human gingiva only",
  cohorts = list(GSE223924 = "10 control + 10 periodontitis",
                 GSE173078 = "12 control + 12 periodontitis; gingivitis excluded"),
  n_samples = nrow(meta),
  n_common_filtered_genes = nrow(expr_before),
  batch_method = batch_method,
  strict_DEG_threshold = "absolute log2FC > 1 and BH FDR < 0.05",
  strict_DEG_n = length(strict_deg),
  WGCNA_input_rule = wgcna_input_rule,
  WGCNA_n_genes = ncol(datExpr),
  WGCNA_soft_power = soft_power,
  selected_periodontitis_module = selected_module,
  selected_module_n_genes = length(selected_genes),
  interpretation = paste(
    "Exploratory cross-cohort gingival transcriptomics.",
    "Association does not establish vitamin D, GDF15, ERK1/2, or MMP causality."
  )
)
jsonlite::write_json(manifest, file.path(SD, "07_bulk_WGCNA_manifest.json"),
                     auto_unbox = TRUE, pretty = TRUE)

message("[5/6] Build Bioorganic Chemistry Fig. 1 style panels")
paper_theme <- theme_bw(base_size = 8, base_family = "Arial") +
  theme(
    panel.grid.major = element_line(colour = "#E7E7E7", linewidth = 0.25),
    panel.grid.minor = element_blank(),
    plot.title = element_text(hjust = 0.5, size = 9, face = "plain"),
    axis.title = element_text(size = 8),
    axis.text = element_text(size = 6.5, colour = "black"),
    legend.title = element_text(size = 7),
    legend.text = element_text(size = 6.5),
    legend.key.size = grid::unit(0.35, "cm"),
    plot.margin = margin(3, 3, 3, 3)
  )

dataset_cols <- c(GSE223924 = "#00BFC4", GSE173078 = "#F8766D")
group_shapes <- c(Control = 16, Periodontitis = 17)

box_panel <- function(mat, title) {
  z <- as.data.table(mat, keep.rownames = "gene")
  z <- melt(z, id.vars = "gene", variable.name = "sample", value.name = "Expression")
  z[meta, on = "sample", dataset := i.dataset]
  ggplot(z, aes(sample, Expression, fill = dataset)) +
    geom_boxplot(outlier.shape = NA, linewidth = 0.20, width = 0.80) +
    scale_fill_manual(values = dataset_cols, name = NULL) +
    labs(title = title, x = "Sample", y = "Expression") +
    paper_theme +
    theme(axis.text.x = element_blank(), axis.ticks.x = element_blank(),
          legend.position = "inside", legend.position.inside = c(0.18, 0.88),
          legend.direction = "horizontal")
}

pca_panel <- function(mat, title = NULL) {
  pc <- prcomp(t(mat), center = TRUE, scale. = FALSE)
  d <- data.table(sample = rownames(pc$x), PC1 = pc$x[, 1], PC2 = pc$x[, 2])
  d[meta, on = "sample", `:=`(dataset = i.dataset, group = i.group)]
  ve <- round(100 * summary(pc)$importance[2, 1:2], 1)
  ggplot(d, aes(PC1, PC2, colour = dataset, shape = group)) +
    stat_ellipse(aes(group = dataset), type = "norm", linewidth = 0.45,
                 level = 0.80, show.legend = FALSE) +
    geom_point(size = 2.0, alpha = 0.90) +
    scale_colour_manual(values = dataset_cols, name = "Project") +
    scale_shape_manual(values = group_shapes, name = "Type") +
    labs(title = title, x = paste0("PC1 (", ve[1], "%)"),
         y = paste0("PC2 (", ve[2], "%)")) + paper_theme
}

pA <- box_panel(expr_before, "Before batch correction")
pB <- pca_panel(expr_before)
pC <- box_panel(expr_after, "After batch correction")
pD <- pca_panel(expr_after)

pE <- ggplot(de, aes(logFC, -log10(pmax(adj.P.Val, 1e-300)), colour = status)) +
  geom_point(size = 0.85, alpha = 0.85) +
  scale_colour_manual(values = c(Down = "#19E51F", Not = "#BDBDBD", Up = "#FF1717"),
                      breaks = c("Down", "Not", "Up"), name = "Sig") +
  geom_vline(xintercept = c(-1, 1), linetype = 3, linewidth = 0.25) +
  geom_hline(yintercept = -log10(0.05), linetype = 3, linewidth = 0.25) +
  labs(x = "logFC", y = expression(-log[10](FDR))) + paper_theme

top_heat <- de[order(adj.P.Val, -abs(logFC))][1:min(80, .N), gene]
hm <- expr_after[top_heat, , drop = FALSE]
hm <- t(scale(t(hm)))
hm[hm > 4] <- 4; hm[hm < -4] <- -4
ann_col <- data.frame(Project = meta$dataset, Type = meta$group,
                      row.names = meta$sample)
ph <- pheatmap(
  hm, cluster_rows = TRUE, cluster_cols = TRUE,
  show_rownames = FALSE, show_colnames = FALSE,
  annotation_col = ann_col,
  annotation_colors = list(Project = dataset_cols,
                           Type = c(Control = "#52D6E6", Periodontitis = "#F78B8B")),
  color = colorRampPalette(c("#0000F2", "white", "#F20D0D"))(101),
  breaks = seq(-4, 4, length.out = 102), border_color = NA,
  fontsize = 7, silent = TRUE
)
pF <- as.ggplot(ph$gtable)

gene_tree <- net$dendrograms[[1]]
block_genes <- net$blockGenes[[1]]
tree_cols <- module_colors[block_genes]
pG_core <- as.ggplot(~ plotDendroAndColors(
  gene_tree, tree_cols, " ",
  dendroLabels = FALSE, hang = 0.03, addGuide = TRUE, guideHang = 0.05,
  main = "", xlab = "",
  marAll = c(1.5, 5, 2, 1), cex.colorLabels = 0.70
))
pG <- ggdraw(pG_core) +
  draw_label("Gene dendrogram and module colors", x = 0.52, y = 0.985,
             size = 9, fontfamily = "Arial", vjust = 1) +
  draw_label("Merged dynamic", x = 0.52, y = 0.02,
             size = 7, fontfamily = "Arial", vjust = 0)

trait_long[, label := sprintf("%.2f\n(%.1g)", correlation, p_value)]
pH <- ggplot(trait_long, aes(trait, module, fill = correlation)) +
  geom_tile(colour = "white", linewidth = 0.5) +
  geom_text(aes(label = label), size = 2.2, family = "Arial") +
  scale_fill_gradient2(low = "#1976D2", mid = "white", high = "#E64B35",
                       midpoint = 0, limits = c(-1, 1), name = "") +
  labs(title = "Module-trait relationships", x = NULL, y = NULL) +
  paper_theme + theme(axis.text.x = element_text(size = 7),
                      axis.text.y = element_text(size = 6.5),
                      legend.position = "right",
                      plot.margin = ggplot2::margin(8, 3, 3, 3))

fig1 <- (pA | pB) / (pC | pD) / (pE | pF) / (pG | pH) +
  plot_layout(widths = c(1.45, 1), heights = c(1, 1, 1.05, 1.05)) +
  plot_annotation(tag_levels = "A", theme = theme(
    plot.tag = element_text(family = "Arial", size = 15, face = "plain")
  ))

ggsave(file.path(FD, "Fig1_Gingiva_bulk_ComBat_DEG_WGCNA_BioorgChem_style.pdf"),
       fig1, width = 10.8, height = 13.3, units = "in", device = cairo_pdf)
ggsave(file.path(FD, "Fig1_Gingiva_bulk_ComBat_DEG_WGCNA_BioorgChem_style.png"),
       fig1, width = 10.8, height = 13.3, units = "in", dpi = 300, bg = "white")

message("[6/6] Completed Fig. 1")
cat("batch_method=", batch_method, "\n", sep = "")
cat("strict_DEGs=", length(strict_deg), "\n", sep = "")
cat("WGCNA_genes=", ncol(datExpr), "\n", sep = "")
cat("selected_module=", selected_module, " (n=", length(selected_genes), ")\n", sep = "")
