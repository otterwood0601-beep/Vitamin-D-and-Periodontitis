from __future__ import annotations
import sys
from pathlib import Path
import pandas as pd
from neuroCombat import neuroCombat

def main() -> int:
    if len(sys.argv) != 4:
        raise SystemExit('usage: combat_batch.py <expression.csv.gz> <metadata.csv> <output.csv.gz>')
    expression_path = Path(sys.argv[1])
    metadata_path = Path(sys.argv[2])
    output_path = Path(sys.argv[3])
    expr = pd.read_csv(expression_path, compression='gzip', index_col=0)
    meta = pd.read_csv(metadata_path)
    meta = meta.set_index('sample').loc[expr.columns]
    covars = pd.DataFrame({'batch': meta['dataset'].astype(str), 'group': meta['group'].astype(str)}, index=meta.index)
    adjusted = neuroCombat(dat=expr, covars=covars, batch_col='batch', categorical_cols=['group'], eb=True, parametric=True, mean_only=False, ref_batch=None)['data']
    out = pd.DataFrame(adjusted, index=expr.index, columns=expr.columns)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(output_path, compression='gzip', index=True, index_label='gene')
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
