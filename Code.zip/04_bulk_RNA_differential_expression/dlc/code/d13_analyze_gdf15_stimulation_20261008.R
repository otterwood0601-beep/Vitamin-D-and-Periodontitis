suppressPackageStartupMessages({library(edgeR);library(limma)})
stage <- "C:/Users/Lin/AppData/Local/Temp/gdf15_stim_20261008"
allres <- list(); expression <- list(); diagnostics <- list(); sensitivities <- list()
for (ds in c("GSE216757","GSE335644")) {
  counts <- as.matrix(read.delim(file.path(stage,paste0(ds,"_counts.tsv")),row.names=1,check.names=FALSE))
  m <- read.csv(file.path(stage,paste0(ds,"_meta.csv")),stringsAsFactors=FALSE)
  stopifnot(identical(colnames(counts),m$sample))
  m$donor <- factor(m$donor)
  lev <- if(ds=="GSE216757") c("ctrl","Pg") else c("ctrl","Fn","IFNg","FnIFNg")
  m$condition <- factor(m$condition,levels=lev)
  design <- model.matrix(~donor+condition,data=m)
  y <- DGEList(counts)
  keep <- filterByExpr(y,design=design)
  stopifnot(keep[which(rownames(y)=="ENSG00000130513")])
  y <- y[keep,,keep.lib.sizes=FALSE]
  y <- calcNormFactors(y,method="TMM")
  y <- estimateDisp(y,design,robust=TRUE)
  fit <- glmQLFit(y,design,robust=TRUE)
  logcpm <- cpm(y,log=TRUE,prior.count=.5)
  rawcpm <- cpm(y,log=FALSE)
  e <- cbind(m,data.frame(GDF15_count=counts["ENSG00000130513",],
                  filtered_library_size=y$samples$lib.size,TMM_factor=y$samples$norm.factors,
                  GDF15_CPM=rawcpm["ENSG00000130513",],GDF15_logCPM=logcpm["ENSG00000130513",]))
  expression[[ds]] <- e
  diagnostics[[ds]] <- data.frame(dataset=ds,n_genes_retained=nrow(y),n_samples=ncol(y),
                          design_rank=qr(design)$rank,design_columns=ncol(design),common_dispersion=y$common.dispersion)
  for (treat in lev[-1]) {
    test <- glmQLFTest(fit,coef=which(colnames(design)==paste0("condition",treat)))
    tt <- topTags(test,n=Inf,sort.by="none")$table
    row <- tt["ENSG00000130513",]
    paired <- reshape(e[e$condition %in% c("ctrl",treat),c("donor","condition","GDF15_logCPM")],
                      idvar="donor",timevar="condition",direction="wide")
    del <- paired[[paste0("GDF15_logCPM.",treat)]]-paired$GDF15_logCPM.ctrl
    allres[[paste(ds,treat)]] <- data.frame(dataset=ds,comparison=paste0(treat,"_vs_ctrl"),
      time_h=if(ds=="GSE216757") 4 else 24,n_pairs=length(del),log2FC=row$logFC,fold_change=2^row$logFC,
      PValue=row$PValue,transcriptome_FDR=row$FDR,n_pairs_increased=sum(del>0),
      method="edgeR paired robust quasi-likelihood; TMM",direction=if(row$logFC>0) "up" else "down")
  }
}

ds <- "GSE118691"
x <- as.matrix(read.delim(file.path(stage,paste0(ds,"_FPKM.tsv")),row.names=1,check.names=FALSE))
m <- read.csv(file.path(stage,paste0(ds,"_meta.csv")),stringsAsFactors=FALSE)
m$time_disagreement <- toupper(as.character(m$time_disagreement))=="TRUE"
stopifnot(identical(colnames(x),m$sample))
for (hours in c(2,6,12,24,48)) {
 for (analysis in c("primary","title_based_sensitivity")) {
  eligible <- m$title_time==hours & m$condition %in% c("ctrl","Fn")
  if(analysis=="primary") eligible <- eligible & !m$time_disagreement
  mm <- m[eligible,,drop=FALSE]
  good <- names(which(table(mm$donor)==2))
  mm <- mm[mm$donor %in% good,,drop=FALSE]
  xx <- x[,mm$sample,drop=FALSE]
  mm$donor <- factor(mm$donor);mm$condition <- factor(mm$condition,levels=c("ctrl","Fn"))
  design <- model.matrix(~donor+condition,data=mm)
  
  keep <- rowSums(xx>.5)>=2
  xx <- xx[keep,,drop=FALSE]
  stopifnot("9518" %in% rownames(xx))
  fit <- lmFit(log2(xx+.5),design)
  fit <- eBayes(fit,trend=TRUE,robust=TRUE)
  j <- which(colnames(design)=="conditionFn")
  tt <- topTable(fit,coef=j,number=Inf,sort.by="none")
  row <- tt["9518",]
  ed <- cbind(mm,data.frame(GDF15_FPKM=xx["9518",],GDF15_logFPKM=log2(xx["9518",]+.5)))
  paired <- reshape(ed[,c("donor","condition","GDF15_logFPKM")],idvar="donor",timevar="condition",direction="wide")
  del <- paired$GDF15_logFPKM.Fn-paired$GDF15_logFPKM.ctrl
  r <- data.frame(dataset=ds,comparison=paste0("Fn_vs_ctrl_",hours,"h"),time_h=hours,
     n_pairs=length(del),log2FC=row$logFC,fold_change=2^row$logFC,PValue=row$P.Value,
     transcriptome_FDR=row$adj.P.Val,n_pairs_increased=sum(del>0),
     method="limma paired robust trend on log2(FPKM+0.5)",direction=if(row$logFC>0) "up" else "down")
  if(analysis=="primary") {
    allres[[paste(ds,hours)]] <- r
    expression[[paste(ds,hours)]] <- ed
  } else {
    sensitivities[[paste(ds,hours)]] <- r
  }
 }
}
result <- do.call(rbind,allres);rownames(result)<-NULL
stopifnot(nrow(result)==9)
result$GDF15_9_comparison_FDR <- p.adjust(result$PValue,method="BH")
write.csv(result,file.path(stage,"02_GDF15_all_primary_results.csv"),row.names=FALSE)
write.csv(do.call(rbind,sensitivities),file.path(stage,"03_GSE118691_title_based_sensitivity.csv"),row.names=FALSE)
write.csv(do.call(rbind,diagnostics),file.path(stage,"04_count_model_diagnostics.csv"),row.names=FALSE)
for(n in names(expression)) write.csv(expression[[n]],file.path(stage,paste0("expression_",n,".csv")),row.names=FALSE)
writeLines(capture.output(sessionInfo()),file.path(stage,"05_R_sessionInfo.txt"))
print(result)
cat("[DONE] All three datasets analyzed; no plots generated\n")
