import os, sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats as st
import gseapy as gp
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from style_npj import set_npj_style, save_npj, NPJ_CASE, NPJ_CTRL, MM
set_npj_style()
DER = 'C:\\wb_links\\dlc_derived'
OUTDIR = 'C:\\wb_links\\dlc_out\\\u6838\u5fc3\u7ed3\u679cA_\u72ec\u7acb\u590d\u73b0'
os.makedirs(OUTDIR, exist_ok=True)
cnt = pd.read_csv(os.path.join(DER, 'external_GSE223924', 'GSE223924_raw_count.csv.gz'), index_col=0)
h_cols = [c for c in cnt.columns if c.startswith('H')]
pt_cols = [c for c in cnt.columns if c.startswith('PT')]
print('H:', len(h_cols), 'PT:', len(pt_cols))
keep = (cnt >= 10).sum(axis=1) >= 3
cnt = cnt[keep]
lib = cnt.sum(axis=0)
logcpm = np.log2(cnt.div(lib, axis=1) * 1000000.0 + 0.5)
tvals, pvals = st.ttest_ind(logcpm[pt_cols], logcpm[h_cols], axis=1, equal_var=False)
from statsmodels.stats.multitest import multipletests
fdr = multipletests(pvals, method='fdr_bh')[1]
de = pd.DataFrame({'symbol': cnt.index, 'ext_t': tvals, 'ext_p': pvals, 'ext_FDR': fdr, 'ext_log2FC': logcpm[pt_cols].mean(axis=1) - logcpm[h_cols].mean(axis=1)})
de.to_csv(os.path.join(DER, 'A2_GSE223924_DE_PT_vs_H.csv'), index=False)
print('GDF15:', de[de.symbol == 'GDF15'].to_string())
SETS = {'MAPK/ERK response': ['FOS', 'FOSB', 'JUN', 'JUNB', 'JUND', 'EGR1', 'EGR2', 'EGR3', 'DUSP1', 'DUSP4', 'DUSP5', 'DUSP6', 'DUSP10', 'MYC', 'IER2', 'NR4A1', 'NR4A2', 'ATF3', 'KLF2', 'KLF4', 'KLF6', 'ZFP36', 'BTG2', 'CYR61', 'CTGF'], 'ECM synthesis': ['COL1A1', 'COL1A2', 'COL3A1', 'COL5A1', 'COL5A2', 'COL6A1', 'COL6A2', 'COL6A3', 'DCN', 'LUM', 'FBN1', 'FMOD', 'BGN', 'FN1', 'SPARC', 'P4HA1', 'PLOD1', 'PLOD2', 'LOX', 'LOXL1', 'LOXL2', 'SERPINH1'], 'ECM proteases': ['MMP1', 'MMP2', 'MMP3', 'MMP9', 'MMP13', 'MMP14', 'MMP16', 'MMP19', 'ADAMTS1', 'ADAMTS4', 'ADAMTS5', 'CTSK', 'CTSL', 'CTSB', 'PLAU', 'PLAT'], 'ECM inhibitors': ['TIMP1', 'TIMP2', 'TIMP3', 'SERPINE1'], 'VFB markers': ['MCAM', 'RGS5', 'ACTA2', 'CSPG4', 'NOTCH3', 'ABCC9', 'KCNJ8', 'MYH11'], 'HoFB markers': ['PI16', 'FGF7', 'WIF1', 'SFRP2', 'DPP4', 'CD34', 'APOE', 'C7']}
z = logcpm.sub(logcpm.mean(axis=1), axis=0).div(logcpm.std(axis=1) + 1e-09, axis=0)
scores = {}
for name, genes in SETS.items():
    g = [x for x in genes if x in z.index]
    scores[name] = z.loc[g].mean(axis=0)
S = pd.DataFrame(scores)
S['group'] = ['PT' if c in pt_cols else 'H' for c in S.index]
S.to_csv(os.path.join(DER, 'A2_GSE223924_program_scores.csv'))
rows = []
for name in SETS:
    h = S.loc[S.group == 'H', name]
    p = S.loc[S.group == 'PT', name]
    u = st.mannwhitneyu(p, h, alternative='two-sided')
    rows.append({'program': name, 'mean_H': h.mean(), 'mean_PT': p.mean(), 'MWU_p': u.pvalue})
prog_stats = pd.DataFrame(rows)
prog_stats.to_csv(os.path.join(DER, 'A2_GSE223924_program_stats.csv'), index=False)
print(prog_stats.to_string())
disc = pd.read_csv('C:\\wb_links\\fig4_src\\03_donor_pseudobulk_DE_periodontitis_vs_healthy.csv.gz', encoding='utf-8-sig')
mm = de.merge(disc[['gene', 't_statistic']], left_on='symbol', right_on='gene')
rho, rho_p = st.spearmanr(mm.ext_t, mm.t_statistic)
print(f'cross-cohort t-stat Spearman rho={rho:.3f} p={rho_p:.2e} (n={len(mm)})')
rnk = de[['symbol', 'ext_t']].dropna()
pre = gp.prerank(rnk=rnk, gene_sets=SETS, permutation_num=1000, seed=42, threads=4, min_size=4, max_size=2000, outdir=None, verbose=False)
g_ext = pre.res2d[['Term', 'NES', 'FDR q-val']].rename(columns={'Term': 'program', 'NES': 'NES_ext', 'FDR q-val': 'FDR_ext'})
g_ext.to_csv(os.path.join(DER, 'A2_GSE223924_program_GSEA.csv'), index=False)
print(g_ext.to_string())
fig = plt.figure(figsize=(180 * MM, 95 * MM))
gs = fig.add_gridspec(1, 3, width_ratios=[1.6, 0.55, 0.9], wspace=0.35, left=0.07, right=0.97, top=0.84, bottom=0.16)

def mini_box2(ax, h, p, ylab=None):
    data = [np.asarray(h), np.asarray(p)]
    bp = ax.boxplot(data, positions=[0, 1], widths=0.55, patch_artist=True, showfliers=False, medianprops=dict(color='black', lw=0.8), whiskerprops=dict(lw=0.6), capprops=dict(lw=0.6), boxprops=dict(lw=0.6))
    for patch, c in zip(bp['boxes'], [NPJ_CTRL, NPJ_CASE]):
        patch.set_facecolor(c)
        patch.set_alpha(0.75)
    rng = np.random.default_rng(42)
    for x, vals, c in [(0, data[0], NPJ_CTRL), (1, data[1], NPJ_CASE)]:
        ax.scatter(x + rng.uniform(-0.12, 0.12, len(vals)), vals, s=7, c=c, ec='black', lw=0.3, zorder=3)
    pv = st.mannwhitneyu(data[1], data[0], alternative='two-sided').pvalue
    star = '***' if pv < 0.001 else '**' if pv < 0.01 else '*' if pv < 0.05 else 'ns'
    y0 = max((d.max() for d in data))
    ymin = min((d.min() for d in data))
    yr = max((y0 - ymin) * 0.15, 1e-06)
    ax.plot([0, 0, 1, 1], [y0 + yr * 0.4, y0 + yr, y0 + yr, y0 + yr * 0.4], lw=0.7, c='black')
    ax.text(0.5, y0 + yr * 1.15, star, ha='center', va='bottom', fontsize=8)
    ax.set_xlim(-0.6, 1.6)
    ax.set_xticks([0, 1])
    ax.set_xticklabels(['H', 'PD'], fontsize=7)
    ax.set_ylim(ymin - yr, y0 + yr * 2.6)
    if ylab:
        ax.set_ylabel(ylab, fontsize=7)
gsA = gs[0, 0].subgridspec(2, 3, wspace=0.45, hspace=0.6)
nes_map = g_ext.set_index('program')
for i, name in enumerate(SETS):
    ax = fig.add_subplot(gsA[i // 3, i % 3])
    mini_box2(ax, S.loc[S.group == 'H', name].values, S.loc[S.group == 'PT', name].values, ylab='Program score (z)' if i % 3 == 0 else None)
    nes = nes_map.loc[name, 'NES_ext']
    fd = nes_map.loc[name, 'FDR_ext']
    star = '***' if fd < 0.001 else '**' if fd < 0.01 else '*' if fd < 0.05 else 'ns'
    ax.set_title(f'{name}\nGSEA NES={nes:.2f} {star}', fontsize=6.8, fontweight='bold', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=0.3'))
fig.text(0.045, 0.92, 'A', fontsize=12, fontweight='bold')
axB = fig.add_subplot(gs[0, 1])
g_h = logcpm.loc['GDF15', h_cols].values
g_p = logcpm.loc['GDF15', pt_cols].values
mini_box2(axB, g_h, g_p, ylab='GDF15 log2(CPM+0.5)')
axB.set_title('GDF15', fontsize=7.5, fontweight='bold', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=0.3'))
fig.text(0.545, 0.92, 'B', fontsize=12, fontweight='bold')
axC = fig.add_subplot(gs[0, 2])
axC.scatter(mm.t_statistic, mm.ext_t, s=2, c='#BFBFBF', lw=0, rasterized=True)
gd = mm[mm.symbol == 'GDF15']
axC.scatter(gd.t_statistic, gd.ext_t, s=25, c='#7E5AA7', ec='black', lw=0.5, zorder=5)
axC.annotate('GDF15', (gd.t_statistic.iloc[0], gd.ext_t.iloc[0]), textcoords='offset points', xytext=(6, 4), fontsize=7)
axA_x = np.linspace(*axC.get_xlim(), 10)
axC.axhline(0, c='black', lw=0.5)
axC.axvline(0, c='black', lw=0.5)
axC.set_xlabel('Discovery t (fibroblast pseudobulk)')
axC.set_ylabel('External t (GSE223924 bulk)')
axC.text(0.03, 0.97, f'Spearman \u03c1 = {rho:.2f}\np = {rho_p:.0e}', transform=axC.transAxes, fontsize=7, va='top')
axC.set_title('Cross-cohort concordance', fontsize=8, fontweight='bold', bbox=dict(facecolor='#E4E6EB', edgecolor='none', boxstyle='square,pad=0.35'))
fig.text(0.72, 0.92, 'C', fontsize=12, fontweight='bold')
save_npj(fig, os.path.join(OUTDIR, '\u6838\u5fc3\u7ed3\u679cA_\u72ec\u7acb\u590d\u73b0_GSE223924'), width_mm=180, height_mm=95, dpi=600)
print('FIG SAVED')
