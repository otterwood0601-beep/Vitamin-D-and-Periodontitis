from pathlib import Path
import json
import pandas as pd
from IPython.display import display, Image
stage = Path('E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u8f93\u51fa/20260724-\u6700\u65b0\u7248\u8ba1\u5212\uff08\u7ef4\u751f\u7d20D-\u7259\u9f88-\u9f8b\u75c5_\u53c2\u8003\u6587\u732eFigure3-4\u590d\u7b97\uff09/12_GSE212728_\u539f\u59cbRNAseq_DESeq2_Figure3C-G')
metadata = pd.read_csv(stage / '00_\u6570\u636e\u5ba1\u8ba1' / '01_GSE212728_SRA\u6837\u672c\u8bbe\u8ba1.csv')
metadata[['run', 'gsm', 'analysis_sample', 'group', 'treatment', 'cell_type']]
alignment = pd.read_csv(stage / '00_\u6570\u636e\u5ba1\u8ba1' / '06_GSE212728_alignment_assignment_summary.csv')
alignment
de_all = pd.read_csv(stage / '02_DESeq2' / '01_GSE212728_DESeq2_D3_vs_Control_all_genes.csv')
candidate = pd.read_csv(stage / '02_DESeq2' / '06_\u4e94\u4e2aSMR\u5019\u9009\u57fa\u56e0_DESeq2\u7ed3\u679c.csv')
summary = pd.DataFrame({'metric': ['tested genes', 'P<0.05 & |FC|>=1.2', 'FDR<0.05 & |FC|>=1.2'], 'value': [de_all['pvalue'].notna().sum(), de_all['reference_style_positive'].sum(), de_all['strict_FDR_positive'].sum()]})
display(summary)
display(candidate[['gene_symbol', 'baseMean', 'log2FoldChange', 'absolute_fold_change', 'pvalue', 'padj', 'reference_style_positive', 'direction']])
go = pd.read_csv(stage / '03_GO_Reactome' / '01_clusterProfiler_GO_BP_CC_MF_all.csv')
reactome = pd.read_csv(stage / '03_GO_Reactome' / '03_clusterProfiler_Reactome_all.csv')
enrichment_summary = pd.DataFrame({'database': ['GO', 'Reactome'], 'nominal_P_lt_0.05': [(go['pvalue'] < 0.05).sum(), (reactome['pvalue'] < 0.05).sum()], 'BH_FDR_lt_0.05': [(go['p.adjust'] < 0.05).sum(), (reactome['p.adjust'] < 0.05).sum()]})
enrichment_summary
composite = stage / '04_Figure3C-G' / 'Figure_3C-G_composite_reference_style.png'
Image(filename=str(composite))
