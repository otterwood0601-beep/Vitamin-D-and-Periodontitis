from __future__ import annotations
import json
import os
import sys
from pathlib import Path
RUN_ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20')
STAGE = RUN_ROOT / '\u8f93\u51fa\u7ed3\u679c' / '03_Bulk_RNA' / '12_GSE212728_\u539f\u59cbRNAseq_DESeq2_Figure3C-G'
QA_DIR = STAGE / '05_\u53ef\u590d\u73b0\u4e0eQA'
DE_DIR = STAGE / '02_DESeq2'
ENRICHMENT_DIR = STAGE / '03_GO_Reactome'
FIGURE_DIR = STAGE / '04_Figure3C-G'
NOTEBOOK_PATH = QA_DIR / 'GSE212728_raw_RNAseq_DESeq2_Figure3C-G.ipynb'
LOCAL_PACKAGES = RUN_ROOT / '\u4ee3\u7801' / '\u8fd0\u884c\u73af\u5883' / 'python_notebook_pkgs'
sys.path.insert(0, str(LOCAL_PACKAGES))
import nbformat as nbf
import pandas as pd
from nbclient import NotebookClient

def posix(path: Path) -> str:
    return path.resolve().as_posix()

def format_gene_list(genes: list[str]) -> str:
    return '\u3001'.join(genes) if genes else '\u65e0'

def main() -> None:
    QA_DIR.mkdir(parents=True, exist_ok=True)
    candidate_path = DE_DIR / '06_\u4e94\u4e2aSMR\u5019\u9009\u57fa\u56e0_DESeq2\u7ed3\u679c.csv'
    audit_path = STAGE / '00_\u6570\u636e\u5ba1\u8ba1' / '08_GSE212728_DESeq2_enrichment_audit.json'
    candidate_results = pd.read_csv(candidate_path)
    audit = json.loads(audit_path.read_text(encoding='utf-8'))
    fixed_candidates = candidate_results['gene_symbol'].astype(str).tolist()
    positive_flag = candidate_results['reference_style_positive']
    if positive_flag.dtype != bool:
        positive_flag = positive_flag.astype(str).str.lower().eq('true')
    positive_candidates = candidate_results.loc[positive_flag, 'gene_symbol'].astype(str).tolist()
    primary_degs = int(audit['primary_DEGs'])
    strict_degs = int(audit['strict_DEGs'])
    go_terms = int(audit['GO_FDR005_terms'])
    reactome_terms = int(audit['Reactome_FDR005_terms'])
    if positive_candidates:
        candidate_takeaway = f'\u56fa\u5b9a\u5019\u9009\u57fa\u56e0\u4e2d\uff0c{format_gene_list(positive_candidates)} \u5728\u5168\u90e85\u4e2a\u6837\u672c\u7684\u4e3bDESeq2\u6a21\u578b\u4e2d\u540c\u65f6\u8fbe\u5230 P<0.05 \u548c |FC|\u22651.2\u3002'
    else:
        candidate_takeaway = '\u56fa\u5b9a\u76845\u4e2aSMR\u5019\u9009\u57fa\u56e0\u5747\u672a\u5728\u5168\u90e85\u4e2a\u6837\u672c\u7684\u4e3bDESeq2\u6a21\u578b\u4e2d\u540c\u65f6\u8fbe\u5230 P<0.05 \u548c |FC|\u22651.2\u3002'
    nb = nbf.v4.new_notebook()
    nb['metadata']['kernelspec'] = {'display_name': 'Python 3', 'language': 'python', 'name': 'python3'}
    nb['metadata']['language_info'] = {'name': 'python', 'version': sys.version.split()[0]}
    nb['cells'] = [nbf.v4.new_markdown_cell('# GSE212728\uff1a\u7ef4\u751f\u7d20D3\u5904\u7406\u4eba\u7259\u9f88\u6210\u7ea4\u7ef4\u7ec6\u80de\n\n\u539f\u59cbSRA reads \u2192 Rsubread\u6bd4\u5bf9 \u2192 featureCounts gene counts \u2192 DESeq2 \u2192 clusterProfiler GO/Reactome \u2192 Figure 3C\u2013G'), nbf.v4.new_markdown_cell(f'## tl;dr\n\n- \u4e3b\u9608\u503c\uff08\u4e0e\u53c2\u8003\u6587\u732e\u4e00\u81f4\uff09\u5f97\u5230 **{primary_degs}** \u4e2a\u5dee\u5f02\u57fa\u56e0\uff1a\u672a\u6821\u6b63 P<0.05 \u4e14 |fold change|\u22651.2\u3002\n- \u4e25\u683c\u8865\u5145\u9608\u503c\u5f97\u5230 **{strict_degs}** \u4e2a\u5dee\u5f02\u57fa\u56e0\uff1aBH FDR<0.05 \u4e14 |fold change|\u22651.2\u3002\n- {candidate_takeaway}\n- GO\u4e0eReactome\u5206\u522b\u6709 **{go_terms}** \u548c **{reactome_terms}** \u4e2aBH FDR<0.05\u6761\u76ee\u3002\n- \u672c\u9636\u6bb5\u7528\u4e8e\u68c0\u67e5D3\u76f4\u63a5\u8f6c\u5f55\u8c03\u63a7\uff0c\u4e0d\u628a\u8f6c\u5f55\u5173\u8054\u5199\u6210\u5df2\u8bc1\u5b9e\u7684\u4ecb\u5bfc\u4f5c\u7528\u3002'), nbf.v4.new_markdown_cell(f'## Context & Methods\n\nGSE212728\u5305\u542b\u4eba\u7259\u9f88\u6210\u7ea4\u7ef4\u7ec6\u80de\u63a5\u53d7\u7ef4\u751f\u7d20D3\uff081000 nM\uff0c48 h\uff09\u62160.1%\u4e59\u9187\u5bf9\u7167\u3002\u516c\u5f00SRA\u5b9e\u9645\u4e3a3\u4e2aD3\u6837\u672c\u548c2\u4e2a\u5bf9\u7167\u6837\u672c\u3002\n\n### Key Assumptions\n\n- \u4f7f\u7528\u5168\u90e85\u4e2a\u516c\u5f00\u6837\u672c\uff0c\u4e0d\u6539\u5206\u7ec4\u3001\u4e0d\u5220\u9664\u6837\u672c\u3002\n- DESeq2\u8bbe\u8ba1\u4e3a `~ group`\uff0c\u5bf9\u6bd4\u65b9\u5411\u4e3a D3 / Control\u3002\n- \u4e3b\u8981\u5dee\u5f02\u9608\u503c\u56fa\u5b9a\u4e3a `P < 0.05` \u4e14 `|FC| >= 1.2`\uff1bBH FDR\u7ed3\u679c\u4f5c\u4e3a\u8865\u5145\u3002\n- \u56fa\u5b9aSMR\u5019\u9009\u57fa\u56e0\u4e3a\uff1a{format_gene_list(fixed_candidates)}\u3002\n- PRJNA1428887\u662f\u5c0f\u9f20\u53e3\u8154\u5fae\u751f\u7269\u6269\u589e\u5b50\u6570\u636e\uff0c\u4e0d\u4f5c\u4e3a\u5bbf\u4e3b\u7259\u9f88bulk RNA-seq\u66ff\u4ee3\u6570\u636e\u3002'), nbf.v4.new_markdown_cell('## Data'), nbf.v4.new_code_cell(f"from pathlib import Path\nimport json\nimport pandas as pd\nfrom IPython.display import display, Image\n\nstage = Path(r'{posix(STAGE)}')\nmetadata = pd.read_csv(stage / '00_\u6570\u636e\u5ba1\u8ba1' / '01_GSE212728_SRA\u6837\u672c\u8bbe\u8ba1.csv')\nmetadata[['run', 'gsm', 'analysis_sample', 'group', 'treatment', 'cell_type']]"), nbf.v4.new_code_cell("alignment = pd.read_csv(stage / '00_\u6570\u636e\u5ba1\u8ba1' / '06_GSE212728_alignment_assignment_summary.csv')\nalignment"), nbf.v4.new_markdown_cell('## Results'), nbf.v4.new_code_cell("de_all = pd.read_csv(stage / '02_DESeq2' / '01_GSE212728_DESeq2_D3_vs_Control_all_genes.csv')\ncandidate = pd.read_csv(stage / '02_DESeq2' / '06_\u4e94\u4e2aSMR\u5019\u9009\u57fa\u56e0_DESeq2\u7ed3\u679c.csv')\nsummary = pd.DataFrame({\n    'metric': ['tested genes', 'P<0.05 & |FC|>=1.2', 'FDR<0.05 & |FC|>=1.2'],\n    'value': [de_all['pvalue'].notna().sum(), de_all['reference_style_positive'].sum(), de_all['strict_FDR_positive'].sum()]\n})\ndisplay(summary)\ndisplay(candidate[['gene_symbol', 'baseMean', 'log2FoldChange', 'absolute_fold_change', 'pvalue', 'padj', 'reference_style_positive', 'direction']])"), nbf.v4.new_code_cell("go = pd.read_csv(stage / '03_GO_Reactome' / '01_clusterProfiler_GO_BP_CC_MF_all.csv')\nreactome = pd.read_csv(stage / '03_GO_Reactome' / '03_clusterProfiler_Reactome_all.csv')\nenrichment_summary = pd.DataFrame({\n    'database': ['GO', 'Reactome'],\n    'nominal_P_lt_0.05': [(go['pvalue'] < 0.05).sum(), (reactome['pvalue'] < 0.05).sum()],\n    'BH_FDR_lt_0.05': [(go['p.adjust'] < 0.05).sum(), (reactome['p.adjust'] < 0.05).sum()]\n})\nenrichment_summary"), nbf.v4.new_code_cell("composite = stage / '04_Figure3C-G' / 'Figure_3C-G_composite_reference_style.png'\nImage(filename=str(composite))"), nbf.v4.new_markdown_cell(f'## Takeaways\n\n- {candidate_takeaway}\n- \u5728\u53c2\u8003\u6587\u732e\u5f0f\u9608\u503c\u4e0b\u5171\u8bc6\u522b\u51fa {primary_degs} \u4e2aD3\u54cd\u5e94\u5dee\u5f02\u57fa\u56e0\uff1b\u5176\u4e2d {strict_degs} \u4e2a\u540c\u65f6\u901a\u8fc7BH FDR<0.05\u3002\n- GO\u4e0eReactome\u4e2d\u5206\u522b\u6709 {go_terms} \u548c {reactome_terms} \u4e2aFDR\u663e\u8457\u6761\u76ee\uff0c\u5177\u4f53\u89e3\u91ca\u5e94\u4ee5\u8f93\u51fa\u8868\u4e2d\u5b9e\u9645\u6761\u76ee\u4e3a\u51c6\uff0c\u4e0d\u9884\u8bbe\u7ef4\u751f\u7d20D/VDR\u3001\u9499\u4fe1\u53f7\u6216\u9f8b\u75c5\u901a\u8def\u5fc5\u7136\u5bcc\u96c6\u3002\n- \u7ed3\u8bba\u9650\u5b9a\u4e3a\uff1a\u8be5\u6570\u636e\u96c6\u63d0\u4f9b\u7ef4\u751f\u7d20D3\u76f4\u63a5\u5904\u7406\u7259\u9f88\u6210\u7ea4\u7ef4\u7ec6\u80de\u7684\u8f6c\u5f55\u7ec4\u8bc1\u636e\uff1b\u662f\u5426\u6784\u6210\u7ef4\u751f\u7d20D\u5f71\u54cd\u9f8b\u75c5\u7684\u5173\u952e\u4ecb\u8d28\uff0c\u4ecd\u9700\u4e0eSMR\u3001\u7259\u9f88\u5355\u7ec6\u80de\u5b9a\u4f4d\u548c\u5b9e\u9a8c\u9a8c\u8bc1\u5171\u540c\u5224\u65ad\u3002')]
    nbf.write(nb, NOTEBOOK_PATH)
    client = NotebookClient(nb, timeout=600, kernel_name='python3', allow_errors=False, resources={'metadata': {'path': str(STAGE)}})
    executed = client.execute()
    nbf.write(executed, NOTEBOOK_PATH)
    code_cells = [cell for cell in executed['cells'] if cell['cell_type'] == 'code']
    if not code_cells or any((cell.get('execution_count') is None for cell in code_cells)):
        raise RuntimeError('Notebook execution counts are incomplete.')
    validation = {'notebook': str(NOTEBOOK_PATH), 'executed_top_to_bottom': True, 'code_cells': len(code_cells), 'cells_with_execution_count': sum((cell.get('execution_count') is not None for cell in code_cells)), 'allow_errors': False, 'kernel': 'python3'}
    (QA_DIR / 'notebook_execution_validation.json').write_text(json.dumps(validation, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(validation, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
