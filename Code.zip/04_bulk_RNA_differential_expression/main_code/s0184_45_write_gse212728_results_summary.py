from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
RUN_ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20')
STAGE = RUN_ROOT / '\u8f93\u51fa\u7ed3\u679c' / '03_Bulk_RNA' / '12_GSE212728_\u539f\u59cbRNAseq_DESeq2_Figure3C-G'
AUDIT_DIR = STAGE / '00_\u6570\u636e\u5ba1\u8ba1'
DE_DIR = STAGE / '02_DESeq2'
ENRICHMENT_DIR = STAGE / '03_GO_Reactome'
OUTPUT = STAGE / '00_GSE212728_\u7ed3\u679c\u6458\u8981.md'

def boolean_series(values: pd.Series) -> pd.Series:
    if values.dtype == bool:
        return values
    return values.astype(str).str.lower().eq('true')

def markdown_escape(value: object) -> str:
    return str(value).replace('|', '\\|').replace('\n', ' ')

def format_number(value: object, digits: int=3) -> str:
    if pd.isna(value):
        return 'NA'
    return f'{float(value):.{digits}g}'

def candidate_table(frame: pd.DataFrame) -> list[str]:
    lines = ['| Gene | log2FC (D3/Control) | |FC| | P | BH FDR | \u4e3b\u9608\u503c\u9633\u6027 |', '|---|---:|---:|---:|---:|:---:|']
    flags = boolean_series(frame['reference_style_positive'])
    for (_, row), flag in zip(frame.iterrows(), flags, strict=True):
        lines.append('| ' + ' | '.join([markdown_escape(row['gene_symbol']), format_number(row['log2FoldChange']), format_number(row['absolute_fold_change']), format_number(row['pvalue']), format_number(row['padj']), '\u662f' if flag else '\u5426']) + ' |')
    return lines

def top_terms(frame: pd.DataFrame, number: int) -> list[str]:
    if frame.empty:
        return ['- \u65e0 BH FDR < 0.05 \u6761\u76ee\u3002']
    frame = frame.sort_values(['p.adjust', 'pvalue']).head(number)
    return [f"- {markdown_escape(row['Description'])} (FDR={format_number(row['p.adjust'])}, Count={int(row['Count'])})" for _, row in frame.iterrows()]

def main() -> None:
    audit = json.loads((AUDIT_DIR / '08_GSE212728_DESeq2_enrichment_audit.json').read_text(encoding='utf-8'))
    candidate = pd.read_csv(DE_DIR / '06_\u4e94\u4e2aSMR\u5019\u9009\u57fa\u56e0_DESeq2\u7ed3\u679c.csv')
    alignment = pd.read_csv(AUDIT_DIR / '06_GSE212728_alignment_assignment_summary.csv')
    go_fdr = pd.read_csv(ENRICHMENT_DIR / '02_clusterProfiler_GO_BP_CC_MF_FDR005.csv')
    reactome_fdr = pd.read_csv(ENRICHMENT_DIR / '04_clusterProfiler_Reactome_FDR005.csv')
    positive_flags = boolean_series(candidate['reference_style_positive'])
    positive = candidate.loc[positive_flags, 'gene_symbol'].astype(str).tolist()
    assignment_min = alignment['assignment_rate'].min()
    assignment_max = alignment['assignment_rate'].max()
    lines = ['# GSE212728 \u539f\u59cb RNA-seq \u7ed3\u679c\u6458\u8981', '', '## \u4e3b\u8981\u7ed3\u679c', '', f'- \u5168\u90e8 5 \u4e2a\u516c\u5f00\u6837\u672c\u5747\u8fdb\u5165\u5206\u6790\uff08D3=3\uff0cControl=2\uff09\uff1bfeatureCounts \u5206\u914d\u7387\u4e3a {assignment_min:.1%}\u2013{assignment_max:.1%}\u3002', f"- \u53c2\u8003\u6587\u732e\u4e3b\u9608\u503c `P<0.05 \u4e14 |FC|\u22651.2`\uff1a{int(audit['primary_DEGs'])} \u4e2a\u5dee\u5f02\u57fa\u56e0\u3002", f"- \u4e25\u683c\u8865\u5145\u9608\u503c `BH FDR<0.05 \u4e14 |FC|\u22651.2`\uff1a{int(audit['strict_DEGs'])} \u4e2a\u5dee\u5f02\u57fa\u56e0\u3002", '- \u56fa\u5b9a SMR \u5019\u9009\u4e2d\u8fbe\u5230\u4e3b\u9608\u503c\u7684\u57fa\u56e0\uff1a' + ('\u3001'.join(positive) if positive else '\u65e0') + '\u3002', '', '## \u56fa\u5b9a SMR \u5019\u9009\u57fa\u56e0', '', *candidate_table(candidate), '', '## GO\uff1aFDR \u6700\u663e\u8457\u6761\u76ee', '']
    for ontology in ('BP', 'CC', 'MF'):
        lines.extend([f'### {ontology}', '', *top_terms(go_fdr.loc[go_fdr['Ontology'].astype(str) == ontology], 5), ''])
    lines.extend(['## Reactome\uff1aFDR \u6700\u663e\u8457\u6761\u76ee', '', *top_terms(reactome_fdr, 10), '', '## \u7ed3\u8bba', ''])
    if positive:
        lines.append('\u56fa\u5b9a\u9057\u4f20\u5019\u9009\u4e2d\uff0c' + '\u3001'.join(positive) + ' \u540c\u65f6\u83b7\u5f97 D3 \u76f4\u63a5\u5904\u7406\u7259\u9f88\u6210\u7ea4\u7ef4\u7ec6\u80de\u7684\u5dee\u5f02\u8868\u8fbe\u652f\u6301\uff0c\u53ef\u8fdb\u5165\u540e\u7eed\u7259\u9f88\u5355\u7ec6\u80de\u5b9a\u4f4d\u3002')
    else:
        lines.append('\u672c\u6b21\u539f\u59cb RNA-seq \u590d\u7b97\u663e\u793a\u7259\u9f88\u6210\u7ea4\u7ef4\u7ec6\u80de\u5b58\u5728\u660e\u786e\u7684 D3 \u8f6c\u5f55\u54cd\u5e94\uff0c\u4f46\u4e94\u4e2a\u56fa\u5b9a SMR \u5019\u9009\u5747\u672a\u540c\u65f6\u8fbe\u5230\u9884\u8bbe P \u503c\u548c fold-change \u9608\u503c\uff1b\u56e0\u6b64\u672c bulk \u9636\u6bb5\u6ca1\u6709\u7b5b\u51fa\u53ef\u4e0e\u53c2\u8003\u6587\u732e PRKCA \u5904\u4e8e\u540c\u7b49\u4f4d\u7f6e\u7684\u5019\u9009\u4ecb\u8d28\u3002')
    lines.extend(['', '\u8be5\u7ed3\u8bba\u4ec5\u63cf\u8ff0\u9057\u4f20\u5019\u9009\u4e0e D3 \u76f4\u63a5\u5904\u7406\u8f6c\u5f55\u7ec4\u7684\u4ea4\u53c9\u9a8c\u8bc1\u7ed3\u679c\uff0c\u4e0d\u628a\u8f6c\u5f55\u5173\u8054\u5199\u6210\u5df2\u8bc1\u5b9e\u7684\u6297\u9f8b\u4ecb\u5bfc\u4f5c\u7528\u3002', '', '\u5b8c\u6574 Figure 3C\u2013G\uff1a`04_Figure3C-G/Figure_3C-G_composite_reference_style.png`\u3002'])
    OUTPUT.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(OUTPUT)
if __name__ == '__main__':
    main()
