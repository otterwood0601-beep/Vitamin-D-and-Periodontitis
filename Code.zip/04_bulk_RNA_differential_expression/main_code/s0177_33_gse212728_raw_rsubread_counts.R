options(stringsAsFactors = FALSE)

script_arg <- commandArgs(trailingOnly = FALSE)
script_path <- sub("^--file=", "", script_arg[grep("^--file=", script_arg)])
run_root <- normalizePath(file.path(dirname(script_path), ".."), winslash = "/", mustWork = TRUE)
stage_dir <- file.path(run_root, "12_GSE212728_\u539f\u59cbRNAseq_DESeq2_Figure3C-G")
audit_dir <- file.path(stage_dir, "00_\u6570\u636e\u5ba1\u8ba1")
counts_dir <- file.path(stage_dir, "01_gene_counts")
log_dir <- file.path(stage_dir, "logs")
dir.create(counts_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)

cache_root <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/04_Bulk_RNA/GSE212728"
fastq_dir <- file.path(cache_root, "fastq")
reference_dir <- file.path(cache_root, "reference")
workspace_temp <- file.path(run_root, "tmp", "GSE212728_raw_Rsubread")
reference_work_dir <- file.path(workspace_temp, "reference")
alignment_temp <- file.path(workspace_temp, "alignment_temp")
dir.create(reference_work_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(alignment_temp, recursive = TRUE, showWarnings = FALSE)

expected_cache <- normalizePath(
  "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/04_Bulk_RNA/GSE212728",
  winslash = "/",
  mustWork = TRUE
)
if (normalizePath(cache_root, winslash = "/", mustWork = TRUE) != expected_cache) {
  stop("Unexpected cache path.")
}
expected_workspace_temp <- normalizePath(
  workspace_temp,
  winslash = "/",
  mustWork = TRUE
)
if (!startsWith(
  normalizePath(alignment_temp, winslash = "/", mustWork = TRUE),
  paste0(expected_workspace_temp, "/alignment_temp")
)) {
  stop("Temporary alignment directory failed the safety check.")
}

.libPaths(c(
  file.path(cache_root, "R_library"),
  "C:/Users/Lin/AppData/Local/R/win-library/4.5",
  .libPaths()
))
suppressPackageStartupMessages(library(Rsubread))

metadata_path <- file.path(audit_dir, "01_GSE212728_SRA\u6837\u672c\u8bbe\u8ba1.csv")
metadata <- read.csv(metadata_path, check.names = FALSE)
metadata$group <- factor(metadata$group, levels = c("Control", "D3"))

expected_fastq <- data.frame(
  file = c(
    "SRR21430403_1.fastq.gz", "SRR21430403_2.fastq.gz",
    "SRR21430404_1.fastq.gz", "SRR21430404_2.fastq.gz",
    "SRR21430405_1.fastq.gz", "SRR21430405_2.fastq.gz",
    "SRR21430406_1.fastq.gz", "SRR21430406_2.fastq.gz",
    "SRR21430407_1.fastq.gz", "SRR21430407_2.fastq.gz"
  ),
  expected_bytes = c(
    1603924157, 1711249651, 1689181950, 1803313637, 1546335154,
    1644174386, 1787822999, 1970632580, 1597591967, 1731362588
  ),
  expected_md5 = c(
    "496def12946529d1c9752272fe6ab43e",
    "16884896b2c396a556cabf1671fb490a",
    "3ce9dc47989217b757fe13f101497fdf",
    "5768e1162746be24ba208246ec5ced1e",
    "8d56db31586834e44b961e40db8f147c",
    "4799cc456fa570806736f296fbfec2ea",
    "321ee1ae77699890f6f42643537e7955",
    "64a6fd5293fc99a30de9c68f04e35c42",
    "8cf2f0ec0e52c2be3899eb726fcb3a8b",
    "5f7d76595c3359fa3d4ab886a43e1a5f"
  )
)
expected_fastq$path <- file.path(fastq_dir, expected_fastq$file)
if (!all(file.exists(expected_fastq$path))) {
  missing <- expected_fastq$file[!file.exists(expected_fastq$path)]
  stop("Missing FASTQ files: ", paste(missing, collapse = ", "))
}
expected_fastq$actual_bytes <- file.info(expected_fastq$path)$size
expected_fastq$bytes_match <- (
  expected_fastq$actual_bytes == expected_fastq$expected_bytes
)
if (!all(expected_fastq$bytes_match)) {
  stop("At least one FASTQ file has an unexpected size.")
}
expected_fastq$actual_md5 <- unname(tools::md5sum(expected_fastq$path))
expected_fastq$md5_match <- (
  tolower(expected_fastq$actual_md5) == expected_fastq$expected_md5
)
write.csv(
  expected_fastq,
  file.path(audit_dir, "05_GSE212728_FASTQ_MD5\u5ba1\u8ba1.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)
if (!all(expected_fastq$md5_match)) {
  stop("At least one FASTQ file failed MD5 validation.")
}

gzip_exe <- "C:/Program Files/Git/usr/bin/gzip.exe"
if (!file.exists(gzip_exe)) {
  stop("gzip.exe was not found.")
}
genome_gz <- file.path(reference_dir, "GRCh38.primary_assembly.genome.fa.gz")
gtf_gz <- file.path(reference_dir, "gencode.v49.annotation.gtf.gz")
gtf_file <- file.path(reference_dir, "gencode.v49.annotation.gtf")
if (!all(file.exists(c(genome_gz, gtf_gz)))) {
  stop("GENCODE v49 genome or annotation archive is missing.")
}
reference_expected_md5 <- c(
  GRCh38.primary_assembly.genome.fa.gz = "1c73e18ea14fec14fe7eca5a48755de3",
  gencode.v49.annotation.gtf.gz = "0ef4a024ea2d35b1b88c12447b0b70b9"
)
reference_paths <- c(genome_gz, gtf_gz)
reference_observed_md5 <- tolower(unname(tools::md5sum(reference_paths)))
if (!identical(reference_observed_md5, unname(reference_expected_md5))) {
  stop("GENCODE genome or annotation MD5 validation failed.")
}

decompress_once <- function(source, destination) {
  if (file.exists(destination) && file.info(destination)$size > 0) {
    return(invisible(destination))
  }
  status <- system2(
    gzip_exe,
    args = c("-dc", shQuote(source)),
    stdout = destination,
    stderr = TRUE
  )
  if (!file.exists(destination) || file.info(destination)$size == 0) {
    stop("Failed to decompress ", source, ": ", paste(status, collapse = "\n"))
  }
  invisible(destination)
}
if (!file.exists(gtf_file) || file.info(gtf_file)$size == 0) {
  gtf_file <- file.path(reference_work_dir, "gencode.v49.annotation.gtf")
  decompress_once(gtf_gz, gtf_file)
}

index_base <- file.path(
  cache_root,
  "rsubread_index",
  "GRCh38_gencode_v49_gapped"
)
index_completion <- file.path(
  cache_root,
  "rsubread_index",
  "GRCh38_gencode_v49_gapped.complete.json"
)
index_files <- Sys.glob(paste0(index_base, ".*"))
index_files <- index_files[
  basename(index_files) != basename(index_completion) &
    !grepl("\\.log$", index_files, ignore.case = TRUE)
]
if (
  !file.exists(index_completion) ||
  length(index_files) < 4 ||
  any(file.info(index_files)$size == 0)
) {
  stop("Validated Rsubread index is incomplete.")
}

counts_list <- list()
mapping_rows <- list()
assignment_rows <- list()

for (i in seq_len(nrow(metadata))) {
  run <- metadata$run[i]
  sample_name <- metadata$analysis_sample[i]
  read1 <- file.path(fastq_dir, paste0(run, "_1.fastq.gz"))
  read2 <- file.path(fastq_dir, paste0(run, "_2.fastq.gz"))
  bam_path <- file.path(alignment_temp, paste0(sample_name, ".BAM"))
  per_sample_counts <- file.path(
    counts_dir,
    paste0("featureCounts_", sample_name, ".csv")
  )
  cache_rds <- file.path(
    log_dir,
    paste0(sample_name, "_alignment_and_featureCounts.rds")
  )

  if (file.exists(per_sample_counts) && file.exists(cache_rds)) {
    cached <- readRDS(cache_rds)
    fc <- cached$featureCounts
    if (is.null(fc$counts) || is.null(fc$stat)) {
      stop("Invalid precomputed featureCounts cache for ", sample_name)
    }
    sample_counts <- as.integer(fc$counts[, 1])
    names(sample_counts) <- rownames(fc$counts)
    counts_list[[sample_name]] <- sample_counts
    fc_stat <- as.data.frame(fc$stat, check.names = FALSE)
    if ("Status" %in% colnames(fc_stat)) {
      status_values <- as.character(fc_stat$Status)
      count_column <- setdiff(colnames(fc_stat), "Status")[[1]]
      fragment_values <- as.numeric(fc_stat[[count_column]])
    } else {
      status_values <- rownames(fc_stat)
      fragment_values <- as.numeric(fc_stat[[1]])
    }
    assignment <- data.frame(
      sample = sample_name,
      status = status_values,
      fragments = fragment_values,
      stringsAsFactors = FALSE
    )
    assignment_rows[[sample_name]] <- assignment
    if (!is.null(cached$mapping_row)) {
      mapping_rows[[sample_name]] <- cached$mapping_row
    } else {
      total_fragments <- sum(assignment$fragments)
      assigned_fragments <- assignment$fragments[
        assignment$status == "Assigned"
      ]
      mapping_rows[[sample_name]] <- data.frame(
        run = run,
        sample = sample_name,
        group = as.character(metadata$group[i]),
        elapsed_minutes = NA_real_,
        bam_bytes = NA_real_,
        total_featurecounts_fragments = total_fragments,
        assigned_fragments = assigned_fragments,
        assignment_rate = assigned_fragments / total_fragments,
        stringsAsFactors = FALSE
      )
    }
    message("Reused validated precomputed counts for ", sample_name)
    next
  }

  started <- Sys.time()
  alignment_result <- align(
    index = index_base,
    readfile1 = read1,
    readfile2 = read2,
    type = "rna",
    input_format = "gzFASTQ",
    output_format = "BAM",
    output_file = bam_path,
    phredOffset = 33,
    unique = TRUE,
    indels = 5,
    nthreads = 14,
    keepReadOrder = FALSE,
    sortReadsByCoordinates = FALSE,
    useAnnotation = TRUE,
    annot.ext = gtf_file,
    isGTF = TRUE,
    GTF.featureType = "exon",
    GTF.attrType = "gene_id"
  )
  if (!file.exists(bam_path) || file.info(bam_path)$size == 0) {
    stop("Alignment did not create a BAM for ", sample_name)
  }

  fc <- featureCounts(
    files = bam_path,
    annot.ext = gtf_file,
    isGTFAnnotationFile = TRUE,
    GTF.featureType = "exon",
    GTF.attrType = "gene_id",
    useMetaFeatures = TRUE,
    allowMultiOverlap = FALSE,
    countMultiMappingReads = FALSE,
    strandSpecific = 0,
    isPairedEnd = TRUE,
    countReadPairs = TRUE,
    requireBothEndsMapped = FALSE,
    countChimericFragments = FALSE,
    autosort = TRUE,
    nthreads = 14,
    tmpDir = alignment_temp,
    verbose = FALSE
  )

  sample_counts <- as.integer(fc$counts[, 1])
  names(sample_counts) <- rownames(fc$counts)
  counts_list[[sample_name]] <- sample_counts
  write.csv(
    data.frame(gene_id = names(sample_counts), count = sample_counts),
    per_sample_counts,
    row.names = FALSE,
    fileEncoding = "UTF-8"
  )

  fc_stat <- as.data.frame(fc$stat, check.names = FALSE)
  if ("Status" %in% colnames(fc_stat)) {
    status_values <- as.character(fc_stat$Status)
    count_column <- setdiff(colnames(fc_stat), "Status")[[1]]
    fragment_values <- as.numeric(fc_stat[[count_column]])
  } else {
    status_values <- rownames(fc_stat)
    fragment_values <- as.numeric(fc_stat[[1]])
  }
  assignment <- data.frame(
    sample = sample_name,
    status = status_values,
    fragments = fragment_values,
    stringsAsFactors = FALSE
  )
  assignment_rows[[sample_name]] <- assignment
  total_fragments <- sum(assignment$fragments)
  assigned_fragments <- assignment$fragments[assignment$status == "Assigned"]
  if (!length(assigned_fragments)) {
    assigned_fragments <- NA_real_
  }
  mapping_rows[[sample_name]] <- data.frame(
    run = run,
    sample = sample_name,
    group = as.character(metadata$group[i]),
    elapsed_minutes = as.numeric(difftime(Sys.time(), started, units = "mins")),
    bam_bytes = file.info(bam_path)$size,
    total_featurecounts_fragments = total_fragments,
    assigned_fragments = assigned_fragments,
    assignment_rate = assigned_fragments / total_fragments,
    stringsAsFactors = FALSE
  )

  saveRDS(
    list(
      alignment_result = alignment_result,
      featureCounts = fc,
      mapping_row = mapping_rows[[sample_name]]
    ),
    cache_rds
  )

  normalized_bam <- normalizePath(bam_path, winslash = "/", mustWork = TRUE)
  normalized_temp <- normalizePath(
    alignment_temp,
    winslash = "/",
    mustWork = TRUE
  )
  if (!startsWith(normalized_bam, paste0(normalized_temp, "/"))) {
    stop("Refusing to remove a BAM outside the validated temporary directory.")
  }
  if (!file.remove(bam_path)) {
    warning("Temporary BAM could not be removed: ", bam_path)
  }
}

reference_ids <- names(counts_list[[1]])
if (!all(vapply(
  counts_list,
  function(x) identical(names(x), reference_ids),
  logical(1)
))) {
  stop("Per-sample featureCounts gene identifiers are not identical.")
}
count_matrix <- do.call(cbind, lapply(counts_list, unname))
rownames(count_matrix) <- reference_ids
colnames(count_matrix) <- names(counts_list)
storage.mode(count_matrix) <- "integer"
count_matrix <- count_matrix[, metadata$analysis_sample, drop = FALSE]
if (!identical(colnames(count_matrix), metadata$analysis_sample)) {
  stop("Count-matrix columns do not match the registered sample names.")
}

annotation <- fc$annotation
annotation$gene_id <- rownames(annotation)
rownames(annotation) <- NULL
write.csv(
  annotation,
  file.path(counts_dir, "01_GENCODEv49_featureCounts_gene_annotation.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)
write.table(
  data.frame(gene_id = rownames(count_matrix), count_matrix),
  gzfile(file.path(counts_dir, "02_GSE212728_raw_gene_counts.tsv.gz")),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)
saveRDS(
  count_matrix,
  file.path(counts_dir, "03_GSE212728_raw_gene_counts.rds")
)
write.csv(
  do.call(rbind, mapping_rows),
  file.path(audit_dir, "06_GSE212728_alignment_assignment_summary.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)
write.csv(
  do.call(rbind, assignment_rows),
  file.path(audit_dir, "07_GSE212728_featureCounts_status.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)
writeLines(
  capture.output(sessionInfo()),
  file.path(log_dir, "R_sessionInfo_counts.txt"),
  useBytes = TRUE
)
message("GSE212728 raw gene counts completed: ", nrow(count_matrix), " genes x ", ncol(count_matrix), " samples.")
