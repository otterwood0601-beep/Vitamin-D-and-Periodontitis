options(stringsAsFactors = FALSE)

script_arg <- commandArgs(trailingOnly = FALSE)
script_path <- sub("^--file=", "", script_arg[grep("^--file=", script_arg)])
run_root <- normalizePath(file.path(dirname(script_path), ".."), winslash = "/", mustWork = TRUE)
stage_dir <- file.path(run_root, "12_GSE212728_\u539f\u59cbRNAseq_DESeq2_Figure3C-G")
audit_dir <- file.path(stage_dir, "00_\u6570\u636e\u5ba1\u8ba1")
counts_dir <- file.path(stage_dir, "01_gene_counts")
de_dir <- file.path(stage_dir, "02_DESeq2")
enrichment_dir <- file.path(stage_dir, "03_GO_Reactome")
log_dir <- file.path(stage_dir, "logs")
reactome_gmt <- file.path(audit_dir, "Reactome_Pathways_2024.gmt")
dir.create(de_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(enrichment_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)
if (!file.exists(reactome_gmt)) {
  stop("Local Reactome GMT is missing: ", reactome_gmt)
}

cache_root <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/04_Bulk_RNA/GSE212728"
.libPaths(c(
  file.path(cache_root, "R_library"),
  "C:/Users/Lin/AppData/Local/R/win-library/4.5",
  .libPaths()
))

suppressPackageStartupMessages({
  library(DESeq2)
  library(AnnotationDbi)
  library(org.Hs.eg.db)
  library(clusterProfiler)
  library(jsonlite)
})

metadata <- read.csv(
  file.path(audit_dir, "01_GSE212728_SRA\u6837\u672c\u8bbe\u8ba1.csv"),
  check.names = FALSE
)
metadata$group <- factor(metadata$group, levels = c("Control", "D3"))
rownames(metadata) <- metadata$analysis_sample

candidate_table <- read.csv(
  file.path(audit_dir, "02_\u5019\u9009\u57fa\u56e0\u56fa\u5b9a\u8868.csv"),
  check.names = FALSE
)
candidate_symbols <- unique(toupper(candidate_table$gene_symbol))

count_matrix <- readRDS(
  file.path(counts_dir, "03_GSE212728_raw_gene_counts.rds")
)
count_matrix <- count_matrix[, rownames(metadata), drop = FALSE]
gene_id_full <- rownames(count_matrix)
gene_id <- sub("\\..*$", "", gene_id_full)

if (anyDuplicated(gene_id)) {
  count_matrix <- rowsum(count_matrix, group = gene_id, reorder = FALSE)
} else {
  rownames(count_matrix) <- gene_id
}
storage.mode(count_matrix) <- "integer"

nonzero <- rowSums(count_matrix) > 0
count_nonzero <- count_matrix[nonzero, , drop = FALSE]
primary_keep <- rowSums(count_nonzero) >= 10
primary_counts <- count_nonzero[primary_keep, , drop = FALSE]

dds <- DESeqDataSetFromMatrix(
  countData = primary_counts,
  colData = metadata,
  design = ~ group
)
dds <- DESeq(dds, quiet = TRUE)
res <- results(
  dds,
  contrast = c("group", "D3", "Control"),
  alpha = 0.05,
  independentFiltering = TRUE
)
res_frame <- as.data.frame(res)
res_frame$gene_id <- rownames(res_frame)
res_frame$gene_symbol <- mapIds(
  org.Hs.eg.db,
  keys = res_frame$gene_id,
  keytype = "ENSEMBL",
  column = "SYMBOL",
  multiVals = "first"
)
res_frame$gene_symbol <- toupper(as.character(res_frame$gene_symbol))
res_frame$fold_change_D3_vs_Control <- 2^res_frame$log2FoldChange
res_frame$absolute_fold_change <- ifelse(
  res_frame$log2FoldChange >= 0,
  res_frame$fold_change_D3_vs_Control,
  1 / res_frame$fold_change_D3_vs_Control
)
res_frame$reference_style_positive <- (
  !is.na(res_frame$pvalue) &
  res_frame$pvalue < 0.05 &
  res_frame$absolute_fold_change >= 1.2
)
res_frame$strict_FDR_positive <- (
  !is.na(res_frame$padj) &
  res_frame$padj < 0.05 &
  res_frame$absolute_fold_change >= 1.2
)
res_frame$direction <- ifelse(
  res_frame$reference_style_positive,
  ifelse(res_frame$log2FoldChange > 0, "Up", "Down"),
  "Not significant"
)
res_frame <- res_frame[, c(
  "gene_id", "gene_symbol", "baseMean", "log2FoldChange", "lfcSE",
  "stat", "pvalue", "padj", "fold_change_D3_vs_Control",
  "absolute_fold_change", "reference_style_positive",
  "strict_FDR_positive", "direction"
)]
res_frame <- res_frame[order(res_frame$pvalue, na.last = TRUE), ]

write.csv(
  res_frame,
  file.path(de_dir, "01_GSE212728_DESeq2_D3_vs_Control_all_genes.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)
write.csv(
  res_frame[res_frame$reference_style_positive, ],
  file.path(de_dir, "02_GSE212728_P005_FC12_DEGs.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)
write.csv(
  res_frame[res_frame$strict_FDR_positive, ],
  file.path(de_dir, "03_GSE212728_FDR005_FC12_DEGs.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

normalized_counts <- counts(dds, normalized = TRUE)
vst_object <- varianceStabilizingTransformation(dds, blind = FALSE)
vst_matrix <- assay(vst_object)
gene_symbol_map_raw <- mapIds(
  org.Hs.eg.db,
  keys = rownames(vst_matrix),
  keytype = "ENSEMBL",
  column = "SYMBOL",
  multiVals = "first"
)
gene_symbol_map <- toupper(as.character(gene_symbol_map_raw))
names(gene_symbol_map) <- names(gene_symbol_map_raw)

write.table(
  data.frame(gene_id = rownames(normalized_counts), normalized_counts),
  gzfile(file.path(de_dir, "04_DESeq2_normalized_gene_counts.tsv.gz")),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)
write.table(
  data.frame(
    gene_id = rownames(vst_matrix),
    gene_symbol = gene_symbol_map,
    vst_matrix
  ),
  gzfile(file.path(de_dir, "05_DESeq2_VST_expression.tsv.gz")),
  sep = "\t",
  quote = FALSE,
  row.names = FALSE
)

candidate_rows <- lapply(candidate_symbols, function(symbol) {
  hit <- which(res_frame$gene_symbol == symbol)
  if (!length(hit)) {
    return(data.frame(
      gene_symbol = symbol,
      gene_id = NA_character_,
      baseMean = NA_real_,
      log2FoldChange = NA_real_,
      fold_change_D3_vs_Control = NA_real_,
      absolute_fold_change = NA_real_,
      pvalue = NA_real_,
      padj = NA_real_,
      reference_style_positive = FALSE,
      strict_FDR_positive = FALSE,
      direction = "Not detected",
      stringsAsFactors = FALSE
    ))
  }
  selected <- hit[which.max(res_frame$baseMean[hit])]
  row <- res_frame[selected, ]
  data.frame(
    gene_symbol = symbol,
    gene_id = row$gene_id,
    baseMean = row$baseMean,
    log2FoldChange = row$log2FoldChange,
    fold_change_D3_vs_Control = row$fold_change_D3_vs_Control,
    absolute_fold_change = row$absolute_fold_change,
    pvalue = row$pvalue,
    padj = row$padj,
    reference_style_positive = row$reference_style_positive,
    strict_FDR_positive = row$strict_FDR_positive,
    direction = row$direction,
    stringsAsFactors = FALSE
  )
})
candidate_results <- do.call(rbind, candidate_rows)
write.csv(
  candidate_results,
  file.path(de_dir, "06_\u4e94\u4e2aSMR\u5019\u9009\u57fa\u56e0_DESeq2\u7ed3\u679c.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

candidate_expression_rows <- list()
for (i in seq_len(nrow(candidate_results))) {
  gene <- candidate_results$gene_symbol[i]
  gene_id_i <- candidate_results$gene_id[i]
  if (is.na(gene_id_i) || !gene_id_i %in% rownames(vst_matrix)) {
    next
  }
  candidate_expression_rows[[gene]] <- data.frame(
    gene_symbol = gene,
    gene_id = gene_id_i,
    sample = colnames(vst_matrix),
    group = as.character(metadata[colnames(vst_matrix), "group"]),
    vst_expression = as.numeric(vst_matrix[gene_id_i, ]),
    normalized_count = as.numeric(normalized_counts[gene_id_i, ]),
    pvalue = candidate_results$pvalue[i],
    padj = candidate_results$padj[i],
    log2FoldChange = candidate_results$log2FoldChange[i],
    absolute_fold_change = candidate_results$absolute_fold_change[i],
    reference_style_positive = candidate_results$reference_style_positive[i],
    stringsAsFactors = FALSE
  )
}
candidate_expression <- do.call(rbind, candidate_expression_rows)
write.csv(
  candidate_expression,
  file.path(de_dir, "07_\u4e94\u4e2aSMR\u5019\u9009\u57fa\u56e0_\u6837\u672c\u8868\u8fbe\u957f\u8868.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

top_de <- res_frame[
  res_frame$reference_style_positive &
  !is.na(res_frame$gene_symbol) &
  nzchar(res_frame$gene_symbol),
]
top_de <- top_de[order(top_de$pvalue), ]
heatmap_ids <- unique(head(top_de$gene_id, 100))
fixed_candidate_ids <- candidate_results$gene_id[
  !is.na(candidate_results$gene_id)
]
heatmap_ids <- unique(c(heatmap_ids, fixed_candidate_ids))
heatmap_ids <- heatmap_ids[heatmap_ids %in% rownames(vst_matrix)]
heatmap_matrix <- vst_matrix[heatmap_ids, , drop = FALSE]
heatmap_symbols <- gene_symbol_map[heatmap_ids]
write.csv(
  data.frame(
    gene_id = heatmap_ids,
    gene_symbol = heatmap_symbols,
    heatmap_matrix
  ),
  file.path(de_dir, "08_Figure3D_heatmap_expression.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

tested_symbols <- unique(res_frame$gene_symbol[
  !is.na(res_frame$gene_symbol) &
  nzchar(res_frame$gene_symbol) &
  !is.na(res_frame$pvalue)
])
deg_symbols <- unique(res_frame$gene_symbol[
  res_frame$reference_style_positive &
  !is.na(res_frame$gene_symbol) &
  nzchar(res_frame$gene_symbol)
])

universe_map <- bitr(
  tested_symbols,
  fromType = "SYMBOL",
  toType = "ENTREZID",
  OrgDb = org.Hs.eg.db
)
deg_map <- bitr(
  deg_symbols,
  fromType = "SYMBOL",
  toType = "ENTREZID",
  OrgDb = org.Hs.eg.db
)
universe_entrez <- unique(universe_map$ENTREZID)
deg_entrez <- unique(deg_map$ENTREZID)

add_candidate_overlap <- function(frame) {
  if (!nrow(frame)) {
    frame$contains_fixed_candidate <- logical(0)
    frame$candidate_overlap <- character(0)
    return(frame)
  }
  overlaps <- vapply(
    strsplit(as.character(frame$geneID), "/", fixed = TRUE),
    function(genes) {
      paste(intersect(toupper(genes), candidate_symbols), collapse = ";")
    },
    character(1)
  )
  frame$candidate_overlap <- overlaps
  frame$contains_fixed_candidate <- nzchar(overlaps)
  frame
}

go_frames <- list()
for (ontology in c("BP", "CC", "MF")) {
  ego <- enrichGO(
    gene = deg_entrez,
    universe = universe_entrez,
    OrgDb = org.Hs.eg.db,
    keyType = "ENTREZID",
    ont = ontology,
    pAdjustMethod = "BH",
    pvalueCutoff = 1,
    qvalueCutoff = 1,
    minGSSize = 10,
    maxGSSize = 500,
    readable = TRUE
  )
  frame <- as.data.frame(ego)
  if (nrow(frame)) {
    frame$Ontology <- ontology
    frame <- add_candidate_overlap(frame)
    go_frames[[ontology]] <- frame
  }
}
go_all <- if (length(go_frames)) {
  do.call(rbind, go_frames)
} else {
  data.frame()
}
write.csv(
  go_all,
  file.path(enrichment_dir, "01_clusterProfiler_GO_BP_CC_MF_all.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)
write.csv(
  if (nrow(go_all)) {
    go_all[!is.na(go_all$p.adjust) & go_all$p.adjust < 0.05, ]
  } else {
    go_all
  },
  file.path(enrichment_dir, "02_clusterProfiler_GO_BP_CC_MF_FDR005.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

read_reactome_gmt <- function(path) {
  lines <- readLines(path, warn = FALSE, encoding = "UTF-8")
  parsed <- lapply(lines, function(line) {
    fields <- strsplit(line, "\t", fixed = TRUE)[[1]]
    if (length(fields) < 3) {
      return(NULL)
    }
    term <- fields[[1]]
    description <- fields[[2]]
    if (!nzchar(description)) {
      description <- term
    }
    genes <- unique(toupper(fields[-c(1, 2)]))
    genes <- genes[nzchar(genes)]
    list(
      term2gene = data.frame(
        term = rep(term, length(genes)),
        gene = genes,
        stringsAsFactors = FALSE
      ),
      term2name = data.frame(
        term = term,
        name = description,
        stringsAsFactors = FALSE
      )
    )
  })
  parsed <- Filter(Negate(is.null), parsed)
  list(
    TERM2GENE = unique(do.call(rbind, lapply(parsed, `[[`, "term2gene"))),
    TERM2NAME = unique(do.call(rbind, lapply(parsed, `[[`, "term2name")))
  )
}

reactome_terms <- read_reactome_gmt(reactome_gmt)
reactome_result <- enricher(
  gene = deg_symbols,
  universe = tested_symbols,
  TERM2GENE = reactome_terms$TERM2GENE,
  TERM2NAME = reactome_terms$TERM2NAME,
  pvalueCutoff = 1,
  pAdjustMethod = "BH",
  qvalueCutoff = 1,
  minGSSize = 10,
  maxGSSize = 500
)
reactome_all <- as.data.frame(reactome_result)
reactome_all <- add_candidate_overlap(reactome_all)
write.csv(
  reactome_all,
  file.path(enrichment_dir, "03_clusterProfiler_Reactome_all.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)
write.csv(
  if (nrow(reactome_all)) {
    reactome_all[
      !is.na(reactome_all$p.adjust) &
      reactome_all$p.adjust < 0.05,
    ]
  } else {
    reactome_all
  },
  file.path(enrichment_dir, "04_clusterProfiler_Reactome_FDR005.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

candidate_pathway_frames <- list()
select_overlap_columns <- function(frame, database) {
  if (!nrow(frame)) {
    return(data.frame())
  }
  data.frame(
    database = database,
    ID = as.character(frame$ID),
    Description = as.character(frame$Description),
    GeneRatio = as.character(frame$GeneRatio),
    BgRatio = as.character(frame$BgRatio),
    pvalue = as.numeric(frame$pvalue),
    p.adjust = as.numeric(frame$p.adjust),
    qvalue = as.numeric(frame$qvalue),
    geneID = as.character(frame$geneID),
    Count = as.integer(frame$Count),
    candidate_overlap = as.character(frame$candidate_overlap),
    contains_fixed_candidate = as.logical(frame$contains_fixed_candidate),
    stringsAsFactors = FALSE
  )
}
if (nrow(go_all)) {
  go_candidate_rows <- go_all[go_all$contains_fixed_candidate, ]
  candidate_pathway_frames[["GO"]] <- select_overlap_columns(
    go_candidate_rows,
    paste0("GO_", go_candidate_rows$Ontology)
  )
}
if (nrow(reactome_all)) {
  candidate_pathway_frames[["Reactome"]] <- select_overlap_columns(
    reactome_all[reactome_all$contains_fixed_candidate, ],
    rep("Reactome", sum(reactome_all$contains_fixed_candidate))
  )
}
candidate_pathway_overlap <- if (length(candidate_pathway_frames)) {
  do.call(rbind, candidate_pathway_frames)
} else {
  data.frame()
}
write.csv(
  candidate_pathway_overlap,
  file.path(enrichment_dir, "05_\u5019\u9009\u57fa\u56e0\u76f4\u63a5\u8fdb\u5165\u7684GO_Reactome\u6761\u76ee.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

audit <- list(
  accession = "GSE212728",
  statistical_method = "DESeq2 1.50.2; design = ~ group; D3 versus Control",
  deposited_samples = ncol(primary_counts),
  control_samples = sum(metadata$group == "Control"),
  D3_samples = sum(metadata$group == "D3"),
  genes_with_nonzero_counts = nrow(count_nonzero),
  genes_after_primary_prefilter = nrow(primary_counts),
  primary_prefilter = "sum of gene counts across all five samples >= 10",
  primary_DE_threshold = "unadjusted P < 0.05 and absolute fold change >= 1.2",
  primary_DEGs = sum(res_frame$reference_style_positive, na.rm = TRUE),
  strict_supplement_threshold = "BH FDR < 0.05 and absolute fold change >= 1.2",
  strict_DEGs = sum(res_frame$strict_FDR_positive, na.rm = TRUE),
  fixed_SMR_candidates = candidate_symbols,
  fixed_candidates_reference_positive = candidate_results$gene_symbol[
    candidate_results$reference_style_positive
  ],
  GO_method = "clusterProfiler::enrichGO, BP/CC/MF, tested genes as universe",
  Reactome_method = paste(
    "clusterProfiler::enricher with Reactome_Pathways_2024.gmt;",
    "tested gene symbols as universe"
  ),
  GO_FDR005_terms = if (nrow(go_all)) {
    sum(go_all$p.adjust < 0.05, na.rm = TRUE)
  } else {
    0
  },
  Reactome_FDR005_terms = if (nrow(reactome_all)) {
    sum(reactome_all$p.adjust < 0.05, na.rm = TRUE)
  } else {
    0
  },
  candidate_containing_enriched_terms = if (is.null(nrow(candidate_pathway_overlap))) {
    0
  } else {
    nrow(candidate_pathway_overlap)
  }
)
write_json(
  audit,
  file.path(audit_dir, "08_GSE212728_DESeq2_enrichment_audit.json"),
  auto_unbox = TRUE,
  pretty = TRUE
)
saveRDS(
  list(
    dds = dds,
    vst = vst_object,
    results = res_frame,
    candidates = candidate_results,
    go = go_all,
    reactome = reactome_all
  ),
  file.path(de_dir, "10_GSE212728_DESeq2_analysis_objects.rds")
)
writeLines(
  capture.output(sessionInfo()),
  file.path(log_dir, "R_sessionInfo_DESeq2_clusterProfiler.txt"),
  useBytes = TRUE
)

message(
  "DESeq2 completed. Primary DEGs: ",
  sum(res_frame$reference_style_positive, na.rm = TRUE),
  "; fixed candidates positive: ",
  paste(
    candidate_results$gene_symbol[candidate_results$reference_style_positive],
    collapse = ", "
  )
)
