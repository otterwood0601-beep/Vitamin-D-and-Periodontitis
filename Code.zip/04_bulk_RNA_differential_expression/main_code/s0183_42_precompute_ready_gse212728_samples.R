options(stringsAsFactors = FALSE)

script_arg <- commandArgs(trailingOnly = FALSE)
script_path <- sub("^--file=", "", script_arg[grep("^--file=", script_arg)])
run_root <- normalizePath(
  file.path(dirname(script_path), ".."),
  winslash = "/",
  mustWork = TRUE
)
stage_dir <- file.path(
  run_root,
  "12_GSE212728_\u539f\u59cbRNAseq_DESeq2_Figure3C-G"
)
audit_dir <- file.path(stage_dir, "00_\u6570\u636e\u5ba1\u8ba1")
counts_dir <- file.path(stage_dir, "01_gene_counts")
log_dir <- file.path(stage_dir, "logs")
cache_root <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/04_Bulk_RNA/GSE212728"
fastq_dir <- file.path(cache_root, "fastq")
reference_dir <- file.path(cache_root, "reference")
alignment_temp <- file.path(
  run_root,
  "tmp",
  "GSE212728_precompute_alignment"
)
dir.create(counts_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(alignment_temp, recursive = TRUE, showWarnings = FALSE)

.libPaths(c(
  file.path(cache_root, "R_library"),
  "C:/Users/Lin/AppData/Local/R/win-library/4.5",
  .libPaths()
))
suppressPackageStartupMessages(library(Rsubread))

metadata <- read.csv(
  file.path(audit_dir, "01_GSE212728_SRA\u6837\u672c\u8bbe\u8ba1.csv"),
  check.names = FALSE
)
metadata$group <- factor(metadata$group, levels = c("Control", "D3"))
ready_runs <- c(
  "SRR21430404",
  "SRR21430405",
  "SRR21430403",
  "SRR21430407"
)
metadata <- metadata[metadata$run %in% ready_runs, , drop = FALSE]
metadata <- metadata[match(ready_runs, metadata$run), , drop = FALSE]
if (nrow(metadata) != length(ready_runs) || anyNA(metadata$run)) {
  stop("Could not resolve the two precompute samples.")
}

expected <- data.frame(
  run = rep(ready_runs, each = 2),
  mate = rep(1:2, times = length(ready_runs)),
  expected_bytes = c(
    1689181950, 1803313637,
    1546335154, 1644174386,
    1603924157, 1711249651,
    1597591967, 1731362588
  ),
  expected_md5 = c(
    "3ce9dc47989217b757fe13f101497fdf",
    "5768e1162746be24ba208246ec5ced1e",
    "8d56db31586834e44b961e40db8f147c",
    "4799cc456fa570806736f296fbfec2ea",
    "496def12946529d1c9752272fe6ab43e",
    "16884896b2c396a556cabf1671fb490a",
    "8cf2f0ec0e52c2be3899eb726fcb3a8b",
    "5f7d76595c3359fa3d4ab886a43e1a5f"
  )
)
expected$file <- paste0(expected$run, "_", expected$mate, ".fastq.gz")
expected$path <- file.path(fastq_dir, expected$file)
if (!all(file.exists(expected$path))) {
  stop("A precompute FASTQ file is missing.")
}
expected$actual_bytes <- file.info(expected$path)$size
if (!all(expected$actual_bytes == expected$expected_bytes)) {
  stop("A precompute FASTQ file has the wrong byte count.")
}
expected$actual_md5 <- unname(tools::md5sum(expected$path))
if (!all(tolower(expected$actual_md5) == expected$expected_md5)) {
  stop("A precompute FASTQ file failed MD5 validation.")
}

index_base <- file.path(
  cache_root,
  "rsubread_index",
  "GRCh38_gencode_v49_gapped"
)
index_completion <- paste0(index_base, ".complete.json")
index_files <- Sys.glob(paste0(index_base, ".*"))
index_files <- index_files[
  basename(index_files) != basename(index_completion) &
    !grepl("\\.log$", index_files, ignore.case = TRUE)
]
if (
  !file.exists(index_completion) ||
  length(index_files) < 4 ||
  any(file.info(index_files)$size == 0)
) {
  stop("The validated Rsubread index is unavailable.")
}
gtf_file <- file.path(reference_dir, "gencode.v49.annotation.gtf")
if (!file.exists(gtf_file) || file.info(gtf_file)$size == 0) {
  stop("The decompressed GENCODE v49 GTF is unavailable.")
}

status_rows <- list()
for (i in seq_len(nrow(metadata))) {
  run <- metadata$run[i]
  sample_name <- metadata$analysis_sample[i]
  read1 <- file.path(fastq_dir, paste0(run, "_1.fastq.gz"))
  read2 <- file.path(fastq_dir, paste0(run, "_2.fastq.gz"))
  bam_path <- file.path(alignment_temp, paste0(sample_name, ".BAM"))
  per_sample_counts <- file.path(
    counts_dir,
    paste0("featureCounts_", sample_name, ".csv")
  )
  cache_rds <- file.path(
    log_dir,
    paste0(sample_name, "_alignment_and_featureCounts.rds")
  )

  if (file.exists(per_sample_counts) && file.exists(cache_rds)) {
    status_rows[[sample_name]] <- data.frame(
      run = run,
      sample = sample_name,
      status = "reused_existing_cache",
      stringsAsFactors = FALSE
    )
    next
  }

  started <- Sys.time()
  if (file.exists(bam_path) && file.info(bam_path)$size > 0) {
    alignment_result <- list(reused_existing_bam = TRUE)
    message("Reused existing BAM for ", sample_name)
  } else {
    alignment_result <- align(
      index = index_base,
      readfile1 = read1,
      readfile2 = read2,
      type = "rna",
      input_format = "gzFASTQ",
      output_format = "BAM",
      output_file = bam_path,
      phredOffset = 33,
      unique = TRUE,
      indels = 5,
      nthreads = 14,
      keepReadOrder = FALSE,
      sortReadsByCoordinates = FALSE,
      useAnnotation = TRUE,
      annot.ext = gtf_file,
      isGTF = TRUE,
      GTF.featureType = "exon",
      GTF.attrType = "gene_id"
    )
  }
  if (!file.exists(bam_path) || file.info(bam_path)$size == 0) {
    stop("Alignment did not create a BAM for ", sample_name)
  }

  fc <- featureCounts(
    files = bam_path,
    annot.ext = gtf_file,
    isGTFAnnotationFile = TRUE,
    GTF.featureType = "exon",
    GTF.attrType = "gene_id",
    useMetaFeatures = TRUE,
    allowMultiOverlap = FALSE,
    countMultiMappingReads = FALSE,
    strandSpecific = 0,
    isPairedEnd = TRUE,
    countReadPairs = TRUE,
    requireBothEndsMapped = FALSE,
    countChimericFragments = FALSE,
    autosort = TRUE,
    nthreads = 14,
    tmpDir = alignment_temp,
    verbose = FALSE
  )
  sample_counts <- as.integer(fc$counts[, 1])
  names(sample_counts) <- rownames(fc$counts)
  write.csv(
    data.frame(gene_id = names(sample_counts), count = sample_counts),
    per_sample_counts,
    row.names = FALSE,
    fileEncoding = "UTF-8"
  )

  fc_stat <- as.data.frame(fc$stat, check.names = FALSE)
  if ("Status" %in% colnames(fc_stat)) {
    status_values <- as.character(fc_stat$Status)
    count_column <- setdiff(colnames(fc_stat), "Status")[[1]]
    fragment_values <- as.numeric(fc_stat[[count_column]])
  } else {
    status_values <- rownames(fc_stat)
    fragment_values <- as.numeric(fc_stat[[1]])
  }
  assignment <- data.frame(
    status = status_values,
    fragments = fragment_values,
    stringsAsFactors = FALSE
  )
  total_fragments <- sum(assignment$fragments)
  assigned_fragments <- assignment$fragments[
    assignment$status == "Assigned"
  ]
  mapping_row <- data.frame(
    run = run,
    sample = sample_name,
    group = as.character(metadata$group[i]),
    elapsed_minutes = as.numeric(difftime(
      Sys.time(),
      started,
      units = "mins"
    )),
    bam_bytes = file.info(bam_path)$size,
    total_featurecounts_fragments = total_fragments,
    assigned_fragments = assigned_fragments,
    assignment_rate = assigned_fragments / total_fragments,
    stringsAsFactors = FALSE
  )
  saveRDS(
    list(
      alignment_result = alignment_result,
      featureCounts = fc,
      mapping_row = mapping_row
    ),
    cache_rds
  )
  normalized_bam <- normalizePath(bam_path, winslash = "/", mustWork = TRUE)
  normalized_temp <- normalizePath(
    alignment_temp,
    winslash = "/",
    mustWork = TRUE
  )
  if (!startsWith(normalized_bam, paste0(normalized_temp, "/"))) {
    stop("Refusing to remove a BAM outside the validated temporary directory.")
  }
  if (!file.remove(bam_path)) {
    warning("Temporary BAM could not be removed: ", bam_path)
  }
  status_rows[[sample_name]] <- data.frame(
    run = run,
    sample = sample_name,
    status = "precomputed_and_validated",
    stringsAsFactors = FALSE
  )
  message(
    "Precomputed ",
    sample_name,
    "; assignment rate = ",
    signif(mapping_row$assignment_rate, 4)
  )
}

write.csv(
  do.call(rbind, status_rows),
  file.path(audit_dir, "09_precomputed_ready_samples_status.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)
writeLines(
  capture.output(sessionInfo()),
  file.path(log_dir, "R_sessionInfo_precompute_ready_samples.txt"),
  useBytes = TRUE
)
