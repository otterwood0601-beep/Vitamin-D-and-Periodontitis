options(stringsAsFactors = FALSE)

script_arg <- commandArgs(trailingOnly = FALSE)
script_path <- sub("^--file=", "", script_arg[grep("^--file=", script_arg)])
run_root <- normalizePath(
  file.path(dirname(script_path), ".."),
  winslash = "/",
  mustWork = TRUE
)
stage_dir <- file.path(
  run_root,
  "12_GSE212728_\u539f\u59cbRNAseq_DESeq2_Figure3C-G"
)
de_dir <- file.path(stage_dir, "02_DESeq2")
enrichment_dir <- file.path(stage_dir, "03_GO_Reactome")
figure_dir <- file.path(stage_dir, "04_Figure3C-G")
qa_dir <- file.path(stage_dir, "05_\u53ef\u590d\u73b0\u4e0eQA")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(qa_dir, recursive = TRUE, showWarnings = FALSE)

cache_root <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/04_Bulk_RNA/GSE212728"
.libPaths(c(
  file.path(cache_root, "R_library"),
  "C:/Users/Lin/AppData/Local/R/win-library/4.5",
  .libPaths()
))

suppressPackageStartupMessages({
  library(ggplot2)
  library(ggrepel)
  library(pheatmap)
  library(cowplot)
  library(grid)
  library(gridExtra)
  library(svglite)
  library(jsonlite)
})

candidate_symbols <- c("MLX", "PSMC3IP", "USP3", "CCDC17", "INSIG2")
group_colours <- c(Control = "#2C7FB8", D3 = "#F28E7F")
ink <- "#202124"
grid_colour <- "#E8EAED"

all_results <- read.csv(
  file.path(de_dir, "01_GSE212728_DESeq2_D3_vs_Control_all_genes.csv"),
  check.names = FALSE
)
candidate_results <- read.csv(
  file.path(de_dir, "06_\u4e94\u4e2aSMR\u5019\u9009\u57fa\u56e0_DESeq2\u7ed3\u679c.csv"),
  check.names = FALSE
)
candidate_expression <- read.csv(
  file.path(de_dir, "07_\u4e94\u4e2aSMR\u5019\u9009\u57fa\u56e0_\u6837\u672c\u8868\u8fbe\u957f\u8868.csv"),
  check.names = FALSE
)
heatmap_data <- read.csv(
  file.path(de_dir, "08_Figure3D_heatmap_expression.csv"),
  check.names = FALSE
)
go_all <- read.csv(
  file.path(enrichment_dir, "01_clusterProfiler_GO_BP_CC_MF_all.csv"),
  check.names = FALSE
)
reactome_all <- read.csv(
  file.path(enrichment_dir, "03_clusterProfiler_Reactome_all.csv"),
  check.names = FALSE
)

theme_reference <- theme_bw(base_size = 10.5) +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(
      colour = grid_colour,
      linewidth = 0.35
    ),
    panel.border = element_rect(colour = "#BDBDBD", linewidth = 0.5),
    axis.text = element_text(colour = ink),
    axis.title = element_text(colour = ink),
    plot.title = element_text(face = "plain", size = 11, hjust = 0.5),
    plot.subtitle = element_text(size = 8.5, colour = "#4D5156"),
    plot.tag = element_text(face = "bold", size = 25, colour = "#111111"),
    strip.background = element_blank(),
    strip.text = element_text(face = "bold", colour = ink),
    legend.title = element_text(size = 8.5),
    legend.text = element_text(size = 8)
  )

save_plot_formats <- function(plot_object, stem, width, height) {
  ggsave(
    file.path(figure_dir, paste0(stem, ".png")),
    plot_object,
    width = width,
    height = height,
    dpi = 360,
    bg = "white"
  )
  ggsave(
    file.path(figure_dir, paste0(stem, ".pdf")),
    plot_object,
    width = width,
    height = height,
    device = cairo_pdf,
    bg = "white"
  )
  ggsave(
    file.path(figure_dir, paste0(stem, ".svg")),
    plot_object,
    width = width,
    height = height,
    device = svglite::svglite,
    bg = "white"
  )
  ggsave(
    file.path(figure_dir, paste0(stem, ".tiff")),
    plot_object,
    width = width,
    height = height,
    dpi = 360,
    compression = "lzw",
    bg = "white"
  )
}

wrap_term <- function(x, width = 34) {
  vapply(
    x,
    function(value) paste(strwrap(value, width = width), collapse = "\n"),
    character(1)
  )
}

parse_ratio <- function(x) {
  parts <- strsplit(as.character(x), "/", fixed = TRUE)
  vapply(
    parts,
    function(part) as.numeric(part[[1]]) / as.numeric(part[[2]]),
    numeric(1)
  )
}

significance_stars <- function(p) {
  if (is.na(p)) {
    return("not detected")
  }
  if (p < 1e-4) {
    return("****")
  }
  if (p < 1e-3) {
    return("***")
  }
  if (p < 1e-2) {
    return("**")
  }
  if (p < 0.05) {
    return("*")
  }
  "ns"
}

volcano <- all_results[
  !is.na(all_results$pvalue) &
    is.finite(all_results$pvalue) &
    is.finite(all_results$log2FoldChange),
]
volcano$minus_log10_p <- -log10(pmax(volcano$pvalue, 1e-300))
volcano$is_candidate <- (
  !is.na(volcano$gene_symbol) &
  volcano$gene_symbol %in% candidate_symbols
)
volcano$display_group <- ifelse(
  volcano$reference_style_positive,
  "P < 0.05 and |FC| >= 1.2",
  "Other tested genes"
)
candidate_volcano <- volcano[volcano$is_candidate, ]

figure_3c <- ggplot(
  volcano,
  aes(x = minus_log10_p, y = log2FoldChange)
) +
  geom_point(
    data = volcano[!volcano$reference_style_positive, ],
    colour = "#BDBDBD",
    alpha = 0.36,
    size = 1.15
  ) +
  geom_point(
    data = volcano[volcano$reference_style_positive, ],
    colour = "#F28E7F",
    alpha = 0.78,
    size = 1.45
  ) +
  geom_vline(
    xintercept = -log10(0.05),
    linetype = "dashed",
    colour = "#666666",
    linewidth = 0.45
  ) +
  geom_hline(
    yintercept = c(-log2(1.2), log2(1.2)),
    linetype = "dashed",
    colour = "#666666",
    linewidth = 0.45
  ) +
  geom_point(
    data = candidate_volcano,
    shape = 24,
    size = 3,
    stroke = 0.8,
    fill = ifelse(
      candidate_volcano$reference_style_positive,
      "#F28E7F",
      "white"
    ),
    colour = ink
  ) +
  ggrepel::geom_text_repel(
    data = candidate_volcano,
    aes(label = gene_symbol),
    seed = 212728,
    size = 3,
    colour = ink,
    min.segment.length = 0,
    box.padding = 0.3,
    max.overlaps = Inf
  ) +
  labs(
    tag = "C",
    title = "Vitamin D3 versus ethanol control",
    subtitle = "DESeq2; reference threshold: P < 0.05 and |fold change| >= 1.2",
    x = expression(-Log[10]~italic(P)),
    y = expression(Log[2]~"fold change")
  ) +
  theme_reference +
  theme(legend.position = "none")

save_plot_formats(figure_3c, "Figure_3C_volcano", 6.5, 5.4)

sample_columns <- setdiff(
  colnames(heatmap_data),
  c("gene_id", "gene_symbol")
)
heat_values <- as.matrix(heatmap_data[, sample_columns, drop = FALSE])
storage.mode(heat_values) <- "double"
heat_symbols <- as.character(heatmap_data$gene_symbol)
heat_symbols[
  is.na(heat_symbols) | !nzchar(heat_symbols)
] <- as.character(heatmap_data$gene_id[
  is.na(heat_symbols) | !nzchar(heat_symbols)
])
rownames(heat_values) <- make.unique(heat_symbols)
heat_z <- t(scale(t(heat_values)))
heat_z[!is.finite(heat_z)] <- 0
heat_z <- pmax(pmin(heat_z, 2.5), -2.5)
sample_groups <- ifelse(grepl("^Control", sample_columns), "Control", "D3")
sample_order <- order(factor(sample_groups, levels = c("Control", "D3")))
heat_z <- heat_z[, sample_order, drop = FALSE]
sample_groups <- sample_groups[sample_order]
heat_annotation <- data.frame(
  Group = factor(sample_groups, levels = c("Control", "D3")),
  row.names = colnames(heat_z)
)
candidate_row_labels <- ifelse(
  sub("\\.[0-9]+$", "", rownames(heat_z)) %in% candidate_symbols,
  sub("\\.[0-9]+$", "", rownames(heat_z)),
  ""
)

heatmap_object <- pheatmap(
  heat_z,
  cluster_rows = TRUE,
  cluster_cols = FALSE,
  show_rownames = TRUE,
  labels_row = candidate_row_labels,
  show_colnames = TRUE,
  annotation_col = heat_annotation,
  annotation_colors = list(Group = group_colours),
  color = colorRampPalette(c("#2166AC", "#F7F7F7", "#B2182B"))(101),
  breaks = seq(-2.5, 2.5, length.out = 102),
  border_color = NA,
  fontsize_row = 5.5,
  fontsize_col = 8.5,
  annotation_legend = TRUE,
  legend = TRUE,
  silent = TRUE
)
figure_3d <- ggdraw() +
  draw_grob(heatmap_object$gtable, x = 0.02, y = 0.01, width = 0.98, height = 0.96) +
  draw_label("D", x = 0.005, y = 0.995, hjust = 0, vjust = 1, size = 25) +
  draw_label(
    "Differential-gene heatmap",
    x = 0.52,
    y = 0.995,
    hjust = 0.5,
    vjust = 1,
    size = 11
  )
save_plot_formats(figure_3d, "Figure_3D_heatmap", 5.2, 8.0)

select_enrichment_terms <- function(frame, ontology = NULL, number = 5) {
  part <- frame
  if (!is.null(ontology)) {
    part <- part[part$Ontology == ontology, ]
  }
  part <- part[!is.na(part$pvalue) & !is.na(part$p.adjust), ]
  if (!nrow(part)) {
    return(part)
  }
  fdr <- part[part$p.adjust < 0.05, ]
  nominal <- part[part$pvalue < 0.05, ]
  if (nrow(fdr)) {
    selected <- fdr
    selected$selection_tier <- "BH FDR < 0.05"
  } else if (nrow(nominal)) {
    selected <- nominal
    selected$selection_tier <- "Nominal P < 0.05"
  } else {
    selected <- part
    selected$selection_tier <- "Top-ranked; not P < 0.05"
  }
  selected <- selected[order(selected$p.adjust, selected$pvalue), ]
  head(selected, number)
}

go_display_parts <- lapply(
  c("BP", "CC", "MF"),
  function(ontology) {
    selected <- select_enrichment_terms(go_all, ontology, 5)
    if (nrow(selected)) {
      selected$Ontology <- ontology
    }
    selected
  }
)
go_display <- do.call(rbind, go_display_parts)
if (!nrow(go_display)) {
  stop("No GO terms are available for Figure 3E.")
}
go_display$GeneRatioNumeric <- parse_ratio(go_display$GeneRatio)
go_display$TermKey <- paste(
  go_display$Ontology,
  wrap_term(go_display$Description, 31),
  sep = " | "
)
go_display$TermKey <- factor(
  go_display$TermKey,
  levels = rev(unique(go_display$TermKey))
)
go_display$minus_log10_p <- -log10(pmax(go_display$pvalue, 1e-300))

figure_3e <- ggplot(
  go_display,
  aes(
    x = GeneRatioNumeric,
    y = TermKey,
    size = Count,
    colour = minus_log10_p
  )
) +
  geom_point(alpha = 0.9) +
  facet_grid(
    Ontology ~ .,
    scales = "free_y",
    space = "free_y"
  ) +
  scale_y_discrete(labels = function(value) sub("^[^|]+ \\| ", "", value)) +
  scale_colour_gradient(low = "#2C7FB8", high = "#D95F4C") +
  labs(
    tag = "E",
    title = "GO enrichment",
    subtitle = "BP, CC and MF; terms ranked by BH FDR",
    x = "GeneRatio",
    y = NULL,
    colour = expression(-Log[10]~italic(P)),
    size = "Count"
  ) +
  theme_reference +
  theme(
    axis.text.y = element_text(size = 7.2),
    legend.position = "right"
  )
save_plot_formats(figure_3e, "Figure_3E_GO_BP_CC_MF", 7.4, 9.0)

reactome_display <- select_enrichment_terms(reactome_all, number = 12)
if (!nrow(reactome_display)) {
  stop("No Reactome terms are available for Figure 3F.")
}
reactome_display$GeneRatioNumeric <- parse_ratio(reactome_display$GeneRatio)
reactome_display$DescriptionWrapped <- factor(
  wrap_term(reactome_display$Description, 42),
  levels = rev(wrap_term(reactome_display$Description, 42))
)
reactome_display$minus_log10_fdr <- -log10(
  pmax(reactome_display$p.adjust, 1e-300)
)

figure_3f <- ggplot(
  reactome_display,
  aes(
    x = GeneRatioNumeric,
    y = DescriptionWrapped,
    size = Count,
    colour = minus_log10_fdr
  )
) +
  geom_point(alpha = 0.92) +
  scale_colour_gradient(low = "#2C7FB8", high = "#D95F4C") +
  labs(
    tag = "F",
    title = "Reactome",
    subtitle = "clusterProfiler::enricher; terms ranked by BH FDR",
    x = "GeneRatio",
    y = NULL,
    colour = expression(-Log[10]~"BH FDR"),
    size = "Count"
  ) +
  theme_reference +
  theme(
    axis.text.y = element_text(size = 7.5),
    legend.position = "right"
  )
save_plot_formats(figure_3f, "Figure_3F_Reactome", 8.2, 8.2)

candidate_expression$group <- factor(
  candidate_expression$group,
  levels = c("Control", "D3")
)
candidate_expression$gene_symbol <- factor(
  candidate_expression$gene_symbol,
  levels = candidate_symbols
)
candidate_results$gene_symbol <- factor(
  candidate_results$gene_symbol,
  levels = candidate_symbols
)
candidate_stats <- merge(
  aggregate(
    vst_expression ~ gene_symbol,
    candidate_expression,
    max
  ),
  candidate_results,
  by = "gene_symbol",
  all.x = TRUE
)
candidate_ranges <- aggregate(
  vst_expression ~ gene_symbol,
  candidate_expression,
  function(x) diff(range(x))
)
names(candidate_ranges)[2] <- "expression_range"
candidate_stats <- merge(
  candidate_stats,
  candidate_ranges,
  by = "gene_symbol",
  all.x = TRUE
)
candidate_stats$annotation_y <- (
  candidate_stats$vst_expression +
  pmax(candidate_stats$expression_range * 0.18, 0.22)
)
candidate_stats$annotation <- vapply(
  candidate_stats$pvalue,
  significance_stars,
  character(1)
)
candidate_stats$detail <- sprintf(
  "P=%.3g; |FC|=%.2f",
  candidate_stats$pvalue,
  candidate_stats$absolute_fold_change
)

figure_3g <- ggplot(
  candidate_expression,
  aes(x = group, y = vst_expression, fill = group)
) +
  geom_boxplot(
    width = 0.58,
    outlier.shape = NA,
    alpha = 0.82,
    colour = "#333333",
    linewidth = 0.5
  ) +
  geom_point(
    position = position_jitter(width = 0.07, height = 0, seed = 212728),
    shape = 21,
    size = 2.15,
    stroke = 0.45,
    colour = "#333333"
  ) +
  geom_text(
    data = candidate_stats,
    aes(
      x = 1.5,
      y = annotation_y,
      label = annotation
    ),
    inherit.aes = FALSE,
    fontface = "bold",
    size = 4
  ) +
  geom_text(
    data = candidate_stats,
    aes(
      x = 1.5,
      y = annotation_y - pmax(expression_range * 0.10, 0.11),
      label = detail
    ),
    inherit.aes = FALSE,
    size = 2.25,
    colour = "#4D5156"
  ) +
  facet_wrap(~ gene_symbol, scales = "free_y", ncol = 5) +
  scale_fill_manual(values = group_colours) +
  labs(
    tag = "G",
    title = "Fixed SMR-candidate expression",
    subtitle = "VST expression; D3 1000 nM for 48 h versus 0.1% ethanol control",
    x = NULL,
    y = "Log expression (VST)",
    fill = "Group"
  ) +
  theme_reference +
  theme(
    legend.position = "right",
    axis.text.x = element_text(size = 8.5)
  )
save_plot_formats(figure_3g, "Figure_3G_candidate_boxplots", 12.5, 4.8)

left_column <- plot_grid(
  figure_3c,
  figure_3d,
  ncol = 1,
  rel_heights = c(0.85, 1.15)
)
upper_composite <- plot_grid(
  left_column,
  figure_3e,
  figure_3f,
  ncol = 3,
  rel_widths = c(0.92, 1.08, 1.12)
)
figure_3cg <- plot_grid(
  upper_composite,
  figure_3g,
  ncol = 1,
  rel_heights = c(1.75, 0.75)
)
save_plot_formats(
  figure_3cg,
  "Figure_3C-G_composite_reference_style",
  20,
  17
)

display_selection <- rbind(
  data.frame(
    panel = "Figure 3E",
    database = paste0("GO_", go_display$Ontology),
    description = go_display$Description,
    pvalue = go_display$pvalue,
    p_adjust = go_display$p.adjust,
    selection_tier = go_display$selection_tier
  ),
  data.frame(
    panel = "Figure 3F",
    database = "Reactome",
    description = reactome_display$Description,
    pvalue = reactome_display$pvalue,
    p_adjust = reactome_display$p.adjust,
    selection_tier = reactome_display$selection_tier
  )
)
write.csv(
  display_selection,
  file.path(qa_dir, "Figure3E_F_display_term_selection.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

figure_audit <- list(
  accession = "GSE212728",
  panels = c("Figure 3C", "Figure 3D", "Figure 3E", "Figure 3F", "Figure 3G"),
  fixed_candidates = candidate_symbols,
  reference_DE_threshold = "unadjusted P < 0.05 and absolute fold change >= 1.2",
  figure_3c_axes = "-log10(P) by log2 fold change, matching the reference",
  figure_3d_rows = paste(
    "Top 100 reference-threshold DEGs plus all detected fixed candidates;",
    "candidate rows are labelled and inclusion does not imply significance."
  ),
  figure_3e_3f_display_rule = paste(
    "Use BH FDR < 0.05 terms when present; otherwise show nominal P < 0.05",
    "terms; if neither exists, show top-ranked terms and record the tier."
  ),
  figure_3g_statistic = paste(
    "DESeq2 P values and absolute fold changes from the all-five-sample model;",
    "stars encode P only and exact P/FC are printed."
  ),
  output_formats = c("PNG", "PDF", "SVG", "TIFF"),
  generated_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %z")
)
write_json(
  figure_audit,
  file.path(qa_dir, "Figure3C-G_plot_audit.json"),
  auto_unbox = TRUE,
  pretty = TRUE
)
writeLines(
  capture.output(sessionInfo()),
  file.path(qa_dir, "R_sessionInfo_plotting.txt"),
  useBytes = TRUE
)

message("Reference-style Figure 3C-G files completed.")
