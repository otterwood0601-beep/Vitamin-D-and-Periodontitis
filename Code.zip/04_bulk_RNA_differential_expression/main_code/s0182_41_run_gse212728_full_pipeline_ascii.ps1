$ErrorActionPreference = "Stop"

$runRoot = Split-Path -Path $PSScriptRoot -Parent
$stage = (
    Get-ChildItem -LiteralPath $runRoot -Directory |
    Where-Object {
        $_.Name -like "12_GSE212728_*_DESeq2_Figure3C-G" -and
        (Test-Path -LiteralPath (Join-Path $_.FullName "01_gene_counts"))
    } |
    Select-Object -First 1
).FullName
if ([string]::IsNullOrWhiteSpace($stage)) {
    throw "Could not resolve the formal GSE212728 stage directory."
}

$logDir = Join-Path $stage "logs"
$qaDir = (
    Get-ChildItem -LiteralPath $stage -Directory |
    Where-Object { $_.Name -like "05_*" } |
    Select-Object -First 1
).FullName
if ([string]::IsNullOrWhiteSpace($qaDir)) {
    throw "Could not resolve the QA directory."
}

$fastqDir = "E:\$([char]0x8840)$([char]0x6E05)$([char]0x7EF4)$([char]0x751F)$([char]0x7D20)\$([char]0x539F)$([char]0x59CB)$([char]0x6570)$([char]0x636E)\04_Bulk_RNA\GSE212728\fastq"
$indexCompletion = "E:\$([char]0x8840)$([char]0x6E05)$([char]0x7EF4)$([char]0x751F)$([char]0x7D20)\$([char]0x539F)$([char]0x59CB)$([char]0x6570)$([char]0x636E)\04_Bulk_RNA\GSE212728\rsubread_index\GRCh38_gencode_v49_gapped.complete.json"
$rscript = "C:\Program Files\R\R-4.5.3\bin\Rscript.exe"
$python = "C:\Users\Lin\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
$pythonPackages = Join-Path $runRoot "source_data\python_notebook_pkgs"
$pipelineLog = Join-Path $logDir "41_full_pipeline_status.log"
$completionMarker = Join-Path $qaDir ".pipeline_complete"

New-Item -ItemType Directory -Path $logDir -Force | Out-Null

function Write-Status {
    param([string]$Message)
    $line = "{0}  {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Message
    Add-Content -LiteralPath $pipelineLog -Value $line -Encoding UTF8
}

$expectedBytes = [ordered]@{
    "SRR21430403_1.fastq.gz" = 1603924157
    "SRR21430403_2.fastq.gz" = 1711249651
    "SRR21430404_1.fastq.gz" = 1689181950
    "SRR21430404_2.fastq.gz" = 1803313637
    "SRR21430405_1.fastq.gz" = 1546335154
    "SRR21430405_2.fastq.gz" = 1644174386
    "SRR21430406_1.fastq.gz" = 1787822999
    "SRR21430406_2.fastq.gz" = 1970632580
    "SRR21430407_1.fastq.gz" = 1597591967
    "SRR21430407_2.fastq.gz" = 1731362588
}

function Test-FastqReady {
    foreach ($entry in $expectedBytes.GetEnumerator()) {
        $path = Join-Path $fastqDir $entry.Key
        if (!(Test-Path -LiteralPath $path)) {
            return $false
        }
        if ((Get-Item -LiteralPath $path).Length -ne [int64]$entry.Value) {
            return $false
        }
    }
    $sidecars = Get-ChildItem -LiteralPath $fastqDir -Filter "*.aria2" -File -ErrorAction SilentlyContinue
    return (@($sidecars).Count -eq 0)
}

function Invoke-Step {
    param(
        [string]$Name,
        [string]$Executable,
        [string[]]$Arguments,
        [string]$Stdout,
        [string]$Stderr
    )
    Write-Status "START $Name"
    $process = Start-Process `
        -FilePath $Executable `
        -ArgumentList $Arguments `
        -RedirectStandardOutput $Stdout `
        -RedirectStandardError $Stderr `
        -WindowStyle Hidden `
        -Wait `
        -PassThru
    $exitCode = $process.ExitCode
    if ($exitCode -ne 0) {
        Write-Status "FAILED $Name exit_code=$exitCode"
        throw "$Name failed with exit code $exitCode"
    }
    Write-Status "COMPLETE $Name"
}

Add-Content -LiteralPath $pipelineLog -Value (
    "{0}  WATCHER_STARTED pid={1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $PID
) -Encoding UTF8

while (!(Test-Path -LiteralPath $indexCompletion) -or !(Test-FastqReady)) {
    $indexReady = Test-Path -LiteralPath $indexCompletion
    $fastqReady = Test-FastqReady
    Write-Status "WAIT index_ready=$indexReady fastq_ready=$fastqReady"
    Start-Sleep -Seconds 20
}

Write-Status "INPUTS_READY"

Invoke-Step `
    -Name "raw_counts" `
    -Executable $rscript `
    -Arguments @("--vanilla", (Join-Path $PSScriptRoot "33_gse212728_raw_rsubread_counts.R")) `
    -Stdout (Join-Path $logDir "33_raw_counts.stdout.log") `
    -Stderr (Join-Path $logDir "33_raw_counts.stderr.log")

Invoke-Step `
    -Name "DESeq2_GO_Reactome" `
    -Executable $rscript `
    -Arguments @("--vanilla", (Join-Path $PSScriptRoot "34_gse212728_deseq2_clusterprofiler.R")) `
    -Stdout (Join-Path $logDir "34_DESeq2_enrichment.stdout.log") `
    -Stderr (Join-Path $logDir "34_DESeq2_enrichment.stderr.log")

Invoke-Step `
    -Name "Figure3C-G" `
    -Executable $rscript `
    -Arguments @("--vanilla", (Join-Path $PSScriptRoot "35_plot_gse212728_reference_style.R")) `
    -Stdout (Join-Path $logDir "35_Figure3C-G.stdout.log") `
    -Stderr (Join-Path $logDir "35_Figure3C-G.stderr.log")

$previousPythonPath = $env:PYTHONPATH
$env:PYTHONPATH = if ([string]::IsNullOrWhiteSpace($previousPythonPath)) {
    $pythonPackages
}
else {
    "$pythonPackages;$previousPythonPath"
}

Invoke-Step `
    -Name "results_summary" `
    -Executable $python `
    -Arguments @((Join-Path $PSScriptRoot "45_write_gse212728_results_summary.py")) `
    -Stdout (Join-Path $logDir "45_results_summary.stdout.log") `
    -Stderr (Join-Path $logDir "45_results_summary.stderr.log")

Invoke-Step `
    -Name "executed_notebook" `
    -Executable $python `
    -Arguments @((Join-Path $PSScriptRoot "38_build_execute_gse212728_notebook.py")) `
    -Stdout (Join-Path $logDir "38_notebook.stdout.log") `
    -Stderr (Join-Path $logDir "38_notebook.stderr.log")

Invoke-Step `
    -Name "final_validation" `
    -Executable $rscript `
    -Arguments @("--vanilla", (Join-Path $PSScriptRoot "39_validate_gse212728_outputs.R")) `
    -Stdout (Join-Path $logDir "39_validation.stdout.log") `
    -Stderr (Join-Path $logDir "39_validation.stderr.log")

Set-Content -LiteralPath $completionMarker -Value (
    "Completed {0}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss zzz")
) -Encoding UTF8
Write-Status "PIPELINE_COMPLETE"
