options(stringsAsFactors = FALSE)

script_arg <- commandArgs(trailingOnly = FALSE)
script_path <- sub("^--file=", "", script_arg[grep("^--file=", script_arg)])
run_root <- normalizePath(
  file.path(dirname(script_path), ".."),
  winslash = "/",
  mustWork = TRUE
)
stage_dir <- file.path(
  run_root,
  "12_GSE212728_\u539f\u59cbRNAseq_DESeq2_Figure3C-G"
)
audit_dir <- file.path(stage_dir, "00_\u6570\u636e\u5ba1\u8ba1")
counts_dir <- file.path(stage_dir, "01_gene_counts")
de_dir <- file.path(stage_dir, "02_DESeq2")
enrichment_dir <- file.path(stage_dir, "03_GO_Reactome")
figure_dir <- file.path(stage_dir, "04_Figure3C-G")
qa_dir <- file.path(stage_dir, "05_\u53ef\u590d\u73b0\u4e0eQA")
dir.create(qa_dir, recursive = TRUE, showWarnings = FALSE)

cache_root <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/04_Bulk_RNA/GSE212728"
.libPaths(c(
  file.path(cache_root, "R_library"),
  "C:/Users/Lin/AppData/Local/R/win-library/4.5",
  .libPaths()
))
suppressPackageStartupMessages(library(jsonlite))

checks <- list()
add_check <- function(name, passed, details) {
  checks[[length(checks) + 1]] <<- data.frame(
    check = name,
    passed = isTRUE(passed),
    details = as.character(details),
    stringsAsFactors = FALSE
  )
}

metadata <- read.csv(
  file.path(audit_dir, "01_GSE212728_SRA\u6837\u672c\u8bbe\u8ba1.csv"),
  check.names = FALSE
)
count_matrix <- readRDS(
  file.path(counts_dir, "03_GSE212728_raw_gene_counts.rds")
)
fastq_audit <- read.csv(
  file.path(audit_dir, "05_GSE212728_FASTQ_MD5\u5ba1\u8ba1.csv"),
  check.names = FALSE
)
alignment <- read.csv(
  file.path(audit_dir, "06_GSE212728_alignment_assignment_summary.csv"),
  check.names = FALSE
)
de_all <- read.csv(
  file.path(de_dir, "01_GSE212728_DESeq2_D3_vs_Control_all_genes.csv"),
  check.names = FALSE
)
de_reference <- read.csv(
  file.path(de_dir, "02_GSE212728_P005_FC12_DEGs.csv"),
  check.names = FALSE
)
de_strict <- read.csv(
  file.path(de_dir, "03_GSE212728_FDR005_FC12_DEGs.csv"),
  check.names = FALSE
)
candidate <- read.csv(
  file.path(de_dir, "06_\u4e94\u4e2aSMR\u5019\u9009\u57fa\u56e0_DESeq2\u7ed3\u679c.csv"),
  check.names = FALSE
)
go_all <- read.csv(
  file.path(enrichment_dir, "01_clusterProfiler_GO_BP_CC_MF_all.csv"),
  check.names = FALSE
)
go_fdr <- read.csv(
  file.path(enrichment_dir, "02_clusterProfiler_GO_BP_CC_MF_FDR005.csv"),
  check.names = FALSE
)
reactome_all <- read.csv(
  file.path(enrichment_dir, "03_clusterProfiler_Reactome_all.csv"),
  check.names = FALSE
)
reactome_fdr <- read.csv(
  file.path(enrichment_dir, "04_clusterProfiler_Reactome_FDR005.csv"),
  check.names = FALSE
)

add_check(
  "Five deposited samples retained",
  ncol(count_matrix) == 5 &&
    nrow(metadata) == 5 &&
    sum(metadata$group == "Control") == 2 &&
    sum(metadata$group == "D3") == 3,
  paste(nrow(metadata), "metadata rows;", ncol(count_matrix), "count columns")
)
add_check(
  "Count columns match metadata",
  identical(colnames(count_matrix), metadata$analysis_sample),
  paste(colnames(count_matrix), collapse = ", ")
)
add_check(
  "Counts are non-negative integers",
  is.integer(count_matrix) &&
    all(count_matrix >= 0) &&
    all(count_matrix == round(count_matrix)),
  paste(nrow(count_matrix), "genes")
)
add_check(
  "All FASTQ byte checks passed",
  nrow(fastq_audit) == 10 && all(fastq_audit$bytes_match),
  paste(sum(fastq_audit$bytes_match), "of", nrow(fastq_audit))
)
add_check(
  "All FASTQ MD5 checks passed",
  nrow(fastq_audit) == 10 && all(fastq_audit$md5_match),
  paste(sum(fastq_audit$md5_match), "of", nrow(fastq_audit))
)
add_check(
  "Alignment summaries cover all samples",
  nrow(alignment) == 5 &&
    all(alignment$assigned_fragments > 0) &&
    all(alignment$assignment_rate > 0 & alignment$assignment_rate <= 1),
  paste("assignment rates", paste(round(alignment$assignment_rate, 3), collapse = ", "))
)

recomputed_reference <- (
  !is.na(de_all$pvalue) &
    de_all$pvalue < 0.05 &
    de_all$absolute_fold_change >= 1.2
)
recomputed_strict <- (
  !is.na(de_all$padj) &
    de_all$padj < 0.05 &
    de_all$absolute_fold_change >= 1.2
)
add_check(
  "Reference-threshold flags recompute exactly",
  identical(
    as.logical(de_all$reference_style_positive),
    as.logical(recomputed_reference)
  ),
  paste(sum(recomputed_reference), "positive genes")
)
add_check(
  "Strict-FDR flags recompute exactly",
  identical(
    as.logical(de_all$strict_FDR_positive),
    as.logical(recomputed_strict)
  ),
  paste(sum(recomputed_strict), "strict genes")
)
add_check(
  "Reference DEG export matches flags",
  nrow(de_reference) == sum(recomputed_reference),
  paste(nrow(de_reference), "exported rows")
)
add_check(
  "Strict DEG export matches flags",
  nrow(de_strict) == sum(recomputed_strict),
  paste(nrow(de_strict), "exported rows")
)

fixed_candidates <- c("MLX", "PSMC3IP", "USP3", "CCDC17", "INSIG2")
add_check(
  "Fixed SMR candidate list is unchanged",
  setequal(candidate$gene_symbol, fixed_candidates) &&
    nrow(candidate) == length(fixed_candidates),
  paste(candidate$gene_symbol, collapse = ", ")
)
add_check(
  "Wrong draft candidate names are absent",
  !any(candidate$gene_symbol %in% c("GDF15", "PLAU", "RORC")),
  "GDF15, PLAU and RORC are not part of the formal candidate table"
)

go_expected_fdr <- sum(!is.na(go_all$p.adjust) & go_all$p.adjust < 0.05)
reactome_expected_fdr <- sum(
  !is.na(reactome_all$p.adjust) &
    reactome_all$p.adjust < 0.05
)
add_check(
  "GO FDR export matches all-term table",
  nrow(go_fdr) == go_expected_fdr,
  paste(nrow(go_fdr), "of", nrow(go_all), "GO terms")
)
add_check(
  "Reactome FDR export matches all-term table",
  nrow(reactome_fdr) == reactome_expected_fdr,
  paste(nrow(reactome_fdr), "of", nrow(reactome_all), "Reactome terms")
)

figure_stems <- c(
  "Figure_3C_volcano",
  "Figure_3D_heatmap",
  "Figure_3E_GO_BP_CC_MF",
  "Figure_3F_Reactome",
  "Figure_3G_candidate_boxplots",
  "Figure_3C-G_composite_reference_style"
)
figure_formats <- c("png", "pdf", "svg", "tiff")
expected_figure_files <- as.vector(outer(
  figure_stems,
  figure_formats,
  paste,
  sep = "."
))
figure_paths <- file.path(figure_dir, expected_figure_files)
figure_info <- file.info(figure_paths)
add_check(
  "All requested figure formats exist",
  all(file.exists(figure_paths)) &&
    all(!is.na(figure_info$size)) &&
    all(figure_info$size > 1000),
  paste(sum(file.exists(figure_paths)), "of", length(figure_paths), "files")
)

notebook_validation_path <- file.path(
  qa_dir,
  "notebook_execution_validation.json"
)
notebook_validation <- if (file.exists(notebook_validation_path)) {
  fromJSON(notebook_validation_path)
} else {
  list(executed_top_to_bottom = FALSE)
}
add_check(
  "Notebook executed top to bottom",
  isTRUE(notebook_validation$executed_top_to_bottom),
  if (file.exists(notebook_validation_path)) {
    notebook_validation_path
  } else {
    "validation file missing"
  }
)

validation_table <- do.call(rbind, checks)
write.csv(
  validation_table,
  file.path(qa_dir, "validation_checks.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)
summary <- list(
  overall = if (all(validation_table$passed)) {
    "Ready to share with stated small-sample caveat"
  } else {
    "Needs revision"
  },
  passed_checks = sum(validation_table$passed),
  total_checks = nrow(validation_table),
  failed_checks = validation_table$check[!validation_table$passed],
  validated_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %z")
)
write_json(
  summary,
  file.path(qa_dir, "validation_summary.json"),
  auto_unbox = TRUE,
  pretty = TRUE
)
writeLines(
  capture.output(sessionInfo()),
  file.path(qa_dir, "R_sessionInfo_validation.txt"),
  useBytes = TRUE
)
print(validation_table)
print(summary)
if (!all(validation_table$passed)) {
  stop(
    "One or more validation checks failed: ",
    paste(summary$failed_checks, collapse = "; ")
  )
}
