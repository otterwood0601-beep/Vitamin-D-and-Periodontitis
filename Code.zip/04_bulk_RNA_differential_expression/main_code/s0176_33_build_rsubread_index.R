options(stringsAsFactors = FALSE)

script_arg <- commandArgs(trailingOnly = FALSE)
script_path <- sub("^--file=", "", script_arg[grep("^--file=", script_arg)])
run_root <- normalizePath(file.path(dirname(script_path), ".."), winslash = "/")

cache_root <- "E:/\u8840\u6e05\u7ef4\u751f\u7d20/\u539f\u59cb\u6570\u636e/04_Bulk_RNA/GSE212728"
reference_dir <- file.path(run_root, "source_data", "GENCODE_v49")
index_dir <- file.path(
  run_root,
  "tmp",
  "GSE212728_genome_Rsubread_split"
)
stage_candidates <- Sys.glob(file.path(
  run_root,
  "12_GSE212728_*Figure3C-G"
))
stage_dir <- stage_candidates[dir.exists(file.path(
  stage_candidates,
  "01_gene_counts"
))]
if (length(stage_dir) != 1L) {
  stop("Could not resolve the unique Figure 3C-G stage directory.")
}
stage_subdirectories <- list.dirs(
  stage_dir,
  recursive = FALSE,
  full.names = TRUE
)
output_dir <- stage_subdirectories[grepl(
  "^00_",
  basename(stage_subdirectories)
)]
if (length(output_dir) != 1L) {
  stop("Could not resolve the unique data-audit directory.")
}
library_dir <- file.path(cache_root, "R_library")
workspace_library <- file.path(run_root, "source_data", "R_library_raw")
.libPaths(c(workspace_library, library_dir, .libPaths()))

suppressPackageStartupMessages({
  library(Rsubread)
  library(jsonlite)
  library(R.utils)
})

dir.create(index_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

reference_files <- c(
  "GRCh38.primary_assembly.genome.fa.gz" = "1c73e18ea14fec14fe7eca5a48755de3",
  "gencode.v49.annotation.gtf.gz" = "0ef4a024ea2d35b1b88c12447b0b70b9",
  "gencode.v49.transcripts.fa.gz" = "ce72162016c56f64918a7dde76535ddb"
)
reference_paths <- file.path(reference_dir, names(reference_files))

if (!all(file.exists(reference_paths))) {
  stop("One or more GENCODE v49 reference files are missing.")
}

observed_md5 <- unname(tools::md5sum(reference_paths))
reference_audit <- data.frame(
  file = names(reference_files),
  path = reference_paths,
  expected_md5 = unname(reference_files),
  observed_md5 = observed_md5,
  md5_match = observed_md5 == unname(reference_files),
  bytes = unname(file.info(reference_paths)$size)
)
write.csv(
  reference_audit,
  file.path(output_dir, "01_GENCODE_v49_reference_MD5_audit.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)
if (!all(reference_audit$md5_match)) {
  stop("GENCODE reference MD5 validation failed.")
}

genome_gz <- file.path(
  reference_dir,
  "GRCh38.primary_assembly.genome.fa.gz"
)
genome_plain <- file.path(
  reference_dir,
  "GRCh38.primary_assembly.genome.fa"
)

index_base <- file.path(index_dir, "GRCh38_gencode_v49_gapped_split4GB")
completion_file <- file.path(
  index_dir,
  "GRCh38_gencode_v49_gapped_split4GB.complete.json"
)
existing_index <- Sys.glob(paste0(index_base, ".*"))
usable_existing_index <- existing_index[
  basename(existing_index) != basename(completion_file) &
    !grepl("\\.log$", existing_index, ignore.case = TRUE)
]
usable_index_ready <- length(usable_existing_index) >= 4 &&
  all(file.info(usable_existing_index)$size > 0)

if (!file.exists(completion_file) && !usable_index_ready) {
  if (!file.exists(genome_plain) || file.info(genome_plain)$size == 0) {
    R.utils::gunzip(
      genome_gz,
      destname = genome_plain,
      overwrite = TRUE,
      remove = FALSE
    )
  }
  if (length(existing_index)) {
    unlink(existing_index, force = TRUE)
  }
  buildindex(
    basename = index_base,
    reference = genome_plain,
    gappedIndex = TRUE,
    indexSplit = TRUE,
    memory = 4000
  )
}

index_files <- Sys.glob(paste0(index_base, ".*"))
index_files <- index_files[
  basename(index_files) != basename(completion_file) &
    !grepl("\\.log$", index_files, ignore.case = TRUE)
]
if (length(index_files) < 4 || any(file.info(index_files)$size == 0)) {
  stop("Rsubread index appears incomplete.")
}

index_manifest <- data.frame(
  file = basename(index_files),
  path = index_files,
  bytes = unname(file.info(index_files)$size),
  integrity_check = "present and non-empty"
)
write.csv(
  index_manifest,
  file.path(output_dir, "02_Rsubread_index_manifest.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

audit <- list(
  accession = "GSE212728",
  reference = "GENCODE release 49, GRCh38 primary assembly",
  reference_genome_md5 = reference_audit$observed_md5[
    reference_audit$file == "GRCh38.primary_assembly.genome.fa.gz"
  ],
  annotation_md5 = reference_audit$observed_md5[
    reference_audit$file == "gencode.v49.annotation.gtf.gz"
  ],
  index_basename = index_base,
  gapped_index = TRUE,
  index_split = TRUE,
  memory_mb = 4000,
  R_version = R.version.string,
  Rsubread_version = as.character(packageVersion("Rsubread")),
  index_files = nrow(index_manifest),
  completed_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %z")
)
write_json(audit, completion_file, auto_unbox = TRUE, pretty = TRUE)
write_json(
  audit,
  file.path(output_dir, "03_Rsubread_index_audit.json"),
  auto_unbox = TRUE,
  pretty = TRUE
)
print(audit)
