$ErrorActionPreference = 'Stop'

$bundleRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$venv = $env:PYSCENIC_VENV
if ($venv) {
    $python = Join-Path $venv 'Scripts\python.exe'
    $pyscenic = Join-Path $venv 'Scripts\pyscenic.exe'
    $arboretoExe = Join-Path $venv 'Scripts\arboreto_with_multiprocessing.exe'
    $arboretoPy = Join-Path $venv 'Scripts\arboreto_with_multiprocessing.py'
} else {
    $python = (Get-Command python -ErrorAction Stop).Source
    $pyscenic = (Get-Command pyscenic -ErrorAction Stop).Source
    $scriptBin = Split-Path -Parent $pyscenic
    $arboretoExe = Join-Path $scriptBin 'arboreto_with_multiprocessing.exe'
    $arboretoPy = Join-Path $scriptBin 'arboreto_with_multiprocessing.py'
}
$inputRoot = Join-Path $bundleRoot "1.$([char]0x6E90)$([char]0x6570)$([char]0x636E)\02_SCENIC$([char]0x8F93)$([char]0x5165)$([char]0x4E0E)$([char]0x4E2D)$([char]0x95F4)$([char]0x7ED3)$([char]0x679C)\01_SCENIC$([char]0x6A21)$([char]0x578B)$([char]0x8F93)$([char]0x5165)"
$resultRoot = Join-Path $bundleRoot "1.$([char]0x6E90)$([char]0x6570)$([char]0x636E)\02_SCENIC$([char]0x8F93)$([char]0x5165)$([char]0x4E0E)$([char]0x4E2D)$([char]0x95F4)$([char]0x7ED3)$([char]0x679C)\02_pySCENIC$([char]0x6838)$([char]0x5FC3)$([char]0x7ED3)$([char]0x679C)"
$resourceRoot = Join-Path $bundleRoot "1.$([char]0x6E90)$([char]0x6570)$([char]0x636E)\01_$([char]0x539F)$([char]0x59CB)$([char]0x8F93)$([char]0x5165)\05_pySCENIC_hg38_v10$([char]0x53C2)$([char]0x8003)$([char]0x6570)$([char]0x636E)$([char]0x5E93)"
$workers = 6
$seed = 20260907

foreach ($required in @($python, $pyscenic)) {
    if (-not (Test-Path -LiteralPath $required)) { throw "Missing local pySCENIC environment file: $required" }
}
New-Item -ItemType Directory -Force -Path $resultRoot | Out-Null

function Invoke-Step {
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        [Parameter(Mandatory=$true)][string]$Expected,
        [Parameter(Mandatory=$true)][scriptblock]$Action
    )
    if ((Test-Path -LiteralPath $Expected) -and ((Get-Item -LiteralPath $Expected).Length -gt 0)) {
        Write-Host "SKIP $Name (existing non-empty output)"
        return
    }
    Write-Host "START $Name"
    & $Action
    if ($LASTEXITCODE -ne 0) { throw "$Name failed with exit code $LASTEXITCODE" }
    if (-not (Test-Path -LiteralPath $Expected)) { throw "$Name did not create $Expected" }
    Write-Host "DONE $Name"
}

foreach ($cohort in @('healthy', 'periodontitis')) {
    $cohortDir = Join-Path $resultRoot $cohort
    New-Item -ItemType Directory -Force -Path $cohortDir | Out-Null
    $loom = Join-Path $inputRoot "${cohort}_ECM_remodeling_raw_counts.loom"
    $tf = Join-Path $inputRoot '01_expressed_TFs_hg38.txt'
    $adj = Join-Path $cohortDir '01_adjacencies.tsv'
    $reg = Join-Path $cohortDir '02_regulons.csv'
    $auc = Join-Path $cohortDir '03_aucell.loom'

    Invoke-Step -Name "$cohort GRNBoost2" -Expected $adj -Action {
        if (Test-Path -LiteralPath $arboretoExe) {
            & $arboretoExe $loom $tf --output $adj --method grnboost2 --seed $seed `
                --num_workers $workers --cell_id_attribute CellID --gene_attribute Gene --sparse
        } elseif (Test-Path -LiteralPath $arboretoPy) {
            & $python $arboretoPy $loom $tf --output $adj --method grnboost2 --seed $seed `
                --num_workers $workers --cell_id_attribute CellID --gene_attribute Gene --sparse
        } else {
            throw 'arboreto_with_multiprocessing entry point was not installed'
        }
    }

    Invoke-Step -Name "$cohort cisTarget motif pruning" -Expected $reg -Action {
        & $pyscenic ctx $adj `
            (Join-Path $resourceRoot 'hg38_500bp_up_100bp_down_full_tx_v10_clust.genes_vs_motifs.rankings.feather') `
            (Join-Path $resourceRoot 'hg38_10kbp_up_10kbp_down_full_tx_v10_clust.genes_vs_motifs.rankings.feather') `
            --annotations_fname (Join-Path $resourceRoot 'motifs-v10nr_clust-nr.hgnc-m0.001-o0.0.tbl') `
            --expression_mtx_fname $loom --output $reg --num_workers $workers `
            --cell_id_attribute CellID --gene_attribute Gene
    }

    Invoke-Step -Name "$cohort AUCell" -Expected $auc -Action {
        & $pyscenic aucell $loom $reg --output $auc --num_workers $workers --seed $seed `
            --cell_id_attribute CellID --gene_attribute Gene
    }
}

@(
    'pySCENIC=0.12.1 local Python 3.10 environment',
    "seed=$seed",
    "workers=$workers",
    'input=GSE164241 ECM remodeling fibroblasts only; Healthy and Periodontitis independently',
    'gene_filter=detected in >=5% of Healthy ECM or >=5% of Periodontitis ECM and in hg38 cisTarget v10 universe',
    'GRN=GRNBoost2',
    'motif_pruning=cisTarget hg38 v10 proximal plus distal; default thresholds',
    'AUCell=pySCENIC defaults'
) | Set-Content -LiteralPath (Join-Path $resultRoot '04_method_parameters.txt') -Encoding utf8

Write-Host 'ALL ECM-ONLY PYSCENIC STEPS COMPLETE'
