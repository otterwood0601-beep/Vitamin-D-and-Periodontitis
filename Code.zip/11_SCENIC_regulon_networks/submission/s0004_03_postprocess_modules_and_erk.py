from __future__ import annotations
import json
import re
from pathlib import Path
import loompy
import numpy as np
import pandas as pd
from pyscenic.cli.utils import load_signatures
from scipy.cluster.hierarchy import fcluster, leaves_list, linkage
from scipy.spatial.distance import squareform
from scipy.stats import fisher_exact, spearmanr
from sklearn.metrics import silhouette_score
BUNDLE_ROOT = Path(__file__).resolve().parents[2]
INPUT = BUNDLE_ROOT / '1.\u6e90\u6570\u636e' / '02_SCENIC\u8f93\u5165\u4e0e\u4e2d\u95f4\u7ed3\u679c' / '01_SCENIC\u6a21\u578b\u8f93\u5165'
PYSCENIC = BUNDLE_ROOT / '1.\u6e90\u6570\u636e' / '02_SCENIC\u8f93\u5165\u4e0e\u4e2d\u95f4\u7ed3\u679c' / '02_pySCENIC\u6838\u5fc3\u7ed3\u679c'
OUT = BUNDLE_ROOT / '1.\u6e90\u6570\u636e' / '03_\u51fa\u56fe\u6570\u636e\u8868' / '01_SCENIC\u6a21\u5757\u4e0eERK12\u7edf\u8ba1'
CONDITIONS = {'healthy': 'Healthy', 'periodontitis': 'Periodontitis'}
OUT.mkdir(parents=True, exist_ok=True)

def canonical_tf(name: str) -> str:
    text = re.sub('\\s*\\([+-]\\)\\s*$', '', str(name).strip())
    return re.sub('_extended$', '', text, flags=re.I).upper()

def bh_adjust(values: pd.Series) -> np.ndarray:
    p = np.asarray(values, dtype=float)
    out = np.full(len(p), np.nan)
    finite = np.isfinite(p)
    x = p[finite]
    if len(x) == 0:
        return out
    order = np.argsort(x)
    ranked = x[order]
    q = ranked * len(ranked) / np.arange(1, len(ranked) + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    restored = np.empty_like(q)
    restored[order] = np.clip(q, 0, 1)
    out[finite] = restored
    return out

def read_auc(path: Path) -> pd.DataFrame:
    with loompy.connect(str(path), mode='r', validate=False) as ds:
        cells = np.asarray(ds.ca.CellID).astype(str)
        arr = np.asarray(ds.ca.RegulonsAUC)
        if arr.dtype.names is None:
            raise ValueError('RegulonsAUC is not a structured array')
        return pd.DataFrame({name: arr[name].astype(float) for name in arr.dtype.names}, index=cells)

def regulon_metadata(path: Path):
    rows = []
    target_map: dict[str, set[str]] = {}
    for signature in load_signatures(str(path)):
        tf = canonical_tf(getattr(signature, 'transcription_factor', signature.name))
        rows.append({'regulon': signature.name, 'tf': tf, 'target_count': len(signature.genes), 'is_extended': 'extended' in signature.name.lower()})
        target_map[signature.name] = {str(g).upper() for g in signature.genes}
    return (pd.DataFrame(rows), target_map)

def choose_one_regulon_per_tf(auc: pd.DataFrame, meta: pd.DataFrame):
    meta = meta.copy()
    auc_by_normalized = {re.sub('\\s+', '', str(column)): column for column in auc.columns}
    meta['auc_column'] = meta['regulon'].map(lambda value: auc_by_normalized.get(re.sub('\\s+', '', str(value))))
    meta = meta.dropna(subset=['auc_column'])
    meta = meta.sort_values(['tf', 'is_extended', 'target_count'], ascending=[True, True, False])
    meta = meta.drop_duplicates('tf', keep='first')
    selected = auc.loc[:, meta['auc_column'].tolist()].copy()
    selected.columns = meta['tf'].tolist()
    return (selected, meta)

def cluster_regulons(auc_tf: pd.DataFrame, selected_meta: pd.DataFrame):
    z = (auc_tf - auc_tf.mean(axis=0)) / auc_tf.std(axis=0, ddof=0).replace(0, 1)
    corr = np.corrcoef(z.to_numpy().T)
    corr = np.nan_to_num(corr, nan=0.0, posinf=0.0, neginf=0.0)
    np.fill_diagonal(corr, 1.0)
    distance = np.clip(1.0 - corr, 0.0, 2.0)
    np.fill_diagonal(distance, 0.0)
    tree = linkage(squareform(distance, checks=False), method='average')
    best_k, best_silhouette = (None, -np.inf)
    for k in range(3, min(14, auc_tf.shape[1] - 1) + 1):
        labels = fcluster(tree, t=k, criterion='maxclust')
        sizes = pd.Series(labels).value_counts()
        if len(sizes) < 2 or sizes.min() < 2:
            continue
        score = float(silhouette_score(distance, labels, metric='precomputed'))
        if score > best_silhouette:
            best_k, best_silhouette = (k, score)
    if best_k is None:
        best_k = min(3, max(2, auc_tf.shape[1] - 1))
        best_silhouette = float('nan')
    raw_labels = fcluster(tree, t=best_k, criterion='maxclust')
    leaf_order = np.asarray(leaves_list(tree), dtype=int)
    label_order: list[int] = []
    for label in raw_labels[leaf_order]:
        if int(label) not in label_order:
            label_order.append(int(label))
    label_to_module = {label: f'M{i + 1}' for i, label in enumerate(label_order)}
    modules = np.asarray([label_to_module[int(label)] for label in raw_labels])
    ordered_tfs = auc_tf.columns.to_numpy()[leaf_order]
    ordered_modules = modules[leaf_order]
    ordered_corr = pd.DataFrame(corr[np.ix_(leaf_order, leaf_order)], index=ordered_tfs, columns=ordered_tfs)
    module_scores = pd.DataFrame(index=auc_tf.index)
    for module in [f'M{i + 1}' for i in range(len(label_order))]:
        module_scores[module] = auc_tf.loc[:, modules == module].mean(axis=1)
    meta_by_tf = selected_meta.set_index('tf')
    summary = pd.DataFrame({'tf': auc_tf.columns, 'module': modules})
    summary['regulon'] = summary['tf'].map(meta_by_tf['regulon'])
    summary['target_count'] = summary['tf'].map(meta_by_tf['target_count'])
    summary = summary.sort_values('tf', key=lambda s: s.map({tf: i for i, tf in enumerate(ordered_tfs)}))
    bounds = []
    for module in [f'M{i + 1}' for i in range(len(label_order))]:
        positions = np.where(ordered_modules == module)[0] + 1
        bounds.append({'module': module, 'start': int(positions.min()), 'end': int(positions.max()), 'n_regulons': int(len(positions))})
    return (ordered_corr, pd.DataFrame(bounds), summary, module_scores, best_k, best_silhouette)

def main() -> None:
    metadata = pd.read_csv(INPUT / '02_ECM_remodeling_cell_metadata_and_umap.csv')
    metadata['cell_id'] = metadata['cell_id'].astype(str)
    metadata = metadata.set_index('cell_id', drop=False)
    raw_erk = pd.read_csv(INPUT / '04_ERK1_ERK2_primary_raw_counts_by_cell.csv.gz')
    raw_erk['cell_id'] = raw_erk['cell_id'].astype(str)
    raw_erk = raw_erk.set_index('cell_id')
    erk_genes = list(raw_erk.columns)
    gene_universe = set(pd.read_csv(INPUT / '03_filtered_gene_audit.csv')['gene'].astype(str).str.upper())
    all_rows = []
    condition_manifest = {}
    for key, condition in CONDITIONS.items():
        out = OUT / key
        out.mkdir(parents=True, exist_ok=True)
        auc = read_auc(PYSCENIC / key / '03_aucell.loom')
        regmeta, target_map = regulon_metadata(PYSCENIC / key / '02_regulons.csv')
        auc_tf, selected_meta = choose_one_regulon_per_tf(auc, regmeta)
        corr, bounds, tf_summary, module_scores, n_modules, silhouette = cluster_regulons(auc_tf, selected_meta)
        corr.to_csv(out / '01_regulon_TF_correlation_ordered.csv.gz', compression='gzip')
        bounds.to_csv(out / '02_module_boundaries.csv', index=False)
        tf_summary.to_csv(out / '03_regulon_TF_module_membership.csv', index=False)
        cells = auc_tf.index.intersection(metadata.index).intersection(raw_erk.index)
        local_meta = metadata.loc[cells]
        expression = raw_erk.loc[cells, erk_genes].astype(float)
        library = local_meta['nCount_RNA'].astype(float).clip(lower=1.0)
        log_norm = np.log1p(expression.mul(10000.0 / library, axis=0))
        gene_sd = log_norm.std(axis=0, ddof=0).replace(0, np.nan)
        erk_score = ((log_norm - log_norm.mean(axis=0)) / gene_sd).fillna(0.0).mean(axis=1)
        score_table = module_scores.loc[cells].copy()
        score_table.insert(0, 'ERK1_ERK2_score', erk_score)
        score_table.insert(0, 'condition', condition)
        score_table.insert(0, 'cell_id', cells)
        score_table.to_csv(out / '04_cell_module_AUCell_and_ERK12_score.csv', index=False)
        rows = []
        primary_in_universe = set(erk_genes) & gene_universe
        for module in bounds['module']:
            module_tfs = tf_summary.loc[tf_summary['module'].eq(module), 'tf']
            regulons = tf_summary.loc[tf_summary['module'].eq(module), 'regulon']
            targets: set[str] = set()
            for regulon in regulons:
                targets.update(target_map.get(regulon, set()))
            targets &= gene_universe
            overlap = targets & primary_in_universe
            a = len(overlap)
            b = len(targets - primary_in_universe)
            c = len(primary_in_universe - targets)
            d = len(gene_universe - (targets | primary_in_universe))
            odds, fisher_p = fisher_exact([[a, b], [c, d]], alternative='greater')
            rho, rho_p = spearmanr(score_table[module], score_table['ERK1_ERK2_score'])
            rows.append({'condition': condition, 'module': module, 'cells': len(cells), 'n_regulons': int(len(module_tfs)), 'Spearman_rho_module_AUCell_vs_ERK12': float(rho), 'Spearman_p': float(rho_p), 'module_target_genes': len(targets), 'ERK12_genes_in_filtered_universe': len(primary_in_universe), 'ERK12_target_overlap_count': a, 'ERK12_target_overlap_genes': '/'.join(sorted(overlap)), 'Fisher_odds_ratio': float(odds), 'Fisher_p': float(fisher_p)})
        table = pd.DataFrame(rows)
        table['Spearman_FDR'] = bh_adjust(table['Spearman_p'])
        table['Fisher_FDR'] = bh_adjust(table['Fisher_p'])
        table['absolute_Spearman_rho'] = table['Spearman_rho_module_AUCell_vs_ERK12'].abs()
        table = table.sort_values(['absolute_Spearman_rho', 'Fisher_p'], ascending=[False, True]).reset_index(drop=True)
        table['ERK12_association_rank'] = np.arange(1, len(table) + 1)
        table.to_csv(out / '05_module_ERK12_association.csv', index=False)
        all_rows.append(table)
        best = table.iloc[0].to_dict()
        condition_manifest[key] = {'label': condition, 'cells': int(auc_tf.shape[0]), 'SCENIC_TFs': int(auc_tf.shape[1]), 'modules': int(n_modules), 'silhouette': silhouette, 'module_numbering_rule': 'top-left to bottom-right dendrogram leaf order', 'best_ERK12_module_by_absolute_Spearman': best}
    combined = pd.concat(all_rows, ignore_index=True)
    combined = combined.sort_values(['absolute_Spearman_rho', 'Fisher_p'], ascending=[False, True]).reset_index(drop=True)
    combined.to_csv(OUT / '06_all_modules_ERK12_association_ranked.csv', index=False)
    manifest = {'input': 'GSE164241 ECM remodeling fibroblasts only', 'conditions': condition_manifest, 'ERK12_primary_definition': "GO:0070371 ERK1 and ERK2 cascade from the user's ERK-1,2 pathway workbook", 'ERK12_score': 'per-gene log1p(CP10K), standardized across cells, then averaged over available pathway genes', 'primary_ranking': 'absolute Spearman rho between mean module AUCell and ERK1/ERK2 score', 'orthogonal_test': 'one-sided Fisher enrichment of module regulon targets in the ERK1/ERK2 gene set', 'overall_highest_association': combined.iloc[0].to_dict()}
    (OUT / '07_analysis_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2, default=str) + '\n', encoding='utf-8')
    print(json.dumps(manifest, ensure_ascii=False, indent=2, default=str))
if __name__ == '__main__':
    main()
