from __future__ import annotations
import json
import math
from pathlib import Path
import anndata as ad
import numpy as np
import pandas as pd
import scipy.sparse as sp
BUNDLE_ROOT = Path(__file__).resolve().parents[2]
RAW = BUNDLE_ROOT / '1.\u6e90\u6570\u636e' / '01_\u539f\u59cb\u8f93\u5165'
H5AD = RAW / '01_CELLxGENE\u6574\u5408\u7259\u5468\u56fe\u8c31' / 'Integrated_Human_Periodontitis_Atlas_105918cells.h5ad'
SELECTED = RAW / '02_GSE164241_ECM\u7ec6\u80de\u7b5b\u9009' / '01_selected_cells_ECM_lineage_Williams_strict_QC.csv'
DATA_OUT = BUNDLE_ROOT / '1.\u6e90\u6570\u636e' / '03_\u51fa\u56fe\u6570\u636e\u8868' / '04_\u4f9b\u4f53\u4f2abulk\u76f8\u5173'
GENES = ('GDF15', 'MAPK1', 'MAPK3')

def dense_vector(x) -> np.ndarray:
    if sp.issparse(x):
        return x.toarray().ravel()
    return np.asarray(x).ravel()

def main() -> None:
    data_dir = DATA_OUT
    qa_dir = DATA_OUT / 'QA'
    data_dir.mkdir(parents=True, exist_ok=True)
    qa_dir.mkdir(parents=True, exist_ok=True)
    selected = pd.read_csv(SELECTED)
    selected = selected[selected['fibroblast_type'].eq('ECM remodeling-associated fibroblasts')].copy()
    selected['h5ad_row'] = selected['h5ad_row'].astype(int)
    selected['condition'] = selected['disease'].replace({'normal': 'Healthy', 'periodontitis': 'Periodontitis'})
    if selected['nCount_RNA'].isna().any() or (selected['nCount_RNA'] <= 0).any():
        raise ValueError('Invalid nCount_RNA values in selected-cell metadata')
    a = ad.read_h5ad(H5AD, backed='r')
    stored_rows = selected['h5ad_row'].to_numpy()
    expected_ids = selected['cell_id'].astype(str).to_numpy()
    offset_scores: dict[int, float] = {}
    for offset in (0, -1):
        rows = stored_rows + offset
        if rows.min() >= 0 and rows.max() < a.n_obs:
            observed = np.asarray(a.obs_names[rows]).astype(str)
            offset_scores[offset] = float(np.mean(observed == expected_ids))
    row_offset = max(offset_scores, key=offset_scores.get)
    if offset_scores[row_offset] != 1.0:
        raise ValueError(f'Unable to obtain a complete cell-ID match: {offset_scores}')
    rows = stored_rows + row_offset
    symbols = a.raw.var['feature_name'].astype(str).to_numpy()
    per_cell = selected[['cell_id', 'donor_id', 'condition', 'nCount_RNA']].reset_index(drop=True)
    gene_column_indices: dict[str, int] = {}
    for gene in GENES:
        idx = np.flatnonzero(symbols == gene)
        if len(idx) != 1:
            raise ValueError(f'Expected one raw-count column for {gene}; found {len(idx)}')
        gene_column_indices[gene] = int(idx[0])
        values = dense_vector(a.raw.X[rows, idx[0]]).astype(float)
        if not np.isfinite(values).all() or np.any(values < 0):
            raise ValueError(f'Invalid raw counts for {gene}')
        per_cell[gene] = values
    a.file.close()
    rows_out: list[dict] = []
    for (condition, donor), frame in per_cell.groupby(['condition', 'donor_id'], sort=True):
        library_sum = float(frame['nCount_RNA'].sum())
        for gene in GENES:
            raw_sum = float(frame[gene].sum())
            rows_out.append({'donor_id': donor, 'condition': condition, 'feature': gene, 'raw_sum': raw_sum, 'library_sum_source_nCount_RNA': library_sum, 'log2_CPM_plus1': math.log2(raw_sum * 1000000.0 / library_sum + 1.0), 'cells': int(len(frame))})
    pseudobulk = pd.DataFrame(rows_out)
    if pseudobulk['donor_id'].nunique() != 21 or len(pseudobulk) != 63:
        raise ValueError(f"Unexpected donor pseudobulk size: donors={pseudobulk['donor_id'].nunique()}, rows={len(pseudobulk)}")
    out_csv = data_dir / '01_GDF15_MAPK1_MAPK3_ECM_donor_pseudobulk_log2CPMplus1.csv'
    pseudobulk.to_csv(out_csv, index=False)
    per_cell.to_csv(data_dir / '00_GDF15_MAPK1_MAPK3_ECM_raw_counts_by_cell.csv.gz', index=False, compression='gzip')
    audit = {'source_h5ad': H5AD.relative_to(BUNDLE_ROOT).as_posix(), 'selected_metadata': SELECTED.relative_to(BUNDLE_ROOT).as_posix(), 'cell_filter': 'GSE164241/Williams ECM remodeling-associated fibroblasts', 'expression_layer': 'AnnData raw.X counts', 'normalization': 'per-donor log2(sum gene counts * 1e6 / sum source nCount_RNA + 1)', 'h5ad_row_offset': int(row_offset), 'cell_id_match_fraction': float(offset_scores[row_offset]), 'gene_column_indices_zero_based': gene_column_indices, 'cells': int(len(per_cell)), 'donors': int(pseudobulk['donor_id'].nunique()), 'donors_by_condition': {str(k): int(v) for k, v in pseudobulk.drop_duplicates('donor_id')['condition'].value_counts().items()}, 'features': list(GENES), 'output': out_csv.relative_to(BUNDLE_ROOT).as_posix()}
    (qa_dir / '01_pseudobulk_extraction_audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(audit, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
