from __future__ import annotations
import json
from pathlib import Path
import anndata as ad
import numpy as np
import pandas as pd
import scipy.sparse as sp
BUNDLE_ROOT = Path(__file__).resolve().parents[2]
RAW = BUNDLE_ROOT / '1.\u6e90\u6570\u636e' / '01_\u539f\u59cb\u8f93\u5165'
H5AD = RAW / '01_CELLxGENE\u6574\u5408\u7259\u5468\u56fe\u8c31' / 'Integrated_Human_Periodontitis_Atlas_105918cells.h5ad'
SELECTED = RAW / '02_GSE164241_ECM\u7ec6\u80de\u7b5b\u9009' / '01_selected_cells_ECM_lineage_Williams_strict_QC.csv'
OUT = BUNDLE_ROOT / '1.\u6e90\u6570\u636e' / '03_\u51fa\u56fe\u6570\u636e\u8868' / '03_MAPK1_MAPK3\u8868\u8fbe'
GENES = ('MAPK1', 'MAPK3')

def dense_vector(x) -> np.ndarray:
    if sp.issparse(x):
        return x.toarray().ravel()
    return np.asarray(x).ravel()

def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    selected = pd.read_csv(SELECTED)
    selected = selected[selected['fibroblast_type'].eq('ECM remodeling-associated fibroblasts')].copy()
    selected['h5ad_row'] = selected['h5ad_row'].astype(int)
    selected['condition'] = selected['disease'].replace({'normal': 'Healthy', 'periodontitis': 'Periodontitis'})
    a = ad.read_h5ad(H5AD, backed='r')
    stored_rows = selected['h5ad_row'].to_numpy()
    expected_ids = selected['cell_id'].astype(str).to_numpy()
    offset_scores: dict[int, float] = {}
    for offset in (0, -1):
        rows = stored_rows + offset
        if rows.min() >= 0 and rows.max() < a.n_obs:
            observed = np.asarray(a.obs_names[rows]).astype(str)
            offset_scores[offset] = float(np.mean(observed == expected_ids))
    row_offset = max(offset_scores, key=offset_scores.get)
    if offset_scores[row_offset] != 1.0:
        raise ValueError(f'Unable to obtain a complete cell-ID match: {offset_scores}')
    rows = stored_rows + row_offset
    symbols = a.var['feature_name'].astype(str).to_numpy()
    out = selected[['cell_id', 'condition', 'donor_id']].copy()
    source_columns: dict[str, int] = {}
    for gene in GENES:
        idx = np.flatnonzero(symbols == gene)
        if len(idx) != 1:
            raise ValueError(f'Expected one {gene} column in AnnData .X; found {len(idx)}')
        source_columns[gene] = int(idx[0])
        values = dense_vector(a.X[rows, idx[0]])
        if len(values) != len(out) or not np.isfinite(values).all() or np.any(values < 0):
            raise ValueError(f'Invalid expression values for {gene}')
        out[gene] = values.astype(float)
    a.file.close()
    data_file = OUT / '00_MAPK1_MAPK3_source_normalized_expression_by_cell.csv.gz'
    audit_file = OUT / '00_MAPK1_MAPK3_source_normalized_expression_audit.json'
    out.to_csv(data_file, index=False, compression='gzip')
    audit = {'source_h5ad': H5AD.relative_to(BUNDLE_ROOT).as_posix(), 'selected_metadata': SELECTED.relative_to(BUNDLE_ROOT).as_posix(), 'expression_layer': 'AnnData .X (source-normalized expression)', 'cell_filter': 'GSE164241/Williams ECM remodeling-associated fibroblasts', 'h5ad_row_offset': int(row_offset), 'cell_id_match_fraction': float(offset_scores[row_offset]), 'gene_column_indices_zero_based': source_columns, 'cells_total': int(len(out)), 'cells_by_condition': {str(k): int(v) for k, v in out['condition'].value_counts().items()}, 'output': data_file.relative_to(BUNDLE_ROOT).as_posix()}
    audit_file.write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(audit, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
