from __future__ import annotations
import json
from pathlib import Path
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.ticker import MaxNLocator
from PIL import Image, ImageDraw, ImageFont
BUNDLE_ROOT = Path(__file__).resolve().parents[2]
FORMAL = BUNDLE_ROOT / '1.\u6e90\u6570\u636e' / '01_\u539f\u59cb\u8f93\u5165' / '04_\u6b63\u5f0fUMAP\u5750\u6807'
OUT = BUNDLE_ROOT / '3.\u56fe' / '03_MAPK1_MAPK3\u8868\u8fbe'
DATA_OUT = BUNDLE_ROOT / '1.\u6e90\u6570\u636e' / '03_\u51fa\u56fe\u6570\u636e\u8868' / '03_MAPK1_MAPK3\u8868\u8fbe'
QA_OUT = DATA_OUT / 'QA'
EXTRACTED = DATA_OUT / '00_MAPK1_MAPK3_source_normalized_expression_by_cell.csv.gz'
EXTRACTION_AUDIT = DATA_OUT / '00_MAPK1_MAPK3_source_normalized_expression_audit.json'
GENES = ('MAPK1', 'MAPK3')
CONDITIONS = {'Healthy': {'zh': '\u5065\u5eb7', 'coords': FORMAL / 'Williams\u5065\u5eb7\u5168\u90e81884\u4e2aECM-remodeling\u7ec6\u80de_GDF15_OE\u539f\u59cb\u503c.csv.gz', 'expected_n': 1884, 'point_size': 6.0}, 'Periodontitis': {'zh': '\u7259\u5468\u708e', 'coords': FORMAL / 'Williams\u7259\u5468\u708e\u5168\u90e8552\u4e2aECM-remodeling\u7ec6\u80de_GDF15_KO\u539f\u59cb\u503c.csv.gz', 'expected_n': 552, 'point_size': 11.0}}
CMAP = LinearSegmentedColormap.from_list('expression_teal', [(0.0, '#D9D9D9'), (0.08, '#D9D9D9'), (0.16, '#B9DDDA'), (0.48, '#69BDB7'), (0.74, '#1B9997'), (1.0, '#006D6F')], N=256)

def configure_matplotlib() -> None:
    mpl.rcParams.update({'font.family': 'Arial', 'font.size': 10.5, 'axes.titlesize': 14, 'axes.labelsize': 12, 'axes.linewidth': 1.05, 'xtick.labelsize': 9.5, 'ytick.labelsize': 9.5, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'savefig.facecolor': 'white', 'figure.facecolor': 'white'})

def read_expression() -> tuple[pd.DataFrame, dict]:
    if not EXTRACTED.exists() or not EXTRACTION_AUDIT.exists():
        raise FileNotFoundError('Run 07a_extract_MAPK1_MAPK3_normalized_expression.py first with the pySCENIC Python environment')
    out = pd.read_csv(EXTRACTED)
    required = {'cell_id', 'condition', 'donor_id', *GENES}
    missing = sorted(required - set(out.columns))
    if missing:
        raise ValueError(f'Missing extracted-expression columns: {missing}')
    audit = json.loads(EXTRACTION_AUDIT.read_text(encoding='utf-8'))
    return (out, audit)

def merge_formal_coordinates(expression: pd.DataFrame) -> tuple[dict[str, pd.DataFrame], list[dict]]:
    merged_by_condition: dict[str, pd.DataFrame] = {}
    audits: list[dict] = []
    for condition, cfg in CONDITIONS.items():
        expr = expression[expression['condition'].eq(condition)].copy()
        coords = pd.read_csv(cfg['coords'])[['cell_id', 'UMAP_1', 'UMAP_2']].copy()
        if expr['cell_id'].duplicated().any() or coords['cell_id'].duplicated().any():
            raise ValueError(f'Duplicate cell IDs for {condition}')
        merged = expr.merge(coords, on='cell_id', how='outer', indicator=True)
        counts = merged['_merge'].value_counts().to_dict()
        if counts.get('left_only', 0) or counts.get('right_only', 0):
            raise ValueError(f'Formal-coordinate mismatch for {condition}: {counts}')
        merged = merged.drop(columns='_merge')
        if len(merged) != cfg['expected_n']:
            raise ValueError(f'Unexpected cell count for {condition}: {len(merged)}')
        merged_by_condition[condition] = merged
        audits.append({'condition': condition, 'cells': int(len(merged)), 'coordinate_source': str(cfg['coords']), 'cell_join': {str(k): int(v) for k, v in counts.items()}, 'coordinate_ranges': {'UMAP_1': [float(merged['UMAP_1'].min()), float(merged['UMAP_1'].max())], 'UMAP_2': [float(merged['UMAP_2'].min()), float(merged['UMAP_2'].max())]}, 'expression': {gene: {'min': float(merged[gene].min()), 'median': float(merged[gene].median()), 'mean': float(merged[gene].mean()), 'max': float(merged[gene].max()), 'detected_cells': int((merged[gene] > 0).sum()), 'detected_percent': float(100 * (merged[gene] > 0).mean())} for gene in GENES}})
    return (merged_by_condition, audits)

def plot_one(df: pd.DataFrame, gene: str, condition: str, cfg: dict, vmax: float) -> tuple[Path, Path]:
    values = df[gene].to_numpy(float)
    order = np.argsort(values, kind='mergesort')
    x = df['UMAP_1'].to_numpy(float)[order]
    y = df['UMAP_2'].to_numpy(float)[order]
    c = values[order]
    fig, ax = plt.subplots(figsize=(7.0, 5.5))
    norm = Normalize(vmin=0.0, vmax=vmax)
    sc = ax.scatter(x, y, c=c, cmap=CMAP, norm=norm, s=cfg['point_size'], linewidths=0, alpha=0.92, rasterized=True)
    ax.set_title(gene, color='#006D6F', fontweight='bold', pad=18)
    ax.text(0.5, 1.005, f'{condition} ECM-remodeling fibroblasts', transform=ax.transAxes, ha='center', va='bottom', fontsize=10.2, color='#444444')
    ax.set_xlabel('UMAP_1')
    ax.set_ylabel('UMAP_2')
    ax.set_aspect('equal', adjustable='box')
    ax.grid(False)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.tick_params(axis='both', width=1.0, length=4.2, color='#222222')
    ax.xaxis.set_major_locator(MaxNLocator(nbins=5))
    ax.yaxis.set_major_locator(MaxNLocator(nbins=5))
    cbar = fig.colorbar(sc, ax=ax, fraction=0.05, pad=0.055, aspect=18)
    cbar.ax.set_title('Normalized\nexpression', fontsize=10.2, fontweight='normal', pad=7)
    cbar.locator = MaxNLocator(nbins=5)
    cbar.update_ticks()
    cbar.ax.tick_params(width=0.9, length=3.8)
    cbar.outline.set_linewidth(0.9)
    fig.subplots_adjust(left=0.12, right=0.88, bottom=0.12, top=0.88)
    out_dir = OUT / cfg['zh']
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{cfg['zh']}_ECM-remodeling_{gene}_\u6807\u51c6\u5316\u8868\u8fbe_\u6b63\u5f0fUMAP\u5750\u6807"
    pdf = out_dir / f'{stem}.pdf'
    png = out_dir / f'{stem}.png'
    fig.savefig(pdf, dpi=300, bbox_inches='tight', pad_inches=0.08)
    fig.savefig(png, dpi=300, bbox_inches='tight', pad_inches=0.08)
    plt.close(fig)
    return (pdf, png)

def make_contact_sheet(paths: list[Path], out_path: Path) -> None:
    images = [Image.open(path).convert('RGB') for path in paths]
    thumb_w = 900
    thumbs = []
    for image in images:
        scale = thumb_w / image.width
        thumbs.append(image.resize((thumb_w, round(image.height * scale)), Image.Resampling.LANCZOS))
    cell_h = max((image.height for image in thumbs))
    margin = 34
    canvas = Image.new('RGB', (2 * thumb_w + 3 * margin, 2 * cell_h + 3 * margin), 'white')
    for index, image in enumerate(thumbs):
        row, col = divmod(index, 2)
        x0 = margin + col * (thumb_w + margin)
        y0 = margin + row * (cell_h + margin)
        canvas.paste(image, (x0, y0))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(out_path, dpi=(180, 180), optimize=True)
    for image in images:
        image.close()

def main() -> None:
    configure_matplotlib()
    OUT.mkdir(parents=True, exist_ok=True)
    DATA_OUT.mkdir(parents=True, exist_ok=True)
    QA_OUT.mkdir(parents=True, exist_ok=True)
    expression, source_audit = read_expression()
    merged_by_condition, condition_audits = merge_formal_coordinates(expression)
    vmax = max((float(df[list(GENES)].to_numpy().max()) for df in merged_by_condition.values()))
    if vmax <= 0:
        raise ValueError('MAPK1/MAPK3 expression is zero in every selected cell')
    outputs: list[dict] = []
    pngs: list[Path] = []
    for condition, cfg in CONDITIONS.items():
        df = merged_by_condition[condition]
        df.to_csv(DATA_OUT / f"{cfg['zh']}_ECM-remodeling_MAPK1_MAPK3\u6807\u51c6\u5316\u8868\u8fbe\u4e0e\u6b63\u5f0fUMAP\u5750\u6807.csv.gz", index=False, compression='gzip')
        for gene in GENES:
            pdf, png = plot_one(df, gene, condition, cfg, vmax)
            outputs.append({'condition': condition, 'gene': gene, 'pdf': str(pdf), 'png': str(png)})
            pngs.append(png)
    make_contact_sheet(pngs, QA_OUT / 'MAPK1_MAPK3_\u5065\u5eb7\u4e0e\u7259\u5468\u708e_\u56db\u56fe\u603b\u89c8.png')
    manifest = {'analysis': 'MAPK1/MAPK3 expression in GSE164241/Williams ECM-remodeling fibroblasts', 'source': source_audit, 'plot_rule': 'AnnData .X source-normalized expression; exact formal UMAP coordinates; no smoothing, clipping, imputation, thresholding, or z-scoring', 'shared_color_scale': {'min': 0.0, 'max': float(vmax)}, 'conditions': condition_audits, 'outputs': outputs}
    (QA_OUT / 'MAPK1_MAPK3_expression_UMAP_audit.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (DATA_OUT / 'README_\u8bf7\u5148\u770b.md').write_text('# MAPK1/MAPK3 expression UMAP\n\n- Four independent maps: MAPK1 and MAPK3 in Healthy and Periodontitis ECM-remodeling fibroblasts.\n- Expression values are the source-normalized values in the atlas AnnData `.X` matrix.\n- Coordinates are the exact formal ECM-remodeling UMAP coordinates used in the approved reference figures.\n- All four maps share one colour scale, so colours are directly comparable.\n- No smoothing, clipping, imputation, thresholding, or z-scoring was applied.\n', encoding='utf-8')
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
