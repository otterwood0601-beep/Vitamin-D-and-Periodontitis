from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
BUNDLE_ROOT = Path(__file__).resolve().parents[2]
WORKBOOK = BUNDLE_ROOT / '1.\u6e90\u6570\u636e' / '01_\u539f\u59cb\u8f93\u5165' / '03_ERK1_ERK2\u901a\u8def\u8868' / 'ERK-1,2\u7684\u901a\u8def.xlsx'
OUT = BUNDLE_ROOT / '1.\u6e90\u6570\u636e' / '02_SCENIC\u8f93\u5165\u4e0e\u4e2d\u95f4\u7ed3\u679c' / '01_SCENIC\u6a21\u578b\u8f93\u5165'

def split_genes(value: object) -> list[str]:
    text = '' if pd.isna(value) else str(value)
    for separator in (';', ','):
        text = text.replace(separator, '/')
    return sorted({gene.strip().upper() for gene in text.split('/') if gene.strip()})

def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    specs = [('GO_BP', 'ID', 'GO:0070371', 'geneID', True), ('GO_BP', 'ID', 'GO:0070372', 'geneID', False), ('Reactome', 'ID', 'MAPK3 (ERK1) Activation', 'geneID', False), ('KEGG', 'term', 'MAPK SIGNALING PATHWAY', 'overlap_genes', False)]
    rows: list[dict[str, object]] = []
    source_rows: list[dict[str, object]] = []
    for sheet, id_col, identifier, gene_col, primary in specs:
        table = pd.read_excel(WORKBOOK, sheet_name=sheet)
        hit = table[table[id_col].astype(str).str.strip().eq(identifier)]
        if len(hit) != 1:
            raise ValueError(f'Expected one row for {sheet}:{identifier}, found {len(hit)}')
        record = hit.iloc[0]
        genes = split_genes(record[gene_col])
        description = str(record.get('Description', record.get('term', identifier)))
        source_rows.append({'sheet': sheet, 'identifier': identifier, 'description': description, 'is_primary_ERK1_ERK2_definition': primary, 'gene_count': len(genes), 'p_value': record.get('pvalue', record.get('p_value', None)), 'adjusted_p': record.get('p.adjust', record.get('adjusted_p', None))})
        rows.extend(({'sheet': sheet, 'identifier': identifier, 'description': description, 'is_primary_ERK1_ERK2_definition': primary, 'gene': gene} for gene in genes))
    long = pd.DataFrame(rows).sort_values(['is_primary_ERK1_ERK2_definition', 'sheet', 'identifier', 'gene'], ascending=[False, True, True, True])
    long.to_csv(OUT / '00_ERK12_gene_sets_from_user_workbook.csv', index=False)
    manifest = {'source_workbook': WORKBOOK.relative_to(BUNDLE_ROOT).as_posix(), 'primary_definition': 'GO:0070371 ERK1 and ERK2 cascade', 'primary_gene_count': int(long[long['is_primary_ERK1_ERK2_definition']]['gene'].nunique()), 'source_rows': source_rows}
    (OUT / '00_ERK12_gene_set_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2, default=str) + '\n', encoding='utf-8')
    print(json.dumps(manifest, ensure_ascii=False, indent=2, default=str))
if __name__ == '__main__':
    main()
