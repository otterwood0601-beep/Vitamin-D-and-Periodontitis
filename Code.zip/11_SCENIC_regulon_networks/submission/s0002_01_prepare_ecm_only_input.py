from __future__ import annotations
import json
import math
from pathlib import Path
import anndata as ad
import loompy
import numpy as np
import pandas as pd
import pyarrow.feather as feather
import scipy.sparse as sp
BUNDLE_ROOT = Path(__file__).resolve().parents[2]
RAW = BUNDLE_ROOT / '1.\u6e90\u6570\u636e' / '01_\u539f\u59cb\u8f93\u5165'
H5AD = RAW / '01_CELLxGENE\u6574\u5408\u7259\u5468\u56fe\u8c31' / 'Integrated_Human_Periodontitis_Atlas_105918cells.h5ad'
SELECTED = RAW / '02_GSE164241_ECM\u7ec6\u80de\u7b5b\u9009' / '01_selected_cells_ECM_lineage_Williams_strict_QC.csv'
RESOURCE = RAW / '05_pySCENIC_hg38_v10\u53c2\u8003\u6570\u636e\u5e93'
OUT = BUNDLE_ROOT / '1.\u6e90\u6570\u636e' / '02_SCENIC\u8f93\u5165\u4e0e\u4e2d\u95f4\u7ed3\u679c' / '01_SCENIC\u6a21\u578b\u8f93\u5165'
DB = RESOURCE / 'hg38_500bp_up_100bp_down_full_tx_v10_clust.genes_vs_motifs.rankings.feather'
TF_FILE = RESOURCE / 'allTFs_hg38.txt'
ERK_SETS = OUT / '00_ERK12_gene_sets_from_user_workbook.csv'
MIN_DETECTION_FRACTION = 0.05

def as_csr(x):
    return x.tocsr() if sp.issparse(x) else sp.csr_matrix(np.asarray(x))

def make_symbol_matrix(x: sp.csr_matrix, symbols: np.ndarray, db_genes: set[str]):
    valid = np.asarray([isinstance(g, str) and bool(g) and (g in db_genes) for g in symbols])
    x = x[:, valid]
    symbols = symbols[valid].astype(str)
    unique_symbols, inverse = np.unique(symbols, return_inverse=True)
    mapper = sp.csr_matrix((np.ones(len(inverse), dtype=np.float32), (np.arange(len(inverse)), inverse)), shape=(len(inverse), len(unique_symbols)))
    return ((x @ mapper).tocsr(), unique_symbols, int(len(symbols) - len(unique_symbols)))

def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    selected = pd.read_csv(SELECTED)
    selected = selected[selected['fibroblast_type'].eq('ECM remodeling-associated fibroblasts')].copy()
    selected['h5ad_row'] = selected['h5ad_row'].astype(int)
    selected['condition'] = selected['disease'].replace({'normal': 'Healthy', 'periodontitis': 'Periodontitis'})
    selected['state'] = 'ECM remodeling'
    if set(selected['condition']) != {'Healthy', 'Periodontitis'}:
        raise ValueError('Both Healthy and Periodontitis ECM remodeling cells are required')
    a = ad.read_h5ad(H5AD, backed='r')
    stored_rows = selected['h5ad_row'].to_numpy()
    expected_ids = selected['cell_id'].astype(str).to_numpy()
    offset_scores: dict[int, float] = {}
    for offset in (0, -1):
        candidate = stored_rows + offset
        if candidate.min() >= 0 and candidate.max() < a.n_obs:
            observed = np.asarray(a.obs_names[candidate]).astype(str)
            offset_scores[offset] = float(np.mean(observed == expected_ids))
    if not offset_scores:
        raise IndexError('At least one h5ad_row is outside the source AnnData')
    row_offset = max(offset_scores, key=offset_scores.get)
    rows = stored_rows + row_offset
    observed_ids = np.asarray(a.obs_names[rows]).astype(str)
    if not np.array_equal(observed_ids, expected_ids):
        raise ValueError(f'Cell-ID mismatch: {int(np.sum(observed_ids != expected_ids))} cells')
    raw_x = as_csr(a.raw.X[rows, :]).astype(np.float32)
    symbols = a.raw.var['feature_name'].astype(str).to_numpy()
    umap = np.asarray(a.obsm['X_umap'][rows, :], dtype=np.float32)
    db_schema = feather.read_table(DB, memory_map=True).schema.names
    db_genes = set(db_schema[:-1]) if db_schema[-1] == 'motifs' else set(db_schema)
    x_prefilter, genes_prefilter, collapsed = make_symbol_matrix(raw_x, symbols, db_genes)
    masks = {condition: selected['condition'].eq(condition).to_numpy() for condition in ('Healthy', 'Periodontitis')}
    detected = {}
    for condition, mask in masks.items():
        threshold = max(1, math.ceil(int(mask.sum()) * MIN_DETECTION_FRACTION))
        detected[condition] = np.asarray((x_prefilter[mask, :] > 0).sum(axis=0)).ravel() >= threshold
    keep = detected['Healthy'] | detected['Periodontitis']
    x = x_prefilter[:, keep]
    genes = genes_prefilter[keep]
    tf_universe = {line.strip() for line in TF_FILE.read_text(encoding='utf-8').splitlines() if line.strip()}
    expressed_tfs = sorted(tf_universe.intersection(genes.tolist()))
    (OUT / '01_expressed_TFs_hg38.txt').write_text('\n'.join(expressed_tfs) + '\n', encoding='utf-8')
    cell_meta = selected[['cell_id', 'h5ad_row', 'donor_id', 'sample_id', 'condition', 'state', 'fibroblast_type', 'trajectory_anchor', 'nCount_RNA', 'nFeature_RNA', 'percent_mt']].copy()
    cell_meta['UMAP_1'] = umap[:, 0]
    cell_meta['UMAP_2'] = umap[:, 1]
    cell_meta.to_csv(OUT / '02_ECM_remodeling_cell_metadata_and_umap.csv', index=False)
    gene_audit = pd.DataFrame({'gene': genes, 'detected_cells_Healthy_ECM': np.asarray((x[masks['Healthy'], :] > 0).sum(axis=0)).ravel(), 'detected_cells_Periodontitis_ECM': np.asarray((x[masks['Periodontitis'], :] > 0).sum(axis=0)).ravel(), 'total_counts': np.asarray(x.sum(axis=0)).ravel(), 'is_TF': [gene in tf_universe for gene in genes]})
    gene_audit.to_csv(OUT / '03_filtered_gene_audit.csv', index=False)
    erk_long = pd.read_csv(ERK_SETS)
    primary_mask = erk_long['is_primary_ERK1_ERK2_definition'].astype(str).str.strip().str.lower().eq('true')
    primary_genes = sorted(erk_long.loc[primary_mask, 'gene'].astype(str).str.upper().unique())
    raw_symbol_upper = np.asarray([str(g).upper() for g in symbols])
    present = [gene for gene in primary_genes if np.any(raw_symbol_upper == gene)]
    erk_columns = {}
    for gene in present:
        indices = np.where(raw_symbol_upper == gene)[0]
        erk_columns[gene] = np.asarray(raw_x[:, indices].sum(axis=1)).ravel()
    erk_counts = pd.DataFrame(erk_columns)
    erk_counts.insert(0, 'cell_id', expected_ids)
    erk_counts.to_csv(OUT / '04_ERK1_ERK2_primary_raw_counts_by_cell.csv.gz', index=False, compression='gzip')
    for condition, mask in masks.items():
        safe = condition.lower()
        matrix = x[mask, :].T.tocsc()
        cm = cell_meta.loc[mask].reset_index(drop=True)
        loompy.create(str(OUT / f'{safe}_ECM_remodeling_raw_counts.loom'), matrix, row_attrs={'Gene': genes.astype(str)}, col_attrs={'CellID': cm['cell_id'].astype(str).to_numpy(), 'Condition': cm['condition'].astype(str).to_numpy(), 'State': cm['state'].astype(str).to_numpy(), 'Donor': cm['donor_id'].astype(str).to_numpy(), 'UMAP_1': cm['UMAP_1'].astype(float).to_numpy(), 'UMAP_2': cm['UMAP_2'].astype(float).to_numpy()})
    manifest = {'source_h5ad': H5AD.relative_to(BUNDLE_ROOT).as_posix(), 'selected_metadata': SELECTED.relative_to(BUNDLE_ROOT).as_posix(), 'cell_filter': 'GSE164241/Williams; fibroblast_type == ECM remodeling-associated fibroblasts', 'cells_total': int(len(selected)), 'cells_by_condition': {k: int(v) for k, v in selected['condition'].value_counts().items()}, 'donors_by_condition': {k: int(v) for k, v in selected.groupby('condition')['donor_id'].nunique().items()}, 'genes_after_common_filter': int(len(genes)), 'expressed_TFs': int(len(expressed_tfs)), 'gene_filter': 'detected in >=5% of Healthy ECM or >=5% of Periodontitis ECM and in hg38 cisTarget v10 universe', 'primary_ERK_gene_set': 'GO:0070371 ERK1 and ERK2 cascade', 'primary_ERK_genes_requested': len(primary_genes), 'primary_ERK_genes_present_in_raw_matrix': len(present), 'primary_ERK_genes_missing': sorted(set(primary_genes) - set(present)), 'duplicate_symbols_collapsed': collapsed, 'h5ad_row_offset': int(row_offset), 'raw_counts_used': True, 'conditions_run_independently': True, 'seed': 20260907}
    (OUT / '05_input_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
