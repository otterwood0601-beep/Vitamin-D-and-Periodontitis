from __future__ import annotations
from pathlib import Path
import pandas as pd
from scipy.stats import pearsonr
BUNDLE_ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = BUNDLE_ROOT / '1.\u6e90\u6570\u636e' / '03_\u51fa\u56fe\u6570\u636e\u8868' / '04_\u4f9b\u4f53\u4f2abulk\u76f8\u5173'
INPUT = DATA_DIR / '03_GDF15_MAPK1_MAPK3_ECM_donor_pseudobulk_wide.csv'
OUTPUT = DATA_DIR / '04_\u6392\u9664GDF15\u96f6\u503c\u4f9b\u4f53_Pearson\u654f\u611f\u6027\u5206\u6790.csv'

def summarize(data: pd.DataFrame, target: str, rule: str) -> dict[str, object]:
    result = pearsonr(data['GDF15'], data[target])
    interval = result.confidence_interval(0.95)
    return {'target': target, 'exclusion_rule': rule, 'n': len(data), 'pearson_r': result.statistic, 'p_value': result.pvalue, 'ci95_low': interval.low, 'ci95_high': interval.high}

def main() -> None:
    data = pd.read_csv(INPUT)
    retained = data.loc[data['GDF15'] > 0].copy()
    rows: list[dict[str, object]] = []
    for target in ('MAPK1', 'MAPK3'):
        rows.append(summarize(data, target, 'none'))
        rows.append(summarize(retained, target, 'exclude all donors with GDF15 = 0'))
    pd.DataFrame(rows).to_csv(OUTPUT, index=False)
if __name__ == '__main__':
    main()
