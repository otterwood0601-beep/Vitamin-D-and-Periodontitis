$ErrorActionPreference = 'Stop'

$scriptDir = $PSScriptRoot
$bundleRoot = Split-Path -Parent (Split-Path -Parent $scriptDir)
$sourceRoot = Join-Path $bundleRoot "1.$([char]0x6E90)$([char]0x6570)$([char]0x636E)"

$required = @(
    "1.$([char]0x6E90)$([char]0x6570)$([char]0x636E)\01_$([char]0x539F)$([char]0x59CB)$([char]0x8F93)$([char]0x5165)\01_CELLxGENE$([char]0x6574)$([char]0x5408)$([char]0x7259)$([char]0x5468)$([char]0x56FE)$([char]0x8C31)\Integrated_Human_Periodontitis_Atlas_105918cells.h5ad",
    "1.$([char]0x6E90)$([char]0x6570)$([char]0x636E)\01_$([char]0x539F)$([char]0x59CB)$([char]0x8F93)$([char]0x5165)\02_GSE164241_ECM$([char]0x7EC6)$([char]0x80DE)$([char]0x7B5B)$([char]0x9009)\01_selected_cells_ECM_lineage_Williams_strict_QC.csv",
    "1.$([char]0x6E90)$([char]0x6570)$([char]0x636E)\01_$([char]0x539F)$([char]0x59CB)$([char]0x8F93)$([char]0x5165)\03_ERK1_ERK2$([char]0x901A)$([char]0x8DEF)$([char]0x8868)\ERK-1,2$([char]0x7684)$([char]0x901A)$([char]0x8DEF).xlsx",
    "1.$([char]0x6E90)$([char]0x6570)$([char]0x636E)\01_$([char]0x539F)$([char]0x59CB)$([char]0x8F93)$([char]0x5165)\04_$([char]0x6B63)$([char]0x5F0F)UMAP$([char]0x5750)$([char]0x6807)\Williams$([char]0x5065)$([char]0x5EB7)$([char]0x5168)$([char]0x90E8)1884$([char]0x4E2A)ECM-remodeling$([char]0x7EC6)$([char]0x80DE)_GDF15_OE$([char]0x539F)$([char]0x59CB)$([char]0x503C).csv.gz",
    "1.$([char]0x6E90)$([char]0x6570)$([char]0x636E)\01_$([char]0x539F)$([char]0x59CB)$([char]0x8F93)$([char]0x5165)\04_$([char]0x6B63)$([char]0x5F0F)UMAP$([char]0x5750)$([char]0x6807)\Williams$([char]0x7259)$([char]0x5468)$([char]0x708E)$([char]0x5168)$([char]0x90E8)552$([char]0x4E2A)ECM-remodeling$([char]0x7EC6)$([char]0x80DE)_GDF15_KO$([char]0x539F)$([char]0x59CB)$([char]0x503C).csv.gz",
    "1.$([char]0x6E90)$([char]0x6570)$([char]0x636E)\01_$([char]0x539F)$([char]0x59CB)$([char]0x8F93)$([char]0x5165)\05_pySCENIC_hg38_v10$([char]0x53C2)$([char]0x8003)$([char]0x6570)$([char]0x636E)$([char]0x5E93)\hg38_500bp_up_100bp_down_full_tx_v10_clust.genes_vs_motifs.rankings.feather",
    "1.$([char]0x6E90)$([char]0x6570)$([char]0x636E)\01_$([char]0x539F)$([char]0x59CB)$([char]0x8F93)$([char]0x5165)\05_pySCENIC_hg38_v10$([char]0x53C2)$([char]0x8003)$([char]0x6570)$([char]0x636E)$([char]0x5E93)\hg38_10kbp_up_10kbp_down_full_tx_v10_clust.genes_vs_motifs.rankings.feather",
    "1.$([char]0x6E90)$([char]0x6570)$([char]0x636E)\01_$([char]0x539F)$([char]0x59CB)$([char]0x8F93)$([char]0x5165)\05_pySCENIC_hg38_v10$([char]0x53C2)$([char]0x8003)$([char]0x6570)$([char]0x636E)$([char]0x5E93)\motifs-v10nr_clust-nr.hgnc-m0.001-o0.0.tbl",
    "1.$([char]0x6E90)$([char]0x6570)$([char]0x636E)\01_$([char]0x539F)$([char]0x59CB)$([char]0x8F93)$([char]0x5165)\05_pySCENIC_hg38_v10$([char]0x53C2)$([char]0x8003)$([char]0x6570)$([char]0x636E)$([char]0x5E93)\allTFs_hg38.txt"
)

$missing = foreach ($relativePath in $required) {
    $fullPath = Join-Path $bundleRoot $relativePath
    if (-not (Test-Path -LiteralPath $fullPath -PathType Leaf)) {
        $relativePath
    }
}
if ($missing) {
    throw "Portable bundle is incomplete. Missing files:`n$($missing -join "`n")"
}

$textExtensions = @('.py', '.R', '.ps1', '.txt', '.md', '.json', '.csv')
$runtimeTextFiles = @(
    Get-ChildItem -LiteralPath $scriptDir -File -Recurse -Force
    Get-ChildItem -LiteralPath $sourceRoot -File -Recurse -Force
) | Where-Object { $_.Extension -in $textExtensions }
$eDriveReferences = $runtimeTextFiles | Select-String -Pattern '(?i)E:[\\/]' -ErrorAction Stop
if ($eDriveReferences) {
    $details = $eDriveReferences | ForEach-Object { "$($_.Path):$($_.LineNumber):$($_.Line.Trim())" }
    throw "E-drive dependency detected:`n$($details -join "`n")"
}

$reparsePoints = Get-ChildItem -LiteralPath $bundleRoot -Recurse -Force |
    Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }
if ($reparsePoints) {
    throw "Linked files/directories are not permitted in the portable bundle:`n$($reparsePoints.FullName -join "`n")"
}

Write-Host "PORTABLE_BUNDLE_OK: all required inputs are local to $bundleRoot; no E-drive dependency or reparse point was found."
