$ErrorActionPreference = 'Stop'

$scriptDir = $PSScriptRoot
& (Join-Path $scriptDir '00_preflight_portable_bundle.ps1')

$venvPython = if ($env:SCENIC_PYTHON) { $env:SCENIC_PYTHON } elseif ($env:PYSCENIC_VENV) { Join-Path $env:PYSCENIC_VENV 'Scripts\python.exe' } else { (Get-Command python -ErrorAction Stop).Source }
$rscript = if ($env:R_SCRIPT) { $env:R_SCRIPT } else { (Get-Command Rscript -ErrorAction Stop).Source }

& $venvPython (Join-Path $scriptDir '00_extract_erk12_gene_sets.py')
if ($LASTEXITCODE -ne 0) { throw 'ERK1/2 workbook extraction failed' }
& $venvPython (Join-Path $scriptDir '01_prepare_ecm_only_input.py')
if ($LASTEXITCODE -ne 0) { throw 'ECM-only input preparation failed' }
& (Join-Path $scriptDir '02_run_pyscenic_ecm_only.ps1')
if ($LASTEXITCODE -ne 0) { throw 'ECM-only pySCENIC failed' }
& $venvPython (Join-Path $scriptDir '03_postprocess_modules_and_erk.py')
if ($LASTEXITCODE -ne 0) { throw 'Module and ERK1/2 post-processing failed' }
Push-Location $scriptDir
try {
    & $rscript '.\04_plot_AE_only.R'
    if ($LASTEXITCODE -ne 0) { throw 'A/E figure generation failed' }
}
finally {
    Pop-Location
}

Write-Host 'PIPELINE COMPLETE'
