from __future__ import annotations
import json
from pathlib import Path
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats
BUNDLE_ROOT = Path(__file__).resolve().parents[2]
DATA_OUT = BUNDLE_ROOT / '1.\u6e90\u6570\u636e' / '03_\u51fa\u56fe\u6570\u636e\u8868' / '04_\u4f9b\u4f53\u4f2abulk\u76f8\u5173'
FIG_OUT = BUNDLE_ROOT / '3.\u56fe' / '04_\u4f9b\u4f53\u4f2abulk\u76f8\u5173'
INPUT = DATA_OUT / '01_GDF15_MAPK1_MAPK3_ECM_donor_pseudobulk_log2CPMplus1.csv'
TARGETS = ('MAPK1', 'MAPK3')

def configure_matplotlib() -> None:
    mpl.rcParams.update({'font.family': 'Arial', 'font.size': 13.2, 'axes.titlesize': 17, 'axes.titleweight': 'bold', 'axes.labelsize': 14, 'axes.linewidth': 0.9, 'xtick.labelsize': 11.5, 'ytick.labelsize': 11.5, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'figure.facecolor': 'white', 'savefig.facecolor': 'white'})

def format_p(value: float) -> str:
    if value < 0.001:
        return f'{value:.1e}'
    return f'{value:.2g}'

def regression_with_mean_ci(x: np.ndarray, y: np.ndarray, grid: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    n = len(x)
    x_mean = float(np.mean(x))
    sxx = float(np.sum((x - x_mean) ** 2))
    if n < 3 or sxx <= 0:
        raise ValueError('At least three non-identical donor x-values are required')
    slope, intercept = np.polyfit(x, y, 1)
    fitted = intercept + slope * x
    residual_sd = float(np.sqrt(np.sum((y - fitted) ** 2) / (n - 2)))
    yhat = intercept + slope * grid
    se_mean = residual_sd * np.sqrt(1.0 / n + (grid - x_mean) ** 2 / sxx)
    critical = float(stats.t.ppf(0.975, df=n - 2))
    return (yhat, yhat - critical * se_mean, yhat + critical * se_mean)

def make_plot(wide: pd.DataFrame, target: str, fig_dir: Path) -> tuple[dict, Path, Path]:
    x = wide['GDF15'].to_numpy(float)
    y = wide[target].to_numpy(float)
    if len(x) != 21 or not np.isfinite(np.c_[x, y]).all():
        raise ValueError(f'Invalid donor data for GDF15-{target}')
    pearson = stats.pearsonr(x, y)
    x_span = float(np.ptp(x))
    x_pad = max(0.12, x_span * 0.05)
    grid = np.linspace(float(x.min() - x_pad * 0.15), float(x.max() + x_pad * 0.15), 240)
    yhat, ci_low, ci_high = regression_with_mean_ci(x, y, grid)
    y_span = float(np.ptp(y))
    y_pad = max(0.18, y_span * 0.08)
    x_limits = (float(x.min() - x_pad), float(x.max() + x_pad))
    y_limits = (float(min(y.min(), ci_low.min()) - y_pad), float(max(y.max(), ci_high.max()) + y_pad))
    fig, ax = plt.subplots(figsize=(10.2, 5.3))
    ax.fill_between(grid, ci_low, ci_high, color='#EDEDED', alpha=0.82, linewidth=0, zorder=1)
    ax.plot(grid, yhat, color='#D9A300', linewidth=2.35, zorder=2)
    ax.scatter(x, y, s=72, color='#8E44AD', alpha=0.9, linewidths=0, zorder=3)
    ax.vlines(x, 0.002, 0.026, transform=ax.get_xaxis_transform(), color='#62B44B', alpha=0.78, linewidth=1.0, zorder=4)
    ax.set_xlim(*x_limits)
    ax.set_ylim(*y_limits)
    ax.set_xlabel('GDF15 donor pseudobulk')
    ax.set_ylabel(f'{target} donor pseudobulk')
    ax.set_title(f'GDF15 and {target}', pad=30)
    ax.text(0.5, 1.018, f'R = {pearson.statistic:.3f}, p = {format_p(float(pearson.pvalue))}', transform=ax.transAxes, ha='center', va='bottom', fontsize=15, fontstyle='italic', color='#111111')
    ax.grid(True, which='major', color='#E7E7E7', linewidth=0.8)
    ax.grid(False, which='minor')
    ax.set_axisbelow(True)
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_color('#555555')
        spine.set_linewidth(0.9)
    ax.tick_params(axis='both', colors='#4A4A4A', width=0.9, length=4.0)
    fig.subplots_adjust(left=0.105, right=0.985, bottom=0.17, top=0.79)
    stem = f'GDF15_{target}_ECM\u4f9b\u4f53\u4f2abulk\u76f8\u5173\u56fe'
    pdf = fig_dir / f'{stem}.pdf'
    png = fig_dir / f'{stem}.png'
    fig.savefig(pdf, dpi=300)
    fig.savefig(png, dpi=300)
    plt.close(fig)
    ci = pearson.confidence_interval(confidence_level=0.95)
    result = {'predictor': 'GDF15', 'response': target, 'n_donors': int(len(x)), 'pearson_r': float(pearson.statistic), 'p_value': float(pearson.pvalue), 'pearson_r_ci_low': float(ci.low), 'pearson_r_ci_high': float(ci.high), 'pdf': str(pdf), 'png': str(png)}
    return (result, pdf, png)

def main() -> None:
    configure_matplotlib()
    fig_dir = FIG_OUT
    data_dir = DATA_OUT
    qa_dir = DATA_OUT / 'QA'
    fig_dir.mkdir(parents=True, exist_ok=True)
    data_dir.mkdir(parents=True, exist_ok=True)
    qa_dir.mkdir(parents=True, exist_ok=True)
    long = pd.read_csv(INPUT)
    expected_features = {'GDF15', 'MAPK1', 'MAPK3'}
    if set(long['feature']) != expected_features:
        raise ValueError(f"Unexpected features: {sorted(set(long['feature']))}")
    wide = long.pivot(index=['donor_id', 'condition', 'cells'], columns='feature', values='log2_CPM_plus1').reset_index()
    if len(wide) != 21 or wide['donor_id'].duplicated().any():
        raise ValueError(f'Expected 21 unique donor rows, found {len(wide)}')
    wide.to_csv(data_dir / '03_GDF15_MAPK1_MAPK3_ECM_donor_pseudobulk_wide.csv', index=False)
    results = []
    for target in TARGETS:
        result, _, _ = make_plot(wide, target, fig_dir)
        results.append(result)
    pd.DataFrame(results).drop(columns=['pdf', 'png']).to_csv(data_dir / '02_GDF15_MAPK1_MAPK3_Pearson\u76f8\u5173\u7edf\u8ba1.csv', index=False)
    manifest = {'analysis': 'GDF15-MAPK1/MAPK3 donor-pseudobulk Pearson correlations', 'cell_population': 'GSE164241/Williams ECM-remodeling fibroblasts only', 'observation_grain': 'one point per donor', 'donors': int(len(wide)), 'donors_by_condition': {str(k): int(v) for k, v in wide['condition'].value_counts().items()}, 'value': 'log2(CPM+1) from donor-summed raw gene counts / donor-summed source nCount_RNA', 'statistics': 'pooled two-sided Pearson correlation across donors, matching the reference K-panel convention', 'results': results}
    (qa_dir / '02_correlation_plot_audit.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (DATA_OUT / 'README_\u8bf7\u5148\u770b.md').write_text('Input: GSE164241/Williams ECM-remodeling fibroblasts only.\nObservation grain: one point per donor (n=21; Healthy=13, Periodontitis=8).\nValue: log2(CPM+1) from donor-summed raw gene counts and donor-summed source nCount_RNA.\nStatistics: pooled two-sided Pearson correlation, matching the reference K-panel convention.\nNo cell-level observations were treated as independent replicates.\n', encoding='utf-8')
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
