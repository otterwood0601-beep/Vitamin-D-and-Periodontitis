from __future__ import annotations
import json
from pathlib import Path
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.ticker import MaxNLocator
from PIL import Image, ImageDraw
BUNDLE_ROOT = Path(__file__).resolve().parents[2]
SCENIC = BUNDLE_ROOT / '1.\u6e90\u6570\u636e' / '03_\u51fa\u56fe\u6570\u636e\u8868' / '01_SCENIC\u6a21\u5757\u4e0eERK12\u7edf\u8ba1'
FORMAL = BUNDLE_ROOT / '1.\u6e90\u6570\u636e' / '01_\u539f\u59cb\u8f93\u5165' / '04_\u6b63\u5f0fUMAP\u5750\u6807'
OUT = BUNDLE_ROOT / '3.\u56fe' / '02_\u6a21\u5757\u6d3b\u6027'
DATA_OUT = BUNDLE_ROOT / '1.\u6e90\u6570\u636e' / '03_\u51fa\u56fe\u6570\u636e\u8868' / '02_\u6a21\u5757\u6d3b\u6027'
QA_OUT = DATA_OUT / 'QA'
CONFIG = {'Healthy': {'activity': SCENIC / 'healthy' / '04_cell_module_AUCell_and_ERK12_score.csv', 'coords': FORMAL / 'Williams\u5065\u5eb7\u5168\u90e81884\u4e2aECM-remodeling\u7ec6\u80de_GDF15_OE\u539f\u59cb\u503c.csv.gz', 'modules': ['M1', 'M2', 'M3'], 'out_dir': OUT / '\u5065\u5eb7', 'filename_label': '\u5065\u5eb7_ECM-remodeling', 'figsize': (8.2, 6.4), 'point_size': 6.0}, 'Periodontitis': {'activity': SCENIC / 'periodontitis' / '04_cell_module_AUCell_and_ERK12_score.csv', 'coords': FORMAL / 'Williams\u7259\u5468\u708e\u5168\u90e8552\u4e2aECM-remodeling\u7ec6\u80de_GDF15_KO\u539f\u59cb\u503c.csv.gz', 'modules': ['M1', 'M2', 'M3', 'M4', 'M5'], 'out_dir': OUT / '\u7259\u5468\u708e', 'filename_label': '\u7259\u5468\u708e_ECM-remodeling', 'figsize': (6.2, 8.2), 'point_size': 11.0}}
COLORS = ['#313695', '#4575B4', '#74ADD1', '#FFFFBF', '#F46D43', '#A50026']
CMAP = LinearSegmentedColormap.from_list('module_activity', COLORS, N=256)

def configure_matplotlib() -> None:
    mpl.rcParams.update({'font.family': 'Arial', 'font.size': 11, 'axes.titlesize': 15, 'axes.titleweight': 'bold', 'axes.labelsize': 12, 'axes.linewidth': 1.15, 'xtick.labelsize': 10, 'ytick.labelsize': 10, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'savefig.facecolor': 'white', 'figure.facecolor': 'white'})

def merge_and_validate(condition: str, cfg: dict) -> tuple[pd.DataFrame, dict]:
    act = pd.read_csv(cfg['activity'])
    coord = pd.read_csv(cfg['coords'])
    required_act = {'cell_id', *cfg['modules']}
    required_coord = {'cell_id', 'UMAP_1', 'UMAP_2'}
    missing_act = sorted(required_act - set(act.columns))
    missing_coord = sorted(required_coord - set(coord.columns))
    if missing_act or missing_coord:
        raise ValueError(f'Missing columns: activity={missing_act}, coordinates={missing_coord}')
    if act['cell_id'].duplicated().any() or coord['cell_id'].duplicated().any():
        raise ValueError(f'Duplicate cell IDs found for {condition}')
    merged = act[['cell_id', *cfg['modules']]].merge(coord[['cell_id', 'UMAP_1', 'UMAP_2']], on='cell_id', how='outer', indicator=True)
    join_counts = merged['_merge'].value_counts().to_dict()
    if join_counts.get('left_only', 0) or join_counts.get('right_only', 0):
        raise ValueError(f'Non-matching cells for {condition}: {join_counts}')
    merged = merged.drop(columns='_merge')
    if not np.isfinite(merged[['UMAP_1', 'UMAP_2', *cfg['modules']]].to_numpy()).all():
        raise ValueError(f'Non-finite coordinates or activity found for {condition}')
    audit = {'condition': condition, 'cells': int(len(merged)), 'modules': cfg['modules'], 'cell_join': {k: int(v) for k, v in join_counts.items()}, 'coordinate_source': str(cfg['coords']), 'activity_source': str(cfg['activity']), 'coordinate_ranges': {'UMAP_1': [float(merged['UMAP_1'].min()), float(merged['UMAP_1'].max())], 'UMAP_2': [float(merged['UMAP_2'].min()), float(merged['UMAP_2'].max())]}, 'activity_ranges': {m: {'min': float(merged[m].min()), 'median': float(merged[m].median()), 'max': float(merged[m].max())} for m in cfg['modules']}}
    return (merged, audit)

def plot_one(df: pd.DataFrame, module: str, cfg: dict) -> tuple[Path, Path]:
    cfg['out_dir'].mkdir(parents=True, exist_ok=True)
    values = df[module].to_numpy(float)
    vmin, vmax = (float(values.min()), float(values.max()))
    if vmax <= vmin:
        vmax = vmin + np.finfo(float).eps
    order = np.argsort(values, kind='mergesort')
    x = df['UMAP_1'].to_numpy(float)[order]
    y = df['UMAP_2'].to_numpy(float)[order]
    c = values[order]
    fig, ax = plt.subplots(figsize=cfg['figsize'])
    norm = Normalize(vmin=vmin, vmax=vmax)
    sc = ax.scatter(x, y, c=c, cmap=CMAP, norm=norm, s=cfg['point_size'], linewidths=0, alpha=0.92, rasterized=True)
    ax.set_title(module, pad=10)
    ax.set_xlabel('UMAP 1')
    ax.set_ylabel('UMAP 2')
    ax.set_aspect('equal', adjustable='box')
    ax.grid(False)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.tick_params(axis='both', width=1.1, length=4.5, color='#222222')
    ax.xaxis.set_major_locator(MaxNLocator(nbins=5))
    ax.yaxis.set_major_locator(MaxNLocator(nbins=6))
    cbar = fig.colorbar(sc, ax=ax, fraction=0.052, pad=0.055, aspect=18)
    cbar.ax.set_title(f'{module} activity', fontsize=11, fontweight='normal', pad=8)
    cbar.locator = MaxNLocator(nbins=5)
    cbar.update_ticks()
    cbar.ax.tick_params(width=1.0, length=4)
    cbar.outline.set_linewidth(1.0)
    fig.subplots_adjust(left=0.12, right=0.87, bottom=0.12, top=0.9)
    stem = f"{cfg['filename_label']}_{module}_activity_\u6b63\u5f0fUMAP\u5750\u6807_\u539f\u59cbAUCell"
    pdf = cfg['out_dir'] / f'{stem}.pdf'
    png = cfg['out_dir'] / f'{stem}.png'
    fig.savefig(pdf, dpi=300, bbox_inches='tight', pad_inches=0.08)
    fig.savefig(png, dpi=300, bbox_inches='tight', pad_inches=0.08)
    plt.close(fig)
    return (pdf, png)

def make_contact_sheet(paths: list[Path], out_path: Path, columns: int) -> None:
    images = [Image.open(p).convert('RGB') for p in paths]
    target_w = 720
    thumbs = []
    for im in images:
        scale = target_w / im.width
        thumbs.append(im.resize((target_w, round(im.height * scale)), Image.Resampling.LANCZOS))
    rows = int(np.ceil(len(thumbs) / columns))
    cell_h = max((im.height for im in thumbs))
    margin = 24
    canvas = Image.new('RGB', (columns * target_w + (columns + 1) * margin, rows * cell_h + (rows + 1) * margin), 'white')
    for i, im in enumerate(thumbs):
        r, c = divmod(i, columns)
        x0 = margin + c * (target_w + margin)
        y0 = margin + r * (cell_h + margin)
        canvas.paste(im, (x0, y0))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(out_path, dpi=(180, 180), optimize=True)
    for im in images:
        im.close()

def main() -> None:
    configure_matplotlib()
    OUT.mkdir(parents=True, exist_ok=True)
    DATA_OUT.mkdir(parents=True, exist_ok=True)
    QA_OUT.mkdir(parents=True, exist_ok=True)
    audits = []
    outputs = []
    for condition, cfg in CONFIG.items():
        df, audit = merge_and_validate(condition, cfg)
        df.to_csv(DATA_OUT / f"{cfg['filename_label']}_\u5168\u90e8\u6a21\u5757\u6d3b\u6027\u4e0e\u6b63\u5f0fUMAP\u5750\u6807.csv.gz", index=False)
        pngs = []
        for module in cfg['modules']:
            pdf, png = plot_one(df, module, cfg)
            outputs.append({'condition': condition, 'module': module, 'pdf': str(pdf), 'png': str(png)})
            pngs.append(png)
        make_contact_sheet(pngs, QA_OUT / f"{cfg['filename_label']}_\u6a21\u5757\u6d3b\u6027\u603b\u89c8.png", columns=2)
        audits.append(audit)
    manifest = {'analysis': 'GSE164241 ECM remodeling fibroblast SCENIC module activity on exact formal UMAP coordinates', 'activity_rule': 'original mean module AUCell values; no smoothing, thresholding, clipping, or transformation', 'color_scale_rule': 'full observed raw range independently labeled for each module', 'conditions': audits, 'outputs': outputs}
    (QA_OUT / 'module_activity_UMAP_audit.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
