suppressPackageStartupMessages({
  library(ggplot2)
  library(cowplot)
  library(patchwork)
  library(scales)
})

script_arg <- grep('^--file=', commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- sub('^--file=', '', script_arg[[1]])
script_dir <- dirname(normalizePath(script_path, winslash = '/', mustWork = TRUE))
bundle_root <- normalizePath(file.path(script_dir, '..', '..'), winslash = '/', mustWork = TRUE)
post <- file.path(bundle_root, "1.\u6e90\u6570\u636e", "03_\u51fa\u56fe\u6570\u636e\u8868", "01_SCENIC\u6a21\u5757\u4e0eERK12\u7edf\u8ba1")
figdir <- file.path(bundle_root, "3.\u56fe", "01_SCENIC\u4e3b\u56fe_AE")
dir.create(figdir, recursive = TRUE, showWarnings = FALSE)

tag_panel <- function(plot, tag) {
  cowplot::ggdraw(plot) +
    cowplot::draw_label(tag, x = 0.004, y = 0.995, hjust = 0, vjust = 1,
                        size = 14, fontface = 'bold', colour = '#111111')
}

make_heatmap <- function(key, tag, title) {
  corr <- read.csv(gzfile(file.path(post, key, '01_regulon_TF_correlation_ordered.csv.gz')),
                   row.names = 1, check.names = FALSE)
  bounds <- read.csv(file.path(post, key, '02_module_boundaries.csv'))
  n <- nrow(corr)
  long <- data.frame(
    x = rep(seq_len(n), each = n),
    y = rep(seq_len(n), times = n),
    correlation = as.vector(as.matrix(corr))
  )
  boxes <- transform(bounds,
                     xmin = start - 0.5, xmax = end + 0.5,
                     ymin = n - end + 0.5, ymax = n - start + 1.5,
                     label_x = start, label_y = n - start + 1.2)
  p <- ggplot(long, aes(x, n - y + 1, fill = correlation)) +
    geom_raster(interpolate = FALSE) +
    geom_rect(data = boxes,
              aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax),
              inherit.aes = FALSE, fill = NA, colour = '#E69F00', linewidth = 0.34) +
    geom_text(data = boxes, aes(label_x, label_y, label = module),
              inherit.aes = FALSE, hjust = 0, vjust = 1,
              size = 2.5, fontface = 'bold', colour = '#222222') +
    scale_fill_gradientn(colours = c('#FFFEE8', '#E7E4F2', '#8882BD', '#2F2A7D'),
                         limits = c(-1, 1), oob = squish) +
    coord_fixed(xlim = c(0.5, n + 0.5), ylim = c(0.5, n + 0.5),
                expand = FALSE, clip = 'off') +
    labs(title = title) +
    theme_void(base_family = 'Arial') +
    theme(plot.title = element_text(size = 10, face = 'bold', hjust = 0.5,
                                    margin = margin(b = 5)),
          legend.position = 'none', plot.margin = margin(12, 6, 6, 15))
  tag_panel(p, tag)
}

pA <- make_heatmap('healthy', 'A', 'Healthy ECM remodeling fibroblasts')
pE <- make_heatmap('periodontitis', 'E', 'Periodontitis ECM remodeling fibroblasts')
combined <- pA + pE + plot_layout(ncol = 2, widths = c(1, 1))

pdf_path <- file.path(figdir, 'Figure_SCENIC_ECM_remodeling_only_article_Figure6_matched_A_E.pdf')
png_path <- file.path(figdir, 'Figure_SCENIC_ECM_remodeling_only_article_Figure6_matched_A_E.png')
ggsave(pdf_path, combined, width = 14.2, height = 7.25, units = 'in', device = cairo_pdf)
ggsave(png_path, combined, width = 14.2, height = 7.25, units = 'in', dpi = 600,
       bg = 'white', limitsize = FALSE)
cat('PDF:', pdf_path, '\nPNG:', png_path, '\n')
