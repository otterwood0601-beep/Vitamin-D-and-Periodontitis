from pathlib import Path
import hashlib
import io
import json
import shutil
from pypdf import PdfReader, PdfWriter, PageObject, Transformation
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
HERE = Path(__file__).resolve().parent
ROOT = HERE / 'GMNN_GTEx_sQTL_panels_20261025'
DEST = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u8865\u5145\u56fe\\\u8865\u5145\u56fe2 SMR\u6548\u5e94\u56fe\\GMNN_GTEx\u6210\u7ea4\u7ef4\u7ec6\u80desQTL_20261025')
PUBLIC = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u8f93\u51fa\\20261025_GMNN_GTEx\u6210\u7ea4\u7ef4\u7ec6\u80desQTL_\u7259\u9f88\u51fa\u8840\u6548\u5e94\u56fe')
DEST.mkdir(parents=True, exist_ok=True)
(ROOT / 'final').mkdir(exist_ok=True)
audit = json.loads((ROOT / 'audit.json').read_text(encoding='utf-8'))
receipt = []
for r in audit['results']:
    name = r['outcome']
    a, b = [PdfReader(p).pages[0] for p in r['figures']]
    w, h = (1500, 760)
    page = PageObject.create_blank_page(width=w, height=h)
    left = (45, 55, 930, 650)
    right = (1000, 125, 470, 570)
    placed = []
    for p, (x, y, bw, bh) in [(a, left), (b, right)]:
        pw, ph = (float(p.mediabox.width), float(p.mediabox.height))
        scale = min(bw / pw, bh / ph)
        xx = x + (bw - pw * scale) / 2
        yy = y + (bh - ph * scale) / 2
        page.merge_transformed_page(p, Transformation().scale(scale).translate(xx, yy))
        placed.append([xx, yy, pw * scale, ph * scale])
    layer = io.BytesIO()
    c = canvas.Canvas(layer, pagesize=(w, h))
    c.setFillColor(HexColor('#25364A'))
    c.setFont('Helvetica-Bold', 20)
    label = 'UKB Neale' if 'Neale' in name else 'UKB MRC-IEU'
    c.drawString(45, 731, f'GMNN - bleeding gums ({label})')
    c.setFont('Helvetica', 11)
    c.drawRightString(1470, 733, 'GTEx V8 cultured-fibroblast sQTL')
    c.setFont('Helvetica-Bold', 19)
    c.drawString(19, 700, 'A')
    c.drawString(980, 700, 'B')
    c.showPage()
    c.save()
    layer.seek(0)
    page.merge_page(PdfReader(layer).pages[0])
    target = ROOT / 'final' / f'Figure_GMNN_{name}_GTEx_fibroblast_sQTL_AB.pdf'
    if target.exists() or (DEST / target.name).exists():
        previous = json.loads((ROOT / 'delivery.json').read_text(encoding='utf-8'))
        old = next((x for x in previous if x['outcome'] == name))
        assert hashlib.sha256(target.read_bytes()).hexdigest() == old['sha256']
        assert hashlib.sha256((DEST / target.name).read_bytes()).hexdigest() == old['sha256']
    writer = PdfWriter()
    writer.add_page(page)
    writer.add_metadata({'/Title': f'GMNN - {label} bleeding gums - GTEx fibroblast sQTL', '/Subject': 'A regional associations; B effect-size scatter. Separate GWAS analysis; no pooled SMR.', '/Keywords': 'GMNN; GTEx V8; cultured fibroblasts; sQTL; bleeding gums; SMR'})
    with target.open('wb') as f:
        writer.write(f)
    check = PdfReader(target)
    assert len(check.pages) == 1
    text = check.pages[0].extract_text()
    assert 'GMNN' in text and 'sQTL' in text and ('GWAS effect size' in text)
    shutil.copy2(target, DEST / target.name)
    receipt.append(dict(outcome=name, path=str(DEST / target.name), page_count=1, sha256=hashlib.sha256(target.read_bytes()).hexdigest(), panel_rectangles=placed, n_shared=r['n_shared'], p_SMR=r['p_SMR'], p_HEIDI=r['p_HEIDI']))
(ROOT / 'delivery.json').write_text(json.dumps(receipt, indent=2, ensure_ascii=False), encoding='utf-8')
(ROOT / '\u65b9\u6cd5\u4e0e\u7ed3\u679c\u8bf4\u660e.md').write_text('# GMNN\u6210\u7ea4\u7ef4\u7ec6\u80desQTL\u4e0e\u7259\u9f88\u51fa\u8840\n\n\u672c\u6b21\u91c7\u7528GTEx V8\u57f9\u517b\u6210\u7ea4\u7ef4\u7ec6\u80desQTL\uff0c\u4e0d\u662fMcRae\u7532\u57fa\u5316QTL\uff0c\u4e5f\u4e0d\u662f\u7259\u9f88\u7279\u5f02\u6210\u7ea4\u7ef4\u7ec6\u80de\u6570\u636e\u3002\n\u4f7f\u7528\u73b0\u884c\u7a3f\u4ef6\u6807\u51c6\u5df2\u5b8c\u6210\u7684SMR\u7ed3\u679c\uff08\u4e3bQTL P<0.0016\uff0cF>=10\uff0cHEIDI QTL P<=0.00157\uff09\u3002\n\u56fa\u5b9a\u9009\u62e9GMNN\u4e24\u4e2a\u526a\u63a5\u8fde\u63a5\u4e2dQTL\u4fe1\u53f7\u8f83\u5f3a\u7684chr6:24775112:24777222:clu_28328:ENSG00000112312.9\uff0c\u4e24\u7ed3\u5c40\u4e00\u81f4\uff0c\u4e0d\u6309\u7ed3\u5c40P\u503c\u6311\u9009\u3002\n\u56feA\u4e3a\u57fa\u56e0\u4f4d\u7f6e\xb11Mb\u7684GWAS\u4e0e\u76ee\u6807sQTL\u533a\u57df\u5173\u8054\u53ca\u57fa\u56e0\u8f68\u8ff9\uff0c\u56feB\u4e3a\u5171\u4eab\u4f4d\u70b9\u6548\u5e94\u53caSMR\u659c\u7387\u3002\u590d\u7528\u539f\u56fe\u7ed8\u56fe\u51fd\u6570\u3001\u5b57\u4f53\u3001\u914d\u8272\u548c\u8bef\u5dee\u68d2\u3002\n\u4e3aWindows\u6587\u4ef6\u540d\u5408\u6cd5\u6027\uff0c\u4ec5\u5728\u590d\u5236\u7684\u63a2\u9488\u6ce8\u91ca\u4e2d\u8bbe\u7f6e\u5b89\u5168\u522b\u540d\uff0cBESD\u548cESI\u6570\u503c\u672a\u6539\u52a8\u3002\nGWAS\u6765\u81ea\u672c\u5730\u539f\u59cbVCF\u6309GRCh37\u533a\u95f4\u63d0\u53d6\uff0c\u57fa\u56e0\u8f68\u8ff9\u6765\u81eaUCSC hg19 ncbiRefSeq\u3002GENCORD\u4e0d\u5728\u672c\u6b21\u8303\u56f4\u3002\nGTEx\u672c\u5730\u4e3alite\u9762\u677f\uff0c\u53ea\u542b\u4fdd\u7559\u7684QTL\u5173\u8054\uff0c\u4e0d\u4ee3\u8868\u5168\u90e8\u672a\u7b5b\u9009\u533a\u57dfQTL\u3002\n\n## \u7ed3\u679c\n\n- UKB Neale\uff1aSMR beta=0.00195661\uff0cP=0.7295564\uff1bHEIDI P=0.9486761\uff1b91\u4e2a\u5171\u4eab\u4f4d\u70b9\u3002\n- UKB MRC-IEU\uff1aSMR beta=0.00330635\uff0cP=0.2617026\uff1b\u4ec51\u4e2a\u5171\u4eab\u4f4d\u70b9\uff0c\u65e0\u6cd5\u4f30\u8ba1HEIDI\u3002\n- \u4e24\u8005\u5747\u672a\u8fbe\u5230SMR P<0.05/11\u3002\u7f3a\u5931HEIDI\u4e0d\u89c6\u4e3a\u901a\u8fc7\u3002\n- \u4e24\u5957GWAS\u5747\u6765\u81eaUK Biobank\uff0c\u5b58\u5728\u6837\u672c\u91cd\u53e0\uff1b\u672c\u6b21\u5206\u522b\u51fa\u56fe\uff0c\u6ca1\u6709\u5408\u5e76\u6548\u5e94\uff0c\u4e5f\u4e0d\u4f5c\u4e3a\u72ec\u7acb\u961f\u5217\u9a8c\u8bc1\u3002\n- GWAS\u6cbf\u7528\u539f\u59cbbeta\u5355\u4f4d\uff0c\u672a\u64c5\u81ea\u6807\u4e3alog odds\u3002\u4e3bQTL\u5f3a\u3001\u4f46SMR\u4e0d\u663e\u8457\uff0c\u4e24\u8005\u4e0d\u6df7\u6dc6\u3002\n\n\u6700\u7ec8\u6309\u7528\u6237\u8981\u6c42\uff0c\u4e24\u5f20\u6574\u56fe\u5206\u522b\u5bf9\u5e94Neale\u548cMRC-IEU\uff0c\u6bcf\u5f20\u5305\u542bA\u3001B\u4e24\u4e2a\u5b50\u56fe\u3002\u6240\u6709\u65e7\u56fe\u4fdd\u7559\u3002\n', encoding='utf-8')
for script in ['build_gmnn_sqtl_panels_20261025.py', 'assemble_gmnn_two_cohort_figures_20261025.py']:
    (ROOT / 'code').mkdir(exist_ok=True)
    shutil.copy2(HERE / script, ROOT / 'code' / script)
shutil.copytree(ROOT, PUBLIC, dirs_exist_ok=True)
print(json.dumps(receipt, indent=2, ensure_ascii=False))
