options(stringsAsFactors = FALSE)

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1L) {
  stop("Usage: Rscript 01_render_volcano_46_valid_genes.R <output_pdf>")
}

output_pdf <- normalizePath(args[[1]], winslash = "/", mustWork = FALSE)
if (file.exists(output_pdf)) {
  stop("Refusing to overwrite an existing output: ", output_pdf)
}

script_arg <- commandArgs(trailingOnly = FALSE)
script_path <- sub("^--file=", "", script_arg[grepl("^--file=", script_arg)][1])
script_dir <- dirname(script_path)
volcano_path <- file.path(script_dir, "05_C_volcano_source_data.csv")
heatmap_path <- file.path(script_dir, "04_B_46_genes_source.csv")

.libPaths(c(
  "G:/\u8840\u6e05\u7ef4\u751f\u7d20/E\u76d8\u7cbe\u7b80\u5f52\u6863_20260908_v2/E\u76d8\u539f\u76f8\u5bf9\u7ed3\u6784/\u4ee3\u7801/\u8fd0\u884c\u73af\u5883/R_library_enrichment",
  "C:/Users/Lin/AppData/Local/R/win-library/4.5",
  .libPaths()
))

suppressPackageStartupMessages({
  library(ggplot2)
  library(ggrepel)
  library(jsonlite)
})

volcano <- read.csv(volcano_path, check.names = FALSE)
heatmap <- read.csv(heatmap_path, check.names = FALSE)

required_volcano <- c(
  "gene_id", "gene_symbol", "log2FoldChange", "padj", "minus_log10_fdr"
)
if (!all(required_volcano %in% names(volcano))) {
  stop("Volcano source is missing required columns")
}
if (!"gene_symbol" %in% names(heatmap)) {
  stop("Heatmap source is missing gene_symbol")
}

valid_symbols <- unique(heatmap$gene_symbol[
  !is.na(heatmap$gene_symbol) & nzchar(trimws(heatmap$gene_symbol))
])
if (length(valid_symbols) != 46L) {
  stop("Expected exactly 46 valid heatmap gene symbols; found ", length(valid_symbols))
}

volcano$log2FoldChange <- as.numeric(volcano$log2FoldChange)
volcano$padj <- as.numeric(volcano$padj)
volcano$minus_log10_fdr <- as.numeric(volcano$minus_log10_fdr)
volcano <- volcano[
  is.finite(volcano$log2FoldChange) & is.finite(volcano$minus_log10_fdr),
  ,
  drop = FALSE
]

selected <- volcano[
  !is.na(volcano$gene_symbol) & volcano$gene_symbol %in% valid_symbols,
  ,
  drop = FALSE
]
if (nrow(selected) != 46L || length(unique(selected$gene_symbol)) != 46L) {
  stop("The volcano table did not match the heatmap's 46 symbols one-to-one")
}
if (any(selected$padj >= 0.05 | abs(selected$log2FoldChange) < 1)) {
  stop("At least one selected gene fails FDR < 0.05 and abs(log2FC) >= 1")
}

volcano$plot_group <- "Not significant"
volcano$plot_group[
  !is.na(volcano$gene_symbol) & volcano$gene_symbol %in% valid_symbols &
    volcano$log2FoldChange < 0
] <- "Down"
volcano$plot_group[
  !is.na(volcano$gene_symbol) & volcano$gene_symbol %in% valid_symbols &
    volcano$log2FoldChange > 0
] <- "Up"
volcano$plot_group <- factor(
  volcano$plot_group,
  levels = c("Down", "Not significant", "Up")
)

volcano$foreground <- volcano$plot_group != "Not significant"
volcano <- volcano[order(volcano$foreground), , drop = FALSE]

up_n <- sum(selected$log2FoldChange > 0)
down_n <- sum(selected$log2FoldChange < 0)
stopifnot(up_n == 33L, down_n == 13L, up_n + down_n == 46L)

x_limit <- 8
y_limit <- 60
x_breaks <- c(-8, -4, 0, 4, 8)
y_breaks <- c(0, 10, 20, 30, 40, 50, 60)

volcano$plot_x <- volcano$log2FoldChange
volcano$plot_y <- volcano$minus_log10_fdr
volcano$boundary_repositioned <- FALSE

selected_offscale <- (
  volcano$foreground &
    (abs(volcano$log2FoldChange) > x_limit |
       volcano$minus_log10_fdr > y_limit)
)
offscale_rows <- which(selected_offscale)
if (length(offscale_rows) != 1L) {
  stop("Expected 1 off-scale gene among the 46; found ", length(offscale_rows))
}
offscale_order <- offscale_rows[
  order(
    volcano$log2FoldChange[offscale_rows],
    volcano$minus_log10_fdr[offscale_rows]
  )
]
volcano$plot_x[offscale_order] <- 7.65
volcano$plot_y[offscale_order] <- 59.20
volcano$boundary_repositioned[offscale_order] <- TRUE

gdf15 <- volcano[
  !is.na(volcano$gene_symbol) & volcano$gene_symbol == "GDF15",
  ,
  drop = FALSE
]

figure_c <- ggplot(
  volcano,
  aes(x = plot_x, y = plot_y)
) +
  geom_point(aes(colour = plot_group), alpha = 0.64, size = 1.35) +
  geom_vline(
    xintercept = c(-1, 1),
    linetype = "dashed",
    colour = "#666666",
    linewidth = 0.45
  ) +
  geom_hline(
    yintercept = -log10(0.05),
    linetype = "dashed",
    colour = "#666666",
    linewidth = 0.45
  ) +
  geom_text_repel(
    data = gdf15,
    aes(x = log2FoldChange, y = minus_log10_fdr, label = gene_symbol),
    seed = 212728,
    colour = "#111111",
    size = 3.3,
    min.segment.length = 0,
    segment.colour = "#111111",
    segment.size = 0.45,
    box.padding = 0.25,
    point.padding = 0.25,
    nudge_x = -1.2,
    nudge_y = 4.0,
    max.overlaps = Inf,
    show.legend = FALSE
  ) +
  scale_colour_manual(
    values = c(
      "Down" = "#2C7BB6",
      "Not significant" = "#B9B9B9",
      "Up" = "#D7191C"
    ),
    breaks = c("Down", "Not significant", "Up"),
    labels = c(
      sprintf("Down (n=%d)", down_n),
      "Not significant",
      sprintf("Up (n=%d)", up_n)
    ),
    drop = FALSE
  ) +
  scale_x_continuous(breaks = x_breaks) +
  scale_y_continuous(breaks = y_breaks) +
  coord_cartesian(
    xlim = c(-x_limit, x_limit),
    ylim = c(0, y_limit),
    expand = FALSE,
    clip = "on"
  ) +
  labs(
    x = "log2 fold change",
    y = "-log10(FDR)",
    colour = NULL
  ) +
  theme_bw(base_size = 11) +
  guides(
    colour = guide_legend(
      nrow = 1,
      byrow = TRUE,
      override.aes = list(size = 2)
    )
  ) +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(colour = "#ECECEC", linewidth = 0.3),
    panel.border = element_rect(colour = "#444444", linewidth = 0.5),
    axis.text = element_text(colour = "#333333"),
    axis.title = element_text(colour = "#111111"),
    legend.position = "top",
    legend.direction = "horizontal",
    legend.text = element_text(size = 7.5),
    legend.key.width = grid::unit(0.32, "cm"),
    legend.spacing.x = grid::unit(0.05, "cm"),
    legend.margin = margin(0, 0, 0, 0),
    plot.margin = margin(10, 14, 10, 10)
  )

dir.create(dirname(output_pdf), recursive = TRUE, showWarnings = FALSE)
preview_png <- file.path(script_dir, "C_volcano_46_valid_genes_preview.png")
ggsave(
  output_pdf,
  figure_c,
  width = 4,
  height = 5,
  device = cairo_pdf,
  bg = "white"
)
ggsave(
  preview_png,
  figure_c,
  width = 4,
  height = 5,
  dpi = 360,
  bg = "white"
)

selected$display_direction <- ifelse(selected$log2FoldChange > 0, "Up", "Down")
selected$boundary_repositioned <- (
  abs(selected$log2FoldChange) > x_limit |
    selected$minus_log10_fdr > y_limit
)
selected <- selected[order(selected$display_direction, selected$padj), , drop = FALSE]
write.csv(
  selected,
  file.path(script_dir, "C_volcano_46_coloured_genes.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

audit <- list(
  status = "completed",
  output_pdf = output_pdf,
  rule = "Only the 46 valid gene symbols displayed in heatmap B are colored",
  thresholds = list(abs_log2FC = 1, BH_FDR = 0.05),
  coloured_total = 46,
  coloured_up = up_n,
  coloured_down = down_n,
  naturally_inside_panel = 45,
  repositioned_to_upper_boundary = 1,
  displayed_coloured_points = 46,
  all_coloured_points_visible = TRUE,
  x_limits = c(-x_limit, x_limit),
  y_limits = c(0, y_limit),
  original_pdf_preserved = TRUE,
  generated_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %z")
)
write_json(
  audit,
  file.path(script_dir, "00_volcano_46_valid_genes_audit.json"),
  auto_unbox = TRUE,
  pretty = TRUE,
  digits = 12
)

cat(sprintf(
  "OUTPUT=%s\nCOLOURED=46 UP=%d DOWN=%d XLIM=+/-%.0f YMAX=%.0f\n",
  output_pdf,
  up_n,
  down_n,
  x_limit,
  y_limit
))
