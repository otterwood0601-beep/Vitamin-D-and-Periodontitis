from pathlib import Path
import sys, shutil, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
from PIL import Image
import fitz
from style_npj import set_npj_style, save_npj, NPJ_CTRL, NPJ_CASE
ROOT = Path(__file__).resolve().parents[1]
if ROOT.name == 'GSE118691_GDF15\u708e\u75c7\u523a\u6fc0_AB_20261008':
    OUT = ROOT
else:
    OUT = ROOT / 'output' / 'GSE118691_GDF15\u708e\u75c7\u523a\u6fc0_AB_20261008'
SOURCE = OUT / 'source_data'
FIGURES = OUT / 'figures'
CODE = OUT / 'code'
TIMES = [2, 6, 12, 24, 48]

def prepare():
    for p in [SOURCE, FIGURES, CODE]:
        p.mkdir(parents=True, exist_ok=True)
    if ROOT != OUT:
        previous = ROOT / 'output' / 'GDF15_\u6210\u7ea4\u7ef4\u7ec6\u80de\u708e\u75c7\u523a\u6fc0_\u4e09\u961f\u5217_20261008' / 'source_data'
        names = [f'expression_GSE118691 {t}.csv' for t in TIMES]
        names += ['GSE118691_sample_manifest.csv', 'GSE118691_time_label_disagreements.csv', '02_GDF15_all_primary_results.csv', '03_GSE118691_title_based_sensitivity.csv', '05_R_sessionInfo.txt', '07_verification.json', '01_raw_file_SHA256.json']
        for name in names:
            shutil.copy2(previous / name, SOURCE / name)
        stage = Path('C:/Users/Lin/AppData/Local/Temp/gdf15_stim_20261008')
        shutil.copy2(stage / 'GSE118691_figure_model_intervals.csv', SOURCE)
        for name in ['d14_plot_gse118691_gdf15_20261008.py', 'd14_gse118691_figure_intervals_20261008.R', 'style_npj.py', 'd13_analyze_gdf15_stimulation_20261008.R']:
            shutil.copy2(ROOT / 'code' / name, CODE / name)

def header(fig, ax, letter, title):
    pos = ax.get_position()
    fig.add_artist(Rectangle((pos.x0, 0.83), pos.width, 0.047, transform=fig.transFigure, facecolor='#E4E6EB', edgecolor='none'))
    fig.text(pos.x0 + pos.width / 2, 0.8535, title, ha='center', va='center', fontsize=8, fontweight='bold')
    fig.text(pos.x0 - 0.038, 0.852, letter, ha='left', va='center', fontsize=13, fontweight='bold')

def main():
    prepare()
    effects = pd.read_csv(SOURCE / 'GSE118691_figure_model_intervals.csv').set_index('time_h')
    pieces = []
    for t in TIMES:
        d = pd.read_csv(SOURCE / f'expression_GSE118691 {t}.csv')
        d['time_h'] = t
        pieces.append(d)
    data = pd.concat(pieces, ignore_index=True)
    data.to_csv(SOURCE / 'GSE118691_plotted_samples.csv', index=False, encoding='utf-8-sig')
    assert len(data) == 44 and data.GSM.nunique() == 44
    assert data.donor.nunique() == 5
    assert np.allclose(data.GDF15_logFPKM, np.log2(data.GDF15_FPKM + 0.5))
    for t in TIMES:
        pair = data[data.time_h == t].pivot(index='donor', columns='condition', values='GDF15_logFPKM')
        assert not pair.isna().any().any()
        assert len(pair) == effects.loc[t, 'n_pairs']
        assert np.isclose((pair.Fn - pair.ctrl).mean(), effects.loc[t, 'log2FC'])
    set_npj_style()
    fig = plt.figure(figsize=(180 / 25.4, 112 / 25.4))
    a = fig.add_axes([0.085, 0.335, 0.465, 0.455])
    b = fig.add_axes([0.675, 0.335, 0.285, 0.455])
    header(fig, a, 'A', 'GDF15 in gingival fibroblasts')
    header(fig, b, 'B', 'Change relative to control')
    colors = {'ctrl': NPJ_CTRL, 'Fn': NPJ_CASE}
    donors = ['B', 'C', 'D', 'E', 'F']
    offsets = dict(zip(donors, [-0.034, -0.017, 0, 0.017, 0.034]))
    for i, t in enumerate(TIMES):
        d = data[data.time_h == t]
        pair = d.pivot(index='donor', columns='condition', values='GDF15_logFPKM')
        for donor, row in pair.iterrows():
            off = offsets[donor]
            a.plot([i - 0.18 + off, i + 0.18 + off], [row.ctrl, row.Fn], color='#BABDC3', lw=0.65, zorder=1)
        for cond, x in [('ctrl', i - 0.18), ('Fn', i + 0.18)]:
            vals = d[d.condition == cond].sort_values('donor')
            bp = a.boxplot(vals.GDF15_logFPKM, positions=[x], widths=0.24, manage_ticks=False, patch_artist=True, showfliers=False, whis=(0, 100), boxprops={'facecolor': colors[cond], 'edgecolor': colors[cond], 'alpha': 0.17, 'linewidth': 0.7}, medianprops={'color': colors[cond], 'linewidth': 1}, whiskerprops={'color': colors[cond], 'linewidth': 0.7}, capprops={'color': colors[cond], 'linewidth': 0.7})
            a.scatter([x + offsets[z] for z in vals.donor], vals.GDF15_logFPKM, s=15, color=colors[cond], edgecolors='white', linewidths=0.35, zorder=3)
        top = d.GDF15_logFPKM.max() + 0.28
        a.plot([i - 0.24, i - 0.24, i + 0.24, i + 0.24], [top - 0.08, top, top, top - 0.08], color='#444444', lw=0.65)
        q = effects.loc[t, 'GDF15_9_comparison_FDR']
        a.text(i, top + 0.045, '***' if q < 0.001 else 'ns', ha='center', va='bottom', fontsize=8)
    a.set_xlim(-0.55, 4.55)
    a.set_ylim(1.9, max(data.GDF15_logFPKM.max() + 0.85, 8.25))
    a.set_xticks(range(5), [f"{t} h\n{int(effects.loc[t, 'n_pairs'])} pairs" for t in TIMES])
    a.set_yticks([2, 3, 4, 5, 6, 7, 8])
    a.set_ylabel('GDF15 expression [log2(FPKM + 0.5)]')
    a.set_xlabel('Time after stimulation', labelpad=7)
    handles = [Line2D([0], [0], marker='o', color='none', markerfacecolor=colors[c], markeredgecolor='white', markersize=4.5, label=label) for c, label in [('ctrl', 'Control'), ('Fn', 'F. nucleatum')]]
    a.legend(handles=handles, frameon=False, loc='upper left', bbox_to_anchor=(-0.02, 1.005), ncol=2, columnspacing=0.8, handletextpad=0.2, borderaxespad=0)
    for i, t in enumerate(TIMES):
        e = effects.loc[t]
        c = NPJ_CASE if e.GDF15_9_comparison_FDR < 0.05 else '#707780'
        b.errorbar(e.fold_change, i, xerr=[[e.fold_change - e.fold_CI_low], [e.fold_CI_high - e.fold_change]], fmt='o', color=c, markersize=4.5, lw=1.1, capsize=2.5, capthick=0.8)
        b.text(e.fold_CI_high + 0.32, i, f'{e.fold_change:.2f}\xd7', va='center', fontsize=7.5, color=c)
    b.axvline(1, color='#A6A6AC', ls=(0, (3, 3)), lw=0.8, zorder=0)
    b.set_xlim(0, 14.6)
    b.set_ylim(4.6, -0.6)
    b.set_xticks([0, 1, 4, 8, 12])
    b.set_yticks(range(5), [f'{t} h' for t in TIMES])
    b.set_xlabel('GDF15 fold change (95% CI)', labelpad=8)
    b.text(0.98, 0.98, '1\xd7 = no change', ha='right', va='top', transform=b.transAxes, fontsize=7, color='#555555')
    for ax in [a, b]:
        ax.spines[['top', 'right']].set_visible(False)
        ax.tick_params(length=2.5, width=0.5)
    fig.text(0.085, 0.175, 'GSE118691 | Primary human gingival fibroblasts | F. nucleatum, MOI 100', fontsize=7.1)
    fig.text(0.085, 0.135, 'A: dots are donor cultures; lines join matched controls and stimulated cultures. B: paired model estimates and 95% CI.', fontsize=6.8)
    fig.text(0.085, 0.1, 'Paired limma; *** FDR < 0.001; ns, not significant. FDR retains all 9 original GDF15 comparisons across 3 datasets.', fontsize=6.8)
    fig.text(0.085, 0.065, 'Two samples with conflicting early time labels excluded; one 12 h pair unavailable. Experimental stimulation, 5 donors.', fontsize=6.8)
    stem = FIGURES / 'GSE118691_GDF15_AB'
    save_npj(fig, str(stem), width_mm=180, height_mm=112, dpi=600)
    fig.savefig(FIGURES / 'GSE118691_GDF15_AB_preview.png', dpi=220)
    plt.close(fig)
    pdf = fitz.open(str(stem) + '.pdf')
    page = pdf[0]
    page.get_pixmap(matrix=fitz.Matrix(2.5, 2.5), alpha=False).save(FIGURES / 'GSE118691_GDF15_AB_PDF_QA.png')
    outside = []
    for block in page.get_text('dict')['blocks']:
        for line in block.get('lines', []):
            for span in line['spans']:
                rect = fitz.Rect(span['bbox'])
                if not page.rect.contains(rect):
                    outside.append(span['text'])
    assert not outside, outside
    fonts = sorted({f[3] for f in page.get_fonts()})
    with Image.open(str(stem) + '.png') as im:
        size = list(im.size)
        dpi = list(im.info.get('dpi', []))
    qa = {'status': 'PASS', 'timepoints_h': TIMES, 'samples': 44, 'unique_donors': 5, 'paired_cultures_per_time': effects.n_pairs.astype(int).tolist(), 'all_sample_values_and_model_effects_verified': True, 'PDF_text_outside_page': outside, 'PDF_font_names': fonts, 'PNG_pixels': size, 'PNG_dpi': dpi, 'visual_review': 'pending'}
    (SOURCE / 'figure_QA.json').write_text(json.dumps(qa, indent=2), encoding='utf-8')
    paragraphs = ['GSE118691\uff1a\u4eba\u539f\u4ee3\u7259\u9f88\u6210\u7ea4\u7ef4\u7ec6\u80de\uff0c\u5177\u6838\u68ad\u6746\u83cc\u523a\u6fc0\uff08MOI 100\uff09\u4e0e\u540c\u4f9b\u8005\u672a\u523a\u6fc0\u5bf9\u7167\u3002', 'A\uff1a\u9010\u4f9b\u8005\u5c55\u793a\u5168\u90e8\u4e94\u4e2a\u65f6\u95f4\u70b9\u30022\u30016\u5c0f\u65f6\u4e0d\u663e\u8457\uff1b12\u300124\u300148\u5c0f\u65f6GDF15\u5347\u9ad8\u3002\u914d\u5bf9\u7ebf\u53ea\u8fde\u63a5\u540c\u65f6\u95f4\u540c\u4f9b\u8005\uff1b\u65f6\u95f4\u70b9\u4e4b\u95f4\u4e3a\u540c\u4e00\u6279\u4f9b\u8005\u91cd\u590d\u6d4b\u91cf\u3002', 'B\uff1a\u914d\u5bf9\u6a21\u578b\u53d8\u5316\u53ca95%\u7f6e\u4fe1\u533a\u95f4\u30022/6/12/24/48\u5c0f\u65f6\u5206\u522b\u4e3a0.96/1.12/3.77/10.60/8.69\u500d\u3002B\u5c5e\u4e8e\u523a\u6fc0\u6548\u5e94\u56fe\uff0c\u4e0d\u662f\u539f\u6765\u7684\u7ec4\u7ec7\u7ec6\u80de\u6bd4\u4f8b\u6821\u6b63\u56fe\u3002', '\u6570\u636e\u4e3aFPKM\uff0c\u4e0d\u662f\u539f\u59cb\u6574\u6570\u8ba1\u6570\u3002\u6a21\u578b\uff1alog2(FPKM+0.5)\uff0c\u4f9b\u8005\u914d\u5bf9limma\uff0ctrend/robust\uff1b\u7f6e\u4fe1\u533a\u95f4\u6765\u81ea\u540c\u4e00\u6a21\u578b\u3002\u500d\u6570\u4e3a\u8be5\u53d8\u6362\u540e\u7684\u914d\u5bf9\u5dee\u503c\u53d62\u7684\u6307\u6570\uff0c\u5e76\u975e\u76f4\u63a5\u8ba1\u7b97\u5e73\u5747FPKM\u6bd4\u503c\u3002', '\u663e\u8457\u6027\u4fdd\u7559\u539f\u4e09\u6570\u636e\u96c6\u5168\u90e89\u9879GDF15\u6bd4\u8f83\u7684BH\u6821\u6b63\uff0c\u672a\u5728\u9009\u51fa\u672c\u6570\u636e\u96c6\u540e\u91cd\u65b0\u7f29\u5c0f\u6821\u6b63\u8303\u56f4\u300212/24/48\u5c0f\u65f6FDR\u5206\u522b\u4e3a0.000150\u30012.18e-10\u30011.11e-9\u3002', '5\u4f4d\u4f9b\u8005\uff0c\u4e3b\u5206\u67902/6/12\u5c0f\u65f6\u54044\u5bf9\uff0c24/48\u5c0f\u65f6\u54045\u5bf9\uff0c\u517144\u4efd\u57f9\u517b\u6837\u672c\u3002GSM3336696\u548cGSM3336698\u65f6\u95f4\u63cf\u8ff0\u76f8\u51b2\u7a81\uff0c\u6392\u9664\uff1bF12F\u7f3a\u5931\u3002\u6807\u9898\u5206\u7ec4\u654f\u611f\u6027\u7ed3\u679c\u4ecd\u4e3a\u65e9\u671f\u4e0d\u663e\u8457\u3001\u540e\u671f\u5347\u9ad8\u3002', '\u7ed3\u8bba\u4ec5\u652f\u6301\u8fd9\u4e2a\u7ec6\u83cc\u523a\u6fc0\u5b9e\u9a8c\u7684\u540e\u671f\u5347\u9ad8\uff0c\u4e0d\u80fd\u636e\u6b64\u58f0\u79f0\u6240\u6709\u708e\u75c7\u72b6\u6001\u5747\u5347\u9ad8\uff0c\u6216\u8bc1\u660e\u7259\u5468\u708e\u6574\u5757\u7ec4\u7ec7\u7684GDF15\u5347\u9ad8\u7531\u6210\u7ea4\u7ef4\u7ec6\u80de\u6bd4\u4f8b\u5bfc\u81f4\u3002\u5df2\u68c0\u67e5\u7684\u5176\u4ed6\u523a\u6fc0\u6570\u636e\u96c6\u51fa\u73b0\u4e0b\u964d\uff0c\u4e0d\u80fd\u5ffd\u7565\u3002', '\u6765\u6e90\uff1ahttps://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE118691', '\u91cd\u65b0\u51fa\u56fe\uff1a\u4f7f\u7528\u9644\u5e26code/d14_plot_gse118691_gdf15_20261008.py\u53casource_data\u5185\u51bb\u7ed3\u7ed3\u679c\u5373\u53ef\uff1b\u533a\u95f4\u6062\u590d\u811a\u672c\u548c\u539f\u914d\u5bf9\u5206\u6790\u811a\u672c\u4e00\u5e76\u9644\u5e26\u3002']
    (OUT / '\u56fe\u8bf4\u660e_20261008.txt').write_text('\n\n'.join(paragraphs), encoding='utf-8-sig')
    print(json.dumps({'output': str(OUT), 'QA': qa}, ensure_ascii=False))
if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    main()
