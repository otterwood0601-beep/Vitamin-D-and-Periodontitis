.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(ggplot2)})
root <- 'C:/wb_links/panel456_20261008'
out <- file.path(root,'module_specific_20261009/six_modules_no_detection')
sel <- fread(file.path(out,'selected_genes.csv'))
targets <- fread(file.path(out,'module_selection_summary.csv'))
d <- fread(file.path(out,'plot_data.csv'))
genes <- sel$gene
mods <- targets$module
types <- c('Pre-extracellular matrix-associated fibroblasts','ECM remodeling-associated fibroblasts','Vascular-associated fibroblasts','Matrix homeostasis-associated fibroblasts','Immune-associated fibroblasts')
short <- c('Pre-ECM','ECM remodeling','Vascular','Matrix homeostasis','Immune')

code <- readLines(file.path(root,'plot_module_specific_six_no_detection_20261009.R'))
start <- which(startsWith(code,'d[,celltype:=factor'))
end <- which(startsWith(code,'tmp <-'))-1L
stopifnot(length(start)==1L,length(end)==1L,nrow(d)==170L,length(mods)==6L)
eval(parse(text=code[start:end]))
dest <- 'C:/Users/Lin/AppData/Local/Temp/Fig4K_hdWGCNA_six_modules_specific_genes_20261009.pdf'
stopifnot(!file.exists(dest))
cairo_pdf(dest,width=1400/230,height=2350/230,family='Arial',bg='white')
print(p)
dev.off()
cat(dest,'\n')
