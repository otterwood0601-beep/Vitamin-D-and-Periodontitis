from pathlib import Path
import fitz, json, hashlib
aux = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008\\\u5176\u4ed6')
src = Path('C:\\Users\\Lin\\AppData\\Local\\Temp\\F_vector_schematic_base_20261009.pdf')
d = fitz.open(src)
w, h = (d[0].rect.width, d[0].rect.height)
cw, ch = (w / 3, h / 2)
gapx, gapy, margin = (8, 10, 4)
out = fitz.open()
p = out.new_page(width=w + 2 * gapx + 2 * margin, height=h + gapy + 2 * margin)
for r in range(2):
    for c in range(3):
        clip = fitz.Rect(c * cw, r * ch, (c + 1) * cw, (r + 1) * ch)
        x, y = (margin + c * (cw + gapx), margin + r * (ch + gapy))
        p.show_pdf_page(fitz.Rect(x, y, x + cw, y + ch), d, 0, clip=clip)
p.insert_font(fontname='ArialBold', fontfile='C:\\Windows\\Fonts\\arialbd.ttf')
p.insert_text((4, 15), 'F', fontname='ArialBold', fontsize=13)
out.set_metadata({'title': 'Figure 4F - vector schematic', 'subject': 'User-authorized conceptual color relocation in turquoise, upper A lighter and right B darker. Not an analytical score map. Original cell coordinates retained; four isolated cells omitted from display only.'})
stage = aux / 'F_vector_SCHEMATIC_ABswap_20261009.pdf'
out.save(stage, garbage=4, deflate=True)
with fitz.open(stage) as check:
    assert len(check) == 1
    assert len(check[0].get_images(full=True)) == 0, 'Raster image unexpectedly embedded'
    assert set(check[0].get_text().split()) == {'F', 'green', 'blue', 'turquoise', 'red', 'yellow', 'brown'}
    assert len(check[0].get_xobjects()) > 0
    check[0].get_pixmap(dpi=160, alpha=False).save(aux / 'QA/F_vector_SCHEMATIC_ABswap_preview_20261009.png')
(aux / 'QA/F_vector_SCHEMATIC_validation_20261009.json').write_text(json.dumps({'pdf': str(stage), 'embedded_raster_images': 0, 'editable_text': True, 'kind': 'schematic, not analytical', 'displayed_cells_per_panel': 14298, 'column_gap_pt': 8, 'row_gap_pt': 10, 'sha256': hashlib.sha256(stage.read_bytes()).hexdigest()}, ensure_ascii=False, indent=2), encoding='utf-8')
print(stage)
