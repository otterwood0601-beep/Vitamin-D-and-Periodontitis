options(stringsAsFactors=FALSE)
set.seed(20261009L)
.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(Seurat);library(Matrix);library(UCell);library(ggplot2);library(cowplot);library(scales);library(grid);library(jsonlite)})
warnings_seen <- character()
globalCallingHandlers(warning=function(w){warnings_seen <<- unique(c(warnings_seen,conditionMessage(w)));invokeRestart('muffleWarning')})
aux <- 'C:/wb_links/panel456_20261008'
old <- "C:/wb_links/dlc/output/Pseudotime_GO0070371_GO0022617_20261008/\u5176\u4ed6/source_data"
original <- fread('C:/wb_links/dlc/data_derived/tranoncol2026_Williams_20260920/05_cell_marker_and_program_scores.csv.gz')
cached <- fread(file.path(old,'32_pseudotime_cell_assignments.csv.gz'))
features <- c('ERK_GO0070371','ECM_GO0022617')
stopifnot(nrow(original)==14302,nrow(cached)==14302,!anyDuplicated(cached$cell_id),setequal(original$cell_id,cached$cell_id))
cached <- cached[match(original$cell_id,cell_id)]
for(v in c('cell_id','fibroblast_short','disease','Study','donor_id','frozen_umap_1','frozen_umap_2')) stopifnot(isTRUE(all.equal(original[[v]],cached[[v]],tolerance=1e-12)))
stopifnot(all(original$Study=='Williams'))
cell <- original[,.(cell_id,fibroblast_short,disease,Study,donor_id,frozen_umap_1,frozen_umap_2)]
for(v in features) cell[[v]] <- cached[[v]]
meta <- fromJSON(file.path(old,'go_gene_sets.json'),simplifyVector=FALSE)
sets <- setNames(lapply(meta,function(x)unlist(x$genes)),vapply(meta,function(x)x$feature,character(1)))
stopifnot(identical(sort(names(sets)),sort(features)),length(sets[[1]])==334,length(sets[[2]])==72)
stopifnot(all(vapply(meta,function(x)x$species,character(1))=='Homo sapiens'))
cat('[1] Same 14302 Williams gingival cells; existing GO scores reused\n');flush.console()
fb <- readRDS('C:/wb_links/dlc_data/outputs/fb_seurat_annotated.rds')
counts <- LayerData(fb,assay='RNA',layer='counts')
stopifnot(all(cell$cell_id %in% colnames(counts)))
sampled <- cell[,head(.SD,min(10L,.N)),by=.(fibroblast_short,disease)]$cell_id
uc <- ScoreSignatures_UCell(matrix=counts[,sampled,drop=FALSE],features=sets,maxRank=1500,ncores=1,missing_genes='skip')
uc <- as.data.table(uc,keep.rownames='cell_id')
sample_audit <- rbindlist(lapply(features,function(v){
 score <- as.numeric(uc[[paste0(v,'_UCell')]])
 truth <- cell[match(uc$cell_id,cell_id)][[v]]
 data.table(cell_id=uc$cell_id,feature=v,cached_score=truth,recomputed_score=score,absolute_difference=abs(score-truth))
}))
fwrite(sample_audit,file.path(aux,'QA/Fig6G_GO_cached_score_spotcheck_20261009.csv'))
print(sample_audit[order(-absolute_difference)][1:6])
stopifnot(max(sample_audit$absolute_difference)<1e-10)
membership <- rbindlist(lapply(features,function(v){
 g <- sets[[v]];present <- g %in% rownames(counts)
 detected <- rep(0L,length(g));detected[present] <- Matrix::rowSums(counts[g[present],cell$cell_id,drop=FALSE]>0)
 data.table(feature=v,gene=g,present_in_matrix=present,n_positive_Williams_cells=detected)
}))
coverage <- membership[,.(n_database_genes=.N,n_present_in_matrix=sum(present_in_matrix),n_detected_in_Williams_cells=sum(n_positive_Williams_cells>0)),by=feature]
old_coverage <- fread(file.path(old,'go_gene_coverage_summary.csv'))
stopifnot(isTRUE(all.equal(as.data.frame(coverage),as.data.frame(old_coverage),check.attributes=FALSE)))
rm(fb,counts);invisible(gc())
cat('[2] Cached scores verified against raw counts; maximum error:',max(sample_audit$absolute_difference),'\n');flush.console()
for(ex in parse('C:/wb_links/dlc/code/tranoncol2026/03_figures.R')){
 if(is.call(ex)&&identical(ex[[1]],as.name('<-'))&&is.symbol(ex[[2]])&&as.character(ex[[2]]) %in% c('FONT','TYPE_COLORS','theme_article','theme_umap','score_umap_violin')) eval(ex)
}
cell[,fibroblast_short:=factor(fibroblast_short,levels=names(TYPE_COLORS))]

body(score_umap_violin)[[2]] <- quote(d <- cell[order(get(s))][frozen_umap_1 >= -8])

plot_parts <- as.list(body(score_umap_violin))
plot_parts <- append(plot_parts,list(quote(pu <- pu + guides(colour=guide_colourbar(display='rectangles')))),after=4L)
body(score_umap_violin) <- as.call(plot_parts)
hidden <- cell[frozen_umap_1 < -8,.(cell_id,frozen_umap_1,frozen_umap_2)]
stopifnot(nrow(hidden)==4)
summary <- rbindlist(lapply(features,function(v)cell[,.(feature=v,n_cells=.N,mean_score=mean(get(v)),median_score=median(get(v)),q25=quantile(get(v),.25),q75=quantile(get(v),.75)),by=fibroblast_short]))
fwrite(cell,file.path(aux,'source_data/Fig6G_GO_cell_scores_20261009.csv.gz'))
fwrite(summary,file.path(aux,'source_data/Fig6G_GO_subtype_summary_20261009.csv'))
fwrite(membership,file.path(aux,'source_data/Fig6G_GO_gene_membership_20261009.csv'))
fwrite(coverage,file.path(aux,'source_data/Fig6G_GO_gene_coverage_20261009.csv'))
fwrite(hidden,file.path(aux,'source_data/Fig6G_GO_display_only_hidden_cells_20261009.csv'))
p <- plot_grid(score_umap_violin('ERK_GO0070371','ERK1/2 cascade\nGO:0070371'),score_umap_violin('ECM_GO0022617','ECM disassembly\nGO:0022617'),nrow=1)

out <- file.path(aux,'Fig6G_GO0070371_GO0022617_20261009.pdf')
if(file.exists(out)) stopifnot(file.copy(out,file.path(aux,'QA/Fig6G_GO_first_draft_raster_colorbars_20261009.pdf'),overwrite=FALSE))
ggsave(out,p,device=cairo_pdf,width=220.8/72,height=209.88/72,units='in',family='Arial',bg='white')
audit <- list(created_at='2026-10-09',scope='Williams human gingival fibroblasts',n_cells=nrow(cell),n_displayed_UMAP=nrow(cell)-nrow(hidden),score_method='UCell, maxRank=1500, missing genes skipped',GO_sources=lapply(meta,function(x)x[c('feature','go_id','msigdb_name','species','source_url','snapshot_date','n_genes')]),source_gene_sets=file.path(old,'go_gene_sets.json'),source_cached_scores=file.path(old,'32_pseudotime_cell_assignments.csv.gz'),scores_reused=TRUE,metadata_and_UMAP_exact_match=TRUE,spotcheck_cells=length(sampled),spotcheck_max_absolute_error=max(sample_audit$absolute_difference),gene_coverage=coverage,plot_code_reused='code/tranoncol2026/03_figures.R: score_umap_violin, TYPE_COLORS, theme_article, theme_umap',only_features=features,other_program_panels_removed=TRUE,summary=summary,warnings=warnings_seen,output=out,visual_review='pending')
writeLines(toJSON(audit,pretty=TRUE,auto_unbox=TRUE,digits=12),file.path(aux,'QA/Fig6G_GO_analysis_validation_20261009.json'))
print(coverage);print(summary);cat('DONE',out,'\n')
