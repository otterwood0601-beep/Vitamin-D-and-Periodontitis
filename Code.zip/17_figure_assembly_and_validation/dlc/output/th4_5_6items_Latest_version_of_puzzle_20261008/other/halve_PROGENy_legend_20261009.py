from pathlib import Path
import json
import fitz
BASE = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008\\\u5176\u4ed6')
SOURCE = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\\u539f\u6587\u683c\u5f0f\u8fc1\u79fb_GDF15_ERK\\Williams\u7edf\u4e00\u91cd\u5206\u6790_20260920\\Reference_Fig3_style_gingival_fibroblast_GDF15_ERK_state_20260915_Williams_20260920.pdf')
OUTPUT = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u8865\u5145\u56fe\\DLC\\6.Lin\\Williams_PROGENy_activity_half_legend_20261009.pdf')
assert not OUTPUT.exists(), 'Never overwrite a previous deliverable.'
original = fitz.open(SOURCE)
working = fitz.open(SOURCE)
page = working[0]
for rect in [fitz.Rect(0, 366, 12, 384), fitz.Rect(142, 367, 149, 391)]:
    page.add_redact_annot(rect, fill=(1, 1, 1))
page.apply_redactions(images=0, graphics=0)
bar = fitz.Rect(118.15234375, 423.93185, 135.4296875, 511.19586)
half = bar.width / 2
target = fitz.Rect(bar.x0, bar.y0, bar.x0 + half, bar.y1)
labels = fitz.Rect(137.5, 424, 144.2, 512)
page.draw_rect(fitz.Rect(117.95, 423.7, 145, 512), color=None, fill=(1, 1, 1), overlay=True)
page.show_pdf_page(target, original, 0, clip=bar, keep_proportion=False, overlay=True)
label_target = fitz.Rect(labels.x0 - half, labels.y0, labels.x1 - half, labels.y1)
page.show_pdf_page(label_target, original, 0, clip=labels, keep_proportion=False, overlay=True)
heatmap = fitz.Rect(12, 385, 113, 583)
old_pix = original[0].get_pixmap(matrix=fitz.Matrix(4, 4), clip=heatmap)
new_pix = page.get_pixmap(matrix=fitz.Matrix(4, 4), clip=heatmap)
assert old_pix.samples == new_pix.samples, 'Heatmap unexpectedly changed.'
crop = fitz.Rect(0, 374, 146.8, 583)
out = fitz.open()
final_page = out.new_page(width=crop.width * 2, height=crop.height * 2 + 10)
final_page.show_pdf_page(fitz.Rect(0, 0, crop.width * 2, crop.height * 2), working, 0, clip=crop)
out.set_metadata({'title': 'Williams fibroblast PROGENy activity - half-width Activity legend', 'subject': 'Original heatmap unchanged; colour bar width multiplied by 0.5'})
out.save(OUTPUT, garbage=4, deflate=True)
audit = {'source': str(SOURCE), 'output': str(OUTPUT), 'original_visible_bar_width_pt': bar.width, 'new_visible_bar_width_pt': target.width, 'width_ratio': target.width / bar.width, 'height_unchanged': target.height == bar.height, 'heatmap_pixels_identical_at_288dpi': True, 'output_global_scale': 2, 'data_reanalysis': False}
(BASE / 'QA' / 'PROGENy_half_legend_QA.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(audit, ensure_ascii=False, indent=2))
