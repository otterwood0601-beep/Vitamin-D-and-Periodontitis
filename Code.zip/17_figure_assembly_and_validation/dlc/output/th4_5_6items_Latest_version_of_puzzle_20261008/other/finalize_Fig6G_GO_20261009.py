from pathlib import Path
import hashlib, json, shutil, sys, datetime, re
import fitz
import numpy as np
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008')
AUX = ROOT / '\u5176\u4ed6'
QA = AUX / 'QA'
SRC = AUX / 'Fig6G_GO0070371_GO0022617_20261009.pdf'
DEST = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u8865\u5145\u56fe\\DLC\\6.Lin') / SRC.name
COMPOSITE = ROOT / '\u56fe/\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u5b8c\u6574\u62fc\u56fe_3\u9875.pdf'
MANIFEST = AUX / '\u62fc\u56fe\u6765\u6e90\u4e0e\u53bb\u91cd\u6e05\u5355.json'
STAGED = QA / '\u5b8c\u6574\u62fc\u56fe_Fig6G_GO\u66ff\u6362\u5f85\u5ba1\u6838_20261009.pdf'
CHECK = QA / 'Fig6G_GO_publication_validation_20261009.json'
TITLE = 'GO-defined ERK1/2 and ECM-disassembly scores'
TILE = fitz.Rect(295, 607, 882, 963)
TARGET = fitz.Rect(295, 635, 882, 963)

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def compare(before, after):
    results = []
    with fitz.open(before) as a, fitz.open(after) as b:
        assert len(a) == len(b) == 3
        for i in range(3):
            assert a[i].rect == b[i].rect
            pa = a[i].get_pixmap(alpha=False)
            pb = b[i].get_pixmap(alpha=False)
            aa = np.frombuffer(pa.samples, np.uint8).reshape(pa.height, pa.width, pa.n)
            bb = np.frombuffer(pb.samples, np.uint8).reshape(pb.height, pb.width, pb.n)
            diff = np.any(aa != bb, axis=2)
            if i == 2:
                diff[int(TILE.y0) - 2:int(TILE.y1) + 3, int(TILE.x0) - 2:int(TILE.x1) + 3] = False
            count = int(diff.sum())
            assert count == 0, (i, count)
            results.append({'page': i + 1, 'changed_pixels_outside_authorized_panel': count})
    return results
if '--commit' not in sys.argv:
    assert SRC.is_file() and COMPOSITE.is_file()
    assert not DEST.exists(), DEST
    manifest = json.loads(MANIFEST.read_text(encoding='utf-8'))
    panel = next((p for p in manifest['panels'] if p['figure'] == 6 and p['tag'] == 'G'))
    assert panel['target'] == list(TARGET)
    before_sha = sha(COMPOSITE)
    manifest_sha = sha(MANIFEST)
    backup = QA / '\u5b8c\u6574\u62fc\u56fe_Fig6G_GO\u66ff\u6362\u524d_20261009.pdf'
    backup_manifest = QA / '\u62fc\u56fe\u6765\u6e90_Fig6G_GO\u66ff\u6362\u524d_20261009.json'
    if backup.exists():
        assert sha(backup) == before_sha
    else:
        shutil.copy2(COMPOSITE, backup)
    if backup_manifest.exists():
        assert sha(backup_manifest) == manifest_sha
    else:
        shutil.copy2(MANIFEST, backup_manifest)
    with fitz.open(SRC) as src:
        assert len(src) == 1 and (not src[0].get_images(full=True))
        text = src[0].get_text()
        for required in ('GO:0070371', 'GO:0022617', 'ERK1/2 cascade', 'ECM disassembly'):
            assert required in text, required
        assert 'Collagen synthesis' not in text and 'ECM organization' not in text
        src[0].get_pixmap(matrix=fitz.Matrix(4, 4), alpha=False).save(QA / 'Fig6G_GO_standalone_preview_20261009.png')
        with fitz.open(COMPOSITE) as doc:
            p = doc[2]
            matches = []
            expanded = TARGET + (-1, -1, 1, 1)
            for xref, name, invoker, bbox in p.get_xobjects():
                if invoker == 0:
                    placed = fitz.Rect(bbox) * p.transformation_matrix
                    if expanded.contains(placed):
                        matches.append(name)
            assert len(matches) == 1, matches
            pattern = b'\\s*q\\s*/' + matches[0].encode() + b'\\s+Do\\s+Q\\s*'
            removed = 0
            for xref in p.get_contents():
                content = doc.xref_stream(xref)
                if re.fullmatch(pattern, content):
                    doc.update_stream(xref, b' q Q ')
                    removed += 1
            assert removed == 1
            p.add_redact_annot(fitz.Rect(295, 607, 882, 634), fill=(1, 1, 1))
            p.apply_redactions(images=0, graphics=0, text=0)
            p.insert_font(fontname='Fig6GArial', fontfile='C:\\Windows\\Fonts\\arial.ttf')
            p.insert_font(fontname='Fig6GArialBold', fontfile='C:\\Windows\\Fonts\\arialbd.ttf')
            p.insert_text((295, 617), 'G', fontname='Fig6GArialBold', fontsize=11)
            assert p.insert_textbox(fitz.Rect(316, 607, 882, 632), TITLE, fontname='Fig6GArial', fontsize=8, lineheight=1.1) >= 0
            p.show_pdf_page(TARGET, src, 0, keep_proportion=True)
            doc.save(STAGED, garbage=4, deflate=True)
        source_rect = list(src[0].rect)
        fonts = src[0].get_fonts(full=True)
    pixel_check = compare(COMPOSITE, STAGED)
    with fitz.open(STAGED) as d:
        d[2].get_pixmap(matrix=fitz.Matrix(2, 2), clip=fitz.Rect(280, 600, 900, 975), alpha=False).save(QA / 'Fig6G_GO_composite_preview_20261009.png')
    record = {'created_at': datetime.datetime.now().isoformat(), 'source': str(SRC), 'final_standalone': str(DEST), 'composite': str(COMPOSITE), 'backup': str(backup), 'backup_manifest': str(backup_manifest), 'stage': str(STAGED), 'source_sha256': sha(SRC), 'composite_before_sha256': before_sha, 'manifest_before_sha256': manifest_sha, 'stage_sha256': sha(STAGED), 'old_panel': panel, 'source_rect': source_rect, 'embedded_raster_images': 0, 'fonts': fonts, 'pixel_checks': pixel_check, 'visual_review': 'pending', 'committed': False}
    CHECK.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'stage': str(STAGED), 'QA': str(CHECK), 'checks': pixel_check}, ensure_ascii=False))
else:
    record = json.loads(CHECK.read_text(encoding='utf-8'))
    assert not record['committed']
    assert sha(SRC) == record['source_sha256']
    assert sha(COMPOSITE) == record['composite_before_sha256'], 'Composite changed since staging'
    assert sha(MANIFEST) == record['manifest_before_sha256'], 'Manifest changed since staging'
    assert sha(STAGED) == record['stage_sha256']
    assert not DEST.exists()
    manifest = json.loads(MANIFEST.read_text(encoding='utf-8'))
    panel = next((p for p in manifest['panels'] if p['figure'] == 6 and p['tag'] == 'G'))
    assert panel == record['old_panel']
    manifest.setdefault('exclusions', []).append({'figure': 6, 'tag': 'G_previous', 'source': panel['source'], 'clip': panel['clip'], 'reason': '2026-10-09 \u7528\u6237\u6307\u5b9a\u53ea\u4fdd\u7559GO:0070371\u53caGO:0022617\uff1b\u65e7\u4e09\u7a0b\u5e8f\u9762\u677f\u5386\u53f2\u539f\u56fe\u4fdd\u7559'})
    panel.update(title=TITLE, source=str(SRC), source_page=1, clip=record['source_rect'], sha256=sha(SRC), GO_terms=['GO:0070371', 'GO:0022617'], score_method='UCell maxRank=1500; complete MSigDB human GO gene sets', n_Williams_cells=14302, score_source='Verified existing 2026-10-08 scores; raw-count spotcheck passed', updated_at='2026-10-09')
    manifest['last_user_revision'] = '2026-10-09 \u7b2c6\u9879G\u6539\u4e3aGO:0070371\u548cGO:0022617\u4e24\u9879\u8bc4\u5206\uff1b\u5176\u5b83\u9762\u677f\u53ca\u6392\u9664\u8bb0\u5f55\u539f\u6837\u4fdd\u7559'
    manifest['visual_review'] = 'passed: revised Figure 6 G inspected; other pixels unchanged'
    shutil.copy2(SRC, DEST)
    assert sha(DEST) == sha(SRC)
    shutil.copy2(STAGED, COMPOSITE)
    assert sha(COMPOSITE) == record['stage_sha256']
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    record.update(visual_review='passed: both standalone and composite inspected', committed=True, final_sha256=sha(DEST), composite_after_sha256=sha(COMPOSITE))
    CHECK.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
    auditfile = QA / 'Fig6G_GO_analysis_validation_20261009.json'
    audit = json.loads(auditfile.read_text(encoding='utf-8'))
    audit['visual_review'] = 'passed: titles, axes, legends, vector marks and subtype order inspected'
    audit['final_output'] = str(DEST)
    auditfile.write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'standalone': str(DEST), 'composite': str(COMPOSITE), 'vector_pdf': True, 'other_panels_unchanged': True}, ensure_ascii=False))
