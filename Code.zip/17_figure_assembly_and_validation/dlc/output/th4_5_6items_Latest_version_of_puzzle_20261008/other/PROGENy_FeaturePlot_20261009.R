options(stringsAsFactors=FALSE)
set.seed(20261009L)
.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(Seurat);library(progeny);library(Matrix);library(data.table);library(ggplot2);library(patchwork);library(viridisLite);library(jsonlite)})
aux <- 'C:/wb_links/panel456_20261008'
sd <- file.path(aux,'source_data')
cat('[1] Reading existing Williams cell identities and frozen UMAP\n');flush.console()
meta <- fread('C:/wb_links/dlc/data_derived/tranoncol2026_Williams_20260920/05_cell_marker_and_program_scores.csv.gz')
stopifnot(nrow(meta)==14302, all(meta$Study=='Williams'), !anyDuplicated(meta$cell_id))
fb <- readRDS('C:/wb_links/dlc_data/outputs/fb_seurat_annotated.rds')
fb <- subset(fb,cells=meta$cell_id)
meta <- meta[match(colnames(fb),cell_id)]
stopifnot(identical(meta$cell_id,colnames(fb)))
norm <- LayerData(fb,assay='RNA',layer='data')
model <- getModel('Human',top=100)
common <- intersect(rownames(norm),rownames(model))
cat('[2] Computing cell-level PROGENy scores: Human top=100, normalized RNA\n');flush.console()

expr <- as.matrix(norm[common,,drop=FALSE])
scores <- progeny(expr,scale=TRUE,organism='Human',top=100,perm=1)
stopifnot(identical(rownames(scores),colnames(fb)),all(is.finite(scores)))

manual <- scale(as.matrix(t(norm[common,,drop=FALSE]) %*% as.matrix(model[common,,drop=FALSE])))
err <- max(abs(manual-scores))
stopifnot(err<1e-10)
cell <- cbind(meta[,.(cell_id,Study,donor_id,disease,fibroblast_short,frozen_umap_1,frozen_umap_2)],as.data.table(scores))
fwrite(cell,file.path(sd,'PROGENy_single_cell_scores_20261009.csv.gz'))
coverage <- data.table(pathway=colnames(model),model_genes=colSums(model!=0),present_genes=colSums(model[common,,drop=FALSE]!=0))
fwrite(coverage,file.path(sd,'PROGENy_single_cell_gene_coverage_20261009.csv'))
fwrite(as.data.table(model,keep.rownames='gene'),file.path(sd,'PROGENy_model_Human_top100_20261009.csv'))
fb[['progeny']] <- CreateAssayObject(data=t(scores))
DefaultAssay(fb) <- 'progeny'
xy <- as.matrix(meta[,.(frozen_umap_1,frozen_umap_2)])
rownames(xy) <- meta$cell_id
colnames(xy) <- c('UMAP_1','UMAP_2')
fb[['frozen']] <- CreateDimReducObject(embeddings=xy,key='UMAP_',assay='RNA')
hidden <- meta[frozen_umap_1 < -8,.(cell_id,frozen_umap_1,frozen_umap_2)]
stopifnot(nrow(hidden)==4)
fwrite(hidden,file.path(sd,'PROGENy_FeaturePlot_display_only_omissions_20261009.csv'))
display <- subset(fb,cells=setdiff(colnames(fb),hidden$cell_id))
features <- c('NFkB','MAPK')
lims <- range(scores[,features])
plots <- lapply(features,function(v){

  base <- FeaturePlot(display,features=v,reduction='frozen',slot='data',coord.fixed=TRUE,
              order=TRUE,cols=viridis(2),pt.size=.35,raster=FALSE,combine=FALSE)[[1]]
  stopifnot(max(abs(base$data[[v]]-scores[rownames(base$data),v]))<1e-10)
  base + labs(x='UMAP_1',y='UMAP_2') +
    scale_colour_gradientn(colours=viridis(10),limits=lims,name='Score (Z)') +
    theme_classic(base_size=10,base_family='Arial') +
    theme(plot.title=element_text(size=12,face='bold',hjust=.5),
          legend.title=element_text(size=9),legend.text=element_text(size=8),
          axis.title=element_text(size=9),axis.text=element_text(size=8)) +
    guides(colour=guide_colourbar(display='rectangles'))
})
p <- wrap_plots(plots,nrow=1,guides='collect') & theme(legend.position='right')
out <- file.path(aux,'PROGENy_NFkB_MAPK_FeaturePlot_Williams_20261009.pdf')
if(file.exists(out)) file.copy(out,file.path(aux,'QA/PROGENy_FeaturePlot_initial_QA_draft.pdf'),overwrite=TRUE)
ggsave(out,p,device=cairo_pdf,width=8,height=3.65,units='in',family='Arial',bg='white')
write_json(list(source='Williams gingival fibroblasts',n_scored=nrow(meta),n_displayed=ncol(display),
  score='PROGENy Human top=100, perm=1; RNA log-normalized expression times signed model weights; Z scaling across all cells for each pathway',
  progeny_version=as.character(packageVersion('progeny')),Seurat_version=as.character(packageVersion('Seurat')),
  features=features,shared_colour_limits=lims,palette='viridis(10)',clipping='none',
  coordinates='existing frozen UMAP, not recomputed',omitted_display_cells=hidden$cell_id,
  independent_recomputation_max_error=err,source_object='C:/wb_links/dlc_data/outputs/fb_seurat_annotated.rds',
  model_gene_coverage=coverage,output=out),file.path(sd,'PROGENy_FeaturePlot_manifest_20261009.json'),pretty=TRUE,auto_unbox=TRUE)
cat('[DONE]',out,'\n'); print(coverage[pathway %in% features]); print(lims)
