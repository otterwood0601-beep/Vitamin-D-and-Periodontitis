from pathlib import Path
import sys
import numpy as np
import pandas as pd
import fitz
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm, LinearSegmentedColormap
R = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
A = R / 'output/\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008/\u5176\u4ed6'
P = A / '\u62fc\u56fe\u7d20\u6750'
sys.path.insert(0, str(R / 'code'))
from style_npj import set_npj_style
set_npj_style()
colors = {'green': '#66BC29', 'blue': '#2A55A5', 'turquoise': '#65C7C8', 'red': '#ED1C24', 'yellow': '#F4E500', 'brown': '#B02525'}
z = pd.read_csv(A / 'source_data/Williams_hdWGCNA_GO_plotted_RAWP.csv')
fig, axes = plt.subplots(6, 1, figsize=(7, 5.7))
norm = LogNorm(vmin=max(z.p.min(), 1e-300), vmax=0.05)
for ax, (mod, col) in zip(axes, colors.items()):
    q = z[z.module.eq(mod)].sort_values('p', ascending=False)
    sc = ax.scatter(q.fold, range(len(q)), c=q.p, s=np.sqrt(q.hit) * 1.4, cmap='magma_r', norm=norm)
    ax.set_yticks(range(len(q)), q.term.str.replace(' \\(GO:\\d+\\)$', '', regex=True), fontsize=5)
    ax.set_ylim(-0.65, len(q) - 0.35)
    ax.set_xlim(-2, z.fold.max() * 1.05)
    ax.set_title(mod, loc='right', fontsize=6, color=col, fontweight='bold')
    ax.spines[['top', 'right']].set_visible(False)
axes[-1].set_xlabel('Fold enrichment', fontsize=7)
fig.subplots_adjust(left=0.64, right=0.9, top=0.98, bottom=0.1, hspace=0.8)
fig.colorbar(sc, cax=fig.add_axes([0.93, 0.25, 0.015, 0.5])).set_label('Raw P', fontsize=7)
fig.text(0.64, 0.01, 'Point area scales with square-root of gene count.', fontsize=5)
fig.savefig(P / 'Williams_hdWGCNA_GO_RAWP.pdf', bbox_inches='tight', pad_inches=0.08)
plt.close(fig)
src = fitz.open(R / 'P2_hdWGCNA_Williams_20260920/outputs/figures/\u56feP2D_\u6a21\u5757hub\u57fa\u56e0\u70b9\u56fe.pdf')
d = fitz.open()
p = d.new_page(width=302, height=620)
p.show_pdf_page(fitz.Rect(0, 0, 302, 540), src, 0)
p.draw_rect(fitz.Rect(0, 525, 240, 541), color=None, fill=(1, 1, 1))
p.insert_font(fontname='Arial', fontfile='C:\\Windows\\Fonts\\arial.ttf')
labels = ['Immune', 'ECM remodeling', 'Vascular', 'Pre-ECM', 'Matrix homeostasis']
for x, t in zip([61.5, 96.3, 131.0, 165.7, 200.4], labels):
    p.insert_text((x + 2, 530 + fitz.get_text_length(t, fontname='helv', fontsize=6)), t, fontname='Arial', fontsize=6, rotate=90)
d.save(P / 'Williams_hub_dot_labels_repaired.pdf', garbage=4, deflate=True)
dat = R / 'data_derived/tranoncol2026_Williams_20260920'
s = pd.read_csv(dat / '06_cell_score_subtype_disease_summary.csv')
features = ['MAPK_ERK', 'MAPK_JNK_p38', 'ECM_synthesis', 'ECM_organization', 'ECM_degradation', 'ECM_inhibitors', 'ECM_adhesion', 'WNT_niche']
s = s[s.feature.isin(features)].groupby(['feature', 'fibroblast_short']).agg(value=('mean', 'mean'), size=('detection_or_positive_fraction', 'mean')).reset_index()
s['z'] = s.groupby('feature').value.transform(lambda x: (x - x.mean()) / x.std(ddof=1))
pr = pd.read_csv(dat / '07_PROGENy_pathway_by_fibroblast_subtype.csv')
pr['fibroblast_short'] = pr.fibroblast_short.str.replace('.', ' ', regex=False)
pr['feature'] = 'PROGENy ' + pr.pathway
pr['z'] = pr.activity_z
pr['size'] = np.minimum(abs(pr.z) / 2.5, 1)
dd = pd.concat([s, pr], ignore_index=True)
programs = features + list(pr.feature.unique())
cmap = LinearSegmentedColormap.from_list('ref', ['#31558C', 'white', '#C6423B'])
fig, ax = plt.subplots(figsize=(3.7, 4.9))
for _, r in dd.iterrows():
    sc = ax.scatter(labels.index(r.fibroblast_short), programs.index(r.feature), s=(0.5 + 2.7 * np.sqrt(max(0, r['size']))) * 10, c=[r.z], vmin=-2.5, vmax=2.5, cmap=cmap, edgecolors='#777777', linewidths=0.15)
ax.set_yticks(range(len(programs)), programs, fontsize=6)
ax.set_xticks(range(5), labels, rotation=45, ha='right', fontsize=6)
ax.set_ylim(len(programs) - 0.4, -0.6)
ax.set_xlim(-0.6, 4.6)
ax.spines[['top', 'right']].set_visible(False)
fig.colorbar(sc, ax=ax, shrink=0.45, label='Z score')
fig.text(0.025, 0.01, 'Size: positive fraction (UCell); |Z| / 2.5 (PROGENy, capped at 1).', fontsize=5)
fig.tight_layout(rect=[0, 0.04, 1, 1])
fig.savefig(P / 'Williams_state_program_dot_repaired.pdf', bbox_inches='tight', pad_inches=0.08)
plt.close(fig)
dd.to_csv(A / 'source_data/Williams_state_program_dot_source.csv', index=False)
print('Layout repairs ready')
