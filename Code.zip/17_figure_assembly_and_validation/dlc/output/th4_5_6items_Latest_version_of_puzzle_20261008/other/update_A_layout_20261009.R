aux <- 'C:/wb_links/panel456_20261008'
figdir <- file.path(aux, '..', '\u56fe')
st <- read.csv(file.path(aux,'source_data/Fig4A_soft_threshold_source.csv'),check.names=FALSE)
out <- file.path(aux,'Fig4A_base_square_compact_20261009.pdf')
stopifnot(!file.exists(out))
power <- 10
cairo_pdf(out,width=7.2,height=3.65,family='Arial',pointsize=10)

par(mfrow=c(1,2),mar=c(2.2,2.65,1.25,.3),oma=c(0,0,.5,0),
    cex=.8,pty='s',mgp=c(1.35,.35,0),tcl=-.25)
plot(st$Power,st$signed_R2,type='b',xlab='Soft-threshold power',
     ylab='Signed scale-free fit R2',main='',cex.main=1.2)
mtext('Selected power: 10',side=3,line=.25,font=2,cex=.8)
abline(h=.8,col='#B2182B',lty=2);abline(v=power,col='#2166AC',lty=3)
box1 <- par('pin')
plot(st$Power,st$mean.k.,type='b',xlab='Soft-threshold power',
     ylab='Mean connectivity',main='')
mtext('18 sample-ID groups',side=3,line=.25,font=2,cex=.8)
box2 <- par('pin')
stopifnot(abs(box1[1]-box1[2])<1e-10,abs(box2[1]-box2[2])<1e-10)
dev.off()
write.csv(data.frame(panel=c('left','right'),width_in=c(box1[1],box2[1]),height_in=c(box1[2],box2[2])),file.path(aux,'source_data/Fig4A_square_geometry_20261009.csv'),row.names=FALSE)
cat(out,'\n')
