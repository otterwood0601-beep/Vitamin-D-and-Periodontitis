from pathlib import Path
import json, hashlib
import numpy as np
import pandas as pd
from PIL import Image
from scipy.ndimage import gaussian_filter, map_coordinates, binary_closing, label
aux = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008\\\u5176\u4ed6')
ref = Path('C:\\Users\\Lin\\AppData\\Local\\Temp\\codex-clipboard-ebf329dd-1fa0-46ef-ac47-5e6ca0992eee.png')
source = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\data_derived\\tranoncol2026_Williams_20260920\\26_cell_hdWGCNA_top50_UCell_scores.csv.gz')
a = np.asarray(Image.open(ref).convert('RGB'), dtype=float)
strength = np.maximum((a[:, :, 1] + a[:, :, 2]) / 2 - a[:, :, 0], 0)
support = gaussian_filter(strength, 1.0) > 2.5
ys, xs = np.where(support)
bbox = [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())]
cells = pd.read_csv(source)
d = cells[cells.frozen_umap_1.ge(-8)].copy()
assert len(d) == 14298
xmin, xmax = (d.frozen_umap_1.min(), d.frozen_umap_1.max())
ymin, ymax = (d.frozen_umap_2.min(), d.frozen_umap_2.max())
px = bbox[0] + (d.frozen_umap_1.to_numpy() - xmin) / (xmax - xmin) * (bbox[2] - bbox[0])
py = bbox[1] + (ymax - d.frozen_umap_2.to_numpy()) / (ymax - ymin) * (bbox[3] - bbox[1])
smoothed = gaussian_filter(a, sigma=(1.2, 1.2, 0))
sampled = np.column_stack([map_coordinates(smoothed[:, :, c], [py, px], order=1, mode='nearest') for c in range(3)])
rgb = np.clip(np.rint(sampled), 0, 255).astype('uint8')
d['schematic_color'] = ['#%02X%02X%02X' % tuple(v) for v in rgb]
d['reference_x_px'] = px
d['reference_y_px'] = py
d['schematic_darkness'] = 255 - rgb.mean(axis=1)
d[['cell_id', 'frozen_umap_1', 'frozen_umap_2', 'turquoise', 'schematic_color', 'schematic_darkness', 'reference_x_px', 'reference_y_px']].to_csv(aux / 'source_data/F_pixel_matched_SCHEMATIC_20261009.csv', index=False)
audit = {'kind': 'user-requested schematic, not analytical scores', 'reference': str(ref), 'reference_sha256': hashlib.sha256(ref.read_bytes()).hexdigest(), 'reference_pixels_analyzed': int(a.shape[0] * a.shape[1]), 'reference_shape': list(a.shape[:2]), 'color_support_bbox_xyxy': bbox, 'source_points_unchanged': True, 'displayed_points': len(d), 'excluded_isolated_points_display_only': 4, 'color_sampling': 'RGB bilinear sample after 1.2-pixel noise smoothing; affine bounding-box registration; no score recomputation', 'actual_rgb_colors': int(len(np.unique(rgb, axis=0)))}
(aux / 'QA/F_pixel_match_provenance_20261009.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(audit, ensure_ascii=False))
