from pathlib import Path
import fitz, hashlib, json, sys
root = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
aux = root / 'output/\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008/\u5176\u4ed6'
src = root / 'P3_WGCNA_Williams_20261008/\u56fe/WGCNA_diagnostics.pdf'
dest = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u8865\u5145\u56fe\\DLC\\6.Lin\\Fig4B_compact_20261009.pdf')
assert not dest.exists() or '--rebuild' in sys.argv, 'Preserve existing destination'
old_hash = hashlib.sha256(src.read_bytes()).hexdigest()
d = fitz.open(src)
p = d[1]
for b in p.get_text('dict')['blocks']:
    for ln in b.get('lines', []):
        for s in ln['spans']:
            if s['text'] in ['Williams fibroblast pseudobulk module clustering', 'Height', 'WGCNA modules']:
                p.add_redact_annot(fitz.Rect(s['bbox']), fill=(1, 1, 1))
p.apply_redactions(images=0, graphics=0, text=0)
out = fitz.open()
q = out.new_page(width=532, height=254)
q.show_pdf_page(fitz.Rect(14, 0, 532, 254), d, 1, clip=fitz.Rect(0, 38, 518, 292))
fontfile = 'C:\\Windows\\Fonts\\arial.ttf'
q.insert_font(fontname='Arial', fontfile=fontfile)
font = fitz.Font(fontfile=fontfile)
q.insert_text((52, 142.4 - 38 + font.text_length('Height', fontsize=12) / 2), 'Height', fontsize=12, fontname='Arial', rotate=90)
label = 'WGCNA modules'
q.insert_text((97 - font.text_length(label, fontsize=12), 231.2), label, fontname='Arial', fontsize=12)
out.set_metadata({'title': 'Figure B - Williams pseudobulk module dendrogram', 'subject': 'Layout-only revision; original tree and module colors preserved'})
out.save(dest, garbage=4, deflate=True)
with fitz.open(dest) as check:
    text = check[0].get_text()
    assert 'Williams' not in text and 'clustering' not in text
    sizes = {s['text'].replace('\xa0', ' '): s['size'] for b in check[0].get_text('dict')['blocks'] for ln in b.get('lines', []) for s in ln['spans']}
    assert sizes['WGCNA modules'] == sizes['Height'] == 12
assert hashlib.sha256(src.read_bytes()).hexdigest() == old_hash
(aux / 'QA/Fig4B_layout_20261009.json').write_text(json.dumps({'source': str(src), 'source_sha256': old_hash, 'output': str(dest), 'labels_fontsize_pt': 12, 'tree_and_colors': 'original vector paths retained', 'source_unchanged': True}, ensure_ascii=False, indent=2), encoding='utf-8')
print(dest)
