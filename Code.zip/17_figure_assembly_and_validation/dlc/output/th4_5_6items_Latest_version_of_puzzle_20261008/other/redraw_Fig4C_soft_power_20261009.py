from pathlib import Path
import hashlib, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator, StrMethodFormatter
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
OUT = ROOT / 'output/\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008'
SOURCE = ROOT / 'P2_hdWGCNA_Williams_20260920/outputs/02_source_data/02_soft_power_table.csv'
df = pd.read_csv(SOURCE)
source_hash = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
assert len(df) == 20 and df.Power.is_unique
selected = 6
plt.rcParams.update({'font.family': 'Arial', 'font.size': 12, 'axes.labelsize': 14, 'xtick.labelsize': 12, 'ytick.labelsize': 12, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'axes.linewidth': 1.2})
fig, axes = plt.subplots(2, 2, figsize=(14, 12.5))
fig.subplots_adjust(left=0.095, right=0.98, bottom=0.075, top=0.96, wspace=0.28, hspace=0.28)
fig.text(0.018, 0.982, 'C', fontsize=28, fontweight='bold', va='top')
columns = ['SFT.R.sq', 'mean.k.', 'median.k.', 'max.k.']
ylabels = ['Scale-free Topology Model Fit', 'Mean Connectivity', 'Median Connectivity', 'Max Connectivity']
all_checks = []
for ax, col, ylabel in zip(axes.flat, columns, ylabels):
    ax.set_facecolor('#EBEBEB')
    if col == 'SFT.R.sq':
        ax.axhspan(-0.05, 0.8, color='#D3D3D3', zorder=0)
        ax.set_ylim(-0.05, 1.075)
        ax.yaxis.set_major_locator(MultipleLocator(0.2))
        ax.yaxis.set_minor_locator(MultipleLocator(0.1))
    else:
        ax.set_ylim(-220, 4400 if col == 'max.k.' else 4150)
        ax.yaxis.set_major_locator(MultipleLocator(1000))
        ax.yaxis.set_minor_locator(MultipleLocator(500))
        ax.yaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
    ax.set_xlim(-0.4, 31.4)
    ax.set_xticks([0, 5, 10, 15, 20, 25, 30])
    ax.xaxis.set_minor_locator(MultipleLocator(2.5))
    ax.grid(which='major', color='white', linewidth=1)
    ax.grid(which='minor', color='white', linewidth=0.5)
    ax.set_axisbelow(True)
    ax.set_box_aspect(1)
    ax.set_xlabel('Soft Power Threshold', labelpad=7)
    ax.set_ylabel(ylabel, labelpad=9)
    y6 = float(df.loc[df.Power.eq(selected), col].iloc[0])
    ax.axvline(selected, color='black', linewidth=1.1, linestyle=(0, (5, 4)))
    ax.axhline(y6, color='black', linewidth=1.1, linestyle=(0, (5, 4)))
    ax.scatter([selected], [y6], s=210, c='black', zorder=4)
    text6 = ax.text(selected, y6, '6', ha='center', va='center', fontsize=13, color='white', zorder=5)
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    occupied = [text6.get_window_extent(renderer).expanded(1.45, 1.65)]
    positions = []
    for row in df.itertuples(index=False, name=None):
        power = int(row[0])
        value = float(df.loc[df.Power.eq(power), col].iloc[0])
        if power == selected:
            continue
        point = ax.transData.transform((power, value))
        txt = ax.text(power, value, str(power), ha='center', va='center', fontsize=12, zorder=5)
        chosen = None
        for dy in [0, 16, -16, 32, -32, 48, -48, 64, -64]:
            pos = ax.transData.inverted().transform(point + [0, dy])
            txt.set_position(pos)
            bb = txt.get_window_extent(renderer).expanded(1.5, 1.25)
            box = ax.get_window_extent(renderer)
            if bb.x0 < box.x0 + 2 or bb.x1 > box.x1 - 2 or bb.y0 < box.y0 + 2 or (bb.y1 > box.y1 - 2):
                continue
            if any((bb.overlaps(other) for other in occupied)):
                continue
            chosen = (pos, bb, dy)
            break
        if chosen is None:
            raise RuntimeError(f'Cannot place {col} power {power}')
        pos, bb, dy = chosen
        occupied.append(bb)
        if dy:
            ax.annotate('', xy=(power, value), xytext=pos, arrowprops={'arrowstyle': '-', 'color': '#707070', 'lw': 0.5}, zorder=3)
            ax.plot(power, value, '.', ms=2, color='black', zorder=3)
        positions.append({'power': power, 'value': value, 'label_y': float(pos[1]), 'offset_pixels': dy})
    all_checks.append({'metric': col, 'selected_power': 6, 'selected_value': y6, 'labels': positions, 'overlaps': 0})
fig.canvas.draw()
ratios = [ax.get_window_extent().width / ax.get_window_extent().height for ax in axes.flat]
assert all((abs(r - 1) < 1e-06 for r in ratios))
base = 'Fig4C_hdWGCNA_soft_threshold_enlarged_20261009'
fig.savefig(OUT / '\u56fe' / f'{base}.pdf')
fig.savefig(OUT / '\u56fe' / f'{base}_600dpi.png', dpi=600)
fig.savefig(OUT / '\u56fe' / f'{base}_preview.png', dpi=120)
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == source_hash
report = {'source': str(SOURCE), 'source_sha256': source_hash, 'former_panel': 'E', 'new_panel': 'C', 'data_changed': False, 'canvas_inches': [14, 12.5], 'square_axis_ratios': ratios, 'labels': all_checks, 'visual_review': 'pending'}
(OUT / '\u5176\u4ed6' / f'{base}_QA.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'pdf': str(OUT / '\u56fe' / f'{base}.pdf'), 'png': str(OUT / '\u56fe' / f'{base}_600dpi.png'), 'label_overlap_count': 0}, ensure_ascii=False))
