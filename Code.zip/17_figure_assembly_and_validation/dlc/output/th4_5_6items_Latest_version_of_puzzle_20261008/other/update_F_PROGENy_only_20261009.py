from pathlib import Path
import sys
import shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import fitz
root = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
work = root / 'output/\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008/\u5176\u4ed6'
out = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u8865\u5145\u56fe\\DLC\\6.Lin\\Fig6F_PROGENy_only_20261009.pdf')
sys.path.insert(0, str(root / 'code'))
from style_npj import set_npj_style
set_npj_style()
original = pd.read_csv(work / 'source_data/Williams_state_program_dot_source.csv')
pr = original[original.feature.str.startswith('PROGENy ', na=False)].copy()
labels = ['Immune', 'ECM remodeling', 'Vascular', 'Pre-ECM', 'Matrix homeostasis']
programs = list(pr.feature.unique())
assert len(pr) == 70 and len(programs) == 14
assert not pr.duplicated(['feature', 'fibroblast_short']).any()
assert set(pr.fibroblast_short) == set(labels)
assert np.isfinite(pr[['z', 'size']].to_numpy()).all()
assert np.allclose(pr['size'], np.minimum(abs(pr.z) / 2.5, 1))
cmap = LinearSegmentedColormap.from_list('ref', ['#31558C', 'white', '#C6423B'])
fig, ax = plt.subplots(figsize=(3.7, 3.7))
for _, r in pr.iterrows():
    sc = ax.scatter(labels.index(r.fibroblast_short), programs.index(r.feature), s=(0.5 + 2.7 * np.sqrt(max(0, r['size']))) * 10, c=[r.z], vmin=-2.5, vmax=2.5, cmap=cmap, edgecolors='#777777', linewidths=0.15)
ax.set_yticks(range(len(programs)), programs, fontsize=6)
ax.set_xticks(range(5), labels, rotation=45, ha='right', fontsize=6)
ax.set_ylim(len(programs) - 0.4, -0.6)
ax.set_xlim(-0.6, 4.6)
ax.spines[['top', 'right']].set_visible(False)
fig.colorbar(sc, ax=ax, shrink=0.55, label='Z score')
fig.text(0.025, 0.97, 'F', fontsize=12, fontweight='bold', va='top')
fig.text(0.11, 0.967, 'Programs across fibroblast states', fontsize=8, va='top')
fig.text(0.025, 0.01, 'Size: |Z| / 2.5 (capped at 1).', fontsize=5)
fig.tight_layout(rect=[0, 0.045, 1, 0.92])
display_programs = [name.removeprefix('PROGENy ') for name in programs]
ax.set_yticks(range(len(programs)), display_programs, fontsize=6)
if out.exists():
    backup = work / 'QA/Fig6F_before_label_cleanup_20261009.pdf'
    if not backup.exists():
        shutil.copy2(out, backup)
fig.savefig(out, bbox_inches='tight', pad_inches=0.08)
plt.close(fig)
with fitz.open(out) as doc:
    assert len(doc) == 1
    text = doc[0].get_text()
    assert all((name in text for name in display_programs))
    assert 'PROGENy' not in text
    removed = ['MAPK_ERK', 'MAPK_JNK_p38', 'ECM_synthesis', 'ECM_organization', 'ECM_degradation', 'ECM_inhibitors', 'ECM_adhesion', 'WNT_niche']
    assert all((name not in text for name in removed))
print(f'PASS: 14 pathways, 70 unchanged scores; {out}')
