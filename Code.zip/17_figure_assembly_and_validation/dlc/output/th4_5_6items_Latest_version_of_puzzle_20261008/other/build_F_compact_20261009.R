.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(ggplot2);library(cowplot)})
aux <- 'C:/wb_links/panel456_20261008'
src <- 'C:/wb_links/dlc/data_derived/tranoncol2026_Williams_20260920/26_cell_hdWGCNA_top50_UCell_scores.csv.gz'
cells <- fread(src)
stopifnot(nrow(cells)==14302,all(cells$Study=='Williams'))
isolated <- cells[frozen_umap_1 < -8]
draw <- cells[frozen_umap_1 >= -8]
stopifnot(nrow(isolated)==4,nrow(draw)==14298)
fwrite(isolated,file.path(aux,'source_data/F_display_only_omitted_isolated_cells_20261009.csv'))
colors <- c(green='#66BC29',blue='#2A55A5',turquoise='#65C7C8',red='#ED1C24',yellow='#F4E500',brown='#B02525')
theme_map <- theme_void(base_family='Arial') + theme(
 plot.title=element_text(size=12,face='bold',hjust=.5,margin=margin(b=2)),
 plot.margin=margin(1,1,1,1))
plots <- lapply(names(colors),function(mn){
 full <- cells[[mn]]
 lim <- as.numeric(quantile(full,.99,na.rm=TRUE))
 d <- draw[order(get(mn))]
 rgb0 <- col2rgb(colors[mn])/255
 pale <- rgb(.8+.2*rgb0[1],.8+.2*rgb0[2],.8+.2*rgb0[3])
 ggplot(d,aes(frozen_umap_1,frozen_umap_2,colour=pmin(get(mn),lim))) +
 geom_point(size=.28) + coord_equal(expand=FALSE,
  xlim=range(draw$frozen_umap_1)+c(-.12,.12),ylim=range(draw$frozen_umap_2)+c(-.12,.12)) +
 scale_colour_gradientn(colours=c('#FEFEFE','#FAFAFA',pale,colors[mn]),
  values=c(0,.5,.8,1),limits=c(min(full),lim),guide='none') +
 labs(title=mn) + theme_map
})
out <- 'C:/Users/Lin/AppData/Local/Temp/F_hdWGCNA_compact_base_20261009.pdf'
stopifnot(!file.exists(out))
cairo_pdf(out,width=7.5,height=5.85,family='Arial',onefile=TRUE)
print(plot_grid(plotlist=plots,ncol=3))
dev.off()
cat('Display only:',nrow(draw),'cells;',nrow(isolated),'isolated cells omitted; original color limits retained.\n')
