from pathlib import Path
import fitz, hashlib, json
root = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
src = root / 'P2_hdWGCNA_Williams_20260920/outputs/figures/\u56feP2C_\u6a21\u5757\u6811.pdf'
dest = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u8865\u5145\u56fe\\DLC\\6.Lin\\Fig4D_hdWGCNA_compact_20261009.pdf')
assert not dest.exists()
before = hashlib.sha256(src.read_bytes()).hexdigest()
d = fitz.open(src)
p = d[0]
for b in p.get_text('dict')['blocks']:
    for ln in b.get('lines', []):
        for s in ln['spans']:
            if s['text'] in ['Height', 'Module colors']:
                p.add_redact_annot(fitz.Rect(s['bbox']), fill=(1, 1, 1))
p.apply_redactions(images=0, graphics=0, text=0)
out = fitz.open()
q = out.new_page(width=474, height=170)
q.show_pdf_page(fitz.Rect(6, 0, 474, 170), d, 0, clip=fitz.Rect(0, 38, 468, 208))
ff = 'C:\\Windows\\Fonts\\arial.ttf'
font = fitz.Font(fontfile=ff)
q.insert_font(fontname='Arial', fontfile=ff)
q.insert_text((42, 108 - 38 + font.text_length('Height', fontsize=12) / 2), 'Height', fontname='Arial', fontsize=12, rotate=90)
q.insert_text((87 - font.text_length('Module colors', fontsize=12), 153), 'Module colors', fontname='Arial', fontsize=12)
out.set_metadata({'title': 'Figure D - Williams hdWGCNA module dendrogram', 'subject': 'Original F renumbered D after C/D exclusion; layout-only edit'})
out.save(dest, garbage=4, deflate=True)
with fitz.open(dest) as check:
    assert len(check) == 1 and 'hdWGCNA' not in check[0].get_text()
    sizes = {s['text'].replace('\xa0', ' '): s['size'] for b in check[0].get_text('dict')['blocks'] for ln in b.get('lines', []) for s in ln['spans']}
    assert sizes['Module colors'] == sizes['Height'] == 12
assert hashlib.sha256(src.read_bytes()).hexdigest() == before
qa = root / 'output/\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008/\u5176\u4ed6/QA/Fig4D_hdWGCNA_20261009.json'
qa.write_text(json.dumps({'source': str(src), 'output': str(dest), 'source_sha256': before, 'old_panel': 'F', 'new_panel': 'D', 'layout_only': True, 'axis_labels_pt': 12}, ensure_ascii=False, indent=2), encoding='utf-8')
print(dest)
