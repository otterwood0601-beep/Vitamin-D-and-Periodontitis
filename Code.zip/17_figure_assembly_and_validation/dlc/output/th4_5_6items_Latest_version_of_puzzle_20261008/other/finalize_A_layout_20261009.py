from pathlib import Path
import fitz
R = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008')
src = fitz.open(R / '\u5176\u4ed6/Fig4A_base_square_compact_20261009.pdf')
d = fitz.open()
p = d.new_page(width=src[0].rect.width, height=src[0].rect.height)
p.show_pdf_page(p.rect, src, 0)
p.insert_font(fontname='ArialBold', fontfile='C:\\Windows\\Fonts\\arialbd.ttf')
p.insert_text((4, 14), 'A', fontname='ArialBold', fontsize=13)
dest = R / '\u56fe/Fig4A_square_compact_20261009.pdf'
assert not dest.exists()
d.save(dest, garbage=4, deflate=True)
p.get_pixmap(dpi=600, alpha=False).save(R / '\u56fe/Fig4A_square_compact_20261009_600dpi.png')
p.get_pixmap(dpi=160, alpha=False).save(R / '\u5176\u4ed6/QA/Fig4A_square_compact_20261009_preview.png')
assert 'Williams pseudobulk' not in p.get_text()
print(dest)
