from pathlib import Path
import json, hashlib
import fitz
from PIL import Image
R = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008')
A = R / '\u5176\u4ed6'
m = json.loads((A / '\u62fc\u56fe\u6765\u6e90\u4e0e\u53bb\u91cd\u6e05\u5355.json').read_text(encoding='utf-8'))
assert m['pages'] == 3
for n, count in [(4, 20), (5, 5), (6, 25)]:
    rows = [r for r in m['panels'] if r['figure'] == n]
    assert len(rows) == count
    assert ''.join((r['tag'] for r in rows)) == ''.join((chr(65 + i) for i in range(count)))
for p, h in {(r['source'], r['sha256']) for r in m['panels']}:
    assert hashlib.sha256(Path(p).read_bytes()).hexdigest() == h
checks = []
Image.MAX_IMAGE_PIXELS = 250000000
with fitz.open(m['pdf']) as d:
    assert len(d) == 3
    for i, p in enumerate(d):
        file = R / '\u56fe' / f'\u7b2c{i + 4}\u9879_\u6700\u65b0\u7248\u5b8c\u6574\u62fc\u56fe_600dpi.png'
        with Image.open(file) as im:
            im.verify()
        with Image.open(file) as im:
            assert im.width == 7500
            assert all((abs(v - 600) < 1 for v in im.info['dpi']))
            checks.append(dict(figure=i + 4, pdf_points=list(p.rect), png=str(file), pixels=list(im.size), dpi=im.info['dpi']))
        assert 'FDR' not in p.get_text()
m['visual_review'] = 'passed: all bands inspected; source label overlap/crop repaired; vector PDF preserved'
m['validation'] = checks
(A / '\u62fc\u56fe\u6765\u6e90\u4e0e\u53bb\u91cd\u6e05\u5355.json').write_text(json.dumps(m, ensure_ascii=False, indent=2), encoding='utf-8')
(A / 'QA/final_validation.json').write_text(json.dumps(dict(passed=True, pages=3, panels=50, checks=checks, original_sources_unchanged=True), ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(dict(passed=True, pages=3, panels=50, pdf=m['pdf']), ensure_ascii=False))
