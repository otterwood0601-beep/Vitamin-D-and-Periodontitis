from pathlib import Path
import fitz, json, hashlib, shutil
aux = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008\\\u5176\u4ed6')
src = Path('C:\\Users\\Lin\\AppData\\Local\\Temp\\F_hdWGCNA_compact_base_20261009.pdf')
old = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u8865\u5145\u56fe\\DLC\\6.Lin\\Fig4F_hdWGCNA_module_UMAP_compact_20261009.pdf')
backup = aux / 'QA/Fig4F_before_spacing_20261009.pdf'
if not backup.exists():
    shutil.copy2(old, backup)
d = fitz.open(src)
w, h = (d[0].rect.width, d[0].rect.height)
cw, ch = (w / 3, h / 2)
gapx, gapy, margin = (8, 10, 4)
out = fitz.open()
p = out.new_page(width=w + 2 * gapx + 2 * margin, height=h + gapy + 2 * margin)
panels = []
for r in range(2):
    for c in range(3):
        clip = fitz.Rect(c * cw, r * ch, (c + 1) * cw, (r + 1) * ch)
        x, y = (margin + c * (cw + gapx), margin + r * (ch + gapy))
        target = fitz.Rect(x, y, x + cw, y + ch)
        p.show_pdf_page(target, d, 0, clip=clip, keep_proportion=True)
        panels.append({'clip': list(clip), 'target': list(target)})
p.insert_font(fontname='ArialBold', fontfile='C:\\Windows\\Fonts\\arialbd.ttf')
p.insert_text((4, 15), 'F', fontname='ArialBold', fontsize=13)
out.set_metadata({'title': 'F - Williams hdWGCNA module-score UMAPs', 'subject': 'Original coordinates and score colors retained; 8 pt column gaps, 10 pt row gap. Four isolated cells omitted from display only.'})
stage = aux / 'F_spaced_ready_20261009.pdf'
out.save(stage, garbage=4, deflate=True)
with fitz.open(stage) as check:
    assert len(check) == 1
    assert set(check[0].get_text().split()) == {'F', 'green', 'blue', 'turquoise', 'red', 'yellow', 'brown'}
(aux / 'QA/Fig4F_spacing_validation_20261009.json').write_text(json.dumps({'source': str(src), 'stage': str(stage), 'destination': str(old), 'old_backup': str(backup), 'column_gap_pt': gapx, 'row_gap_pt': gapy, 'panels': panels, 'source_hash': hashlib.sha256(src.read_bytes()).hexdigest()}, ensure_ascii=False, indent=2), encoding='utf-8')
print(stage)
