from pathlib import Path
import sys, json, hashlib, re, textwrap
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, Normalize
import fitz
R = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
A = R / 'output/\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008/\u5176\u4ed6'
source = A / 'source_data/Williams_hdWGCNA_GO_plotted_RAWP.csv'
half_spacing = '--half-spacing' in sys.argv
stem = 'hdWGCNA_GO_combined_rawP_20261009' + ('_half_spacing' if half_spacing else '')
out = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u8865\u5145\u56fe\\DLC\\6.Lin') / (stem + '.pdf')
assert not out.exists() or '--rebuild' in sys.argv
sys.path.insert(0, str(R / 'code'))
from style_npj import set_npj_style
set_npj_style()
original = pd.read_csv(source)
modules = ['green', 'blue', 'turquoise', 'red', 'yellow', 'brown']
assert len(original) == 30 and original.groupby('module').size().eq(5).all()
assert original.p.between(0, 0.05, inclusive='neither').all()
t = pd.concat([original[original.module.eq(m)].sort_values('p', kind='stable') for m in reversed(modules)], ignore_index=True)
t['x'] = t.module.map(dict(zip(modules, range(6))))
t['y'] = np.arange(len(t))
t['log10_raw_p'] = np.log10(t.p)
t['display_term'] = t.term.str.replace(' \\(GO:\\d+\\)$', '', regex=True)
labels = list(t.display_term) if half_spacing else [textwrap.fill(s, width=74, break_long_words=False, break_on_hyphens=False) for s in t.display_term]
extra_left = 2 if half_spacing else 0
fig_width = 11 + extra_left
fig, ax = plt.subplots(figsize=(fig_width, 6.7 if half_spacing else 13.4))
fig.subplots_adjust(left=(11 * 0.515 + extra_left) / fig_width, right=(11 * 0.845 + extra_left) / fig_width, bottom=0.075, top=0.992)
cmap = LinearSegmentedColormap.from_list('reference', ['#FFF000', '#E9A4BD', '#A51CE7'], N=256)
norm = Normalize(vmin=np.floor(t.log10_raw_p.min()), vmax=np.ceil(t.log10_raw_p.max()))
area = lambda n: 36 + np.asarray(n) * 0.42
sc = ax.scatter(t.x, t.y, s=area(t.hit), c=t.log10_raw_p, cmap=cmap, norm=norm, edgecolors='#747474', linewidths=0.7, zorder=3)
ax.set_xlim(-0.6, 5.6)
ax.set_ylim(29.6, -0.6)
ax.set_xticks(range(6), modules, rotation=45, ha='right', fontsize=10)
ax.set_yticks(t.y, labels, fontsize=8.5)
if half_spacing:
    for label in ax.get_yticklabels():
        label.set_linespacing(0.7)
ax.tick_params(axis='y', length=3, pad=4)
ax.tick_params(axis='x', length=3, pad=4)
ax.set_axisbelow(True)
ax.grid(True, axis='both', color='#ECECEC', linewidth=0.65)
for spine in ax.spines.values():
    spine.set_visible(True)
    spine.set_color('#777777')
    spine.set_linewidth(0.8)
for y in [4.5, 9.5, 14.5, 19.5, 24.5]:
    ax.axhline(y, color='#CCCCCC', lw=0.8, zorder=1)
counts = [10, 100, 300, 500]
handles = [ax.scatter([], [], s=area(c), facecolors='white', edgecolors='#747474', linewidths=0.8) for c in counts]
legend = ax.legend(handles, [str(c) for c in counts], title='Count', loc='upper left', bbox_to_anchor=(1.025, 1), frameon=False, fontsize=9, title_fontsize=10, labelspacing=1.4, borderpad=0.5, handletextpad=1.1)
legend.get_title().set_fontweight('bold')
cax = fig.add_axes([(11 * 0.902 + extra_left) / fig_width, 0.3, 11 * 0.024 / fig_width, 0.34])
cb = fig.colorbar(sc, cax=cax, ticks=[-25, -20, -15, -10, -5, -2])
cb.ax.set_title('log10(raw P)', fontsize=10, fontweight='bold', pad=10)
cb.ax.tick_params(labelsize=9)
cb.outline.set_visible(False)
fig.canvas.draw()
renderer = fig.canvas.get_renderer()
boxes = [l.get_window_extent(renderer) for l in ax.get_yticklabels()]
assert all((b.x0 >= 0 for b in boxes)), 'Label clipping'
assert all((not boxes[i].overlaps(boxes[i + 1]) for i in range(len(boxes) - 1))), 'Label collision'
actual_spacing_pt = abs(ax.transData.transform((0, 1))[1] - ax.transData.transform((0, 0))[1]) * 72 / fig.dpi
original_spacing_pt = 13.4 * (0.992 - 0.075) * 72 / 30.2
assert np.isclose(actual_spacing_pt / original_spacing_pt, 0.5 if half_spacing else 1)
fig.savefig(out, bbox_inches='tight', pad_inches=0.08)
plt.close(fig)
with fitz.open(out) as d:
    assert len(d) == 1
    text = d[0].get_text()
    assert 'Count' in text and 'log10(raw P)' in text
t.to_csv(A / 'source_data' / f'{stem}.csv', index=False)
report = {'output': str(out), 'source': str(source), 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'module_count': 6, 'terms_per_module': 5, 'total_points': 30, 'raw_p_unchanged': True, 'gene_counts_unchanged': True, 'x': 'module identity', 'size': '36 + 0.42 * count (points squared)', 'color': 'log10(raw P)', 'layout': 'single shared grid, 6 groups separated by rules', 'original_preserved': True}
report.update(row_spacing_points=actual_spacing_pt, spacing_ratio=actual_spacing_pt / original_spacing_pt, label_fontsize=8.5)
(A / 'QA' / f'{stem}.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(report, ensure_ascii=False))
