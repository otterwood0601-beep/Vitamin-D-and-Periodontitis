from pathlib import Path
import fitz, hashlib, json
src = Path('C:\\Users\\Lin\\AppData\\Local\\Temp\\F_hdWGCNA_compact_base_20261009.pdf')
dest = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u8865\u5145\u56fe\\DLC\\6.Lin\\Fig4F_hdWGCNA_module_UMAP_compact_20261009.pdf')
aux = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008\\\u5176\u4ed6')
assert not dest.exists()
d = fitz.open(src)
p = d[0]
p.insert_font(fontname='ArialBold', fontfile='C:\\Windows\\Fonts\\arialbd.ttf')
p.insert_text((3, 13), 'F', fontname='ArialBold', fontsize=13)
d.set_metadata({'title': 'F - Williams hdWGCNA module-score UMAPs', 'subject': 'Data-derived contrast version matching supplied screenshots. Four isolated cells omitted from display only; all 14302 cells retained in analyses. Original coordinates and score-color limits unchanged.'})
d.save(dest, garbage=4, deflate=True)
with fitz.open(dest) as check:
    assert len(check) == 1
    assert set(check[0].get_text().split()) == {'F', 'green', 'blue', 'turquoise', 'red', 'yellow', 'brown'}
    check[0].get_pixmap(dpi=160, alpha=False).save(aux / 'QA/Fig4F_compact_preview_20261009.png')
(aux / 'QA/Fig4F_compact_validation_20261009.json').write_text(json.dumps({'output': str(dest), 'sha256': hashlib.sha256(dest.read_bytes()).hexdigest(), 'displayed_cells': 14298, 'omitted_for_display_only': 4, 'source_n_cells': 14302, 'color_mapping': 'Same limits and gradient as H contrast preview; screenshot version, not AI AB-swap schematic', 'source_data_unchanged': True}, ensure_ascii=False, indent=2), encoding='utf-8')
print(dest)
