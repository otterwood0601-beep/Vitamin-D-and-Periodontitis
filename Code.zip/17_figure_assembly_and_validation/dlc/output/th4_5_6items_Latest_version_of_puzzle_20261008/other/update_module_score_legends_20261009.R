.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(ggplot2);library(grid)})
aux <- 'C:/wb_links/panel456_20261008'
src <- 'C:/wb_links/dlc/code/tranoncol2026/03_figures.R'

for(ex in parse(src)) {
 if(is.call(ex) && identical(ex[[1]],as.name('<-')) && is.symbol(ex[[2]]) &&
    as.character(ex[[2]]) %in% c('FONT','TYPE_COLORS','MODULE_COLORS','theme_article')) eval(ex)
}
mods <- names(MODULE_COLORS)
ms <- fread('C:/wb_links/dlc/data_derived/tranoncol2026_Williams_20260920/27_hdWGCNA_module_by_subtype_summary.csv')
ms <- ms[module %in% mods]
ms[, mean_z := as.numeric(scale(mean_score)), by=module]
ms[, module := factor(module,levels=rev(mods))]
ms[, fibroblast_short := factor(fibroblast_short,levels=names(TYPE_COLORS))]
stopifnot(nrow(ms)==30)
p <- ggplot(ms,aes(fibroblast_short,module)) +
 geom_point(aes(size=pct_positive*100,colour=mean_z)) +
 scale_colour_gradient2(low='#5077A6',mid='#E5E5E5',high='#BD3F39',midpoint=0,
                        name='Mean score\n(row Z-score)',breaks=c(-1.5,0,1.5)) +
 scale_size_continuous(range=c(1.6,8),name='Score > 0\n(% cells)',breaks=c(99.3,99.6,100),labels=c('99.3','99.6','100')) +
 labs(x=NULL,y='Features',title=NULL) + theme_article +
 theme(axis.text=element_text(size=9),axis.title=element_text(size=10),
       axis.text.x=element_text(angle=45,hjust=1,size=8),
       legend.title=element_text(size=7.5),legend.text=element_text(size=7),
       legend.position='right',legend.box='vertical',
       legend.key=element_rect(fill='white',colour=NA),
       legend.background=element_rect(fill='white',colour=NA),
       legend.spacing.y=unit(7,'pt'),aspect.ratio=1.45) +
 guides(colour=guide_colourbar(order=1,barheight=unit(40,'pt'),barwidth=unit(7,'pt')),
        size=guide_legend(order=2,override.aes=list(colour='#555555'),keyheight=unit(25,'pt')))
out <- file.path(aux,'Fig4G_hdWGCNA_module_scores_legend_20261009.pdf')
ggsave(out,p,device=cairo_pdf,width=4.4,height=4.8,units='in',family='Arial',bg='white')
fwrite(ms,file.path(aux,'source_data/Fig4G_module_scores_legend_20261009.csv'))
cat(out,'\n')
