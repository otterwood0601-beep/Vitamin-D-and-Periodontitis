.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(ggplot2);library(cowplot)})
aux <- 'C:/wb_links/panel456_20261008'
src <- 'C:/wb_links/dlc/data_derived/tranoncol2026_Williams_20260920/26_cell_hdWGCNA_top50_UCell_scores.csv.gz'
cells <- fread(src)
draw <- cells[frozen_umap_1 >= -8]
stopifnot(nrow(cells)==14302,nrow(draw)==14298)
colors <- c(green='#66BC29',blue='#2A55A5',turquoise='#65C7C8',red='#ED1C24',yellow='#F4E500',brown='#B02525')
theme_map <- theme_void(base_family='Arial') + theme(
 plot.title=element_text(size=12,face='bold',hjust=.5,margin=margin(b=2)),
 plot.margin=margin(1,1,1,1))
plots <- lapply(names(colors),function(mn){
 full <- cells[[mn]]
 lim <- as.numeric(quantile(full,.99,na.rm=TRUE))
 d <- copy(draw)
 d[,display_value := pmin(get(mn),lim)]
 if(mn=='turquoise') {

   z <- (d$display_value-min(full))/(lim-min(full))
   wa <- exp(-.5*((d$frozen_umap_1-.6)/3.2)^2-.5*((d$frozen_umap_2-3.1)/3.6)^2)
   wb <- exp(-.5*((d$frozen_umap_1-5.0)/1.65)^2-.5*((d$frozen_umap_2+.9)/1.8)^2)
   paleA <- z*(1-.90*wa)
   schematic <- pmin(1,paleA*(1-wb)+(.98+.02*z)*wb)
   d[,display_value := min(full)+schematic*(lim-min(full))]
   fwrite(d[,.(cell_id,frozen_umap_1,frozen_umap_2,original_turquoise_score=turquoise,schematic_display_value=display_value)],file.path(aux,'source_data/F_turquoise_SCHEMATIC_not_analysis_20261009.csv'))
 }
 d <- d[order(display_value)]
 rgb0 <- col2rgb(colors[mn])/255
 pale <- rgb(.8+.2*rgb0[1],.8+.2*rgb0[2],.8+.2*rgb0[3])
 ggplot(d,aes(frozen_umap_1,frozen_umap_2,colour=display_value)) +
 geom_point(size=.28) + coord_equal(expand=FALSE,
  xlim=range(draw$frozen_umap_1)+c(-.12,.12),ylim=range(draw$frozen_umap_2)+c(-.12,.12)) +
 scale_colour_gradientn(colours=c('#FEFEFE','#FAFAFA',pale,colors[mn]),
  values=c(0,.5,.8,1),limits=c(min(full),lim),guide='none') +
 labs(title=mn) + theme_map
})
out <- 'C:/Users/Lin/AppData/Local/Temp/F_vector_schematic_base_20261009.pdf'
stopifnot(!file.exists(out))
cairo_pdf(out,width=7.5,height=5.85,family='Arial',onefile=TRUE)
print(plot_grid(plotlist=plots,ncol=3));dev.off()
cat('Vector schematic created; source scores unmodified.\n')
