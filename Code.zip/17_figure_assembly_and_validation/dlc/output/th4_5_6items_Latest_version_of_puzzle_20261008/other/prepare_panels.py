from pathlib import Path
import ast, json, sys, hashlib
import numpy as np
import pandas as pd
from scipy.stats import hypergeom
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm, LogNorm
import fitz
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
OUT = ROOT / 'output/\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008'
AUX = OUT / '\u5176\u4ed6'
PAN = AUX / '\u62fc\u56fe\u7d20\u6750'
DATA = AUX / 'source_data'
for d in (PAN, DATA, OUT / '\u56fe', AUX / 'QA'):
    d.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT / 'code'))
from style_npj import set_npj_style, strip_header
set_npj_style()
plt.rcParams.update({'font.size': 7, 'axes.labelsize': 7, 'xtick.labelsize': 6, 'ytick.labelsize': 6})

def save(fig, name):
    path = PAN / name
    fig.savefig(path, bbox_inches='tight', pad_inches=0.07)
    plt.close(fig)
    return path
tree = ast.parse((ROOT / 'code/B4_mapk_ecm.py').read_text(encoding='utf-8-sig'))
sets = {}
for node in tree.body:
    if isinstance(node, ast.Assign) and any((isinstance(t, ast.Name) and t.id in ['ECM_SETS', 'MAPK_SET'] for t in node.targets)):
        sets.update(ast.literal_eval(node.value))
(DATA / 'reused_B4_program_sets.json').write_text(json.dumps(sets, indent=2), encoding='utf-8')
rank = pd.read_csv(ROOT / 'P3_WGCNA_Williams_20261008_RAWP/\u5176\u4ed6/source_data/08_A_shared_gene_effects_RAWP.csv')
assert rank.gene.is_unique and len(rank) == 11444
rank[['gene', 't', 'stat_vd']].to_csv(DATA / 'Williams_Zhang_rankings.csv', index=False)
print('Ranks and original program sets ready', flush=True)
import decoupler as dc
net = pd.read_csv(ROOT / 'data_derived/B4_PROGENy_human_top500_network.csv')
net = net[net.target.isin(rank.gene)].copy()
ulm = []
for tag, col in [('Periodontitis', 't'), ('VitaminD3', 'stat_vd')]:
    mat = rank.set_index('gene')[[col]].T
    est, pvals = dc.mt.ulm(mat, net, verbose=False)
    for pathway in est.columns:
        ulm.append(dict(pathway=pathway, dataset=tag, activity=float(est[pathway].iloc[0]), p=float(pvals[pathway].iloc[0])))
ulm = pd.DataFrame(ulm)
ulm.to_csv(DATA / 'PROGENy_Williams_Zhang_RAWP.csv', index=False)
print('PROGENy Williams-only complete', flush=True)
SD = ROOT / 'P2_hdWGCNA_Williams_20260920/outputs/02_source_data'
hub = pd.read_csv(SD / '05_hub_genes.csv')
colors = {'green': '#66BC29', 'blue': '#2A55A5', 'turquoise': '#65C7C8', 'red': '#ED1C24', 'yellow': '#F4E500', 'brown': '#B02525'}
fig, axes = plt.subplots(2, 3, figsize=(5.6, 2.6))
for ax, (mod, color) in zip(axes.flat, colors.items()):
    z = hub[hub.module.eq(mod)].nlargest(7, 'kME').sort_values('kME')
    ax.barh(z.gene_name, z.kME, color=color, height=0.7)
    ax.set_title(mod, fontsize=7)
    ax.set_xlabel('kME', fontsize=6)
    ax.tick_params(labelsize=5)
    ax.spines[['top', 'right']].set_visible(False)
fig.tight_layout(pad=0.7, w_pad=0.5, h_pad=0.7)
save(fig, 'Williams_hdWGCNA_correct_hubs.pdf')
mem = pd.read_csv(SD / '03_module_gene_membership.csv')
universe = set(mem.gene_name.dropna())
go = {}
gmt = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20\\\u539f\u59cb\u6570\u636e\\05_\u5355\u7ec6\u80deRNA\\gene_sets\\GO_Biological_Process_2025.gmt')
for line in gmt.read_text(encoding='utf-8-sig').splitlines():
    cols = line.split('\t')
    genes = set(cols[2:]) & universe
    if genes:
        go[cols[0]] = genes
ugo = set().union(*go.values())
rows = []
for mod in colors:
    qg = set(mem.loc[mem.module.eq(mod), 'gene_name']) & ugo
    for term, tg in go.items():
        hit = len(qg & tg)
        if not hit:
            continue
        p = float(hypergeom.sf(hit - 1, len(ugo), len(tg), len(qg)))
        rows.append(dict(module=mod, term=term, hit=hit, term_size=len(tg), query_size=len(qg), universe=len(ugo), p=p, fold=hit / len(qg) / (len(tg) / len(ugo))))
ora = pd.DataFrame(rows)
ora.to_csv(DATA / 'Williams_hdWGCNA_GO_all_RAWP.csv', index=False)
oldgo = pd.read_csv(SD / '06_module_GO_BP_enrichment.csv')
check = oldgo[['module', 'term', 'p', 'fold']].merge(ora[['module', 'term', 'p', 'fold']], on=['module', 'term'], suffixes=('_old', '_new'))
assert len(check) == len(oldgo)
assert np.allclose(check.p_old, check.p_new, rtol=1e-08, atol=1e-280)
assert np.allclose(check.fold_old, check.fold_new, rtol=1e-08)
tops = ora[ora.p.lt(0.05)].sort_values('p').groupby('module', sort=False).head(5)
tops.to_csv(DATA / 'Williams_hdWGCNA_GO_plotted_RAWP.csv', index=False)
fig, axes = plt.subplots(len(colors), 1, figsize=(7, 5.7), gridspec_kw={'height_ratios': [max(len(tops[tops.module.eq(m)]), 1) for m in colors]})
norm = LogNorm(vmin=max(tops.p.min(), 1e-300), vmax=0.05)
for ax, (mod, color) in zip(np.ravel(axes), colors.items()):
    z = tops[tops.module.eq(mod)].sort_values('p', ascending=False)
    label = z.term.str.replace(' \\(GO:\\d+\\)$', '', regex=True)
    sc = ax.scatter(z.fold, range(len(z)), c=z.p, s=np.sqrt(z.hit) * 5, cmap='magma_r', norm=norm)
    ax.set_yticks(range(len(z)), label, fontsize=5)
    ax.set_title(mod, loc='right', fontsize=6, color=color, fontweight='bold')
    ax.spines[['top', 'right']].set_visible(False)
    ax.set_xlim(0, max(ora.fold.quantile(0.98), tops.fold.max()) * 1.05)
axes[-1].set_xlabel('Fold enrichment', fontsize=7)
fig.subplots_adjust(left=0.64, right=0.9, top=0.98, bottom=0.08, hspace=0.75)
cb = fig.colorbar(sc, cax=fig.add_axes([0.93, 0.18, 0.015, 0.55]))
cb.set_label('Raw P', fontsize=7)
save(fig, 'Williams_hdWGCNA_GO_RAWP.pdf')
vde = pd.read_csv(ROOT / 'data_derived/tranoncol2026_Williams_20260920/08_vascular_vs_other_donor_aware_DE.csv.gz')
vde[['gene', 'logFC', 'P.Value', 'diff_detection']].to_csv(DATA / 'Williams_vascular_existing_DE_RAWP.csv', index=False)
fig, ax = plt.subplots(figsize=(2.8, 3.25))
cmap = matplotlib.colors.LinearSegmentedColormap.from_list('ref', ['#31558C', '#F7F2E8', '#B63B36'])
sc = ax.scatter(vde.diff_detection, -np.log10(vde['P.Value'].clip(lower=1e-300)), c=vde.logFC, s=2, alpha=0.65, cmap=cmap, norm=TwoSlopeNorm(vmin=min(-1, vde.logFC.min()), vcenter=0, vmax=max(1, vde.logFC.max())))
ax.axhline(-np.log10(0.05), lw=0.35, c='#555555')
ax.axvline(0, lw=0.35, c='#555555')
ax.set_xlabel('Difference in detection fraction')
ax.set_ylabel('-log10(raw P)')
ax.set_title('Vascular vs other fibroblast states', fontsize=7)
labs = vde.nsmallest(6, 'P.Value')
for _, z in labs.iterrows():
    ax.annotate(z.gene, (z.diff_detection, -np.log10(z['P.Value'])), xytext=(3, 2), textcoords='offset points', fontsize=5)
fig.colorbar(sc, ax=ax, shrink=0.55, label='log2FC')
save(fig, 'Williams_vascular_volcano_RAWP.pdf')
ref = ROOT / 'output/\u539f\u6587\u683c\u5f0f\u8fc1\u79fb_GDF15_ERK/Williams\u7edf\u4e00\u91cd\u5206\u6790_20260920/Reference_Fig5_style_hdWGCNA_GDF15_ERK_module_20260915_Williams_20260920.pdf'
old = fitz.open(ref)
corrected = fitz.open()
p = corrected.new_page(width=480, height=445)
p.show_pdf_page(p.rect, old, 0)
p.draw_rect(fitz.Rect(0, 0, 480, 151), color=None, fill=(1, 1, 1), overlay=True)
td = fitz.open(ROOT / 'P2_hdWGCNA_Williams_20260920/outputs/figures/\u56feP2C_\u6a21\u5757\u6811.pdf')
p.show_pdf_page(fitz.Rect(4, 18, 180, 145), td, 0)
hb = fitz.open(PAN / 'Williams_hdWGCNA_correct_hubs.pdf')
p.show_pdf_page(fitz.Rect(190, 14, 477, 147), hb, 0)
p.insert_font(fontname='ArialBold', fontfile='C:\\Windows\\Fonts\\arialbd.ttf')
p.insert_text((2, 12), 'A', fontname='ArialBold', fontsize=12)
p.insert_text((185, 12), 'B', fontname='ArialBold', fontsize=12)
corrected.save(PAN / 'Williams_hdWGCNA_summary_input_corrected.pdf', garbage=4, deflate=True)
notes = dict(disease='Williams gingival fibroblast pseudobulk, conservative 18 sample-ID groups', vitaminD='Zhang/GSE212728 D3 vs ethanol, one donor, 3+2 cultures', shared_genes=len(rank), program_sets='Exact original B4 sets reused; manually predefined, not WGCNA modules', progeny='Original decoupler mt.ulm with pinned official human top500 network', GO='Same original full gene universe and GO2025 hypergeometric test, raw P<0.05 top5 per module; saved historical P and fold independently reproduced', corrected_hd_inputs='Historical Fig5 A/B hard-coded original all-study paths replaced with Williams dendrogram and Williams kME hubs', progeny_results=ulm[ulm.pathway.eq('MAPK')].to_dict('records'))
(DATA / 'panel_update_provenance.json').write_text(json.dumps(notes, ensure_ascii=False, indent=2), encoding='utf-8')
print('Preparation done: correct Williams HD bindings, raw-P GO and vascular plot', flush=True)
