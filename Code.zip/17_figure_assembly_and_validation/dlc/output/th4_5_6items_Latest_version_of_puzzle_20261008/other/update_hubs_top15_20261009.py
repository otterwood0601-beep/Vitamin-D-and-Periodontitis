from pathlib import Path
import sys, json, hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import fitz
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
AUX = ROOT / 'output/\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008/\u5176\u4ed6'
SD = ROOT / 'P2_hdWGCNA_Williams_20260920/outputs/02_source_data'
TOP_N = int(sys.argv[1]) if len(sys.argv) > 1 else 15
assert TOP_N in (15, 20)
DEST = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u8865\u5145\u56fe\\DLC\\6.Lin') / f'Fig4E_hdWGCNA_top{TOP_N}_hubs_20261009.pdf'
assert not DEST.exists()
sys.path.insert(0, str(ROOT / 'code'))
from style_npj import set_npj_style
set_npj_style()
membership = pd.read_csv(SD / '03_module_gene_membership.csv')
old = pd.read_csv(SD / '05_hub_genes.csv')
colors = {'green': '#66BC29', 'blue': '#2A55A5', 'turquoise': '#65C7C8', 'red': '#ED1C24', 'yellow': '#F4E500', 'brown': '#B02525'}
fig, axes = plt.subplots(2, 3, figsize=(7.5, 5.9 + (TOP_N - 15) * 0.34))
plotted = []
for ax, (mod, color) in zip(axes.flat, colors.items()):
    z = membership.loc[membership.module.eq(mod), ['gene_name', 'module', 'kME_' + mod]].rename(columns={'kME_' + mod: 'kME'})
    assert z.gene_name.is_unique and z.kME.notna().all() and (len(z) >= TOP_N)
    oldmod = old[old.module.eq(mod)].sort_values('kME', ascending=False)
    ranked = z.sort_values('kME', ascending=False, kind='stable')
    assert set(ranked.head(10).gene_name) == set(oldmod.gene_name)
    check = oldmod.merge(z, on=['gene_name', 'module'], suffixes=('_old', '_full'))
    assert np.allclose(check.kME_old, check.kME_full, rtol=1e-12, atol=1e-14)
    top = ranked.head(TOP_N).copy()
    top['rank'] = range(1, TOP_N + 1)
    plotted.append(top)
    bars = top.sort_values('kME', kind='stable')
    ax.barh(bars.gene_name, bars.kME, color=color, height=0.7)
    ax.set_title(mod, fontsize=9)
    ax.set_xlabel('kME', fontsize=8)
    ax.tick_params(labelsize=7)
    ax.spines[['top', 'right']].set_visible(False)
    ax.set_xlim(left=0)
    ax.margins(y=0.025)
fig.tight_layout(pad=0.9, w_pad=1.3, h_pad=1.4)
fig.savefig(DEST, bbox_inches='tight', pad_inches=0.07)
plt.close(fig)
table = pd.concat(plotted, ignore_index=True)
assert len(table) == 6 * TOP_N and table.groupby('module').size().eq(TOP_N).all()
table.to_csv(AUX / f'source_data/Fig4E_hdWGCNA_top{TOP_N}_hubs_20261009.csv', index=False)
with fitz.open(DEST) as doc:
    assert len(doc) == 1
    txt = doc[0].get_text()
    assert all((g in txt for g in table.gene_name))
report = {'output': str(DEST), 'source': str(SD / '03_module_gene_membership.csv'), 'source_sha256': hashlib.sha256((SD / '03_module_gene_membership.csv').read_bytes()).hexdigest(), 'panels': 6, 'genes_per_panel': TOP_N, 'total_bars': 6 * TOP_N, 'top10_matches_previous': True, 'ranking': 'descending signed within-module kME', 'original_outputs_preserved': True}
(AUX / f'QA/Fig4E_top{TOP_N}_validation_20261009.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(report, ensure_ascii=False))
