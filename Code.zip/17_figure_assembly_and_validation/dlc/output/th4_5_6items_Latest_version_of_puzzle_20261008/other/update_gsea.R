.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5','C:/Users/Lin/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(fgsea);library(data.table);library(jsonlite)})
args <- commandArgs(trailingOnly=TRUE)
root <- args[1]
sets <- fromJSON(file.path(root,'source_data','reused_B4_program_sets.json'))
r <- fread(file.path(root,'source_data','Williams_Zhang_rankings.csv'))
set.seed(20261008L)
res <- rbindlist(lapply(c('t','stat_vd'),function(v){
 s <- setNames(r[[v]],r$gene)
 g <- fgseaMultilevel(sets,stats=s,minSize=5,maxSize=2000,nproc=1,eps=1e-30)
 g[,dataset:=if(v=='t')'Periodontitis' else 'VitaminD3']
 g[,padj:=NULL]
 g[,leadingEdge:=vapply(leadingEdge,paste,collapse=';',FUN.VALUE=character(1))]
 g
}))
fwrite(res,file.path(root,'source_data','GSEA_Williams_Zhang_RAWP.csv'))
print(res[,.(dataset,pathway,NES,pval,size)])
cat('[DONE] Williams-only raw-P program GSEA\n')
