from pathlib import Path
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
AUX = ROOT / 'output/\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008/\u5176\u4ed6'
PAN = AUX / '\u62fc\u56fe\u7d20\u6750'
DATA = AUX / 'source_data'
sys.path.insert(0, str(ROOT / 'code'))
from style_npj import set_npj_style, strip_header
set_npj_style()
gsea = pd.read_csv(DATA / 'GSEA_Williams_Zhang_RAWP.csv')
terms = ['ECM synthesis/assembly', 'ECM protease inhibitors', 'ECM adhesion/signaling', 'ECM proteases (degradation)', 'MAPK/ERK immediate response']
piv = gsea.pivot(index='pathway', columns='dataset', values='NES').reindex(terms)[['Periodontitis', 'VitaminD3']]
pv = gsea.pivot(index='pathway', columns='dataset', values='pval').reindex(terms)[['Periodontitis', 'VitaminD3']]
fig, ax = plt.subplots(figsize=(3.7, 3.05))
im = ax.imshow(piv, cmap='RdBu_r', vmin=-3, vmax=3, aspect='auto')
ax.set_xticks([0, 1], ['Disease\n(PD-healthy)', 'Vitamin D3\n(D3-ethanol)'])
ax.set_yticks(range(5), ['ECM synthesis', 'ECM inhibitors', 'ECM adhesion', 'ECM proteases', 'MAPK/ERK response'])
ax.tick_params(length=0, labelsize=7)
for i in range(5):
    for j in range(2):
        p = pv.iloc[i, j]
        star = '***' if p < 0.001 else '**' if p < 0.01 else '*' if p < 0.05 else ''
        ax.text(j, i, f'{piv.iloc[i, j]:.2f}\n{star}', ha='center', va='center', fontsize=7, color='white' if abs(piv.iloc[i, j]) > 1.8 else 'black')
strip_header(ax, 'Program GSEA - Williams + Zhang')
fig.colorbar(im, ax=ax, shrink=0.75, label='NES')
fig.text(0.05, 0.01, 'Stars: raw P. Manually predefined original B4 programs.', fontsize=6)
fig.tight_layout(rect=[0, 0.05, 1, 1])
fig.savefig(PAN / 'MAPK_ECM_GSEA_Williams_RAWP.pdf', bbox_inches='tight', pad_inches=0.08)
plt.close(fig)
import json
sets = json.loads((DATA / 'reused_B4_program_sets.json').read_text())
genes = sets['MAPK/ERK immediate response']
r = pd.read_csv(DATA / 'Williams_Zhang_rankings.csv').set_index('gene')
genes = [g for g in genes if g in r.index]
d = r.loc[genes, ['t', 'stat_vd']]
fig, ax = plt.subplots(figsize=(2.7, 3.8))
im = ax.imshow(d, cmap='RdBu_r', vmin=-8, vmax=8, aspect='auto')
ax.set_yticks(range(len(d)), d.index, fontsize=6)
ax.set_xticks([0, 1], ['Disease t', 'VD3 stat'], fontsize=7)
ax.tick_params(length=0)
strip_header(ax, 'MAPK/ERK response genes')
fig.colorbar(im, ax=ax, shrink=0.6, label='Statistic')
fig.tight_layout()
fig.savefig(PAN / 'MAPK_gene_heatmap_Williams.pdf', bbox_inches='tight', pad_inches=0.08)
plt.close(fig)
pro = pd.read_csv(DATA / 'PROGENy_Williams_Zhang_RAWP.csv')
score = pro.pivot(index='pathway', columns='dataset', values='activity')[['Periodontitis', 'VitaminD3']]
pp = pro.pivot(index='pathway', columns='dataset', values='p')[['Periodontitis', 'VitaminD3']]
score = score.sort_values('Periodontitis')
pp = pp.reindex(score.index)
fig, ax = plt.subplots(figsize=(4.0, 3.1))
im = ax.imshow(score, cmap='RdBu_r', vmin=-15, vmax=15, aspect='auto')
ax.set_xticks([0, 1], ['Disease\n(PD-healthy)', 'Vitamin D3\n(D3-ethanol)'])
ax.set_yticks(range(len(score)), score.index, fontsize=7)
ax.tick_params(length=0, labelsize=7)
for i in range(len(score)):
    for j in range(2):
        p = pp.iloc[i, j]
        star = '***' if p < 0.001 else '**' if p < 0.01 else '*' if p < 0.05 else ''
        ax.text(j, i, f'{score.iloc[i, j]:.2f}{star}', ha='center', va='center', fontsize=6, color='white' if abs(score.iloc[i, j]) > 9 else 'black')
strip_header(ax, 'PROGENy transcriptional footprint')
fig.colorbar(im, ax=ax, shrink=0.75, label='ULM activity')
fig.text(0.03, 0.01, 'Human top500 genes/pathway; stars: raw P.', fontsize=6)
fig.tight_layout(rect=[0, 0.05, 1, 1])
fig.savefig(PAN / 'PROGENy_Williams_RAWP.pdf', bbox_inches='tight', pad_inches=0.08)
plt.close(fig)
print('Latest gingiva-only GSEA, gene heatmap and PROGENy panels ready')
