.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(Seurat);library(Matrix);library(data.table)})
source('C:/wb_links/dlc_config/project_paths.R',encoding='UTF-8')
out <- 'C:/wb_links/panel456_20261008/module_specific_20261009'
dir.create(out,showWarnings=FALSE,recursive=TRUE)
cat('Loading existing annotated expression object\n');flush.console()
obj <- readRDS(file.path(WORK,'01_\u6570\u636e\u51c6\u5907/outputs/fb_seurat_annotated.rds'))
meta <- obj[[]]
use <- rownames(meta)[as.character(meta$Study)=='Williams']
stopifnot(length(use)==14302)
mem <- fread('C:/wb_links/dlc/P2_hdWGCNA_Williams_20260920/outputs/02_source_data/03_module_gene_membership.csv')
mem <- mem[module!='grey']
expr <- GetAssayData(obj,assay='RNA',layer='data')[mem$gene_name,use,drop=FALSE]
meta <- meta[use,,drop=FALSE]
cat('Cell types:',paste(unique(meta$fibroblast_type),collapse='; '),'\n');flush.console()
ans <- lapply(unique(as.character(meta$fibroblast_type)),function(ct){
 x <- expr[,as.character(meta$fibroblast_type)==ct,drop=FALSE]
 lin <- x;lin@x <- expm1(lin@x)
 data.table(gene=rownames(x),celltype=ct,n_cells=ncol(x),mean_log=Matrix::rowMeans(x),mean_linear=Matrix::rowMeans(lin),pct=100*Matrix::rowMeans(x>0))
})
dt <- rbindlist(ans)
dt <- merge(dt,mem[,.(gene=gene_name,module)],by='gene',all.x=TRUE)
dt[,max_other_mean:=vapply(seq_len(.N),function(i)max(mean_linear[-i]),numeric(1)),by=gene]
dt[,ratio:=mean_linear/pmax(max_other_mean,1e-8)]
dt[,eligible:=ratio>=2 & pct>=10]
fwrite(dt,file.path(out,'all_module_gene_celltype_expression.csv'))
eligible <- dt[eligible==TRUE]
fwrite(eligible,file.path(out,'eligible_specific_genes.csv'))
summary <- eligible[,.(n_eligible=.N,median_ratio=median(ratio)),by=.(module,celltype)]
setorder(summary,module,-n_eligible,-median_ratio)
fwrite(summary,file.path(out,'eligible_counts_by_module_celltype.csv'))
targets <- summary[,head(.SD,1),by=module]
selected <- merge(eligible,targets[,.(module,celltype)],by=c('module','celltype'))
setorder(selected,module,-ratio,-pct)
selected <- selected[,head(.SD,6),by=module]
fwrite(selected,file.path(out,'selected_specific_genes.csv'))
fwrite(dt[gene %in% selected$gene],file.path(out,'selected_genes_plot_data.csv'))
print(summary)
cat('Selected genes\n');print(selected[,.(module,celltype,gene,ratio,pct)])
cat('Module sizes\n');print(mem[,.N,by=module])
