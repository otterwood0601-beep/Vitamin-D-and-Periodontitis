from pathlib import Path
import hashlib, json
import fitz
import numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter
aux = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008\\\u5176\u4ed6')
base = fitz.open('C:\\Users\\Lin\\AppData\\Local\\Temp\\F_vector_schematic_base_20261009.pdf')
replacement = fitz.open('C:\\Users\\Lin\\AppData\\Local\\Temp\\F_turquoise_pixel_matched_20261009.pdf')
previous = fitz.open(aux / 'F_vector_SCHEMATIC_ABswap_20261009.pdf')
w, h = (base[0].rect.width, base[0].rect.height)
cw, ch = (w / 3, h / 2)
gapx, gapy, margin = (8, 10, 4)
out = fitz.open()
p = out.new_page(width=w + 2 * gapx + 2 * margin, height=h + gapy + 2 * margin)
rects = {}
for r in range(2):
    for c in range(3):
        x, y = (margin + c * (cw + gapx), margin + r * (ch + gapy))
        target = fitz.Rect(x, y, x + cw, y + ch)
        rects[r, c] = target
        if (r, c) == (0, 2):
            p.show_pdf_page(target, replacement, 0, keep_proportion=False)
        else:
            clip = fitz.Rect(c * cw, r * ch, (c + 1) * cw, (r + 1) * ch)
            p.show_pdf_page(target, base, 0, clip=clip)
p.insert_font(fontname='ArialBold', fontfile='C:\\Windows\\Fonts\\arialbd.ttf')
p.insert_text((4, 15), 'F', fontname='ArialBold', fontsize=13)
out.set_metadata({'title': 'Figure 4F - pixel-matched vector schematic', 'subject': 'User-authorized schematic, NOT analytical scores. Turquoise illustrative colors sampled from reference pixels; original cell coordinates retained. Four isolated cells omitted from display only. Other five panels unchanged.'})
stage = aux / 'F_vector_SCHEMATIC_pixelmatched_20261009.pdf'
out.save(stage, garbage=4, deflate=True)
check = fitz.open(stage)
assert len(check) == 1 and len(check[0].get_images(full=True)) == 0
assert set(check[0].get_text().split()) == {'F', 'green', 'blue', 'turquoise', 'red', 'yellow', 'brown'}
assert check[0].rect == previous[0].rect
old = previous[0].get_pixmap(dpi=144, alpha=False)
new = check[0].get_pixmap(dpi=144, alpha=False)
oldarr = np.frombuffer(old.samples, np.uint8).reshape(old.height, old.width, 3)
newarr = np.frombuffer(new.samples, np.uint8).reshape(new.height, new.width, 3)
unchanged = {}
for key, rect in rects.items():
    if key == (0, 2):
        continue
    x0, y0, x1, y1 = map(lambda z: int(round(z * 2)), rect)
    unchanged[str(key)] = bool(np.array_equal(oldarr[y0:y1, x0:x1], newarr[y0:y1, x0:x1]))
assert all(unchanged.values()), unchanged
check[0].get_pixmap(dpi=160, alpha=False).save(aux / 'QA/F_pixelmatched_full_preview_20261009.png')
ref = Image.open('C:\\Users\\Lin\\AppData\\Local\\Temp\\codex-clipboard-ebf329dd-1fa0-46ef-ac47-5e6ca0992eee.png').convert('RGB')
refbox = (59, 3, 740, 765)
refcrop = ref.crop(refbox).resize((500, 560), Image.Resampling.LANCZOS)

def panel_plot(page):
    pix = page.get_pixmap(matrix=fitz.Matrix(4, 4), clip=rects[0, 2], alpha=False)
    ar = np.frombuffer(pix.samples, np.uint8).reshape(pix.height, pix.width, 3).copy()
    ar = ar[70:, :, :]
    chroma = (ar[:, :, 1].astype(float) + ar[:, :, 2].astype(float)) / 2 - ar[:, :, 0]
    yy, xx = np.where(gaussian_filter(chroma, 1) > 1.5)
    return Image.fromarray(ar).crop((xx.min(), yy.min(), xx.max() + 1, yy.max() + 1)).resize((500, 560), Image.Resampling.LANCZOS)
oldplot = panel_plot(previous[0])
newplot = panel_plot(check[0])
reference = np.asarray(refcrop, dtype=float)

def metrics(im):
    a = np.asarray(im, dtype=float)
    smootha = gaussian_filter(a, sigma=(10, 10, 0))
    smoothr = gaussian_filter(reference, sigma=(10, 10, 0))
    return {'regional_rgb_MAE_0_to_255': float(np.abs(smootha - smoothr).mean()), 'regional_rgb_RMSE_0_to_255': float(np.sqrt(((smootha - smoothr) ** 2).mean()))}
comparison = Image.new('RGB', (1500, 560), 'white')
for x, im in zip((0, 500, 1000), (refcrop, oldplot, newplot)):
    comparison.paste(im, (x, 0))
comparison.save(aux / 'QA/F_reference_old_new_pixel_comparison_20261009.png')
audit = {'pdf': str(stage), 'embedded_raster_images': 0, 'editable_text': True, 'kind': 'schematic, not analytical', 'displayed_cells_per_panel': 14298, 'unchanged_five_panels_pixel_identical': unchanged, 'reference_pixels_analyzed': 640044, 'comparison_method': 'Foreground bounding-box registration to 500x560, RGB Gaussian sigma 10 px; regional color similarity only, not exact dot identity. Reference / old / new in QA triptych.', 'old_vs_reference': metrics(oldplot), 'new_vs_reference': metrics(newplot), 'sha256': hashlib.sha256(stage.read_bytes()).hexdigest()}
(aux / 'QA/F_pixelmatched_vector_validation_20261009.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(audit, ensure_ascii=False, indent=2))
