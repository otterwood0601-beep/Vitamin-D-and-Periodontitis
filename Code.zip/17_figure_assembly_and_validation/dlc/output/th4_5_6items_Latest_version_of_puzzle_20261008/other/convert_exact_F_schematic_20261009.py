from pathlib import Path
from PIL import Image
import fitz, io, shutil, json, hashlib
src = Path('C:\\Users\\Lin\\AppData\\Local\\Temp\\codex-clipboard-1f6e4538-bedf-4d04-aefe-e1acd1cc11e8.png')
aux = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008\\\u5176\u4ed6')
dest = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u8865\u5145\u56fe\\DLC\\6.Lin\\Fig4F_hdWGCNA_module_UMAP_compact_20261009.pdf')
backup = aux / 'QA/Fig4F_data_plot_before_requested_schematic_replacement_20261009.pdf'
if not backup.exists():
    shutil.copy2(dest, backup)
with Image.open(src) as im:
    rgb = im.convert('RGB')
    width, height = rgb.size
    original_pixels = rgb.tobytes()
d = fitz.open()
p = d.new_page(width=540, height=540 * height / width)
p.insert_image(p.rect, filename=str(src), keep_proportion=True)
d.set_metadata({'title': 'Figure 4F - user-selected schematic illustration', 'subject': 'Exact raster supplied by user. Illustrative spatial color modification; not a data-derived result. No in-image annotations added.'})
stage = aux / 'F_exact_requested_schematic_20261009.pdf'
d.save(stage, garbage=4, deflate=True)
with fitz.open(stage) as check:
    assert len(check) == 1
    images = check[0].get_images(full=True)
    assert len(images) == 1
    extracted = check.extract_image(images[0][0])
    with Image.open(io.BytesIO(extracted['image'])) as embed:
        assert embed.convert('RGB').tobytes() == original_pixels
    assert not check[0].get_text().strip()
shutil.copyfile(stage, dest)
assert hashlib.sha256(stage.read_bytes()).digest() == hashlib.sha256(dest.read_bytes()).digest()
(aux / 'QA/Fig4F_exact_requested_schematic_validation_20261009.json').write_text(json.dumps({'source_image': str(src), 'source_sha256': hashlib.sha256(src.read_bytes()).hexdigest(), 'output': str(dest), 'pixels_identical': True, 'width_px': width, 'height_px': height, 'kind': 'user-requested illustrative variant, not data-derived', 'previous_pdf_backup': str(backup)}, ensure_ascii=False, indent=2), encoding='utf-8')
print('Verified exact source pixels and replaced: ' + str(dest))
