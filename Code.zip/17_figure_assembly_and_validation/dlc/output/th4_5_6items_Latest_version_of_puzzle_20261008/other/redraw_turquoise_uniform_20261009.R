options(stringsAsFactors=FALSE)
.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5','C:/Users/Lin/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(ggplot2);library(ggrepel);library(igraph)})
ROOT <- 'C:/wb_links/dlc'
DAT <- file.path(ROOT,'data_derived/tranoncol2026_Williams_20260920')
OUT <- 'C:/wb_links/panel456_20261008'
FONT <- 'Arial'
tn <- fread(file.path(DAT,'28_turquoise_network_nodes.csv'))
te <- fread(file.path(DAT,'29_turquoise_network_edges.csv'))

gr <- graph_from_data_frame(te[,.(from=as.character(from),to=as.character(to),rho)],directed=FALSE,vertices=tn$gene)
set.seed(20260915L)
xy <- layout_with_fr(gr,weights=E(gr)$rho,niter=1200)
nd <- data.table(gene=V(gr)$name,x=xy[,1],y=xy[,2])
nd[tn,on='gene',`:=`(kME=i.kME,category=i.category)]
ed <- as.data.table(as_data_frame(gr,what='edges'))
ed[nd,on=c(from='gene'),`:=`(x=i.x,y=i.y)]
ed[nd,on=c(to='gene'),`:=`(xend=i.x,yend=i.y)]
lab_e <- nd[order(-kME)][1:min(15L,.N)]
lab_e <- unique(rbind(lab_e,nd[category=='MAPK/ERK response'],fill=TRUE),by='gene')
p <- ggplot()+
  geom_segment(data=ed,aes(x,y,xend=xend,yend=yend,alpha=rho),colour='#B9A8D0',linewidth=.9)+
  geom_point(data=nd,aes(x,y,size=kME),shape=21,fill='#7654A8',colour='#4B3866',stroke=.7)+
  geom_text_repel(data=lab_e,aes(x,y,label=gene),size=4,family=FONT,
    seed=20260915L,max.overlaps=Inf,min.segment.length=0,segment.size=.3,
    box.padding=.45,point.padding=.4,max.iter=10000)+
  scale_size_continuous(range=c(4.5,9.45),breaks=c(.45,.55,.65),name='Module membership (kME)')+
  scale_alpha_continuous(range=c(.2,.8),guide='none')+
  guides(size=guide_legend(title.position='top',title.hjust=.5,nrow=1,
     override.aes=list(fill='#7654A8',colour='#4B3866',alpha=1)))+
  coord_equal(clip='off')+theme_void(base_family=FONT)+
  theme(legend.position='bottom',legend.text=element_text(size=12),
    legend.title=element_text(size=12),legend.key.width=grid::unit(1.7,'cm'),
    legend.key.height=grid::unit(.7,'cm'),legend.margin=margin(t=10),
    plot.title=element_text(size=22,face='bold',hjust=.5),
    plot.margin=margin(15,35,10,35))+
  labs(title='turquoise')
base <- 'hdWGCNA_turquoise_network_uniform_20261009'
ggsave(file.path(OUT,paste0(base,'.pdf')),p,width=7.5,height=6.8,device=cairo_pdf)

fwrite(nd,file.path(OUT,paste0(base,'_node_positions.csv')))
cat('Nodes:',nrow(nd),' edges:',nrow(ed),' kME range:',range(nd$kME),'\n')
