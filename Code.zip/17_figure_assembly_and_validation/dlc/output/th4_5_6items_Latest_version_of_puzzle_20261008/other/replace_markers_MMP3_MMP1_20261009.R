.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(Seurat);library(Matrix);library(data.table);library(ggplot2);library(cowplot);library(scales);library(grid)})
warnings_seen <- character()
globalCallingHandlers(warning=function(w) {warnings_seen <<- unique(c(warnings_seen,conditionMessage(w)));invokeRestart('muffleWarning')})
aux <- 'C:/wb_links/panel456_20261008'
dat <- 'C:/wb_links/dlc/data_derived/tranoncol2026_Williams_20260920'
cell <- fread(file.path(dat,'05_cell_marker_and_program_scores.csv.gz'))
stopifnot(nrow(cell)==14302,!anyDuplicated(cell$cell_id),all(grepl('Williams',cell$Study,ignore.case=TRUE)))
cat('Read original expression object\n');flush.console()
fb <- readRDS('C:/wb_links/dlc_data/outputs/fb_seurat_annotated.rds')
norm <- LayerData(fb,assay='RNA',layer='data')
genes <- c('MMP3','MAPK1','MAPK3','MMP1')
stopifnot(all(genes %in% rownames(norm)),all(cell$cell_id %in% colnames(norm)))
x <- as.matrix(norm[genes,cell$cell_id,drop=FALSE])
stopifnot(isTRUE(all.equal(as.numeric(x['MAPK1',]),cell$MAPK1,tolerance=1e-10)),
          isTRUE(all.equal(as.numeric(x['MAPK3',]),cell$MAPK3,tolerance=1e-10)))
for(g in genes) cell[[g]] <- as.numeric(x[g,])
if(!'frozen_umap_1' %in% names(cell)) setnames(cell,c('UMAP1','UMAP2'),c('frozen_umap_1','frozen_umap_2'))

for(ex in parse('C:/wb_links/dlc/code/tranoncol2026/03_figures.R')) {
 if(is.call(ex)&&identical(ex[[1]],as.name('<-'))&&is.symbol(ex[[2]])&&
    as.character(ex[[2]]) %in% c('FONT','TYPE_COLORS','theme_article','theme_umap','feature_violin')) eval(ex)
}
cell[,fibroblast_short:=factor(fibroblast_short,levels=names(TYPE_COLORS))]
stats <- rbindlist(lapply(genes,function(g) data.table(gene=g,cells=nrow(cell),positive_cells=sum(cell[[g]]>0),max_expression=max(cell[[g]]),map_upper_limit=as.numeric(quantile(cell[[g]],.995)))))
print(stats)
stopifnot(all(stats$map_upper_limit>0))
summary <- rbindlist(lapply(genes,function(g) cell[,.(gene=g,n_cells=.N,mean=mean(get(g)),positive_fraction=mean(get(g)>0)),by=fibroblast_short]))
fwrite(cell[,c('cell_id','Study','disease','donor_id','fibroblast_short','frozen_umap_1','frozen_umap_2',genes),with=FALSE],file.path(aux,'source_data/Williams_MMP3_ERK_MMP1_expression_20261009.csv.gz'))
fwrite(stats,file.path(aux,'source_data/Williams_MMP3_ERK_MMP1_QC_20261009.csv'))
fwrite(summary,file.path(aux,'source_data/Williams_MMP3_ERK_MMP1_subtype_summary_20261009.csv'))
p <- plot_grid(feature_violin('MMP3'),feature_violin('MAPK1'),feature_violin('MAPK3'),feature_violin('MMP1'),ncol=2)
out <- file.path(aux,'Williams_MMP3_ERK1_2_MMP1_expression_20261009.pdf')
stopifnot(!file.exists(out)||'--rebuild' %in% commandArgs(TRUE))
ggsave(out,p,device=cairo_pdf,width=6.0,height=3.1,units='in',family='Arial',bg='white')
writeLines(warnings_seen,file.path(aux,'QA/Williams_MMP3_ERK_MMP1_warnings_20261009.txt'))
print(warnings_seen)
cat('DONE',out,'\n')
