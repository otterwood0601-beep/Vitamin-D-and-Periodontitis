from pathlib import Path
import sys, gc
import fitz
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008')
idx = int(sys.argv[1]) - 4
with fitz.open(ROOT / '\u56fe/\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u5b8c\u6574\u62fc\u56fe_3\u9875.pdf') as d:
    p = d[idx]
    pix = p.get_pixmap(dpi=600, alpha=False)
    target = ROOT / '\u56fe' / f'\u7b2c{idx + 4}\u9879_\u6700\u65b0\u7248\u5b8c\u6574\u62fc\u56fe_600dpi.png'
    pix.save(target)
    print(f'{target} | {pix.width} x {pix.height} | 600 dpi', flush=True)
