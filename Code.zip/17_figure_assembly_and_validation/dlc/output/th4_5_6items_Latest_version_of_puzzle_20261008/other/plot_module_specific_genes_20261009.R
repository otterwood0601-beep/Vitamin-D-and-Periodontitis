.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(ggplot2);library(ragg)})
base <- 'C:/wb_links/panel456_20261008/module_specific_20261009'
sel <- fread(file.path(base,'selected_specific_genes.csv'))
d <- fread(file.path(base,'selected_genes_plot_data.csv'))
types <- c('Pre-extracellular matrix-associated fibroblasts','ECM remodeling-associated fibroblasts','Vascular-associated fibroblasts','Matrix homeostasis-associated fibroblasts','Immune-associated fibroblasts')
short <- c('Pre-ECM','ECM remodeling','Vascular','Matrix homeostasis','Immune')
mods <- c('blue','yellow','turquoise','brown')
sel[,module_order:=match(module,mods)]
setorder(sel,module_order,-ratio,-pct)
genes <- sel$gene
d[,celltype:=factor(celltype,levels=types,labels=short)]
d[,module:=factor(module,levels=mods)]
d[,gene:=factor(gene,levels=rev(genes))]

d[,relative_mean:=mean_linear/max(mean_linear),by=gene]
stopifnot(nrow(d)==22*5,all(sel$ratio>=2),all(sel$pct>=10))
stopifnot(all(d[,max(relative_mean),by=gene]$V1==1))
fwrite(d,file.path(base,'specific_dotplot_source_with_relative_scale.csv'))
p <- ggplot(d,aes(celltype,gene)) +
 geom_point(aes(size=pct,colour=relative_mean)) +
 scale_colour_viridis_c(option='magma',limits=c(0,1),name='Relative mean\nexpression\n(within gene)') +
 scale_size_area(max_size=4.5,limits=c(0,100),breaks=c(10,25,50,75,100),name='% expressed') +
 facet_grid(module~.,scales='free_y',space='free_y') +
 labs(x=NULL,y=NULL,caption='Selection: target mean >= 2x each other state; target detection >= 10%.\nNo qualifying genes in green/red. This is a selected display, not all module genes.') +
 theme_classic(base_family='Arial',base_size=10) +
 theme(axis.text.x=element_text(angle=45,hjust=1,colour='black'),
 axis.text.y=element_text(colour='black',size=9),
 strip.background=element_blank(),strip.text.y=element_text(face='bold',size=10),
 panel.spacing.y=grid::unit(5,'pt'),legend.title=element_text(size=9),
 legend.text=element_text(size=8),plot.caption=element_text(size=7,hjust=0),
 plot.margin=margin(8,8,8,8))
tmp <- 'C:/Users/Lin/AppData/Local/Temp/module_specific_diagonal_preview_20261009.png'
stopifnot(!file.exists(tmp))
agg_png(tmp,width=1400,height=1800,units='px',res=230,background='white')
print(p);dev.off()
cat(tmp,'\n')
