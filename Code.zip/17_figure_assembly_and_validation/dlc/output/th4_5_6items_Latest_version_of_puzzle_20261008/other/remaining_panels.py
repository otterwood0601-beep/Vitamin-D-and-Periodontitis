from pathlib import Path
import sys
import numpy as np
import pandas as pd
from scipy.stats import mannwhitneyu
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
AUX = ROOT / 'output/\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008/\u5176\u4ed6'
PAN = AUX / '\u62fc\u56fe\u7d20\u6750'
DATA = AUX / 'source_data'
sys.path.insert(0, str(ROOT / 'code'))
from style_npj import set_npj_style
set_npj_style()
cells = pd.read_csv(ROOT / 'data_derived/tranoncol2026_Williams_20260920/05_cell_marker_and_program_scores.csv.gz')
groups = pd.read_csv(ROOT / 'P3_WGCNA_Williams_20261008_RAWP/\u5176\u4ed6/source_data/01_sample_group_manifest.csv')
mapping = {geo: r.participant_group for r in groups.itertuples() for geo in r.GEO_ids.split(';')}
cells['participant_group'] = cells.donor_id.map(mapping)
assert cells.participant_group.notna().all() and len(cells) == 14302
programs = ['MAPK_ERK', 'MAPK_JNK_p38', 'ECM_synthesis', 'ECM_organization', 'ECM_degradation', 'ECM_inhibitors', 'ECM_adhesion']
means = cells.groupby(['participant_group', 'disease'])[programs].mean().reset_index()
assert len(means) == 18
means.to_csv(DATA / 'Williams_18group_UCell_means.csv', index=False)
summary = means.groupby('disease')[programs].median().T.reindex(columns=['normal', 'periodontitis'])
ps = []
for gene in programs:
    p = mannwhitneyu(means.loc[means.disease.eq('normal'), gene], means.loc[means.disease.eq('periodontitis'), gene], alternative='two-sided', method='exact').pvalue
    ps.append(p)
summary['raw_p'] = ps
summary.to_csv(DATA / 'Williams_18group_UCell_group_summary_RAWP.csv')
fig, ax = plt.subplots(figsize=(4.0, 3.2))
im = ax.imshow(summary.iloc[:, :2], aspect='auto', cmap='Reds', vmin=0, vmax=0.8)
ax.set_xticks([0, 1], ['Healthy\n13 groups', 'Periodontitis\n5 groups'])
ax.set_yticks(range(len(programs)), programs, fontsize=6)
ax.tick_params(length=0)
for i in range(len(programs)):
    p = ps[i]
    star = '***' if p < 0.001 else '**' if p < 0.01 else '*' if p < 0.05 else ''
    for j in range(2):
        ax.text(j, i, f'{summary.iloc[i, j]:.3f}{star}', ha='center', va='center', fontsize=7)
fig.colorbar(im, ax=ax, shrink=0.7, label='Median group-mean UCell')
ax.set_title('Williams sample-group program footprint', fontsize=8)
fig.text(0.025, 0.01, 'Conservative sample-ID groups; stars: raw two-sided Wilcoxon P.', fontsize=6)
fig.tight_layout(rect=[0, 0.055, 1, 1])
fig.savefig(PAN / 'Williams_group_footprint_RAWP.pdf', bbox_inches='tight', pad_inches=0.08)
plt.close(fig)
mt = pd.read_csv(ROOT / 'P2_hdWGCNA_Williams_20260920/outputs/02_source_data/10_module_trait_bubble.csv')
mods = ['yellow', 'turquoise', 'blue', 'green', 'brown', 'red']
traits = ['Immune', 'ECM remodeling', 'Vascular', 'Pre-ECM', 'Matrix homeostasis', 'Periodontitis', 'GDF15_logCPM']
fig, ax = plt.subplots(figsize=(4.7, 3.05))
for _, r in mt.iterrows():
    if r['module'] not in mods or r['trait'] not in traits:
        continue
    sc = ax.scatter(traits.index(r['trait']), mods.index(r['module']), s=5 + np.clip(-np.log10(max(r['p'], 1e-300)), 0, 200) * 0.65, c=[r['rho']], cmap='RdBu_r', vmin=-1, vmax=1, edgecolors='none')
ax.set_xticks(range(len(traits)), traits, rotation=45, ha='right', fontsize=6)
ax.set_yticks(range(len(mods)), mods, fontsize=7)
ax.invert_yaxis()
ax.set_ylim(5.7, -0.7)
ax.set_xlim(-0.7, 6.7)
ax.spines[['top', 'right']].set_visible(False)
fig.colorbar(sc, ax=ax, shrink=0.7, label='Pearson r')
ax.set_title('hdWGCNA metacell associations', fontsize=8)
fig.text(0.025, 0.01, 'Point size: -log10(raw P), capped at 200.', fontsize=6)
fig.tight_layout(rect=[0, 0.055, 1, 1])
fig.savefig(PAN / 'Williams_module_trait_RAWP.pdf', bbox_inches='tight', pad_inches=0.08)
plt.close(fig)
print('Group heatmap and module-trait panel ready')
