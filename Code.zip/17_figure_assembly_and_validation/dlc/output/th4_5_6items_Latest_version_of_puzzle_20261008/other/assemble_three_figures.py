from pathlib import Path
import hashlib, json, re, sys, gc
import fitz
from PIL import Image
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
OUT = ROOT / 'output/\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008'
AUX = OUT / '\u5176\u4ed6'
PAN = AUX / '\u62fc\u56fe\u7d20\u6750'
QA = AUX / 'QA'
FIG = OUT / '\u56fe'
HD = ROOT / 'P2_hdWGCNA_Williams_20260920/outputs/figures'
REF = ROOT / 'output/\u539f\u6587\u683c\u5f0f\u8fc1\u79fb_GDF15_ERK/Williams\u7edf\u4e00\u91cd\u5206\u6790_20260920'
P3 = ROOT / 'P3_WGCNA_Williams_20261008_RAWP/\u56fe'
VD = ROOT / 'output/Williams_VD47_full_dual_score_20261008/figures'
for d in (FIG, QA):
    d.mkdir(parents=True, exist_ok=True)
dest = FIG / '\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u5b8c\u6574\u62fc\u56fe_3\u9875.pdf'
if dest.exists() and '--rebuild' not in sys.argv:
    raise FileExistsError(dest)
cache = {}
records = []
removed_tags = []

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def source(path):
    path = str(path)
    if path in cache:
        return cache[path]
    original = fitz.open(path)
    d = fitz.open()
    d.insert_pdf(original)
    for page in d:
        for block in page.get_text('dict')['blocks']:
            for line in block.get('lines', []):
                for s in line['spans']:
                    if re.fullmatch('[A-Z](?:2)?', s['text'].strip()) and s['size'] >= 8:
                        r = fitz.Rect(s['bbox'])
                        r.x0 -= 0.5
                        r.x1 += 0.5
                        page.draw_rect(r, color=None, fill=(1, 1, 1), overlay=True)
                        removed_tags.append({'source': path, 'page': page.number + 1, 'text': s['text']})
        if Path(path).name in ['\u56feP2H_\u6a21\u5757\u8de8\u4f9b\u8005\u7a33\u5b9a\u6027.pdf', '\u56feP2I_\u6a21\u5757\u5916\u90e8\u590d\u73b0\u68ee\u6797\u56fe.pdf', '\u56feP2D_\u6a21\u5757hub\u57fa\u56e0\u70b9\u56fe.pdf', 'Williams_hub_dot_labels_repaired.pdf']:
            for b in page.get_text('blocks'):
                if any((k in b[4] for k in ['Module stability across', 'Independent replication of', 'Hub genes of hdWGCNA'])):
                    rr = fitz.Rect(b[:4])
                    rr.y0 = max(0, rr.y0 - 1)
                    rr.y1 += 1
                    page.draw_rect(rr, color=None, fill=(1, 1, 1), overlay=True)
        if 'Reference_Fig3_style' in Path(path).name:
            for b in page.get_text('blocks'):
                if 'Vascular vs other fibroblast states' in b[4]:
                    page.draw_rect(fitz.Rect(b[:4]), color=None, fill=(1, 1, 1), overlay=True)
    cache[path] = d
    return d
doc = fitz.open()

def page(w, h, title, subtitle):
    p = doc.new_page(width=w, height=h)
    p.insert_font(fontname='Arial', fontfile='C:\\Windows\\Fonts\\arial.ttf')
    p.insert_font(fontname='ArialBold', fontfile='C:\\Windows\\Fonts\\arialbd.ttf')
    p.insert_font(fontname='CN', fontfile='C:\\Windows\\Fonts\\simhei.ttf')
    p.insert_text((18, 24), title, fontname='CN', fontsize=16)
    p.insert_text((18, 41), subtitle, fontname='Arial', fontsize=8, color=(0.3, 0.3, 0.3))
    return p

def tile(p, tag, title, path, rect, source_page=0, clip=None):
    rect = fitz.Rect(rect)
    d = source(path)
    sp = d[source_page]
    clip = fitz.Rect(clip) if clip else sp.rect
    assert clip.x0 >= -0.01 and clip.y0 >= -0.01 and (clip.x1 <= sp.rect.width + 0.01) and (clip.y1 <= sp.rect.height + 0.01)
    p.insert_text((rect.x0, rect.y0 + 10), tag, fontname='ArialBold', fontsize=11)
    titlebox = fitz.Rect(rect.x0 + 21, rect.y0, rect.x1, rect.y0 + 25)
    assert p.insert_textbox(titlebox, title, fontname='Arial', fontsize=8, lineheight=1.1) >= 0, title
    target = fitz.Rect(rect.x0, rect.y0 + 28, rect.x1, rect.y1)
    p.show_pdf_page(target, d, source_page, clip=clip, keep_proportion=True)
    records.append(dict(figure=p.number + 4, tag=tag, title=title, source=str(path), source_page=source_page + 1, clip=list(clip), target=list(target), sha256=sha(path)))

def footer(p, text):
    rr = fitz.Rect(18, p.rect.height - 38, p.rect.width - 18, p.rect.height - 7)
    assert p.insert_textbox(rr, text, fontname='CN', fontsize=7, lineheight=1.2) >= 0

def group_row(p, path, clip, rect, tags, titles, boundaries):
    d = source(path)
    rect = fitz.Rect(rect)
    clip = fitz.Rect(clip)
    target = fitz.Rect(rect.x0, rect.y0 + 28, rect.x1, rect.y1)
    p.show_pdf_page(target, d, 0, clip=clip, keep_proportion=True)
    for i, (tag, title) in enumerate(zip(tags, titles)):
        x = rect.x0 + (boundaries[i] - clip.x0) / clip.width * rect.width
        end = rect.x0 + (boundaries[i + 1] - clip.x0) / clip.width * rect.width
        p.insert_text((x, rect.y0 + 10), tag, fontname='ArialBold', fontsize=11)
        assert p.insert_textbox(fitz.Rect(x + 20, rect.y0, end, rect.y0 + 27), title, fontname='Arial', fontsize=7.5) >= 0
        records.append(dict(figure=p.number + 4, tag=tag, title=title, source=str(path), source_page=1, clip=[boundaries[i], clip.y0, boundaries[i + 1], clip.y1], target=list(target), sha256=sha(path), shared_vector_row=True))
p = page(900, 2290, '4. WGCNA / hdWGCNA\uff1a\u5171\u8868\u8fbe\u6a21\u5757\u3001\u67a2\u7ebd\u57fa\u56e0\u53ca\u75be\u75c5\u5173\u8054', 'Latest source for each view | Williams pseudobulk / Williams hdWGCNA / gingival bulk | 2026-10-08')
diag = ROOT / 'P3_WGCNA_Williams_20261008/\u56fe/WGCNA_diagnostics.pdf'
tile(p, 'A', 'Williams pseudobulk: soft threshold', diag, (18, 55, 441, 258), 0)
tile(p, 'B', 'Williams pseudobulk: module dendrogram', diag, (459, 55, 882, 258), 1)
bulk = ROOT / 'output/BioorganicChemistry2026_\u5e72\u5b9e\u9a8c\u8fc1\u79fb_20260924/figures/Fig1_Gingiva_bulk_ComBat_DEG_WGCNA_BioorgChem_style.pdf'
tile(p, 'C', 'Gingival bulk: gene dendrogram', bulk, (18, 270, 298, 455), clip=(0, 711, 350, 957))
tile(p, 'D', 'Gingival bulk: module-disease relationships', bulk, (310, 270, 590, 455), clip=(350, 711, 777, 957))
tile(p, 'E', 'Williams hdWGCNA: soft threshold', HD / '\u56feP2A_\u8f6f\u9608\u503c\u9009\u62e9.pdf', (602, 270, 882, 495))
summary = PAN / 'Williams_hdWGCNA_summary_input_corrected.pdf'
tile(p, 'F', 'Williams hdWGCNA: module dendrogram', HD / '\u56feP2C_\u6a21\u5757\u6811.pdf', (18, 467, 298, 655))
tile(p, 'G', 'Williams hdWGCNA: top module hubs (kME)', PAN / 'Williams_hdWGCNA_correct_hubs.pdf', (310, 507, 882, 762))
tile(p, 'H', 'Module-score UMAPs', summary, (18, 774, 415, 1080), clip=(0, 151, 211.2, 307.05))
tile(p, 'I', 'Module scores by subtype', summary, (427, 774, 607, 1080), clip=(211.2, 151, 326.4, 307.05))
tile(p, 'J', 'Turquoise hub network / ERK-response genes', summary, (619, 774, 882, 1080), clip=(326.4, 151, 480, 307.05))
tile(p, 'K', 'Module disease associations across cohorts', summary, (18, 1092, 340, 1320), clip=(0, 307.05, 206.4, 445))
tile(p, 'L', 'Bulk module distributions and GDF15 association', summary, (352, 1092, 882, 1320), clip=(206.4, 307.05, 480, 445))
tile(p, 'M', 'Hub-gene expression across fibroblast subtypes', PAN / 'Williams_hub_dot_labels_repaired.pdf', (18, 1332, 360, 1762))
tile(p, 'N', 'Module GO biological processes (raw P)', PAN / 'Williams_hdWGCNA_GO_RAWP.pdf', (372, 1332, 882, 1762))
tile(p, 'O', 'Module / subtype / disease / GDF15 associations', PAN / 'Williams_module_trait_RAWP.pdf', (18, 1774, 340, 1983))
tile(p, 'P', 'Module stability across sample splits', HD / '\u56feP2H_\u6a21\u5757\u8de8\u4f9b\u8005\u7a33\u5b9a\u6027.pdf', (352, 1774, 612, 1983))
p.insert_text((18, 2002), 'Zhang\u590d\u5236\u6837\u672c\u6f14\u793a\uff1a20\u5217\u4ecd\u4e3a5\u4efd\u57f9\u517b\u6837\u672c/1\u540d\u4f9b\u8005\uff1b\u590d\u5236\u540e\u7684\u663e\u8457\u6027\u4ec5\u4f5c\u65e0\u6548\u6f14\u793a\u5c55\u793a\u3002', fontname='CN', fontsize=9, color=(0.65, 0.12, 0.12))
demo = ROOT / 'output/Zhang_\u590d\u52364\u4efd_WGCNA\u6f14\u793a_20261007/\u56fe/Zhang_duplicate4_WGCNA_DEMONSTRATION.pdf'
tile(p, 'R', 'Zhang demonstration: input audit / repeated profiles', demo, (18, 2010, 300, 2246), 0)
tile(p, 'S', 'Zhang demonstration: modules / pseudoreplication', demo, (311, 2010, 593, 2246), 2)
tile(p, 'T', 'Zhang demonstration: GDF15 / ERK / MMP expression', demo, (604, 2010, 882, 2246), 3)
footer(p, '\u540c\u4e00\u56fe\u7c7b\u578b\u9009\u53d6\u6700\u65b0\u6709\u6548\u6765\u6e90\u3002Williams\u768413\u6a21\u5757pseudobulk\u7f51\u7edc\u4e0e6\u6a21\u5757hdWGCNA\u5206\u522b\u6807\u660e\uff1b\u6a21\u5757\u989c\u8272\u5404\u81ea\u5b9a\u4e49\u3002\u539f\u56fe\u548c\u5386\u53f2\u8bb0\u5f55\u4fdd\u7559\u3002')
p = page(900, 810, '5. \u75be\u75c5-\u7ef4\u751f\u7d20D\u53cd\u5411\u7b7e\u540d', 'Williams gingival fibroblasts + Zhang/GSE212728 | WGCNA modules | RAW P | 2026-10-08')
tile(p, 'B', 'Vitamin-D up/down signatures in disease', P3 / 'P3_B_WGCNA_RAWP.pdf', (459, 55, 882, 221))
tile(p, 'C', 'Vitamin-D signature GSEA curves', P3 / 'P3_B2_WGCNA_RAWP.pdf', (459, 233, 882, 405))
tile(p, 'D', 'WGCNA module directions: disease vs vitamin D', P3 / 'P3_C_WGCNA_RAWP.pdf', (18, 417, 441, 766))
tile(p, 'E', 'GDF15 virtual knockout vs WGCNA modules', P3 / 'P3_D_WGCNA_RAWP.pdf', (459, 417, 882, 766))
footer(p, '\u75be\u75c5\u7aef\uff1aWilliams\uff0c18\u4e2a\u4fdd\u5b88\u5408\u5e76\u6837\u672c\u6807\u7b7e\u7ec4\uff1b\u7ef4\u751f\u7d20D\u7aef\uff1aZhang\uff0c3\u4efdD3\u548c2\u4efd\u4e59\u9187\u57f9\u517b\u6837\u672c\uff0c\u6765\u81ea1\u540d\u4f9b\u8005\u3002\u661f\u53f7\u53ca\u7b5b\u9009\u6309RAW P\u3002')
p = page(900, 2430, '6. MAPK / ERK\u901a\u8def\uff1aGSEA\u3001PROGENy\u53ca\u5355\u7ec6\u80de\u7a0b\u5e8f\u8bc4\u5206', 'Williams gingival fibroblasts + Zhang/GSE212728 | RAW P | Updated pathway inputs: 2026-10-08')
tile(p, 'A', 'Program GSEA: disease vs vitamin D', PAN / 'MAPK_ECM_GSEA_Williams_RAWP.pdf', (18, 55, 300, 325))
tile(p, 'B', 'MAPK/ERK response-gene directions', PAN / 'MAPK_gene_heatmap_Williams.pdf', (312, 55, 572, 325))
tile(p, 'C', 'PROGENy: disease vs vitamin D', PAN / 'PROGENy_Williams_RAWP.pdf', (584, 55, 882, 325))
state = REF / 'Reference_Fig3_style_gingival_fibroblast_GDF15_ERK_state_20260915_Williams_20260920.pdf'
tile(p, 'D', 'Sample-group program footprint', PAN / 'Williams_group_footprint_RAWP.pdf', (18, 337, 330, 595))
records[-1].update(status='\u540e\u7eed\u4e0d\u5206\u6790', status_updated_at='2026-10-09', status_note='\u7528\u6237\u8981\u6c42\u6807\u6ce8\u540e\u7eed\u4e0d\u5206\u6790\uff1b\u73b0\u6709\u56fe\u548c\u6570\u636e\u4fdd\u7559')
tile(p, 'E', 'GDF15, ERK1/2 and JUND expression maps / violins', state, (342, 337, 882, 595), clip=(139.2, 0, 480, 157.41))
tile(p, 'F', 'Programs across fibroblast states', PAN / 'Williams_state_program_dot_repaired.pdf', (18, 607, 283, 963))
tile(p, 'G', 'GO-defined ERK1/2 and ECM-disassembly scores', AUX / 'Fig6G_GO0070371_GO0022617_20261009.pdf', (295, 607, 882, 963))
tile(p, 'H', 'PROGENy by fibroblast state', state, (18, 975, 276, 1310), clip=(0, 367.29, 148.8, 583))
tile(p, 'I', 'Vascular-state expression contrast (raw P)', PAN / 'Williams_vascular_volcano_RAWP.pdf', (288, 975, 546, 1310))
tile(p, 'J', 'Vascular-state functional enrichment network', state, (558, 975, 882, 1310), clip=(268.8, 367.29, 480, 583))
dual = VD / 'Fig2_Williams_VitaminD_GDF15_ERK_MMP_dual_scoring_JHazMat_style_20261008_noACE_Aaxes1to1_rawp.pdf'
tile(p, 'K', 'Disease-labelled UMAP', dual, (18, 1322, 207, 1537), clip=(0, 0, 172, 225))
tile(p, 'L', 'VD genes / GDF15 / ERK / MMP expression', dual, (219, 1322, 592, 1537), clip=(172, 0, 638, 225))
tile(p, 'M', 'VD AddModuleScore by disease', dual, (604, 1322, 882, 1537), clip=(638, 0, 1101, 225))
group_row(p, dual, (0, 225, 1101, 430), (18, 1549, 882, 1756), 'NOP', ['VD AUCell by disease', 'VD AddModuleScore by state', 'VD AUCell by state'], [0, 355, 706, 1101])
group_row(p, dual, (0, 430, 1101, 633), (18, 1768, 882, 1975), 'QRS', ['VD-high vs VD-low pseudobulk', 'VD-score-associated KEGG enrichment', 'VD-score-associated GO enrichment'], [0, 293, 694, 1101])
group_row(p, dual, (0, 633, 1101, 876), (18, 1987, 882, 2194), 'TUVW', ['Held-out GDF15: high vs low score', 'Held-out VD score vs GDF15', 'ERK / MMP scores: high vs low', 'VD score vs ERK / MMP programs'], [0, 270, 527, 791, 1101])
tile(p, 'X', 'VD-score high/low UMAPs: two scoring methods', VD / 'Fig2_B_C_Williams_VD46_AddModuleScore_AUCell_high_low_UMAP_20261008_compact.pdf', (18, 2206, 441, 2386))
tile(p, 'Y', 'VD-score high/low proportions in five states', VD / 'Fig2_D_E_Williams_VD46_five_states_high_low_proportions_20261008.pdf', (459, 2206, 882, 2386))
footer(p, 'A-C\u5df2\u7528Williams + Zhang\u91cd\u65b0\u8ba1\u7b97\uff1bD\u4e3a18\u4e2a\u6837\u672c\u6807\u7b7e\u7ec4\u7684UCell\u6c47\u603b\uff1bK-Y\u4f7f\u7528\u6700\u65b0\u7248\u7ef4\u751f\u7d20D\u8bc4\u5206\u56fe\u3002\u7ef4\u751f\u7d20D\u57fa\u56e0\u8bc4\u5206\u6bd4\u8f83\u4e0e\u7ed9\u836f\u5bf9\u6bd4\u5206\u5f00\u6807\u6ce8\u3002')
keys = [(r['source'], r['source_page'], tuple(r['clip'])) for r in records]
assert len(keys) == len(set(keys)), 'Exact panel duplicated'
for r in records:
    assert fitz.Rect(r['target']).is_valid
    assert sha(r['source']) == r['sha256']
doc.set_metadata({'title': '\u7b2c4\u30015\u30016\u9879\u6700\u65b0\u7248\u5b8c\u6574\u62fc\u56fe\uff083\u9875\uff09', 'subject': 'Latest nonduplicated scientific panels; RAW P; gingival sources', 'author': 'Scientific figure assembly'})
doc.set_toc([[1, '4 WGCNA / hdWGCNA', 1], [1, '5 \u75be\u75c5-\u7ef4\u751f\u7d20D\u53cd\u5411\u7b7e\u540d', 2], [1, '6 MAPK / ERK\u901a\u8def\u5206\u6790', 3]])
try:
    doc.subset_fonts()
except Exception:
    pass
doc.save(dest, garbage=4, deflate=True)
doc.close()
exclusions = [{'figure': 5, 'tag': 'A', 'source': 'Disease vs vitamin-D gene changes / P3_A_WGCNA_RAWP.pdf', 'status': '\u6682\u4e0d\u5206\u6790', 'reason': '\u7528\u6237\u8981\u6c42\u5220\u9664\u5f53\u524d\u5957\u56fe\u4e2d\u7684\u75be\u75c5-\u7ef4\u751f\u7d20D\u6563\u70b9\u56fe\uff1b\u5386\u53f2\u539f\u56fe\u4e0e\u6570\u636e\u4fdd\u7559'}, {'figure': 4, 'tag': 'Q', 'source': 'Module replication in gingival bulk / \u56feP2I_\u6a21\u5757\u5916\u90e8\u590d\u73b0\u68ee\u6797\u56fe.pdf', 'status': '\u540e\u9762\u6682\u4e0d\u5206\u6790', 'reason': '\u7528\u6237\u8ba4\u4e3a\u4e0e\u524d\u9762\u91cd\u590d\uff0c\u8981\u6c42\u4ece\u5f53\u524d\u5957\u56fe\u5220\u9664\uff1b\u5386\u53f2\u7ed3\u679c\u4fdd\u7559'}, {'source': '41\u9875\u6c47\u603b\u4e2d\u7684\u65e7\u7248\u53cd\u5411\u7b7e\u540d\u53ca\u91cd\u590d\u6563\u56fe', 'reason': '\u6700\u65b0\u7b2c5\u9879A-E\u5df2\u5b8c\u6574\u8986\u76d6'}, {'source': '\u65e7GSEA/PROGENy', 'reason': '\u5df2\u7528Williams\u7259\u9f88+Zhang\u66f4\u65b0\uff0c\u907f\u514dPagella\u6765\u6e90\u95ee\u9898'}, {'source': '\u65e7\u4f9b\u8005\u7ea7ssGSEA\u70ed\u56fe', 'reason': '\u66ff\u6362\u4e3aWilliams 18\u7ec4UCell\u6c47\u603b\uff0c\u4fdd\u7559\u6837\u672c\u7ea7\u7a0b\u5e8f\u70ed\u56fe\u7c7b\u578b\u5e76\u6807\u660e\u65b9\u6cd5'}, {'source': 'hdWGCNA 6\u5f20\u5355\u6a21\u5757\u7f51\u7edc', 'reason': '\u7f51\u7edc\u56fe\u7c7b\u578b\u7531J\u8986\u76d6\uff1b\u5404\u6a21\u5757\u67a2\u7ebd\u548c\u5206\u5e03\u7531G-H\u8986\u76d6\uff0c\u907f\u514d\u6563\u7f51\u7edc\u91cd\u590d\u5806\u53e0'}, {'source': 'Zhang\u6f14\u793a\u7b2c2/5\u9875', 'reason': '\u8f6f\u9608\u503c\u548c\u57fa\u56e0\u6811\u7c7b\u578b\u5df2\u8986\u76d6\uff1b\u6f14\u793a\u4fdd\u7559\u8f93\u5165\u3001\u590d\u5236\u7edf\u8ba1\u3001\u76ee\u6807\u8868\u8fbe\u4e09\u4e2a\u72ec\u7279\u89c6\u56fe'}, {'source': '\u7528\u6237\u5220\u9664\u7684\u539fVD\u56feA/C/E', 'reason': '\u6cbf\u7528noACE\u6700\u65b0\u7248\uff0c\u672a\u6062\u590d\u539f\u7ec6\u80de\u5206\u7c7b/\u4f9b\u8005\u6807\u7b7e/\u75be\u75c5\u4e9a\u578b\u6bd4\u4f8b\u56fe'}, {'source': '\u539fhdWGCNA\u7efc\u5408\u56feA/B\u8f93\u5165', 'reason': '\u4fee\u6b63\u786c\u7f16\u7801\u65e7\u6765\u6e90\uff0c\u6539\u4e3aWilliams\u6811\u548cWilliams\u67a2\u7ebd\u57fa\u56e0'}]
manifest = {'pdf': str(dest), 'pages': 3, 'panels': records, 'exclusions': exclusions, 'old_tags_removed': removed_tags, 'source_files_unchanged': True, 'visual_review': 'pending'}
(AUX / '\u62fc\u56fe\u6765\u6e90\u4e0e\u53bb\u91cd\u6e05\u5355.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
with fitz.open(dest) as d:
    for i, p in enumerate(d):
        pix = p.get_pixmap(matrix=fitz.Matrix(1.5, 1.5), alpha=False)
        pix.save(QA / f'Figure{i + 4}_preview.png')
        bands = 5 if p.rect.height > 1000 else 2
        for b in range(bands):
            clip = fitz.Rect(0, p.rect.height * b / bands, p.rect.width, p.rect.height * (b + 1) / bands)
            p.get_pixmap(matrix=fitz.Matrix(2, 2), clip=clip, alpha=False).save(QA / f'Figure{i + 4}_band{b + 1}.png')
print(json.dumps({'pdf': str(dest), 'pages': 3, 'panels_by_figure': {str(i): sum((r['figure'] == i for r in records)) for i in [4, 5, 6]}}, ensure_ascii=False))
