.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(ggplot2);library(cowplot);library(ragg)})
aux <- 'C:/wb_links/panel456_20261008'
src <- 'C:/wb_links/dlc/data_derived/tranoncol2026_Williams_20260920/26_cell_hdWGCNA_top50_UCell_scores.csv.gz'
mod_cell <- fread(src)
stopifnot(nrow(mod_cell)==14302,all(mod_cell$Study=='Williams'))
MODULE_COLORS <- c(green='#66BC29',blue='#2A55A5',turquoise='#65C7C8',red='#ED1C24',yellow='#F4E500',brown='#B02525')
theme_umap <- theme_void(base_family='Arial') + theme(
 plot.title=element_text(size=15,face='bold',hjust=.5,margin=margin(b=3)),
 plot.margin=margin(2,2,2,2))
audit <- list()
feature_module <- function(mn) {
 d <- mod_cell[order(get(mn))]
 lim <- quantile(d[[mn]],.99,na.rm=TRUE)
 rgb0 <- col2rgb(MODULE_COLORS[mn])/255
 pale <- rgb(.8+.2*rgb0[1],.8+.2*rgb0[2],.8+.2*rgb0[3])
 audit[[mn]] <<- data.frame(module=mn,n=nrow(d),min=min(d[[mn]]),upper_99pct=lim,max=max(d[[mn]]),high_color=MODULE_COLORS[mn])

 ggplot(d,aes(frozen_umap_1,frozen_umap_2,colour=pmin(get(mn),lim))) +
 geom_point(size=.28) + coord_equal() +
 scale_colour_gradientn(colours=c('#FEFEFE','#FAFAFA',pale,MODULE_COLORS[mn]),
                         values=c(0,.5,.8,1),guide='none') +
 labs(title=mn) + theme_umap
}
g <- plot_grid(plotlist=lapply(names(MODULE_COLORS),feature_module),ncol=3)
out <- 'C:/Users/Lin/AppData/Local/Temp/H_hdWGCNA_contrast_preview_20261009.png'
stopifnot(!file.exists(out))
agg_png(out,width=1680,height=1180,units='px',res=200,background='white')
print(g);dev.off()
fwrite(rbindlist(audit),file.path(aux,'source_data/H_contrast_display_audit_20261009.csv'))
cat(out,'\n')
