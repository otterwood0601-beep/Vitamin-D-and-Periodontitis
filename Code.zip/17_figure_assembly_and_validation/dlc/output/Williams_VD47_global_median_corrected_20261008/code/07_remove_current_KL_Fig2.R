ROOT <- 'C:/wb_links/williams_vd47_global_20261008'
protected <- c(list.files(file.path(ROOT,'source_data'),full.names=TRUE),
  list.files(file.path(ROOT,'figures'),full.names=TRUE))
protected <- protected[!dir.exists(protected)]
before <- tools::md5sum(protected)
generator <- readLines(file.path(ROOT,'code','03_render_combined_global_Fig2.R'))
prefix <- generator[seq_len(grep('^inventory <-',generator)-1L)]
prefix <- gsub('03_global_plot_recipe.R','07_noCurrentKL_plot_recipe.R',prefix,fixed=TRUE)
eval(parse(text=prefix),envir=.GlobalEnv)
inventory <- c('pDisease','pMapAMS','pMapAUC','pPropAMS','pPropAUC','pD',
               'pF','pG','pH','pI','pO','pP')
plots <- setNames(lapply(inventory,get),LETTERS[seq_along(inventory)])
for (tag in names(plots)) plots[[tag]] <- plots[[tag]] + labs(tag=tag) +
  theme(plot.tag=element_text(family='Arial',size=10.5,face='plain'),plot.tag.position='topleft')
rows <- list((plots$A|plots$B|plots$C)+plot_layout(widths=c(1,1,1)),
             plots$D|plots$E|plots$F,plots$G|plots$H|plots$I|plots$J,
             (plots$K|plots$L)+plot_layout(widths=c(1,1)))
fig <- (rows[[1]]/rows[[2]]/rows[[3]]/rows[[4]]) +
  plot_layout(heights=c(1,1,1,1.08),guides='keep') +
  plot_annotation(caption=paste(
    'Global medians across all 14,302 Williams fibroblasts: B/D use AddModuleScore; C/E use AUCell. Downstream groups use the global median of the two-method consensus score.',
    'All p values are raw (unadjusted). UMAPs hide 4 isolated cells for display only; all analyses retain them.',sep='\n'),
    theme=theme(plot.caption=element_text(family='Arial',size=6,hjust=0)))
base <- 'Fig2_Williams_VD46_global_median_combined_A_L_20261008_noGDF15_KL'
out_pdf <- file.path(ROOT,'figures',paste0(base,'.pdf'))
out_png <- file.path(ROOT,'figures',paste0(base,'.png'))
stopifnot(!file.exists(out_pdf),!file.exists(out_png))
render <- tempfile('noCurrentKL_fig2_',tmpdir='C:/wb_temp')
dir.create(render)
render <- normalizePath(render,winslash='/',mustWork=TRUE)
pdf_path <- file.path(render,paste0(base,'.pdf'))
png_path <- file.path(render,paste0(base,'.png'))
ggsave(pdf_path,fig,width=15.3,height=12.4,units='in',device=cairo_pdf)
ggsave(png_path,fig,width=15.3,height=12.4,units='in',dpi=600,bg='white')
stopifnot(file.copy(pdf_path,out_pdf,overwrite=FALSE),file.copy(png_path,out_png,overwrite=FALSE))
old_mapping <- fread(file.path(SD,'61_noKLM_panel_mapping.csv'))
mapping <- old_mapping[match(inventory,plot_object)]
mapping[,previous_panel:=panel]
mapping[,panel:=names(plots)]
fwrite(mapping,file.path(SD,'64_noCurrentKL_panel_mapping.csv'))
after <- tools::md5sum(protected)
stopifnot(identical(before,after))
write_json(list(created_at=format(Sys.time()),panel_order=names(plots),rows=c(3,3,4,2),
  removed_previous_panels=c('K','L'),removed_plot_objects=c('pM','pN'),
  width_inches=15.3,height_inches=12.4,axis_ratio_UMAP=1,font='Arial',raw_p=TRUE,
  source_scores_reused_without_recalculation=TRUE,
  original_files_unchanged=identical(before,after),protected_file_hashes=as.list(before),
  output_pdf=out_pdf,output_png=out_png),
  file.path(SD,'65_noCurrentKL_figure_manifest.json'),pretty=TRUE,auto_unbox=TRUE)
cat(out_pdf,'\n')
