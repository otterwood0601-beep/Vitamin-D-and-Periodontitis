from pathlib import Path
import json
import hashlib
import fitz
import numpy as np
import pandas as pd
from scipy import stats
from PIL import Image
root = Path('C:/wb_links/williams_vd47_global_20261008')
old = Path('C:/wb_links/williams_vd47_full_20261008')
sd = root / 'source_data'
cells = pd.read_csv(sd / '03_Williams_VD47_dual_scores.csv.gz')
before = pd.read_csv(old / 'source_data' / '03_Williams_VD47_dual_scores.csv.gz')
j = cells.merge(before, on='cell_id', suffixes=('_new', '_old'), validate='one_to_one')
assert len(j) == 14302
for col in ['AddModuleScore', 'AUCell', 'consensus_score', 'GDF15_heldout_consensus_score', 'frozen_umap_1', 'frozen_umap_2', 'MAPK_ERK', 'ECM_degradation', 'GDF15']:
    assert np.allclose(j[col + '_new'], j[col + '_old'], rtol=0, atol=1e-14)
for score, col in [('AddModuleScore', 'AddModuleScore_group'), ('AUCell', 'AUCell_group'), ('consensus_score', 'score_group'), ('GDF15_heldout_consensus_score', 'GDF15_heldout_group')]:
    assert (cells[col] == np.where(cells[score] > cells[score].median(), 'High', 'Low')).all()
changed = int((j.score_group_new != j.score_group_old).sum())
assert changed > 0
props = pd.read_csv(sd / '53_state_method_high_low_proportions.csv')
for m in ['AddModuleScore', 'AUCell']:
    n = cells.groupby(['state', m + '_group']).size()
    for row in props.loc[props.method == m].itertuples():
        assert row.n_cells == n.loc[row.state, row.score_group]
        assert abs(row.percent - 100 * row.n_cells / row.total_cells) < 1e-12
assert np.allclose(props.groupby(['method', 'state']).percent.sum(), 100)
assert (props.groupby('method').n_cells.sum() == 14302).all()
endpoints = pd.read_csv(sd / '06_donor_state_group_endpoint_summary.csv')
tests = pd.read_csv(sd / '11_high_low_endpoint_tests.csv').set_index('endpoint')
cells['GDF15_detection'] = (cells.GDF15 > 0).astype(float)
cells['GDF15_mean'] = cells.GDF15
for endpoint in ['GDF15_detection', 'GDF15_mean', 'MAPK_ERK', 'ECM_degradation']:
    group = 'GDF15_heldout_group' if endpoint.startswith('GDF15') else 'score_group'
    expected = cells.groupby(['donor_id', group])[endpoint].mean().unstack()
    got = endpoints.pivot(index='donor_id', columns='score_group', values=endpoint)
    expected = expected.reindex(got.index)
    assert np.allclose(expected[['Low', 'High']], got[['Low', 'High']], rtol=0, atol=1e-12)
    p = stats.wilcoxon(got.High - got.Low, zero_method='wilcox', correction=True, method='approx').pvalue
    assert abs(p - tests.loc[endpoint, 'p_value']) < 1e-10, (endpoint, p, tests.loc[endpoint, 'p_value'])
    assert abs(np.median(got.High - got.Low) - tests.loc[endpoint, 'median_delta']) < 1e-12
de = pd.read_csv(sd / '08_paired_pseudobulk_high_vs_low_DE.csv.gz')
z = de.loc[~de.in_VD47_signature]
expected = np.where((z['P.Value'] < 0.05) & (z.logFC > 0.25), 'Up', np.where((z['P.Value'] < 0.05) & (z.logFC < -0.25), 'Down', 'NS'))
assert (z.direction == expected).all()
up = set(z.loc[z.direction == 'Up', 'gene'])
assert up == set((sd / '39_rawp_enrichment_input_genes.txt').read_text().splitlines())
for db in ['KEGG_2021_Human', 'GO_Biological_Process_2025']:
    d = pd.read_csv(sd / ('40_rawp_' + db + '.csv'))
    p = stats.hypergeom.sf(d.Count - 1, len(z), d.term_background_genes, len(up))
    assert np.allclose(p, d['P.value'], rtol=1e-08, atol=1e-200)
pb = pd.read_csv(sd / '23_pseudobulk_sample_metadata.csv')
assert len(pb) == 42 and (pb.groupby('donor_id').score_group.nunique() == 2).all()
bulk = pd.read_csv(sd / '18_bulk_VD35_score_and_Bisque_fractions.csv')
oldbulk = pd.read_csv(old / 'source_data' / '18_bulk_VD35_score_and_Bisque_fractions.csv')
assert len(bulk) == 44
assert (bulk.score_group == np.where(bulk.VD35_score > bulk.VD35_score.median(), 'High', 'Low')).all()
bj = bulk.merge(oldbulk, on='sample', suffixes=('_new', '_old'), validate='one_to_one')
bulk_changed = int((bj.score_group_new != bj.score_group_old).sum())
assert np.allclose(bj.VD35_score_new, bj.VD35_score_old, rtol=0, atol=1e-14)
assoc = pd.read_csv(sd / '19_VD35_Bisque_fraction_associations.csv').set_index('cell_type')
design = np.column_stack([np.ones(44), (bulk.score_group == 'High').astype(float), pd.get_dummies(bulk.dataset, drop_first=True).astype(float).to_numpy()])
for ct in assoc.index:
    y = np.arcsin(np.sqrt(bulk[ct].clip(0, 1)))
    coef = np.linalg.lstsq(design, y, rcond=None)[0]
    residual = y - design @ coef
    df = len(bulk) - design.shape[1]
    se = np.sqrt(np.diag(np.linalg.inv(design.T @ design)) * (residual @ residual / df))
    p = 2 * stats.t.sf(abs(coef[1] / se[1]), df)
    assert abs(p - assoc.loc[ct, 'adjusted_high_vs_low_p']) < 1e-10
    assert abs(coef[1] - assoc.loc[ct, 'adjusted_high_vs_low_beta']) < 1e-10
exact = pd.read_csv(sd / '28_bulk_K_exact_plotted_variables.csv')
rx = exact.VD35_adjusted_score
ry = exact.TNK_adjusted_fraction
r = np.corrcoef(rx, ry)[0, 1]
p = 2 * stats.t.sf(abs(r * np.sqrt(41 / (1 - r * r))), 41)
partial = pd.read_csv(sd / '20_VD35_TNK_partial_correlation.csv').iloc[0]
assert abs(r - partial.r) < 1e-12 and abs(p - partial.p_value) < 1e-12
files = {'Fig2': 'Fig2_Williams_VD46_global_median_combined_A_Q_20261008_corrected', 'Fig1': 'Fig1F_J_K_VD35_correlation_Bisque_JHazMat_style_20261008_global_median_corrected'}
qa = {'original_scores_and_coordinates_unchanged': True, 'all_four_global_thresholds_verified': True, 'single_cell_consensus_labels_changed': changed, 'bulk_labels_changed': bulk_changed, 'proportions_and_pair_tests_independently_verified': True, 'bulk_regressions_independently_verified': True, 'enrichment_independently_verified': True, 'DE_non_signature_counts': z.direction.value_counts().to_dict(), 'files': {}}
for key, name in files.items():
    path = root / 'figures' / (name + '.pdf')
    doc = fitz.open(path)
    page = doc[0]
    text = page.get_text()
    assert len(doc) == 1
    assert all((t in text.splitlines() for t in (list('ABCDEFGHIJKLMNOPQ') if key == 'Fig2' else ['F', 'J', 'K'])))
    assert 'Global median' in text or 'Global medians' in text
    assert 'FDR' not in text and 'q =' not in text
    assert all(('Arial' in f[3] or 'Symbol' in f[3] for f in page.get_fonts()))
    image = Image.open(path.with_suffix('.png'))
    assert abs(image.info['dpi'][0] - 600) < 1
    page.get_pixmap(matrix=fitz.Matrix(1.3, 1.3)).save(sd / (key + '_final_QA.png'))
    if key == 'Fig2':
        axis = []
        boxes = {tag: [] for tag in 'GHIJ'}
        for draw in page.get_drawings():
            for item in draw['items']:
                if item[0] == 'l' and draw['color'] == (0.0, 0.0, 0.0) and (0.7 < draw['width'] < 1.1):
                    a, b = item[1:]
                    if draw['rect'].y1 < 0.2 * page.rect.height and (abs(a.x - b.x) < 0.01 or abs(a.y - b.y) < 0.01):
                        length = abs(a - b)
                        if 10 < length < 50:
                            axis.append(length)
                if item[0] == 're' and draw['fill'] is not None:
                    rect = item[1]
                    if 0.39 * page.rect.height < rect.y0 < 0.6 * page.rect.height and 10 < rect.width < 70 and (rect.height > 1):
                        boxes[list(boxes)[min(int(rect.x0 / (page.rect.width / 4)), 3)]].append(rect.width)
        assert len(axis) == 6 and max(axis) - min(axis) < 0.02, axis
        assert len(boxes['G']) == 2 and len(boxes['H']) == 2 and (len(boxes['I']) == 5), boxes
        assert max(boxes['G'] + boxes['H'] + boxes['I']) - min(boxes['G'] + boxes['H'] + boxes['I']) < 0.02, boxes
        for value in props.percent:
            assert f'{value:.2f}%' in text
        for i in range(5):
            clip = fitz.Rect(0, page.rect.height * i / 5, page.rect.width, page.rect.height * (i + 1) / 5)
            page.get_pixmap(matrix=fitz.Matrix(1.8, 1.8), clip=clip).save(sd / f'Fig2_final_row{i + 1}_QA.png')
        qa['UMAP_axis_stroke_lengths'] = axis
        qa['box_widths'] = boxes
    qa['files'][key] = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'png_pixels': image.size, 'dpi': image.info['dpi']}
(sd / '60_final_validation.json').write_text(json.dumps(qa, indent=2), encoding='utf-8')
print(json.dumps(qa, indent=2))
