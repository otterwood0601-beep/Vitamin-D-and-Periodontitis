from pathlib import Path
import json
import fitz
root = Path('C:/wb_links/williams_vd47_global_20261008')
path = root / 'figures' / 'Fig2_Williams_VD46_global_median_combined_A_L_20261008_noGDF15_KL.pdf'
p = fitz.open(path)[0]
ds = p.get_drawings()
metrics = {}
axes = sorted([d['rect'] for d in ds if d['color'] == (0, 0, 0) and d['rect'].height < 0.1 and (d['rect'].width > 90) and (300 < d['rect'].y0 < 600)], key=lambda r: (round(r.y0), r.x0))
for tag, axis in zip('DEFGHIJ', axes):
    entry = {'old_panel_width_pt': axis.width, 'old_axis_bounds': list(axis)}
    if tag in 'DEGH':
        rectangles = [d['rect'] for d in ds if d['fill'] is not None and d['fill'] != (1, 1, 1) and (d['rect'].width > 20) and (axis.x0 < d['rect'].x0 < axis.x1) and (axis.y0 - 150 < d['rect'].y0 < axis.y0)]
        xbounds = sorted(set(((round(r.x0, 3), round(r.x1, 3)) for r in rectangles)))
        assert len(xbounds) == (5 if tag in 'DE' else 2), (tag, xbounds)
        widths = [b - a for a, b in xbounds]
        gaps = [xbounds[i + 1][0] - xbounds[i][1] for i in range(len(xbounds) - 1)]
        edges = [xbounds[0][0] - axis.x0, axis.x1 - xbounds[-1][1]]
        removed = 0.75 * (sum(gaps) + (sum(edges) if tag in 'GH' else 0))
        entry.update(old_mark_widths_pt=widths, old_between_gaps_pt=gaps, old_edge_gaps_pt=edges, new_panel_width_pt=axis.width - removed)
    elif tag == 'F':
        points = [d['rect'] for d in ds if d['fill'] is not None and d['fill'] != (1, 1, 1) and (0 < d['rect'].width < 15) and (axis.x0 < d['rect'].x0 < axis.x1) and (axis.y0 - 150 < d['rect'].y0 < axis.y0) and any((it[0] == 'c' for it in d['items']))]
        groups = {}
        for r in points:
            center = round((r.x0 + r.x1) / 2, 1)
            groups.setdefault(center, []).append(r)
        assert len(groups) == 5, groups
        centers = sorted(groups)
        radii = [max((r.width for r in groups[c])) / 2 for c in centers]
        gaps = [centers[i + 1] - centers[i] - radii[i] - radii[i + 1] for i in range(4)]
        newcenters = [centers[0]]
        for i in range(4):
            newcenters.append(newcenters[-1] + radii[i] + radii[i + 1] + gaps[i] / 4)
        scale = axis.width / 5.2
        entry.update(old_centers_pt=centers, max_dot_radii_pt=radii, old_between_gaps_pt=gaps, new_positions=[1 + (c - centers[0]) / scale for c in newcenters], new_panel_width_pt=axis.width - 0.75 * sum(gaps))
    metrics[tag] = entry
out = root / 'source_data' / '67_marked_gap_targets.json'
assert not out.exists()
out.write_text(json.dumps(metrics, indent=2), encoding='utf-8')
print(json.dumps(metrics, indent=2))
