ROOT <- 'C:/wb_links/williams_vd47_global_20261008'
source <- readLines(file.path(ROOT,'code','07_remove_current_KL_Fig2.R'))
source <- source[seq_len(grep('^base <-',source)-1L)]
source <- gsub('07_noCurrentKL_plot_recipe.R','12_tightUMAP_Kboxes_plot_recipe.R',source,fixed=TRUE)
eval(parse(text=source),envir=.GlobalEnv)
metrics <- read_json(file.path(SD,'67_marked_gap_targets.json'),simplifyVector=TRUE)
positions <- 1+(seq_along(state_levels)-1)*(.58+(1-.58)/4)
for(tag in c('D','E')) {
  p <- plots[[tag]]
  p$data <- copy(p$data)
  p$data[, .compact_x:=positions[as.integer(state)]]
  p$mapping$x <- rlang::quo(.compact_x)
  for(i in seq_along(p$layers)) {
    if(is.data.frame(p$layers[[i]]$data) && 'state' %in% names(p$layers[[i]]$data)) {
      p$layers[[i]]$data <- copy(p$layers[[i]]$data)
      p$layers[[i]]$data[, .compact_x:=positions[as.integer(state)]]
      p$layers[[i]]$mapping$x <- rlang::quo(.compact_x)
    }
  }
  plots[[tag]] <- p + scale_x_continuous(breaks=positions,labels=state_levels,
    limits=c(positions[1]-.6,tail(positions,1)+.6),expand=expansion(mult=0))
}
f_positions <- metrics$F$new_positions
p <- plots$F
p$data <- copy(p$data)
p$data[, .compact_x:=f_positions[as.integer(state)]]
p$mapping$x <- rlang::quo(.compact_x)
plots$F <- p + scale_x_continuous(breaks=f_positions,labels=state_levels,
  limits=c(f_positions[1]-.6,tail(f_positions,1)+.6),expand=expansion(mult=0))
box_width <- .245384615384615
box_step <- box_width+(1-box_width)/4
edge <- (.6-box_width/2)/4
for(tag in c('G','H')) {
  p <- plots[[tag]]
  p$data <- copy(p$data)
  p$data[, .compact_x:=ifelse(as.character(disease)=='normal',1,1+box_step)]
  p$mapping$x <- rlang::quo(.compact_x)
  for(i in seq_along(p$layers)) {
    ld <- p$layers[[i]]$data
    if(is.data.frame(ld) && 'x' %in% names(ld) && all(ld$x==1.5)) {
      p$layers[[i]]$data <- copy(ld)
      p$layers[[i]]$data$x <- 1+box_step/2
    }
    if(inherits(p$layers[[i]]$position,'PositionJitter')) p$layers[[i]]$position$seed <- 20261008L
  }
  plots[[tag]] <- p + scale_x_continuous(breaks=c(1,1+box_step),
    labels=c('normal','periodontitis'),
    limits=c(1-box_width/2-edge,1+box_step+box_width/2+edge),expand=expansion(mult=0))
}

k_original_panel <- 229.281
k_original_combined <- 481.524
k_unit_scale <- k_original_panel/2.2
k_box_width <- 24.609/k_unit_scale
k_step <- k_box_width+.52
k_edge <- .36/4
k_new_panel <- k_unit_scale*(2*k_box_width+.52+2*k_edge)
p <- plots$K
p$data <- copy(p$data)
p$data[, .compact_K_x:=ifelse(as.character(score_group)=='Low',1,1+k_step)]
p$mapping$x <- rlang::quo(.compact_K_x)
for(i in seq_along(p$layers)) {
  if(inherits(p$layers[[i]]$geom,'GeomBoxplot')) {p$layers[[i]]$geom_params$width <- k_box_width; p$layers[[i]]$stat_params$width <- k_box_width}
  if(inherits(p$layers[[i]]$position,'PositionJitter')) p$layers[[i]]$position$seed <- 20261008L
  if('x' %in% names(p$layers[[i]]$mapping)) p$layers[[i]]$mapping$x <- rlang::quo(1+k_step/2)
}
plots$K <- p + scale_x_continuous(breaks=c(1,1+k_step),labels=c('Low','High'),
  limits=c(1-k_box_width/2-k_edge,1+k_step+k_box_width/2+k_edge),expand=expansion(mult=0))
rows <- list((plots$A|plots$B|plots$C)+plot_layout(widths=c(1,1,1)),
             plots$D|plots$E|plots$F,plots$G|plots$H|plots$I|plots$J,
             (plots$K|plots$L)+plot_layout(widths=c(1,1)))
fig <- (rows[[1]]/rows[[2]]/rows[[3]]/rows[[4]]) +
  plot_layout(heights=c(1,1,1,1.08),guides='keep') +
  plot_annotation(caption=paste(
    'Global medians across all 14,302 Williams fibroblasts: B/D use AddModuleScore; C/E use AUCell. Downstream groups use the global median of the two-method consensus score.',
    'All p values are raw (unadjusted). UMAPs hide 4 isolated cells for display only; all analyses retain them.',sep='\n'),
    theme=theme(plot.caption=element_text(family='Arial',size=6,hjust=0)))
base <- 'Fig2_Williams_VD46_global_median_A_L_20261008_tightUMAP_Kboxes_v2'
if(Sys.getenv('SKIP_HIGHRES_PNG')!='1') base <- paste0(base,'_final')
out_pdf <- file.path(ROOT,'figures',paste0(base,'.pdf'))
out_png <- file.path(ROOT,'figures',paste0(base,'.png'))
stopifnot(!file.exists(out_pdf),!file.exists(out_png))
render <- tempfile('tightUMAP_Kboxes_v2_fig2_',tmpdir='C:/wb_temp')
dir.create(render)
render <- normalizePath(render,winslash='/',mustWork=TRUE)
pdf_path <- file.path(render,paste0(base,'.pdf'))
png_path <- file.path(render,paste0(base,'.png'))
cairo_pdf(pdf_path,width=15.3,height=12.4,family='Arial')
gt <- patchworkGrob(fig)
for(row in 2:3) {
  idx <- which(gt$layout$name==paste0('patchwork-table-',row))
  child <- gt$grobs[[idx]]
  tags <- if(row==2) c('D','E','F') else c('G','H','I','J')
  for(i in seq_along(tags)) {
    col <- child$layout$l[child$layout$name==paste0('panel-',i)]
    stopifnot(length(col)==1L)
    target <- metrics[[tags[i]]]$new_panel_width_pt
    if(is.null(target)) target <- metrics[[tags[i]]]$old_panel_width_pt
    child$widths[col] <- grid::unit(target,'bigpts')
  }
  gt$grobs[[idx]] <- child
}

idx <- which(gt$layout$name=='patchwork-table-1')
child <- gt$grobs[[idx]]
panel_cols <- unique(child$layout$l[grepl('^panel;',child$layout$name)])
stopifnot(length(panel_cols)==3L)
child$widths[panel_cols] <- grid::unit(rep(160,3),'bigpts')
gt$grobs[[idx]] <- child
idx <- which(gt$layout$name=='patchwork-table-4')
child <- gt$grobs[[idx]]
panel_cols <- unique(child$layout$l[grepl('^panel;',child$layout$name)])
stopifnot(length(panel_cols)==2L)
child$widths[panel_cols] <- grid::unit(c(k_original_combined-2*(k_original_panel-k_new_panel),481.524),'bigpts')
gt$grobs[[idx]] <- child
grid::grid.draw(gt); dev.off()
if(Sys.getenv('SKIP_HIGHRES_PNG')!='1') {
  ggsave(png_path,gt,width=15.3,height=12.4,units='in',dpi=600,bg='white')
  stopifnot(file.copy(png_path,out_png,overwrite=FALSE))
}
stopifnot(file.copy(pdf_path,out_pdf,overwrite=FALSE))
after <- tools::md5sum(protected)
stopifnot(identical(before,after))
write_json(list(created_at=format(Sys.time()),changed_panels=c('A','B','C','K'),previous_compaction_preserved=TRUE,UMAP_slot_width_pt=160,K_box_width_target_pt=24.609,K_edge_whitespace_factor=.25,
  whitespace_factor=.25,bar_width_unchanged=TRUE,box_width_unchanged=TRUE,
  point_size_and_fonts_unchanged=TRUE,unchanged_panel_widths=c('I','J'),
  analyses_not_recomputed=TRUE,original_files_unchanged=TRUE,
  protected_file_hashes=as.list(before),targets=metrics,output_pdf=out_pdf,output_png=out_png),
  file.path(SD,if(Sys.getenv('SKIP_HIGHRES_PNG')=='1') '71_tightUMAP_Kboxes_v2_manifest.json' else
    '74_tightUMAP_Kboxes_v2_final_manifest.json'),pretty=TRUE,auto_unbox=TRUE)
cat(out_pdf,'\n')
