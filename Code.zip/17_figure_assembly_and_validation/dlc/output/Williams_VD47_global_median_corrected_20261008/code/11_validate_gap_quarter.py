from pathlib import Path
import json, hashlib
from collections import Counter
import fitz
import numpy as np
from PIL import Image
root = Path('C:/wb_links/williams_vd47_global_20261008')
sd = root / 'source_data'
name = 'Fig2_Williams_VD46_global_median_A_L_20261008_gap_quarter_final'
path = root / 'figures' / (name + '.pdf')
doc = fitz.open(path)
assert len(doc) == 1, len(doc)
p = doc[0]
ds = p.get_drawings()
text = p.get_text()
old_doc = fitz.open(root / 'figures' / 'Fig2_Williams_VD46_global_median_combined_A_L_20261008_noGDF15_KL.pdf')
old = old_doc[0]
targets = json.loads((sd / '67_marked_gap_targets.json').read_text())
manifest = json.loads((sd / '69_gap_quarter_final_manifest.json').read_text())
for filename, md5 in manifest['protected_file_hashes'].items():
    assert hashlib.md5(Path(filename).read_bytes()).hexdigest() == md5, filename
assert all((text.splitlines().count(tag) == 1 for tag in 'ABCDEFGHIJKL'))
assert 'All p values are raw (unadjusted)' in text
assert 'p = 0.00127' in text and 'rho = 0.42, p = 0.06' in text
assert all(('Arial' in f[3] or 'Symbol' in f[3] for f in p.get_fonts()))
axes = sorted([d['rect'] for d in ds if d['color'] == (0, 0, 0) and d['rect'].height < 0.1 and (d['rect'].width > 80) and (300 < d['rect'].y0 < 600)], key=lambda r: (round(r.y0), r.x0))
assert len(axes) == 7, axes
qa = {}
for tag, axis in zip('DEFGHIJ', axes):
    record = {'panel_width_pt': axis.width}
    if tag in 'DEGH':
        rectangles = [d['rect'] for d in ds if d['fill'] is not None and d['fill'] != (1, 1, 1) and (d['rect'].width > 20) and (axis.x0 < d['rect'].x0 < axis.x1) and (axis.y0 - 150 < d['rect'].y0 < axis.y0)]
        xbounds = sorted(set(((round(r.x0, 3), round(r.x1, 3)) for r in rectangles)))
        assert len(xbounds) == (5 if tag in 'DE' else 2), (tag, xbounds)
        widths = [b - a for a, b in xbounds]
        gaps = [xbounds[i + 1][0] - xbounds[i][1] for i in range(len(xbounds) - 1)]
        edges = [xbounds[0][0] - axis.x0, axis.x1 - xbounds[-1][1]]
        ratios = np.array(gaps) / targets[tag]['old_between_gaps_pt']
        assert np.max(np.abs(ratios - 0.25)) < 0.002, (tag, ratios)
        assert np.max(np.abs(np.array(widths) - targets[tag]['old_mark_widths_pt'])) < 0.02, (tag, widths)
        if tag in 'GH':
            er = np.array(edges) / targets[tag]['old_edge_gaps_pt']
            assert np.max(np.abs(er - 0.25)) < 0.002, (tag, er)
            record['edge_gap_ratios'] = er.tolist()
        record.update(gap_ratios=ratios.tolist(), mark_widths_pt=widths)
    elif tag == 'F':
        points = [d['rect'] for d in ds if d['fill'] is not None and d['fill'] != (1, 1, 1) and (0 < d['rect'].width < 15) and (axis.x0 < d['rect'].x0 < axis.x1) and (axis.y0 - 150 < d['rect'].y0 < axis.y0) and any((it[0] == 'c' for it in d['items']))]
        groups = {}
        for r in points:
            groups.setdefault(round((r.x0 + r.x1) / 2, 1), []).append(r)
        assert len(groups) == 5, groups
        centers = sorted(groups)
        radii = [max((r.width for r in groups[c])) / 2 for c in centers]
        gaps = [centers[i + 1] - centers[i] - radii[i] - radii[i + 1] for i in range(4)]
        ratios = np.array(gaps) / targets[tag]['old_between_gaps_pt']
        assert np.max(np.abs(ratios - 0.25)) < 0.003, ratios
        assert np.max(np.abs(np.array(radii) - targets[tag]['max_dot_radii_pt'])) < 0.02, radii
        record.update(gap_ratios=ratios.tolist(), max_dot_radii_pt=radii)
    else:
        assert abs(axis.width - targets[tag]['old_panel_width_pt']) < 0.02, (tag, axis)
    qa[tag] = record
im = Image.open(path.with_suffix('.png'))
assert im.size == (9180, 7440) and abs(im.info['dpi'][0] - 600) < 1
p.get_pixmap(matrix=fitz.Matrix(1.5, 1.5), clip=fitz.Rect(0, 198, p.rect.width, 626)).save(sd / 'Fig2_gap_quarter_middle_QA.png')
qa.update(old_files_unchanged=True, png_pixels=im.size, png_dpi=im.info['dpi'], numerical_gap_verification_passed=True, visual_inspection_completed=False)
(sd / '70_gap_quarter_validation.json').write_text(json.dumps(qa, indent=2), encoding='utf-8')
print(json.dumps(qa, indent=2))
