from pathlib import Path
import json, hashlib
import fitz
from PIL import Image
root = Path('C:/wb_links/williams_vd47_global_20261008')
sd = root / 'source_data'
manifest = json.loads((sd / '62_noKLM_figure_manifest.json').read_text())
assert manifest['removed_original_panels'] == ['K', 'L', 'M']
assert manifest['original_files_unchanged']
for path, md5 in manifest['protected_file_hashes'].items():
    assert hashlib.md5(Path(path).read_bytes()).hexdigest() == md5, path
path = root / 'figures' / 'Fig2_Williams_VD46_global_median_combined_A_N_20261008_noKLM.pdf'
doc = fitz.open(path)
assert len(doc) == 1
page = doc[0]
text = page.get_text()
lines = text.splitlines()
assert all((lines.count(tag) == 1 for tag in 'ABCDEFGHIJKLMN'))
assert not any((tag in lines for tag in 'OPQ'))
assert not any((term.lower() in text.lower() for term in ['KEGG', 'GO enrichment', 'log2FC', 'pseudobulk']))
assert 'All p values are raw (unadjusted)' in text
assert 'GDF15' in text and 'MAPK/ERK (ERK1/2)' in text
assert all(('Arial' in f[3] or 'Symbol' in f[3] for f in page.get_fonts()))
im = Image.open(path.with_suffix('.png'))
assert im.size == (9180, 7440), im.size
assert abs(im.info['dpi'][0] - 600) < 1
axis = []
boxes = {tag: [] for tag in 'GHIJ'}
for draw in page.get_drawings():
    for item in draw['items']:
        if item[0] == 'l' and draw['color'] == (0.0, 0.0, 0.0) and (0.7 < draw['width'] < 1.1):
            a, b = item[1:]
            if draw['rect'].y1 < 0.25 * page.rect.height and (abs(a.x - b.x) < 0.01 or abs(a.y - b.y) < 0.01):
                length = abs(a - b)
                if 10 < length < 50:
                    axis.append(length)
        if item[0] == 're' and draw['fill'] is not None:
            rect = item[1]
            if 0.48 * page.rect.height < rect.y0 < 0.745 * page.rect.height and 10 < rect.width < 70 and (rect.height > 1):
                boxes[list(boxes)[min(int(rect.x0 / (page.rect.width / 4)), 3)]].append(rect.width)
assert len(axis) == 6 and max(axis) - min(axis) < 0.02, axis
assert len(boxes['G']) == 2 and len(boxes['H']) == 2 and (len(boxes['I']) == 5), boxes
assert max(boxes['G'] + boxes['H'] + boxes['I']) - min(boxes['G'] + boxes['H'] + boxes['I']) < 0.02, boxes
page.get_pixmap(matrix=fitz.Matrix(1.3, 1.3)).save(sd / 'Fig2_noKLM_final_QA.png')
for i in range(4):
    clip = fitz.Rect(0, page.rect.height * i / 4, page.rect.width, page.rect.height * (i + 1) / 4)
    page.get_pixmap(matrix=fitz.Matrix(1.8, 1.8), clip=clip).save(sd / f'Fig2_noKLM_row{i + 1}_QA.png')
qa = {'pdf_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'old_files_and_analytical_tables_unchanged': True, 'removed_panels_verified': True, 'remaining_tags': list('ABCDEFGHIJKLMN'), 'rows': [3, 3, 4, 4], 'png_pixels': im.size, 'dpi': im.info['dpi'], 'UMAP_axis_lengths': axis, 'box_widths': boxes, 'visual_inspection_completed': False}
(sd / '63_noKLM_validation.json').write_text(json.dumps(qa, indent=2), encoding='utf-8')
print(json.dumps(qa, indent=2))
