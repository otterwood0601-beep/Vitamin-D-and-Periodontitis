suppressPackageStartupMessages({library(data.table);library(ggplot2);library(patchwork);library(jsonlite)})
ROOT <- 'C:/wb_links/williams_vd47_global_20261008'
OLD <- 'C:/wb_links/williams_vd47_full_20261008'
SD <- file.path(ROOT,'source_data')
recipe <- readLines(file.path(OLD,'code','08_original_rawp_recipe.R'))
recipe <- recipe[seq_len(grep('^fig <-',recipe)-1L)]
recipe <- gsub(OLD,ROOT,recipe,fixed=TRUE)
recipe <- gsub('geom_boxplot(width = 0.54','geom_boxplot(width = 0.245384615384615',recipe,fixed=TRUE)
writeLines(recipe,file.path(ROOT,'code','03_global_plot_recipe.R'))
eval(parse(text=recipe),envir=.GlobalEnv)
add_axis <- function(p) {
  d <- cells[display_in_UMAP==TRUE]
  x <- min(d$frozen_umap_1)-1.2
  y <- min(d$frozen_umap_2)-.6
  p + annotate('segment',x=x,y=y,xend=x+2,yend=y,linewidth=.35,colour='black',
        arrow=grid::arrow(length=grid::unit(1.4,'mm'))) +
      annotate('segment',x=x,y=y,xend=x,yend=y+2,linewidth=.35,colour='black',
        arrow=grid::arrow(length=grid::unit(1.4,'mm'))) +
      annotate('text',x=x+1,y=y-.45,label='UMAP 1',family='Arial',size=2.5,hjust=.5,vjust=1) +
      annotate('text',x=x-.45,y=y+1,label='UMAP 2',family='Arial',size=2.5,angle=90) +
      coord_fixed(ratio=1,xlim=range(c(d$frozen_umap_1,x-.45)),
                  ylim=range(c(d$frozen_umap_2,y-.45)))
}
d <- cells[display_in_UMAP==TRUE]
pB$data <- d
pDisease <- add_axis(pB)
set.seed(20260925)
d <- d[sample(.N)]
map_method <- function(m) {
  d[,(paste0(m,'_group')):=factor(get(paste0(m,'_group')),levels=c('Low','High'))]
  p <- ggplot(d,aes(frozen_umap_1,frozen_umap_2,colour=.data[[paste0(m,'_group')]])) +
    geom_point(size=.13,alpha=.68) + scale_colour_manual(values=score_cols,name=NULL,drop=FALSE) +
    labs(title=paste0('VD46 ',m,': high / low')) + umap_theme +
    theme(legend.position=c(.78,.18),legend.background=element_rect(fill=scales::alpha('white',.78),colour=NA))
  add_axis(p)
}
pMapAMS <- map_method('AddModuleScore')
pMapAUC <- map_method('AUCell')
props <- fread(file.path(SD,'53_state_method_high_low_proportions.csv'))
props[,state:=factor(state,levels=state_levels)]
props[,score_group:=factor(score_group,levels=c('Low','High'))]
prop_method <- function(m) {
  z <- props[method==m]
  totals <- unique(z[,.(state,total_cells)])
  ggplot(z,aes(state,percent,fill=score_group)) +
    geom_col(width=.58,colour='white',linewidth=.25,position=position_stack(reverse=TRUE)) +
    geom_text(aes(label=sprintf('%.2f%%',percent)),position=position_stack(vjust=.5,reverse=TRUE),
      family='Arial',size=2.25,colour='black') +
    geom_text(data=totals,aes(state,104,label=paste0('n=',format(total_cells,big.mark=',',trim=TRUE))),
      inherit.aes=FALSE,family='Arial',size=2.15) +
    scale_fill_manual(values=score_cols,name=NULL,drop=FALSE) +
    scale_y_continuous(breaks=c(0,25,50,75,100),labels=function(v) paste0(v,'%'),
      limits=c(0,110),expand=expansion(mult=c(0,0))) +
    labs(title=paste0('VD46 ',m,': high / low by state'),x=NULL,y='Cells within each state (%)') +
    paper_theme + theme(axis.text.x=element_text(angle=42,hjust=1,size=6.3),legend.position='top')
}
pPropAMS <- prop_method('AddModuleScore')
pPropAUC <- prop_method('AUCell')
inventory <- c('pDisease','pMapAMS','pMapAUC','pPropAMS','pPropAUC','pD',
               'pF','pG','pH','pI','pJ','pK','pL','pM','pN','pO','pP')
plots <- setNames(lapply(inventory,get),LETTERS[seq_along(inventory)])
for (tag in names(plots)) plots[[tag]] <- plots[[tag]] + labs(tag=tag) +
  theme(plot.tag=element_text(family='Arial',size=10.5,face='plain'),plot.tag.position='topleft')
rows <- list((plots$A|plots$B|plots$C)+plot_layout(widths=c(1,1,1)),plots$D|plots$E|plots$F,
             plots$G|plots$H|plots$I|plots$J,plots$K|plots$L|plots$M,
             plots$N|plots$O|plots$P|plots$Q)
fig <- (rows[[1]]/rows[[2]]/rows[[3]]/rows[[4]]/rows[[5]]) +
  plot_layout(heights=c(1,1,1,1.08,1.08),guides='keep') +
  plot_annotation(caption=paste(
    'Global medians across all 14,302 Williams fibroblasts: B/D use AddModuleScore; C/E use AUCell. Downstream groups use the global median of the two-method consensus score.',
    'GDF15 comparisons use its held-out signature. All p values are raw (unadjusted); DE uses raw p < 0.05 and |log2FC| > 0.25. UMAPs hide 4 isolated cells for display only; all analyses retain them.',sep='\n'),
    theme=theme(plot.caption=element_text(family='Arial',size=6,hjust=0)))
base <- 'Fig2_Williams_VD46_global_median_combined_A_Q_20261008_corrected'
render <- tempfile('global_fig2_',tmpdir='C:/wb_temp')
dir.create(render)
render <- normalizePath(render,winslash='/',mustWork=TRUE)
pdf_path <- file.path(render,paste0(base,'.pdf'))
png_path <- file.path(render,paste0(base,'.png'))
ggsave(pdf_path,fig,width=15.3,height=15.5,units='in',device=cairo_pdf)
if (Sys.getenv('SKIP_HIGHRES_PNG')!='1') {
  ggsave(png_path,fig,width=15.3,height=15.5,units='in',dpi=600,bg='white')
  stopifnot(file.copy(png_path,file.path(ROOT,'figures'),overwrite=TRUE))
}
stopifnot(file.copy(pdf_path,file.path(ROOT,'figures'),overwrite=TRUE))
mapping <- data.table(panel=names(plots),plot_object=inventory,description=c(
  'Disease UMAP','AddModuleScore global high/low UMAP','AUCell global high/low UMAP',
  'AddModuleScore global high/low percentages by state','AUCell global high/low percentages by state',
  'VD/GDF15/ERK/MMP gene dotplot','Disease AddModuleScore','Disease AUCell',
  'State AddModuleScore','State AUCell','Global consensus high/low pseudobulk DE',
  'KEGG enrichment','GO enrichment','GDF15 held-out global high/low',
  'GDF15 held-out score correlation','ERK/MMP global high/low','ERK/MMP score correlation'))
fwrite(mapping,file.path(SD,'58_combined_panel_mapping.csv'))
write_json(list(created_at=format(Sys.time()),panel_order=names(plots),rows=c(3,3,4,3,4),
  width_inches=15.3,height_inches=15.5,axis_ratio_UMAP=1,font='Arial',raw_p=TRUE,
  combined_requested_three_figures=TRUE,source_scores_reused_without_recalculation=TRUE,
  regrouped_and_downstream_recomputed=TRUE,
  output_pdf=file.path(ROOT,'figures',basename(pdf_path)),output_png=file.path(ROOT,'figures',basename(png_path))),
  file.path(SD,'59_combined_figure_manifest.json'),pretty=TRUE,auto_unbox=TRUE)
cat(file.path(ROOT,'figures',basename(pdf_path)),'\n')
