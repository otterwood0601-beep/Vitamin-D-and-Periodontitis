ROOT <- 'C:/wb_links/williams_vd47_global_20261008'
code <- readLines(file.path(ROOT,'code','09_compact_marked_gaps.R'))
code <- gsub('09_compact_plot_recipe.R','12_tightUMAP_Kboxes_plot_recipe.R',code,fixed=TRUE)
code <- gsub('gap_quarter','tightUMAP_Kboxes_v2',code,fixed=TRUE)
code <- gsub('68_tightUMAP_Kboxes_v2_manifest.json','71_tightUMAP_Kboxes_v2_manifest.json',code,fixed=TRUE)
code <- gsub('69_tightUMAP_Kboxes_v2_final_manifest.json','74_tightUMAP_Kboxes_v2_final_manifest.json',code,fixed=TRUE)
code <- gsub("changed_panels=c('D','E','F','G','H')",
             "changed_panels=c('A','B','C','K'),previous_compaction_preserved=TRUE,UMAP_slot_width_pt=160,K_box_width_target_pt=24.609,K_edge_whitespace_factor=.25",code,fixed=TRUE)
before_rows <- c(
  "# K: preserve inter-box clear gap, narrow each box to G/H, and quarter both outer gaps.",
  "k_original_panel <- 229.281",
  "k_original_combined <- 481.524",
  "k_unit_scale <- k_original_panel/2.2",
  "k_box_width <- 24.609/k_unit_scale",
  "k_step <- k_box_width+.52",
  "k_edge <- .36/4",
  "k_new_panel <- k_unit_scale*(2*k_box_width+.52+2*k_edge)",
  "p <- plots$K",
  "p$data <- copy(p$data)",
  "p$data[, .compact_K_x:=ifelse(as.character(score_group)=='Low',1,1+k_step)]",
  "p$mapping$x <- rlang::quo(.compact_K_x)",
  "for(i in seq_along(p$layers)) {",
  "  if(inherits(p$layers[[i]]$geom,'GeomBoxplot')) {p$layers[[i]]$geom_params$width <- k_box_width; p$layers[[i]]$stat_params$width <- k_box_width}",
  "  if(inherits(p$layers[[i]]$position,'PositionJitter')) p$layers[[i]]$position$seed <- 20261008L",
  "  if('x' %in% names(p$layers[[i]]$mapping)) p$layers[[i]]$mapping$x <- rlang::quo(1+k_step/2)",
  "}",
  "plots$K <- p + scale_x_continuous(breaks=c(1,1+k_step),labels=c('Low','High'),",
  "  limits=c(1-k_box_width/2-k_edge,1+k_step+k_box_width/2+k_edge),expand=expansion(mult=0))"
)
at <- grep('^rows <- list',code)
stopifnot(length(at)==1L)
code <- append(code,before_rows,after=at-1L)
before_draw <- c(
  "# Fixed slots remove empty margins while coord_fixed preserves UMAP size and 1:1 axes.",
  "idx <- which(gt$layout$name=='patchwork-table-1')",
  "child <- gt$grobs[[idx]]",
  "panel_cols <- unique(child$layout$l[grepl('^panel;',child$layout$name)])",
  "stopifnot(length(panel_cols)==3L)",
  "child$widths[panel_cols] <- grid::unit(rep(160,3),'bigpts')",
  "gt$grobs[[idx]] <- child",
  "idx <- which(gt$layout$name=='patchwork-table-4')",
  "child <- gt$grobs[[idx]]",
  "panel_cols <- unique(child$layout$l[grepl('^panel;',child$layout$name)])",
  "stopifnot(length(panel_cols)==2L)",
  "child$widths[panel_cols] <- grid::unit(c(k_original_combined-2*(k_original_panel-k_new_panel),481.524),'bigpts')",
  "gt$grobs[[idx]] <- child"
)
at <- grep('^grid::grid.draw',code)
stopifnot(length(at)==1L)
code <- append(code,before_draw,after=at-1L)
writeLines(code,file.path(ROOT,'code','12_tightUMAP_Kboxes_render_recipe.R'))
eval(parse(text=code),envir=.GlobalEnv)
