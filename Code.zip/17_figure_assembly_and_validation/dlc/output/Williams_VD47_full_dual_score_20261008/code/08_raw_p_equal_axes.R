suppressPackageStartupMessages({library(data.table); library(jsonlite)})
ROOT <- 'C:/wb_links/williams_vd47_full_20261008'
SD <- file.path(ROOT,'source_data')
sources <- file.path(SD,c('03_Williams_VD47_dual_scores.csv.gz',
  '08_paired_pseudobulk_high_vs_low_DE.csv.gz','10_disease_score_tests.csv',
  '11_high_low_endpoint_tests.csv','12_endpoint_correlations.csv'))
before <- tools::md5sum(sources)
de <- fread(sources[2])
universe <- de[in_VD47_signature == FALSE,gene]
foreground <- de[in_VD47_signature == FALSE & P.Value < .05 & logFC > .25,gene]
down <- de[in_VD47_signature == FALSE & P.Value < .05 & logFC < -.25,gene]
fwrite(de[in_VD47_signature == FALSE,
  .(gene,logFC,raw_p = P.Value,direction = fifelse(P.Value < .05 & logFC > .25,'Up',
                    fifelse(P.Value < .05 & logFC < -.25,'Down','NS')))],
  file.path(SD,'38_rawp_DE_plot_data.csv'))
writeLines(foreground,file.path(SD,'39_rawp_enrichment_input_genes.txt'))
files <- c(GO_Biological_Process_2025 = 'C:/wb_links/genesets/GO_Biological_Process_2025.gmt',
           KEGG_2021_Human = file.path(SD,'KEGG_2021_Human.gmt'))
for (db in names(files)) {
  sets <- lapply(readLines(files[[db]],warn = FALSE),function(ln) {
    z <- strsplit(ln,'\t',fixed = TRUE)[[1]]
    list(Term = z[1],genes = intersect(unique(z[-c(1,2)]),universe))
  })
  sets <- Filter(function(z) length(z$genes) >= 5 && length(z$genes) <= 500,sets)
  result <- rbindlist(lapply(sets,function(z) {
    ov <- intersect(foreground,z$genes)
    data.table(Term = z$Term,Count = length(ov),
      P.value = phyper(length(ov)-1,length(z$genes),length(universe)-length(z$genes),
                       length(foreground),lower.tail = FALSE),
      Genes = paste(ov,collapse = ';'),term_background_genes = length(z$genes),
      input_gene_count = length(foreground),universe_count = length(universe))
  }))
  setorder(result,P.value)
  fwrite(result,file.path(SD,paste0('40_rawp_',db,'.csv')))
  print(result[Count > 0 & P.value < .05,.(Term,Count,P.value)][1:8])
}
recipe <- readLines(file.path(ROOT,'code','03_original_recipe_adapted.R'))
recipe <- gsub('15_VD47_high_','40_rawp_',recipe,fixed = TRUE)
recipe <- gsub('Adjusted.P.value','P.value',recipe,fixed = TRUE)
recipe <- gsub('neglog10_FDR','-log10(pmax(P.Value,1e-300))',recipe,fixed = TRUE)
recipe <- gsub('order(adj.P.Val)','order(P.Value)',recipe,fixed = TRUE)
recipe <- gsub('expression(-log[10](FDR))','expression(-log[10](raw~p))',recipe,fixed = TRUE)
recipe <- gsub('expression(-log[10](adjusted~p))','expression(-log[10](raw~p))',recipe,fixed = TRUE)
idx <- grep('^de_plot <-',recipe)
stopifnot(length(idx)==1)
recipe <- append(recipe,c(
  "de_plot[, direction := fifelse(P.Value < .05 & logFC > .25,'Up',fifelse(P.Value < .05 & logFC < -.25,'Down','NS'))]"
),after = idx)
idx <- grep('q < 0.001|q = ',recipe)
stopifnot(length(idx)==2)
recipe[idx] <- c(
  '    fmt_p(paired_tests[endpoint == "MAPK_ERK", p_value][1]),',
  '    fmt_p(paired_tests[endpoint == "ECM_degradation", p_value][1])'
)
idx <- grep('^fmt_p <-',recipe)
recipe <- append(recipe,'  # All displayed p values are unadjusted, per user request.',after=idx)
writeLines(recipe,file.path(ROOT,'code','08_original_rawp_recipe.R'))

layout <- readLines(file.path(ROOT,'code','07_Aaxes_recipe_adapted.R'))
layout <- gsub('03_original_recipe_adapted.R','08_original_rawp_recipe.R',layout,fixed=TRUE)

layout <- gsub('1.061057612096422','0.8278989098718522',layout,fixed=TRUE)
layout <- gsub('20261008_noACE_Aaxes','20261008_noACE_Aaxes1to1_rawp',layout,fixed=TRUE)
layout <- gsub('33_Aaxes_panel_label_mapping.csv','41_rawp_panel_label_mapping.csv',layout,fixed=TRUE)
layout <- gsub('34_Aaxes_layout_manifest.json','42_rawp_layout_manifest.json',layout,fixed=TRUE)
idx <- grep('^plots <-',layout)
layout <- append(layout,c(
  "pB <- pB + coord_fixed(ratio = 1)",
  "fig_note <- 'Exploratory analysis: all p values are raw (unadjusted); DE: raw p < 0.05 and |log2FC| > 0.25.'"
),after=idx-1)
idx <- grep('plot_layout(heights',layout,fixed = TRUE)
stopifnot(length(idx)==1)
layout[idx] <- paste0(layout[idx]," + plot_annotation(caption = fig_note,theme = theme(plot.caption = element_text(family = 'Arial',size = 6,hjust = 0)))")
writeLines(layout,file.path(ROOT,'code','08_rawp_layout_recipe.R'))
eval(parse(text = layout),envir = .GlobalEnv)
stopifnot(identical(unname(before),unname(tools::md5sum(sources))))
stopifnot(ggplot_build(pB)$plot$coordinates$ratio == 1)
mf <- file.path(SD,'42_rawp_layout_manifest.json')
man <- read_json(mf,simplifyVector = TRUE)
man$revision <- 'A fixed 1:1 x/y units; all plotted tests and enrichment/DE thresholds use raw p'
man$unchanged_statistics <- FALSE
man$original_test_statistics_preserved <- TRUE
man$panel_A_coordinate_ratio <- 1
man$DE_threshold <- 'raw p < 0.05 and absolute log2FC > 0.25; all signature candidates excluded'
man$raw_p_non_signature_up <- length(foreground)
man$raw_p_non_signature_down <- length(down)
man$universe_n <- length(universe)
man$enrichment <- 'raw-p DE foreground; one-sided hypergeometric raw p < 0.05; no multiple-testing correction'
man$inference_scope <- 'Exploratory nominal significance; not multiplicity-controlled confirmation'
man$source_md5_unchanged <- as.list(before)
man$panel_A_display_n <- nrow(display_A)
man$analysis_n <- nrow(cells)
write_json(man,mf,pretty=TRUE,auto_unbox=TRUE)
cat('RAW P UP:',length(foreground),'DOWN:',length(down),'\n')
