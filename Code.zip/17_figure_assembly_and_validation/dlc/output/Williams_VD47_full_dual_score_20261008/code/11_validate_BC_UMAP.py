from pathlib import Path
import json
import hashlib
import fitz
import numpy as np
import pandas as pd
from PIL import Image
root = Path('C:/wb_links/williams_vd47_full_20261008')
sd = root / 'source_data'
src = pd.read_csv(sd / '03_Williams_VD47_dual_scores.csv.gz')
maps = pd.read_csv(sd / '47_BC_method_high_low_cell_groups.csv.gz')
assert len(src) == len(maps) == 14302
assert maps.cell_id.is_unique
joined = maps.merge(src, on='cell_id', validate='one_to_one', suffixes=('_map', '_src'))
for col in ['AddModuleScore', 'AUCell', 'frozen_umap_1', 'frozen_umap_2']:
    assert np.allclose(joined[col + '_map'], joined[col + '_src'], rtol=0, atol=1e-14)
counts = {}
for method in ['AddModuleScore', 'AUCell']:
    medians = maps.groupby(['donor_id', 'state'])[method].transform('median')
    group = np.where(maps[method] > medians, 'High', 'Low')
    assert np.allclose(maps[method + '_threshold'], medians, rtol=0, atol=1e-14)
    assert (group == maps[method + '_group']).all()
    counts[method] = maps[method + '_group'].value_counts().to_dict()
assert (maps.display_in_BC == (maps.frozen_umap_1 >= -8)).all()
assert maps.display_in_BC.sum() == 14298
old_omitted = pd.read_csv(sd / '35_A_display_omitted_cells.csv')
assert set(maps.loc[~maps.display_in_BC, 'cell_id']) == set(old_omitted.cell_id)
path = root / 'figures' / 'Fig2_B_C_Williams_VD46_AddModuleScore_AUCell_high_low_UMAP_20261008_compact.pdf'
doc = fitz.open(path)
assert len(doc) == 1
page = doc[0]
text = page.get_text()
for phrase in ['B', 'C', 'AddModuleScore', 'AUCell', 'Low', 'High', 'UMAP 1', 'UMAP 2']:
    assert phrase in text
assert all(('Arial' in f[3] or 'Symbol' in f[3] for f in page.get_fonts()))
axis_lengths = []
for path_data in page.get_drawings():
    if path_data['color'] == (0.0, 0.0, 0.0) and 0.7 < path_data['width'] < 1.1:
        for item in path_data['items']:
            if item[0] == 'l':
                a, b = item[1:]
                if abs(a.x - b.x) < 0.01 or abs(a.y - b.y) < 0.01:
                    axis_lengths.append(abs(a - b))
assert len(axis_lengths) == 4, axis_lengths
assert max(axis_lengths) - min(axis_lengths) < 0.02, axis_lengths
png = Image.open(path.with_suffix('.png'))
assert abs(png.info['dpi'][0] - 600) < 1
page.get_pixmap(matrix=fitz.Matrix(2, 2)).save(sd / '51_BC_UMAP_QA.png')
qa = dict(method_group_counts=counts, source_scores_and_coordinates_unchanged=True, independent_grouping_validation=True, same_display_exclusions_as_A=True, equal_axis_stroke_points=axis_lengths, png_pixels=png.size, png_dpi=png.info['dpi'], sha256=hashlib.sha256(path.read_bytes()).hexdigest())
(sd / '52_BC_UMAP_QA.json').write_text(json.dumps(qa, indent=2), encoding='utf-8')
print(json.dumps(qa, indent=2))
