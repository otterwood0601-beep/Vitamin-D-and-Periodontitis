suppressPackageStartupMessages({library(data.table); library(ggplot2);
  library(patchwork); library(jsonlite)})
ROOT <- 'C:/wb_links/williams_vd47_full_20261008'
SD <- file.path(ROOT,'source_data')
input <- file.path(SD,'47_BC_method_high_low_cell_groups.csv.gz')
before <- tools::md5sum(input)
recipe <- readLines(file.path(ROOT,'code','08_original_rawp_recipe.R'))
stop_at <- grep('# A-C:',recipe,fixed=TRUE)
eval(parse(text=recipe[seq_len(stop_at-1)]),envir=.GlobalEnv)
groups <- fread(input)
stopifnot(nrow(groups)==14302L,!anyDuplicated(groups$cell_id))
props <- rbindlist(lapply(c('AddModuleScore','AUCell'),function(m) {
  a <- groups[,.(n_cells=.N),by=c('state',paste0(m,'_group'))]
  setnames(a,paste0(m,'_group'),'score_group')
  a[, total_cells:=sum(n_cells),by=state]
  a[, `:=`(percent=100*n_cells/total_cells,method=m)]
  a
}))
props[,state:=factor(state,levels=state_levels)]
props[,score_group:=factor(score_group,levels=c('Low','High'))]
setorder(props,method,state,score_group)
stopifnot(all(props[,sum(n_cells),by=method]$V1==14302L))
stopifnot(all(abs(props[,sum(percent),by=.(method,state)]$V1-100)<1e-10))
fwrite(props,file.path(SD,'53_state_method_high_low_proportions.csv'))
wide <- dcast(props,state+total_cells~method+score_group,value.var='percent')
fwrite(wide,file.path(SD,'54_state_method_high_low_proportions_wide.csv'))
plot_method <- function(m,tag) {
  d <- props[method==m]
  totals <- unique(d[,.(state,total_cells)])
  ggplot(d,aes(state,percent,fill=score_group)) +
    geom_col(width=.58,colour='white',linewidth=.25,position=position_stack(reverse=TRUE)) +
    geom_text(aes(label=sprintf('%.2f%%',percent)),
      position=position_stack(vjust=.5,reverse=TRUE),family='Arial',size=2.25,colour='black') +
    geom_text(data=totals,aes(state,104,label=paste0('n=',format(total_cells,big.mark=',',trim=TRUE))),
      inherit.aes=FALSE,family='Arial',size=2.15) +
    scale_fill_manual(values=score_cols,name=NULL,drop=FALSE) +
    scale_y_continuous(breaks=c(0,25,50,75,100),labels=function(v) paste0(v,'%'),
      limits=c(0,110),expand=expansion(mult=c(0,0))) +
    labs(title=paste0('VD46 ',m,': high / low by state'),x=NULL,y='Cells within each state (%)',tag=tag) +
    paper_theme + theme(axis.text.x=element_text(angle=42,hjust=1,size=6.3),
      plot.tag=element_text(family='Arial',size=10.5,face='plain'),
      plot.tag.position='topleft',legend.position='top',legend.direction='horizontal')
}
fig <- (plot_method('AddModuleScore','D') | plot_method('AUCell','E')) +
  plot_annotation(caption=paste(
    'All 14,302 Williams gingival fibroblasts included; denominators are all cells in each state.',
    'High > median; Low <= median, separately within each donor and fibroblast state for each method.',
    'Near-50/50 proportions arise from the grouping rule; this is not a subtype enrichment test.',sep='\n'),
    theme=theme(plot.caption=element_text(family='Arial',size=6,hjust=0)))
base <- 'Fig2_D_E_Williams_VD46_five_states_high_low_proportions_20261008'
render <- tempfile('stateprops_',tmpdir='C:/wb_temp')
dir.create(render)
render <- normalizePath(render,winslash='/',mustWork=TRUE)
for (ext in c('pdf','png')) {
  p <- file.path(render,paste0(base,'.',ext))
  if (ext=='pdf') ggsave(p,fig,width=10.2,height=3.7,units='in',device=cairo_pdf)
  else ggsave(p,fig,width=10.2,height=3.7,units='in',dpi=600,bg='white')
  dest <- file.path(ROOT,'figures',basename(p))
  if (file.exists(dest)) stop('Existing output must be preserved: ',dest)
  stopifnot(file.copy(p,dest,overwrite=FALSE))
}
stopifnot(identical(unname(before),unname(tools::md5sum(input))))
write_json(list(created_at=format(Sys.time()),input=input,source_input_md5=as.list(before),
  source_grouping='same cell-level method-specific labels as previous B/C maps, no reclassification',
  dataset='Williams human gingival fibroblasts',cells=14302L,include_display_omitted_four=TRUE,
  denominator='all cells in each fibroblast state; cell-pooled descriptive proportions, not donor means',
  inferential_tests='none; descriptive counts and fractions only',
  group_rule='within donor and state median per method; ties retained Low',
  old_figures_preserved=TRUE,colours=score_cols,
  output_pdf=file.path(ROOT,'figures',paste0(base,'.pdf'))),
  file.path(SD,'55_state_high_low_proportions_manifest.json'),pretty=TRUE,auto_unbox=TRUE)
print(wide)
