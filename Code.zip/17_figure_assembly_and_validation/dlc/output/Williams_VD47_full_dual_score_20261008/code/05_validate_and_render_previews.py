from pathlib import Path
import json
import hashlib
import fitz
import pandas as pd
import numpy as np
from scipy import stats
from PIL import Image
root = Path('C:/wb_links/williams_vd47_full_20261008')
sd = root / 'source_data'
old = Path('C:/wb_links/jhazmat2026_no2uc_20260925/figures')
latest = Path('C:/wb_links/williams_vd47_fg_20261008/source_data')
cells = pd.read_csv(sd / '03_Williams_VD47_dual_scores.csv.gz')
prior = pd.read_csv(latest / '03_Williams_VD47_dual_scores.csv.gz')
joined = cells.merge(prior[['cell_id', 'AddModuleScore', 'AUCell']], on='cell_id', validate='one_to_one')
assert len(joined) == 14302
for score in ['AddModuleScore', 'AUCell']:
    assert np.allclose(joined[score + '_x'], joined[score + '_y'], rtol=0, atol=1e-14)
    donor = cells.groupby(['donor_id', 'disease'])[score].median().reset_index()
    a = donor.loc[donor.disease == 'normal', score]
    b = donor.loc[donor.disease == 'periodontitis', score]
    p = stats.mannwhitneyu(a, b, alternative='two-sided', method='asymptotic', use_continuity=True).pvalue
    expected = pd.read_csv(sd / '10_disease_score_tests.csv').set_index('endpoint').loc[score, 'p_value']
    assert abs(p - expected) < 1e-12
bulk = pd.read_csv(sd / '18_bulk_VD35_score_and_Bisque_fractions.csv')
cohort = pd.get_dummies(bulk.dataset, drop_first=True).astype(float).to_numpy()
x = np.column_stack([np.ones(len(bulk)), cohort])
score = bulk.VD35_score.to_numpy()
frac = np.arcsin(np.sqrt(bulk['T/NK'].clip(0, 1).to_numpy()))
rx = score - x @ np.linalg.lstsq(x, score, rcond=None)[0]
ry = frac - x @ np.linalg.lstsq(x, frac, rcond=None)[0]
r = np.corrcoef(rx, ry)[0, 1]
df = len(bulk) - x.shape[1] - 1
p = 2 * stats.t.sf(abs(r * np.sqrt(df / (1 - r * r))), df)
expected = pd.read_csv(sd / '20_VD35_TNK_partial_correlation.csv').iloc[0]
assert abs(r - expected['r']) < 1e-12 and abs(p - expected['p_value']) < 1e-12
bulk['VD35_adjusted_score'] = rx
bulk['TNK_adjusted_fraction'] = ry
bulk.to_csv(sd / '28_bulk_K_exact_plotted_variables.csv', index=False)
names = ['Fig2_Williams_VitaminD_GDF15_ERK_MMP_dual_scoring_JHazMat_style_20261008', 'Fig1F_J_K_VD35_correlation_Bisque_JHazMat_style_20261008']
qa = dict(cells=14302, donor_labels=21, full_scores_equal_previous=True, independent_Wilcoxon_recalculation_passed=True, independent_bulk_partial_correlation_passed=True, bulk_samples=len(bulk), bulk_signature_n=35, files=[])
for name in names:
    path = root / 'figures' / f'{name}.pdf'
    doc = fitz.open(path)
    assert len(doc) == 1
    text = doc[0].get_text()
    assert 'VD17' not in text and 'p = 0.00\n' not in text
    for tag in list('ABCDEFGHIJKLMNOP') if name.startswith('Fig2') else ['F', 'J', 'K']:
        assert tag in text.splitlines()
    if name.startswith('Fig2'):
        assert 'VD46 AddModuleScore' in text and 'VD45 held-out score' in text
        assert 'q = 0.068' in text
    else:
        assert 'VD35' in text and 'Cohort-adjusted VD35 score' in text
    fonts = doc[0].get_fonts()
    assert all(('Arial' in f[3] or 'Symbol' in f[3] for f in fonts))
    png = Image.open(path.with_suffix('.png'))
    assert abs(png.info['dpi'][0] - 600) < 1
    doc[0].get_pixmap(matrix=fitz.Matrix(1.4, 1.4)).save(sd / f'QA_{name}.png')
    if name.startswith('Fig2'):
        rect = doc[0].rect
        for i in range(4):
            clip = fitz.Rect(0, rect.height * i / 4, rect.width, rect.height * (i + 1) / 4)
            doc[0].get_pixmap(matrix=fitz.Matrix(2, 2), clip=clip).save(sd / f'QA_Fig2_row{i + 1}.png')
    qa['files'].append(dict(name=path.name, sha256=hashlib.sha256(path.read_bytes()).hexdigest(), png_pixels=png.size, font_names=[f[3] for f in fonts]))
for mf, key in [('16_figure_manifest.json', 'outputs'), ('21_Fig1F_J_K_manifest.json', 'output')]:
    data = json.loads((sd / mf).read_text(encoding='utf-8'))
    data[key] = [str(root / 'figures' / Path(p).name).replace('\\', '/') for p in data[key]]
    (sd / mf).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
qa['legacy_pdfs_sha256'] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in old.glob('*.pdf') if p.name in ['Fig2_Williams_VitaminD_GDF15_ERK_MMP_dual_scoring_JHazMat_style.pdf', 'Fig1F_J_K_VD17_correlation_Bisque_JHazMat_style.pdf']}
(sd / '29_validation_record.json').write_text(json.dumps(qa, indent=2), encoding='utf-8')
print(json.dumps(qa, indent=2))
