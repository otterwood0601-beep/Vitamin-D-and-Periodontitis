from pathlib import Path
import hashlib
import json
import fitz
import numpy as np
import pandas as pd
from PIL import Image
root = Path('C:/wb_links/williams_vd47_full_20261008')
sd = root / 'source_data'
cells = pd.read_csv(sd / '03_Williams_VD47_dual_scores.csv.gz')
actual = pd.read_csv(sd / '53_state_method_high_low_proportions.csv')
expected = []
for m in ['AddModuleScore', 'AUCell']:
    d = cells[['donor_id', 'state', m]].copy()
    threshold = d.groupby(['donor_id', 'state'])[m].transform('median')
    d['score_group'] = np.where(d[m] > threshold, 'High', 'Low')
    n = d.groupby(['state', 'score_group']).size().rename('n_cells').reset_index()
    n['method'] = m
    n['total_cells'] = n.groupby('state').n_cells.transform('sum')
    n['percent'] = 100 * n.n_cells / n.total_cells
    expected.append(n)
expected = pd.concat(expected, ignore_index=True)
v = actual.merge(expected, on=['method', 'state', 'score_group'], suffixes=('_plot', '_independent'), validate='one_to_one')
assert len(v) == 20
for col in ['n_cells', 'total_cells', 'percent']:
    assert np.allclose(v[col + '_plot'], v[col + '_independent'], rtol=0, atol=1e-12)
assert (actual.groupby('method').n_cells.sum() == 14302).all()
assert np.allclose(actual.groupby(['method', 'state']).percent.sum(), 100)
path = root / 'figures' / 'Fig2_D_E_Williams_VD46_five_states_high_low_proportions_20261008.pdf'
doc = fitz.open(path)
assert len(doc) == 1
page = doc[0]
text = page.get_text()
for phrase in ['D', 'E', 'AddModuleScore', 'AUCell', 'Immune', 'ECM remodeling', 'Vascular', 'Pre-ECM', 'Matrix homeostasis', '50%', '100%']:
    assert phrase in text, phrase
for value in actual.percent:
    assert f'{value:.2f}%' in text
for n in actual.total_cells.unique():
    assert f'n={n:,}' in text
assert all(('Arial' in f[3] or 'Symbol' in f[3] for f in page.get_fonts()))
png = Image.open(path.with_suffix('.png'))
assert abs(png.info['dpi'][0] - 600) < 1
page.get_pixmap(matrix=fitz.Matrix(1.8, 1.8)).save(sd / '56_state_proportions_QA.png')
qa = dict(independent_recalculation_from_original_scores=True, rows=len(actual), total_cells=14302, percent_sums_verified=True, labels_and_totals_verified=True, png_pixels=png.size, png_dpi=png.info['dpi'], sha256=hashlib.sha256(path.read_bytes()).hexdigest())
(sd / '57_state_proportions_QA.json').write_text(json.dumps(qa, indent=2), encoding='utf-8')
print(pd.read_csv(sd / '54_state_method_high_low_proportions_wide.csv').to_string(index=False))
print(json.dumps(qa, indent=2))
