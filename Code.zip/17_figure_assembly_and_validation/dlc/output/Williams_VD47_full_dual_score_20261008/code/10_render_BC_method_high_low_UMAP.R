suppressPackageStartupMessages({library(data.table); library(ggplot2);
  library(patchwork); library(jsonlite)})
ROOT <- 'C:/wb_links/williams_vd47_full_20261008'
SD <- file.path(ROOT,'source_data')
src <- file.path(SD,'03_Williams_VD47_dual_scores.csv.gz')
src_md5 <- tools::md5sum(src)
recipe <- readLines(file.path(ROOT,'code','08_original_rawp_recipe.R'))
recipe <- recipe[seq_len(grep('^fig <-',recipe)-1L)]
eval(parse(text=recipe),envir=.GlobalEnv)
stopifnot(nrow(cells)==14302L,!anyDuplicated(cells$cell_id))
for (method in c('AddModuleScore','AUCell')) {
  threshold_col <- paste0(method,'_threshold')
  group_col <- paste0(method,'_group')
  cells[, (threshold_col) := median(get(method)),by=.(donor_id,state)]
  cells[, (group_col) := factor(ifelse(get(method)>get(threshold_col),'High','Low'),
                                levels=c('Low','High'))]
}
cells[, display_in_BC := frozen_umap_1 >= -8]
stopifnot(sum(!cells$display_in_BC)==4L)
maps <- cells[display_in_BC==TRUE]

set.seed(20260925)
maps <- maps[sample(.N)]
axis_x <- min(maps$frozen_umap_1)-1.2
axis_y <- min(maps$frozen_umap_2)-.6
xlim_bc <- range(c(maps$frozen_umap_1,axis_x-.45))
ylim_bc <- range(c(maps$frozen_umap_2,axis_y-.45))
make_map <- function(method,tag) {
  ggplot(maps,aes(frozen_umap_1,frozen_umap_2,colour=.data[[paste0(method,'_group')]])) +
    geom_point(size=.13,alpha=.68) +
    scale_colour_manual(values=score_cols,drop=FALSE,name=NULL) +
    annotate('segment',x=axis_x,y=axis_y,xend=axis_x+2,yend=axis_y,
      linewidth=.35,colour='black',arrow=grid::arrow(length=grid::unit(1.4,'mm'))) +
    annotate('segment',x=axis_x,y=axis_y,xend=axis_x,yend=axis_y+2,
      linewidth=.35,colour='black',arrow=grid::arrow(length=grid::unit(1.4,'mm'))) +
    annotate('text',x=axis_x+1,y=axis_y-.45,label='UMAP 1',family='Arial',
             size=2.5,hjust=.5,vjust=1) +
    annotate('text',x=axis_x-.45,y=axis_y+1,label='UMAP 2',family='Arial',
             size=2.5,angle=90,hjust=.5,vjust=.5) +
    coord_fixed(ratio=1,xlim=xlim_bc,ylim=ylim_bc) +
    labs(title=paste0('VD46 ',method,': high / low'),tag=tag) + umap_theme +
    theme(legend.position=c(.78,.18),
      legend.background=element_rect(fill=scales::alpha('white',.78),colour=NA),
      plot.tag=element_text(family='Arial',size=10.5,face='plain'),
      plot.tag.position='topleft')
}
p_mapB <- make_map('AddModuleScore','B')
p_mapC <- make_map('AUCell','C')
fig_bc <- (p_mapB | p_mapC) + plot_annotation(
  caption=paste('High: above the method-specific median within each donor / fibroblast state; Low: at or below the median.',
                '14,298 cells displayed; 4 isolated cells omitted from display only. Scores and analyses retain all 14,302 cells.',sep='\n'),
  theme=theme(plot.caption=element_text(family='Arial',size=5.8,hjust=0)))
base <- 'Fig2_B_C_Williams_VD46_AddModuleScore_AUCell_high_low_UMAP_20261008_compact'
render <- tempfile('BCmaps_',tmpdir='C:/wb_temp')
dir.create(render)
render <- normalizePath(render,winslash='/',mustWork=TRUE)
for (ext in c('pdf','png')) {
  path <- file.path(render,paste0(base,'.',ext))
  if (ext=='pdf') ggsave(path,fig_bc,width=5.1,height=3.1,units='in',device=cairo_pdf)
  else ggsave(path,fig_bc,width=5.1,height=3.1,units='in',dpi=600,bg='white')
  dest <- file.path(ROOT,'figures',basename(path))
  if (file.exists(dest)) stop('Do not overwrite an existing B/C export: ',dest)
  stopifnot(file.copy(path,dest,overwrite=FALSE))
}
fwrite(cells[,.(cell_id,donor_id,state,disease,frozen_umap_1,frozen_umap_2,
  AddModuleScore,AUCell,AddModuleScore_threshold,AUCell_threshold,
  AddModuleScore_group,AUCell_group,display_in_BC)],
  file.path(SD,'47_BC_method_high_low_cell_groups.csv.gz'))
counts_bc <- rbindlist(lapply(c('AddModuleScore','AUCell'),function(method) {
  cells[,.(n_all=.N,n_display=sum(display_in_BC)),
        by=c(paste0(method,'_group'))][,.(method,group=get(paste0(method,'_group')),n_all,n_display)]
}))
fwrite(counts_bc,file.path(SD,'48_BC_method_high_low_counts.csv'))
thresholds <- rbindlist(lapply(c('AddModuleScore','AUCell'),function(method) {
  cells[,.(threshold=median(get(method)),n_cells=.N,
           n_high=sum(get(paste0(method,'_group'))=='High'),
           n_low=sum(get(paste0(method,'_group'))=='Low')),
        by=.(donor_id,state)][,method:=method]
}))
fwrite(thresholds,file.path(SD,'49_BC_method_high_low_thresholds.csv'))
stopifnot(identical(unname(src_md5),unname(tools::md5sum(src))))
write_json(list(created_at=format(Sys.time()),dataset='Williams human gingival fibroblasts',
  signature='latest real VD DEG signature plus user-added GDF15; 46 measured genes',
  panel_B='AddModuleScore method-specific high/low',panel_C='AUCell method-specific high/low',
  rule='High > median; Low <= median; each method separately within donor_id and fibroblast state',
  not_consensus_groups=TRUE,not_global_median=TRUE,ties='ties remain Low, no arbitrary tie breaking',
  coordinate_source='existing frozen UMAP; no recalculation or rotation',axis_ratio=1,
  total_cells=nrow(cells),display_cells=nrow(maps),display_omitted_cells=4,
  omission_scope='display only, same isolated cells as current A',
  unchanged_original_input_md5=as.list(src_md5),colours=score_cols,
  existing_composite_and_statistics_preserved=TRUE,
  output_pdf=file.path(ROOT,'figures',paste0(base,'.pdf')),
  output_png=file.path(ROOT,'figures',paste0(base,'.png'))),
  file.path(SD,'50_BC_UMAP_manifest.json'),pretty=TRUE,auto_unbox=TRUE)
print(counts_bc)
cat(file.path(ROOT,'figures',paste0(base,'.pdf')),'\n')
