from pathlib import Path
import json
import math
import hashlib
import fitz
import pandas as pd
from scipy.stats import hypergeom
from PIL import Image
root = Path('C:/wb_links/williams_vd47_full_20261008')
sd = root / 'source_data'
name = 'Fig2_Williams_VitaminD_GDF15_ERK_MMP_dual_scoring_JHazMat_style_20261008_noACE_Aaxes1to1_rawp'
pdf = root / 'figures' / (name + '.pdf')
doc = fitz.open(pdf)
page = doc[0]
text = page.get_text()
assert len(doc) == 1
assert all((tag in text.splitlines() for tag in 'ABCDEFGHIJKLM'))
assert 'raw p' in text
assert 'FDR' not in text and 'adjusted p' not in text and ('q =' not in text)
assert all(('Arial' in f[3] or 'Symbol' in f[3] for f in page.get_fonts()))
png = Image.open(pdf.with_suffix('.png'))
assert abs(png.info['dpi'][0] - 600) < 1
de = pd.read_csv(sd / '08_paired_pseudobulk_high_vs_low_DE.csv.gz')
de = de.loc[~de.in_VD47_signature]
up = set(de.loc[(de['P.Value'] < 0.05) & (de.logFC > 0.25), 'gene'])
down = set(de.loc[(de['P.Value'] < 0.05) & (de.logFC < -0.25), 'gene'])
plot = pd.read_csv(sd / '38_rawp_DE_plot_data.csv')
assert set(plot.loc[plot.direction == 'Up', 'gene']) == up
assert set(plot.loc[plot.direction == 'Down', 'gene']) == down
enrich = {}
for db in ['KEGG_2021_Human', 'GO_Biological_Process_2025']:
    d = pd.read_csv(sd / ('40_rawp_' + db + '.csv'))
    independent = hypergeom.sf(d.Count - 1, len(de), d.term_background_genes, len(up))
    assert all((math.isclose(a, b, rel_tol=1e-09, abs_tol=1e-300) for a, b in zip(independent, d['P.value'])))
    enrich[db] = d.loc[(d['P.value'] < 0.05) & (d.Count > 0)].head(8)[['Term', 'Count', 'P.value']].to_dict('records')
axes = []
boxes = {'C': [], 'D': [], 'E': []}
for path in page.get_drawings():
    r = path['rect']
    if r.x1 < page.rect.width / 3 and r.y1 < page.rect.height / 4:
        if path['color'] == (0.0, 0.0, 0.0) and 0.7 < path['width'] < 1.1:
            for item in path['items']:
                if item[0] == 'l':
                    a, b = item[1:]
                    if abs(a.x - b.x) < 0.01 or abs(a.y - b.y) < 0.01:
                        length = abs(a - b)
                        if 10 < length < 50:
                            axes.append(float(length))
    for item in path['items']:
        if item[0] != 're' or path['fill'] is None:
            continue
        rect = item[1]
        if 10 < rect.width < 70 and rect.height > 1:
            if rect.y1 < page.rect.height / 4 and rect.x0 > 2 * page.rect.width / 3:
                boxes['C'].append(rect.width)
            elif page.rect.height / 4 < rect.y0 < page.rect.height / 2:
                if rect.x1 < page.rect.width / 3:
                    boxes['D'].append(rect.width)
                elif page.rect.width / 3 < rect.x0 and rect.x1 < 2 * page.rect.width / 3:
                    boxes['E'].append(rect.width)
assert len(axes) == 2, axes
assert abs(axes[0] - axes[1]) < 0.02, axes
assert len(boxes['C']) == 2 and len(boxes['D']) == 2 and (len(boxes['E']) == 5), boxes
assert max(sum(boxes.values(), [])) - min(sum(boxes.values(), [])) < 0.03, boxes
page.get_pixmap(matrix=fitz.Matrix(1.4, 1.4)).save(sd / '43_rawp_QA_full.png')
page.get_pixmap(matrix=fitz.Matrix(2, 2), clip=fitz.Rect(0, 0, page.rect.width / 3, page.rect.height / 4)).save(sd / '44_rawp_QA_A.png')
page.get_pixmap(matrix=fitz.Matrix(1.7, 1.7), clip=fitz.Rect(0, page.rect.height / 2, page.rect.width, page.rect.height)).save(sd / '45_rawp_QA_G_M.png')
qa = dict(up=len(up), down=len(down), universe=len(de), enrichment_top8=enrich, equal_axis_stroke_points=axes, box_widths_points=boxes, png_pixels=png.size, dpi=png.info['dpi'], raw_p_labels_verified=True, independent_enrichment_verified=True, pdf_sha256=hashlib.sha256(pdf.read_bytes()).hexdigest())
(sd / '46_rawp_QA.json').write_text(json.dumps(qa, indent=2), encoding='utf-8')
print(json.dumps(qa, indent=2))
