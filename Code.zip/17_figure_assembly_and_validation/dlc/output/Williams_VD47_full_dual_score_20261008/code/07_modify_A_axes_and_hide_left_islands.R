suppressPackageStartupMessages({library(data.table); library(jsonlite)})
ROOT <- 'C:/wb_links/williams_vd47_full_20261008'
source_files <- file.path(ROOT,'source_data',c('03_Williams_VD47_dual_scores.csv.gz',
  '08_paired_pseudobulk_high_vs_low_DE.csv.gz','10_disease_score_tests.csv',
  '11_high_low_endpoint_tests.csv','12_endpoint_correlations.csv'))
before_md5 <- tools::md5sum(source_files)
code <- readLines(file.path(ROOT,'code','06_modify_Fig2_delete_ACE.R'))
insertion <- grep('^plots <- setNames',code)
stopifnot(length(insertion) == 1)
panel_A_change <- c(
  "display_excluded <- cells[frozen_umap_1 < -8]",
  "stopifnot(nrow(display_excluded) == 4L)",
  "display_A <- cells[!cell_id %in% display_excluded$cell_id]",
  "stopifnot(nrow(display_A) == 14298L)",
  "pB$data <- display_A",
  "axis_x <- min(display_A$frozen_umap_1) - 1.2",
  "axis_y <- min(display_A$frozen_umap_2) - 0.6",
  "pB <- pB +",
  "  annotate('segment',x = axis_x,y = axis_y,xend = axis_x+2,yend = axis_y,",
  "    linewidth = 0.35,colour = 'black',arrow = grid::arrow(length = grid::unit(1.4,'mm'))) +",
  "  annotate('segment',x = axis_x,y = axis_y,xend = axis_x,yend = axis_y+2,",
  "    linewidth = 0.35,colour = 'black',arrow = grid::arrow(length = grid::unit(1.4,'mm'))) +",
  "  annotate('text',x = axis_x+1,y = axis_y-0.45,label = 'UMAP 1',",
  "    family = 'Arial',size = 2.5,hjust = 0.5,vjust = 1) +",
  "  annotate('text',x = axis_x-0.45,y = axis_y+1,label = 'UMAP 2',",
  "    family = 'Arial',size = 2.5,angle = 90,hjust = 0.5,vjust = 0.5) +",
  "  labs(caption = '4 isolated cells omitted from display only') +",
  "  theme(plot.caption = element_text(family = 'Arial',size = 5.8,hjust = 0,colour = '#555555'))"
)
code <- append(code,panel_A_change,after = insertion-1L)
code <- gsub('20261008_noACE_boxwidthH','20261008_noACE_Aaxes',code,fixed = TRUE)
code <- gsub('30_noACE_panel_label_mapping.csv','33_Aaxes_panel_label_mapping.csv',code,fixed = TRUE)
code <- gsub('31_noACE_layout_manifest.json','34_Aaxes_layout_manifest.json',code,fixed = TRUE)
writeLines(code,file.path(ROOT,'code','07_Aaxes_recipe_adapted.R'))
eval(parse(text = code),envir = .GlobalEnv)
stopifnot(identical(unname(before_md5),unname(tools::md5sum(source_files))))
fwrite(display_excluded[,.(cell_id,donor_id,disease,state,frozen_umap_1,frozen_umap_2)],
       file.path(ROOT,'source_data','35_A_display_omitted_cells.csv'))
manifest_path <- file.path(ROOT,'source_data','34_Aaxes_layout_manifest.json')
manifest <- read_json(manifest_path,simplifyVector = TRUE)
manifest$panel_A_axes <- 'L-shaped arrows labelled UMAP 1/UMAP 2; no numeric ticks'
manifest$panel_A_display_n <- nrow(display_A)
manifest$analysis_n_unchanged <- nrow(cells)
manifest$omitted_display_n <- nrow(display_excluded)
manifest$omission_rule <- 'User-marked far-left isolated islands, frozen_umap_1 < -8'
manifest$omission_scope <- 'Panel A display only; source expression, scores and tests unchanged'
manifest$statistics_input_md5_unchanged <- as.list(before_md5)
write_json(manifest,manifest_path,pretty = TRUE,auto_unbox = TRUE)
cat('Panel A: 14298 displayed, four cells omitted from display only; analysis unchanged.\n')
