suppressPackageStartupMessages({library(ggplot2); library(patchwork); library(data.table); library(jsonlite)})
ROOT <- 'C:/wb_links/williams_vd47_full_20261008'
target <- file.path(ROOT,'figures')
render_dir <- tempfile('fig2_noACE_',tmpdir = 'C:/wb_temp')
dir.create(render_dir)
render_dir <- normalizePath(render_dir,winslash = '/',mustWork = TRUE)
recipe <- readLines(file.path(ROOT,'code','03_original_recipe_adapted.R'))
stop_at <- grep('^fig <-',recipe)
stopifnot(length(stop_at)==1)
recipe <- recipe[seq_len(stop_at-1L)]
eval(parse(text = recipe),envir = .GlobalEnv)

bf <- ggplot_build(pF)
bh <- ggplot_build(pH)
reference_width <- median(bh$data[[1]]$xmax-bh$data[[1]]$xmin)
range_F <- diff(bf$layout$panel_params[[1]]$x.range)
range_H <- diff(bh$layout$panel_params[[1]]$x.range)
FG_BOX_WIDTH <- reference_width * range_F/range_H
if (nzchar(Sys.getenv('FG_BOX_WIDTH_OVERRIDE'))) FG_BOX_WIDTH <- as.numeric(Sys.getenv('FG_BOX_WIDTH_OVERRIDE'))
recipe <- gsub('geom_boxplot(width = 0.54','geom_boxplot(width = FG_BOX_WIDTH',recipe,fixed = TRUE)
eval(parse(text = recipe),envir = .GlobalEnv)
stopifnot(abs(median(ggplot_build(pF)$data[[1]]$xmax-ggplot_build(pF)$data[[1]]$xmin)-FG_BOX_WIDTH)<1e-10)

FG_BOX_WIDTH_G <- FG_BOX_WIDTH
F_multiplier <- if (nzchar(Sys.getenv('F_BOX_PHYSICAL_MULTIPLIER')))
  as.numeric(Sys.getenv('F_BOX_PHYSICAL_MULTIPLIER')) else 1.061057612096422
FG_BOX_WIDTH_F <- FG_BOX_WIDTH_G * F_multiplier
FG_BOX_WIDTH <- FG_BOX_WIDTH_F
pF <- box_disease('AddModuleScore','AddModuleScore by disease','VD46 AddModuleScore','AddModuleScore')
FG_BOX_WIDTH <- FG_BOX_WIDTH_G
pG <- box_disease('AUCell','AUCell by disease','VD46 AUCell','AUCell')

original <- c('B','D','F','G','H','I','J','K','L','M','N','O','P')
mapping <- data.table(original_label = original,new_label = LETTERS[seq_along(original)])
plots <- setNames(lapply(paste0('p',original),get),original)
for (i in seq_along(plots)) {
  plots[[i]] <- plots[[i]] + labs(tag = mapping$new_label[i]) +
    theme(plot.tag = element_text(family = 'Arial',size = 10.5,face = 'plain'),
          plot.tag.position = 'topleft')
}
row1 <- plots[['B']] | plots[['D']] | plots[['F']]
row2 <- plots[['G']] | plots[['H']] | plots[['I']]
row3 <- plots[['J']] | plots[['K']] | plots[['L']]
row4 <- plots[['M']] | plots[['N']] | plots[['O']] | plots[['P']]
fig <- (row1 / row2 / row3 / row4) +
  plot_layout(heights = c(1,1,1.08,1.08),guides = 'keep')
base <- 'Fig2_Williams_VitaminD_GDF15_ERK_MMP_dual_scoring_JHazMat_style_20261008_noACE_boxwidthH'
pdf_path <- file.path(render_dir,paste0(base,'.pdf'))
png_path <- file.path(render_dir,paste0(base,'.png'))
ggsave(pdf_path,fig,width = 15.3,height = 12.4,units = 'in',device = cairo_pdf)
if (Sys.getenv('SKIP_HIGHRES_PNG') != '1') {
  ggsave(png_path,fig,width = 15.3,height = 12.4,units = 'in',dpi = 600,bg = 'white')
  stopifnot(file.copy(png_path,target,overwrite = TRUE))
}
stopifnot(file.copy(pdf_path,target,overwrite = TRUE))
fwrite(mapping,file.path(ROOT,'source_data','30_noACE_panel_label_mapping.csv'))
write_json(list(created_at = format(Sys.time()),revision = 'layout only',
  removed_original_panels = c('A','C','E'),original_order = original,new_order = mapping$new_label,
  row_panel_counts = c(3,3,3,4),unchanged_statistics = TRUE,
  reference_box_panel_original = 'H',reference_box_panel_new = 'E',
  changed_box_panels_original = c('F','G'),changed_box_panels_new = c('C','D'),
  reference_box_width_data_units = reference_width,F_width_data_units = FG_BOX_WIDTH_F,
  G_width_data_units = FG_BOX_WIDTH_G,F_physical_calibration_multiplier = F_multiplier,
  reference_x_range = range_H,FG_x_range = range_F,
  retained_font = 'Arial',retained_colours = TRUE,old_full_PDF_retained = TRUE,
  output_pdf = file.path(target,basename(pdf_path)),output_png = file.path(target,basename(png_path))),
  file.path(ROOT,'source_data','31_noACE_layout_manifest.json'),pretty = TRUE,auto_unbox = TRUE)
cat('F/G width=',FG_BOX_WIDTH,'; H width=',reference_width,'\n')
cat(file.path(target,basename(pdf_path)),'\n')
