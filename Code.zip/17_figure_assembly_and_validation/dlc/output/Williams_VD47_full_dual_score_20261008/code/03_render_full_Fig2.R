OUT <- 'C:/wb_links/williams_vd47_full_20261008'
target <- file.path(OUT,'figures')
render_dir <- tempfile('williams_full_fig2_',tmpdir = 'C:/wb_temp')
dir.create(render_dir)
render_dir <- normalizePath(render_dir, winslash = '/', mustWork = TRUE)
code <- readLines('C:/wb_links/no2uc_original_code/03_make_figure2.R')
code <- gsub('C:/wb_links/jhazmat2026_no2uc_20260925',OUT,code,fixed = TRUE)
code <- gsub('VD17','VD47',code,fixed = TRUE)
code <- gsub('FD <- file.path(OUT, "figures")',paste0('FD <- "',render_dir,'"'),code,fixed = TRUE)

visible <- c('VD47 AddModuleScore','VD47 AUCell','VD47 consensus score','VD47-high','VD47-low',
             'VD47 high vs low','VD47 score vs','VD47 / GDF15')
for (s in visible) code <- gsub(s,sub('VD47','VD46',s,fixed = TRUE),code,fixed = TRUE)
code <- gsub('VD46 / GDF15 / ERK1/2 / MMP genes','VD markers / GDF15 / ERK1/2 / MMP genes',code,fixed = TRUE)

loc <- grep('if \\(p < 0.001\\) return',code)
code <- append(code,'  if (p < 0.01) return(paste0("p = ", formatC(p, digits = 3, format = "g")))',after = loc)

go_loc <- grep('^go <- fread',code)
code <- append(code,'go <- go[Adjusted.P.value < 0.05 & Count > 0]',after = go_loc)
k_loc <- grep('^kegg <- fread',code)
code <- append(code,'kegg <- kegg[Adjusted.P.value < 0.05 & Count > 0]',after = k_loc)

code <- gsub('GDF15 detection: VD46 high vs low','GDF15: VD45 high vs low (held-out)',code,fixed = TRUE)
ns <- grep('^pN <-',code); ne <- grep('^# O-P:',code)-1L
code[ns:ne] <- gsub('consensus_score','GDF15_heldout_consensus_score',code[ns:ne],fixed = TRUE)
code[ns:ne] <- gsub('VD46 score vs GDF15','VD45 score vs GDF15 (held-out)',code[ns:ne],fixed = TRUE)
code[ns:ne] <- gsub('VD46 consensus score','VD45 held-out score',code[ns:ne],fixed = TRUE)

code <- gsub('ERK1/2 and MMP/ECM programs','ERK / MMP programs (nonoverlapping)',code,fixed = TRUE)

js <- grep('^pJ <-',code); je <- grep('^enrich_plot <-',code)-1L
code[js:je] <- gsub('c(0.80, 0.78)','c(0.15, 0.80)',code[js:je],fixed = TRUE)

code <- gsub('fmt_p(paired_tests[endpoint == "MAPK_ERK", p_value][1])',
  'paste0(fmt_p(paired_tests[endpoint == "MAPK_ERK", p_value][1]), "; q < 0.001")',code,fixed = TRUE)
code <- gsub('fmt_p(paired_tests[endpoint == "ECM_degradation", p_value][1])',
  'paste0(fmt_p(paired_tests[endpoint == "ECM_degradation", p_value][1]), "; q = ", sprintf("%.3f", paired_tests[endpoint == "ECM_degradation", FDR][1]))',code,fixed = TRUE)
code <- gsub('Fig2_Williams_VitaminD_GDF15_ERK_MMP_dual_scoring_JHazMat_style',
             'Fig2_Williams_VitaminD_GDF15_ERK_MMP_dual_scoring_JHazMat_style_20261008',code,fixed = TRUE)
save_at <- grep('^ggsave\\(pdf_path',code)
code <- append(code,'ggsave(png_path, fig, width = 15.3, height = 12.4, units = "in", dpi = 600, bg = "white")',after = save_at)
writeLines(code,file.path(OUT,'code','03_original_recipe_adapted.R'))
eval(parse(text = code),envir = .GlobalEnv)
stopifnot(file.info(pdf_path)$size > 1000,file.info(png_path)$size > 1000)
stopifnot(file.copy(c(pdf_path,png_path),target,overwrite = TRUE))
fig_manifest$outputs <- file.path(target, basename(fig_manifest$outputs))
fig_manifest$actual_single_cell_signature_n <- 46L
fig_manifest$GDF15_panels_heldout_signature_n <- 45L
fig_manifest$multiple_testing <- 'O displays raw p and BH q; other raw p values are exploratory'
write_json(fig_manifest, file.path(OUT,'source_data','16_figure_manifest.json'),auto_unbox = TRUE,pretty = TRUE)
cat('Saved full Fig2\n')
