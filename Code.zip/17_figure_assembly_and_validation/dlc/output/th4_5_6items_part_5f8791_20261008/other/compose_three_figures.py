from pathlib import Path
import json
import hashlib
import io
import sys
import fitz
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
OUT = ROOT / 'output' / '\u7b2c4_5_6\u9879_\u4e09\u5f20\u5b8c\u6574\u62fc\u56fe_20261008'
FIG = OUT / '\u56fe'
AUX = OUT / '\u5176\u4ed6'
QA = AUX / 'QA'
for p in (FIG, AUX, QA):
    p.mkdir(parents=True, exist_ok=True)
PDF = FIG / '\u7b2c4_5_6\u9879_\u5404\u4e00\u5f20\u5b8c\u6574\u62fc\u56fe_20261008.pdf'
if PDF.exists():
    if '--rebuild-owned' not in sys.argv:
        raise FileExistsError('Preserve existing result; use a new output filename.')
    with fitz.open(PDF) as own:
        assert own.metadata.get('title') == '\u7b2c4\u30015\u30016\u9879 - \u5404\u4e00\u5f20\u6700\u65b0\u7248\u5b8c\u6574\u62fc\u56fe - 2026-10-08'
        assert len(own) == 3
ARIAL = 'C:\\Windows\\Fonts\\arial.ttf'
BOLD = 'C:\\Windows\\Fonts\\arialbd.ttf'
pdfmetrics.registerFont(TTFont('ArialTask', ARIAL))
pdfmetrics.registerFont(TTFont('ArialTaskBold', BOLD))
W = 510.2362
M = 6
GAP = 10
records = []
sources = {}
doc = fitz.open()

def source(path, strip_stars=False):
    path = Path(path)
    key = (str(path), strip_stars)
    if key not in sources:
        sha = hashlib.sha256(path.read_bytes()).hexdigest()
        d = fitz.open(stream=path.read_bytes(), filetype='pdf')
        removals = []
        for pg in d:
            if strip_stars:
                pg.set_mediabox(fitz.Rect(0, 0, pg.rect.width + 20, pg.rect.height))
            for b in pg.get_text('dict')['blocks']:
                for line in b.get('lines', []):
                    for span in line['spans']:
                        text = span['text'].strip()
                        is_label = (len(text) == 1 and text in 'ABCDEFGHIJKLMN' or text == 'B2') and span['size'] >= 9
                        is_star = strip_stars and bool(text) and (set(text) == {'*'})
                        if is_label or is_star:
                            box = fitz.Rect(span['bbox']) & pg.rect
                            pg.add_redact_annot(box, fill=None if is_star else (1, 1, 1))
                            removals.append(dict(page=pg.number + 1, text=text, bbox=list(box)))
            if pg.first_annot:
                pg.apply_redactions(images=0, graphics=0)
        sources[key] = dict(doc=d, path=path, sha256=sha, removed=removals, right_margin_expansion_pt=20 if strip_stars else 0)
    return sources[key]

def exact_rect(x, y, width, src_rect):
    return fitz.Rect(x, y, x + width, y + width * src_rect.height / src_rect.width)

def show(pg, src, num, clip, dest, label=None, label_xy=None, kind='panel'):
    sr = fitz.Rect(clip)
    dr = fitz.Rect(dest)
    pg.show_pdf_page(dr, src['doc'], num, clip=sr, keep_proportion=True)
    records.append(dict(output_page=pg.number + 1, source=str(src['path']), source_page=num + 1, source_clip=list(sr), destination=list(dr), label=label, kind=kind))
    if label:
        xy = label_xy or (dr.x0 + 1, dr.y0 + 13)
        annotations[pg.number].append(dict(kind='label', x=xy[0], y=xy[1], text=label))
annotations = {}

def page(height):
    pg = doc.new_page(width=W, height=height)
    annotations[pg.number] = []
    return pg

def band(pg, y, title):
    annotations[pg.number].append(dict(kind='band', y=y, title=title))

def foot(pg, y, text):
    annotations[pg.number].append(dict(kind='foot', y=y, text=text))
ref = ROOT / 'output' / '\u539f\u6587\u683c\u5f0f\u8fc1\u79fb_GDF15_ERK' / 'Williams\u7edf\u4e00\u91cd\u5206\u6790_20260920'
raw = ROOT / 'P3_WGCNA_Williams_20261008_RAWP' / '\u56fe'
core = ROOT / 'output' / '\u6838\u5fc3\u7ed3\u679cB_MAPK_ECM'
diag = source(ROOT / 'P3_WGCNA_Williams_20261008' / '\u56fe' / 'WGCNA_diagnostics.pdf')
hd = source(ref / 'Reference_Fig5_style_hdWGCNA_GDF15_ERK_module_20260915_Williams_20260920.pdf')
bulk = source(ROOT / 'output' / 'BioorganicChemistry2026_\u5e72\u5b9e\u9a8c\u8fc1\u79fb_20260924' / 'figures' / 'Fig1_Gingiva_bulk_ComBat_DEG_WGCNA_BioorgChem_style.pdf')
pg = page(986)
band(pg, 5, '4 | WGCNA / hdWGCNA: co-expression modules and disease association')
band(pg, 25, 'Williams pseudobulk WGCNA | latest: 2026-10-08')
left = fitz.Rect(0, 0, 255, 302)
right = diag['doc'][1].rect
show(pg, diag, 0, left, exact_rect(M, 47, 185, left), 'A')
show(pg, diag, 1, right, exact_rect(210, 69, W - 216, right), 'B')
hd_y = 295
band(pg, hd_y - 20, 'Williams hdWGCNA | latest: 2026-09-20')
hd_dest = exact_rect(M, hd_y, W - 2 * M, hd['doc'][0].rect)
show(pg, hd, 0, hd['doc'][0].rect, hd_dest, kind='complete_hdWGCNA_figure_once')
scale = hd_dest.width / hd['doc'][0].rect.width
hd_labels = [('C', 0.5, 0), ('D', 183.3, 0), ('E', 0.6, 150.2), ('F', 211.5, 150.2), ('G', 326.9, 150.2), ('H', 0.6, 305.9), ('I', 207.2, 305.9)]
for lab, x, y in hd_labels:
    annotations[pg.number].append(dict(kind='label', x=M + x * scale, y=hd_y + y * scale + 13, text=lab))
bulk_y = hd_dest.y1 + 26
band(pg, bulk_y - 20, 'Gingival bulk WGCNA | GSE223924 + GSE173078 | latest: 2026-09-24')
clip = fitz.Rect(0, 710, 777, 957)
bulk_dest = exact_rect(M, bulk_y, W - 2 * M, clip)
show(pg, bulk, 0, clip, bulk_dest, kind='bulk_WGCNA_only_G_H')
s = bulk_dest.width / clip.width
for lab, x, y in [('J', 8.5, 715.2), ('K', 350.4, 720.8)]:
    annotations[pg.number].append(dict(kind='label', x=M + x * s, y=bulk_y + (y - 710) * s + 13, text=lab))
foot(pg, 974, 'Pseudobulk: 18 sample-ID groups; hdWGCNA: 21 sample labels. Network colours independent; donor identity unverified.')
pg = page(609)
band(pg, 5, '5 | Disease-vitamin D reverse signature | Williams + Zhang | raw P | 2026-10-08')
defs = [('A', 'P3_A_WGCNA_RAWP.pdf', M, 30, 268), ('B', 'P3_B_WGCNA_RAWP.pdf', 288, 30, W - 294), ('C', 'P3_B2_WGCNA_RAWP.pdf', 288, 189, W - 294), ('D', 'P3_C_WGCNA_RAWP.pdf', M, 318, 245), ('E', 'P3_D_WGCNA_RAWP.pdf', 269, 318, W - 275)]
for lab, filename, x, y, width in defs:
    src = source(raw / filename)
    clip = src['doc'][0].rect
    show(pg, src, 0, clip, exact_rect(x, y, width, clip), lab)
foot(pg, 582, 'A: gene effects; B-C: vitamin D signatures; D: expression-derived WGCNA modules; E: GDF15 virtual-KO overlap.')
foot(pg, 594, 'All displayed P values are raw. WGCNA: 18 grouped Williams sample labels; vitamin D: GSE212728 D3 vs ethanol.')
state = source(ref / 'Reference_Fig3_style_gingival_fibroblast_GDF15_ERK_state_20260915_Williams_20260920.pdf')
for box in state['doc'][0].search_for('Vascular vs other fibroblast states'):
    state['doc'][0].add_redact_annot(box, fill=None)
state['doc'][0].add_redact_annot(fitz.Rect(140, 374, 267, 385), fill=None)
state['doc'][0].apply_redactions(images=0, graphics=0)
vd = source(ROOT / 'output' / 'Williams_VD47_full_dual_score_20261008' / 'figures' / 'Fig2_Williams_VitaminD_GDF15_ERK_MMP_dual_scoring_JHazMat_style_20261008_noACE_Aaxes1to1_rawp.pdf')
pg = page(738)
band(pg, 5, '6 | MAPK/ERK: Williams gingival pathway footprints and single-cell programme scores')
band(pg, 25, 'Williams gingiva only | pathway/state analyses: 2026-09-20')
pro_clip = fitz.Rect(0, 371, 147, 583)
score_clip = fitz.Rect(149, 177, 267, 368)
show(pg, state, 0, pro_clip, exact_rect(M, 49, 230, pro_clip), 'A')
show(pg, state, 0, score_clip, exact_rect(264, 49, 220, score_clip), 'B')
single_y = 450
band(pg, single_y - 20, 'Williams single-cell | vitamin D gene-score high vs low | raw P | latest: 2026-10-08')
clips = [('C', fitz.Rect(531, 635, 794, 873), M, 235), ('D', fitz.Rect(794, 635, 1101, 873), 251, W - 257)]
for lab, clip, x, width in clips:
    show(pg, vd, 0, clip, exact_rect(x, single_y, width, clip), lab)
foot(pg, 710, 'A: PROGENy by fibroblast state; B: MAPK/ERK programme by state; C-D: vitamin D gene-score / ERK-MMP programmes.')
foot(pg, 722, 'Ineligible legacy GSEA/PROGENy input excluded; gingiva-only disease-vs-vitamin-D GSEA remains to be rebuilt.')
foot(pg, 734, 'Vitamin D gene-score high/low groups are expression-score groups, not vitamin D treatment groups. Displayed P: raw.')
for n, pg in enumerate(doc):
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(W, pg.rect.height))
    for x in annotations[n]:
        if x['kind'] == 'band':
            c.setFillColorRGB(228 / 255, 230 / 255, 235 / 255)
            c.rect(M, pg.rect.height - x['y'] - 16, W - 2 * M, 16, fill=1, stroke=0)
            c.setFillColorRGB(0.1, 0.12, 0.15)
            c.setFont('ArialTaskBold', 7.5)
            c.drawString(M + 5, pg.rect.height - x['y'] - 11.5, x['title'])
        elif x['kind'] == 'label':
            c.setFillColorRGB(0, 0, 0)
            c.setFont('ArialTaskBold', 12)
            c.drawString(x['x'], pg.rect.height - x['y'], x['text'])
        else:
            c.setFillColorRGB(0.25, 0.25, 0.25)
            c.setFont('ArialTask', 5.4)
            c.drawString(M, pg.rect.height - x['y'], x['text'])
    c.showPage()
    c.save()
    overlay = fitz.open(stream=buf.getvalue(), filetype='pdf')
    pg.show_pdf_page(pg.rect, overlay, 0)
    overlay.close()
doc.set_metadata(dict(title='\u7b2c4\u30015\u30016\u9879 - \u5404\u4e00\u5f20\u6700\u65b0\u7248\u5b8c\u6574\u62fc\u56fe - 2026-10-08', subject='Three vector figure plates; deduplicated; no demonstration appendix', author='Scientific figure composition'))
doc.set_toc([[1, '4. WGCNA / hdWGCNA', 1], [1, '5. Disease-vitamin D reverse signature', 2], [1, '6. MAPK / ERK', 3]])
doc.save(PDF, garbage=4, deflate=True)
doc.close()
names = ['\u7b2c4\u9879_WGCNA_hdWGCNA_\u5b8c\u6574\u62fc\u56fe_20261008', '\u7b2c5\u9879_\u75be\u75c5\u7ef4\u751f\u7d20D\u53cd\u5411\u7b7e\u540d_\u5b8c\u6574\u62fc\u56fe_RAWP_20261008', '\u7b2c6\u9879_MAPK_ERK_\u5b8c\u6574\u62fc\u56fe_20261008']
with fitz.open(PDF) as final:
    assert len(final) == 3
    page_checks = []
    for n, pg in enumerate(final):
        pg.get_pixmap(dpi=160, alpha=False).save(FIG / (names[n] + '_\u9884\u89c8.png'))
        pg.get_pixmap(dpi=600, alpha=False).save(FIG / (names[n] + '.png'))
        page_checks.append(dict(page=n + 1, size=list(pg.rect), fonts=pg.get_fonts(), labels=[a['text'] for a in annotations[n] if a['kind'] == 'label']))
source_audit = []
for src in sources.values():
    current = hashlib.sha256(src['path'].read_bytes()).hexdigest()
    assert current == src['sha256']
    source_audit.append(dict(path=str(src['path']), sha256=current, unchanged=True, removed_in_memory=src['removed'], right_margin_expansion_pt=src['right_margin_expansion_pt']))
manifest = dict(output=str(PDF), pages=3, source_audit=source_audit, panel_mapping=records, page_checks=page_checks, only_latest_per_analysis=True, no_repeated_standalone_versions=True, old_files_preserved=True, methodology='Lossless source-PDF vector clipping and placement. No rerun, no raster image editing, no statistic relabelling.', legacy_tissue_issue='Legacy mixed-periodontium GSEA and contrast-level PROGENy excluded. Figure 6 uses Williams gingiva only.', gsea_status='Gingiva-only disease-vs-vitamin-D GSEA is not available among eligible latest figures and was not recomputed in this composition request.', visual_QA='pending')
(AUX / '\u62fc\u56fe\u6765\u6e90\u4e0e\u6838\u9a8c.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(dict(pdf=str(PDF), pages=3, png_600dpi=3, png_preview=3), ensure_ascii=False))
