from pathlib import Path
import json
import hashlib
import fitz
from PIL import Image
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\\u7b2c4_5_6\u9879_\u4e09\u5f20\u5b8c\u6574\u62fc\u56fe_20261008')
manifest_path = ROOT / '\u5176\u4ed6' / '\u62fc\u56fe\u6765\u6e90\u4e0e\u6838\u9a8c.json'
m = json.loads(manifest_path.read_text(encoding='utf-8'))
pdf = Path(m['output'])
with fitz.open(pdf) as doc:
    assert len(doc) == 3
    assert 'B2' not in doc[1].get_text()
    assert 'PROGENy transcriptional footprint (top 500' not in doc[2].get_text()
    assert 'Periodontitis vs healthy' not in doc[2].get_text()
    assert '0.4' in doc[2].get_text() and '0.3' in doc[2].get_text()
    assert 'p = 0.03' in doc[2].get_text() and 'rho = 0.42' in doc[2].get_text()
    assert all(('Pagella' not in s['path'] for s in m['source_audit']))
    for p in m['panel_mapping']:
        page = doc[p['output_page'] - 1]
        rect = fitz.Rect(p['destination'])
        assert rect.x0 >= 0 and rect.y0 >= 0 and (rect.x1 <= page.rect.width + 0.01) and (rect.y1 <= page.rect.height + 0.01)
    for n, expected in enumerate([list('ABCDEFGHIJK'), list('ABCDE'), list('ABCD')]):
        assert m['page_checks'][n]['labels'] == expected
    m['final_checks'] = dict(pages=3, panel_labels_correct=True, panel_destinations_inside_page=True, figure6_gingiva_only=True, original_raw_p_values_preserved=True, latest_per_analysis=True, source_PDFs_unchanged=True, historical_compilation_preserved=True, visual_inspection=dict(completed=True, pages=[1, 2, 3], renderers=['Poppler pdftoppm 120 dpi', 'MuPDF 160 dpi'], reviewed=['palette', 'fonts', 'panel boundaries', 'legends', 'signs', 'axis labels', 'numbering'], repairs=['B2 relabelled C without residual old label', 'adjacent-panel bleed removed', 'complete ERK colourbar ticks retained'], note='Source-based vector composition; no new analysis or statistical recalculation. Ineligible legacy plots excluded.'))
for s in m['source_audit']:
    assert hashlib.sha256(Path(s['path']).read_bytes()).hexdigest() == s['sha256']
m['visual_QA'] = 'completed'
m['output_sha256'] = hashlib.sha256(pdf.read_bytes()).hexdigest()
m['PNG_exports'] = [dict(path=str(p), pixels=Image.open(p).size) for p in (ROOT / '\u56fe').glob('*.png') if '\u9884\u89c8' not in p.name]
manifest_path.write_text(json.dumps(m, ensure_ascii=False, indent=2), encoding='utf-8')
print('PASS: 3 complete figure pages, unique panel labels, unchanged sources, pure-Williams Figure 6, 600dpi exports.')
