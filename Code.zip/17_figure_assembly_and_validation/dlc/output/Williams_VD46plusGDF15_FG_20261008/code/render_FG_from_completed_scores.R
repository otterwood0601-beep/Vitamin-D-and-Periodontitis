options(stringsAsFactors = FALSE, scipen = 999)
suppressPackageStartupMessages({library(data.table); library(ggplot2); library(patchwork)})
set.seed(20260925)
OUT <- 'C:/wb_links/williams_vd47_fg_20261008'
SD <- file.path(OUT, 'source_data')
target_FD <- file.path(OUT, 'figures')

FD <- tempfile('williams_fg_render_', tmpdir = 'C:/wb_temp')
dir.create(FD)
donor <- fread(file.path(SD, '04_donor_score_summary.csv'))
tests <- fread(file.path(SD, '10_disease_score_tests.csv'))
present <- fread(file.path(SD, '02_actual_scoring_genes.csv'))$gene
lines <- readLines(file.path(OUT, 'code', 'recalculate_FG.R'))
start <- grep('^donor\\[, disease := factor', lines)
end <- grep('^manifest <- list', lines) - 1L
plot_code <- lines[start:end]
plot_code <- gsub("dpi = 600, bg = 'white'", "dpi = 600, bg = 'white', device = 'png', type = 'cairo'", plot_code, fixed = TRUE)
eval(parse(text = plot_code))
stopifnot(file.info(pdf_path)$size > 1000, file.info(png_path)$size > 1000)
stopifnot(file.copy(c(pdf_path, png_path), target_FD, overwrite = TRUE))
cat('Rendered actual ', length(present), '-gene scores without recalculation\n', sep = '')
