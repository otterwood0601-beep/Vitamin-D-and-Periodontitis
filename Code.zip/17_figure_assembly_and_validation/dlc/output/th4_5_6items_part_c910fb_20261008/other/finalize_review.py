from pathlib import Path
import json
import hashlib
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u56fe\u6c47\u603b_20261008')
pdf = ROOT / '\u56fe' / '\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u56fe\u6c47\u603b_20261008.pdf'
for p in [ROOT / '\u5176\u4ed6' / '\u6c47\u603b\u6765\u6e90\u6e05\u5355.json', ROOT / '\u5176\u4ed6' / 'QA' / 'page_integrity_check.json']:
    data = json.loads(p.read_text(encoding='utf-8'))
    data['visual_review'] = dict(completed=True, renderer='Poppler pdftoppm 120 dpi', inspected_pages=list(range(1, 42)), sheets=11, corrected_generated_index='B2 labelled as GSEA curves, matching actual source panel.', generated_pages_no_overflow=True, new_merge_defects_detected=False, inherited_source_defects='Some original hdWGCNA and legacy footprint pages have title edge clipping or crowded labels. Preserved as requested original pages and disclosed in overview; this is not a replot.', historical_statistics='Some preserved historical figures use FDR. RAW P latest figures explicitly labelled. No label substitution or statistical recalculation.', historical_tissue_issue='Legacy core GSEA and PROGENy disease input includes Pagella periodontal tissue not verified pure gingiva; explicitly labelled historical reference.', warning='Poppler reported missing display font Symbol; rendered pages inspected and source drawing command integrity checked.')
    data['output_sha256'] = hashlib.sha256(pdf.read_bytes()).hexdigest()
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
print('Final visual review and source-integrity record complete; 41 pages.')
