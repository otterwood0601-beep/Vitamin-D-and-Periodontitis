from pathlib import Path
from PIL import Image, ImageOps, ImageDraw, ImageFont
import json
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u56fe\u6c47\u603b_20261008')
QA = ROOT / '\u5176\u4ed6' / 'QA'
pages = sorted(QA.glob('page-*.png'), key=lambda p: int(p.stem.split('-')[-1]))
assert len(pages) == 41, len(pages)
font = ImageFont.truetype('C:\\Windows\\Fonts\\arial.ttf', 25)
for s in range(0, len(pages), 4):
    sheet = Image.new('RGB', (2400, 1800), '#e5e7eb')
    draw = ImageDraw.Draw(sheet)
    for offset, path in enumerate(pages[s:s + 4]):
        pic = Image.open(path).convert('RGB')
        pic.thumbnail((1160, 820), Image.Resampling.LANCZOS)
        col, row = (offset % 2, offset // 2)
        x = col * 1200 + 20 + (1160 - pic.width) // 2
        y = row * 900 + 55 + (820 - pic.height) // 2
        sheet.paste(pic, (x, y))
        draw.text((col * 1200 + 25, row * 900 + 15), f'Page {s + offset + 1}', fill='#111827', font=font)
    sheet.save(QA / f'review-{s // 4 + 1:02d}.jpg', quality=94)
print('11 complete-page visual review sheets ready')
