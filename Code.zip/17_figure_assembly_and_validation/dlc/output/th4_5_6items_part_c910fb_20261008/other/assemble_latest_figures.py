from pathlib import Path
from datetime import datetime
import hashlib
import json
import io
import sys
import fitz
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
OUT = ROOT / 'output' / '\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u56fe\u6c47\u603b_20261008'
FIG = OUT / '\u56fe'
AUX = OUT / '\u5176\u4ed6'
QA = AUX / 'QA'
for p in (FIG, AUX, QA):
    p.mkdir(parents=True, exist_ok=True)
PDF = FIG / '\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u56fe\u6c47\u603b_20261008.pdf'
if PDF.exists() and '--verify-only' not in sys.argv:
    if '--rebuild-owned' not in sys.argv:
        raise FileExistsError(f'Preserve existing output: {PDF}')
    with fitz.open(PDF) as prior:
        assert prior.metadata.get('title') == '\u7b2c4\u30015\u30016\u9879\u6700\u65b0\u7248\u56fe\u6c47\u603b - 2026-10-08'
        assert len(prior) == 41, "Only replace this request's own generated compilation"
pdfmetrics.registerFont(TTFont('Chinese', 'C:\\Windows\\Fonts\\simhei.ttf'))
pdfmetrics.registerFont(TTFont('Arial', 'C:\\Windows\\Fonts\\arial.ttf'))
hd = ROOT / 'P2_hdWGCNA_Williams_20260920' / 'outputs' / 'figures'
ref = ROOT / 'output' / '\u539f\u6587\u683c\u5f0f\u8fc1\u79fb_GDF15_ERK' / 'Williams\u7edf\u4e00\u91cd\u5206\u6790_20260920'
raw = ROOT / 'P3_WGCNA_Williams_20261008_RAWP' / '\u56fe'
core = ROOT / 'output' / '\u6838\u5fc3\u7ed3\u679cB_MAPK_ECM'
vd = ROOT / 'output' / 'Williams_VD47_full_dual_score_20261008' / 'figures'

def item(label, path, note=''):
    return dict(label=label, path=str(path), note=note)
groups = [dict(title='4. WGCNA / hdWGCNA', subtitle='\u5171\u8868\u8fbe\u6a21\u5757\u3001\u67a2\u7ebd\u57fa\u56e0\u53ca\u75be\u75c5\u5173\u8054', notes=['Williams pseudobulk WGCNA\uff1a2026-10-08\uff0c13\u4e2a\u975e\u7070\u6a21\u5757\u3002', 'Williams hdWGCNA\uff1a2026-09-20\uff0c6\u4e2a\u975e\u7070\u6a21\u5757\u3002\u4e24\u5957\u6a21\u5757\u989c\u8272\u5404\u81ea\u5b9a\u4e49\u3002', 'bulk WGCNA\uff1aGSE223924 + GSE173078\uff0c44\u4efd\u7259\u9f88\u7ec4\u7ec7\u6837\u672c\u3002', '\u5386\u53f2\u56fe\u539f\u9875\u4fdd\u7559\uff1a\u90e8\u5206\u7edf\u8ba1\u4f7f\u7528FDR\uff1b\u6a21\u5757/\u4f9b\u8005\u6807\u7b7e\u6309\u539f\u5206\u6790\u53e3\u5f84\u3002'], items=[item('Williams WGCNA\uff1a\u8f6f\u9608\u503c\u3001\u57fa\u56e0\u6811\u4e0e\u6a21\u5757\u8bca\u65ad\uff082\u9875\uff09', ROOT / 'P3_WGCNA_Williams_20261008' / '\u56fe' / 'WGCNA_diagnostics.pdf'), item('\u7259\u9f88bulk\uff1a\u6279\u6b21\u5904\u7406\u3001\u5dee\u5f02\u8868\u8fbe\u53caWGCNA\u7efc\u5408\u56fe', ROOT / 'output' / 'BioorganicChemistry2026_\u5e72\u5b9e\u9a8c\u8fc1\u79fb_20260924' / 'figures' / 'Fig1_Gingiva_bulk_ComBat_DEG_WGCNA_BioorgChem_style.pdf'), item('Williams hdWGCNA\uff1a\u539f\u6587\u683c\u5f0f\u7efc\u5408\u56fe A-G', ref / 'Reference_Fig5_style_hdWGCNA_GDF15_ERK_module_20260915_Williams_20260920.pdf')] + [item(label, hd / name) for label, name in [('hdWGCNA A\uff1a\u8f6f\u9608\u503c\u9009\u62e9', '\u56feP2A_\u8f6f\u9608\u503c\u9009\u62e9.pdf'), ('hdWGCNA B\uff1a\u6a21\u5757\u7279\u5f81UMAP', '\u56feP2B_\u6a21\u5757\u7279\u5f81UMAP.pdf'), ('hdWGCNA C\uff1a\u6a21\u5757\u57fa\u56e0\u6811', '\u56feP2C_\u6a21\u5757\u6811.pdf'), ('hdWGCNA D\uff1a\u67a2\u7ebd\u57fa\u56e0\u70b9\u56fe', '\u56feP2D_\u6a21\u5757hub\u57fa\u56e0\u70b9\u56fe.pdf'), ('hdWGCNA E\uff1a\u67a2\u7ebd\u57fa\u56e0\u7f51\u7edc', '\u56feP2E_\u6a21\u5757hub\u7f51\u7edc.pdf'), ('hdWGCNA F\uff1a\u6a21\u5757GO\u5bcc\u96c6', '\u56feP2F_\u6a21\u5757GO\u5bcc\u96c6.pdf'), ('hdWGCNA G\uff1a\u6a21\u5757-\u4e9a\u7fa4/\u75be\u75c5/GDF15\u5173\u8054', '\u56feP2G_\u6a21\u5757\u4e9a\u7fa4\u75be\u75c5\u5173\u8054\u6c14\u6ce1\u56fe.pdf'), ('hdWGCNA H\uff1a\u8de8\u6837\u672c\u6807\u7b7e\u7a33\u5b9a\u6027', '\u56feP2H_\u6a21\u5757\u8de8\u4f9b\u8005\u7a33\u5b9a\u6027.pdf'), ('hdWGCNA I\uff1a\u7259\u9f88bulk\u6a21\u5757\u590d\u73b0\u68ee\u6797\u56fe', '\u56feP2I_\u6a21\u5757\u5916\u90e8\u590d\u73b0\u68ee\u6797\u56fe.pdf')]] + [item(f'hdWGCNA {color}\uff1a\u8be6\u7ec6\u6a21\u5757\u7f51\u7edc', hd / '\u6a21\u5757\u7f51\u7edc\u56fe' / f'{color}.pdf') for color in ['blue', 'brown', 'green', 'red', 'turquoise', 'yellow']]), dict(title='5. \u75be\u75c5-\u7ef4\u751f\u7d20D\u53cd\u5411\u7b7e\u540d', subtitle='2026-10-08 RAW P\u65b0\u7248\uff1b\u91c7\u7528Williams\u8ba1\u7b97\u7684WGCNA\u6a21\u5757', notes=['\u75be\u75c5\u8f93\u5165\uff1aWilliams\u7259\u9f88\u6210\u7ea4\u7ef4\u7ec6\u80de\uff1b\u7ef4\u751f\u7d20D\u8f93\u5165\uff1aZhang / GSE212728\u3002', '18\u4e2a\u4fdd\u5b88\u5408\u5e76\u6837\u672c\u6807\u7b7e\u7ec4\uff1b\u751f\u7269\u5b66\u4f9b\u8005\u72ec\u7acb\u6027\u5f85\u6838\u5b9e\u3002', 'WGCNA\u6a21\u5757\u4e0e\u75be\u75c5\u5dee\u5f02\u6765\u81ea\u540c\u4e00\u53d1\u73b0\u961f\u5217\uff1b\u5c5e\u4e8e\u63a2\u7d22\u6027\u6bd4\u8f83\u3002', 'D\u4f7f\u7528\u5df2\u6709Williams GDF15\u865a\u62df\u6572\u9664\u7ed3\u679c\u4e0e\u6a21\u5757\u4ea4\u53c9\u6bd4\u8f83\u3002'], items=[item(label, raw / name) for label, name in [('A\uff1a\u75be\u75c5\u4e0e\u7ef4\u751f\u7d20D\u57fa\u56e0\u53d8\u5316\u56db\u8c61\u9650', 'P3_A_WGCNA_RAWP.pdf'), ('B\uff1a\u7ef4\u751f\u7d20D\u4e0a/\u4e0b\u8c03\u7b7e\u540dGSEA', 'P3_B_WGCNA_RAWP.pdf'), ('B2\uff1a\u7ef4\u751f\u7d20D\u4e0a/\u4e0b\u8c03\u7b7e\u540dGSEA\u66f2\u7ebf', 'P3_B2_WGCNA_RAWP.pdf'), ('C\uff1aWGCNA\u6a21\u5757\u65b9\u5411\u70ed\u56fe', 'P3_C_WGCNA_RAWP.pdf'), ('D\uff1aGDF15\u865a\u62df\u6572\u9664\u4e0eWGCNA\u6a21\u5757\u4ea4\u53c9\u6bd4\u8f83', 'P3_D_WGCNA_RAWP.pdf')]]), dict(title='6. MAPK / ERK\u901a\u8def\u4e0e\u5355\u7ec6\u80de\u8bc4\u5206', subtitle='Williams\u5355\u7ec6\u80de\u6700\u65b0\u7248 + \u5386\u53f2GSEA / PROGENy\u539f\u9875', notes=['Williams\u72b6\u6001\u56fe\uff1a2026-09-20\uff1b\u7ef4\u751f\u7d20D\u53cc\u8bc4\u5206\u53ca\u8865\u5145\u56fe\uff1a2026-10-08\u3002', '\u7ef4\u751f\u7d20D\u57fa\u56e0\u8bc4\u5206\u662f\u8868\u8fbe\u8bc4\u5206\uff1b\u5bf9\u5e94\u9ad8\u4f4e\u7ec4\u6bd4\u8f83\u5e76\u975e\u7ed9\u836f\u5206\u7ec4\u3002', '\u65e7GSEA/PROGENy\u75be\u75c5\u8f93\u5165\u542bPagella\u7259\u5468\u7ec4\u7ec7\uff0c\u672a\u6838\u5b9e\u4e3a\u7eaf\u7259\u9f88\u3002', '\u8fd9\u4e24\u5f20\u65e7\u56fe\u4ec5\u5217\u4e3a\u5386\u53f2\u53c2\u8003\uff1b\u65e7\u4f9b\u8005\u7ea7\u70ed\u56fe\u53e6\u4fdd\u7559\u5176\u539f\u59cb\u8f93\u5165\u53e3\u5f84\u3002', '\u672c\u6b21\u53ea\u6574\u7406\u539f\u56fe\uff0c\u5386\u53f2\u56fe\u4e2d\u7684FDR\u53ca\u65e2\u6709\u88c1\u8fb9\u672a\u6539\u52a8\u3002'], items=[item('Williams\uff1a\u7ec6\u80de\u72b6\u6001\u3001GDF15/ERK\u8868\u8fbe\u4e0e\u7a0b\u5e8f\u8bc4\u5206 A-G', ref / 'Reference_Fig3_style_gingival_fibroblast_GDF15_ERK_state_20260915_Williams_20260920.pdf'), item('Williams\uff1a\u7ef4\u751f\u7d20D/GDF15/ERK/MMP\u53cc\u8bc4\u5206\u7efc\u5408\u56fe RAW P', vd / 'Fig2_Williams_VitaminD_GDF15_ERK_MMP_dual_scoring_JHazMat_style_20261008_noACE_Aaxes1to1_rawp.pdf'), item('Williams\u53cc\u8bc4\u5206\u8865\u5145\uff1a\u9ad8/\u4f4e\u5206\u7ec4UMAP\uff08\u7d27\u51d1\u6700\u65b0\u7248\uff09', vd / 'Fig2_B_C_Williams_VD46_AddModuleScore_AUCell_high_low_UMAP_20261008_compact.pdf'), item('Williams\u53cc\u8bc4\u5206\u8865\u5145\uff1a5\u79cd\u72b6\u6001\u7684\u9ad8/\u4f4e\u8bc4\u5206\u7ec6\u80de\u6bd4\u4f8b', vd / 'Fig2_D_E_Williams_VD46_five_states_high_low_proportions_20261008.pdf'), item('\u5386\u53f2\u53c2\u8003\uff1aMAPK/ECM GSEA\u65b9\u5411\u4e0e\u5e94\u7b54\u57fa\u56e0\u70ed\u56fe', core / '\u6838\u5fc3\u7ed3\u679cB_MAPK_ECM_\u65b9\u5411\u70ed\u56fe_20260914.pdf'), item('\u5386\u53f2\u53c2\u8003\uff1aPROGENy\u8f6c\u5f55\u8db3\u8ff9', core / '\u7b2c4\u9879_PROGENy\u8f6c\u5f55\u8db3\u8ff9_20260914.pdf'), item('\u5386\u53f2\u53c2\u8003\uff1a\u4f9b\u8005\u6807\u7b7e\u7ea7\u7a0b\u5e8f\u8db3\u8ff9\u70ed\u56fe', ROOT / 'P4_MAPK_ECM' / 'outputs' / 'figures' / '\u56feP4C_\u4f9b\u8005\u7ea7\u7a0b\u5e8f\u8db3\u8ff9\u70ed\u56fe.pdf')]), dict(title='\u9644\u5f55. Zhang\u590d\u5236\u6837\u672cWGCNA\u6f14\u793a', subtitle='\u7528\u6237\u8981\u6c42\u4fdd\u7559\u7684\u6f14\u793a\u7248\u672c\uff0c\u72ec\u7acb\u4e8e\u6b63\u5f0f\u5206\u6790', notes=['GSE212728\uff1a5\u4efd\u57f9\u517b\u6837\u672c\uff083 D3 + 2\u4e59\u9187\uff09\uff0c\u6765\u81ea1\u540d\u4f9b\u8005\u3002', '\u590d\u52364\u4efd\u5f62\u621020\u5217\uff0c\u4ecd\u662f5\u79cd\u539f\u59cb\u8868\u8fbe\u6570\u636e\uff1b\u65b0\u589e\u72ec\u7acb\u6837\u672c\u6570\u4e3a0\u3002', '\u539f\u56fe\u5df2\u660e\u786e\u6807\u6ce8DEMONSTRATION ONLY\uff1b\u590d\u5236\u540e\u7684P\u503c\u5c5e\u4e8e\u65e0\u6548\u6f14\u793a\u3002'], items=[item('Zhang\uff1a\u590d\u5236\u8f93\u5165\u3001\u53c2\u6570\u3001\u6a21\u5757\u3001\u76ee\u6807\u57fa\u56e0\u53ca\u57fa\u56e0\u6811\uff085\u9875\uff09', ROOT / 'output' / 'Zhang_\u590d\u52364\u4efd_WGCNA\u6f14\u793a_20261007' / '\u56fe' / 'Zhang_duplicate4_WGCNA_DEMONSTRATION.pdf')])]

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
next_page = 2
for g in groups:
    g['header_page'] = next_page
    next_page += 1
    for x in g['items']:
        p = Path(x['path'])
        if not p.is_file():
            raise FileNotFoundError(p)
        with fitz.open(p) as d:
            x['pages'] = len(d)
            x['sizes'] = [[round(t.rect.width, 4), round(t.rect.height, 4)] for t in d]
        x['sha256_before'] = sha(p)
        x['start_page'] = next_page
        next_page += x['pages']
    g['end_page'] = next_page - 1
W, H = A4

def generated_page(title, subtitle, lines, notes, page_number):
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    c.setTitle('\u7b2c4\u30015\u30016\u9879\u6700\u65b0\u7248\u56fe\u6c47\u603b')
    c.setFillColorRGB(0.11, 0.15, 0.21)
    c.setFont('Chinese', 19)
    c.drawString(38, H - 55, title)
    c.setFont('Chinese', 10)
    c.setFillColorRGB(0.35, 0.39, 0.45)
    c.drawString(38, H - 79, subtitle)
    c.setStrokeColorRGB(0.8, 0.82, 0.86)
    c.line(38, H - 95, W - 38, H - 95)
    y = H - 125
    for label, page in lines:
        c.setFillColorRGB(0.12, 0.16, 0.22)
        c.setFont('Chinese', 10)
        c.drawString(38, y, label)
        c.setFont('Arial', 10)
        c.drawRightString(W - 38, y, str(page))
        y -= 22
    y -= 15
    c.setFillColorRGB(0.18, 0.23, 0.3)
    c.setFont('Chinese', 11)
    c.drawString(38, y, '\u6765\u6e90\u4e0e\u7248\u672c\u8bf4\u660e')
    y -= 24
    c.setFont('Chinese', 9)
    for text in notes:
        chunks = []
        line = ''
        for ch in text:
            if pdfmetrics.stringWidth(line + ch, 'Chinese', 9) > W - 90:
                chunks.append(line)
                line = ch
            else:
                line += ch
        chunks.append(line)
        for chunk in chunks:
            c.drawString(42, y, chunk)
            y -= 16
        y -= 5
    if y < 58:
        raise RuntimeError(f'Generated contents page overflow: {title}')
    c.setFont('Chinese', 8)
    c.setFillColorRGB(0.45, 0.48, 0.52)
    c.drawString(38, 28, '\u539f\u56fe\u539f\u9875\u5408\u5e76\uff1b\u539f\u59cb\u5206\u6790\u3001\u914d\u8272\u3001\u6bd4\u4f8b\u4e0e\u5386\u53f2\u6587\u4ef6\u5747\u4fdd\u7559\u3002')
    c.setFont('Arial', 8)
    c.drawRightString(W - 38, 28, str(page_number))
    c.showPage()
    c.save()
    return fitz.open(stream=buf.getvalue(), filetype='pdf')
doc = fitz.open()
toc = []
overview = [(g['title'], f"{g['header_page']}-{g['end_page']}") for g in groups]
first = generated_page('\u7b2c4\u30015\u30016\u9879\u6700\u65b0\u7248\u56fe\u6c47\u603b', '\u6574\u7406\u65e5\u671f\uff1a2026-10-08 | \u540c\u56fe\u9009\u6700\u65b0\u7248\u672c\uff1b\u4e0d\u540c\u8f93\u5165\u4e0e\u7248\u5f0f\u5206\u5f00\u5217\u793a', overview, ['\u672c\u6587\u4ef6\u6c47\u603b\u65e2\u6709\u5206\u6790\u56fe\uff0c\u4e0d\u91cd\u7b97\u5206\u6790\u3001\u4e0d\u8986\u76d6\u539f\u56fe\u3002\u53f3\u680f\u4e3a\u672c\u6c47\u603bPDF\u9875\u7801\u3002', '\u7b2c5\u9879\u91c7\u752810\u67088\u65e5RAW P\u7248\uff1b\u7b2c4\u30016\u9879\u6309\u5404\u56fe\u5b9e\u9645\u7248\u672c\u65e5\u671f\u4fdd\u7559\u3002', '\u7b2c4\u9879\u5305\u62ec\u7259\u9f88bulk\u3001Williams hdWGCNA\u53ca\u65b0\u7248Williams WGCNA\u8bca\u65ad\u3002', '\u7b2c6\u9879\u5305\u62ecWilliams\u7ec6\u80de\u72b6\u6001\u3001\u7ef4\u751f\u7d20D\u53cc\u8bc4\u5206\u53ca\u5386\u53f2GSEA/PROGENy\u3002', '\u5386\u53f2\u56fe\u4e2d\u7684FDR\u7ee7\u7eed\u6309\u539f\u56fe\u6807\u6ce8\uff1b\u672c\u6b21\u672a\u7edf\u4e00\u91cd\u7b97\u4e3aRAW P\u3002', '\u65e7GSEA/PROGENy\u5305\u542b\u672a\u6838\u5b9e\u4e3a\u7eaf\u7259\u9f88\u7684Pagella\u8f93\u5165\uff0c\u5df2\u5728\u7b2c6\u9879\u6807\u660e\u3002', '\u590d\u5236Zhang\u6837\u672c\u7684\u56fe\u5355\u72ec\u653e\u5728\u6f14\u793a\u9644\u5f55\uff0c\u4e0d\u4e0e\u6b63\u5f0f\u7ed3\u679c\u6df7\u6392\u3002', '\u540c\u4e00\u961f\u5217\u4ea7\u751f\u7684\u6a21\u5757\u3001\u5dee\u5f02\u548c\u901a\u8def\u7ed3\u679c\u5c5e\u4e8e\u4e92\u8865\u5206\u6790\uff0c\u4e0d\u89c6\u4e3a\u72ec\u7acb\u91cd\u590d\u9a8c\u8bc1\u3002', '\u539f\u56fe\u5b58\u5728\u7684\u6807\u9898\u88c1\u8fb9\u7b49\u65e7\u7248\u95ee\u9898\u4fdd\u7559\uff1b\u672c\u6c47\u603b\u4e0d\u65b0\u589e\u88c1\u526a\u6216\u6539\u7ed8\u3002'], 1)
doc.insert_pdf(first)
first.close()
toc.append([1, '\u76ee\u5f55\u4e0e\u7248\u672c\u8bf4\u660e', 1])
mapping = []
for g in groups:
    cp = generated_page(g['title'], g['subtitle'], [(x['label'], x['start_page']) for x in g['items']], g['notes'], g['header_page'])
    doc.insert_pdf(cp)
    cp.close()
    toc.append([1, g['title'], g['header_page']])
    for x in g['items']:
        with fitz.open(x['path']) as src:
            doc.insert_pdf(src)
        toc.append([2, x['label'], x['start_page']])
        mapping.append(dict(section=g['title'], **x))
doc.set_toc(toc)
doc.set_metadata(dict(title='\u7b2c4\u30015\u30016\u9879\u6700\u65b0\u7248\u56fe\u6c47\u603b - 2026-10-08', author='Scientific figure compilation', subject='WGCNA; reverse signature; MAPK/ERK; gingival fibroblasts'))
if '--verify-only' not in sys.argv:
    doc.save(PDF, garbage=4, deflate=True)
doc.close()
pixel_checks = []
with fitz.open(PDF) as merged:
    assert len(merged) == next_page - 1
    for x in mapping:
        with fitz.open(x['path']) as src:
            for j, sp in enumerate(src):
                mp = merged[x['start_page'] - 1 + j]
                assert abs(sp.rect.width - mp.rect.width) < 0.01
                assert abs(sp.rect.height - mp.rect.height) < 0.01
                sm = sp.get_pixmap(matrix=fitz.Matrix(0.6, 0.6), alpha=False)
                mm = mp.get_pixmap(matrix=fitz.Matrix(0.6, 0.6), alpha=False)
                content_identical = sp.read_contents() == mp.read_contents()
                assert content_identical, f"Page drawing commands changed: {x['path']} page {j + 1}"
                identical = sm.samples == mm.samples
                maximum_pixel_difference = max((abs(a - b) for a, b in zip(sm.samples, mm.samples)), default=0)
                assert maximum_pixel_difference <= 2, f"Page render changed: {x['path']} page {j + 1}"
                pixel_checks.append(dict(output_page=x['start_page'] + j, source_page=j + 1, drawing_commands_identical=content_identical, pixels_identical=identical, maximum_pixel_difference=maximum_pixel_difference, note='Up to 2/255 raster rounding tolerance; original drawing commands unchanged.'))
        x['sha256_after'] = sha(x['path'])
        assert x['sha256_before'] == x['sha256_after']
    for g in groups:
        p = merged[g['header_page'] - 1]
        assert len(p.get_text()) > 50
    total_pages = len(merged)
record = dict(created_at=datetime.now().isoformat(timespec='seconds'), output=str(PDF), total_pages=total_pages, source_files=len(mapping), figure_pages=len(pixel_checks), source_pages_unchanged=True, source_files_unchanged=True, note='Existing source-PDF edge clipping and historical statistical labels were preserved, not repaired or recalculated.', visual_review='pending', sources=mapping, page_pixel_checks=pixel_checks)
(AUX / '\u6c47\u603b\u6765\u6e90\u6e05\u5355.json').write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
(QA / 'page_integrity_check.json').write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(dict(output=str(PDF), pages=total_pages, source_files=len(mapping), figure_pages=len(pixel_checks), page_content_unchanged=True), ensure_ascii=False))
