from pathlib import Path
import json, hashlib, shutil
import fitz
import numpy as np
root = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008')
aux = root / '\u5176\u4ed6'
qa = aux / 'QA'
target = root / '\u56fe/\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u5b8c\u6574\u62fc\u56fe_3\u9875.pdf'
manifest_path = aux / '\u62fc\u56fe\u6765\u6e90\u4e0e\u53bb\u91cd\u6e05\u5355.json'
m = json.loads(manifest_path.read_text(encoding='utf-8'))
entries = [r for r in m['panels'] if r['figure'] == 5 and r['tag'] == 'A']
assert len(entries) == 1, entries
entry = entries[0]
backup = qa / '\u5b8c\u6574\u62fc\u56fe_Fig5A\u5220\u9664\u524d_20261009.pdf'
backup_manifest = qa / '\u62fc\u56fe\u6e05\u5355_Fig5A\u5220\u9664\u524d_20261009.json'
assert not backup.exists() and (not backup_manifest.exists()), 'Backup conflict'
shutil.copy2(target, backup)
shutil.copy2(manifest_path, backup_manifest)
before = fitz.open(target)
doc = fitz.open(target)
rect = fitz.Rect(18, 55, 441, 405)
doc[1].add_redact_annot(rect, fill=(1, 1, 1))
doc[1].apply_redactions(images=2, graphics=2, text=0)
stage = qa / '\u5b8c\u6574\u62fc\u56fe_Fig5A\u5220\u9664\u540e_20261009.pdf'
doc.save(stage, garbage=4, deflate=True)
doc.close()
after = fitz.open(stage)
assert len(after) == 3
assert 'Disease vs vitamin-D gene changes' not in after[1].get_text()
assert 'Spearman' not in after[1].get_text()
checks = []
for i in range(3):
    oldpix = before[i].get_pixmap(matrix=fitz.Matrix(1, 1), alpha=False)
    newpix = after[i].get_pixmap(matrix=fitz.Matrix(1, 1), alpha=False)
    a = np.frombuffer(oldpix.samples, np.uint8).reshape(oldpix.height, oldpix.width, 3)
    b = np.frombuffer(newpix.samples, np.uint8).reshape(newpix.height, newpix.width, 3)
    assert a.shape == b.shape
    if i == 1:
        mask = np.ones(a.shape[:2], dtype=bool)
        mask[54:407, 17:443] = False
        assert np.array_equal(a[mask], b[mask]), 'Content changed outside Fig5A'
        assert np.all(b[56:405, 19:441] == 255), 'Fig5A area not blank'
    else:
        assert np.array_equal(a, b), f'Unrelated page {i + 1} changed'
    checks.append({'page': i + 1, 'other_content_pixel_identical': True})
after[1].get_pixmap(matrix=fitz.Matrix(1.2, 1.2), alpha=False).save(qa / 'Fig5A_removed_page_preview_20261009.png')
after.close()
before.close()
assert hashlib.sha256(target.read_bytes()).digest() == hashlib.sha256(backup.read_bytes()).digest(), 'Current PDF changed during edit'
shutil.copy2(stage, target)
m['panels'] = [r for r in m['panels'] if not (r['figure'] == 5 and r['tag'] == 'A')]
m['exclusions'].append({'figure': 5, 'tag': 'A', 'title': entry['title'], 'source': entry['source'], 'status': '\u6682\u4e0d\u5206\u6790', 'reason': '2026-10-09 \u7528\u6237\u8981\u6c42\u5220\u9664\u75be\u75c5-\u7ef4\u751f\u7d20D\u6563\u70b9\u56fe\uff1b\u5386\u53f2\u539f\u56fe\u4e0e\u6570\u636e\u4fdd\u7559'})
m['last_user_revision'] = '2026-10-09 \u5220\u9664\u7b2c5\u9879A\u6563\u70b9\u56fe\uff0c\u6807\u8bb0\u6682\u4e0d\u5206\u6790\uff1b\u524d\u6b21Q\u56fe\u6392\u9664\u7ee7\u7eed\u4fdd\u7559'
manifest_path.write_text(json.dumps(m, ensure_ascii=False, indent=2), encoding='utf-8')
audit = {'removed': 'Figure 5 A: Disease vs vitamin-D gene changes', 'status': '\u6682\u4e0d\u5206\u6790', 'output': str(target), 'historical_backup': str(backup), 'other_panels_unchanged': checks, 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'visual_review': 'pending'}
(qa / 'Fig5A_removal_validation_20261009.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(audit, ensure_ascii=False, indent=2))
