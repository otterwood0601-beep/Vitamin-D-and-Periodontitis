from pathlib import Path
import fitz
folder = Path('C:\\Users\\Lin\\Desktop\\\u6700\u7ec8\u6295\u7a3f\u6587\u672c\\\u8865\u5145\u56fe\\DLC\\6.Lin')
source = folder / 'PROGENy_NFkB_MAPK_FeaturePlot_Williams_20261009.pdf'
target = folder / 'PROGENy_MAPK_FeaturePlot_Williams_20261009.pdf'
with fitz.open(source) as doc:
    clip = fitz.Rect(258, 4, 530, 256)
    result = fitz.open()
    page = result.new_page(width=clip.width, height=clip.height)
    page.show_pdf_page(page.rect, doc, 0, clip=clip)
    text = page.get_text(clip=page.rect)
    assert 'MAPK' in text and 'NFkB' not in text and ('Score (Z)' in text)
    result.save(target, garbage=4, deflate=True)
    result.close()
print(target)
