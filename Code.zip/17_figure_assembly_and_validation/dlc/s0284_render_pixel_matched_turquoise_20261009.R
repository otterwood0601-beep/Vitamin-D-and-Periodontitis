.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(ggplot2)})
aux <- 'C:/wb_links/panel456_20261008'
d <- fread(file.path(aux,'source_data/F_pixel_matched_SCHEMATIC_20261009.csv'))

p <- ggplot(d,aes(frozen_umap_1,frozen_umap_2,colour=schematic_color)) +
 geom_point(size=.28) + coord_equal(expand=FALSE,
  xlim=range(d$frozen_umap_1)+c(-.12,.12),ylim=range(d$frozen_umap_2)+c(-.12,.12)) +
 scale_colour_identity() + labs(title='turquoise') +
 theme_void(base_family='Arial') + theme(
 plot.title=element_text(size=12,face='bold',hjust=.5,margin=margin(b=2)),
 plot.margin=margin(1,1,1,1))
cairo_pdf('C:/Users/Lin/AppData/Local/Temp/F_turquoise_pixel_matched_20261009.pdf',width=2.5,height=2.925,family='Arial')
print(p);dev.off()
