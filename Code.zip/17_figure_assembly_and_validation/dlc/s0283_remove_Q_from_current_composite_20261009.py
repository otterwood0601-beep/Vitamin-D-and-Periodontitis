from pathlib import Path
import json, hashlib, shutil
import fitz
import numpy as np
root = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u62fc\u56fe_20261008')
aux = root / '\u5176\u4ed6'
qa = aux / 'QA'
target = root / '\u56fe/\u7b2c4_5_6\u9879_\u6700\u65b0\u7248\u5b8c\u6574\u62fc\u56fe_3\u9875.pdf'
manifest_path = aux / '\u62fc\u56fe\u6765\u6e90\u4e0e\u53bb\u91cd\u6e05\u5355.json'
m = json.loads(manifest_path.read_text(encoding='utf-8'))
entries = [r for r in m['panels'] if r['figure'] == 4 and r['tag'] == 'Q']
assert len(entries) == 1, entries
entry = entries[0]
backup = qa / '\u5b8c\u6574\u62fc\u56fe_Q\u5220\u9664\u524d_20261009.pdf'
backup_manifest = qa / '\u62fc\u56fe\u6e05\u5355_Q\u5220\u9664\u524d_20261009.json'
assert not backup.exists() and (not backup_manifest.exists()), 'Backup already exists; avoid overwrite'
shutil.copy2(target, backup)
shutil.copy2(manifest_path, backup_manifest)
before = fitz.open(target)
doc = fitz.open(target)
rect = fitz.Rect(624, 1774, 882, 1983)
doc[0].add_redact_annot(rect, fill=(1, 1, 1))
doc[0].apply_redactions(images=2, graphics=2, text=0)
stage = qa / '\u5b8c\u6574\u62fc\u56fe_Q\u5220\u9664\u540e_20261009.pdf'
doc.save(stage, garbage=4, deflate=True)
doc.close()
after = fitz.open(stage)
assert len(after) == 3
assert 'Module replication in gingival bulk' not in after[0].get_text()
checks = []
for i in range(3):
    oldpix = before[i].get_pixmap(matrix=fitz.Matrix(1, 1), alpha=False)
    newpix = after[i].get_pixmap(matrix=fitz.Matrix(1, 1), alpha=False)
    a = np.frombuffer(oldpix.samples, np.uint8).reshape(oldpix.height, oldpix.width, 3)
    b = np.frombuffer(newpix.samples, np.uint8).reshape(newpix.height, newpix.width, 3)
    assert a.shape == b.shape
    if i == 0:
        mask = np.ones(a.shape[:2], dtype=bool)
        mask[1773:1985, 623:884] = False
        assert np.array_equal(a[mask], b[mask]), 'Changed content outside Q'
        assert np.all(b[1775:1983, 625:882] == 255), 'Q area is not blank'
    else:
        assert np.array_equal(a, b), f'Unrelated page {i + 1} changed'
    checks.append({'page': i + 1, 'other_content_pixel_identical': True})
after[0].get_pixmap(matrix=fitz.Matrix(1.3, 1.3), clip=fitz.Rect(340, 1745, 900, 2010), alpha=False).save(qa / 'Q_removed_context_preview_20261009.png')
after.close()
before.close()
shutil.copy2(stage, target)
m['panels'] = [r for r in m['panels'] if not (r['figure'] == 4 and r['tag'] == 'Q')]
m['exclusions'].append({'figure': 4, 'tag': 'Q', 'title': entry['title'], 'source': entry['source'], 'status': '\u540e\u9762\u6682\u4e0d\u5206\u6790', 'reason': '2026-10-09 \u7528\u6237\u8ba4\u4e3a\u4e0e\u524d\u9762\u91cd\u590d\uff0c\u8981\u6c42\u5220\u9664\u5f53\u524d\u5957\u56fe\u4e2d\u7684\u6b64\u9762\u677f\uff1b\u5386\u53f2\u6570\u636e\u53ca\u539f\u56fe\u4fdd\u7559'})
m['last_user_revision'] = '2026-10-09 \u5220\u9664Q\u56fe\uff0c\u6807\u8bb0\u540e\u9762\u6682\u4e0d\u5206\u6790\uff1b\u672a\u91cd\u6392\u5176\u4f59\u9762\u677f'
manifest_path.write_text(json.dumps(m, ensure_ascii=False, indent=2), encoding='utf-8')
audit = {'removed': 'Figure 4 Q: Module replication in gingival bulk', 'status': '\u540e\u9762\u6682\u4e0d\u5206\u6790', 'output': str(target), 'historical_backup': str(backup), 'other_panels_unchanged': checks, 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'visual_review': 'pending'}
(qa / 'Q_removal_validation_20261009.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(audit, ensure_ascii=False, indent=2))
