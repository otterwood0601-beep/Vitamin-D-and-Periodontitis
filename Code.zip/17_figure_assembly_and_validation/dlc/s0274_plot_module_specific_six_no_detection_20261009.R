.libPaths(c('C:/Users/Lin/AppData/Local/R/win-library/4.5',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(ggplot2);library(ragg)})
base <- 'C:/wb_links/panel456_20261008/module_specific_20261009'
out <- file.path(base,'six_modules_no_detection')
dir.create(out,recursive=TRUE,showWarnings=FALSE)
dt <- fread(file.path(base,'all_module_gene_celltype_expression.csv'))
dt[,eligible:=ratio>=2] 
selection <- list(); target_records <- list()
for(m in unique(dt$module)) {
 q <- dt[module==m & eligible==TRUE]
 fallback <- !nrow(q)
 if(fallback) {
  q <- dt[module==m & ratio>1]
  setorder(q,celltype,-ratio,-pct)
  candidates <- q[,head(.SD,6),by=celltype]
  ranks <- candidates[,. (n=.N,score=mean(ratio)),by=celltype]
  ranks <- ranks[n==6][order(-score)]
 } else {
  ranks <- q[,.(n=.N,score=median(ratio)),by=celltype][order(-n,-score)]
 }
 target <- ranks$celltype[1]
 z <- q[celltype==target][order(-ratio,-pct)][1:min(6,.N)]
 z[,selection_status:=if(fallback)'relative_preference_below_2x' else 'at_least_2x_each_other_state']
 selection[[m]] <- z
 target_records[[m]] <- data.table(module=m,target=target,n=nrow(z),fallback=fallback,max_ratio=max(z$ratio),min_ratio=min(z$ratio))
}
sel <- rbindlist(selection)
targets <- rbindlist(target_records)
types <- c('Pre-extracellular matrix-associated fibroblasts','ECM remodeling-associated fibroblasts','Vascular-associated fibroblasts','Matrix homeostasis-associated fibroblasts','Immune-associated fibroblasts')
short <- c('Pre-ECM','ECM remodeling','Vascular','Matrix homeostasis','Immune')
targets[,target_index:=match(target,types)]
setorder(targets,target_index,fallback,module)
mods <- targets$module
sel[,module_order:=match(module,mods)]
setorder(sel,module_order,-ratio,-pct)
genes <- sel$gene
d <- dt[gene %in% genes]
d[,relative_mean:=mean_linear/max(mean_linear),by=gene]
stopifnot(uniqueN(sel$module)==6,uniqueN(sel$gene)==nrow(sel),nrow(d)==5*nrow(sel))
stopifnot(all(sel[module %in% c('red','green')]$ratio<2),all(sel[!module %in% c('red','green')]$ratio>=2))
fwrite(sel,file.path(out,'selected_genes.csv'))
fwrite(targets,file.path(out,'module_selection_summary.csv'))
fwrite(d,file.path(out,'plot_data.csv'))
d[,celltype:=factor(celltype,levels=types,labels=short)]
d[,gene:=factor(gene,levels=rev(genes))]
d[,module:=factor(module,levels=mods)]
labs_mod <- setNames(ifelse(mods %in% c('green','red'),paste0(mods,'*'),mods),mods)
p <- ggplot(d,aes(celltype,gene)) +
 geom_point(aes(size=pct,colour=relative_mean)) +
 scale_colour_gradientn(colours=c('#000004','#3B0F70','#8C2981','#DE4968','#F89D6C','#D9A400'),
  limits=c(0,1),name='Relative mean\nexpression\n(within gene)') +
 scale_size_area(max_size=4.5,limits=c(0,100),breaks=c(10,25,50,75,100),name='% expressed') +
 facet_grid(module~.,scales='free_y',space='free_y',labeller=labeller(module=labs_mod)) +
 labs(x=NULL,y=NULL,caption='No minimum detection percentage. Selected genes, not all module genes.\n* green/red: strongest relative preference, below 2x; other modules: at least 2x each other state.') +
 theme_classic(base_family='Arial',base_size=10) +
 theme(axis.text.x=element_text(angle=45,hjust=1,colour='black'),axis.text.y=element_text(colour='black',size=9),
 strip.background=element_blank(),strip.text.y=element_text(face='bold',size=10),
 panel.spacing.y=grid::unit(5,'pt'),legend.title=element_text(size=9),legend.text=element_text(size=8),
 plot.caption=element_text(size=7,hjust=0),plot.margin=margin(8,8,8,8))
tmp <- 'C:/Users/Lin/AppData/Local/Temp/module_specific_six_gold_20261009.png'
stopifnot(!file.exists(tmp))
agg_png(tmp,width=1400,height=2350,units='px',res=230,background='white')
print(p);dev.off()
print(targets);cat('Total selected:',nrow(sel),'\n')
