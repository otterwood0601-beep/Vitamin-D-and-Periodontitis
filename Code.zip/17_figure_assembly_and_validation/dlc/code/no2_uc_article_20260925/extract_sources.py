from __future__ import annotations
import json
import re
import sys
import zipfile
from pathlib import Path
from docx import Document
from lxml import etree
from pptx import Presentation

def clean(text: str) -> str:
    return re.sub('\\s+', ' ', text or '').strip()

def extract_pptx(path: Path) -> dict:
    prs = Presentation(path)
    slides = []
    for idx, slide in enumerate(prs.slides, start=1):
        items = []
        for shape in sorted(slide.shapes, key=lambda s: (getattr(s, 'top', 0), getattr(s, 'left', 0))):
            entry = {'name': shape.name, 'shape_type': str(shape.shape_type), 'left': int(getattr(shape, 'left', 0)), 'top': int(getattr(shape, 'top', 0)), 'width': int(getattr(shape, 'width', 0)), 'height': int(getattr(shape, 'height', 0))}
            if getattr(shape, 'has_text_frame', False):
                entry['text'] = clean('\n'.join((p.text for p in shape.text_frame.paragraphs)))
            if getattr(shape, 'has_table', False):
                entry['table'] = [[clean(cell.text) for cell in row.cells] for row in shape.table.rows]
            items.append(entry)
        notes = ''
        try:
            notes = clean('\n'.join((shape.text for shape in slide.notes_slide.shapes if getattr(shape, 'has_text_frame', False))))
        except Exception:
            pass
        slides.append({'slide': idx, 'items': items, 'notes': notes})
    return {'source': str(path), 'slide_width': int(prs.slide_width), 'slide_height': int(prs.slide_height), 'slide_count': len(prs.slides), 'slides': slides}

def extract_docx(path: Path) -> dict:
    doc = Document(path)
    paragraphs = []
    for idx, paragraph in enumerate(doc.paragraphs, start=1):
        text = clean(paragraph.text)
        if text:
            paragraphs.append({'index': idx, 'style': paragraph.style.name if paragraph.style else '', 'text': text})
    tables = []
    for idx, table in enumerate(doc.tables, start=1):
        tables.append({'table': idx, 'rows': [[clean(cell.text) for cell in row.cells] for row in table.rows]})
    all_xml_text = []
    namespaces = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    with zipfile.ZipFile(path) as archive:
        xml_names = [name for name in archive.namelist() if name == 'word/document.xml' or name.startswith('word/header') or name.startswith('word/footer')]
        for name in xml_names:
            root = etree.fromstring(archive.read(name))
            parts = [clean(x) for x in root.xpath('//w:t/text()', namespaces=namespaces)]
            all_xml_text.append({'part': name, 'text': clean(' '.join(parts))})
        media = [name for name in archive.namelist() if name.startswith('word/media/')]
    return {'source': str(path), 'paragraph_count': len(doc.paragraphs), 'table_count': len(doc.tables), 'inline_shape_count': len(doc.inline_shapes), 'media_count': len(media), 'paragraphs': paragraphs, 'tables': tables, 'xml_text_parts': all_xml_text, 'media_files': media}

def main() -> None:
    if len(sys.argv) == 4 and sys.argv[1] == '--docx':
        docx_path = Path(sys.argv[2])
        out_dir = Path(sys.argv[3])
        out_dir.mkdir(parents=True, exist_ok=True)
        doc = extract_docx(docx_path)
        (out_dir / 'docx_structure.json').write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding='utf-8')
        doc_lines = [f"[{p['style']}] {p['text']}" for p in doc['paragraphs']]
        for table in doc['tables']:
            doc_lines.append(f"\n# Table {table['table']}")
            doc_lines.extend((' | '.join(row) for row in table['rows']))
        (out_dir / 'docx_text.txt').write_text('\n'.join(doc_lines), encoding='utf-8')
        print(json.dumps({'docx_paragraphs': len(doc['paragraphs']), 'docx_tables': doc['table_count'], 'docx_inline_shapes': doc['inline_shape_count'], 'docx_media': doc['media_count']}, ensure_ascii=False))
        return
    if len(sys.argv) != 4:
        raise SystemExit('usage: extract_sources.py <pptx> <docx> <output_dir> | --docx <docx> <output_dir>')
    pptx_path = Path(sys.argv[1])
    docx_path = Path(sys.argv[2])
    out_dir = Path(sys.argv[3])
    out_dir.mkdir(parents=True, exist_ok=True)
    ppt = extract_pptx(pptx_path)
    doc = extract_docx(docx_path)
    (out_dir / 'pptx_structure.json').write_text(json.dumps(ppt, ensure_ascii=False, indent=2), encoding='utf-8')
    (out_dir / 'docx_structure.json').write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding='utf-8')
    ppt_lines = []
    for slide in ppt['slides']:
        ppt_lines.append(f"# Slide {slide['slide']}")
        for item in slide['items']:
            if item.get('text'):
                ppt_lines.append(item['text'])
            for row in item.get('table', []):
                ppt_lines.append(' | '.join(row))
        if slide.get('notes'):
            ppt_lines.append('[Notes] ' + slide['notes'])
        ppt_lines.append('')
    (out_dir / 'pptx_text.txt').write_text('\n'.join(ppt_lines), encoding='utf-8')
    doc_lines = [f"[{p['style']}] {p['text']}" for p in doc['paragraphs']]
    for table in doc['tables']:
        doc_lines.append(f"\n# Table {table['table']}")
        doc_lines.extend((' | '.join(row) for row in table['rows']))
    (out_dir / 'docx_text.txt').write_text('\n'.join(doc_lines), encoding='utf-8')
    print(json.dumps({'pptx_slides': ppt['slide_count'], 'docx_paragraphs': len(doc['paragraphs']), 'docx_tables': doc['table_count'], 'docx_inline_shapes': doc['inline_shape_count'], 'docx_media': doc['media_count']}, ensure_ascii=False))
if __name__ == '__main__':
    main()
