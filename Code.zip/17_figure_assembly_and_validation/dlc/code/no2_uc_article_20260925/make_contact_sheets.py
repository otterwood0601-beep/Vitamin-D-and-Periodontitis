from __future__ import annotations
import math
import sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

def main() -> None:
    if len(sys.argv) < 4:
        raise SystemExit('usage: make_contact_sheets.py <input_dir> <glob> <output_dir> [per_sheet]')
    input_dir = Path(sys.argv[1])
    pattern = sys.argv[2]
    output_dir = Path(sys.argv[3])
    per_sheet = int(sys.argv[4]) if len(sys.argv) > 4 else 12
    output_dir.mkdir(parents=True, exist_ok=True)
    paths = sorted(input_dir.glob(pattern))
    if not paths:
        raise SystemExit(f'no files matching {pattern} in {input_dir}')
    cols = 3
    rows = math.ceil(per_sheet / cols)
    thumb_w, thumb_h, label_h = (440, 280, 28)
    for sheet_index, start in enumerate(range(0, len(paths), per_sheet), start=1):
        subset = paths[start:start + per_sheet]
        canvas = Image.new('RGB', (cols * thumb_w, rows * (thumb_h + label_h)), 'white')
        draw = ImageDraw.Draw(canvas)
        for pos, path in enumerate(subset):
            image = Image.open(path).convert('RGB')
            image.thumbnail((thumb_w - 12, thumb_h - 12), Image.Resampling.LANCZOS)
            cell_x = pos % cols * thumb_w
            cell_y = pos // cols * (thumb_h + label_h)
            x = cell_x + (thumb_w - image.width) // 2
            y = cell_y + (thumb_h - image.height) // 2
            canvas.paste(image, (x, y))
            draw.rectangle((cell_x, cell_y, cell_x + thumb_w - 1, cell_y + thumb_h + label_h - 1), outline='#BFBFBF', width=1)
            draw.text((cell_x + 8, cell_y + thumb_h + 4), path.name, fill='black', font=ImageFont.load_default())
        canvas.save(output_dir / f'contact-{sheet_index:02d}.jpg', quality=92)
    print(f'created {math.ceil(len(paths) / per_sheet)} contact sheets from {len(paths)} images')
if __name__ == '__main__':
    main()
