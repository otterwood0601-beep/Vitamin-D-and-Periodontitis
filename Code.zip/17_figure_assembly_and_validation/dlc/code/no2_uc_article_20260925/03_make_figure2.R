options(stringsAsFactors = FALSE, scipen = 999)
set.seed(20260925)

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(patchwork)
  library(cowplot)
  library(ggrepel)
  library(scales)
  library(jsonlite)
})

OUT <- "C:/wb_links/jhazmat2026_no2uc_20260925"
SD <- file.path(OUT, "source_data")
FD <- file.path(OUT, "figures")

cells <- fread(file.path(SD, "03_Williams_VD17_dual_scores.csv.gz"))
dot <- fread(file.path(SD, "02_selected_gene_dotplot.csv"))
donor <- fread(file.path(SD, "04_donor_score_summary.csv"))
state <- fread(file.path(SD, "05_donor_state_score_summary.csv"))
endpoint <- fread(file.path(SD, "06_donor_state_group_endpoint_summary.csv"))
overall <- fread(file.path(SD, "07_donor_state_endpoint_summary.csv"))
de <- fread(file.path(SD, "08_paired_pseudobulk_high_vs_low_DE.csv.gz"))
disease_tests <- fread(file.path(SD, "10_disease_score_tests.csv"))
paired_tests <- fread(file.path(SD, "11_high_low_endpoint_tests.csv"))
corr_tests <- fread(file.path(SD, "12_endpoint_correlations.csv"))

go_file <- file.path(SD, "15_VD17_high_GO_Biological_Process_2025.csv")
kegg_file <- file.path(SD, "15_VD17_high_KEGG_2021_Human.csv")
if (!file.exists(go_file) || !file.exists(kegg_file)) {
  stop("Enrichment outputs are missing; run 02_fetch_enrichment.R first")
}
go <- fread(go_file)
kegg <- fread(kegg_file)

state_levels <- c("Immune", "ECM remodeling", "Vascular", "Pre-ECM", "Matrix homeostasis")
state_cols <- c(
  "Immune" = "#E78383",
  "ECM remodeling" = "#D7CE62",
  "Vascular" = "#76AFC1",
  "Pre-ECM" = "#D8A8B8",
  "Matrix homeostasis" = "#80C9B5"
)
disease_cols <- c("normal" = "#E68173", "periodontitis" = "#4D8FC2")
score_cols <- c("Low" = "#E68173", "High" = "#4D8FC2")

cells[, state := factor(state, levels = state_levels)]
cells[, disease := factor(disease, levels = c("normal", "periodontitis"))]
cells[, score_group := factor(score_group, levels = c("Low", "High"))]
donor[, disease := factor(disease, levels = c("normal", "periodontitis"))]
state[, state := factor(state, levels = state_levels)]
endpoint[, score_group := factor(score_group, levels = c("Low", "High"))]

paper_theme <- theme_classic(base_size = 7.6, base_family = "Arial") +
  theme(
    axis.title = element_text(size = 7.5, colour = "black"),
    axis.text = element_text(size = 6.3, colour = "black"),
    axis.line = element_line(linewidth = 0.35, colour = "black"),
    axis.ticks = element_line(linewidth = 0.3, colour = "black"),
    plot.title = element_text(size = 8.2, hjust = 0.5, face = "plain"),
    strip.text = element_text(size = 6.8, colour = "black"),
    strip.background = element_rect(fill = "white", colour = "black", linewidth = 0.3),
    legend.title = element_text(size = 6.5),
    legend.text = element_text(size = 5.8),
    legend.key.size = grid::unit(0.28, "cm"),
    plot.margin = margin(3, 3, 3, 3)
  )

umap_theme <- theme_void(base_family = "Arial", base_size = 7.6) +
  theme(
    plot.title = element_text(size = 8.2, hjust = 0.5),
    legend.title = element_text(size = 6.5),
    legend.text = element_text(size = 5.6),
    legend.key.size = grid::unit(0.25, "cm"),
    plot.margin = margin(3, 3, 3, 3)
  )

fmt_p <- function(p) {
  if (!is.finite(p)) return("p = NA")
  if (p < 0.001) return("p < 0.001")
  paste0("p = ", formatC(p, digits = 2, format = "f"))
}

short_term <- function(x, n = 42) {
  x <- gsub(" \\([A-Z]+:[0-9]+\\)$", "", x)
  ifelse(nchar(x) > n, paste0(substr(x, 1, n - 3), "..."), x)
}

enrich_top <- function(dt, n = 8) {
  if (!nrow(dt)) return(data.table())
  pcol <- intersect(c("Adjusted.P.value", "adjusted_p", "Adjusted.P.value."), names(dt))[1]
  termcol <- intersect(c("Term", "term"), names(dt))[1]
  if (is.na(pcol) || is.na(termcol)) stop("Unexpected enrichment columns")
  countcol <- intersect(c("Count", "count"), names(dt))[1]
  if (is.na(countcol)) {
    gcol <- intersect(c("Genes", "overlap_genes"), names(dt))[1]
    if (!is.na(gcol)) dt[, Count := lengths(strsplit(get(gcol), ";"))] else dt[, Count := 1]
    countcol <- "Count"
  }
  z <- copy(dt)[is.finite(get(pcol))][order(get(pcol))][1:min(n, .N)]
  z[, `:=`(
    term_plot = factor(short_term(get(termcol)), levels = rev(short_term(get(termcol)))),
    neglog10 = -log10(pmax(get(pcol), 1e-300)),
    count_plot = as.numeric(get(countcol))
  )]
  z
}

pA <- ggplot(cells, aes(frozen_umap_1, frozen_umap_2, colour = state)) +
  geom_point(size = 0.13, alpha = 0.72) +
  scale_colour_manual(values = state_cols, drop = FALSE, name = "Fibroblast state") +
  labs(title = "Fibroblast states") + umap_theme +
  theme(legend.position = "right")

pB <- ggplot(cells, aes(frozen_umap_1, frozen_umap_2, colour = disease)) +
  geom_point(size = 0.13, alpha = 0.68) +
  scale_colour_manual(values = disease_cols, name = NULL) +
  labs(title = "Gingival disease") + umap_theme +
  theme(legend.position = c(0.78, 0.18),
        legend.background = element_rect(fill = alpha("white", 0.78), colour = NA))

donor_ids <- sort(unique(cells$donor_id))
donor_cols <- setNames(hue_pal(l = 65, c = 100)(length(donor_ids)), donor_ids)
pC <- ggplot(cells, aes(frozen_umap_1, frozen_umap_2, colour = donor_id)) +
  geom_point(size = 0.13, alpha = 0.66) +
  scale_colour_manual(values = donor_cols, guide = "none") +
  labs(title = paste0("Donors (n = ", length(donor_ids), ")")) + umap_theme

dot[, state := factor(state, levels = state_levels)]
dot[, avg_scaled := {
  s <- sd(average_expression)
  if (!is.finite(s) || s == 0) rep(0, .N) else (average_expression - mean(average_expression)) / s
}, by = gene]
gene_order <- unique(dot$gene)
dot[, gene := factor(gene, levels = rev(gene_order))]
pD <- ggplot(dot, aes(state, gene, size = percent_detected, colour = avg_scaled)) +
  geom_point() +
  scale_size(range = c(0.25, 3.2), name = "% detected") +
  scale_colour_gradient2(low = "#4575B4", mid = "white", high = "#D73027",
                         midpoint = 0, name = "Mean\n(z-score)") +
  labs(title = "VD17 / GDF15 / ERK1/2 / MMP genes", x = NULL, y = NULL) +
  paper_theme +
  theme(axis.text.x = element_text(angle = 42, hjust = 1), legend.position = "right")

pref <- cells[, .N, by = .(disease, state)]
pref[, disease_prop := N / sum(N), by = disease]
overall_prop <- cells[, .N, by = state][, .(state, overall_prop = N / sum(N))]
pref[overall_prop, on = "state", overall_prop := i.overall_prop]
pref[, log2_OE := log2((disease_prop + 1e-6) / (overall_prop + 1e-6))]
pE <- ggplot(pref, aes(state, disease, fill = log2_OE)) +
  geom_tile(colour = "white", linewidth = 0.7) +
  geom_text(aes(label = percent(disease_prop, accuracy = 0.1)), size = 2.0,
            family = "Arial") +
  scale_fill_gradient2(low = "#4D8FC2", mid = "white", high = "#E68173",
                       midpoint = 0, name = "log2 O/E") +
  labs(title = "State distribution preference", x = NULL, y = NULL) +
  paper_theme + theme(axis.text.x = element_text(angle = 42, hjust = 1))

box_disease <- function(value, title, ylab, endpoint_name) {
  pval <- disease_tests[endpoint == endpoint_name, p_value][1]
  ggplot(donor, aes(disease, .data[[value]], fill = disease)) +
    geom_boxplot(width = 0.54, outlier.shape = NA, linewidth = 0.38, alpha = 0.88) +
    geom_jitter(width = 0.09, size = 1.05, shape = 21, colour = "black", stroke = 0.2) +
    scale_fill_manual(values = disease_cols, guide = "none") +
    annotate("text", x = 1.5, y = Inf, label = fmt_p(pval), vjust = 1.2,
             size = 2.2, family = "Arial") +
    labs(title = title, x = NULL, y = ylab) + paper_theme +
    theme(axis.text.x = element_text(angle = 20, hjust = 1))
}

pF <- box_disease("AddModuleScore", "AddModuleScore by disease",
                  "VD17 AddModuleScore", "AddModuleScore")
pG <- box_disease("AUCell", "AUCell by disease", "VD17 AUCell", "AUCell")

box_state <- function(value, title, ylab) {
  ggplot(state[n_cells >= 5], aes(state, .data[[value]], fill = state)) +
    geom_boxplot(width = 0.58, outlier.shape = NA, linewidth = 0.32, alpha = 0.88) +
    geom_jitter(width = 0.10, size = 0.55, alpha = 0.75) +
    scale_fill_manual(values = state_cols, guide = "none", drop = FALSE) +
    labs(title = title, x = NULL, y = ylab) + paper_theme +
    theme(axis.text.x = element_text(angle = 42, hjust = 1, size = 5.5))
}

pH <- box_state("AddModuleScore", "AddModuleScore by state", "VD17 AddModuleScore")
pI <- box_state("AUCell", "AUCell by state", "VD17 AUCell")

de_plot <- de[in_VD17_signature == FALSE]
de_plot[, y_plot := pmin(35, neglog10_FDR)]
de_plot[, direction := factor(direction, levels = c("Down", "NS", "Up"))]
axis_genes <- c("GDF15", "MAPK1", "MAPK3", "MMP1", "MMP2", "MMP3", "MMP9", "MMP14")
labels <- unique(c(
  de_plot[order(adj.P.Val)][1:min(6, .N), gene],
  intersect(axis_genes, de_plot$gene)
))
pJ <- ggplot(de_plot, aes(logFC, y_plot, colour = direction)) +
  geom_point(size = 0.55, alpha = 0.72) +
  geom_vline(xintercept = c(-0.25, 0.25), linetype = 2, linewidth = 0.28) +
  geom_hline(yintercept = -log10(0.05), linetype = 2, linewidth = 0.28) +
  geom_text_repel(data = de_plot[gene %in% labels], aes(label = gene),
                  size = 1.85, family = "Arial", max.overlaps = Inf,
                  min.segment.length = 0, box.padding = 0.25, show.legend = FALSE) +
  scale_colour_manual(values = c("Down" = "#4D8FC2", "NS" = "#BDBDBD", "Up" = "#E68173"),
                      drop = FALSE, name = NULL) +
  labs(title = "VD17-high vs VD17-low pseudobulk", x = "log2 fold change",
       y = expression(-log[10](FDR))) + paper_theme +
  theme(legend.position = c(0.80, 0.78),
        legend.background = element_rect(fill = alpha("white", 0.75), colour = NA))

enrich_plot <- function(dt, title, col) {
  z <- enrich_top(dt, 8)
  if (!nrow(z)) {
    return(ggplot() + annotate("text", x = 0, y = 0, label = "No enriched terms",
                               size = 2.5, family = "Arial") +
             xlim(-1, 1) + ylim(-1, 1) + theme_void() + ggtitle(title))
  }
  ggplot(z, aes(neglog10, term_plot, size = count_plot, colour = neglog10)) +
    geom_point(alpha = 0.88) +
    scale_size(range = c(1.1, 3.6), name = "Genes") +
    scale_colour_gradient(low = "#F5C7BD", high = col, guide = "none") +
    labs(title = title, x = expression(-log[10](adjusted~p)), y = NULL) +
    paper_theme + theme(axis.text.y = element_text(size = 5.3))
}

pK <- enrich_plot(kegg, "KEGG enrichment", "#C84D43")
pL <- enrich_plot(go, "GO biological process", "#C84D43")

gdf_test <- paired_tests[endpoint == "GDF15_detection", p_value][1]
pM <- ggplot(endpoint[n_cells >= 5], aes(score_group, GDF15_detection * 100,
                                        fill = score_group, group = pair_id)) +
  geom_line(aes(group = pair_id), colour = "#9E9E9E", linewidth = 0.18, alpha = 0.35) +
  geom_boxplot(aes(group = score_group), width = 0.48, outlier.shape = NA,
               linewidth = 0.35, alpha = 0.88) +
  geom_point(shape = 21, size = 0.75, colour = "black", stroke = 0.15,
             position = position_jitter(width = 0.06)) +
  scale_fill_manual(values = score_cols, guide = "none") +
  annotate("text", x = 1.5, y = Inf, label = fmt_p(gdf_test), vjust = 1.2,
           size = 2.2, family = "Arial") +
  labs(title = "GDF15 detection: VD17 high vs low", x = NULL,
       y = "GDF15-positive cells (%)") + paper_theme

gdf_corr <- corr_tests[endpoint == "GDF15_detection"]
pN <- ggplot(overall, aes(consensus_score, GDF15_detection * 100, colour = disease)) +
  geom_point(size = 1.05, alpha = 0.78) +
  geom_smooth(method = "lm", se = TRUE, colour = "#555555", fill = "#D9D9D9",
              linewidth = 0.45, inherit.aes = FALSE,
              aes(x = consensus_score, y = GDF15_detection * 100)) +
  scale_colour_manual(values = disease_cols, name = NULL) +
  annotate("text", x = -Inf, y = Inf,
           label = paste0("Spearman rho = ", sprintf("%.2f", gdf_corr$rho),
                          ", ", fmt_p(gdf_corr$p_value)),
           hjust = -0.02, vjust = 1.2, size = 2.05, family = "Arial") +
  labs(title = "VD17 score vs GDF15", x = "VD17 consensus score",
       y = "GDF15-positive cells (%)") + paper_theme +
  theme(legend.position = c(0.78, 0.82),
        legend.background = element_rect(fill = alpha("white", 0.75), colour = NA))

prog_long <- melt(
  endpoint[n_cells >= 5],
  id.vars = c("pair_id", "score_group"),
  measure.vars = c("MAPK_ERK", "ECM_degradation"),
  variable.name = "program", value.name = "score"
)
prog_long[, program := factor(program, levels = c("MAPK_ERK", "ECM_degradation"),
                              labels = c("MAPK/ERK (ERK1/2)", "MMP/ECM degradation"))]
prog_anno <- data.table(
  program = factor(c("MAPK/ERK (ERK1/2)", "MMP/ECM degradation"),
                   levels = levels(prog_long$program)),
  label = c(
    fmt_p(paired_tests[endpoint == "MAPK_ERK", p_value][1]),
    fmt_p(paired_tests[endpoint == "ECM_degradation", p_value][1])
  )
)
pO <- ggplot(prog_long, aes(score_group, score, fill = score_group, group = pair_id)) +
  geom_line(aes(group = pair_id), colour = "#9E9E9E", linewidth = 0.16, alpha = 0.30) +
  geom_boxplot(aes(group = score_group), width = 0.48, outlier.shape = NA,
               linewidth = 0.33, alpha = 0.88) +
  geom_point(shape = 21, size = 0.52, colour = "black", stroke = 0.12,
             position = position_jitter(width = 0.055)) +
  geom_text(data = prog_anno, aes(x = 1.5, y = Inf, label = label),
            inherit.aes = FALSE, vjust = 1.2, size = 1.9, family = "Arial") +
  facet_wrap(~ program, scales = "free_y", nrow = 1) +
  scale_fill_manual(values = score_cols, guide = "none") +
  labs(title = "ERK1/2 and MMP/ECM programs", x = NULL, y = "UCell program score") +
  paper_theme + theme(axis.text.x = element_text(size = 5.8))

prog_corr <- melt(
  overall,
  id.vars = c("pair_id", "disease", "consensus_score"),
  measure.vars = c("MAPK_ERK", "ECM_degradation"),
  variable.name = "program", value.name = "score"
)
prog_corr[, program := factor(program, levels = c("MAPK_ERK", "ECM_degradation"),
                              labels = c("MAPK/ERK (ERK1/2)", "MMP/ECM degradation"))]
corr_anno <- data.table(
  program = factor(c("MAPK/ERK (ERK1/2)", "MMP/ECM degradation"),
                   levels = levels(prog_corr$program)),
  label = c(
    paste0("rho = ", sprintf("%.2f", corr_tests[endpoint == "MAPK_ERK", rho][1]),
           ", ", fmt_p(corr_tests[endpoint == "MAPK_ERK", p_value][1])),
    paste0("rho = ", sprintf("%.2f", corr_tests[endpoint == "ECM_degradation", rho][1]),
           ", ", fmt_p(corr_tests[endpoint == "ECM_degradation", p_value][1]))
  )
)
pP <- ggplot(prog_corr, aes(consensus_score, score, colour = disease)) +
  geom_point(size = 0.75, alpha = 0.72) +
  geom_smooth(aes(group = 1), method = "lm", se = TRUE, colour = "#555555",
              fill = "#D9D9D9", linewidth = 0.4) +
  geom_text(data = corr_anno, aes(x = -Inf, y = Inf, label = label),
            inherit.aes = FALSE, hjust = -0.02, vjust = 1.15,
            size = 1.8, family = "Arial") +
  facet_wrap(~ program, scales = "free_y", nrow = 1) +
  scale_colour_manual(values = disease_cols, name = NULL) +
  labs(title = "VD17 score vs programs", x = "VD17 consensus score",
       y = "UCell program score") + paper_theme +
  theme(legend.position = "bottom", legend.direction = "horizontal")

fig <- (pA | pB | pC | pD) /
       (pE | pF | pG | pH) /
       (pI | pJ | pK | pL) /
       (pM | pN | pO | pP) +
  plot_layout(guides = "keep", heights = c(1.00, 1.00, 1.08, 1.08)) +
  plot_annotation(
    tag_levels = "A",
    theme = theme(
      plot.tag = element_text(family = "Arial", size = 10.5, face = "plain")
    )
  )

pdf_path <- file.path(FD, "Fig2_Williams_VitaminD_GDF15_ERK_MMP_dual_scoring_JHazMat_style.pdf")
png_path <- file.path(FD, "Fig2_Williams_VitaminD_GDF15_ERK_MMP_dual_scoring_JHazMat_style.png")
ggsave(pdf_path, fig, width = 15.3, height = 12.4, units = "in", device = cairo_pdf)

fig_manifest <- list(
  created_at = format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"),
  outputs = c(pdf_path, png_path),
  panel_order = setNames(
    c(
      "UMAP by fibroblast state", "UMAP by gingival disease", "UMAP by donor",
      "Vitamin-D/GDF15/ERK/MMP gene dot plot", "Fibroblast-state disease preference",
      "AddModuleScore by disease", "AUCell by disease", "AddModuleScore by state",
      "AUCell by state", "Paired pseudobulk high-vs-low differential expression",
      "KEGG enrichment", "GO biological-process enrichment", "GDF15 high-vs-low",
      "GDF15 correlation", "ERK1/2 and MMP/ECM high-vs-low", "ERK1/2 and MMP/ECM correlations"
    ), LETTERS[1:16]
  ),
  style = "White background; compact A-P topology; orange-red low/normal and blue high/periodontitis; Arial-like typography; classic thin axes.",
  caveat = "Panel logic and styling match the reference figure; biological labels and axis ranges necessarily reflect Williams human gingival fibroblast data."
)
write_json(fig_manifest, file.path(SD, "16_figure_manifest.json"),
           auto_unbox = TRUE, pretty = TRUE)

cat(pdf_path, "\n", png_path, "\n")
