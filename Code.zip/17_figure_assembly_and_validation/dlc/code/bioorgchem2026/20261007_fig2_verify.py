from pathlib import Path
import json
import hashlib
import fitz
import pandas as pd
from PIL import Image
import sys
OUT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC\\output\\VitaminD_DEG_overlap_FDR005_plus_GDF15_20261007')
if len(sys.argv) > 1:
    OUT = Path(sys.argv[1])
sd = OUT / 'source_data'
pdf = OUT / 'figures' / (sys.argv[2] if len(sys.argv) > 2 else 'Fig2_VitaminD_DEG_FDR005_plus_GDF15_6panels_20261007.pdf')
manifest = json.loads((sd / '16_Fig2_manifest.json').read_text(encoding='utf-8'))
vd = pd.read_csv(manifest['vitaminD_input'])
dis = pd.read_csv(manifest['disease_input'])
strict = set(vd.loc[vd.padj.lt(0.05) & vd.log2FoldChange.abs().ge(manifest.get('vitaminD_abs_log2FC_threshold', 0)), 'gene_symbol'].dropna().str.strip()) - {''}
disease = set(dis.loc[dis['adj.P.Val'].lt(0.05) & dis.logFC.abs().ge(manifest.get('disease_abs_log2FC_threshold', 0)), 'gene'])
expected = (strict | {'GDF15'}) & disease
actual = set(pd.read_csv(sd / '09_vitaminD_gingiva_overlap_genes.csv').gene)
assert expected == actual and len(actual) == manifest['overlap_n']
assert len(strict) == manifest['vitaminD_strict_FDR_n'] and 'GDF15' not in strict
assert len(disease) == manifest['disease_FDR_n']
dis.loc[dis['adj.P.Val'].lt(0.05) & dis.logFC.abs().ge(manifest.get('disease_abs_log2FC_threshold', 0))].to_csv(sd / '19_periodontitis_DEGs_threshold_filtered.csv', index=False, encoding='utf-8-sig')
if 'actual_square_plotting_panels' not in manifest['layout'] and 'actual_rectangular_plotting_panels' not in manifest['layout']:
    assert manifest['layout']['GO_KEGG_ratio'] == 1.2
ecm_checks = {}
if 'square_DEF' in manifest['layout']:
    for panel, dims in manifest['layout']['square_DEF'].items():
        assert panel in 'DEF' and abs(dims[0] - dims[1]) < 1e-09
    import re
    for file, library_files in [('17_GO_displayed_terms.csv', list(sd.glob('10_enrichr_GO_*.csv'))), ('18_KEGG_displayed_terms.csv', [sd / '10_enrichr_KEGG_2021_Human.csv'])]:
        plotted = pd.read_csv(sd / file)
        full = pd.concat([pd.read_csv(f) for f in library_files], ignore_index=True)
        related = full.term.str.contains(manifest['display_selection']['keyword_rule'], case=False, regex=True)
        mixed = manifest['display_selection'].get('mode') == 'mixed_ECM_quota25'
        facet_clean = manifest['display_selection'].get('mode') == 'facet5_clean'
        if facet_clean:
            if file.startswith('17_'):
                category_names = {'Biological': 'BP', 'Cellular': 'CC', 'Molecular': 'MF'}
                full = pd.concat([pd.read_csv(f).assign(category=category_names[f.stem.split('_')[3]]) for f in library_files], ignore_index=True)
                related = full.term.str.contains(manifest['display_selection']['keyword_rule'], case=False, regex=True)
                selected_groups = []
                facet_ecm_counts = {}
                for cat in ['BP', 'CC', 'MF']:
                    terms = manifest['display_selection']['GO_facet_seed_terms'][cat]
                    if isinstance(terms, str):
                        terms = [terms]
                    seeds = full[full.category.eq(cat) & full.term.isin(terms)]
                    other = full[full.category.eq(cat) & ~full.term.isin(terms) & ~related].sort_values(['adjusted_p', 'term']).head(5 - len(seeds))
                    part = pd.concat([seeds, other]).sort_values(['gene_ratio', 'adjusted_p', 'term'], ascending=[False, True, True])
                    displayed = plotted[plotted.category.eq(cat)]
                    assert len(displayed) == 5 and displayed.gene_ratio.is_monotonic_decreasing
                    assert displayed.ECM_related.sum() == len(seeds) and 1 <= len(seeds) <= 2
                    assert displayed.term.tolist() == part.term.tolist()
                    selected_groups.append(part)
                    facet_ecm_counts[cat] = len(seeds)
                selected = pd.concat(selected_groups)
                mf = plotted[plotted.category.eq('MF') & plotted.ECM_related]
                assert mf.iloc[0].overlap_genes == 'TGM2'
                assert 'indirect' in mf.iloc[0].ECM_relation_type
                ecm_checks['GO_facets_five_each'] = True
                ecm_checks['GO_facet_ECM_counts'] = facet_ecm_counts
                ecm_checks['MF_ECM_relation_indirect_only'] = True
            else:
                if 'KEGG_seed_terms' in manifest['display_selection']:
                    seeds = full[full.term.isin(manifest['display_selection']['KEGG_seed_terms'])]
                    other = full[~related].sort_values(['adjusted_p', 'term']).head(13)
                    selected = pd.concat([seeds, other]).sort_values(['gene_ratio', 'adjusted_p', 'term'], ascending=[False, True, True])
                    assert len(seeds) == 2 and seeds.adjusted_p.gt(0.05).all()
                    ecm_checks['C_two_ECM_related_terms_original_FDR_nonsignificant'] = True
                else:
                    selected = full.sort_values(['adjusted_p', 'term']).head(15).sort_values(['gene_ratio', 'adjusted_p', 'term'], ascending=[False, True, True])
                assert len(plotted) == 15 and plotted.gene_ratio.is_monotonic_decreasing
                ecm_checks['KEGG_15_terms_no_ECM_quota'] = True
        elif mixed:
            if file.startswith('17_'):
                full = pd.concat([pd.read_csv(f).assign(category=f.stem.split('_')[3]) for f in library_files], ignore_index=True)
                related = full.term.str.contains(manifest['display_selection']['keyword_rule'], case=False, regex=True)
                seeds = full[full.term.isin(manifest['display_selection']['GO_seed_terms'])]
                other = full[~related].sort_values(['adjusted_p', 'term']).groupby('category', sort=False).head(5)
                selected = pd.concat([seeds, other])
            else:
                seeds = full[related].sort_values(['adjusted_p', 'term'])
                total = min(25, 4 * len(seeds))
                seeds = seeds.head(-(-total // 4))
                selected = pd.concat([seeds, full[~related].sort_values(['adjusted_p', 'term']).head(total - len(seeds))])
            selected = selected.sort_values(['gene_ratio', 'adjusted_p', 'term'], ascending=[False, True, True])
            fraction = plotted.term.str.contains(manifest['display_selection']['keyword_rule'], case=False, regex=True).mean()
            assert 0.25 <= fraction < 1
            panel = 'B' if file.startswith('17_') else 'C'
            ecm_checks[panel + '_ECM_fraction'] = float(fraction)
        else:
            selected = full[related].sort_values(['gene_ratio', 'adjusted_p', 'term'], ascending=[False, True, True])
        if not facet_clean or file.startswith('18_'):
            assert plotted.gene_ratio.is_monotonic_decreasing
        assert plotted.term.tolist() == selected.term.tolist()
        assert (plotted.adjusted_p.reset_index(drop=True) - selected.adjusted_p.reset_index(drop=True)).abs().max() < 1e-12
        assert (plotted['count'] / len(actual) - plotted.gene_ratio).abs().max() < 1e-12
    ecm_checks.update({'square_DEF_inches': manifest['layout']['square_DEF'], 'GeneRatio_descending_top_to_bottom': True, 'ECM_selection_exactly_matches_recorded_rule': True, 'selected_FDR_unchanged_from_full_library': True})
gdf = vd[vd.gene_symbol.eq('GDF15')].iloc[0]
assert gdf.padj > 0.05 and manifest['GDF15']['inclusion_rule'].endswith('NOT_FDR_significant')
hub = pd.read_csv(sd / '15_STRING_MCC_degree_hubs.csv')
network_checks = {}
if manifest.get('network', {}).get('required_score') in [100, 200]:
    required_score = manifest['network']['required_score']
    import networkx as nx
    import math
    edges = pd.read_csv(sd / '11_STRING_functional_network.tsv', sep='\t')
    query = json.loads((sd / '22_STRING_request_audit.json').read_text(encoding='utf-8'))
    assert query['required_score'] == required_score and query['added_nodes'] == 0 and (set(query['genes']) == actual)
    assert query['tsv_sha256'] == hashlib.sha256((sd / '11_STRING_functional_network.tsv').read_bytes()).hexdigest()
    assert edges.score.ge(required_score / 1000).all() and edges.ncbiTaxonId.eq(9606).all()
    g = nx.Graph()
    g.add_nodes_from(actual)
    g.add_edges_from(zip(edges.preferredName_A, edges.preferredName_B))
    assert set(g) == actual and nx.number_of_selfloops(g) == 0
    mcc = {n: 0 for n in g}
    for clique in nx.find_cliques(g):
        if len(clique) >= 2:
            for n in clique:
                mcc[n] += math.factorial(len(clique) - 1)
    for row in hub.itertuples():
        assert row.Degree == g.degree[row.gene] and row.MCC == mcc[row.gene]
    assert g.number_of_edges() == manifest['network']['edges']
    e_graph = g.subgraph(hub.gene.head(20))
    assert e_graph.number_of_edges() == manifest['network']['E_edges']
    old_edges = pd.read_csv(sd / '21_STRING_score400_previous.tsv', sep='\t')
    old_pairs = {tuple(sorted(pair)) for pair in zip(old_edges.preferredName_A, old_edges.preferredName_B)}
    new_pairs = {tuple(sorted(pair)) for pair in g.edges}
    assert old_pairs <= new_pairs
    network_checks = {'STRING_score_threshold': required_score / 1000, 'D_nodes': len(g), 'D_edges': g.number_of_edges(), 'E_nodes': len(e_graph), 'E_edges': e_graph.number_of_edges(), 'previous_score400_edges': len(old_pairs), 'new_edges': len(new_pairs - old_pairs), 'GDF15_neighbors': sorted(g.neighbors('GDF15')), 'network_MCC_degree_independently_verified': True}
    edge_audit = edges.copy()
    edge_audit['new_vs_score400_previous'] = [tuple(sorted((a, b))) not in old_pairs for a, b in zip(edges.preferredName_A, edges.preferredName_B)]
    edge_audit['below_previous_0_4_threshold'] = edges.score.lt(0.4)
    edge_audit.to_csv(sd / f'25_STRING{required_score / 10:03.0f}_edge_audit.csv', index=False, encoding='utf-8-sig')
unverified = manifest.get('STRING_mapping', {}).get('not_verified_genes', [])
assert hub[hub.gene.isin(unverified)][['MCC', 'Degree']].isna().all().all()
d = fitz.open(pdf)
assert len(d) == 1
page = d[0]
fonts = page.get_fonts()
assert all(('Arial' in f[3] for f in fonts))
text = page.get_text()
if network_checks:
    assert '[added]' not in text and 'GDF15' in text
    network_checks['GDF15_plain_label_verified'] = True
    spans = [s for b in page.get_text('dict')['blocks'] for l in b.get('lines', []) for s in l['spans']]
    side = manifest['layout']['square_DEF']['D'][0] * 72
    bottom_left = (page.rect.width - 3 * side) / 2
    for panel, x0 in [('D', bottom_left), ('E', bottom_left + side)]:
        network_labels = [s for s in spans if s['text'] in actual and s['bbox'][1] > page.rect.height - side and (x0 <= s['bbox'][0] < x0 + side)]
        display = manifest['network'].get('D_display')
        expected_labels = display['nodes'] if panel == 'D' and display else 20
        assert len(network_labels) == expected_labels, (panel, len(network_labels))
        for i, s in enumerate(network_labels):
            for other in network_labels[i + 1:]:
                assert (fitz.Rect(s['bbox']) & fitz.Rect(other['bbox'])).get_area() < 0.01, ('network label collision', panel, s, other)
        if panel == 'D' and display:
            assert {s['text'] for s in network_labels} == actual - set(display['hidden_nodes'])
            shown = g.subgraph(actual - set(display['hidden_nodes']))
            assert shown.number_of_edges() == display['edges'] == 39
            shown_file = pd.read_csv(sd / '26_D_displayed_edges.csv')
            assert {tuple(sorted(pair)) for pair in zip(shown_file['from'], shown_file['to'])} == {tuple(sorted(pair)) for pair in shown.edges}
            circles = []
            for drawing in page.get_drawings():
                r = drawing['rect']
                if drawing.get('fill') is not None and drawing['items'] and all((item[0] == 'c' for item in drawing['items'])) and (abs(r.width - r.height) < 0.1) and (5 < r.width < 40) and (r.y0 > page.rect.height - side) and (x0 < r.x0 < r.x1 < x0 + side):
                    circles.append(r)
            assert len(circles) == 16, len(circles)
            for s in network_labels:
                for circle in circles:
                    assert (fitz.Rect(s['bbox']) & circle).get_area() < 0.01, ('D text overlaps node', s, circle)
            for i, circle in enumerate(circles):
                for other in circles[i + 1:]:
                    center = fitz.Point((circle.x0 + circle.x1) / 2, (circle.y0 + circle.y1) / 2)
                    other_center = fitz.Point((other.x0 + other.x1) / 2, (other.y0 + other.y1) / 2)
                    assert center.distance_to(other_center) > (circle.width + other.width) / 2 + 0.1
            previous_pdf = OUT.parent / 'VitaminD_PD_STRING010_compact_GDF15_20261008' / 'figures' / 'Fig2_STRING010_compact_GDF15_20261008.pdf'
            previous = fitz.open(previous_pdf)
            unchanged_region = fitz.Rect(bottom_left + side, page.rect.height - side, page.rect.width, page.rect.height)
            assert page.get_pixmap(dpi=145, clip=unchanged_region).samples == previous[0].get_pixmap(dpi=145, clip=unchanged_region).samples
            previous.close()
            network_checks.update({'D_user_marked_five_nodes_hidden_only': True, 'D_displayed_nodes': 16, 'D_displayed_edges': 39, 'D_labels_do_not_overlap_any_circle': True, 'D_circles_do_not_overlap': True, 'E_F_render_pixels_unchanged': True})
    network_checks['DE_network_gene_labels_no_overlap'] = True
assert 'FDR' in text
if manifest['display_selection'].get('mode') == 'facet5_clean':
    for forbidden in ['not significant', 'full-library', 'All 21 overlap', 'Mixed GO display', 'Mixed KEGG display', 'Gingiva: FDR']:
        assert forbidden not in text, forbidden
    assert all((cat in text for cat in ['BP', 'CC', 'MF']))
    ecm_checks['bottom_explanatory_small_text_removed'] = True
else:
    assert 'not significant' in text
labels = []
out_of_bounds = []
red_spans = []
for block in page.get_text('dict')['blocks']:
    for line in block.get('lines', []):
        for span in line['spans']:
            if span['color'] == int('D73027', 16):
                red_spans.append(span['text'])
            if span['text'] in list('ABCDEF') and span['size'] >= 14:
                labels.append(span['text'])
                r = fitz.Rect(span['bbox'])
                if r.x0 < 0 or r.y0 < 0 or r.x1 > page.rect.width or (r.y1 > page.rect.height):
                    out_of_bounds.append(span)
assert sorted(labels) == list('ABCDEF'), labels
assert not out_of_bounds, out_of_bounds
if 'actual_square_plotting_panels' in manifest['layout']:
    expected_sizes = {round(dims[0] * 72, 3) for dims in manifest['layout']['actual_square_plotting_panels'].values()}
    squares = {}
    for drawing in page.get_drawings():
        for item in drawing['items']:
            if item[0] == 're':
                r = item[1]
                if abs(r.width - r.height) < 0.02 and any((abs(r.width - side) < 0.1 for side in expected_sizes)):
                    squares[tuple((round(v, 3) for v in r))] = [round(r.width, 3), round(r.height, 3)]
    assert len(squares) == 4, squares
    assert sum((abs(dims[0] - 3.2 * 72) < 0.1 for dims in squares.values())) == 3
    c_side = manifest['layout']['actual_square_plotting_panels']['C'][0] * 72
    assert sum((abs(dims[0] - c_side) < 0.1 for dims in squares.values())) == 1
    if manifest['layout'].get('BC_equal_overall_height'):
        b_rects = [fitz.Rect(coords) for coords, dims in squares.items() if abs(dims[0] - 3.2 * 72) < 0.1]
        c_rect = next((fitz.Rect(coords) for coords, dims in squares.items() if abs(dims[0] - c_side) < 0.1))
        top_error = abs(min((r.y0 for r in b_rects)) - c_rect.y0)
        bottom_error = abs(max((r.y1 for r in b_rects)) - c_rect.y1)
        assert top_error < 0.02 and bottom_error < 0.02, (top_error, bottom_error)
        assert abs(manifest['layout']['panel_gtable_metrics']['B']['height_in'] - manifest['layout']['panel_gtable_metrics']['C']['height_in']) < 1e-08
        ecm_checks['BC_top_bottom_alignment_error_points'] = [top_error, bottom_error]
        ecm_checks['BC_equal_overall_height_verified'] = True
    plotted_go = pd.read_csv(sd / '17_GO_displayed_terms.csv')
    expected_red = plotted_go[plotted_go.ECM_related].term_short.tolist()
    if 'KEGG_seed_terms' in manifest['display_selection']:
        plotted_kegg = pd.read_csv(sd / '18_KEGG_displayed_terms.csv')
        expected_red += plotted_kegg[plotted_kegg.ECM_related].term_short.tolist()
    red_text = re.sub('\\s+', ' ', ' '.join(red_spans))
    for label in expected_red:
        assert re.sub('\\s+', ' ', label) in red_text, (label, red_text)
    ecm_checks['actual_B_facets_and_C_square_pdf_rectangles'] = list(squares.values())
    ecm_checks['ECM_labels_red_verified_in_PDF'] = True
    ecm_checks['ECM_red_text'] = red_text
if 'actual_rectangular_plotting_panels' in manifest['layout']:
    shapes = manifest['layout']['actual_rectangular_plotting_panels']
    rectangles = {}
    for drawing in page.get_drawings():
        for item in drawing['items']:
            if item[0] == 're':
                r = item[1]
                if any((abs(r.width - dims[0] * 72) < 0.1 and abs(r.height - dims[1] * 72) < 0.1 for dims in shapes.values())):
                    rectangles[tuple((round(v, 3) for v in r))] = r
    assert len(rectangles) == 4, rectangles
    b_rects = sorted([r for r in rectangles.values() if abs(r.height - shapes['B_BP'][1] * 72) < 0.1], key=lambda r: r.y0)
    assert len(b_rects) == 3
    if manifest['layout'].get('B_three_stacked_square_facets'):
        assert all((abs(r.width - r.height) < 0.02 for r in b_rects))
        assert max((r.x0 for r in b_rects)) - min((r.x0 for r in b_rects)) < 0.02
        ecm_checks['B_three_stacked_square_facets_verified_from_PDF'] = True
    c_rect = next((r for r in rectangles.values() if abs(r.height - shapes['C'][1] * 72) < 0.1))
    assert all((abs(r.width - c_rect.width) < 0.02 for r in b_rects))
    assert abs(b_rects[0].y0 - c_rect.y0) < 0.02 and abs(b_rects[-1].y1 - c_rect.y1) < 0.02
    prev = manifest['layout']['BC_previous_geometry']
    assert all((abs(shapes[key][1] / prev[key][1] - 1 / 3) < 1e-09 for key in shapes))
    label_boxes = []
    for file, side in [('17_GO_displayed_terms.csv', 'B'), ('18_KEGG_displayed_terms.csv', 'C')]:
        plotted = pd.read_csv(sd / file)
        for row in plotted.itertuples():
            matches = [r for r in page.search_for(row.term_short) if r.y0 > b_rects[0].y0 - 15 and r.y1 < c_rect.y1 + 15 and (r.x1 < b_rects[0].x0 + 1 if side == 'B' else r.x0 > b_rects[0].x1 and r.x1 < c_rect.x0 + 1)]
            assert len(matches) == len(row.term_short.split('\n')), (side, row.term_short, matches)
            box = fitz.Rect(matches[0])
            for r in matches[1:]:
                box.include_rect(r)
            label_boxes.append((side, row.term, box))
        red_targets = plotted[plotted.ECM_related].term_short.tolist()
        red_text = re.sub('\\s+', ' ', ' '.join(red_spans))
        for label in red_targets:
            assert re.sub('\\s+', ' ', label) in red_text, (side, label)
    overlaps = []
    for i, (side, term, box) in enumerate(label_boxes):
        for side2, term2, box2 in label_boxes[i + 1:]:
            if side == side2 and (box & box2).get_area() > 0.01:
                overlaps.append([term, term2])
    assert not overlaps, overlaps
    for rect in [b_rects[-1], c_rect]:
        ticks = [s for b in page.get_text('dict')['blocks'] for l in b.get('lines', []) for s in l['spans'] if rect.y1 < s['bbox'][1] < rect.y1 + 15 and rect.x0 - 15 < s['bbox'][0] < rect.x1 + 15]
        for i, s in enumerate(ticks):
            for other in ticks[i + 1:]:
                assert (fitz.Rect(s['bbox']) & fitz.Rect(other['bbox'])).get_area() < 0.01, ('x tick collision', s, other)
    large_spans = [s for b in page.get_text('dict')['blocks'] for l in b.get('lines', []) for s in l['spans'] if abs(s['size'] - manifest['layout']['BC_label_font_pt']) < 0.1]
    assert len(large_spans) >= 30
    spans = [s for b in page.get_text('dict')['blocks'] for l in b.get('lines', []) for s in l['spans']]
    bc_tags = [s for s in spans if s['text'] in ['B', 'C'] and s['size'] >= 17]
    assert len(bc_tags) == 2 and abs(bc_tags[0]['bbox'][1] - bc_tags[1]['bbox'][1]) < 0.02
    for tag_span in bc_tags:
        tag_rect = fitz.Rect(tag_span['bbox'])
        for s in spans:
            if s is not tag_span:
                assert (tag_rect & fitz.Rect(s['bbox'])).get_area() < 0.01, ('tag collision', tag_span, s)
    ecm_checks.update({'BC_same_plot_width_and_equal_overall_height': True, 'BC_row_spacing_multiplier_verified': 1 / 3, 'BC_label_font_pt': manifest['layout']['BC_label_font_pt'], 'all_30_term_labels_present_and_no_label_overlap': True, 'ECM_labels_red_verified_in_PDF': True, 'actual_BC_rectangles_points': [list(r) for r in rectangles.values()]})
page.get_pixmap(dpi=145).save(OUT / 'renders' / 'Fig2_pdf_review.png')
png = pdf.with_suffix('.png')
page.get_pixmap(dpi=600).save(png)
im = Image.open(png)
qa = {**ecm_checks, **network_checks, 'overlap_independently_recomputed': True, 'vitaminD_strict_n': len(strict), 'vitaminD_augmented_n': len(strict | {'GDF15'}), 'disease_threshold_filtered_n': len(disease), 'overlap_n': len(actual), 'strict_overlap_n': len(strict & disease), 'GDF15_manually_included_NOT_FDR_significant': True, 'unverified_mapping_genes': unverified, 'unverified_mapping_hub_scores_unavailable': True, 'fonts': sorted({f[3] for f in fonts}), 'panel_labels': labels, 'labels_inside_page': True, 'GO_KEGG_height_ratio': manifest['layout']['GO_KEGG_ratio'], 'png_pixels': list(im.size), 'png_dpi': im.info.get('dpi'), 'pdf_sha256': hashlib.sha256(pdf.read_bytes()).hexdigest(), 'visual_check': 'pending model inspection of final PDF render'}
(OUT / 'logs' / 'figure_QA.json').write_text(json.dumps(qa, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(qa, ensure_ascii=False, indent=2))
