from pathlib import Path
import json, hashlib, math, sys
import fitz
import pandas as pd
out = Path(sys.argv[1])
abc_top = len(sys.argv) > 2 and sys.argv[2] == 'ABC_top'
balanced = abc_top and len(sys.argv) > 3 and (sys.argv[3] == 'B_center')
src = out / 'logs' / 'Fig2_before_vector_packing.pdf'
dest = out / 'figures' / ('Fig2_ABCtop_AaboveD_20261008.pdf' if abc_top else 'Fig2_tight_C150_Arow2_20261008.pdf')
if balanced:
    dest = out / 'figures' / 'Fig2_B150_centered_ABCtop_20261008.pdf'
sd = out / 'source_data'
manifest = json.loads((sd / '16_Fig2_manifest.json').read_text(encoding='utf-8'))
old = fitz.open(src)
page = old[0]
layout = manifest['layout']
top = layout['new_row_heights_in'][0] * 72
middle = layout['new_row_heights_in'][1] * 72
bottom = layout['square_DEF']['D'][0] * 72
left = (page.rect.width - 3 * bottom) / 2
regions = {'A': fitz.Rect((page.rect.width - 3.6 * 72) / 2, 0, (page.rect.width + 3.6 * 72) / 2, top), 'B': fitz.Rect(0, top, 9.5 * 72, top + middle), 'C': fitz.Rect(9.5 * 72, top, page.rect.width, top + middle), 'D': fitz.Rect(left, top + middle, left + bottom, page.rect.height), 'E': fitz.Rect(left + bottom, top + middle, left + 2 * bottom, page.rect.height), 'F': fitz.Rect(left + 2 * bottom, top + middle, left + 3 * bottom, page.rect.height)}
spans = [s for b in page.get_text('dict')['blocks'] for l in b.get('lines', []) for s in l['spans']]
drawings = page.get_drawings()

def bounds(region, ignore_tag=False):
    objects = []
    for span in spans:
        if ignore_tag and span['text'] in ['B', 'C'] and (span['size'] >= 17):
            continue
        r = fitz.Rect(span['bbox'])
        if region.contains(r):
            objects.append(r)
    for drawing in drawings:
        fill = drawing.get('fill')
        color = drawing.get('color')
        if fill is not None and all((v > 0.99 for v in fill)) and (color is None or all((v > 0.99 for v in color))):
            continue
        r = drawing['rect']
        if r.is_empty:
            r = fitz.Rect(r.x0 - 0.4, r.y0 - 0.4, r.x1 + 0.4, r.y1 + 0.4)
        if region.contains(r):
            objects.append(r)
    assert objects
    result = fitz.Rect(objects[0])
    for r in objects[1:]:
        result.include_rect(r)
    return result + (-3, -3, 3, 3)
crops = {name: bounds(region, name in ['B', 'C']) for name, region in regions.items()}
y0 = min((crops[k].y0 for k in ['B', 'C']))
y1 = max((crops[k].y1 for k in ['B', 'C']))
for key in ['B', 'C']:
    crops[key].y0 = y0
    crops[key].y1 = y1
gap = 12
margin = 5
tag_space = 23
row1w = crops['B'].width + gap + crops['C'].width
row2names = ['D', 'E', 'F'] if abc_top else ['A', 'D', 'E', 'F']
row2w = sum((crops[k].width for k in row2names)) + (len(row2names) - 1) * gap
width = max(row1w + (crops['A'].width + gap if abc_top else 0), row2w) + 2 * margin
row1h = crops['B'].height + tag_space
row2h = max((crops[k].height for k in row2names))
height = 2 * margin + row1h + gap + row2h
result = fitz.open()
target = result.new_page(width=width, height=height)
placements = {}
row1x = width - margin - row1w
placements['B'] = fitz.Rect(row1x, margin + tag_space, row1x + crops['B'].width, margin + tag_space + crops['B'].height)
cx = placements['B'].x1 + gap
placements['C'] = fitz.Rect(cx, margin + tag_space, cx + crops['C'].width, margin + tag_space + crops['C'].height)
bx = margin
by = margin + row1h + gap
if abc_top:
    placements['A'] = fitz.Rect(margin, margin, margin + crops['A'].width, margin + crops['A'].height)
if balanced:
    equal_gap = (placements['C'].x0 - placements['A'].x1 - crops['B'].width) / 2
    assert equal_gap >= gap
    bx_center = placements['A'].x1 + equal_gap
    placements['B'] = fitz.Rect(bx_center, margin + tag_space, bx_center + crops['B'].width, margin + tag_space + crops['B'].height)
for name in row2names:
    placements[name] = fitz.Rect(bx, by, bx + crops[name].width, by + crops[name].height)
    bx = placements[name].x1 + gap
for name in list('ABCDEF'):
    part = fitz.open()
    part.insert_pdf(old, from_page=0, to_page=0)
    pp = part[0]
    crop = crops[name]
    full = pp.rect
    outside = [fitz.Rect(0, 0, full.width, crop.y0), fitz.Rect(0, crop.y1, full.width, full.height), fitz.Rect(0, crop.y0, crop.x0, crop.y1), fitz.Rect(crop.x1, crop.y0, full.width, crop.y1)]
    for r in outside:
        if not r.is_empty:
            pp.add_redact_annot(r, fill=False)
    pp.apply_redactions(images=0, graphics=2, text=0)
    pp.set_cropbox(crop)
    target.show_pdf_page(placements[name], part, 0, keep_proportion=False)
    part.close()
target.insert_font(fontname='Arial', fontfile='C:\\Windows\\Fonts\\arial.ttf')
for name in ['B', 'C']:
    target.insert_text((placements[name].x0, margin + 17), name, fontname='Arial', fontsize=18)
result.save(dest, garbage=4, deflate=True)
result.close()
old.close()
final = fitz.open(dest)
fp = final[0]
previous = fitz.open(src)
rects = {}
shapes = layout['actual_rectangular_plotting_panels']
for drawing in fp.get_drawings():
    for item in drawing['items']:
        if item[0] == 're':
            r = item[1]
            if any((abs(r.width - dims[0] * 72) < 0.1 and abs(r.height - dims[1] * 72) < 0.1 for dims in shapes.values())):
                rects[tuple((round(v, 3) for v in r))] = r
assert len(rects) == 4
b_rects = sorted([r for r in rects.values() if abs(r.height - 1.06666666666667 * 72) < 0.1], key=lambda r: r.y0)
cr = next((r for r in rects.values() if abs(r.height - shapes['C'][1] * 72) < 0.1))
assert len(b_rects) == 3 and all((abs(r.width - shapes['B_BP'][0] * 72) < 0.02 for r in b_rects))
assert abs(cr.width / b_rects[0].width - shapes['C'][0] / shapes['B_BP'][0]) < 0.001
if balanced:
    assert all((abs(r.width / r.height - 1.5) < 0.001 for r in b_rects))
    assert abs(placements['B'].x0 - placements['A'].x1 - (placements['C'].x0 - placements['B'].x1)) < 0.001
assert abs(cr.y0 - b_rects[0].y0) < 0.02 and abs(cr.y1 - b_rects[-1].y1) < 0.02
if abc_top:
    assert placements['A'].y1 < placements['D'].y0
    assert abs(placements['A'].x0 - placements['D'].x0) < 0.001
    assert placements['A'].x1 < placements['B'].x0
else:
    assert placements['A'].y0 > max((placements[k].y1 for k in ['B', 'C']))
assert abs(placements['C'].x1 - (width - margin)) < 0.001
fs = [s for b in fp.get_text('dict')['blocks'] for l in b.get('lines', []) for s in l['spans']]
tags = [s for s in fs if s['text'] in list('ABCDEF') and s['size'] >= 14]
assert sorted((s['text'] for s in tags)) == list('ABCDEF')
assert all(('Arial' in f[3] for f in fp.get_fonts()))
assert '[added]' not in fp.get_text()
for name in ['B', 'C']:
    data = pd.read_csv(sd / ('17_GO_displayed_terms.csv' if name == 'B' else '18_KEGG_displayed_terms.csv'))
    region = placements[name]
    boxes = []
    for row in data.itertuples():
        hits = [r for r in fp.search_for(row.term_short) if region.contains(r)]
        assert len(hits) == len(row.term_short.split('\n')), (name, row.term_short, hits)
        box = fitz.Rect(hits[0])
        for r in hits[1:]:
            box.include_rect(r)
        boxes.append(box)
    assert all(((a & b).get_area() < 0.01 for i, a in enumerate(boxes) for b in boxes[i + 1:]))
    red = ' '.join((s['text'] for s in fs if region.contains(fitz.Rect(s['bbox'])) and s['color'] == int('D73027', 16)))
    for term in data[data.ECM_related].term_short:
        assert ' '.join(term.split()) in ' '.join(red.split())
for name in ['A', 'D', 'E', 'F']:
    old_text = previous[0].get_text('text', clip=crops[name])
    new_text = fp.get_text('text', clip=placements[name])
    assert old_text == new_text, (name, old_text, new_text)
    assert abs(crops[name].width - placements[name].width) < 0.001 and abs(crops[name].height - placements[name].height) < 0.001

def styled_paths(doc_page, region):
    paths = []
    for path in doc_page.get_drawings():
        fill = path.get('fill')
        color = path.get('color')
        r = path['rect']
        if fill is not None and all((v > 0.99 for v in fill)) and (color is None or all((v > 0.99 for v in color))):
            continue
        if region.contains(r):
            paths.append((path['type'], fill, color, path.get('width'), path.get('fill_opacity'), path.get('stroke_opacity'), [r.x0 - region.x0, r.y0 - region.y0, r.x1 - region.x0, r.y1 - region.y0]))
    return paths
for name in ['A', 'D', 'E', 'F']:
    p_old = styled_paths(previous[0], crops[name])
    p_new = styled_paths(fp, placements[name])
    assert len(p_old) == len(p_new), (name, len(p_old), len(p_new))
    for a, b in zip(p_old, p_new):
        assert a[:6] == b[:6], (name, a, b)
        assert max((abs(x - y) for x, y in zip(a[6], b[6]))) < 0.03, (name, a, b)

def image_signatures(doc, doc_page):
    return {(item[2], item[3], hashlib.sha256(doc.extract_image(item[0])['image']).hexdigest()) for item in doc_page.get_images()}
assert image_signatures(final, fp) == image_signatures(previous, previous[0]), 'Only unchanged source colour-bar images are allowed'
d_region = placements['D']
circles = [d['rect'] for d in fp.get_drawings() if d.get('fill') is not None and d['items'] and all((i[0] == 'c' for i in d['items'])) and (5 < d['rect'].width < 40) and (abs(d['rect'].width - d['rect'].height) < 0.1) and d_region.contains(d['rect'])]
d_labels = [s for s in fs if s['text'] in set(pd.read_csv(sd / '23_D_network_layout.csv').gene) and d_region.contains(fitz.Rect(s['bbox']))]
assert len(circles) == 16 and len(d_labels) == 16
assert all(((fitz.Rect(s['bbox']) & r).get_area() < 0.01 for s in d_labels for r in circles))
fp.get_pixmap(dpi=145).save(out / 'renders' / 'Fig2_pdf_review.png')
fp.get_pixmap(dpi=600).save(dest.with_suffix('.png'))
pack = {'source_pdf': str(src), 'crops_points': {k: list(v) for k, v in crops.items()}, 'placements_points': {k: list(v) for k, v in placements.items()}, 'row_order': [['B', 'C'], ['A', 'D', 'E', 'F']], 'inter_panel_gap_points': gap, 'margin_points': margin, 'width_points': width, 'height_points': height, 'C_plot_width_multiplier': 1.5, 'native_vector_copy_no_rasterization': True, 'A_D_E_F_physical_styling_unchanged': True, 'A_D_E_F_vector_shapes_colours_opacity_unchanged': True, 'B_three_square_facets_verified': True, 'BC_plots_same_height': True, 'BC_right_aligned': True, 'BC_15_labels_each_no_overlap': True, 'D_text_circle_nonoverlap_verified': True, 'pdf_sha256': hashlib.sha256(dest.read_bytes()).hexdigest(), 'visual_check': 'pending'}
(out / 'logs' / 'packing_QA.json').write_text(json.dumps(pack, ensure_ascii=False, indent=2), encoding='utf-8')
manifest['layout']['vector_packing'] = pack
pack['row_order'] = [['A', 'B', 'C'], ['D', 'E', 'F']] if abc_top else [['B', 'C'], ['A', 'D', 'E', 'F']]
pack['A_above_D_left_aligned'] = abc_top
pack['B_three_square_facets_verified'] = all((abs(r.width - r.height) < 0.02 for r in b_rects))
pack['B_width_multiplier'] = layout.get('B_width_multiplier', 1)
if balanced:
    pack['BC_right_aligned'] = False
    pack['C_right_aligned'] = True
    pack['B_centered_between_A_C'] = True
    pack['A_to_B_gap_points'] = placements['B'].x0 - placements['A'].x1
    pack['B_to_C_gap_points'] = placements['C'].x0 - placements['B'].x1
(out / 'logs' / 'packing_QA.json').write_text(json.dumps(pack, ensure_ascii=False, indent=2), encoding='utf-8')
manifest['layout']['final_width_in'] = width / 72
manifest['layout']['final_height_in'] = height / 72
(sd / '16_Fig2_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(pack, ensure_ascii=False, indent=2))
