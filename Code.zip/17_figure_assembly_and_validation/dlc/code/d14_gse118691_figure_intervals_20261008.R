suppressPackageStartupMessages(library(limma))
stage <- "C:/Users/Lin/AppData/Local/Temp/gdf15_stim_20261008"
x <- as.matrix(read.delim(file.path(stage,"GSE118691_FPKM.tsv"),row.names=1,check.names=FALSE))
m <- read.csv(file.path(stage,"GSE118691_meta.csv"),stringsAsFactors=FALSE)
m$time_disagreement <- toupper(as.character(m$time_disagreement))=="TRUE"
prior <- read.csv(file.path(stage,"02_GDF15_all_primary_results.csv"),stringsAsFactors=FALSE)
out <- list()
for(hours in c(2,6,12,24,48)) {
  mm <- m[m$title_time==hours & m$condition %in% c("ctrl","Fn") & !m$time_disagreement,,drop=FALSE]
  good <- names(which(table(mm$donor)==2));mm <- mm[mm$donor %in% good,,drop=FALSE]
  xx <- x[,mm$sample,drop=FALSE]
  mm$donor <- factor(mm$donor);mm$condition <- factor(mm$condition,levels=c("ctrl","Fn"))
  design <- model.matrix(~donor+condition,data=mm)
  xx <- xx[rowSums(xx>.5)>=2,,drop=FALSE]
  fit <- eBayes(lmFit(log2(xx+.5),design),trend=TRUE,robust=TRUE)
  k <- which(rownames(fit)=="9518"); j <- which(colnames(design)=="conditionFn")
  mu <- fit$coefficients[k,j]
  se <- fit$stdev.unscaled[k,j]*sqrt(fit$s2.post[k])
  df <- fit$df.total[k]; bound <- qt(.975,df)*se
  pr <- prior[prior$dataset=="GSE118691" & prior$time_h==hours,]
  stopifnot(abs(mu-pr$log2FC)<1e-10,abs(fit$p.value[k,j]-pr$PValue)<1e-10)
  out[[as.character(hours)]] <- data.frame(time_h=hours,n_pairs=length(good),log2FC=mu,
     log2FC_CI_low=mu-bound,log2FC_CI_high=mu+bound,fold_change=2^mu,
     fold_CI_low=2^(mu-bound),fold_CI_high=2^(mu+bound),moderated_SE=se,moderated_df=df,
     PValue=pr$PValue,GDF15_9_comparison_FDR=pr$GDF15_9_comparison_FDR,
     interval_method="paired limma robust-trend moderated t; 95% confidence interval")
}
out <- do.call(rbind,out)
write.csv(out,file.path(stage,"GSE118691_figure_model_intervals.csv"),row.names=FALSE)
print(out)
cat("[DONE] Same-model intervals recovered; previous effects and P-values reproduced\n")
