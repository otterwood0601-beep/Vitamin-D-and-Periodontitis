from pathlib import Path
import json, shutil, sys
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests
sys.stdout.reconfigure(encoding='utf8')
ROOT = Path('E:\\\u8840\u6e05\u7ef4\u751f\u7d20D DLC')
OUT = ROOT / 'output' / 'GDF15_\u6210\u7ea4\u7ef4\u7ec6\u80de\u708e\u75c7\u523a\u6fc0_\u4e09\u961f\u5217_20261008'
STAGE = Path('C:\\Users\\Lin\\AppData\\Local\\Temp\\gdf15_stim_20261008')
SD, CODE = (OUT / 'source_data', OUT / 'code')
for p in STAGE.glob('*.csv'):
    if not p.name.endswith('_meta.csv'):
        shutil.copy2(p, SD / p.name)
shutil.copy2(STAGE / '05_R_sessionInfo.txt', SD / '05_R_sessionInfo.txt')
shutil.copy2(ROOT / 'code' / 'd13_analyze_gdf15_stimulation_20261008.R', CODE / 'd13_analyze_gdf15_stimulation_20261008.R')
res = pd.read_csv(SD / '02_GDF15_all_primary_results.csv')
assert len(res) == 9 and (not res.duplicated(['dataset', 'comparison']).any())
assert np.allclose(multipletests(res.PValue, method='fdr_bh')[1], res.GDF15_9_comparison_FDR)
assert np.allclose(2 ** res.log2FC, res.fold_change)
assert np.isfinite(res[['log2FC', 'PValue', 'transcriptome_FDR']].to_numpy()).all()
checks = []
for _, r in res.iterrows():
    name = r.dataset if r.dataset != 'GSE118691' else r.dataset + ' ' + str(int(r.time_h))
    d = pd.read_csv(SD / ('expression_' + name + '.csv'))
    treatment = r.comparison.split('_vs_ctrl')[0]
    col = 'GDF15_logFPKM' if r.dataset == 'GSE118691' else 'GDF15_logCPM'
    pv = d[d.condition.isin(['ctrl', treatment])].pivot(index='donor', columns='condition', values=col)
    assert not pv.isna().any().any() and len(pv) == r.n_pairs
    delta = pv[treatment] - pv.ctrl
    assert int((delta > 0).sum()) == r.n_pairs_increased
    if r.dataset == 'GSE118691':
        assert np.isclose(delta.mean(), r.log2FC, atol=1e-10)
    else:
        cpm = d.GDF15_count / (d.filtered_library_size * d.TMM_factor) * 1000000.0
        assert np.allclose(cpm, d.GDF15_CPM)
    checks.append(dict(dataset=r.dataset, comparison=r.comparison, n_pairs=len(pv), n_increased=int((delta > 0).sum()), mean_paired_log_expression_change=float(delta.mean()), paired_t_P=float(stats.ttest_1samp(delta, 0).pvalue)))
pd.DataFrame(checks).to_csv(SD / '06_independent_pairing_and_expression_QA.csv', index=False)
sens = pd.read_csv(SD / '03_GSE118691_title_based_sensitivity.csv')
assert all(sens.loc[sens.time_h.isin([12, 24, 48]), 'log2FC'] > 0)
assert (res[res.dataset == 'GSE118691'].query('time_h>=12').GDF15_9_comparison_FDR < 0.05).all()
qa = dict(status='PASS', primary_comparisons=9, paired_effects_checked=9, figures_generated=0, multiple_testing='BH across nine prespecified GDF15 contrasts independently recomputed', temporal_conflicts='Two early-time samples excluded; title-based sensitivity preserves conclusion')
(SD / '07_verification.json').write_text(json.dumps(qa, indent=2, ensure_ascii=False), encoding='utf8')
summary = '\n\n'.join(['GDF15\u708e\u75c7\u523a\u6fc0\u4e09\u961f\u5217\u7ed3\u679c\uff082026-10-08\uff1b\u672a\u51fa\u56fe\uff09', '\u4e3b\u8981\u7ed3\u679c\uff1a1\u4e2a\u5b9e\u9a8c\u6570\u636e\u96c6\u652f\u6301\u7279\u5b9a\u523a\u6fc0\u540e\u8f83\u665a\u9636\u6bb5\u5347\u9ad8\uff1b2\u4e2a\u6570\u636e\u96c6\u663e\u793a\u4e0b\u964d\u3002\u4e0d\u80fd\u6cdb\u5316\u4e3a\u6240\u6709\u708e\u75c7\u6761\u4ef6\u4e0b\u5747\u5347\u9ad8\u3002', 'GSE216757\uff1a5\u540d\u4f9b\u8005\uff0cDMSO\u80cc\u666f\u4e0b\u7259\u9f88\u535f\u5549\u5355\u80de\u83cc\u523a\u6fc04\u5c0f\u65f6\uff0c\u4e0e\u540c\u4e00\u4f9b\u8005\u672a\u523a\u6fc0\u914d\u5bf9\u3002\u6392\u9664DAC\u836f\u7269\u7ec4\u3002GDF15\u4e3a\u5bf9\u71670.627\u500d\uff0c\u4e0b\u964d\u7ea637%\uff1bP=0.005876\uff1b9\u9879GDF15\u6bd4\u8f83FDR=0.007555\uff1b\u5168\u8f6c\u5f55\u7ec4FDR=0.044073\u30025\u5bf9\u4e2d4\u5bf9\u4e0b\u964d\u3002', 'GSE335644\uff1a4\u4e2a\u4f9b\u8005\u7ec6\u80de\u7cfb\uff0c24\u5c0f\u65f6\u3002\u5177\u6838\u68ad\u6746\u83cc\u3001IFN\u03b3\u53ca\u4e8c\u8005\u8054\u5408\u523a\u6fc0\u540e\u5206\u522b\u4e3a\u5bf9\u71670.559\u30010.517\u30010.212\u500d\uff0c\u5747\u663e\u8457\u4e0b\u964d\uff1b\u5404\u523a\u6fc0\u57474/4\u914d\u5bf9\u4e0b\u964d\u3002\u7ec6\u83cc\u5242\u91cfMOI50\u3002', 'GSE118691\uff1a5\u540d\u4f9b\u8005\uff0c\u5177\u6838\u68ad\u6746\u83ccMOI100\u523a\u6fc0\u30022\u30016\u5c0f\u65f6\u65e0\u663e\u8457\u53d8\u5316\uff1b12\u300124\u300148\u5c0f\u65f6\u5206\u522b\u4e3a\u5bf9\u71673.768\u300110.604\u30018.693\u500d\uff0c\u5747\u663e\u8457\u5347\u9ad8\uff1b9\u9879\u6bd4\u8f83FDR\u5206\u522b0.000150\u30012.18e-10\u30011.11e-9\u300212\u5c0f\u65f64\u5bf9\u5747\u5347\u9ad8\uff1b24/48\u5c0f\u65f65\u5bf9\u5747\u5347\u9ad8\u3002', 'FANTOM5\u4e34\u5e8a\u57f9\u517b\u914d\u5bf9\u7ed3\u679c\u6cbf\u7528\u65e2\u5f80\u5206\u6790\uff1a3\u5bf9\uff0c2\u5bf9\u5347\u9ad8\u30011\u5bf9\u964d\u4f4e\uff1b\u7cbe\u786e\u914d\u5bf9P=0.500\uff0c\u4e0d\u652f\u6301\u660e\u786e\u4e34\u5e8a\u5347\u9ad8\u3002', '\u65b9\u6cd5\uff1a\u8ba1\u6570\u6570\u636e\u7528edgeR\uff0cTMM\u5f52\u4e00\u5316\u3001\u4f9b\u8005\u56fa\u5b9a\u6548\u5e94\u3001\u7a33\u5065\u62df\u4f3c\u7136\u68c0\u9a8c\u3002GSE118691\u53ea\u6709\u516c\u5f00FPKM\u77e9\u9635\uff0c\u7528\u6bcf\u4e2a\u65f6\u95f4\u70b9\u7684\u914d\u5bf9limma\uff08log2(FPKM+0.5)\uff0ctrend/robust\uff09\uff0c\u672a\u5c06FPKM\u5f53\u4f5c\u539f\u59cb\u8ba1\u6570\u3002\u4fdd\u7559\u5404\u6bd4\u8f83\u5168\u57fa\u56e0FDR\uff0c\u5e76\u5bf99\u9879\u9884\u8bbeGDF15\u6bd4\u8f83BH\u6821\u6b63\u3002', '\u65f6\u95f4\u6807\u6ce8\u6838\u67e5\uff1aGSE118691\u7684GSM3336696\uff08F2F\uff09\u6807\u98982h\u3001SOFT\u65f6\u95f46h\uff1bGSM3336698\uff08F6F\uff09\u6807\u98986h\u3001SOFT\u65f6\u95f412h\u3002\u4e3b\u5206\u6790\u6392\u9664\u8fd9\u4e24\u4efd\u6837\u672c\uff0c\u6240\u4ee52/6\u5c0f\u65f6\u54044\u5bf9\uff1b12\u5c0f\u65f6F\u4f9b\u8005\u65e0\u660e\u786e\u523a\u6fc0\u6837\u672c\uff0c\u4e3a4\u5bf9\uff1b24/48\u5c0f\u65f6\u54045\u5bf9\u3002\u6309\u6807\u9898\u7eb3\u5165\u65e9\u671f\u7b2c5\u5bf9\u7684\u654f\u611f\u6027\u5206\u6790\u4fdd\u7559\u539f\u7ed3\u8bba\u3002', 'GSE216757\u548cGSE335644\u6709GFHD06\u548cGFHD102\u5171\u540c\u7ec6\u80de\u7cfb\u7f16\u53f7\uff0c\u4e0d\u80fd\u79f0\u4e3a\u5b8c\u5168\u72ec\u7acb\u7684\u4f9b\u8005\u9a8c\u8bc1\u3002\u4e0d\u540c\u7814\u7a76\u7684\u57f9\u517b\u3001\u7ec6\u83cc\u79cd\u7c7b/\u5242\u91cf\u548c\u523a\u6fc0\u65b9\u5f0f\u4e0d\u540c\u3002\u7ed3\u679c\u662f\u4f53\u5916\u6761\u4ef6\u4e0b\u7684\u8868\u8fbe\u53cd\u5e94\uff0c\u4e0d\u80fd\u76f4\u63a5\u8bc1\u660e\u4e34\u5e8a\u7259\u5468\u708e\u4e2d\u7684\u56e0\u679c\u5173\u7cfb\u6216\u86cb\u767d\u91cf\u3002', '\u56feB\uff1a\u539fB\u68c0\u9a8c\u6574\u5757\u7259\u9f88\u7684\u7ec6\u80de\u6bd4\u4f8b\u5f71\u54cd\uff0c\u4e0d\u9002\u7528\u4e8e\u8bba\u8bc1\u5206\u79bb\u6210\u7ea4\u7ef4\u7ec6\u80de\u81ea\u8eab\u8868\u8fbe\u5347\u9ad8\uff0c\u8fd9\u6761\u8bba\u8bc1\u5e94\u53bb\u6389\u539fB\u3002\u5386\u53f2\u6587\u4ef6\u672a\u5220\u9664\uff0c\u672c\u6b21\u672a\u751f\u6210\u56fe\u3002', '\u516c\u5f00\u6765\u6e90\uff1ahttps://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE216757 ; https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE335644 ; https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE118691', '\u539f\u59cb\u77e9\u9635\u548c\u5b8c\u6574GEO\u6837\u672c\u5143\u6570\u636e\u5728raw_data\uff1b\u914d\u5bf9\u660e\u7ec6\u3001\u5168\u90e8\u4e3b\u5206\u6790\u548c\u654f\u611f\u6027\u7ed3\u679c\u5728source_data\uff1b\u811a\u672c\u5728code\u3002\u91cd\u8dd1\u987a\u5e8f\uff1aPython prepare\u5efa\u7acbASCII\u6682\u5b58\u8f93\u5165\uff1bR analyze\u8ba1\u7b97\uff1bPython verify\u5f52\u6863\u548c\u6838\u9a8c\u3002'])
(OUT / '\u7ed3\u679c\u7b80\u8ff0_20261008.txt').write_text(summary, encoding='utf8')
shutil.copy2(__file__, CODE / Path(__file__).name)
print(json.dumps(qa, indent=2, ensure_ascii=False))
print(res[['dataset', 'comparison', 'n_pairs', 'fold_change', 'GDF15_9_comparison_FDR', 'transcriptome_FDR']].to_string(index=False))
